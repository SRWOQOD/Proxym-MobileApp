package com.bankerise.bo.audit.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserUpdateAuditActivityFilterResource {

    private LocalDate creationDate;
    private String qid;
    private String username;
    private String service;
    private String responsesStatus;
}
