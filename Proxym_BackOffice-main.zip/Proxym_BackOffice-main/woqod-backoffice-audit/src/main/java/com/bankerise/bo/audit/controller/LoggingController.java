package com.bankerise.bo.audit.controller;

import com.bankerise.bo.audit.enums.MenuEnum;
import com.woqod.bo.commons.security.Permissions;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping(value = "/audit")
@Controller
@Scope(value = "session")
@Data
public class LoggingController {
    private static final String BO_ACTIVITY = "/audit/boActivity";
    private static final String BE_ACTIVITY = "/audit/beActivity";
    private static final String USER_UPDATE_ACTIVITY = "/audit/userUpdateActivity";
    private static final String BE_CALLS = "/audit/calls";
    private static final String LOGGING_EXCEPTION = "/audit/exception";
    private static final String LOGGING_EVENT = "/audit/event";
    /**
     * beans
     */
    private final Permissions permissions;


    @Autowired
    public LoggingController(Permissions permissions) {
        this.permissions = permissions;
    }

    /**
     * This method used to display Bo User Action page
     */
    @GetMapping(value = "/boActivity")
    public ModelAndView displayBoActivity() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_LOGGING_BO_ACTION.name(), BO_ACTIVITY);
    }

    @GetMapping(value = "/beActivity")
    public ModelAndView displayBeAudit() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_LOGGING_BE_ACTION.name(), BE_ACTIVITY);
    }

    @GetMapping(value = "/userUpdateActivity")
    public ModelAndView displayUserUpdateAudit() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_LOGGING_BE_ACTION.name(), USER_UPDATE_ACTIVITY);
    }
}

