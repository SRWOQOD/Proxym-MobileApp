package com.bankerise.bo.audit.model;

import com.bankerise.bo.audit.constant.LoggingConstant;
import com.bankerise.bo.audit.service.UserUpdateAuditLogService;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.AuditUserUpdateResource;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class UserUpdateAuditLazyModel extends LazyDataModel<AuditUserUpdateResource> {

    private final transient UserUpdateAuditLogService userUpdateAuditLogService;
    private static final long serialVersionUID = 2;

    private transient PaginatedListResponse<AuditUserUpdateResource> data;
    private Map<String, String> uriParams;
    private Boolean searchData = false;

    private LocalDate startDate;
    private LocalDate endDate;

    private Boolean flag = false;

    public UserUpdateAuditLazyModel(UserUpdateAuditLogService userUpdateAuditLogService) {
        this.userUpdateAuditLogService = userUpdateAuditLogService;
        this.uriParams = new HashMap<>();

    }

    @Override
    public Object getRowKey(AuditUserUpdateResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));
    }

    @Override
    public List<AuditUserUpdateResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            if (BooleanUtils.isTrue(searchData)) {
                first = 0;
            }
            PaginatedListResponse<AuditUserUpdateResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));
            response = userUpdateAuditLogService.getPaginatedUserUpdateAuditLogs(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            setSearchData(false);
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", LoggingConstant.AUDIT_BACK_END_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, LoggingConstant.AUDITS);
            log.error(e.getMessage());
            return new ArrayList<>();
        }
    }


}

