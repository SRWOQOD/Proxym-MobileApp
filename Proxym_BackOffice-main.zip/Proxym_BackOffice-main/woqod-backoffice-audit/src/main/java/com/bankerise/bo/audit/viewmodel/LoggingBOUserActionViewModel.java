package com.bankerise.bo.audit.viewmodel;

import com.bankerise.bo.audit.model.BoActivityFilterResource;
import com.bankerise.bo.audit.model.BoAuditLazyModel;
import com.bankerise.bo.audit.service.LoggingService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.base.Strings;
import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.event.ToggleEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.Visibility;
import org.primefaces.util.ComponentUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;

import javax.annotation.PostConstruct;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.ValueHolder;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * User: farouk kraiem
 * Date: 14/04/2020 15:13
 */
@Data
@Slf4j
@Component
@Scope("view")
public class LoggingBOUserActionViewModel {

    private static final String SERVICE_NAME = "BACKOFFICE_LOG";
    /**
     * Beans
     */
    private final LoggingService loggingService;
    private final UserActionService userActionService;
    private LazyDataModel<UserActionModel> lazyModel;
    private BoActivityFilterResource boActivityFilterResource;
    /**
     * Simple attribute
     */
    private String data;
    private String exceptionData;
    private String oldData;
    private StreamedContent file;
    private StreamedContent oldFile;
    private List<String> features;
    private List<String> userNameList;
    private List<String> userActionList;
    private String filename = "boActivity.txt";
    private Boolean toByte = false; // convert from base64
    private String contentType = "text/plain";
    private List<Boolean> list;
    private long numberOfBoUserAuditLogs;

    private String validationError = "Validation Error";


    public LoggingBOUserActionViewModel(LoggingService loggingService, UserActionService userActionService) {
        this.loggingService = loggingService;
        this.userActionService = userActionService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    @PostConstruct
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * This method used to initialize required attributes
     */
    private void init() {
        list = Arrays.asList(true, true, true, true, false, false, true, true, true);
        boActivityFilterResource = new BoActivityFilterResource();
        boActivityFilterResource.setUserAction(new UserActionModel());
        lazyModel = new BoAuditLazyModel(userActionService, boActivityFilterResource.getUserAction(), true, boActivityFilterResource.getStartDate(), boActivityFilterResource.getEndDate());
        userNameList = loggingService.getAllUserName();
        userActionList = userActionService.findAllActions();
        numberOfBoUserAuditLogs = userActionService.count();
        search();
    }

    public void onToggle(ToggleEvent e) {
        list.set((Integer) e.getData(), e.getVisibility() == Visibility.VISIBLE);
    }


    public void search() {
        log.info("[loggingBOUserActionViewModel] search");

        if (!BooleanUtils.isTrue(checkDates())) {
            BoUtils.showErrorPopup(validationError, "Start date must be smaller then end date");
            return;
        }

        ((BoAuditLazyModel) lazyModel).setEnd(boActivityFilterResource.getEndDate());
        ((BoAuditLazyModel) lazyModel).setStart(boActivityFilterResource.getStartDate());
        ((BoAuditLazyModel) lazyModel).setSearch(boActivityFilterResource.getUserAction());
        ((BoAuditLazyModel) lazyModel).setSearchFlag(true);
    }

    public Boolean checkDates() {
        if(boActivityFilterResource.getStartDate() != null && boActivityFilterResource.getEndDate() != null) {
            return boActivityFilterResource.getStartDate().compareTo(boActivityFilterResource.getEndDate()) <= 0;
        }
        return true;
    }


    public void cancel() {
        log.info("[loggingEventViewModel] cancel");
        list = Arrays.asList(true, true, true, true, false, false, true, true, true);
        boActivityFilterResource = new BoActivityFilterResource();
        boActivityFilterResource.setUserAction(new UserActionModel());
        lazyModel = new BoAuditLazyModel(userActionService, boActivityFilterResource.getUserAction(), true, boActivityFilterResource.getStartDate(), boActivityFilterResource.getEndDate());
        userNameList = loggingService.getAllUserName();
        search();
    }


    /**
     * used to return string contain exception value to be showen in exported file
     *
     * @param column
     * @return
     */
    public String exportCustom(UIColumn column) {
        String value = "";
        for (UIComponent child : column.getChildren()) {
            if (child instanceof ValueHolder || child instanceof HtmlInputHidden) {
                value = ComponentUtils.getValueToRender(FacesContext.getCurrentInstance(), child);
            }
        }

        return value;
    }


    public void setData(String data) {
        this.data = data;
        byte[] bval = data.getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        if (BooleanUtils.isTrue(toByte)) {
            stream = new ByteArrayInputStream(Base64.getDecoder().decode(bval));
        }

        InputStream finalStream = stream;
        file = DefaultStreamedContent.builder().contentType(contentType).name(filename).stream(() -> finalStream).build();

    }

    public void setExceptionData(String data) {
        this.exceptionData = data;
        byte[] bval = data.getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        file = DefaultStreamedContent.builder().contentType(contentType).name(filename).stream(() -> stream).build();
    }

    public void setOldData(String data) {
        this.oldData = data;
        byte[] bval = data.getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        oldFile = DefaultStreamedContent.builder().contentType(contentType).name(filename).stream(() -> stream).build();

    }

    public String objToData(Object object) throws JsonProcessingException {
        ObjectWriter mapper = new ObjectMapper().writerWithDefaultPrettyPrinter();
        return mapper.writeValueAsString(object);

    }

    public String shorten(String ipAddress){
        return ipAddress.substring(0, ipAddress.indexOf("/") -1);
    }

}
