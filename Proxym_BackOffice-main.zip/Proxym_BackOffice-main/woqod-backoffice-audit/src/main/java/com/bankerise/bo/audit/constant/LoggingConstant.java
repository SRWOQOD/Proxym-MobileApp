package com.bankerise.bo.audit.constant;

/**
 * Created By Farouk-Kraiem
 *
 * @Date 15/04/2020
 * @Time 10:16
 **/
public final class LoggingConstant {

    private LoggingConstant() {
    }

    public static final String FILE_EXPORT_NAME_BO_ACTIVITY = "boActivity.txt";
    public static final String CONTENT_TYPE = "text/plain";
    public static final String AUDIT_BACK_END_SERVICE_IMPL = "LoggingServiceImpl";
    public static final String AUDIT_USER_UPDATE_SERVICE_IMPL = "UserUpdateAuditLogServiceImpl";
    public static final String AUDIT_BACK_END_REST_CLIENT = "LogsRestClient";
    public static final String AUDIT_USER_UPDATE_REST_CLIENT = "UserUpdateLogsRestClient";
    public static final String AUDIT_BACK_END_LAZY_MODEL = "BeAuditLazyModel";
    public static final String AUDITS = "audits";

}
