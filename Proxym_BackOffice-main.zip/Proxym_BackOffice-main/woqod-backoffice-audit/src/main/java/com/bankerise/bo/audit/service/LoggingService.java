package com.bankerise.bo.audit.service;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.AuditBackEndResource;

import java.util.List;
import java.util.Map;


public interface LoggingService {

    List<String> getAllUserName();

    PaginatedListResponse<AuditBackEndResource> getPaginatedAuditBackEnd(Map<String, String> uriParams);

    Integer count();
}
