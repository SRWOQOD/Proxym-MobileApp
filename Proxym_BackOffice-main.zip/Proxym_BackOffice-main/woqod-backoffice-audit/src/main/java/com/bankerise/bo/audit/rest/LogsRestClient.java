package com.bankerise.bo.audit.rest;


import com.bankerise.bo.audit.constant.LoggingConstant;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AuditBackEndResource;

import java.util.HashMap;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */

@Component
@Slf4j
@PropertySource("classpath:properties/audit.properties")
public class LogsRestClient {

    private final CustomRestTemplate logsTemplate;

    private final String paginatedListAuditBackEnd;

    private final BaseUrlProvider baseUrlProvider;

    private String count;

    @Value("${uri.ws.logs.get}")
    private String getResourceUri;
    @Value("${uri.ws.logs.getWithOffsetAndLimit}")
    private String getWithOffsetAndLimit;
    @Value("${uri.ws.logs.getWithAllParameters}")
    private String getWithAllParameters;

    @Autowired
    public LogsRestClient(CustomRestTemplate logsTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.auditBackEnd.paginated}") String paginatedListAuditBackEnd, @Value("${uri.ws.count.auditBackEnd}") String count) {
        this.logsTemplate = logsTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.paginatedListAuditBackEnd = paginatedListAuditBackEnd;
        this.count = count;
    }


    /**
     * used to get parameters paginated and filtered
     *
     * @param filters
     * @return
     * @throws RestBackendException
     */
    public PaginatedListResponse<AuditBackEndResource> paginatedParams(Map<String, String> filters) {
        log.debug("{} paginatedParams", LoggingConstant.AUDIT_BACK_END_REST_CLIENT);
        String urii = paginatedListAuditBackEnd.concat("/filtered");

        return (PaginatedListResponse<AuditBackEndResource>) logsTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(urii, filters),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<AuditBackEndResource>>>() {
                        });
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) logsTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }

}
