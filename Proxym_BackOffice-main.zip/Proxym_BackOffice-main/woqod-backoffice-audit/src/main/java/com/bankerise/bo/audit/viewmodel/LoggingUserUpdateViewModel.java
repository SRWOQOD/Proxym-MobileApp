package com.bankerise.bo.audit.viewmodel;

import com.bankerise.bo.audit.model.UserUpdateAuditActivityFilterResource;
import com.bankerise.bo.audit.model.UserUpdateAuditLazyModel;
import com.bankerise.bo.audit.service.UserUpdateAuditLogService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.woqod.area.service.AreaService;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.util.ComponentUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.AuditUserUpdateResource;
import wq.woqod.resources.resources.UserBoUpdateResource;
import wq.woqod.resources.resources.UserUpdateResource;

import javax.annotation.PostConstruct;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.ValueHolder;
import javax.faces.context.FacesContext;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


@Data
@Slf4j
@Component
@Scope("view")
public class LoggingUserUpdateViewModel {

    private static final String SERVICE_NAME = "USER_UPDATE_AUDIT_LOG";
    /**
     * Beans
     */
    private final UserUpdateAuditLogService userUpdateAuditLogService;
    private final AreaService areaService;

    private LazyDataModel<AuditUserUpdateResource> lazyModel;
    private UserUpdateAuditActivityFilterResource userUpdateAuditActivityFilterResource;
    private String data;
    private Boolean toByte = false;
    private String contentType = "text/plain";
    private String filename = "userUpdateActivity.txt";
    private StreamedContent file;
    private String exceptionData;
    private UserUpdateResource userResource;
    private UserUpdateResource newUserResource;
    private UserBoUpdateResource boUserResource;
    private UserBoUpdateResource newBoUserResource;
    private String selectedServiceName;

    /**
     * Simple attribute
     */

    private Integer numberOfUserUpdateAuditLogs;

    public LoggingUserUpdateViewModel(UserUpdateAuditLogService userUpdateAuditLogService, AreaService areaService) {
        this.userUpdateAuditLogService = userUpdateAuditLogService;
        this.areaService = areaService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    @PostConstruct
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * This method used to initialize required attributes
     */
    private void init() {
        lazyModel = new UserUpdateAuditLazyModel(userUpdateAuditLogService);
        numberOfUserUpdateAuditLogs = userUpdateAuditLogService.count();
        userUpdateAuditActivityFilterResource = new UserUpdateAuditActivityFilterResource();
        search();
    }

    public void search() {
        log.info("[loggingUserUpdateViewModel] search");
        final Map<String, String> uriParams = new HashMap<>();

        if (userUpdateAuditActivityFilterResource.getQid() != null && !userUpdateAuditActivityFilterResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(userUpdateAuditActivityFilterResource.getQid().trim().getBytes()));
        }
        if (userUpdateAuditActivityFilterResource.getUsername() != null && !userUpdateAuditActivityFilterResource.getUsername().isEmpty()) {
            uriParams.put("username", userUpdateAuditActivityFilterResource.getUsername().trim());
        }
        if (userUpdateAuditActivityFilterResource.getService() != null && !userUpdateAuditActivityFilterResource.getService().isEmpty()) {
            uriParams.put("service", userUpdateAuditActivityFilterResource.getService().trim());
        }
        if (userUpdateAuditActivityFilterResource.getCreationDate() != null) {
            uriParams.put("creationDate", DateFormatter.localDateToStringDate(userUpdateAuditActivityFilterResource.getCreationDate()));
        }
        ((UserUpdateAuditLazyModel) this.lazyModel).setSearchData(true);
        ((UserUpdateAuditLazyModel) this.lazyModel).setUriParams(uriParams);
    }

    public void clear() {
        init();
    }

    public String objToData(Object object) throws JsonProcessingException {
        ObjectWriter mapper = new ObjectMapper().writerWithDefaultPrettyPrinter();
        return mapper.writeValueAsString(object);

    }

    public void setData(String data) throws JsonProcessingException {
        this.data = data;
        if (data.contains("Id") || data.contains("id")) {
            ObjectMapper mapper = JsonMapper.builder()
                    .addModule(new JavaTimeModule())
                    .build();
            mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            userResource = mapper.readValue(data, UserUpdateResource.class);
            if (selectedServiceName.equals("/users/updateUser")) {
                boUserResource = mapper.readValue(data, UserBoUpdateResource.class);
            } else {
                userResource = mapper.readValue(data, UserUpdateResource.class);
            }
        }
    }

    public void setExceptionData(String data) throws JsonProcessingException {
        this.exceptionData = data;
        if (exceptionData.contains("Id") || exceptionData.contains("id")) {
            ObjectMapper mapper = JsonMapper.builder()
                    .addModule(new JavaTimeModule())
                    .build();
            mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            if (!selectedServiceName.equals("/users/updateUser")) {
                newUserResource = mapper.readValue(exceptionData, UserUpdateResource.class);
            } else {
                newBoUserResource = mapper.readValue(exceptionData, UserBoUpdateResource.class);
            }
        }
    }


    public String exportCustom(UIColumn column) {
        String value = "";
        for (UIComponent child : column.getChildren()) {
            if (child instanceof ValueHolder) {
                value = ComponentUtils.getValueToRender(FacesContext.getCurrentInstance(), child);
            }
        }

        return value;
    }

    public String decryptQid(String qid) {
        return BoUtils.decodeFromBase64(qid);
    }

    public String getAreaNameById(String areaId) {
        return areaService.getAreaById(Long.valueOf(areaId)).getAreaNameEn();
    }
}
