package com.bankerise.bo.audit;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

/**
 * User: Nasreddine.Jrebi
 * Date: 04/12/2018 16:06
 */

/**
 * class used to perform autoconfiguratuin
 */
@Configuration
@ComponentScan(basePackages = {"com.bankerise.bo.audit"})
@EnableSpringDataWebSupport
public class AuditConfig {
}
