package com.bankerise.bo.audit;

import com.bankerise.bo.audit.enums.MenuEnum;
import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

/**
 * User: Nasreddine.Jrebi
 * Date: 29/11/2018 14:35
 */
@Component
public class AuditBootstrap {

    private static final String AUDIT_MODULE = "Audit";

    /**
     * used to save menu features and action in menu loader in order to save them in db
     */
    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(AUDIT_MODULE, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }
}



