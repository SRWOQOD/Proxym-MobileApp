package com.bankerise.bo.audit.model;

import com.bankerise.bo.audit.constant.LoggingConstant;
import com.bankerise.bo.audit.service.LoggingService;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.AuditBackEndResource;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class BeAuditLazyModel extends LazyDataModel<AuditBackEndResource> {

    private final transient LoggingService loggingService;
    private static final long serialVersionUID = 2;

    private transient PaginatedListResponse<AuditBackEndResource> data;
    private Map<String, String> uriParams;
    private Boolean searchData = false;

    private LocalDate startDate;
    private LocalDate endDate;

    private Boolean flag = false;

    public BeAuditLazyModel(LoggingService loggingService) {
        this.loggingService = loggingService;
        this.uriParams = new HashMap<>();

    }

    @Override
    public Object getRowKey(AuditBackEndResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));
    }

    @Override
    public List<AuditBackEndResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            if (BooleanUtils.isTrue(searchData)) {
                first = 0;
            }
            PaginatedListResponse<AuditBackEndResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));
            response = loggingService.getPaginatedAuditBackEnd(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            setSearchData(false);
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", LoggingConstant.AUDIT_BACK_END_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, LoggingConstant.AUDITS);
            log.error(e.getMessage());
            return new ArrayList<>();
        }

    }
}

