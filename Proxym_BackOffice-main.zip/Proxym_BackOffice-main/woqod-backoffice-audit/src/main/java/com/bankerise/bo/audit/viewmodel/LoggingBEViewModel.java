package com.bankerise.bo.audit.viewmodel;

import com.bankerise.bo.audit.model.BeActivityFilterResource;
import com.bankerise.bo.audit.model.BeAuditLazyModel;
import com.bankerise.bo.audit.service.LoggingService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.base.Strings;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.util.ComponentUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.AuditBackEndResource;

import javax.annotation.PostConstruct;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.ValueHolder;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


@Data
@Slf4j
@Component
@Scope("view")
public class LoggingBEViewModel {

    private static final String SERVICE_NAME = "BACKEND_LOG";
    /**
     * Beans
     */
    private final LoggingService loggingService;
    private LazyDataModel<AuditBackEndResource> lazyModel;
    private BeActivityFilterResource beActivityFilterResource;
    private String data;
    private Boolean toByte = false; // convert from base64
    private String contentType = "text/plain";
    private String filename = "beActivity.txt";
    private StreamedContent file;
    private String exceptionData;
    /**
     * Simple attribute
     */

    private Integer numberOfBEUserAuditLogs;

    public LoggingBEViewModel(LoggingService loggingService) {
        this.loggingService = loggingService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    @PostConstruct
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * This method used to initialize required attributes
     */
    private void init() {
        lazyModel = new BeAuditLazyModel(loggingService);
        numberOfBEUserAuditLogs = loggingService.count();
        beActivityFilterResource = new BeActivityFilterResource();
        search();
    }

    public void search() {
        log.info("[loggingBEViewModel] search");
        final Map<String, String> uriParams = new HashMap<>();

        if (beActivityFilterResource.getQid() != null && !beActivityFilterResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(beActivityFilterResource.getQid().getBytes()));
        }
        if (beActivityFilterResource.getService() != null && !beActivityFilterResource.getService() .isEmpty()) {
            uriParams.put("service", beActivityFilterResource.getService() .trim());
        }
        if (beActivityFilterResource.getResponsesStatus() != null && !beActivityFilterResource.getResponsesStatus().isEmpty()) {
            uriParams.put("responseDescription", beActivityFilterResource.getResponsesStatus().trim());
        }
        if (beActivityFilterResource.getCreationDate() != null) {
            uriParams.put("creationDate", DateFormatter.localDateToStringDate(beActivityFilterResource.getCreationDate()));
        }
        ((BeAuditLazyModel) this.lazyModel).setSearchData(true);
        ((BeAuditLazyModel) this.lazyModel).setUriParams(uriParams);
    }

    public void clear() {
     init();
    }

    public String objToData(Object object) throws JsonProcessingException {
        ObjectWriter mapper = new ObjectMapper().writerWithDefaultPrettyPrinter();
        return mapper.writeValueAsString(object);

    }

    public void setData(String data) {
        this.data = data;
        byte[] bval = data.getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        if (BooleanUtils.isTrue(toByte)) {
            stream = new ByteArrayInputStream(Base64.getDecoder().decode(bval));
        }

        InputStream finalStream = stream;
        file = DefaultStreamedContent.builder().contentType(contentType).name(filename).stream(() -> finalStream).build();

    }

    public void setExceptionData(String data) {
        this.exceptionData = data;
        byte[] bval = data.getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        file = DefaultStreamedContent.builder().contentType(contentType).name(filename).stream(() -> stream).build();
    }


    public String exportCustom(UIColumn column) {
        String value = "";
        for (UIComponent child : column.getChildren()) {
            if (child instanceof ValueHolder) {
                value = ComponentUtils.getValueToRender(FacesContext.getCurrentInstance(), child);
            }
        }

        return value;
    }

    public String decryptQid(String qid) {
        return BoUtils.decodeFromBase64(qid);
    }

}
