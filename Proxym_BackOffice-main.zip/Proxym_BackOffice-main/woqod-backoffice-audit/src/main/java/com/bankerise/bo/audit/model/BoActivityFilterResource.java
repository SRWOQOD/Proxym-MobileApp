package com.bankerise.bo.audit.model;

import com.woqod.bo.commons.model.UserActionModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BoActivityFilterResource {

    private LocalDate startDate;
    private LocalDate endDate;
    private UserActionModel userAction;
}
