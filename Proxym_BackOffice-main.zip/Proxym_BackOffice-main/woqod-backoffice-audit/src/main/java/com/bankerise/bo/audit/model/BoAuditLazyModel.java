package com.bankerise.bo.audit.model;

import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class BoAuditLazyModel extends LazyDataModel<UserActionModel> {

    private final transient UserActionService userActionService;
    private static final long serialVersionUID = 1;

    private Boolean displayData;
    private transient UserActionModel search;
    private LocalDate start;
    private LocalDate end;
    private Boolean searchFlag = false;

    public BoAuditLazyModel(UserActionService userActionService, UserActionModel search, Boolean displayData, LocalDate start, LocalDate end) {
        this.userActionService = userActionService;
        this.displayData = displayData;
        this.search = search;
        this.start = start;
        this.end = end;
    }


    @Override
    public Object getRowKey(UserActionModel object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));
    }


    @Override
    public List<UserActionModel> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                      Map<String, FilterMeta> filters) {

        try {
            if (BooleanUtils.isTrue(searchFlag)) {
                first = 0;
            }
            Page<UserActionModel> response;
            int page = first / pageSize;

            response = userActionService.getFilteredUserAction(search,
                    PageRequest.of(page, pageSize, (sortOrder.equals(SortOrder.ASCENDING) ? Sort.Direction.ASC : Sort.Direction.DESC ),"actionDate"),
                    start, end);

            this.setRowCount((int) response.getTotalElements());
            this.setPageSize(pageSize);
            searchFlag = false;
            return response.getContent();

        } catch (RestBackendException e) {
            log.info("{} load", "BoAuditLazyModel");
            return new ArrayList<>();
        }

    }
}