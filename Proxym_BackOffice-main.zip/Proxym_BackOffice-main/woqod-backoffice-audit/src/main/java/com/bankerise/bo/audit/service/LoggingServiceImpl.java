package com.bankerise.bo.audit.service;


import com.bankerise.bo.audit.constant.LoggingConstant;
import com.bankerise.bo.audit.rest.LogsRestClient;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AuditBackEndResource;

import java.util.List;
import java.util.Map;

/**
 * Created By Farouk-Kraiem
 *
 * @Date 24/04/2020
 * @Time 09:09
 **/

@Slf4j
@Service
@Data
public class LoggingServiceImpl implements LoggingService {
    private static final String LOGGING_SERVICE_IMPL = "[ LoggingServiceImpl ]";

    private final UserService userService;

    private final LogsRestClient logsRestClient;

    @Autowired
    public LoggingServiceImpl(UserService userService, LogsRestClient logsRestClient) {
        this.userService = userService;
        this.logsRestClient = logsRestClient;
    }


    @Override
    public List<String> getAllUserName() {
        log.debug("{} getAllUserName", LOGGING_SERVICE_IMPL);
        return userService.findAllUserName();
    }


    @Override
    public PaginatedListResponse<AuditBackEndResource> getPaginatedAuditBackEnd(Map<String, String> uriParams) {
        log.debug("{} getPaginatedAuditBackEnd ", LoggingConstant.AUDIT_BACK_END_SERVICE_IMPL);
        return logsRestClient.paginatedParams(uriParams);
    }

    @Override
    public Integer count() {
        return logsRestClient.count();
    }

}
