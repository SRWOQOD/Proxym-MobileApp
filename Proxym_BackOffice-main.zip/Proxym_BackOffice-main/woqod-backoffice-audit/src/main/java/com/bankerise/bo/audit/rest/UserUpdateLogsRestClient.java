package com.bankerise.bo.audit.rest;


import com.bankerise.bo.audit.constant.LoggingConstant;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AuditUserUpdateResource;

import java.util.Map;

/**
 * @author nada.achour
 * on 18/10/2022
 */

@Component
@Slf4j
@PropertySource("classpath:properties/user-update-audit.properties")
public class UserUpdateLogsRestClient {

    private final CustomRestTemplate logsTemplate;

    private final String paginatedListUserUpdateAudit;

    private final BaseUrlProvider baseUrlProvider;

    private String count;

    @Value("${uri.ws.logs.get}")
    private String getResourceUri;

    @Autowired
    public UserUpdateLogsRestClient(CustomRestTemplate logsTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.audit.paginated}") String paginatedListAuditBackEnd, @Value("${uri.ws.count.audit}") String count) {
        this.logsTemplate = logsTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.paginatedListUserUpdateAudit = paginatedListAuditBackEnd;
        this.count = count;
    }


    /**
     * used to get parameters paginated and filtered
     *
     * @param filters
     * @return
     * @throws RestBackendException
     */
    public PaginatedListResponse<AuditUserUpdateResource> paginatedParams(Map<String, String> filters) {
        log.debug("{} paginatedParams", LoggingConstant.AUDIT_USER_UPDATE_REST_CLIENT);
        String urii = paginatedListUserUpdateAudit.concat("/filtered");

        return (PaginatedListResponse<AuditUserUpdateResource>) logsTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(urii, filters),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<AuditUserUpdateResource>>>() {
                        });
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) logsTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse>>() {
                        });
        return response.getObject();
    }

}
