package com.bankerise.bo.audit.service;


import com.bankerise.bo.audit.constant.LoggingConstant;
import com.bankerise.bo.audit.rest.LogsRestClient;
import com.bankerise.bo.audit.rest.UserUpdateLogsRestClient;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AuditBackEndResource;
import wq.woqod.resources.resources.AuditUserUpdateResource;

import java.util.List;
import java.util.Map;

/**
 * Created By nada-achour
 *
 * @Date 18/10/2022
 * @Time 01:12
 **/

@Slf4j
@Service
@Data
public class UserUpdateAuditLogServiceImpl implements UserUpdateAuditLogService {
    private static final String USER_UPDATE_LOGGING_SERVICE_IMPL = "[ UserUpdateLoggingServiceImpl ]";

    private final UserService userService;

    private final UserUpdateLogsRestClient userUpdateLogsRestClient;

    @Autowired
    public UserUpdateAuditLogServiceImpl(UserService userService, UserUpdateLogsRestClient userUpdateLogsRestClient) {
        this.userService = userService;
        this.userUpdateLogsRestClient = userUpdateLogsRestClient;
    }


    @Override
    public List<String> getAllUserName() {
        log.debug("{} getAllByUserName", USER_UPDATE_LOGGING_SERVICE_IMPL);
        return userService.findAllUserName();
    }

    @Override
    public PaginatedListResponse<AuditUserUpdateResource> getPaginatedUserUpdateAuditLogs(Map<String, String> uriParams) {
        log.debug("{} getPaginatedUserUpdateAuditLogs ", LoggingConstant.AUDIT_USER_UPDATE_SERVICE_IMPL);
        return userUpdateLogsRestClient.paginatedParams(uriParams);
    }

    @Override
    public Integer count() {
        return userUpdateLogsRestClient.count();
    }

}
