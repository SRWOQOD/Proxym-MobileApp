package com.woqod.management.service;


import wq.woqod.resources.resources.AmountResource;

import java.util.HashMap;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
public interface IManagementService {

    AmountResource getAmount();

    void updateAmount(HashMap<String, Object> serviceData);
}
