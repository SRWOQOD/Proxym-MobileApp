package com.woqod.management.utils;

public final class Constants {
    public static final String MANAGEMENT_URL = "/amount";

    private Constants() {
    }
}
