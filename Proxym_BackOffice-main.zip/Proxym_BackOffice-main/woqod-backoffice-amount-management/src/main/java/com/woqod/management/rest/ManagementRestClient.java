package com.woqod.management.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AmountResource;

import java.util.HashMap;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */

@Component
@Slf4j
@PropertySource("classpath:properties/management.properties")
public class ManagementRestClient {

    private final CustomRestTemplate amountRestTemplate = new CustomRestTemplate();

    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.management.get}")
    private String getResourceUri;

    @Value("${uri.ws.management.update}")
    private String updateUri;

    public ManagementRestClient(BaseUrlProvider baseUrlProvider) {
        this.baseUrlProvider = baseUrlProvider;
    }


    public AmountResource getAmount() {

        ObjectResponse<AmountResource> response = (ObjectResponse<AmountResource>) amountRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(getResourceUri), new ParameterizedTypeReference<GenericResponse<ObjectResponse<AmountResource>>>() {
                });
        return response.getObject();
    }


    public BooleanResponse updateAmount(AmountResource amountResource) {
        HashMap<String, String> data = new HashMap<>();
        data.put("max", String.valueOf(amountResource.getMaxAmount()));
        data.put("min", String.valueOf(amountResource.getMinAmount()));

        return amountRestTemplate
                .getBooleanResponse(baseUrlProvider.getUrl(updateUri, data));
    }

}
