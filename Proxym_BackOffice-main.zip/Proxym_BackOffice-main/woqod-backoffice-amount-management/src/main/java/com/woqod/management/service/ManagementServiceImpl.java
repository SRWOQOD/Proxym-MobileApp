package com.woqod.management.service;


import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.management.rest.ManagementRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AmountResource;

import java.util.HashMap;

/**
 * @author med-amine.dahmen
 * on 07/2/2020
 */
@Service
@Slf4j
public class ManagementServiceImpl implements IManagementService {

    private final ManagementRestClient managementRestClient;

    public ManagementServiceImpl(ManagementRestClient managementRestClient) {
        this.managementRestClient = managementRestClient;
    }

    @Override
    public AmountResource getAmount() {
        return managementRestClient.getAmount();
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void updateAmount(HashMap<String, Object> serviceData) {
        AmountResource amountResource = (AmountResource) serviceData.get(UtilsConstants.POST_DATA);
        managementRestClient.updateAmount(amountResource);
    }


}
