package com.woqod.management;


import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.management.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
@Component
public class ManagementBootstarp {
    private static final String AMOUNT_MANAGEMENT = "WOQODe Amount Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(AMOUNT_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }

}
