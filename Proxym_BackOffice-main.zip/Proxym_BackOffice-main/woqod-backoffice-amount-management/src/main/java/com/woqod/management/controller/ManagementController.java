package com.woqod.management.controller;

import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.management.enums.MenuEnum;
import com.woqod.management.service.IManagementService;
import com.woqod.management.utils.Constants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.resources.resources.AmountResource;
import java.util.HashMap;

@Controller
@RequestMapping(value = Constants.MANAGEMENT_URL)
@Data
@Slf4j
public class ManagementController {


    private static final String MANAGEMENTAMOUNT = "managementAmount";
    private final Permissions permissions;
    private IManagementService iManagementService;
    private AmountResource amountResource;
    private String validationError = "Validation Error";


    @Autowired
    public ManagementController(IManagementService iManagementService, Permissions permissions) {
        this.iManagementService = iManagementService;
        this.permissions = permissions;
    }


    @GetMapping("")
    public ModelAndView display() {
        init();
        return permissions.getModelAndView(MenuEnum.DISPLAY_EDIT_AMOUNT.name(), MANAGEMENTAMOUNT);
    }

    public void init() {
        this.amountResource = iManagementService.getAmount();
    }

    public void save() {
        if (checkValidity()) {
            HashMap<String, Object> serviceData = new HashMap<>();
            serviceData.put(UtilsConstants.FEATURE, MenuEnum.DISPLAY_EDIT_AMOUNT.name());
            serviceData.put(UtilsConstants.POST_DATA, amountResource);

            try {
                iManagementService.updateAmount(serviceData);
                BoUtils.showsuccesspopup();
            } catch (RestBackendException exception) {
                BoUtils.showErrorPopup("Failed", exception.getDescription());
            }
        }
    }

    public boolean checkValidity() {
        boolean checkValidity = false;
        if (amountResource != null && amountResource.getMaxAmount() != null && amountResource.getMinAmount() != null) {
            if (amountResource.getMaxAmount() <= 0) {
                BoUtils.showErrorPopup(validationError, "Max must be bigger than 0.");
            } else if (amountResource.getMinAmount() < 0) {
                BoUtils.showErrorPopup(validationError, "Min must be bigger or equal to 0.");
            } else if (amountResource.getMaxAmount() <= amountResource.getMinAmount()) {
                BoUtils.showErrorPopup(validationError, "Max must be bigger than Min.");
            } else {
                checkValidity = true;
            }
        }
        return checkValidity;
    }
}
