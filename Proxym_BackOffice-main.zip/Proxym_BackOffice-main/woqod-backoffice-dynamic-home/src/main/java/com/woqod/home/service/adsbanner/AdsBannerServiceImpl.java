package com.woqod.home.service.adsbanner;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.home.rest.AdsBannerRestClient;
import com.woqod.home.rest.AppRedirectionRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AdsBannerResource;
import wq.woqod.resources.resources.AppRedirectionRessource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class AdsBannerServiceImpl implements AdsBannerService {

    private final AdsBannerRestClient adsBannerRestClient;
    private final AppRedirectionRestClient appRedirectionRestClient;

    @Autowired
    public AdsBannerServiceImpl(AdsBannerRestClient adsBannerRestClient, AppRedirectionRestClient appRedirectionRestClient) {
        this.adsBannerRestClient = adsBannerRestClient;
        this.appRedirectionRestClient = appRedirectionRestClient;
    }

    @Override
    public List<AdsBannerResource> getAllAds() {
        return adsBannerRestClient.getAdsbanner();
    }

    @Override
    public List<AppRedirectionRessource> getAppRedirectionList() {
        return appRedirectionRestClient.getAppRedirectionList();
    }

    @Override
    public AppRedirectionRessource getByName(String name) {
        return appRedirectionRestClient.getByName(name);
    }

    @Override
    public List<AdsBannerResource> filteredAdsBanner(Map<String, String> uriParams) {
        return adsBannerRestClient.filteredAdsBanner(uriParams);
    }

    @Override
    public AdsBannerResource getById(String adsId) {
        return adsBannerRestClient.getById(adsId);
    }

    @Override
    public void update(List<AdsBannerResource> activeAd) {
        adsBannerRestClient.update(activeAd);
    }

    @Override
    public void update(AdsBannerResource adsBannerResource) {
        adsBannerRestClient.update(adsBannerResource);
    }

    @Override
    public Integer count() {
        return adsBannerRestClient.count();
    }

    @Override
    public void delete(String id) {
        adsBannerRestClient.delete(id);
    }
}
