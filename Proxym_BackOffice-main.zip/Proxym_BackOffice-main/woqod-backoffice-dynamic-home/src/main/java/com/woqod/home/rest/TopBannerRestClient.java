package com.woqod.home.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.TopBannerResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/top.properties")
public class TopBannerRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
    external config attributes
     */
    private String topbanner;
    private String count;

    @Autowired
    public TopBannerRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.topbanner}") String topbanner, @Value("${uri.ws.topbanner.count}") String count) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.topbanner = topbanner;
        this.count = count;
    }

    public List<TopBannerResource> findAll() {
        String uri = topbanner.concat("/all");
        return BannersRestClient.getBannerList(customRestTemplate,baseUrlProvider,uri);

    }


    /**
     * used to get parameters paginated and filtred
     *
     * @return
     */
    public List<TopBannerResource> paginatedParams(Map<String, String> uriParams) {
        String uri = topbanner.concat("/filtered");
        return BannersRestClient.getBannerPaginatedList(customRestTemplate, baseUrlProvider, uri, uriParams);
    }

    public TopBannerResource getById(String topId) {
        String uri = topbanner.concat("/").concat(topId);
        ObjectResponse<TopBannerResource> response = (ObjectResponse<TopBannerResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<TopBannerResource>>>() {
                        });
        return response.getObject();
    }

    public Boolean update(List<TopBannerResource> activeTop) {
        String uri = topbanner + "/all";
        BooleanResponse response = BannersRestClient.update(customRestTemplate, baseUrlProvider, uri, activeTop);
        return response.isSuccess();
    }

    public Boolean update(TopBannerResource activeTop) {
        String uri = topbanner;
        BooleanResponse response = BannersRestClient.update(customRestTemplate, baseUrlProvider, uri, activeTop);
        return response.isSuccess();
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = BannersRestClient.count(customRestTemplate, baseUrlProvider, uri);
        return response.getObject();
    }
    public Boolean delete(String id) {
        String uri = topbanner + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

}
