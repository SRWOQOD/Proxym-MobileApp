package com.woqod.home.viewmodel.businessbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.topbanner.TopBannerService;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.FileUploadResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

import static wq.woqod.resources.enumerations.FileSubjectEnum.BUSINESS_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class AddBusinessBannerViewModel {
    /*
    Beans
     */
    private final DataFactory dataFactory;
    private final TopBannerService topBannerService;
    private final FileRestClient restClient;
    /*
    state
    */
    private FileUploadResource adsResource;
    private List<FileTypeEnum> fileTypeEnum;
    private List<String> appRedirections;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private String selectedAppRedirection;
    private String encodedImage;
    private String encodedIconChecked;
    private String encodedIconUnChecked;
    private String redirectionPath = "Redirection Path";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";
    private static final String ERROR_UPLOADING_FILE  =  "An error has occured when uploading file : ";
    private static final String IS_UPLOADED  =  "is uploaded.";

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        fileTypeEnum = new ArrayList<>();
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(topBannerService.getAppRedirectionList().stream().map(AppRedirectionRessource::getName).collect(Collectors.toList()));
        this.adsResource = FileUploadResource.builder().subject(BUSINESS_BANNER).extension(CommonViewModel.DEFAULT_PICTURE_EXTENSION).isNewFile(Boolean.TRUE).build();
    }

    public void save() {

        adsResource.setCheckedIcon(encodedIconChecked);
        adsResource.setUnCheckedIcon(encodedIconUnChecked);
        adsResource.setFile(encodedImage);

        // Validate URL if filled
        if (BooleanUtils.isTrue(adsResource.getRedirection()) && adsResource.getRedirectionTypeEnum() == RedirectionTypeEnum.URL) {

            if (!this.isValidUrl(adsResource.getRedirectionPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection Path");
                return;
            }

            if (!this.isValidUrl(adsResource.getRedirectionArPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection Path");
                return;
            }
        }

        // Validate APP if filled
        if (BooleanUtils.isTrue(adsResource.getRedirection()) && adsResource.getRedirectionTypeEnum() == RedirectionTypeEnum.APP) {

            if (StringUtils.isBlank(selectedAppRedirection)) {
                BoUtils.showErrorPopup("App Redirection", "App Redirection must not be empty");
                return;
            } else {
                adsResource.setAppRedirection(selectedAppRedirection);
            }
        }

        if (Objects.isNull(adsResource.getFile()) || Objects.isNull(adsResource.getUnCheckedIcon()) || Objects.isNull(adsResource.getCheckedIcon())) {
            BoUtils.showErrorPopup("Validation error", "Image and icons are mandatory");
            return;
        }

        try {
            restClient.addItem(adsResource);
            BoUtils.showsuccesspopup();
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup(error, errorMessage);
        }
        dataFactory.redirect("businessBanner");

    }

    private boolean isValidUrl(String url) {
        try {
            new URL(url).toURI();
            return true;
        } catch (URISyntaxException | MalformedURLException exception) {
            return false;
        }
    }

    public void handleEncodedImageUpload(FileUploadEvent fileUploadEvent) {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error(ERROR_UPLOADING_FILE+ e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if (bi != null){
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (width < 1024 || height < 452) {
                BoUtils.showErrorPopup("Image ", "Kindly attach an image with 1024 height and 452 width");
            } else {
                encodedImage = Base64
                        .getEncoder()
                        .encodeToString(fileImage.getContent());
                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + IS_UPLOADED);
            }
        }
    }

    public void handleEncodedIconCheckedUpload(FileUploadEvent fileUploadEvent) {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error(ERROR_UPLOADING_FILE + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (104 > height || width < 105) {
                BoUtils.showErrorPopup("File", "Kindly attach an image with 104 height and 105 width");
            } else {
                encodedIconChecked = Base64
                        .getEncoder()
                        .encodeToString(fileImage.getContent());
                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + IS_UPLOADED);
            }
        }
    }

    public void handleEncodedIconUnCheckedUpload(FileUploadEvent fileUploadEvent) {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error(ERROR_UPLOADING_FILE + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (104 > height || width < 105) {
                BoUtils.showErrorPopup("File", "Kindly attach an image with 104 height and 105 width");
            } else {
                encodedIconUnChecked = Base64
                        .getEncoder()
                        .encodeToString(fileImage.getContent());
                BoUtils.showInfoPopup("Unselected Icon", fileUploadEvent.getFile().getFileName() + IS_UPLOADED);
            }
        }
    }

    public void clear() {
        init();
    }

}

