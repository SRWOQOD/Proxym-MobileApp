package com.woqod.home.constatnt;

public final class HomeConstant {
    public static final String ADS_BANNER_MANAGEMENT_URL = "/adsBanner";
    public static final String TOP_BANNER_MANAGEMENT_URL = "/topBanner";
    public static final String BUSINESS_BANNER_MANAGEMENT_URL = "/businessBanner";
    public static final String APP_TIPS_MANAGEMENT_URL = "/apptips";

    public static final String BUNDLE_NAME = "home_messages";
    public static final String ADS_LIST = "adsbanner";
    public static final String TIPS_LIST = "apptips";
    public static final String TOP_LIST = "topbanner";
    public static final String BUSINESS_LIST = "businessbanner";
    public static final String ADS_ID = "id";
    public static final String TOP_ID = "id";
    public static final String EDIT_ADS = "editAds";
    public static final String EDIT_TOP = "editop";
    public static final String EDIT_BUSINESS = "editBusiness";
    public static final String EDIT_URL = "adsBanner/edit?id=";
    public static final String EDIT_TIPS_URL = "apptips/edit?id=";
    public static final String EDIT_TOP_URL = "topBanner/edit?id=";
    public static final String EDIT_BUSINESS_URL = "businessBanner/edit?id=";
    public static final String BACK_URL = "/adsBanner";
    public static final String BACK_APP_TIPS_URL = "/apptips";
    public static final String BACK_TOP_URL = "topBanner";
    public static final String BACK_BUSINESS_URL = "/businessBanner";
    public static final String ADD_ADS = "addAdsbanner";
    public static final String ADD_BUSINESS = "addBusinessbanner";
    public static final String ADD_ADS_PATH = "/adsBanner/add";
    public static final String ADD_TOP_BANNER_MANAGEMENT_URL = "/topBanner/add";
    public static final String ADD_BUSINESS_BANNER_MANAGEMENT_URL = "/businessBanner/add";
    public static final String ADD_TOP_BANNER = "addTopBanner";
    public static final String ORDER = "Order";
    public static final String ADD_APP_TIPS_URL = "/apptips/add";
    public static final String EDIT_APP_TIPS_URL = "/apptips/edit";
    public static final String ADD_APP_TIPS = "addApptips";
    public static final String EDIT_APP_TIPS = "editApptips";

    private HomeConstant() {
        // content constant
    }
}
