package com.woqod.home.viewmodel.adsbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.adsbanner.AdsBannerService;
import com.woqod.home.viewmodel.common.CommonTopBannerViewModel;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.FileUploadResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static wq.woqod.resources.enumerations.FileSubjectEnum.ADS_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class AddAdsViewModel extends CommonTopBannerViewModel {
    /*
    Beans
     */
    private final DataFactory dataFactory;
    private final FileRestClient restClient;
    private final AdsBannerService adsBannerService;
    /*
    state
    */
    private FileUploadResource adsResource;
    private String selectedAppRedirection;
    private List<String> appRedirections;
    private List<FileTypeEnum> fileTypeEnum;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private FileUploadResource fileUploadResource;
    private String redirectionPath = "Redirection Path";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        fileTypeEnum = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(adsBannerService.getAppRedirectionList().stream().map(AppRedirectionRessource::getName)
                .collect(Collectors.toList()));
        this.adsResource = FileUploadResource.builder().subject(ADS_BANNER).isNewFile(Boolean.FALSE)
                .isNewVideo(Boolean.FALSE).isNewVideoThumbnail(Boolean.FALSE).build();
    }

    /**
     * Method called when save Ads banner is called
     */
    public void save() {
        // Validate the picture
        if (adsResource.getFileTypeEnum() == FileTypeEnum.IMG && !isValidPicture()) {
            BoUtils.showErrorPopup(error, "Please upload a picture");
            return;
        }

        // Validate the videos
        if (adsResource.getFileTypeEnum() == FileTypeEnum.VIDEO && !isValidVideos()) {
                BoUtils.showErrorPopup(error, "Please upload the required videos");
                return;
        }

        this.validateRedirectionForm();
            // Validate APP if filled
        if (BooleanUtils.isTrue(adsResource.getRedirection()) && adsResource.getRedirectionTypeEnum() == RedirectionTypeEnum.APP) {

            if (StringUtils.isBlank(selectedAppRedirection)) {
                BoUtils.showErrorPopup("App Redirection", "App Redirection must not be empty");
                return;
            } else {
                adsResource.setAppRedirection(selectedAppRedirection);
            }

        }
        // end of validation step

        if (adsResource.getFileTypeEnum() == FileTypeEnum.IMG) {
            adsResource.setFile(encodedString);
            adsResource.setExtension(DEFAULT_PICTURE_EXTENSION);
            adsResource.setIsNewFile(isNewFile);
        } else {
            adsResource.setFile(encodedVideo);
            adsResource.setVideoThumbnail(encodedThambnail);
            adsResource.setExtension(DEFAULT_VIDEO_EXTENSION);
            adsResource.setIsNewVideo(isNewVideo);
            adsResource.setIsNewVideoThumbnail(isNewVideoThambnail);
        }

        try {
            restClient.addItem(adsResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("adsBanner");
        } catch (RestBackendException e) {
            log.error("An error has occured when calling the Backend API");
            BoUtils.showErrorPopup(error, errorMessage);
        }

    }

    private void validateRedirectionForm(){
        if (BooleanUtils.isTrue(adsResource.getRedirection()) && adsResource.getRedirectionTypeEnum() == RedirectionTypeEnum.URL) {

            if (StringUtils.isBlank(adsResource.getRedirectionPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Redirection English Path must not be empty ");
                return;
            }

            if (!CommonViewModel.isValidUrl(adsResource.getRedirectionPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection English Path");
                return;
            }
            if (!CommonViewModel.isValidUrl(adsResource.getRedirectionPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection English Path");
                return;
            }

            if (StringUtils.isBlank(adsResource.getRedirectionArPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Redirection Arabic Path must not be empty ");
                return;
            }

            if (!CommonViewModel.isValidUrl(adsResource.getRedirectionArPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection Arbaic Path");
                return;
            }
            if (!CommonViewModel.isValidUrl(adsResource.getRedirectionArPath())) {
                BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection Arbaic Path");
            }
        }
    }

    public void clear() {
        init();
    }

}
