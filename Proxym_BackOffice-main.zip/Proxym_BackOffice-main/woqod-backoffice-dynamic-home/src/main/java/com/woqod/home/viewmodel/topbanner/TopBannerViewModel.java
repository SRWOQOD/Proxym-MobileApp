package com.woqod.home.viewmodel.topbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.models.HomeBoModel;
import com.woqod.home.service.topbanner.TopBannerService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.event.ReorderEvent;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.TopBannerResource;

import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class TopBannerViewModel {

    private static final String SERVICE_NAME = "TOP_BANNER";
    static final String EDIT_TOP_BANNER = "EDIT_TOP_BANNER";
    private final DataFactory dataFactory;
    private final TopBannerService topBannerService;
    private TopBannerResource topBannerResource;
    private TopBannerResource topBanner;
    private List<TopBannerResource> topBannerResources;
    private HomeBoModel homeBoModel;
    Map<String, String> uriParams;
    private Integer topBannersNumber;
    private boolean isDraggable;

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        topBannerResource = new TopBannerResource();
        uriParams = new HashMap<>();
        isDraggable = true;
        topBannerResources = topBannerService.findAll();
        topBannersNumber = topBannerResources.size();
        homeBoModel = new HomeBoModel();
        search();
    }


    public String editUrl(long id) {
        return HomeConstant.EDIT_TOP_URL.concat(String.valueOf(id));
    }

    public String getEditTopFeature() {
        return EDIT_TOP_BANNER;
    }

    public void clear() {
        uriParams = new HashMap<>();
        homeBoModel = new HomeBoModel();
        search();
    }

    public void search() {
        isDraggable = false;
        uriParams.put("dateFrom", DateFormatter.DateToString(homeBoModel.getDateFrom()));
        uriParams.put("dateTo", DateFormatter.DateToString(homeBoModel.getDateTo()));
        uriParams.put("active", homeBoModel.getActive());
        uriParams.put("title", homeBoModel.getTitle());
        topBannerResources = topBannerService.getPaginatedList(uriParams);
        topBannersNumber = topBannerResources.size();
    }

    public boolean isImage() {
        boolean response = false;
        if (topBanner != null && topBanner.getFileTypeEnum() !=null && topBanner.getFileTypeEnum().name().equals("IMG")) {
                    response = true;
        }
        return response;
    }

    public void delete(String id) {
        topBannerService.delete(id);
        topBannersNumber = topBannerService.count();
        BoUtils.showsuccesspopup();
        dataFactory.redirect("topBanner");
    }

    public void onRowReorder(ReorderEvent event) {
        if (event != null) {
            int fromIndex = event.getFromIndex();
            int toIndex = event.getToIndex();
            List<TopBannerResource> listToUpdate = new ArrayList<>();
            if (toIndex >= fromIndex) {
                for (int i = fromIndex; i <= toIndex; i++) {
                    topBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(topBannerResources.get(i));
                }
            } else {
                for (int i = toIndex; i <= fromIndex; i++) {
                    topBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(topBannerResources.get(i));
                }
            }
            topBannerService.update(listToUpdate);
            init();
        }

    }
}
