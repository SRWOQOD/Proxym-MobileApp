package com.woqod.home.viewmodel.adsbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.models.HomeBoModel;
import com.woqod.home.service.adsbanner.AdsBannerService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.event.ReorderEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.AdsBannerResource;

import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class AdsBannerViewModel {

    private static final String SERVICE_NAME = "ADS_BANNER";
    static final String EDIT_BANNER = "EDIT_BANNER";
    private final DataFactory dataFactory;
    private final AdsBannerService adsBannerService;
    private AdsBannerResource adsBannerResource;
    private AdsBannerResource adsBanner;
    private List<AdsBannerResource> adsBannerResources;
    private HomeBoModel homeBoModel;
    Map<String, String> uriParams;
    private Integer numberOfAdsBannerItems;
    private boolean isDraggable;
    @Autowired
    public AdsBannerViewModel(DataFactory dataFactory, AdsBannerService adsBannerService) {
        this.dataFactory = dataFactory;
        this.adsBannerService = adsBannerService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        adsBannerResource = new AdsBannerResource();
        uriParams = new HashMap<>();
        isDraggable = true;
        adsBannerResources = adsBannerService.getAllAds();
        numberOfAdsBannerItems = adsBannerResources.size();
        homeBoModel = new HomeBoModel();
        search();
    }

    public void clear() {
        homeBoModel = new HomeBoModel();
        uriParams = new HashMap<>();
        search();
    }

    public void search() {
        isDraggable = false;
        uriParams.put("dateFrom", DateFormatter.DateToString(homeBoModel.getDateFrom()));
        uriParams.put("dateTo", DateFormatter.DateToString(homeBoModel.getDateTo()));
        uriParams.put("active", homeBoModel.getActive());
        uriParams.put("title", homeBoModel.getTitle());
        adsBannerResources = adsBannerService.filteredAdsBanner(uriParams);
        numberOfAdsBannerItems = adsBannerResources.size();
    }

    public String editUrl(long id) {
        return HomeConstant.EDIT_URL.concat(String.valueOf(id));
    }

    public String getEditAdsFeature() {
        return EDIT_BANNER;
    }

    public void delete(String id) {
        adsBannerService.delete(id);
        numberOfAdsBannerItems = adsBannerService.count();
        dataFactory.redirect("adsBanner");
    }

    public void onRowReorder(ReorderEvent event) {
        if (event != null) {
            int fromIndex = event.getFromIndex();
            int toIndex = event.getToIndex();
            List<AdsBannerResource> listToUpdate = new ArrayList<>();
            if (toIndex >= fromIndex) {
                for (int i = fromIndex; i <= toIndex; i++) {
                    adsBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(adsBannerResources.get(i));
                }
            } else {
                for (int i = toIndex; i <= fromIndex; i++) {
                    adsBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(adsBannerResources.get(i));
                }
            }
            adsBannerService.update(listToUpdate);
            init();
        }
    }

    public boolean isImage() {
        boolean response = false;
        if (adsBanner != null && adsBanner.getFileTypeEnum() !=null && adsBanner.getFileTypeEnum().name().equals("IMG")) {
                    response = true;
        }
        return response;
    }

}
