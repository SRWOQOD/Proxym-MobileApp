package com.woqod.home.service.topbanner;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.home.rest.AppRedirectionRestClient;
import com.woqod.home.rest.TopBannerRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.TopBannerResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class TopBannerServiceImpl implements TopBannerService {
    private final AppRedirectionRestClient appRedirectionRestClient;
    private final TopBannerRestClient topBannerRestClient;

    @Autowired
    public TopBannerServiceImpl(AppRedirectionRestClient appRedirectionRestClient, TopBannerRestClient topBannerRestClient) {
        this.appRedirectionRestClient = appRedirectionRestClient;
        this.topBannerRestClient = topBannerRestClient;
    }

    @Override
    public List<AppRedirectionRessource> getAppRedirectionList() {
        return appRedirectionRestClient.getAppRedirectionList();
    }

    @Override
    public AppRedirectionRessource getByName(String name) {
        return appRedirectionRestClient.getByName(name);
    }

    @Override
    public List<TopBannerResource> getPaginatedList(Map<String, String> uriParams) {
        return topBannerRestClient.paginatedParams(uriParams);
    }

    @Override
    public List<TopBannerResource> findAll() {
        return topBannerRestClient.findAll();
    }

    @Override
    public TopBannerResource getById(String adsId) {
        return topBannerRestClient.getById(adsId);
    }

    @Override
    public void update(List<TopBannerResource> activeTopBanner) {
        topBannerRestClient.update(activeTopBanner);
    }

    @Override
    public void update(TopBannerResource topBannerResource) {
        topBannerRestClient.update(topBannerResource);
    }

    @Override
    public Integer count() {
        return topBannerRestClient.count();
    }

    @Override
    public void delete(String id) {
        topBannerRestClient.delete(id);
    }


}
