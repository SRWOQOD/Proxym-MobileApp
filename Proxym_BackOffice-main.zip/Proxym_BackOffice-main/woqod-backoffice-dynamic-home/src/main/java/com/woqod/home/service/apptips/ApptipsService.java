package com.woqod.home.service.apptips;

import wq.woqod.resources.resources.AppTipsResource;

import java.util.List;
import java.util.Map;

public interface ApptipsService {

    List<AppTipsResource> getAllAds();

    List<AppTipsResource> filterAds(Map<String, String> uriParams);

    AppTipsResource getById(String adsId);

    void update(List<AppTipsResource> activeAd);

    void update(AppTipsResource appTipsResource);

    Integer count();

    void delete(String id);
}
