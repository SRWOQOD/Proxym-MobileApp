package com.woqod.home.viewmodel.common;

import com.woqod.bo.commons.utils.BoUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Base64;

/**
 * @author yosri.zouari
 * @since 29/01/2022
 */
@Getter
@Setter
@Slf4j
public class CommonTopBannerViewModel extends CommonViewModel {

    protected static final String DEFAULT_VIDEO_EXTENSION = "mp4";

    protected String encodedVideo;
    protected String encodedThambnail;
    protected Boolean isNewVideo;
    protected Boolean isNewVideoThambnail;
    protected String videoFileName;

    @Override
    protected boolean validateFileFormat(byte[] image) {

        try {
            BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image));
            if (bufferedImage.getWidth() < 1024 || bufferedImage.getHeight() < 452) {
                BoUtils.showErrorPopup("Validation Error", "height: " + bufferedImage.getHeight() + ", width: " + bufferedImage.getWidth() + " are not a valid dimensions");
                encodedString = "";
                return false;
            }
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return true;
    }

    public void handleVideoUpload(FileUploadEvent fileUploadEvent) {
        UploadedFile videoFile = fileUploadEvent.getFile();
        byte[] videoBytes = videoFile.getContent();
        if (BooleanUtils.isTrue(validateVideoFormat(videoBytes))) {
            encodedVideo = Base64
                    .getEncoder()
                    .encodeToString(videoBytes);
            isNewVideo = Boolean.TRUE;
            videoFileName = fileUploadEvent.getFile().getFileName();
            BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
        }
    }

    public void handleVideoThambnail(FileUploadEvent fileUploadEvent) {
        UploadedFile videoThumbnail = fileUploadEvent.getFile();
        byte[] videoThumbnailBytes = videoThumbnail.getContent();

        if (validateFileFormat(videoThumbnailBytes)) {

            encodedThambnail = Base64
                    .getEncoder()
                    .encodeToString(videoThumbnailBytes);
            isNewVideoThambnail = Boolean.TRUE;
            BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
        }
    }

    protected boolean isValidVideos() {
        return StringUtils.isNotBlank(encodedVideo) && StringUtils.isNotBlank(encodedThambnail);
    }

    protected Boolean validateVideoFormat(byte[] video) {
        return true;
    }
}
