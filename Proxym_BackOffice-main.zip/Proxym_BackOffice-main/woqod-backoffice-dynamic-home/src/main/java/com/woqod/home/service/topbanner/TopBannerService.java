package com.woqod.home.service.topbanner;

import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.TopBannerResource;

import java.util.List;
import java.util.Map;

public interface TopBannerService {
    List<AppRedirectionRessource> getAppRedirectionList();

    AppRedirectionRessource getByName(String name);

    List<TopBannerResource> getPaginatedList(Map<String, String> uriParams);

    List<TopBannerResource> findAll();

    TopBannerResource getById(String topId);

    void update(List<TopBannerResource> activeTop);

    void update(TopBannerResource topUploadResource);

    Integer count();

    void delete(String id);
}
