package com.woqod.home.service.businessbanner;

import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.BusinessBannerResource;

import java.util.List;
import java.util.Map;

public interface BusinessBannerService {
    List<AppRedirectionRessource> getAppRedirectionList();

    AppRedirectionRessource getByName(String name);

    List<BusinessBannerResource> getAllAds();

    List<BusinessBannerResource> filterBusiness(Map<String, String> uriParams);

    BusinessBannerResource getById(String adsId);

    void update(List<BusinessBannerResource> activeAd);

    Integer count();

    void delete(String id);
}
