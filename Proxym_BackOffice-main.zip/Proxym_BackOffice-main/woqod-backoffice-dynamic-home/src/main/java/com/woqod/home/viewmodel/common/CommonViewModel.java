package com.woqod.home.viewmodel.common;

import com.woqod.bo.commons.utils.BoUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Base64;

/**
 * @author yosri.zouari
 * @since 28/01/2022
 */
@Getter
@Setter
@Slf4j
public abstract class CommonViewModel {

    public static final String DEFAULT_PICTURE_EXTENSION = "png";

    protected UploadedFile fileImage;
    protected String encodedString;
    protected Boolean isNewFile;

    /**
     * Method called when upload file is called
     *
     * @param fileUploadEvent
     * @throws IOException
     */
    public void handleFileUpload(FileUploadEvent fileUploadEvent) {
        fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();

        if(validateFileFormat(image)) {

            encodedString = Base64
                    .getEncoder()
                    .encodeToString(fileImage.getContent());

            // flag user in update mode
            isNewFile = Boolean.TRUE;

            BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
        }
    }

    /**
     * Validate URL
     *
     * @param url
     * @return
     */
    public static boolean isValidUrl(String url) {
        try {
            new URL(url).toURI();
            return true;
        } catch (URISyntaxException | MalformedURLException exception) {
            return false;
        }
    }

    protected boolean isValidPicture() {
        return StringUtils.isNotBlank(encodedString);
    }

    protected boolean validateFileFormat(byte[] image) {

        try {
            BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image));
            if (bufferedImage.getWidth() < 1024 || bufferedImage.getHeight() < 452) {
                BoUtils.showErrorPopup("Validation Error", "height: " + bufferedImage.getHeight() + ", width: " + bufferedImage.getWidth() + " are not a valid dimensions");
                return false;
            }
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return true;
    }
}
