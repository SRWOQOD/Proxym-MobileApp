package com.woqod.home.viewmodel.topbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.topbanner.TopBannerService;
import com.woqod.home.viewmodel.common.CommonTopBannerViewModel;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.FileUploadResource;

import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static wq.woqod.resources.enumerations.FileSubjectEnum.TOP_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class AddTpBannerViewModel extends CommonTopBannerViewModel {
    /*
   Beans
    */
    private final DataFactory dataFactory;
    private final FileRestClient restClient;
    private final TopBannerService topBannerService;
    /*
    state
    */
    private FileUploadResource topResource;
    private String selectedAppRedirection;
    private List<FileTypeEnum> fileTypeEnum;
    private List<String> appRedirections;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private String redirectionPath = "Redirection Path";
    private String redirectionArPath = "Redirection Arabic Path";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        fileTypeEnum = new ArrayList<>();
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(topBannerService.getAppRedirectionList().stream().map(AppRedirectionRessource::getName).collect(Collectors.toList()));
        this.topResource = FileUploadResource.builder().subject(TOP_BANNER).isNewFile(Boolean.FALSE)
                .isNewVideo(Boolean.FALSE).isNewVideoThumbnail(Boolean.FALSE).build();

    }

    public void save() {

        // Validate the picture
        if (topResource.getFileTypeEnum() == FileTypeEnum.IMG && !isValidPicture()) {
            BoUtils.showErrorPopup(error, "Please upload a picture");
            return;
        }

        // Validate the videos
        if (topResource.getFileTypeEnum() == FileTypeEnum.VIDEO && !isValidVideos()) {
            BoUtils.showErrorPopup(error, "Please upload the required videos");
            return;
        }

        // Validate URL if filled

        if (BooleanUtils.isTrue(topResource.getRedirection()) && topResource.getRedirectionTypeEnum() == RedirectionTypeEnum.URL && !CommonViewModel.isValidUrl(topResource.getRedirectionPath())) {
            BoUtils.showErrorPopup(redirectionPath, "Please verify your Redirection English Path");
            return;
        }

        if (BooleanUtils.isTrue(topResource.getRedirection()) && topResource.getRedirectionTypeEnum() == RedirectionTypeEnum.URL && !CommonViewModel.isValidUrl(topResource.getRedirectionArPath())) {
            BoUtils.showErrorPopup(redirectionArPath, "Please verify your Redirection Arabic Path");
            return;
        }

        if (BooleanUtils.isTrue(topResource.getRedirection()) && topResource.getRedirectionTypeEnum() == RedirectionTypeEnum.APP) {
                topResource.setAppRedirection(selectedAppRedirection);
        }

        if (topResource.getFileTypeEnum() == FileTypeEnum.IMG) {
            topResource.setFile(encodedString);
            topResource.setExtension(DEFAULT_PICTURE_EXTENSION);
            topResource.setIsNewFile(isNewFile);
        } else {
            topResource.setFile(encodedVideo);
            topResource.setVideoThumbnail(encodedThambnail);
            topResource.setExtension(DEFAULT_VIDEO_EXTENSION);
            topResource.setIsNewVideo(isNewVideo);
            topResource.setIsNewVideoThumbnail(isNewVideoThambnail);
        }

        try {
            restClient.addItem(topResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("topBanner");
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup(error, errorMessage);
        }
    }


    public void clear() {
        init();
    }

}
