package com.woqod.home.service.apptips;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.home.rest.ApptipsRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AppTipsResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ApptipsServiceImpl implements ApptipsService {

    private final ApptipsRestClient apptipsRestClient;

    @Autowired
    public ApptipsServiceImpl(ApptipsRestClient apptipsRestClient) {
        this.apptipsRestClient = apptipsRestClient;
    }

    @Override
    public List<AppTipsResource> getAllAds() {
        return apptipsRestClient.getAdsbanner();
    }

    @Override
    public List<AppTipsResource> filterAds(Map<String, String> uriParams) {
        return apptipsRestClient.filterAds(uriParams);
    }

    @Override
    public AppTipsResource getById(String adsId) {
        return apptipsRestClient.getById(adsId);
    }

    @Override
    public void update(List<AppTipsResource> activeAd) {
        apptipsRestClient.update(activeAd);
    }

    @Override
    public void update(AppTipsResource appTipsResource) {
        apptipsRestClient.update(appTipsResource);
    }

    @Override
    public Integer count() {
        return apptipsRestClient.count();
    }
    @Override
    public void delete(String id) {
         apptipsRestClient.delete(id);
    }

}
