package com.woqod.home.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.home.constatnt.HomeConstant;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Data
@Slf4j
@Controller
@RequestMapping(value = HomeConstant.APP_TIPS_MANAGEMENT_URL)
public class AppTipsController {
    private final Permissions permissions;

    @Autowired
    public AppTipsController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView("APP_TIPS", HomeConstant.TIPS_LIST);
    }

    /**
     * used to display update AppTips view
     *
     * @return
     */
    @GetMapping("/edit")
    public ModelAndView updateDisplay() {
        return permissions.getModelAndView("EDIT_APP_TIPS", HomeConstant.EDIT_APP_TIPS);
    }

    /**
     * used to display add AppTips view
     *
     * @return
     */
    @GetMapping("/add")
    public ModelAndView updateAdd() {
        return permissions.getModelAndView("ADD_BANNER", HomeConstant.ADD_APP_TIPS);
    }

}
