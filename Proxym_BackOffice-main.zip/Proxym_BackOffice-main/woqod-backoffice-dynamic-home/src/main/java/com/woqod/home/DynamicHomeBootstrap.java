package com.woqod.home;

import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.home.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;


@Component
public class DynamicHomeBootstrap {
    private static final String DYNAMIC_HOME_MANAGEMENT = "dynamic_home_Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(DYNAMIC_HOME_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }

}
