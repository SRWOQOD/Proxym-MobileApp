package com.woqod.home.viewmodel.apptips;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.models.HomeBoModel;
import com.woqod.home.service.apptips.ApptipsService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.event.ReorderEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.AppTipsResource;

import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class AppTipsViewModel {
    private static final String SERVICE_NAME = "APP_TIPS";
    static final  String EDIT_APP_TIPS = "EDIT_APP_TIPS";
    private final DataFactory dataFactory;
    private final ApptipsService apptipsService;
    private AppTipsResource resource;
    private AppTipsResource appTipsResource;
    private List<AppTipsResource> appTipsResources;
    private HomeBoModel homeBoModel;
    Map<String, String> uriParams;
    private Integer numberOfAppTipsItems;
    private boolean isDraggable;

    @Autowired
    public AppTipsViewModel(DataFactory dataFactory, ApptipsService apptipsService) {
        this.dataFactory = dataFactory;
        this.apptipsService = apptipsService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        resource = new AppTipsResource();
        uriParams = new HashMap<>();
        isDraggable = true;
        appTipsResources = apptipsService.filterAds(uriParams);
        numberOfAppTipsItems = appTipsResources.size();
        homeBoModel = new HomeBoModel();
        search();
    }

    public void clear() {
        homeBoModel = new HomeBoModel();
        uriParams = new HashMap<>();
        search();
    }


    public void search() {
        uriParams.put("dateFrom", DateFormatter.DateToString(homeBoModel.getDateFrom()));
        uriParams.put("dateTo", DateFormatter.DateToString(homeBoModel.getDateTo()));
        uriParams.put("active", homeBoModel.getActive());
        uriParams.put("title", homeBoModel.getTitle());
        appTipsResources = apptipsService.filterAds(uriParams);
        numberOfAppTipsItems = appTipsResources.size();
    }

    public String editUrl(long id) {
        return HomeConstant.EDIT_TIPS_URL.concat(String.valueOf(id));
    }

    public String getEditAdsFeature() {
        return EDIT_APP_TIPS;
    }

    public void delete(String id){
        apptipsService.delete(id);
        numberOfAppTipsItems = apptipsService.count();
        BoUtils.showsuccesspopup();
        dataFactory.redirect("apptips");
    }

    public void onRowReorder(ReorderEvent event) {
        if (event != null) {
            int fromIndex = event.getFromIndex();
            int toIndex = event.getToIndex();
            List<AppTipsResource> listToUpdate = new ArrayList<>();
            if (toIndex >= fromIndex) {
                for (int i = fromIndex; i <= toIndex; i++) {
                    appTipsResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(appTipsResources.get(i));
                }
            } else {
                for (int i = toIndex; i <= fromIndex; i++) {
                    appTipsResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(appTipsResources.get(i));
                }
            }
            apptipsService.update(listToUpdate);
            init();
        }
    }

}
