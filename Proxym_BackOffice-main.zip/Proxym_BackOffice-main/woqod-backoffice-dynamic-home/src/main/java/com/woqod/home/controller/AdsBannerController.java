package com.woqod.home.controller;

import com.woqod.bo.commons.security.Permissions;
 import com.woqod.home.constatnt.HomeConstant;
 import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Data
@Slf4j
@Controller
@RequestMapping(value = HomeConstant.ADS_BANNER_MANAGEMENT_URL)
public class AdsBannerController {
    private final Permissions permissions;

    @Autowired
    public AdsBannerController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView("ADS_BANNER", HomeConstant.ADS_LIST);
    }

    /**
     * used to display update Ads Banner view
     *
     * @return
     */
    @GetMapping("/edit")
    public ModelAndView updateDisplay() {
        return permissions.getModelAndView("EDIT_BANNER", HomeConstant.EDIT_ADS);
    }

    /**
     * used to display add Ads Banner view
     *
     * @return
     */
    @GetMapping("/add")
    public ModelAndView updateAdd() {
        return permissions.getModelAndView("ADD_BANNER", HomeConstant.ADD_ADS);
    }

}
