package com.woqod.home.service.adsbanner;

import wq.woqod.resources.resources.AdsBannerResource;
import wq.woqod.resources.resources.AppRedirectionRessource;

import java.util.List;
import java.util.Map;

public interface AdsBannerService {

    List<AdsBannerResource> getAllAds();

    List<AppRedirectionRessource> getAppRedirectionList();

    List<AdsBannerResource> filteredAdsBanner(Map<String, String> uriParams);

    AppRedirectionRessource getByName(String name);

    AdsBannerResource getById(String adsId);

    void update(List<AdsBannerResource> activeAd);

    void update(AdsBannerResource adsBannerResource);

    Integer count();

    void delete(String id);
}
