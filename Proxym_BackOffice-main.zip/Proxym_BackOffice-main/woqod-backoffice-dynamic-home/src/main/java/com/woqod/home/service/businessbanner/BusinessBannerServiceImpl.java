package com.woqod.home.service.businessbanner;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.home.rest.AppRedirectionRestClient;
import com.woqod.home.rest.BusinessBannerRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.BusinessBannerResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BusinessBannerServiceImpl implements BusinessBannerService {

    private final BusinessBannerRestClient bannerRestClient;
    private final AppRedirectionRestClient appRedirectionRestClient;

    @Autowired
    public BusinessBannerServiceImpl(BusinessBannerRestClient bannerRestClient, AppRedirectionRestClient appRedirectionRestClient) {
        this.bannerRestClient = bannerRestClient;
        this.appRedirectionRestClient = appRedirectionRestClient;
    }

    @Override
    public AppRedirectionRessource getByName(String name) {
        return appRedirectionRestClient.getByName(name);
    }

    @Override
    public List<AppRedirectionRessource> getAppRedirectionList() {
        return appRedirectionRestClient.getAppRedirectionList();
    }

    @Override
    public List<BusinessBannerResource> getAllAds() {
        return bannerRestClient.getAdsbanner();
    }

    @Override
    public List<BusinessBannerResource> filterBusiness(Map<String, String> uriParams) {
        return bannerRestClient.filterBusiness(uriParams);
    }

    @Override
    public BusinessBannerResource getById(String adsId) {
        return bannerRestClient.getById(adsId);
    }

    @Override
    public void update(List<BusinessBannerResource> activeAd) {
        bannerRestClient.update(activeAd);
    }

    @Override
    public Integer count() {
        return bannerRestClient.count();
    }
    @Override
    public void delete(String id) {
        bannerRestClient.delete(id);
    }


}
