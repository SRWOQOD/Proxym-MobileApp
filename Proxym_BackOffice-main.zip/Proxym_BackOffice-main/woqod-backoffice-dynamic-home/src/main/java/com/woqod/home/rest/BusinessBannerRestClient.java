package com.woqod.home.rest;

import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.BusinessBannerResource;
import wq.woqod.resources.resources.UpdateBusinessResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/business.properties")
public class BusinessBannerRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
    external config attributes
     */
    private String adsbanner;
    private String count;

    @Autowired
    public BusinessBannerRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.business}") String adsbanner, @Value("${uri.ws.business.count}") String count) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.adsbanner = adsbanner;
        this.count = count;
    }

    public List<BusinessBannerResource> getAdsbanner() {
        String uri = adsbanner;
        return BannersRestClient.getBannerList(customRestTemplate, baseUrlProvider, uri);

    }


    /**
     * used to get parameters paginated and filtred
     *
     * @return
     * @throws RestBackendException
     */
    public List<BusinessBannerResource> filterBusiness(Map<String, String> uriParams) {
        String uri = adsbanner.concat("/filtered");
        return BannersRestClient.getBannerPaginatedList(customRestTemplate, baseUrlProvider, uri, uriParams);
    }

    public BusinessBannerResource getById(String adsId) {
        String uri = adsbanner.concat("/").concat(adsId);
        ObjectResponse<BusinessBannerResource> response = (ObjectResponse<BusinessBannerResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<BusinessBannerResource>>>() {
                        });
        return response.getObject();
    }

    public Boolean update(List<BusinessBannerResource> activeAd) {
        UpdateBusinessResource updateBusinessResource = new UpdateBusinessResource();
        updateBusinessResource.setList(activeAd);
        String uri = adsbanner + "/all";
        BooleanResponse response = BannersRestClient.update(customRestTemplate, baseUrlProvider, uri, updateBusinessResource);
        return response.isSuccess();
    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = BannersRestClient.count(customRestTemplate, baseUrlProvider, uri);
        return response.getObject();
    }
    public Boolean delete(String id) {
        String uri = adsbanner + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

}
