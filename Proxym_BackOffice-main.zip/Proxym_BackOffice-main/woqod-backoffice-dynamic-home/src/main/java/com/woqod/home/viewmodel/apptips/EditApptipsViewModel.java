package com.woqod.home.viewmodel.apptips;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.apptips.ApptipsService;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.resources.AppTipsResource;
import wq.woqod.resources.resources.FileUploadResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static wq.woqod.resources.enumerations.FileSubjectEnum.APP_TIPS;

@Data
@Slf4j
@Component
@Scope("view")
public class EditApptipsViewModel extends CommonViewModel {
    /*
    Beans
     */
    private final ApptipsService apptipsService;
    private final DataFactory dataFactory;
    private final FileRestClient restClient;

    /*
   state
    */
    private String adsId;
    private AppTipsResource adsResource;
    private List<AppTipsResource> activeAd;
    private Map<String, String> uriParams;
    private FileUploadResource fileUploadResource;

    @Autowired
    public EditApptipsViewModel(ApptipsService apptipsService, DataFactory dataFactory, FileRestClient restClient) {
        this.apptipsService = apptipsService;
        this.dataFactory = dataFactory;
        this.restClient = restClient;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            adsId = request.getParameter(HomeConstant.ADS_ID);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        //copy object vales's in other object
        uriParams = new HashMap<>();
        uriParams.put("active", "true");
        activeAd = apptipsService.filterAds(uriParams);
        adsResource = apptipsService.getById(adsId);
        this.fileUploadResource = FileUploadResource.builder().subject(APP_TIPS).isNewFile(Boolean.FALSE)
                .fileTypeEnum(FileTypeEnum.IMG).extension(DEFAULT_PICTURE_EXTENSION).build();
        mapAppTipResourceToFileResource();
        encodedString = fileUploadResource.getFile();
    }

    private void mapAppTipResourceToFileResource() {
        this.fileUploadResource.setId(adsResource.getId());
        this.fileUploadResource.setFile(adsResource.getFileUrl());
        this.fileUploadResource.setTitle(adsResource.getTitle());
        this.fileUploadResource.setTitleArabic(adsResource.getTitleArabic());
        this.fileUploadResource.setActive(adsResource.getActive());
        this.fileUploadResource.setCreationDate(adsResource.getCreationDate());
    }

    public void clear() {
        init();
    }

    public void update() {

        // Validate the picture
        if (BooleanUtils.isTrue(isNewFile) && !isValidPicture() ) {
                BoUtils.showErrorPopup("Error", "Please upload a picture");
                return;
        }

        if (BooleanUtils.isTrue(isNewFile)) {
            fileUploadResource.setFile(encodedString);
            fileUploadResource.setIsNewFile(Boolean.TRUE);
        }
        fileUploadResource.setFileUrl(adsResource.getFileUrl());
        try {
            restClient.addItem(fileUploadResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("apptips");
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup("Error ", "An error has occurred , Please try later");
        }

    }

    @Override
    protected boolean validateFileFormat(byte[] image) {

        try {
            BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image));
            if (bufferedImage.getHeight() < 700 || bufferedImage.getWidth() < 390) {
                BoUtils.showErrorPopup("Validation Error", "height: " + bufferedImage.getHeight() + ", width: " + bufferedImage.getWidth() + " are not a valid dimensions");
                return false;
            }
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return true;
    }
}
