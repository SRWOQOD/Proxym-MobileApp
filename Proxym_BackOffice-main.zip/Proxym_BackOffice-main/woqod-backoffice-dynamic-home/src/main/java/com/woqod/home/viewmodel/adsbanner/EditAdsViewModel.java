package com.woqod.home.viewmodel.adsbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.adsbanner.AdsBannerService;
import com.woqod.home.viewmodel.common.CommonTopBannerViewModel;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.model.file.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.AppRedirection;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.AdsBannerResource;
import wq.woqod.resources.resources.FileUploadResource;
import wq.woqod.resources.resources.TopBannerResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

import static wq.woqod.resources.enumerations.FileSubjectEnum.ADS_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class EditAdsViewModel extends CommonTopBannerViewModel {
    /*
    Beans
     */
    private final AdsBannerService adsBannerService;
    private final DataFactory dataFactory;
    private final FileRestClient restClient;

    /*
   state
    */
    private String adsId;
    private AdsBannerResource adsResource;
    private AdsBannerResource oldAdsResource;
    private List<AdsBannerResource> activeAd;
    private List<FileTypeEnum> fileTypeEnum;
    private List<AppRedirection> appRedirections;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private Map<String, String> uriParams;
    private FileUploadResource adsUploadResource;
    private UploadedFile fileImageVar;
    private List<String> oerderList;
    private String selectedAppRedirection;

    @Autowired
    public EditAdsViewModel(AdsBannerService adsBannerService, DataFactory dataFactory, FileRestClient restClient) {
        this.adsBannerService = adsBannerService;
        this.dataFactory = dataFactory;
        this.restClient = restClient;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            adsId = request.getParameter(HomeConstant.ADS_ID);
            oldAdsResource = adsBannerService.getById(adsId);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        //copy object vales's in other object
        uriParams = new HashMap<>();
        uriParams.put("active", "true");
        fileTypeEnum = new ArrayList<>();
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(Arrays.asList(AppRedirection.values()));
        activeAd = adsBannerService.filteredAdsBanner(uriParams);
        adsResource = adsBannerService.getById(adsId);
        this.adsUploadResource = FileUploadResource.builder().subject(ADS_BANNER).build();
        mapAdsResourceToFileResource();
        encodedString = adsUploadResource.getFile();
        encodedThambnail = adsUploadResource.getVideoThumbnail();
    }

    private void mapAdsResourceToFileResource() {
        this.adsUploadResource.setId(adsResource.getId());
        this.adsUploadResource.setFile(adsResource.getFileUrl());
        this.adsUploadResource.setActive(adsResource.getActive());
        this.adsUploadResource.setTitle(adsResource.getTitle());
        this.adsUploadResource.setFile(adsResource.getFileUrl());
        this.adsUploadResource.setTitleArabic(adsResource.getTitleArabic());
        this.adsUploadResource.setVideoThumbnail(adsResource.getVideoThumbnail());
        this.adsUploadResource.setFileTypeEnum(adsResource.getFileTypeEnum());
        this.adsUploadResource.setVideoTitleEn(adsResource.getVideoTitleEn());
        this.adsUploadResource.setVideoTitleAr(adsResource.getVideoTitleAr());
        this.adsUploadResource.setRedirectionPath(adsResource.getRedirectionPath());
        this.adsUploadResource.setRedirectionArPath(adsResource.getRedirectionArPath());
        this.adsUploadResource.setAppRedirection(adsResource.getAppRedirection());
        this.adsUploadResource.setRedirection(adsResource.getRedirection());
        this.adsUploadResource.setRedirectionTypeEnum(adsResource.getRedirectionTypeEnum());
        this.adsUploadResource.setCreationDate(adsResource.getCreationDate());
        this.adsUploadResource.setTitleDisplayed(adsResource.getTitleDisplayed());
    }

    public void clear() {
        init();
    }

    public void update() {
        if (adsUploadResource.getFileTypeEnum() == FileTypeEnum.IMG) {
            adsUploadResource.setFile(encodedString);
            adsUploadResource.setExtension(DEFAULT_PICTURE_EXTENSION);
            adsUploadResource.setIsNewFile(isNewFile);
        } else {
            adsUploadResource.setFile(encodedVideo);
            adsUploadResource.setVideoThumbnail(encodedThambnail);
            adsUploadResource.setExtension(DEFAULT_VIDEO_EXTENSION);
            adsUploadResource.setIsNewVideo(isNewVideo);
            adsUploadResource.setIsNewVideoThumbnail(isNewVideoThambnail);
        }

        if(isNewFile == null || !isNewFile) {
            adsUploadResource.setFileUrl(adsResource.getFileUrl());
        }


        try {
            restClient.addItem(adsUploadResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("adsBanner");
        } catch (RestBackendException e) {
            log.error("An error has occured when calling the Backend API");
            BoUtils.showErrorPopup("Error ", "An error has occurred , Please try later");
        }
    }

    public boolean isImage() {
        boolean response = false;
        if (!Objects.isNull(adsResource) && !Objects.isNull(adsResource.getFileTypeEnum()) && adsResource.getFileTypeEnum().name().equals("IMG")) {
                    response = true;
        }
        return response;
    }
}
