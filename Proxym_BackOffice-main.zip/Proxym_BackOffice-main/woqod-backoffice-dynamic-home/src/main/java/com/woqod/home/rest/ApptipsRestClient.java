package com.woqod.home.rest;

import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AppTipsResource;
import wq.woqod.resources.resources.UpdateAppTipsResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/apptips.properties")
public class ApptipsRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
    external config attributes
     */
    private String adsbanner;
    private String count;

    @Autowired
    public ApptipsRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.apptips}") String adsbanner, @Value("${uri.ws.apptips.count}") String count) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.adsbanner = adsbanner;
        this.count = count;
    }

    public List<AppTipsResource> getAdsbanner() {
        String uri = adsbanner;
        return BannersRestClient.getBannerList(customRestTemplate, baseUrlProvider, uri);

    }


    /**
     * used to get parameters paginated and filtred
     *
     * @return
     * @throws RestBackendException
     */
    public List<AppTipsResource> filterAds(Map<String, String> uriParams) {
        String uri = adsbanner.concat("/filtered");
        return BannersRestClient.getBannerPaginatedList(customRestTemplate, baseUrlProvider, uri, uriParams);
    }

    public AppTipsResource getById(String adsId) {
        String uri = adsbanner.concat("/").concat(adsId);
        ObjectResponse<AppTipsResource> response = (ObjectResponse<AppTipsResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<AppTipsResource>>>() {
                        });
        return response.getObject();
    }

    public Boolean update(List<AppTipsResource> activeAd) {
        UpdateAppTipsResource updateAppTipsResource = new UpdateAppTipsResource();
        updateAppTipsResource.setList(activeAd);
        String uri = adsbanner + "/all";
        BooleanResponse response = BannersRestClient.update(customRestTemplate, baseUrlProvider, uri, updateAppTipsResource);
        return response.isSuccess();
    }

    public Boolean update(AppTipsResource appTipsResource) {
        String uri = adsbanner + "/update";
        BooleanResponse response = BannersRestClient.update(customRestTemplate, baseUrlProvider, uri, appTipsResource);
        return response.isSuccess();
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = BannersRestClient.count(customRestTemplate, baseUrlProvider, uri);
        return response.getObject();
    }

    public Boolean delete(String id) {
        String uri = adsbanner + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }
}
