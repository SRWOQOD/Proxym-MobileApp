package com.woqod.home.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;
import java.util.Map;

public class BannersRestClient {

    private BannersRestClient() {

    }

    public static <T> List<T> getBannerList(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, String uri) {
        return ((ListResponse<T>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<T>>>() {
                        })).getList();
    }


    public  static <T>List<T> getBannerPaginatedList(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, String uri, Map<String, String> uriParams) {
        return ((ListResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<T>>>() {
                        })).getList();
    }

    public static BooleanResponse update(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, String uri, Object obj) {
        return  (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), obj,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
    }

    public static ObjectResponse<Integer> count(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, String uri) {
        return (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
    }

}
