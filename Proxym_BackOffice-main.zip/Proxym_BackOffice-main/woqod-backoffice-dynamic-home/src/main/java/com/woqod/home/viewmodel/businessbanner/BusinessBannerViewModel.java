package com.woqod.home.viewmodel.businessbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.models.HomeBoModel;
import com.woqod.home.service.businessbanner.BusinessBannerService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.primefaces.event.ReorderEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.AppTipsResource;
import wq.woqod.resources.resources.BusinessBannerResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class BusinessBannerViewModel {

    private static final String SERVICE_NAME = "BUSINESS_BANNER";

    private final DataFactory dataFactory;
    private final BusinessBannerService businessBannerService;
    private BusinessBannerResource businessBannerResource;
    private BusinessBannerResource businessBanner;
    private List<BusinessBannerResource> businessBannerResources;
    private HomeBoModel homeBoModel;
    Map<String, String> uriParams;
    private Integer numberOfBussinessBannerItems;
    private boolean isDraggable;

    @Autowired
    public BusinessBannerViewModel(DataFactory dataFactory, BusinessBannerService businessBannerService) {
        this.dataFactory = dataFactory;
        this.businessBannerService = businessBannerService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        businessBannerResource = new BusinessBannerResource();
        uriParams = new HashMap<>();
        isDraggable = true;
        businessBannerResources = businessBannerService.filterBusiness(uriParams);
        numberOfBussinessBannerItems = businessBannerResources.size();
        homeBoModel = new HomeBoModel();
        search();
    }

    public void clear() {

        businessBannerResource = new BusinessBannerResource();
        homeBoModel = new HomeBoModel();
        uriParams = new HashMap<>();
        search();
    }

    public void search() {
        uriParams.put("dateFrom", DateFormatter.DateToString(homeBoModel.getDateFrom()));
        uriParams.put("dateTo", DateFormatter.DateToString(homeBoModel.getDateTo()));
        uriParams.put("active", homeBoModel.getActive());
        uriParams.put("title", homeBoModel.getTitle());
        businessBannerResources = businessBannerService.filterBusiness(uriParams);
        numberOfBussinessBannerItems = businessBannerResources.size();
    }

    public String editUrl(long id) {
        return HomeConstant.EDIT_BUSINESS_URL.concat(String.valueOf(id));
    }

    public String getEditAdsFeature() {
        return "EDIT_BUSINESS_BANNER";
    }

    public void delete(String id) {
        businessBannerService.delete(id);
        numberOfBussinessBannerItems = businessBannerService.count();
        BoUtils.showsuccesspopup();
        dataFactory.redirect("businessBanner");
    }

    public void onRowReorder(ReorderEvent event) {
        if (event != null) {
            int fromIndex = event.getFromIndex();
            int toIndex = event.getToIndex();
            List<BusinessBannerResource> listToUpdate = new ArrayList<>();
            if (toIndex >= fromIndex) {
                for (int i = fromIndex; i <= toIndex; i++) {
                    businessBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(businessBannerResources.get(i));
                }
            } else {
                for (int i = toIndex; i <= fromIndex; i++) {
                    businessBannerResources.get(i).setOrderItem(i + 1L);
                    listToUpdate.add(businessBannerResources.get(i));
                }
            }
            businessBannerService.update(listToUpdate);
            init();
        }
    }

    public static String html2text(String html) {
        return Jsoup.parse(html).text();
    }
}
