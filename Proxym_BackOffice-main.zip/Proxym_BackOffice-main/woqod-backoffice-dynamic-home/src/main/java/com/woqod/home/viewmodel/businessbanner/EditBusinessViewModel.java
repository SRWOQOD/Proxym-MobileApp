package com.woqod.home.viewmodel.businessbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.businessbanner.BusinessBannerService;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.BusinessBannerResource;
import wq.woqod.resources.resources.FileUploadResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static wq.woqod.resources.enumerations.FileSubjectEnum.BUSINESS_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class EditBusinessViewModel extends CommonViewModel {
    /*
    Beans
     */
    private final BusinessBannerService bannerService;
    private final DataFactory dataFactory;
    private final FileRestClient restClient;

    /*
   state
    */
    private String adsId;
    private List<String> oerderList;
    private BusinessBannerResource oldAdsResource;
    private BusinessBannerResource adsResource;
    private List<BusinessBannerResource> activeAd;
    private Map<String, String> uriParams;
    private List<FileTypeEnum> fileTypeEnum;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private List<String> appRedirections;
    private String selectedAppRedirection;
    private String encodedImage;
    private String encodedIconChecked;
    private String encodedIconUnChecked;
    private FileUploadResource businessUploadResource;
    private String isUploaded = " is uploaded.";
    private String redirectionPath = "Redirection Path";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";


    @Autowired
    public EditBusinessViewModel(BusinessBannerService bannerService, DataFactory dataFactory, FileRestClient restClient) {
        this.bannerService = bannerService;
        this.dataFactory = dataFactory;
        this.restClient = restClient;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            adsId = request.getParameter(HomeConstant.ADS_ID);
            oldAdsResource = bannerService.getById(adsId);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        fileTypeEnum = new ArrayList<>();
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(bannerService.getAppRedirectionList().stream().map(AppRedirectionRessource::getName).collect(Collectors.toList()));
        //copy object vales's in other object
        uriParams = new HashMap<>();
        activeAd = bannerService.filterBusiness(uriParams);
        adsResource = bannerService.getById(adsId);
        mapBusinessBannerToFileResource();
        encodedImage = businessUploadResource.getFile();
        encodedIconChecked = businessUploadResource.getCheckedIcon();
        encodedIconUnChecked = businessUploadResource.getUnCheckedIcon();
    }

    private void mapBusinessBannerToFileResource() {
        this.businessUploadResource = FileUploadResource.builder().subject(BUSINESS_BANNER).build();
        this.businessUploadResource.setId(adsResource.getId());
        this.businessUploadResource.setCheckedIcon(adsResource.getCheckedIconUrl());
        this.businessUploadResource.setUnCheckedIcon(adsResource.getUncheckedIconUrl());
        this.businessUploadResource.setFile(adsResource.getImageUrl());
        this.businessUploadResource.setActive(adsResource.getActive());
        this.businessUploadResource.setFileTypeEnum(adsResource.getFileTypeEnum());
        this.businessUploadResource.setAppRedirection(adsResource.getAppRedirection());
        this.businessUploadResource.setRedirection(adsResource.getRedirection());
        this.businessUploadResource.setRedirectionTypeEnum(adsResource.getRedirectionTypeEnum());
        this.businessUploadResource.setRedirectionPath(adsResource.getRedirectionPath());
        this.businessUploadResource.setRedirectionArPath(adsResource.getRedirectionArPath());
        this.businessUploadResource.setTitle(adsResource.getTitle());
        this.businessUploadResource.setIconTitle(adsResource.getIconTitle());
        this.businessUploadResource.setIconTitleArabic(adsResource.getIconTitleArabic());
        this.businessUploadResource.setDetails(adsResource.getDescription());
        this.businessUploadResource.setDetailsArabic(adsResource.getDescriptionArabic());
        this.businessUploadResource.setCreationDate(adsResource.getCreationDate());
        this.businessUploadResource.setTitleArabic(adsResource.getTitleArabic());
    }

    public void clear() {
        init();
    }


    public void update() {
        if (businessUploadResource.getRedirection() != null && businessUploadResource.getRedirection()
                && businessUploadResource.getRedirectionTypeEnum() == (RedirectionTypeEnum.URL)
                && !businessUploadResource.getRedirectionPath().startsWith("https")
                && !businessUploadResource.getRedirectionPath().startsWith("http"))
        {
                    BoUtils.showErrorPopup("Redirection Path", "Please verify your Redirection Path");
                    return;
        }

        if (businessUploadResource.getRedirectionTypeEnum() != null && businessUploadResource.getRedirectionTypeEnum() == RedirectionTypeEnum.URL
                && businessUploadResource.getRedirection() != null && BooleanUtils.isTrue(businessUploadResource.getRedirection()) && businessUploadResource.getRedirectionPath() == null
                && (businessUploadResource.getRedirectionPath()).isEmpty()) {
            BoUtils.showErrorPopup(redirectionPath, "Redirection Path must not be empty ");
            return;
        }
        if (businessUploadResource.getRedirection() != null && selectedAppRedirection != null) {
            businessUploadResource.setAppRedirection(selectedAppRedirection);
        }
        businessUploadResource.setCheckedIcon(encodedIconChecked);
        businessUploadResource.setUnCheckedIcon(encodedIconUnChecked);
        businessUploadResource.setFile(encodedImage);
        businessUploadResource.setFileUrl(adsResource.getImageUrl());
        businessUploadResource.setExtension("PNG");
        businessUploadResource.setIsNewFile(isNewFile);

        try {
            restClient.addItem(businessUploadResource);
            BoUtils.showsuccesspopup();
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup(error, errorMessage);
        }
        dataFactory.redirect("businessBanner");

    }

    public void handleEncodedImageUpload(FileUploadEvent fileUploadEvent) throws IOException {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = ImageIO.read(new ByteArrayInputStream(image));
        int width = bi.getWidth();
        int height = bi.getHeight();
        if (width < 1024 || height < 452) {
            BoUtils.showErrorPopup("Image ", "Kindly attach an image with 1024 height and 452 width");
        } else {
            encodedImage = Base64
                    .getEncoder()
                    .encodeToString(fileImage.getContent());
            isNewFile = Boolean.TRUE;
            BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + isUploaded);
        }
    }

    public void handleEncodedIconCheckedUpload(FileUploadEvent fileUploadEvent) throws IOException {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = ImageIO.read(new ByteArrayInputStream(image));
        int width = bi.getWidth();
        int height = bi.getHeight();
        if (104 > height && width < 105) {
            BoUtils.showErrorPopup("File", "Kindly attach an image with 104 height and 105 width");
        } else {
            encodedIconChecked = Base64
                    .getEncoder()
                    .encodeToString(fileImage.getContent());
            isNewFile = Boolean.TRUE;
            BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + isUploaded);
        }
    }


    public void handleEncodedIconUnCheckedUpload(FileUploadEvent fileUploadEvent) throws IOException {
        UploadedFile fileImage = fileUploadEvent.getFile();
        byte[] image = fileImage.getContent();
        BufferedImage bi = ImageIO.read(new ByteArrayInputStream(image));
        int width = bi.getWidth();
        int height = bi.getHeight();
        if (104 > height && width < 105) {
            BoUtils.showErrorPopup("File", "Kindly attach an image with 104 height and 105 width");
        } else {
            encodedIconUnChecked = Base64
                    .getEncoder()
                    .encodeToString(fileImage.getContent());
            isNewFile = Boolean.TRUE;
            BoUtils.showInfoPopup("Unselected Icon", fileUploadEvent.getFile().getFileName() + isUploaded);
        }
    }

}
