package com.woqod.home.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AppRedirectionRessource;

import java.util.List;

@Slf4j
@Component
@PropertySource("classpath:properties/appRedirection.properties")
public class AppRedirectionRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
    external config attributes
     */
    private String appRedirection;

    @Autowired
    public AppRedirectionRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.appRedirection}") String appRedirection) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.appRedirection = appRedirection;
    }

    public List<AppRedirectionRessource> getAppRedirectionList() {
        String uri = appRedirection;
        return ((ListResponse<AppRedirectionRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<AppRedirectionRessource>>>() {
                        })).getList();
    }

    public AppRedirectionRessource getByName(String name) {
        String uri = appRedirection.concat("/").concat(name);
        ObjectResponse<AppRedirectionRessource> response = (ObjectResponse<AppRedirectionRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<AppRedirectionRessource>>>() {
                        });
        return response.getObject();
    }
}
