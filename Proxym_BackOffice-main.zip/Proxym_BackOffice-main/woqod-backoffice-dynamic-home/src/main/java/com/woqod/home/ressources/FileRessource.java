package com.woqod.home.ressources;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.primefaces.model.file.UploadedFile;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileRessource {
    private UploadedFile file;
    private UploadedFile unCheckedImage;
    private UploadedFile checkedImage;
    private UploadedFile fileVideo;
    private UploadedFile videoThumbnail;

}
