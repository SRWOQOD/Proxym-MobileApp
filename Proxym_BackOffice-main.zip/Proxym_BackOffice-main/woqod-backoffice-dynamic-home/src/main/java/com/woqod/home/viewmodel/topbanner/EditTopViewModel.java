package com.woqod.home.viewmodel.topbanner;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.service.topbanner.TopBannerService;
import com.woqod.home.viewmodel.common.CommonTopBannerViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.AppRedirection;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;
import wq.woqod.resources.resources.FileUploadResource;
import wq.woqod.resources.resources.TopBannerResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static wq.woqod.resources.enumerations.FileSubjectEnum.TOP_BANNER;

@Data
@Slf4j
@Component
@Scope("view")
public class EditTopViewModel extends CommonTopBannerViewModel {
    /*
    Beans
     */
    private final TopBannerService topBannerService;
    private final DataFactory dataFactory;
    private final FileRestClient restClient;

    /*
   state
    */
    private String topId;
    private List<String> oerderList;
    private TopBannerResource topResource;
    private TopBannerResource oldTopResource;
    private List<TopBannerResource> activeTop;
    private Map<String, String> uriParams;
    private List<FileTypeEnum> fileTypeEnum;
    private List<AppRedirection> appRedirections;
    private List<RedirectionTypeEnum> redirectionTypeEnums;
    private String selectedAppRedirection;
    private FileUploadResource topUploadResource;

    @Autowired
    public EditTopViewModel(TopBannerService topBannerService, DataFactory dataFactory, FileRestClient restClient) {
        this.topBannerService = topBannerService;
        this.dataFactory = dataFactory;
        this.restClient = restClient;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            topId = request.getParameter(HomeConstant.TOP_ID);
            oldTopResource = topBannerService.getById(topId);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        fileTypeEnum = new ArrayList<>();
        appRedirections = new ArrayList<>();
        redirectionTypeEnums = new ArrayList<>();
        fileTypeEnum.addAll(Arrays.asList(FileTypeEnum.values()));
        redirectionTypeEnums.addAll(Arrays.asList(RedirectionTypeEnum.values()));
        appRedirections.addAll(Arrays.asList(AppRedirection.values()));
        //copy object vales's in other object
        uriParams = new HashMap<>();
        uriParams.put("active", "true");
        activeTop = topBannerService.getPaginatedList(uriParams);
        topResource = topBannerService.getById(topId);
        this.topUploadResource = FileUploadResource.builder().subject(TOP_BANNER).build();
        mapTopBannerResourceToFileResource();
        encodedString = topUploadResource.getFile();
        encodedThambnail = topUploadResource.getVideoThumbnail();
    }

    private void mapTopBannerResourceToFileResource() {
        this.topUploadResource.setId(topResource.getId());
        this.topUploadResource.setTitle(topResource.getTitle());
        this.topUploadResource.setTitleArabic(topResource.getTitleArabic());
        this.topUploadResource.setFile(topResource.getFileUrl());
        this.topUploadResource.setActive(topResource.getActive());
        this.topUploadResource.setRedirection(topResource.getRedirection());
        this.topUploadResource.setRedirectionTypeEnum(topResource.getRedirectionTypeEnum());
        this.topUploadResource.setRedirectionPath(topResource.getRedirectionPath());
        this.topUploadResource.setRedirectionArPath(topResource.getRedirectionArPath());
        this.topUploadResource.setVideoThumbnail(topResource.getVideoThumbnail());
        this.topUploadResource.setFileTypeEnum(topResource.getFileTypeEnum());
        this.topUploadResource.setAppRedirection(topResource.getAppRedirection());
        this.topUploadResource.setVideoTitleEn(topResource.getVideoTitleEn());
        this.topUploadResource.setVideoTitleAr(topResource.getVideoTitleAr());
        this.topUploadResource.setCreationDate(topResource.getCreationDate());
        this.topUploadResource.setTitleDisplayed(topResource.getTitleDisplayed());
    }

    public void clear() {
        init();
    }

    public void update() {

        if (topUploadResource.getFileTypeEnum() == FileTypeEnum.IMG) {
            topUploadResource.setFile(encodedString);
            topUploadResource.setExtension(DEFAULT_PICTURE_EXTENSION);
            topUploadResource.setIsNewFile(isNewFile);
        } else {
            topUploadResource.setFile(encodedVideo);
            topUploadResource.setVideoThumbnail(encodedThambnail);
            topUploadResource.setExtension(DEFAULT_VIDEO_EXTENSION);
            topUploadResource.setIsNewVideo(isNewVideo);
            topUploadResource.setIsNewVideoThumbnail(isNewVideoThambnail);
        }
        topUploadResource.setFileUrl(topResource.getFileUrl());

        try {
            restClient.addItem(topUploadResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("topBanner");
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup("Error ", "An error has occurred , Please try later");
        }

    }

    public boolean isImage() {
        boolean response = false;
        if (!Objects.isNull(topResource) && !Objects.isNull(topResource.getFileTypeEnum()) && topResource.getFileTypeEnum().name().equals("IMG")) {
                    response = true;
        }
        return response;
    }

}
