package com.woqod.home.viewmodel.apptips;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.home.rest.FileRestClient;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.resources.FileUploadResource;

import javax.annotation.ManagedBean;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import static wq.woqod.resources.enumerations.FileSubjectEnum.APP_TIPS;

@Data
@Slf4j
@Component
@Scope("view")
@ManagedBean
public class AddApptipsViewModel extends CommonViewModel {

    private final DataFactory dataFactory;
    private FileUploadResource fileUploadResource;
    private final FileRestClient restClient;

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        this.fileUploadResource = FileUploadResource.builder().subject(APP_TIPS).isNewFile(Boolean.FALSE)
                .fileTypeEnum(FileTypeEnum.IMG).extension(DEFAULT_PICTURE_EXTENSION).build();
        encodedString = "";

    }

    public void save() {

        // Validate the picture
        if(!isValidPicture()) {
            BoUtils.showErrorPopup("Error", "Please upload a picture");
            return;
        }

        fileUploadResource.setFile(encodedString);
        fileUploadResource.setIsNewFile(isNewFile);

        try {
            restClient.addItem(fileUploadResource);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("apptips");
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup("Error ", "An error has occurred , Please try later");
        }

    }

    public void clear() {
        init();
    }

    @Override
    protected boolean validateFileFormat(byte[] image) {

        try {
            BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image));
            if (bufferedImage.getHeight() < 700 || bufferedImage.getWidth() < 390) {
                BoUtils.showErrorPopup("Validation Error", "height: " + bufferedImage.getHeight() + ", width: " + bufferedImage.getWidth() + " are not a valid dimensions");
                return false;
            }
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return true;
    }
}
