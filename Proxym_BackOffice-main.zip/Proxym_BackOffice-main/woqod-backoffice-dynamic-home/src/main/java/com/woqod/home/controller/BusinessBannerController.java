package com.woqod.home.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.home.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Data
@Slf4j
@Controller
@RequestMapping(value = HomeConstant.BUSINESS_BANNER_MANAGEMENT_URL)
public class BusinessBannerController {
    private final Permissions permissions;

    @Autowired
    public BusinessBannerController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView("BUSINESS_BANNER", HomeConstant.BUSINESS_LIST);
    }

    /**
     * used to display update Ads Banner view
     *
     * @return
     */
    @GetMapping("/edit")
    public ModelAndView updateDisplay() {
        return permissions.getModelAndView("EDIT_BUSINESS_BANNER", HomeConstant.EDIT_BUSINESS);
    }

    /**
     * used to display add Ads Banner view
     *
     * @return
     */
    @GetMapping("/add")
    public ModelAndView updateAdd() {
        return permissions.getModelAndView("ADD_BUSINESS_BANNER", HomeConstant.ADD_BUSINESS);
    }

}
