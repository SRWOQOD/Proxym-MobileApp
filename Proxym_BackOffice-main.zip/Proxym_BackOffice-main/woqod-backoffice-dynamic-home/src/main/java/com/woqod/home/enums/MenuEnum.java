package com.woqod.home.enums;


import com.woqod.bo.commons.enums.*;
import java.util.Arrays;
import java.util.Optional;


public enum MenuEnum implements Menu {
//    ADS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "adsBanner"),
//            HomeConstant.ADS_BANNER_MANAGEMENT_URL, "", "", true,
//            ParentModuleEnum.DYNAMIC_HOME.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
//
//    EDIT_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editAdsBanner"), "", "", "", true,
//            ADS_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
//    ADD_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addAdsBanner"), HomeConstant.ADD_ADS_PATH, "", "", true,
//            ADS_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
//
//    TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "topBanner"),
//            HomeConstant.TOP_BANNER_MANAGEMENT_URL, "", "", true,
//            ParentModuleEnum.DYNAMIC_HOME.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
//
//    ADD_TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addTopBanner"), HomeConstant.ADD_TOP_BANNER_MANAGEMENT_URL, "", "", true,
//            TOP_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
//    EDIT_TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editTpBanner"), HomeConstant.ADD_TOP_BANNER_MANAGEMENT_URL, "", "", true,
//            TOP_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
//
//    BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "businessBanner"),
//            HomeConstant.BUSINESS_BANNER_MANAGEMENT_URL, "", "", true,
//            ParentModuleEnum.DYNAMIC_HOME.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
//
//    ADD_BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addbusinessBanner"), HomeConstant.ADD_BUSINESS_BANNER_MANAGEMENT_URL, "", "", true,
//            BUSINESS_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
//    EDIT_BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editbusinessBanner"), HomeConstant.EDIT_BUSINESS_URL, "", "", true,
//            BUSINESS_BANNER.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
//
//    APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "apptips"),
//            HomeConstant.APP_TIPS_MANAGEMENT_URL, "", "", true,
//            ParentModuleEnum.DYNAMIC_HOME.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
//
//    ADD_APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "addAppTips"), HomeConstant.ADD_APP_TIPS_URL, "", "", true,
//            APP_TIPS.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
//    EDIT_APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "editAppTips"), HomeConstant.EDIT_APP_TIPS_URL, "", "", true,
//            APP_TIPS.name(),
//            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
//
;
    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }

}
