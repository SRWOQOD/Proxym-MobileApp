package com.woqod.fahes;

import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.fahes.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;


@Component
public class FahesBootstarp {
    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put("Fahes Inspection Management", ListMenu.builder().menus(Arrays.asList(MenuEnum.values())).build());
    }
}
