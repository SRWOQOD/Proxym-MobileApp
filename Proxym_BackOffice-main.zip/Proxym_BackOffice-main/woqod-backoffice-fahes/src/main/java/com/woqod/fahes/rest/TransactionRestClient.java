package com.woqod.fahes.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */

@Component
@Slf4j
@PropertySource("classpath:properties/fahes.properties")
public class TransactionRestClient {

    private final CustomRestTemplate topUpRestTemplate = new CustomRestTemplate();
    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.transaction.paginated}")
    private String paginatedList;

    @Value("${uri.ws.transById}")
    private String transById;
    @Value("${uri.ws.prtransactionlog.count}")
    private String count;

    public TransactionRestClient(BaseUrlProvider baseUrlProvider) {
        this.baseUrlProvider = baseUrlProvider;
    }


    public PaginatedListResponse<PRTransactionLogResource> paginatedListTransactions(Map<String, String> uriParams) {
        log.debug("[TopUpRestClient] paginatedListTransactions");
        String uri = paginatedList;

        return (PaginatedListResponse<PRTransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<PRTransactionLogResource>>>() {
                        });
    }

    public PRTransactionLogResource getTransById(String referenceNumber) {
        Map<String, String> uriParams = new HashMap<>();
        uriParams.put("uuid", referenceNumber);

        ObjectResponse<PRTransactionLogResource> response = (ObjectResponse<PRTransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(transById, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<PRTransactionLogResource>>>() {
                        });
        return response.getObject();
    }


    public List<PRTransactionLogResource> getTransactions(Map<String, String> uriParams) {
        String uri = "/prtransactionlog";
        return ((ListResponse<PRTransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<PRTransactionLogResource>>>() {
                        })).getList();

    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
}
