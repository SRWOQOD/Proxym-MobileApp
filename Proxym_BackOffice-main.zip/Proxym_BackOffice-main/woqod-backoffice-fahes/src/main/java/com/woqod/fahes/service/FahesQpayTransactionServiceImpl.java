package com.woqod.fahes.service;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.fahes.rest.FahesQpayTransactionRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.QpayRefundResponseResource;

import javax.faces.context.FacesContext;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class FahesQpayTransactionServiceImpl implements IFahesQpayTransactionService {

    private final FahesQpayTransactionRestClient transactionRestClient;
    private final DataFactory dataFactory;

    public FahesQpayTransactionServiceImpl(FahesQpayTransactionRestClient transactionRestClient, DataFactory dataFactory) {
        this.transactionRestClient = transactionRestClient;
        this.dataFactory = dataFactory;
    }

    @Override
    public PaginatedListResponse getPaginatedTransactions(Map<String, String> uriParams) {
        return transactionRestClient.paginatedListTransactions(uriParams);
    }

    public ObjectResponse<FahesQpayTransactionResource> getTransactionById(String referenceNumber) {
        try {
            return transactionRestClient.getTransactionById(referenceNumber);
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    @Override
    public List<FahesQpayTransactionResource> transactions(Map<String, String> uriParams) {
        return transactionRestClient.getTransactions(uriParams);
    }

    @Override
    public Integer count() {
        return transactionRestClient.count();
    }

    @Override
    public void refundTransaction(String pun, String amount) throws IOException {
        ObjectResponse<QpayRefundResponseResource> refundResource;

        try {
            refundResource = transactionRestClient.refundTransaction(pun, amount);

            if (refundResource.getObject().getStatus().equals("5002")) {
                String message = "Refund request send successfully!\n" + refundResource.getObject().getStatusMessage();
                BoUtils.showInfoPopup(refundResource.getObject().getStatus(), message);
            } else {
                BoUtils.showInfoPopup(refundResource.getObject().getStatus(), refundResource.getObject().getStatusMessage());
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesContext.getCurrentInstance().getExternalContext().redirect(dataFactory.getContext() + "/error.xhtml");
        }
    }

    @Override
    public void updateRefundProcess(boolean isHidden) {
        transactionRestClient.updateRefundProcess(isHidden);
    }


    @Override
    public boolean isRefundProcessHidden() {
        return transactionRestClient.isRefundProcessHidden();
    }
}
