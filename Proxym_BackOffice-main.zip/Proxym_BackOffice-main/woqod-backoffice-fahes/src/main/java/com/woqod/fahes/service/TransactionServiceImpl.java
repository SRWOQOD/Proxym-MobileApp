package com.woqod.fahes.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.fahes.rest.TransactionRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.List;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
@Service
@Slf4j
public class TransactionServiceImpl implements ITransactionService {

    private final TransactionRestClient transactionRestClient;

    public TransactionServiceImpl(TransactionRestClient transactionRestClient) {
        this.transactionRestClient = transactionRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedTransactions(Map<String, String> uriParams) {
        return transactionRestClient.paginatedListTransactions(uriParams);
    }

    @Override
    public PRTransactionLogResource getTransById(String referenceNumber) {
        try {
            return transactionRestClient.getTransById(referenceNumber);
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    @Override
    public List<PRTransactionLogResource> transactions(Map<String, String> uriParams) {
        return transactionRestClient.getTransactions(uriParams);
    }
    @Override
    public Integer count() {
        return transactionRestClient.count();
    }

}
