package com.woqod.fahes.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.base.Strings;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.fahes.enums.MenuEnum;
import com.woqod.fahes.lazymodel.FahesTransactionLazyModel;
import com.woqod.fahes.models.FahesTransactionFilterResource;
import com.woqod.fahes.service.IFahesService;
import com.woqod.fahes.service.ITransactionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.component.export.ExcelOptions;
import org.primefaces.component.export.PDFOptions;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.PreRegistrationResource;
import wq.woqod.resources.resources.TransactionLogResource;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping({"FahesTransactions"})
@Data
@Slf4j
public class FahesListPreTransactionController {
    private static final String TRANSACTION_LIST = "listPreTransaction";
    private final Permissions permissions;
    private final IFahesService iFahesService;
    private final ITransactionService iTransactionService;

    FahesTransactionLazyModel lazyModel;
    FahesTransactionLazyModel fahesLazyModel;

    private FahesTransactionFilterResource fahesTransactionFilterResource ;

    private String validationError = "Validation Error";


    private String userID;
    private String description;
    private String amount;
    private String currency;
    private String paymentMethod;
    private String authReversal;
    private String rpsStatus;
    private LocalDate createdDate;
    private PDFOptions pdfOpt;
    private ExcelOptions excelOpt;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private PreRegistrationResource preRegistrationResource;
    private PRTransactionLogResource transaction;
    private StreamedContent fileTransaction;
    private String contentType = "text/plain";
    Integer fahesTransactionsNumber;

    @Autowired
    public FahesListPreTransactionController(Permissions permissions, IFahesService iFahesService, ITransactionService iTransactionService) {
        this.permissions = permissions;
        this.iFahesService = iFahesService;
        this.iTransactionService = iTransactionService;
    }

    public static TransactionStatusEnum[] getTransactionStatusEnums() {
        return TransactionStatusEnum.values();
    }

    @GetMapping({""})
    public ModelAndView display() {
        this.init();
        return this.permissions.getModelAndView(MenuEnum.DISPLAY_TRANSACTION_FAHES.name(), TRANSACTION_LIST);
    }

    public void customizationOptions() {
        excelOpt = new ExcelOptions();
        excelOpt.setFacetBgColor("#F88017");
        excelOpt.setFacetFontSize("5");
        excelOpt.setFacetFontColor("#0000ff");
        excelOpt.setFacetFontStyle("normal");
        excelOpt.setCellFontColor("#00ff00");
        excelOpt.setCellFontSize("5");

        pdfOpt = new PDFOptions();
        pdfOpt.setFacetFontStyle("normal");
        pdfOpt.setCellFontSize("5");
    }

    public void init() {
        FahesListPreTransactionController.log.info("[FahesListPreTransactionController] init  ");
        customizationOptions();
        this.lazyModel = null;
        userID = "";
        amount = "";
        currency = "";
        description = "";
        createdDate = null;
        authReversal = "";
        rpsStatus = "";
        uriParams = new HashMap<>();
        this.lazyModel = new FahesTransactionLazyModel(iTransactionService);
        fahesTransactionsNumber = iTransactionService.count();
        fahesTransactionFilterResource = new FahesTransactionFilterResource();
        search();
    }

    public void clear() {
       fahesTransactionFilterResource = new FahesTransactionFilterResource();
       uriParams = new HashMap<>();
       search();
    }

    public void search() {
        FahesListPreTransactionController.log.info("[FahesListPreTransactionController] search");
        uriParams = new HashMap<>();

        if (!BooleanUtils.isTrue(checkDates())) {
            BoUtils.showErrorPopup(validationError, "Start date must be smaller then end date");
            return;
        }

        if (fahesTransactionFilterResource.getTransactionUUID() != null && !fahesTransactionFilterResource.getTransactionUUID().isEmpty()) {
            uriParams.put("transactionUUID", fahesTransactionFilterResource.getTransactionUUID().trim());
        }
        if (fahesTransactionFilterResource.getReferenceNumber() != null && !fahesTransactionFilterResource.getReferenceNumber().isEmpty()) {
            uriParams.put("referenceNumber", fahesTransactionFilterResource.getReferenceNumber().trim());
        }
        if (fahesTransactionFilterResource.getTransactionStatus() != null && !fahesTransactionFilterResource.getTransactionStatus().isEmpty()) {
            uriParams.put("transactionStatus", fahesTransactionFilterResource.getTransactionStatus());
        }

        this.getUriParams(uriParams);

        this.lazyModel.setSearchFlag(true);
        this.lazyModel.setSearch(uriParams);
    }

    public void getUriParams(Map<String, String> uriParams) {

        if (fahesTransactionFilterResource.getMobile() != null && !fahesTransactionFilterResource.getMobile().isEmpty()) {
            uriParams.put("mobile", fahesTransactionFilterResource.getMobile().trim());
        }
        if (fahesTransactionFilterResource.getQid() != null && !fahesTransactionFilterResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(fahesTransactionFilterResource.getQid().getBytes()));
        }
        if (fahesTransactionFilterResource.getTransactionID() != null && !fahesTransactionFilterResource.getTransactionID().isEmpty()) {
            uriParams.put("transactionID", fahesTransactionFilterResource.getTransactionID().trim());
        }
        if (fahesTransactionFilterResource.getApiStatus() != null && !fahesTransactionFilterResource.getApiStatus().isEmpty()) {
            uriParams.put("apiStatus", fahesTransactionFilterResource.getApiStatus().trim());
        }
        if (fahesTransactionFilterResource.getPlateNumber() != null && !fahesTransactionFilterResource.getPlateNumber().isEmpty()) {
            uriParams.put("plateNumber", fahesTransactionFilterResource.getPlateNumber().trim());
        }
        if (fahesTransactionFilterResource.getStartDate() != null) {
            uriParams.put("startDate", DateFormatter.localDateToStringDate(fahesTransactionFilterResource.getStartDate()));
        }
        if (fahesTransactionFilterResource.getEndDate() != null) {
            uriParams.put("endDate", DateFormatter.localDateToStringDate(fahesTransactionFilterResource.getEndDate()));
        }
    }

    public Boolean checkDates() {
        if(fahesTransactionFilterResource.getStartDate() != null && fahesTransactionFilterResource.getEndDate() != null) {
            return fahesTransactionFilterResource.getStartDate().compareTo(fahesTransactionFilterResource.getEndDate()) <= 0;
        }
        return true;
    }

    public void exportCSV() throws IOException, JRException {
        List<PRTransactionLogResource> transactions = iTransactionService.transactions(uriParams);
        for (PRTransactionLogResource listTransaction : transactions) {
            listTransaction.setQid(BoUtils.decodeFromBase64(listTransaction.getQid()));
        }
        String base64 = GenerateJasperReport.generateReport(iTransactionService.transactions(uriParams), "export/fahes.jrxml", "Fahes Transactions", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Transactions.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {
        List<PRTransactionLogResource> transactions = iTransactionService.transactions(uriParams);
        for (PRTransactionLogResource listTransaction : transactions) {
            listTransaction.setQid(BoUtils.decodeFromBase64(listTransaction.getQid()));
        }

        String base64 = GenerateJasperReport.generateReport(transactions, "fahes/fahesTransaction.jrxml", "Fahes Transactions", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Transactions.pdf").stream(() -> is).build();
    }

    public void getTransById(PRTransactionLogResource pre) {
        this.preRegistrationResource = this.iFahesService.getPreRegistrationById(pre.getTransactionUUID());
    }

    public String objToData() throws JsonProcessingException {
        ObjectWriter mapper = new ObjectMapper().writerWithDefaultPrettyPrinter();
        return mapper.writeValueAsString(transaction);

    }

    public void download() throws IOException {
        byte[] bval = this.objToData().getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        fileTransaction = DefaultStreamedContent.builder().contentType(contentType).name("Transction.txt").stream(() -> stream).build();
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            byte[] valueDecoded = Base64.getDecoder().decode(qid);
            return new String(valueDecoded);
        } else {
            return qid;
        }
    }
}
