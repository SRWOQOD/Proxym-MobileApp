package com.woqod.fahes.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.List;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
public interface ITransactionService {

    PaginatedListResponse<PRTransactionLogResource> getPaginatedTransactions(Map<String, String> uriParams);

    PRTransactionLogResource getTransById(String referenceNumber);

    List<PRTransactionLogResource> transactions(Map<String, String> uriParams);

    Integer count();
}
