package com.woqod.fahes.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.fahes.service.IFahesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.CarResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class FahesCarLazyModel extends LazyDataModel<CarResource> {
    private static final long serialVersionUID = 1;
    private final transient IFahesService iFahesService;
    private Map<String, String> search;
    private Boolean searchFlag = false;

    public FahesCarLazyModel(final IFahesService iFahesService) {
        this.iFahesService = iFahesService;
        this.search = new HashMap<>();
    }


    @Override
    public Object getRowKey(final CarResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(final int rowIndex) {
        if (rowIndex == -1 || this.getPageSize() == 0) {
            super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % this.getPageSize());
        }
    }

    @Override
    public List<CarResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        if (BooleanUtils.isTrue(searchFlag)) {
            first = 0;
        }
        search.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

        try {
            final PaginatedListResponse<CarResource> response = this.iFahesService.getPaginatedCars(this.search);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchFlag = false;
            return response.getList();
        } catch (Exception e) {
            log.error(e.getMessage());
            final FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return new ArrayList<>();
        }
    }

    public void setSearch(final Map<String, String> search) {
        this.search = search;
    }
}
