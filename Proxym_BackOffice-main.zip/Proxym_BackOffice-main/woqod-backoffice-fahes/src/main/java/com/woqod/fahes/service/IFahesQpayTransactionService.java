package com.woqod.fahes.service;

import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FahesQpayTransactionResource;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface IFahesQpayTransactionService {

    PaginatedListResponse<FahesQpayTransactionResource> getPaginatedTransactions(Map<String, String> uriParams);

    ObjectResponse<FahesQpayTransactionResource> getTransactionById(String referenceNumber);

    List<FahesQpayTransactionResource> transactions(Map<String, String> uriParams);

    void refundTransaction(String pun, String amount) throws IOException;

    Integer count();

    void updateRefundProcess(boolean isHidden);

    boolean isRefundProcessHidden();

}
