package com.woqod.fahes.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.QpayRefundResponseResource;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */

@Component
@Slf4j
@PropertySource("classpath:properties/fahesqpay.properties")
public class FahesQpayTransactionRestClient {

    private final CustomRestTemplate topUpRestTemplate = new CustomRestTemplate();
    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.qpay.transaction.paginated}")
    private String paginatedList;

    @Value("${uri.ws.transById}")
    private String transById;

    @Value("${uri.ws.qpay.transaction.count}")
    private String count;

    @Value("${uri.ws.refundTransaction}")
    private String refundTransactionUrl;

    @Value("${uri.ws.qpay.fahes.refundconfig}")
    private String refundConfig;

    public FahesQpayTransactionRestClient(BaseUrlProvider baseUrlProvider) {
        this.baseUrlProvider = baseUrlProvider;
    }

    public PaginatedListResponse<FahesQpayTransactionResource> paginatedListTransactions(Map<String, String> uriParams) {
        log.debug("[TopUpRestClient] paginatedListTransactions");
        String uri = paginatedList;

        return (PaginatedListResponse<FahesQpayTransactionResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<FahesQpayTransactionResource>>>() {
                        });
    }

    public ObjectResponse<FahesQpayTransactionResource> getTransactionById(String referenceNumber) {
        Map<String, String> uriParams = new HashMap<>();
        uriParams.put("pun", referenceNumber);

        return  (ObjectResponse<FahesQpayTransactionResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(transById, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<FahesQpayTransactionResource>>>() {
                        });
    }


    public List<FahesQpayTransactionResource> getTransactions(Map<String, String> uriParams) {
        String uri = "/qpay/prtransaction";
        return ((ListResponse<FahesQpayTransactionResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<FahesQpayTransactionResource>>>() {
                        })).getList();

    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse<Integer>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return  response.getObject();
    }


    public ObjectResponse<QpayRefundResponseResource> refundTransaction(String pun, String amount) {
        HashMap<String, String> map = new HashMap<>();
        map.put("pun", pun);
        map.put("amount", amount);
        return  (ObjectResponse) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(refundTransactionUrl, map),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<QpayRefundResponseResource>>>() {
                        });
    }


    public void updateRefundProcess(boolean isHidden) {
        BooleanResponse response = (BooleanResponse) topUpRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(refundConfig), isHidden,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        log.info(String.valueOf(response));
    }

    public boolean isRefundProcessHidden() {
        String uri = refundConfig;
        BooleanResponse response = (BooleanResponse) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }
}
