package com.woqod.fahes.viewmodel;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.fahes.service.IFahesQpayTransactionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.ManagedBean;
import javax.faces.context.FacesContext;

@Data
@Slf4j
@Component
@Scope("session")
@ManagedBean
public class HideRefundQpayFahesTransactionsViewModel {
    /*
    Beans
     */
    private final DataFactory dataFactory;
    private final IFahesQpayTransactionService fahesQpayTransactionService;

    /*
    State
     */
    private boolean isHidden;
    private String notHiddenMsg = "Hidden";
    private String hiddenMsg = "Not Hidden";


    @Autowired
    public HideRefundQpayFahesTransactionsViewModel(DataFactory dataFactory, IFahesQpayTransactionService fahesQpayTransactionService) {
        this.dataFactory = dataFactory;
        this.fahesQpayTransactionService = fahesQpayTransactionService;
    }


    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        this.isHidden = fahesQpayTransactionService.isRefundProcessHidden();
    }

    public boolean getIsHidden() {
        return isHidden;
    }

    public void updateIsHidden() {
        fahesQpayTransactionService.updateRefundProcess(isHidden);
        dataFactory.redirect("FahesQpayTransactions/hide");
    }
}
