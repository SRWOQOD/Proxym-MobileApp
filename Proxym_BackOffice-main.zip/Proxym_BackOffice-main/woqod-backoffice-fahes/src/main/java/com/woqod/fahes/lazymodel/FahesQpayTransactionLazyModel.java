package com.woqod.fahes.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.fahes.service.IFahesQpayTransactionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.PRTransactionLogResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.*;

@Data
@Slf4j
public class FahesQpayTransactionLazyModel extends LazyDataModel<FahesQpayTransactionResource> {

    private static final long serialVersionUID = 1;
    private final transient IFahesQpayTransactionService iTransactionService;
    private Map<String, String> search;
    private Boolean searchFlag = false;
    private transient List<FahesQpayTransactionResource> data = new ArrayList<>();

    public FahesQpayTransactionLazyModel(IFahesQpayTransactionService iTransactionService) {
        this.iTransactionService = iTransactionService;
        this.search = new HashMap<>();
    }


    @Override
    public Object getRowKey(final FahesQpayTransactionResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(final int rowIndex) {
        if (rowIndex == -1 || this.getPageSize() == 0) {
            super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % this.getPageSize());
        }
    }

    @Override
    public FahesQpayTransactionResource getRowData(String rowKey) {
        Optional<FahesQpayTransactionResource> userResourceOptional = data.stream().filter(r -> r.getId().equals(Long.parseLong(rowKey))).findFirst();
        return userResourceOptional.orElse(null);

    }

    @Override
    public List<FahesQpayTransactionResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        if (Boolean.TRUE.equals(searchFlag)) {
            first = 0;
        }
        search.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

        try {
            final PaginatedListResponse<FahesQpayTransactionResource> response = this.iTransactionService.getPaginatedTransactions(this.search);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchFlag = false;
            data.addAll(response.getList());
            return response.getList();
        } catch (Exception e) {
            log.error(e.getMessage());
            final FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return new ArrayList<>();
        }
    }

    public Boolean getSearchFlag() {
        return searchFlag;
    }

    public void setSearchFlag(Boolean searchFlag) {
        this.searchFlag = searchFlag;
    }

    public void setSearch(final Map<String, String> search) {
        this.search = search;
    }
}
