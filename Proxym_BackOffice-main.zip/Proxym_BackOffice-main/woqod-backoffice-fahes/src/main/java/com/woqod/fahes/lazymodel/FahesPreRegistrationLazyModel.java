package com.woqod.fahes.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.fahes.service.IFahesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.CarCategoryResource;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.PlateTypeResource;
import wq.woqod.resources.resources.PreRegistrationResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class FahesPreRegistrationLazyModel extends LazyDataModel<PreRegistrationResource> implements Serializable {
    private final transient IFahesService iFahesService;
    private Map<String, String> search;
    private Boolean searchFlag = false;
    private transient PreRegistrationResource preRegistrationResource;
    private static final long serialVersionUID = 1;


    public FahesPreRegistrationLazyModel(final IFahesService iFahesService) {
        this.iFahesService = iFahesService;
        this.search = new HashMap<>();
        this.preRegistrationResource = new PreRegistrationResource();
        this.preRegistrationResource.setCar(CarResource.builder().plateType(new PlateTypeResource()).build());
        this.preRegistrationResource.setCarCategoryResource(CarCategoryResource.builder().build());
    }


    @Override
    public Object getRowKey(final PreRegistrationResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(final int rowIndex) {
        if (rowIndex == -1 || this.getPageSize() == 0) {
            super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % this.getPageSize());
        }
    }

    @Override
    public List<PreRegistrationResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        if (BooleanUtils.isTrue(searchFlag)) {
            first = 0;
        }
        search.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

        try {
            final PaginatedListResponse<PreRegistrationResource> response = this.iFahesService.getPaginatedPreRegistration(this.search);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchFlag = false;
            return response.getList();
        } catch (Exception e) {
            log.error(e.getMessage());
            final FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return new ArrayList<>();
        }
    }

}
