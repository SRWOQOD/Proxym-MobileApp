
package com.woqod.fahes.controller;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.fahes.enums.MenuEnum;
import com.woqod.fahes.lazymodel.FahesPreRegistrationLazyModel;
import com.woqod.fahes.service.IFahesService;
import com.woqod.fahes.service.ITransactionService;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.PreRegistrationResource;

import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping({"FahesPreRegistration"})
@Getter
@Setter
@Slf4j
public class FahesListPreRegistrationController {
    private static final String PRE_REGISTRATION = "preRegistration";
    private final Permissions permissions;
    private final IFahesService iFahesService;
    private final ITransactionService iTransactionService;
    private LazyDataModel<PreRegistrationResource> lazyModel;


    private String referenceNumber;
    private String transactionUUID;
    private String qid;
    private String plateNumber;
    private String plateType;
    private LocalDate creationDate;
    private PRTransactionLogResource transaction;
    private StreamedContent fileCSV;
    private StreamedContent file;
    Map<String, String> uriParams = new HashMap<>();
    private StreamedContent fileReceipt;
    private String contentType = "text/plain";

    private final DataFactory dataFactory;

    @Autowired
    public FahesListPreRegistrationController(Permissions permissions, IFahesService iFahesService, ITransactionService iTransactionService, DataFactory dataFactory) {
        this.iTransactionService = iTransactionService;
        this.permissions = permissions;
        this.iFahesService = iFahesService;
        this.dataFactory = dataFactory;
    }


    public void init() {
        FahesListPreRegistrationController.log.info("[FahesListPreRegistrationController] init");
        referenceNumber = "";
        transactionUUID = "";
        qid = "";
        plateNumber = "";
        plateType = "";
        creationDate = null;
        uriParams = new HashMap<>();
        this.lazyModel = new FahesPreRegistrationLazyModel(iFahesService);
    }

    public void clear() {
        this.init();
    }

    public void preProcessPDF(Object document) {
        Document doc = (Document) document;
        doc.setPageSize(PageSize.A4.rotate());
    }

    public void search() {
        uriParams = new HashMap<>();

        if (transactionUUID != null) {
            uriParams.put("transactionUUID", transactionUUID);
        }
        if (qid != null) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(qid.trim().getBytes()));
        }
        if (referenceNumber != null) {
            uriParams.put("referenceNumber", referenceNumber);
        }
        if (plateNumber != null) {
            uriParams.put("plateNumber", plateNumber);
        }
        if (creationDate != null) {
            uriParams.put("dateCreation", DateFormatter.localDateToStringDate(creationDate));
        }
        if (plateType != null) {
            uriParams.put("plateType", plateType);
        }

        ((FahesPreRegistrationLazyModel) this.lazyModel).setSearchFlag(true);
        ((FahesPreRegistrationLazyModel) this.lazyModel).setSearch(uriParams);
    }


    public void sendEmail(String transactionUUID) {
        PreRegistrationResource pre = iFahesService.getPreRegistrationById(transactionUUID);
        try {
            HashMap<String, Object> serviceData = new HashMap<>();
            serviceData.put(UtilsConstants.POST_DATA, pre);
            serviceData.put(UtilsConstants.FEATURE, MenuEnum.SEND_EMAIL.name());
            if (iFahesService.sendEmailBo(serviceData)) {
                BoUtils.showInfoPopup("SUCCESS", "Mail sent successfully");
            } else {
                BoUtils.showFailurePopup();
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            BoUtils.showFailurePopup();
        }
    }

    public void getTransById(PreRegistrationResource pre) {
        this.transaction = this.iTransactionService.getTransById(pre.getTransactionUUID());
    }

    public void generatePdf(String transactionUUID) throws IOException {
        try {
            PreRegistrationResource pre = iFahesService.getPreRegistrationById(transactionUUID);
            if (pre != null) {
                String base64 = this.iFahesService.generatePDF(pre.getReferenceNumber());
                ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
                fileReceipt = DefaultStreamedContent.builder().contentType(contentType).name("Receipt_" + pre.getReferenceNumber() + ".pdf").stream(() -> is).build();
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesContext.getCurrentInstance().getExternalContext().redirect(dataFactory.getContext() + "/error.xhtml");
        }
    }

    public void exportCSV() throws IOException {
        try {
            String base64 = GenerateJasperReport.generateReport(iFahesService.preRegistration(uriParams), "export/generateReceipt.jrxml", "Fahes Receipts", JasperReportType.CSV);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));

            fileCSV = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Receipts.csv").stream(() -> is).build();
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesContext.getCurrentInstance().getExternalContext().redirect(dataFactory.getContext() + "/error.xhtml");
        }
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(iFahesService.preRegistration(uriParams), "fahes/generateReceipt.jrxml", "Fahes Receipts", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Receipts.pdf").stream(() -> is).build();
    }

}
