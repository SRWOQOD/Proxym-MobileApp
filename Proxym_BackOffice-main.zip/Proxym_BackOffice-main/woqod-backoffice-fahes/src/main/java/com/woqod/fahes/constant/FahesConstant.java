package com.woqod.fahes.constant;

public final class FahesConstant {
    public static final String BUNDLE_NAME = "fahes_messages";
    public static final String HIDE_REFUND_ACTION_FAHES_URL = "/FahesQpayTransactions/hide";
    public static final String HIDE_REFUND_ACTION_FAHES_VIEW = "hideRefundQpayFahesTransactions";

    private FahesConstant() {
    }
}
