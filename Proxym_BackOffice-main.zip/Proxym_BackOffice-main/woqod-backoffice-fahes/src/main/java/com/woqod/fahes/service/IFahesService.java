package com.woqod.fahes.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.PreRegistrationResource;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface IFahesService {
    PaginatedListResponse<CarResource> getPaginatedCars(Map<String, String> uriParams);

    PaginatedListResponse<PreRegistrationResource> getPaginatedPreRegistration(Map<String, String> uriParams);

    Boolean sendEmailBo(HashMap<String, Object> serviceData);

    String generatePDF(String receiptUrl) throws IOException;

    List<CarResource> cars(Map<String, String> uriParams);

    List<PreRegistrationResource> preRegistration(Map<String, String> uriParams);

    PreRegistrationResource getPreRegistrationById(String id);

    Integer count();
}

