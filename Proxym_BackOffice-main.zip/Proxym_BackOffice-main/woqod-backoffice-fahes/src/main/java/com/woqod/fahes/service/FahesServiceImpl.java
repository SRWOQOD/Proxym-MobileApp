package com.woqod.fahes.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.fahes.rest.FahesRestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.PreRegistrationResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FahesServiceImpl implements IFahesService {

    private final FahesRestClient fahesRestClient;

    public FahesServiceImpl(final FahesRestClient fahesRestClient) {
        this.fahesRestClient = fahesRestClient;
    }

    @Value("${receipt.url}")
    private String url;

    @Override
    public PaginatedListResponse<CarResource> getPaginatedCars(Map<String, String> uriParams) {
        return this.fahesRestClient.getPaginatedCars(uriParams);
    }

    @Override
    public PaginatedListResponse<PreRegistrationResource> getPaginatedPreRegistration(Map<String, String> uriParams) {
        return this.fahesRestClient.getPaginatedPreRegistration(uriParams);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public Boolean sendEmailBo(HashMap<String, Object> serviceData) {
        PreRegistrationResource pre = (PreRegistrationResource) serviceData.get(UtilsConstants.POST_DATA);
        return fahesRestClient.sendEmailBo(pre);
    }

    @Override
    public String generatePDF(String receiptUrl) {
        return fahesRestClient.generatePDF(receiptUrl);
    }

    @Override
    public List<CarResource> cars(Map<String, String> uriParams) {
        return fahesRestClient.getCars(uriParams);
    }

    @Override
    public List<PreRegistrationResource> preRegistration(Map<String, String> uriParams) {
        return fahesRestClient.getPreRegistration(uriParams);
    }

    @Override
    public PreRegistrationResource getPreRegistrationById(String id) {
        return fahesRestClient.getPreRegistrationById(id);
    }

    @Override
    public Integer count() {
        return fahesRestClient.count();
    }
}
