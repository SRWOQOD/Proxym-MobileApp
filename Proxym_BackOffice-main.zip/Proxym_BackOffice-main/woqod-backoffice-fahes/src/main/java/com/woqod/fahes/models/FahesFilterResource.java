package com.woqod.fahes.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FahesFilterResource {

    private String plateNumber;
    private String active;
    private LocalDate creationDate;
    private String owner;
}
