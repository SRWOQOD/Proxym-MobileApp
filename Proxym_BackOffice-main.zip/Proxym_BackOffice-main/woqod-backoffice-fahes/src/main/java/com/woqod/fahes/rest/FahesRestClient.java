package com.woqod.fahes.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.PreRegistrationResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
@PropertySource({"classpath:properties/fahes.properties"})
public class FahesRestClient {
    private final CustomRestTemplate fahesRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.fahes.paginated}")
    private String paginatedCarUri;

    @Value("${uri.ws.fahes.paginated.preRegistration}")
    private String preRegistration;


    @Value("${uri.ws.preRegistration.sendEmail}")
    private String sendEmailBoUrl;


    @Value("${uri.ws.preRegistration.generatePdf}")
    private String generatePdfUrl;

    @Value("${uri.ws.preRegistration.getByUUID}")
    private String getByUUID;

    @Value("${uri.ws.count}")
    private String count;

    public FahesRestClient(final BaseUrlProvider baseUrlProvider) {
        this.fahesRestTemplate = new CustomRestTemplate();
        this.baseUrlProvider = baseUrlProvider;
    }

    public PaginatedListResponse<CarResource> getPaginatedCars(final Map<String, String> uriParams) {
        return (PaginatedListResponse<CarResource>) this.fahesRestTemplate.getGenericResponseBody(this.baseUrlProvider.getUrl(this.paginatedCarUri, uriParams), new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<CarResource>>>() {
        });
    }

    public PaginatedListResponse<PreRegistrationResource> getPaginatedPreRegistration(Map<String, String> uriParams) {
        return (PaginatedListResponse<PreRegistrationResource>) this.fahesRestTemplate.getGenericResponseBody(this.baseUrlProvider.getUrl(this.preRegistration, uriParams), new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<PreRegistrationResource>>>() {
        });

    }

    public Boolean sendEmailBo(PreRegistrationResource pre) {
        HashMap<String, String> map = new HashMap<>();
        map.put("reference_number", pre.getReferenceNumber());
        map.put("transactionuuid", pre.getTransactionUUID());
        BooleanResponse response = fahesRestTemplate
                .getBooleanResponse(baseUrlProvider.getUrl(sendEmailBoUrl, map));
        return response.isSuccess();
    }


    public String generatePDF(String referenceNumber) {

        String uri = generatePdfUrl.concat("?reference_number=").concat(referenceNumber);
        ObjectResponse<String> response = (ObjectResponse<String>) fahesRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<String>>>() {
                        });
        return response.getObject();
    }

    public List<CarResource> getCars(Map<String, String> uriParams) {
        String uri = "/car/cars";
        return ((ListResponse<CarResource>) fahesRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<CarResource>>>() {
                        })).getList();

    }

    public List<PreRegistrationResource> getPreRegistration(Map<String, String> uriParams) {
        String uri = "/preregistration/preregistrations";
        return ((ListResponse<PreRegistrationResource>) fahesRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<PreRegistrationResource>>>() {
                        })).getList();

    }

    public PreRegistrationResource getPreRegistrationById(String id) {
        String uri = getByUUID.concat("?transactionuuid=").concat(id);
        ObjectResponse<PreRegistrationResource> response = (ObjectResponse<PreRegistrationResource>) fahesRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<PreRegistrationResource>>>() {
                        });
        return response.getObject();
    }

    public Integer count() {
        String uri =  "/car/count";
        ObjectResponse<Integer> response = (ObjectResponse) fahesRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse>>() {
                        });
        return response.getObject();
    }
}
