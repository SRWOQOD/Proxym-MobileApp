package com.woqod.fahes.viewmodel;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.base.Strings;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.fahes.lazymodel.FahesQpayTransactionLazyModel;
import com.woqod.fahes.service.IFahesQpayTransactionService;
import com.woqod.fahes.service.IFahesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.component.export.ExcelOptions;
import org.primefaces.component.export.PDFOptions;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.PreRegistrationResource;
import wq.woqod.resources.resources.QpayRefundResponseResource;

import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class FahesQpayTransactionViewModel {

    private static final String SERVICE_NAME = "QPAY_FAHES_TRANSACTION";

    private final Permissions permissions;
    private final DataFactory dataFactory;
    private final IFahesService iFahesService;
    private final IFahesQpayTransactionService iTransactionService;
    FahesQpayTransactionLazyModel fahesLazyModel;

    private String referenceNumber;
    private String transactionStatus;
    private String userID;
    private String qid;
    private String mobile;
    private String description;
    private String amount;
    private String currency;
    private String paymentMethod;
    private String apiStatus;
    private String transactionID;
    private String authReversal;
    private String rpsStatus;
    private String plateNumber;
    private LocalDate createdDate;
    private LocalDate startDate;
    private LocalDate endDate;
    private PDFOptions pdfOpt;
    private ExcelOptions excelOpt;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private PreRegistrationResource preRegistrationResource;
    private ObjectResponse<QpayRefundResponseResource> refundResource;
    private FahesQpayTransactionResource transaction;
    private StreamedContent fileTransaction;
    private String contentType = "text/plain";
    Integer fahesTransactionsNumber;
    private String pun;
    private FahesQpayTransactionResource selectedTransaction;
    private Integer refundAmount;
    private Boolean isHidden;

    @Autowired
    public FahesQpayTransactionViewModel(Permissions permissions, DataFactory dataFactory, IFahesService iFahesService, IFahesQpayTransactionService iTransactionService) {
        this.permissions = permissions;
        this.dataFactory = dataFactory;
        this.iFahesService = iFahesService;
        this.iTransactionService = iTransactionService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    public static TransactionStatusEnum[] getTransactionStatusEnums() {
        return TransactionStatusEnum.values();
    }

    public void customizationOptions() {
        excelOpt = new ExcelOptions();
        excelOpt.setFacetBgColor("#F88017");
        excelOpt.setFacetFontSize("5");
        excelOpt.setFacetFontColor("#0000ff");
        excelOpt.setFacetFontStyle("normal");
        excelOpt.setCellFontColor("#00ff00");
        excelOpt.setCellFontSize("5");

        pdfOpt = new PDFOptions();
        pdfOpt.setFacetFontStyle("normal");
        pdfOpt.setCellFontSize("5");
    }

    public void init() {
        customizationOptions();
        this.fahesLazyModel = null;
        pun = "";
        referenceNumber = "";
        transactionStatus = "";
        userID = "";
        mobile = "";
        amount = "";
        currency = "";
        description = "";
        qid = "";
        transactionID = "";
        createdDate = null;
        authReversal = "";
        rpsStatus = "";
        apiStatus = "";
        plateNumber = "";
        startDate = null;
        endDate = null;
        refundAmount = null;
        isHidden = iTransactionService.isRefundProcessHidden();
        uriParams = new HashMap<>();
        this.fahesLazyModel = new FahesQpayTransactionLazyModel(iTransactionService);
        fahesTransactionsNumber = iTransactionService.count();
    }

    public void clear() {
        this.init();
    }

    public void search() {
        FahesQpayTransactionViewModel.log.info("[FahesQpayTransactionsViewModel] search");
        uriParams = new HashMap<>();

        this.putParamsForSearch();

        if (plateNumber != null && !plateNumber.isEmpty()) {
            uriParams.put("plateNumber", plateNumber.trim());
        }
        if (startDate != null) {
            uriParams.put("startDate", DateFormatter.localDateToStringDate(startDate));
        }
        if (endDate != null) {
            uriParams.put("endDate", DateFormatter.localDateToStringDate(endDate));
        }
        this.fahesLazyModel.setSearchFlag(true);
        this.fahesLazyModel.setSearch(uriParams);
    }

    private void putParamsForSearch() {
        if (pun != null && !pun.isEmpty()) {
            uriParams.put("pun", pun.trim());
        }
        if (referenceNumber != null && !referenceNumber.isEmpty()) {
            uriParams.put("referenceNumber", referenceNumber.trim());
        }
        if (transactionStatus != null && !transactionStatus.isEmpty()) {
            uriParams.put("transactionStatus", transactionStatus);
        }
        if (mobile != null && !mobile.isEmpty()) {
            uriParams.put("mobile", mobile.trim());
        }
        buildSearchUriParams();

        this.fahesLazyModel.setSearchFlag(true);
        this.fahesLazyModel.setSearch(uriParams);
    }

    private void buildSearchUriParams() {
        if (qid != null && !qid.isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(qid.trim().getBytes()));
        }
        if (transactionID != null && !transactionID.isEmpty()) {
            uriParams.put("transactionID", transactionID.trim());
        }
        if (apiStatus != null && !apiStatus.isEmpty()) {
            uriParams.put("apiStatus", apiStatus.trim());
        }
        if (plateNumber != null && !plateNumber.isEmpty()) {
            uriParams.put("plateNumber", plateNumber.trim());
        }
        if (startDate != null) {
            uriParams.put("startDate", DateFormatter.localDateToStringDate(startDate));
        }
        if (endDate != null) {
            uriParams.put("endDate", DateFormatter.localDateToStringDate(endDate));
        }
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(iTransactionService.transactions(uriParams), "export/fahesQpayTransactions.jrxml", "Fahes Transactions", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Transactions.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {

        List<FahesQpayTransactionResource> transactions = iTransactionService.transactions(uriParams);
        for (FahesQpayTransactionResource listTransaction : transactions) {
            listTransaction.setQid(BoUtils.decodeFromBase64(listTransaction.getQid()));
        }
        String base64 = GenerateJasperReport.generateReport(transactions, "fahes/fahesQpayTransactions.jrxml", "Fahes Transactions", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType(contentType).name("Fahes Transactions.pdf").stream(() -> is).build();
    }

    public void getTransactionById(FahesQpayTransactionResource pre) {
        this.preRegistrationResource = this.iFahesService.getPreRegistrationById(pre.getPun());
    }

    public String objToData() throws JsonProcessingException {
        ObjectWriter mapper = new ObjectMapper().writerWithDefaultPrettyPrinter();
        return mapper.writeValueAsString(transaction);

    }

    public void download() throws IOException {
        byte[] bval = this.objToData().getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(bval);
        fileTransaction = DefaultStreamedContent.builder().contentType(contentType).name("QpayTransctions.txt").stream(() -> stream).build();

    }

    public void refundTransaction(FahesQpayTransactionResource selectedTransaction) throws IOException {
        if (refundAmount > selectedTransaction.getAmount()) {
            BoUtils.showErrorPopup("Invalid refund amount", "Correct the amount \n" +
                    "value, it should be full amount of original transaction to\n" +
                    "be refunded.");
        } else {
            iTransactionService.refundTransaction(selectedTransaction.getPun(), String.valueOf(refundAmount));
        }
    }

    public void getTransById(FahesQpayTransactionResource pre) {
        this.preRegistrationResource = this.iFahesService.getPreRegistrationById(pre.getPun());
    }

    public String decodeTransactionStatusMessage(String transactionStatusMessage) {
        String decodeStatusMessage;
        try {
            log.info("Encoded String : {}", transactionStatusMessage);
            decodeStatusMessage = URLDecoder.decode(transactionStatusMessage, "UTF-8");
            log.info("Decoded String : {}", decodeStatusMessage);
            return decodeStatusMessage;
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError("UTF-8 not supported");
        }
    }

    public void clearRefundedAmount() {
        this.refundAmount = null;
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            byte[] valueDecoded = Base64.getDecoder().decode(qid);
            return new String(valueDecoded);
        } else {
            return qid;
        }
    }
}
