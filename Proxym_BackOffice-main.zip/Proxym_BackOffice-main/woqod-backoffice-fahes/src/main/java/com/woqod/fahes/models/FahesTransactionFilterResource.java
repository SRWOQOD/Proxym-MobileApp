package com.woqod.fahes.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FahesTransactionFilterResource {

    private String transactionUUID;
    private String referenceNumber;
    private String transactionStatus;
    private String qid;
    private String mobile;
    private LocalDate startDate;
    private LocalDate endDate;
    private String plateNumber;
    private String transactionID;
    private String apiStatus;
}
