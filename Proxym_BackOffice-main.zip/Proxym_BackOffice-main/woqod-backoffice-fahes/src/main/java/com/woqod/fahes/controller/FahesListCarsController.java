package com.woqod.fahes.controller;

import com.google.common.base.Strings;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.fahes.enums.MenuEnum;
import com.woqod.fahes.lazymodel.FahesCarLazyModel;
import com.woqod.fahes.models.FahesFilterResource;
import com.woqod.fahes.service.IFahesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.TransactionLogResource;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping({"/fahes"})
@Data
@Slf4j
public class FahesListCarsController {
    private static final String CAR_LIST = "listCar";
    private static final String QPAY_PAYMENT_URL = "qpayPayment";


    private final Permissions permissions;
    private final IFahesService fahesService;
    private LazyDataModel<CarResource> lazyModel;
    private FahesFilterResource fahesFilterResource;

    private List<CarResource> carResources;
    private String year;
    private String plateType;
    private String manufacturer;
    private String model;
    private LocalDate dueDate;
    private String vin;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private Integer fahesCars;

    @Autowired
    public FahesListCarsController(final Permissions permissions, final IFahesService fahesService) {
        this.permissions = permissions;
        this.fahesService = fahesService;
    }

    @GetMapping({""})
    public ModelAndView display() {
        this.init();
        return this.permissions.getModelAndView(MenuEnum.DISPLAY_FAHES.name(), CAR_LIST);
    }


    @GetMapping({"/qpay"})
    public ModelAndView displayQpay() {
        this.init();
        return this.permissions.getModelAndView(MenuEnum.DISPLAY_FAHES.name(), QPAY_PAYMENT_URL);
    }

    public void init() {
        FahesListCarsController.log.info("[FahesListCarsController] init  ");
        uriParams = new HashMap<>();
        this.year = "";
        this.plateType = "";
        this.manufacturer = "";
        this.model = "";
        this.dueDate = null;
        this.vin = "";
        this.lazyModel = new FahesCarLazyModel(fahesService);
        fahesCars = fahesService.count();
        fahesFilterResource = new FahesFilterResource();
        search();
    }

    public void search() {
        log.info("[FahesListCarsController] search");
        uriParams = new HashMap<>();
        uriParams.put("plateNumber", this.fahesFilterResource.getPlateNumber());
        uriParams.put("year", this.year);
        if (!this.plateType.isEmpty()) {
            uriParams.put("plateType", this.plateType);
        }
        uriParams.put("active", this.fahesFilterResource.getActive());
        if (fahesFilterResource.getCreationDate() != null) {
            uriParams.put("creationDate", DateFormatter.localDateToStringDate(fahesFilterResource.getCreationDate()));
        }
        uriParams.put("manufacturer", this.manufacturer);
        uriParams.put("model", this.model);
        if (dueDate != null) {
            uriParams.put("dueDate", DateFormatter.localDateToStringDate(dueDate));
        }
        uriParams.put("owner", (fahesFilterResource.getOwner() != null) ? Base64.getEncoder().encodeToString(fahesFilterResource.getOwner().trim().getBytes()) : null);
        uriParams.put("vin", this.vin);
        ((FahesCarLazyModel) this.lazyModel).setSearchFlag(true);
        ((FahesCarLazyModel) this.lazyModel).setSearch(uriParams);
    }

    public void clear() {
        fahesFilterResource = new FahesFilterResource();
        uriParams = new HashMap<>();
        search();
    }

    public void exportCSV() throws IOException, JRException {

        List<CarResource> cars = fahesService.cars(uriParams);
        for (CarResource carResource : cars) {
            carResource.setOwnerQid(BoUtils.decodeFromBase64(carResource.getOwnerQid()));
        }
        String base64 = GenerateJasperReport.generateReport(cars, "export/cars.jrxml", "Cars List", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Cars.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        List<CarResource> cars = fahesService.cars(uriParams);
        for (CarResource carResource : cars) {
            carResource.setOwnerQid(BoUtils.decodeFromBase64(carResource.getOwnerQid()));
        }
        String base64 = GenerateJasperReport.generateReport(cars, "fahes/cars.jrxml", "Cars List", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Cars.pdf").stream(() -> is).build();
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            byte[] valueDecoded = Base64.getDecoder().decode(qid);
            return new String(valueDecoded);
        } else {
            return qid;
        }
    }
}
