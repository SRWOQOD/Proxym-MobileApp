package com.woqod.content.viewmodel.news;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.content.rest.FileUploadRestClient;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FileUploadResource;

import javax.annotation.ManagedBean;
import javax.faces.application.FacesMessage;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Base64;
import java.net.URL;
import java.util.Objects;

import static wq.woqod.resources.enumerations.FileSubjectEnum.NEWS;

@Data
@Slf4j
@Component
@Scope("view")
public class AddNewsViewModel {
    /*
       Beans
        */
    private final DataFactory dataFactory;

    /*
    state
    */
    private FileUploadResource fileUploadResource;
    private UploadedFile file;
    private UploadedFile detailsFile;
    private final FileUploadRestClient restClient;
    private String encodedListPicture;
    private String encodedDetailsPicture;
    private StreamedContent fileToDisplay;
    private String validationError = "Validation Error ";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        this.fileUploadResource = FileUploadResource.builder().subject(NEWS)
                .extension(CommonViewModel.DEFAULT_PICTURE_EXTENSION).isNewFile(Boolean.TRUE)
                .isNewVideo(Boolean.TRUE).build();
    }

    public void save() {
        if (CommonViewModel.isValidUrl(fileUploadResource.getLink())) {
            fileUploadResource.setFile(encodedListPicture);
            fileUploadResource.setDetailsNewsPicture(encodedDetailsPicture);
            if (Objects.isNull(fileUploadResource.getFile()) || Objects.isNull(fileUploadResource.getDetailsNewsPicture())) {
                BoUtils.showErrorPopup(validationError, "Images are mandatory");
                return;
            }
            try {
                restClient.addItem(fileUploadResource);
                BoUtils.showsuccesspopup();
            } catch (RestBackendException e) {
                BoUtils.showErrorPopup(error, errorMessage);
            }
            dataFactory.redirect("news");
        } else {
            BoUtils.showErrorPopup(error, "Link invalid, News Link must be a valid URL");
        }

    }

    public void handleListPicture(FileUploadEvent fileUploadEvent) {
        file = fileUploadEvent.getFile();
        byte[] image = file.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error("An error has occured when uploading file : " + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (700 > height || width < 700) {
                BoUtils.showErrorPopup("Image ", "Kindly attach an image with 700 height and width");
            } else {
                encodedListPicture = Base64
                        .getEncoder()
                        .encodeToString(file.getContent());
                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
            }
        }
    }

    public void handleDetailsPicture(FileUploadEvent fileUploadEvent) {
        detailsFile = fileUploadEvent.getFile();
        byte[] image = detailsFile.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error("An error has occured when uploading file : " + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (height < 700 || width < 700) {
                BoUtils.showErrorPopup("Image ", "Kindly attach an image with 700 height and width");
            } else {
                encodedDetailsPicture = Base64
                        .getEncoder()
                        .encodeToString(detailsFile.getContent());
                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
            }
        }
    }

    public void clear() {
        init();
    }
}
