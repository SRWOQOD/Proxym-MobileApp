package com.woqod.content.viewmodel;

import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.service.PetrolService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.*;
import wq.woqod.resources.resources.FacilityStationResource;
import wq.woqod.resources.resources.ServiceStationResource;
import wq.woqod.resources.resources.StationResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Data
@Slf4j
@Component
@Scope("view")
public class ViewPetrolsViewModel {

    private final PetrolService petrolService;

    private StationResource stationResource;
    private List<ServiceStationResource> serviceStationResources;
    private List<FacilityStationResource> facilityStationResource;
    private List<ServiceNameEnum> serviceNameEnums;
    private List<ServiceStateEnum> serviceStateEnums;
    private List<StationCategoryEnum> stationCategoryEnums;
    private List<StationStatusEnum> stationStatusEnums;
    private List<FacilityNameEnum> facilityNameEnum;
    private List<FacilityNameEnum> selectedFacilities;
    private String petrolId;

    @Autowired
    public ViewPetrolsViewModel(PetrolService petrolService) {
        this.petrolService = petrolService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            petrolId = request.getParameter(ContentConstant.PETROL_ID);
            init();
        }
    }

    public List<FacilityNameEnum> getSelectedFacilities() {
        return selectedFacilities != null ? selectedFacilities : new ArrayList<>();
    }

    public void setSelectedFacilities(List<FacilityNameEnum> selectedFacilities) {
        this.selectedFacilities = selectedFacilities != null ? selectedFacilities : new ArrayList<>();
    }

    public void setSelectedFacilities() {
        for (FacilityStationResource facility : facilityStationResource) {
            selectedFacilities.add(facility.getName());
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.info("petrolId: ", petrolId);
        stationResource = new StationResource();
        facilityNameEnum = Arrays.asList(FacilityNameEnum.values());
        selectedFacilities = Arrays.asList(FacilityNameEnum.values());
        stationResource = petrolService.getPetrolStationById(petrolId);
        serviceStationResources = new ArrayList<>(stationResource.getServiceStations());
        facilityStationResource = new ArrayList<>(stationResource.getFacilityStations());
    }

    public String getDisplayPetrolsContentsFeature() {
        return MenuEnum.DISPLAY_PETROL_CONTENT.name();
    }

    public String getViewPetrolContentsFeature() {
        return MenuEnum.VIEW_PETROL_CONTENT.name();
    }

}
