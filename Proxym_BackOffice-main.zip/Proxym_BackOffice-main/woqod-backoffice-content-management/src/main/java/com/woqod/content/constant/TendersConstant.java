package com.woqod.content.constant;

public final class TendersConstant {
    private TendersConstant() {
    }

    public static final String CONTENT_TENDERS_MANAGEMENT_URL = "tenders";
    public static final String TENDERS_LIST = "listTenders";
    public static final String EDIT_TENDER = "editTender";
    public static final String EDIT_TENDER_URL = "tender/edit?id=";
    public static final String TENDERS_LAZY_MODEL = "TendersLazyModel";
    public static final String TENDERS = "tenders";
    public static final String TENDERS_CATEGORY = "categoryEnum";
    public static final String COLLECTIONDATE = "collectionDate";
    public static final String TENDERS_DESCRIPTION = "description";
    public static final String TENDERS_BOND = "bond";
    public static final String COLLECTION_DATE_FROM = "collectionDateFrom";
    public static final String COLLECTION_DATE_TO = "collectionDateTo";
    public static final String CLOSING_DATE_FROM = "closingDateFrom";
    public static final String CLOSING_DATE_TO = "closingDateTo";


}
