package com.woqod.content.constant;

public final class StationConstant {
    private StationConstant() {
    }

    public static final String STATION_URL = "/station";


    public static final String STATUS = "status";
    public static final String CATEGORY = "category";
    public static final String TITLE = "title";
    public static final String PHONE = "phone";
    public static final String ARABICNAME = "arabicName";
    public static final String STATIONS_LIST = "listStations";
    public static final String STATION_LAZY_MODEL = "StationLazyModel";
    public static final String STATIONS = "stations";
    public static final String STATION_REST_CLIENT = "StationRestTemplate";
    public static final String STATION_VIEW_MODEL = "[stationViewModel]";
    public static final String STATION_SERVICE_IMPL = "StationServiceImpl";


}
