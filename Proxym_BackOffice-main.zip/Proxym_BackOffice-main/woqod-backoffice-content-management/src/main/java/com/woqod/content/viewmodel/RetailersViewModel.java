package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.RetailersLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.RetailersService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.RetailersResource;

import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class RetailersViewModel {

    private final RetailersService retailersService;
    private final ContentService contentService;

    private RetailersResource retailersResource;
    private RetailersResource filteredretailersResource;
    private LazyDataModel<RetailersResource> lazyModel;


    @Autowired
    public RetailersViewModel(RetailersService retailersService, ContentService contentService) {
        this.retailersService = retailersService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        retailersResource = new RetailersResource();
        filteredretailersResource = new RetailersResource();
        lazyModel = new RetailersLazyModel(retailersService);
    }

    public void search() {

        Map<String, String> uriParams = new HashMap<>();

        if (filteredretailersResource.getRetailId() != null) {
            uriParams.put(ContentConstant.RETAILERS_ID, filteredretailersResource.getRetailId().toString());
        }

        if (filteredretailersResource.getTitle() != null) {
            uriParams.put(ContentConstant.RETAILERS_TITLE, filteredretailersResource.getTitle());
        }

        if (filteredretailersResource.getContactPerson() != null) {
            uriParams.put(ContentConstant.RETAILERS_CONTACT_PERSON, filteredretailersResource.getContactPerson());
        }


        ((RetailersLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filteredretailersResource = new RetailersResource();
        init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.RETAILERS);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());

        contentService.updateContentCategory(serviceData);
    }

    public String getDisplayRetailersFeature() {
        return MenuEnum.DISPLAY_RETAILERS_CONTENT.name();
    }


}
