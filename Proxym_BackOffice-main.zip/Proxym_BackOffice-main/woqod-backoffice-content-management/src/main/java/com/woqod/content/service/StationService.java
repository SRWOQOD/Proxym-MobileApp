package com.woqod.content.service;

import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.StationResource;

import java.util.HashMap;
import java.util.Map;

public interface StationService {
    PaginatedListResponse<StationResource> getPaginatedStations(Map<String, String> uriParams);

    BooleanResponse updateStationsServicesState(HashMap<String, Object> serviceData);
}
