package com.woqod.content.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.models.HomeBoModel;
import com.woqod.content.service.news.NewsService;
import com.woqod.content.viewmodel.news.NewsViewModel;
import com.woqod.home.viewmodel.topbanner.TopBannerViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.NewsResource;

import java.util.*;
import java.util.stream.Collectors;

@Data
@Slf4j
public class NewsLazyModel extends LazyDataModel<NewsResource> {
    private static final long serialVersionUID = 1;
    private final NewsService newsService;

    private Map<String, String> uriParams;

    public NewsLazyModel(NewsService newsService) {
        this.newsService = newsService;
        this.uriParams = new HashMap<>();
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        if (rowIndex == -1 || getPageSize() == 0) {
            super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % getPageSize());
        }
    }

    /**
     * used to get filtered and paginated data
     */
    @Override
    public List<NewsResource> load(final int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            PaginatedListResponse<NewsResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading("creationDate", SortOrder.DESCENDING, first, pageSize));
            response = newsService.getPaginatedList(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            Comparator<NewsResource> comparator = Comparator.comparing(NewsResource::getCreationDate).reversed();
            return response.getList().stream().sorted(comparator).collect(Collectors.toList());

        } catch (Exception e) {
            log.error("NewsLazyModel {}  ", UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA);
            return new ArrayList<>();
        }

    }
}