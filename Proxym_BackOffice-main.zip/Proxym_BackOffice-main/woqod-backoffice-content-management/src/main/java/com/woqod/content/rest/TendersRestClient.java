package com.woqod.content.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.TendersResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/tenders.properties")
public class TendersRestClient {
    private final CustomRestTemplate customRestTemplate;
    private BaseUrlProvider baseUrlProvider;
    private String tenders;

    @Autowired
    public TendersRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("tenders") String tenders) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.tenders = tenders;
    }

    public PaginatedListResponse<TendersResource> getPaginatedTenders(Map<String, String> uriParams) {
        String uri = tenders.concat("/filtred");
        return (PaginatedListResponse<TendersResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<TendersResource>>>() {
                        });
    }

    public boolean delete(String tenderID) {
        String uri = tenders + "/tender/" + tenderID;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public List<TendersResource> getTenders(Map<String, String> uriParams) {
        String uri = "/tenders/tenders";
        return ((ListResponse<TendersResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<TendersResource>>>() {
                        })).getList();


    }


}
