package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FahesResource;

import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class FahesContentRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String fahes;

    @Autowired
    public FahesContentRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.fahes}") String fahes) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.fahes = fahes;
    }

    public PaginatedListResponse<FahesResource> paginatedParams(Map<String, String> uriParams) {
        String uri = fahes.concat("/filtred");
        return (PaginatedListResponse<FahesResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<FahesResource>>>() {
                        });

    }
}
