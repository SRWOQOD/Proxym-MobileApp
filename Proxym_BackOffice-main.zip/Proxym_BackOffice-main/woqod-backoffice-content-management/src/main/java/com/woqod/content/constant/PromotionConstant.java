package com.woqod.content.constant;

public final class PromotionConstant {

    private PromotionConstant() {
    }

    public static final String PROMOTION_LIST = "listPromotions";
    public static final String PROMOTION_LAZY_MODEL = "PromotionLazyModel";
    public static final String PROMOTIONS = "promotions";
    public static final String BUNDLE_NAME = "content_messages";
    public static final String CONTENT_PROMOTOINS_MANAGEMENT_URL = "/promotion";
    public static final String DELETE_PROMOTION_URL = "/promotion/delete";
    public static final String EXPORT_PROMOTION_URL = "/promotion/export";
    public static final String EDIT_PROMOTION_URL = "promotion/edit?id=";
    public static final String EDIT_PROMOTION = "editPromotion";
    public static final String PROMOTIONID = "id";
    public static final String PROMOTION_ID = "promotionsId";
    public static final String PROMOTION_TITLE = "title";
    public static final String PROMOTION_DESCRIPTION = "description";

}
