package com.woqod.content.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping(value = ContentConstant.CONTENT_MANAGEMENT_URL)
@Data
public class ContentController {
    private final Permissions permissions;

    @Autowired
    public ContentController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_CONTENTS.name(), ContentConstant.CONTENT_LIST);
    }

    @GetMapping("/retailers")
    public ModelAndView displayRetl() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_RETAILERS_CONTENT.name(), ContentConstant.CONTENT_RETAILERS);
    }

    @GetMapping("/supermarket")
    public ModelAndView displaySuper() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_SUPERMARKET_CONTENT.name(), ContentConstant.CONTENT_SUPERMARKET);
    }

    @GetMapping("/fahes")
    public ModelAndView displayFahes() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_FAHES_CONTENT.name(), ContentConstant.CONTENT_FAHES);
    }

    @GetMapping("/prices")
    public ModelAndView displayPrices() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_PRICES_CONTENT.name(), ContentConstant.CONTENT_PRICES);
    }

    @GetMapping("/promotion")
    public ModelAndView displayPromotion() {
        return new ModelAndView("redirect:/promotion");
    }

    @GetMapping("/station")
    public ModelAndView displayPetrol() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_PETROL_CONTENT.name(), ContentConstant.CONTENT_PETROL);
    }

    @GetMapping("/station/view")
    public ModelAndView viewPetrolStation() {
        return permissions.getModelAndView(MenuEnum.VIEW_PETROL_CONTENT.name(), ContentConstant.CONTENT_VIEW_PETROL);
    }

    @GetMapping("/tenders")
    public ModelAndView viewTenders() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_TENDERS.name(), ContentConstant.CONTENT_TENDERS);
    }

    @GetMapping("/stockprices")
    public ModelAndView viewStockPrices() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_STOCK_PRICES.name(), ContentConstant.CONTENT_STOCK_PRICES);
    }
}
