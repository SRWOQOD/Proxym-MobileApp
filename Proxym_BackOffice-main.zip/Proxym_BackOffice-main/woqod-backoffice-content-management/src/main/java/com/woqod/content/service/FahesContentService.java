package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FahesResource;

import java.util.Map;

public interface FahesContentService {

    PaginatedListResponse<FahesResource> getPaginatedFahes(Map<String, String> uriParams);

}
