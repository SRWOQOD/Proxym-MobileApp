package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.PricesLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.PricesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.*;
import wq.woqod.resources.resources.PetrolResource;

import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class PricesViewModel {

    private final PricesService pricesService;
    private final ContentService contentService;

    private PetrolResource petrolResource;
    private PetrolResource filterpetrolResource;
    private LazyDataModel<PetrolResource> lazyModel;
    private List<PetrolResource> list;


    @Autowired
    public PricesViewModel(ContentService contentService, PricesService pricesService) {
        this.pricesService = pricesService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        petrolResource = new PetrolResource();
        filterpetrolResource = new PetrolResource();
        list = pricesService.getList();
        lazyModel = new PricesLazyModel(pricesService);
    }

    public void search() {
        Map<String, String> uriParams = new HashMap<>();

        if (filterpetrolResource.getName() != null) {
            uriParams.put(ContentConstant.PETROL_NAME, filterpetrolResource.getName());
        }

        if (filterpetrolResource.getPrice() != null) {
            uriParams.put(ContentConstant.PETROL_PRICE, filterpetrolResource.getPrice().toString());
        }

        if (filterpetrolResource.getArabicName() != null && !filterpetrolResource.getArabicName().isEmpty()) {
            uriParams.put(ContentConstant.PETROL_ARABIC_NAME, filterpetrolResource.getArabicName());
        }
        ((PricesLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filterpetrolResource = new PetrolResource();
        init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.PRICES);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());

        contentService.updateContentCategory(serviceData);
    }

    public String getDisplayPricesFeature() {
        return MenuEnum.DISPLAY_PRICES_CONTENT.name();
    }


}
