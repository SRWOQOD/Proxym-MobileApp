package com.woqod.content.service;

import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.rest.ContentRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.ContentInfoResource;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Service
public class ContentServiceImpl implements ContentService {

    private final ContentRestClient contentRestClient;

    @Autowired
    public ContentServiceImpl(ContentRestClient contentRestClient) {
        this.contentRestClient = contentRestClient;
    }

    @Override
    public List<ContentInfoResource> getAllContents() {
        return contentRestClient.getAllContents();
    }

    @Override
    public List<AreaResource> getAllAreas() {
        return contentRestClient.getArea().getList();
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public ContentInfoResource updateContentsInfoByCategory(HashMap<String, Object> serviceData) {
        ContentCategoryEnum category = (ContentCategoryEnum) serviceData.get(UtilsConstants.POST_DATA);
        return contentRestClient.updateContentsInfoByCategory(String.valueOf(category));
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void updateContentCategory(HashMap<String, Object> serviceData) {
        ContentCategoryEnum category = (ContentCategoryEnum) serviceData.get(UtilsConstants.POST_DATA);
        contentRestClient.updateContentsByCategory(category);
    }

    @Override
    public void updateAllContent() {
        contentRestClient.updateAllContent();
    }
}
