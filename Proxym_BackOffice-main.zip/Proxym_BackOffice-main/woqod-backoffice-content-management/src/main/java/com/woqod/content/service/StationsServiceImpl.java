package com.woqod.content.service;

import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.rest.StationsRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.StationUpdateResources;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class StationsServiceImpl implements StationService {

    private final StationsRestTemplate stationsRestTemplate;

    @Autowired
    public StationsServiceImpl(StationsRestTemplate stationsRestTemplate) {
        this.stationsRestTemplate = stationsRestTemplate;
    }

    @Override
    public PaginatedListResponse getPaginatedStations(Map<String, String> uriParams) {
        return stationsRestTemplate.paginatedParams(uriParams);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public BooleanResponse updateStationsServicesState(HashMap<String, Object> serviceData) {
        StationUpdateResources stationUpdateResources = (StationUpdateResources) serviceData.get(UtilsConstants.POST_DATA);

        return stationsRestTemplate.updateStationsServicesState(stationUpdateResources);
    }
}
