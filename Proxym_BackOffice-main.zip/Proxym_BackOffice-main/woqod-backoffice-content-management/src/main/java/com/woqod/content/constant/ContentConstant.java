package com.woqod.content.constant;

public final class ContentConstant {
    public static final String CONTENT_MANAGEMENT_URL = "/contents";
    public static final String SUB_CONTENT_MANAGEMENT_URL = "contents";
    public static final String CONTENT_MANAGEMENT_URL_RETAILERS = "contents/retailers";
    public static final String VIEW_PETROL_URL = "contents/station/view?id=";
    public static final String CONTENT_LIST = "listContents";
    public static final String CONTENT_RETAILERS = "listRetailers";
    public static final String CONTENT_SUPERMARKET = "listSupermarkets";
    public static final String CONTENT_FAHES = "listFahes";
    public static final String CONTENT_PRICES = "listPrices";
    public static final String CONTENT_STOCK_PRICES = "listStockPrices";
    public static final String CONTENT_PETROL = "listPetrols";
    public static final String CONTENT_VIEW_PETROL = "viewPetrol";
    public static final String CONTENT_TENDERS = "listTenders";
    public static final String RETAILERS_LAZY_MODEL = "RetailersLazyModel";
    public static final String RETAILERS = "Retailers";
    public static final String PETROL_ID = "id";

    public static final String RETAILERS_ID = "retailId";
    public static final String RETAILERS_TITLE = "title";
    public static final String RETAILERS_CONTACT_PERSON = "contactPerson";

    public static final String SUPERMARKET_ID = "marketId";
    public static final String SUPERMARKET_TITLE = "title";
    public static final String SUPERMARKET_CONTACT_PERSON = "contactPerson";

    public static final String PETROL_NAME = "name";
    public static final String PETROL_PRICE = "price";
    public static final String PETROL_ARABIC_NAME = "arabicName";

    public static final String STOCK_PRICES_VOLUME = "volume";
    public static final String STOCK_PRICES_MARKET_NAME = "marketName";
    public static final String STOCK_PRICES_SYNC_DATE = "dateStock";

    public static final String FAHES_TITLE = "title";
    public static final String FAHES_PHONE = "phone";
    public static final String FAHES_STATUS = "status";

    public static final String STATION_TITLE = "title";
    public static final String STATION_STATUS = "status";

    public static final String BUNDLE_NAME = "content_messages";


    //NEWS
    public static final String NEWS_BUNDLE_NAME = "news_messages";
    public static final String NEWS_MANAGEMENT_URL = "/news";
    public static final String NEWS_LIST = "news/listnews";
    public static final String ADD_NEWS_URL = "/news/add";
    public static final String EDIT_NEWS_URL = "/news/edit";
    public static final String VIEW_URL = "news/view?id=";
    public static final String EDIT_URL = "news/edit?id=";
    public static final String ADD_URL = "news/add";
    public static final String ADD_VIEW = "news/addNews";
    public static final String EDIT_VIEW = "news/editNews";
    public static final String NEWS_ID = "id";
    public static final String BACK_NEWS_URL = "news";

    private ContentConstant() {

        // content constant
    }
}
