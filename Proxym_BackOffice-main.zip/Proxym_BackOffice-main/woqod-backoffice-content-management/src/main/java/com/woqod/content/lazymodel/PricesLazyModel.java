package com.woqod.content.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.service.PricesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.PetrolResource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class PricesLazyModel extends LazyDataModel<PetrolResource> {
    private final PricesService pricesService;
    private static final long serialVersionUID = 1;
    private Map<String, String> uriParams;

    public PricesLazyModel(PricesService pricesService) {
        this.pricesService = pricesService;
        this.uriParams = new HashMap<>();
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtred and paginated data
     */
    @Override
    public List<PetrolResource> load(final int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            PaginatedListResponse<PetrolResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading("date", SortOrder.DESCENDING, first, pageSize));
            response = pricesService.getPaginatedPetrolPrices(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", ContentConstant.RETAILERS_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, ContentConstant.RETAILERS);
            return new ArrayList<>();
        }

    }
}
