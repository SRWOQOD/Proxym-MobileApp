package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.PetrolRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.StationResource;

import java.util.Map;

@Slf4j
@Service
public class PetrolServiceImpl implements PetrolService {

    private final PetrolRestClient petrolRestClient;

    @Autowired
    public PetrolServiceImpl(PetrolRestClient petrolRestClient) {
        this.petrolRestClient = petrolRestClient;
    }

    public PaginatedListResponse getPaginatedPetrols(Map<String, String> uriParams) {
        return petrolRestClient.paginatedParams(uriParams);
    }

    @Override
    public StationResource getPetrolStationById(String petrolId) {
        return petrolRestClient.getPetrolStationById(petrolId);
    }

}
