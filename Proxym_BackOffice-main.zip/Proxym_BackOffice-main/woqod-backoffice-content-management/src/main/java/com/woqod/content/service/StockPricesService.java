package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.StockPricesRessource;

import java.util.List;
import java.util.Map;

public interface StockPricesService {

    PaginatedListResponse<StockPricesRessource> getPaginatedStockPrices(Map<String, String> uriParams);

    List<StockPricesRessource> getList();

}
