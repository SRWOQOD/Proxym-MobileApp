package com.woqod.content.service.news;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.NewsRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.NewsResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class NewsServiceImpl implements NewsService {

    private final NewsRestClient newsRestClient;

    @Autowired
    public NewsServiceImpl(NewsRestClient newsRestClient) {
        this.newsRestClient = newsRestClient;
    }


    @Override
    public void save(NewsResource newsResource) {
        newsRestClient.save(newsResource);
    }

    @Override
    public PaginatedListResponse<NewsResource> getPaginatedList(Map<String, String> uriParams) {
        return newsRestClient.paginatedParams(uriParams);
    }

    @Override
    public NewsResource getById(String newsId) {
        return newsRestClient.getNewsById(newsId);
    }

    @Override
    public void update(List<NewsResource> activeNews) {
        newsRestClient.update(activeNews);
    }

    @Override
    public void update(NewsResource newsResource) {
        newsRestClient.update(newsResource);
    }

    @Override
    public Integer count() {
        return newsRestClient.count();
    }
    @Override
    public void delete(String id) {
        newsRestClient.delete(id);
    }


}
