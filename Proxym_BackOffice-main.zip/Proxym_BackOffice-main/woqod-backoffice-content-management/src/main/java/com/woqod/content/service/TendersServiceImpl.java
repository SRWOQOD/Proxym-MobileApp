package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.rest.TendersRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.TendersResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class TendersServiceImpl implements TendersService {

    private final TendersRestClient tendersRestClient;

    @Autowired
    public TendersServiceImpl(TendersRestClient tendersRestClient) {
        this.tendersRestClient = tendersRestClient;
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void deleteTender(Map<String, Object> serviceData) {
        String tenderID = (String) serviceData.get(UtilsConstants.POST_DATA);
        tendersRestClient.delete(tenderID);
    }

    @Override
    public PaginatedListResponse getPaginatedTenders(Map<String, String> uriParams) {
        return tendersRestClient.getPaginatedTenders(uriParams);
    }

    @Override
    public List<TendersResource> tenders(Map<String, String> uriParams) {
        return tendersRestClient.getTenders(uriParams);
    }
}
