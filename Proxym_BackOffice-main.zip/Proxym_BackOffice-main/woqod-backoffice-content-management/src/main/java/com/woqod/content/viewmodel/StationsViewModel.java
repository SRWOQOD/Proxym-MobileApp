package com.woqod.content.viewmodel;


import com.woqod.bo.commons.security.Permissions;
import com.woqod.content.constant.StationConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.StationLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.StationService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ServiceNameEnum;
import wq.woqod.resources.enumerations.ServiceStateEnum;
import wq.woqod.resources.enumerations.StationCategoryEnum;
import wq.woqod.resources.enumerations.StationStatusEnum;
import wq.woqod.resources.resources.*;

import javax.faces.context.FacesContext;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class StationsViewModel {
    /*
   Beans
    */
    private final StationService stationService;
    private final ContentService contentService;

    /*
    state
    */
    private StationResource filterStationResource;
    private StationResource stationResource;
    private List<ServiceNameEnum> serviceNameEnums;
    private List<ServiceStateEnum> serviceStateEnums;
    private List<StationCategoryEnum> stationCategoryEnums;
    private Set<StationStatusEnum> stationStatusEnums;
    private LazyDataModel<StationResource> lazyModel;
    private List<AreaResource> areaResources;

    private final Permissions permissions;
    private String nextEnum;
    private StationUpdateResources stationUpdateResources;
    private Map<Long, StationUpdateResources> stationUpdateResourcesHashMap = new HashMap<>();


    @Autowired
    public StationsViewModel(StationService stationService, ContentService contentService, Permissions permissions) {
        this.stationService = stationService;
        this.contentService = contentService;
        this.permissions = permissions;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        stationCategoryEnums = Arrays.asList(StationCategoryEnum.values());
        stationStatusEnums = new HashSet<>(Arrays.asList(StationStatusEnum.values()));
        serviceNameEnums = Arrays.asList(ServiceNameEnum.values());
        serviceStateEnums = Arrays.asList(ServiceStateEnum.values());
        lazyModel = new StationLazyModel(stationService);
        stationResource = new StationResource();
        areaResources = contentService.getAllAreas();
        filterStationResource = new StationResource();
        filterStationResource.setStatus(null);
    }

    public void clear() {
        filterStationResource = new StationResource();
        init();
        search();
    }

    public void search() {
        log.debug("{} search", StationConstant.STATION_VIEW_MODEL);
        Map<String, String> uriParams = new HashMap<>();
        if (filterStationResource.getCategory() != null) {
            uriParams.put(StationConstant.CATEGORY, filterStationResource.getCategory().name());
        }

        if (filterStationResource.getTitle() != null) {
            uriParams.put(StationConstant.TITLE, filterStationResource.getTitle().trim());
        }

        uriParams.put(StationConstant.PHONE, filterStationResource.getPhone());
        if (filterStationResource.getStatus() != null) {
            uriParams.put(StationConstant.STATUS, filterStationResource.getStatus().name());
        }
        uriParams.put(StationConstant.ARABICNAME, filterStationResource.getArabicName());
        ((StationLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public String getDisplayStationFeature() {
        return MenuEnum.DISPLAY_STATIONS.name();
    }


    public Boolean indexOfService(String service, StationResource station) {
        boolean resp = false;
        for (ServiceStationResource serviceStationResource : station.getServiceStations()
        ) {
            if (serviceStationResource.getName().name().equals(service)) {
                resp = true;
            }
        }
        return resp;
    }

    public String stateOfService(String service, StationResource station) {
        for (ServiceStationResource serviceStationResource : station.getServiceStations()) {
            if (serviceStationResource.getName().name().equals(service)) {
                return serviceStationResource.getState().toString();
            }
        }
        return "";
    }


    public void changeListener(StationResource stationResource, String service) {
        if (stationUpdateResourcesHashMap.get(stationResource.getStationId()) == null) {
            stationUpdateResourcesHashMap.put(stationResource.getStationId(), new StationUpdateResources());
        }

        stationUpdateResources = stationUpdateResourcesHashMap.get(stationResource.getStationId());
        List<StationUpdateResource> stationUpdateResourceList = new ArrayList<>();
        StationUpdateResource tmp = new StationUpdateResource();
        Map<Long, ServiceStateEnum> services = new HashMap<>();


        for (ServiceStationResource rs : stationResource.getServiceStations()) {
            if (rs.getName().toString().equals(service)) {
                rs.setState(ServiceStateEnum.valueOf(nextEnum));
            }


            tmp.setStationId(stationResource.getStationId());
            services.put(rs.getId(), rs.getState());
            tmp.setServices(services);

            stationUpdateResourceList.add(tmp);
        }

        stationUpdateResources.setStationId(stationResource.getStationId());
        stationUpdateResources.setStationUpdateResources(stationUpdateResourceList);


        stationUpdateResourcesHashMap.put(tmp.getStationId(), stationUpdateResources);

        log.info("sending to update : " + stationResource);
    }

    public List<ServiceStateEnum> getwithoutthis(String service) {
        List<ServiceStateEnum> tmp = new ArrayList<>(serviceStateEnums);
        tmp.remove(ServiceStateEnum.valueOf(service));
        return tmp;
    }

}
