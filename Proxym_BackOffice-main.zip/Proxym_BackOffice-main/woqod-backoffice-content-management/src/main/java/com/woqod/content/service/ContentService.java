package com.woqod.content.service;

import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.ContentInfoResource;

import java.util.HashMap;
import java.util.List;

public interface ContentService {

    List<ContentInfoResource> getAllContents();

    List<AreaResource> getAllAreas();

    ContentInfoResource updateContentsInfoByCategory(HashMap<String, Object> serviceData);

    void updateContentCategory(HashMap<String, Object> serviceData);

    void updateAllContent();
}
