package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.RetailersRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
public class RetailersServiceImpl implements RetailersService {

    private final RetailersRestClient retailersRestClient;

    @Autowired
    public RetailersServiceImpl(RetailersRestClient retailersRestClient) {
        this.retailersRestClient = retailersRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedRetailers(Map<String, String> uriParams) {
        return retailersRestClient.paginatedParams(uriParams);
    }

}
