package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.SuperMarketResource;

import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class SupermarketRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String supermarkets;

    @Autowired
    public SupermarketRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.supermarkets}") String supermarkets) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.supermarkets = supermarkets;
    }

    public PaginatedListResponse<SuperMarketResource> paginatedParams(Map<String, String> uriParams) {
        String uri = supermarkets.concat("/filtred");
        return (PaginatedListResponse<SuperMarketResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<SuperMarketResource>>>() {
                        });
    }
}
