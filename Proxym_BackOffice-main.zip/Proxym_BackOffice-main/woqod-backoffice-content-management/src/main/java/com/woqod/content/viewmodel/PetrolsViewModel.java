package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.PetrolLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.PetrolService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.*;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.ServiceStationResource;
import wq.woqod.resources.resources.StationResource;

import javax.faces.context.FacesContext;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class PetrolsViewModel {

    private final PetrolService petrolService;
    private final ContentService contentService;

    private StationResource stationResource;
    private StationResource filterstationResource;
    private LazyDataModel<StationResource> lazyModel;
    private List<ServiceNameEnum> serviceNameEnums;
    private List<AreaResource> areaResources;
    private List<ServiceStateEnum> serviceStateEnums;
    private List<StationCategoryEnum> stationCategoryEnums;
    private List<StationStatusEnum> stationStatusEnums;
    private String nextEnum;
    private String areaId;


    @Autowired
    public PetrolsViewModel(PetrolService petrolService, ContentService contentService) {
        this.petrolService = petrolService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        areaId = "";
        stationResource = new StationResource();
        filterstationResource = new StationResource();
        stationCategoryEnums = Arrays.asList(StationCategoryEnum.values());
        stationStatusEnums = Arrays.asList(StationStatusEnum.values());
        serviceNameEnums = Arrays.asList(ServiceNameEnum.values());
        serviceStateEnums = Arrays.asList(ServiceStateEnum.values());
        areaResources = contentService.getAllAreas();
        lazyModel = new PetrolLazyModel(petrolService);
    }

    public String viewPetrolStation(Long id) {
        log.info("id: ", id);
        return ContentConstant.VIEW_PETROL_URL.concat(String.valueOf(id));
    }

    public void search() {
        Map<String, String> uriParams = new HashMap<>();

        if (filterstationResource.getTitle() != null) {
            uriParams.put(ContentConstant.STATION_TITLE, filterstationResource.getTitle());
        }

        if (filterstationResource.getStatus() != null) {
            uriParams.put(ContentConstant.STATION_STATUS, filterstationResource.getStatus().name());
        }

        if (filterstationResource.getPetrolCategory() != null) {
            uriParams.put("categoryp", filterstationResource.getPetrolCategory());
        }

        if (filterstationResource.getCategory() != null) {
            uriParams.put("category", String.valueOf(filterstationResource.getCategory()));
        }

        if (areaId != null && !areaId.isEmpty()) {
            uriParams.put("areaId", areaId);
        }

        ((PetrolLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filterstationResource = new StationResource();
        this.init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.PETROL);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());
        contentService.updateContentCategory(serviceData);
    }

    public String getDisplayPetrolsContentsFeature() {
        return MenuEnum.DISPLAY_PETROL_CONTENT.name();
    }

    public Boolean indexOfService(String service, StationResource station) {
        boolean resp = false;
        for (ServiceStationResource serviceStationResource : station.getServiceStations()
        ) {
            if (serviceStationResource.getName().name().equals(service)) {
                resp = true;
            }
        }
        return resp;
    }

    public String stateOfService(String service, StationResource station) {
        for (ServiceStationResource serviceStationResource : station.getServiceStations()) {
            if (serviceStationResource.getName().name().equals(service)) {
                return serviceStationResource.getState().toString();
            }
        }
        return "";
    }

    public List<ServiceStateEnum> getwithoutthis(String service) {
        List<ServiceStateEnum> tmp = new ArrayList<>(serviceStateEnums);
        tmp.remove(ServiceStateEnum.valueOf(service));
        return tmp;
    }

    public static boolean isEmptyMap(Map<?, ?> map) {
        return map.isEmpty();
    }

    public Double calculateRating(Double ratingSum, Long ratedBy) {
        if (ratingSum != null) {
            return Double.valueOf(String.format("%.2f", ratingSum / ratedBy));
        } else {
            return (double) 0;
        }
    }

    public String getViewPetrolContentsFeature() {
        return MenuEnum.VIEW_PETROL_CONTENT.name();
    }
}
