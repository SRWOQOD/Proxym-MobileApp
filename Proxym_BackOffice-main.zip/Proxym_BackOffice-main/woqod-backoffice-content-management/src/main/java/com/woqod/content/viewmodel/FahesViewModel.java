package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.FahesLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.FahesContentService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.FahesResource;

import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class FahesViewModel {

    private final FahesContentService fahesService;
    private final ContentService contentService;
    private FahesResource fahesResource;
    private FahesResource filtredfahesResource;
    private LazyDataModel<FahesResource> lazyModel;
    private List<AreaResource> areaResources;
    private String areaId;


    @Autowired
    public FahesViewModel(FahesContentService fahesService, ContentService contentService) {
        this.fahesService = fahesService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        areaId = "";
        fahesResource = new FahesResource();
        filtredfahesResource = new FahesResource();
        areaResources = contentService.getAllAreas();
        lazyModel = new FahesLazyModel(fahesService);
    }

    public void search() {
        Map<String, String> uriParams = new HashMap<>();

        if (filtredfahesResource.getTitle() != null) {
            uriParams.put(ContentConstant.FAHES_TITLE, filtredfahesResource.getTitle());
        }

        if (filtredfahesResource.getPhone() != null) {
            uriParams.put(ContentConstant.FAHES_PHONE, filtredfahesResource.getPhone());
        }

        if (filtredfahesResource.getStatus() != null) {
            uriParams.put(ContentConstant.FAHES_STATUS, filtredfahesResource.getStatus());
        }
        if (areaId != null && !areaId.isEmpty()) {
            uriParams.put("areaId", areaId);
        }
        ((FahesLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filtredfahesResource = new FahesResource();
        init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.FAHES);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());

        contentService.updateContentCategory(serviceData);
    }

    public String getDisplayFahesFeature() {
        return MenuEnum.DISPLAY_FAHES_CONTENT.name();
    }


}
