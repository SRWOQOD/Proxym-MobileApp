package com.woqod.content.enums;


import com.woqod.bo.commons.enums.*;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.constant.PromotionConstant;
import com.woqod.content.constant.TendersConstant;
import com.woqod.home.constatnt.HomeConstant;
import com.woqod.text.constatnt.TextConstant;

import java.util.Arrays;
import java.util.Optional;


public enum MenuEnum implements Menu {

    DISPLAY_CONTENTS(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayContents"),
            ContentConstant.CONTENT_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    DISPLAY_RETAILERS_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayRetailers"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    DISPLAY_SUPERMARKET_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "DisplaySupermarket"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    DISPLAY_FAHES_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayFahes"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    DISPLAY_PRICES_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayPrices"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 5L)),
    DISPLAY_PETROL_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayPetrol"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 6L)),
    DISPLAY_STATIONS(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayStations"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    DISPLAY_STOCK_PRICES(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayStockPrices"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 8L)),

    VIEW_PETROL_CONTENT(new Bundle(ContentConstant.BUNDLE_NAME, "ViewPetrol"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 7L)),

    DISPLAY_PROMOTIONS(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayPromotions"), PromotionConstant.CONTENT_PROMOTOINS_MANAGEMENT_URL,
            "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    EDIT_PROMOTION(new Bundle(ContentConstant.BUNDLE_NAME, "EditPromotion"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    DELETE_PROMOTION(new Bundle(ContentConstant.BUNDLE_NAME, "DeletePromotion"), PromotionConstant.DELETE_PROMOTION_URL, "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    EXPORT_PROMOTIONS(new Bundle(ContentConstant.BUNDLE_NAME, "ExportPromotion"), PromotionConstant.EXPORT_PROMOTION_URL, "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 4L)),

    DISPLAY_TENDERS(new Bundle(ContentConstant.BUNDLE_NAME, "DisplayTenders"), TendersConstant.CONTENT_TENDERS_MANAGEMENT_URL, "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 5L)),
    EDIT_TENDER(new Bundle(ContentConstant.BUNDLE_NAME, "EditTender"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    DELETE_TENDER(new Bundle(ContentConstant.BUNDLE_NAME, "DeleteTender"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    EXPORT_TENDERS(new Bundle(ContentConstant.BUNDLE_NAME, "ExportTender"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    UPDATE_CONTENT_CATEGORY(new Bundle(ContentConstant.BUNDLE_NAME, "updateContentCategory"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 5L)),

    UPDATE_CONTENT_INFO(new Bundle(ContentConstant.BUNDLE_NAME, "updateContentInfo"), "", "", "", true, DISPLAY_CONTENTS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 6L)),


    DISPLAY_NEWS(new Bundle(ContentConstant.NEWS_BUNDLE_NAME, "DisplayNews"),
            ContentConstant.NEWS_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ADD_NEWS(new Bundle(ContentConstant.BUNDLE_NAME, "addTopNews"),
            ContentConstant.ADD_NEWS_URL, "", "", true,
            DISPLAY_NEWS.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),

    EDIT_NEWS(new Bundle(ContentConstant.BUNDLE_NAME, "editTpBanner"),
            ContentConstant.EDIT_NEWS_URL, "", "", true,
            DISPLAY_NEWS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),

    ADS_BANNER(new Bundle(ContentConstant.BUNDLE_NAME, "adsbannerbundle"),
            HomeConstant.ADS_BANNER_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 2L)),

    EDIT_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editAdsBanner"), "", "", "", true,
            ADS_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    ADD_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addAdsBanner"), HomeConstant.ADD_ADS_PATH, "", "", true,
            ADS_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),

    TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "topBanner"),
            HomeConstant.TOP_BANNER_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ADD_TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addTopBanner"), HomeConstant.ADD_TOP_BANNER_MANAGEMENT_URL, "", "", true,
            TOP_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    EDIT_TOP_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editTpBanner"), HomeConstant.ADD_TOP_BANNER_MANAGEMENT_URL, "", "", true,
            TOP_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),

    BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "businessBanner"),
            HomeConstant.BUSINESS_BANNER_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ADD_BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "addbusinessBanner"), HomeConstant.ADD_BUSINESS_BANNER_MANAGEMENT_URL, "", "", true,
            BUSINESS_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    EDIT_BUSINESS_BANNER(new Bundle(HomeConstant.BUNDLE_NAME, "editbusinessBanner"), HomeConstant.EDIT_BUSINESS_URL, "", "", true,
            BUSINESS_BANNER.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),

    APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "apptips"),
            HomeConstant.APP_TIPS_MANAGEMENT_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ADD_APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "addAppTips"), HomeConstant.ADD_APP_TIPS_URL, "", "", true,
            APP_TIPS.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    EDIT_APP_TIPS(new Bundle(HomeConstant.BUNDLE_NAME, "editAppTips"), HomeConstant.EDIT_APP_TIPS_URL, "", "", true,
            APP_TIPS.name(),
            new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    ABOUT_WOQODE(new Bundle(TextConstant.BUNDLE_NAME, "about_woqode"),
            TextConstant.ABOUT_WOQODE_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    TERMS_AND_CONDITIONS(new Bundle(TextConstant.BUNDLE_NAME, "terms_and_conditions"),
            TextConstant.TERMS_AND_CONDITIONS_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 2L)),

    ABOUT_WOQOD(new Bundle(TextConstant.BUNDLE_NAME, "about_us"),
            TextConstant.ABOUT_WOQOD_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    BUKLPG(new Bundle(TextConstant.BUNDLE_NAME, "buklpg"),
            TextConstant.BUKLPG_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ABOUT_FAHES(new Bundle(TextConstant.BUNDLE_NAME, "about_fahes"),
            TextConstant.ABOUT_FAHES_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    ABOUT_SHAHAF(new Bundle(TextConstant.BUNDLE_NAME, "about_shahaf"),
            TextConstant.ABOUT_SHAHAF_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    INSCRIPTION_TIPS(new Bundle(TextConstant.BUNDLE_NAME, "inscription_tips"),
            TextConstant.INSCRIPTION_TIPS_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    PRIVACY_POLICY(new Bundle(TextConstant.BUNDLE_NAME, "privacy_policy"),
            TextConstant.PRIVACY_POLICY_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

    TERMS_AND_CONDITIONS_PAYMENT_FAHES(new Bundle(TextConstant.BUNDLE_NAME, "terms_of_use_fahes"),
            TextConstant.TERMS_AND_CONDITIONS_PAYMENT_FAHES_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),

/*
    TERMS_AND_CONDITIONS_PAYMENT_WOQOD(new Bundle(TextConstant.BUNDLE_NAME, "terms_of_use_woqod"),
            TextConstant.TERMS_AND_CONDITIONS_PAYMENT_WOQOD_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
*/

    TERMS_OF_USE(new Bundle(TextConstant.BUNDLE_NAME, "terms_of_use"),
            TextConstant.TERMS_OF_USE_URL, "", "", true,
            ParentModuleEnum.CONTENT_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),


    ;

    MenuEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }

}
