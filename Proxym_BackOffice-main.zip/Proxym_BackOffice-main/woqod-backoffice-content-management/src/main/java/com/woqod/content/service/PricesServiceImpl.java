package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.PricesRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.PetrolResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class PricesServiceImpl implements PricesService {

    private final PricesRestClient pricesRestClient;

    @Autowired
    public PricesServiceImpl(PricesRestClient pricesRestClient) {
        this.pricesRestClient = pricesRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedPetrolPrices(Map<String, String> uriParams) {
        return pricesRestClient.paginatedParams(uriParams);
    }

    @Override
    public List<PetrolResource> getList() {
        return pricesRestClient.getList();
    }
}
