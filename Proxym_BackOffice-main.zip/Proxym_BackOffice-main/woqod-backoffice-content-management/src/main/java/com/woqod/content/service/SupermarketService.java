package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.SuperMarketResource;

import java.util.Map;

public interface SupermarketService {

    PaginatedListResponse<SuperMarketResource> getPaginatedSupermarkets(Map<String, String> uriParams);

}
