package com.woqod.content.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping(value = ContentConstant.NEWS_MANAGEMENT_URL)
@Data
public class NewsController {
    private final Permissions permissions;

    @Autowired
    public NewsController(Permissions permissions) {
        this.permissions = permissions;

    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_NEWS.name(), ContentConstant.NEWS_LIST);
    }

    /**
     * used to display add news view
     */
    @GetMapping("/add")
    public ModelAndView addDisplay() {
        return permissions.getModelAndView(MenuEnum.ADD_NEWS.name(), ContentConstant.ADD_VIEW);
    }

    @GetMapping("/edit")
    public ModelAndView updateDisplay() {
        return permissions.getModelAndView(MenuEnum.EDIT_NEWS.name(), ContentConstant.EDIT_VIEW);
    }
}
