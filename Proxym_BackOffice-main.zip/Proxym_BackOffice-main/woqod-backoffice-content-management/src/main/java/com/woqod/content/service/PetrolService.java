package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.StationResource;

import java.util.Map;

public interface PetrolService {

    PaginatedListResponse<StationResource> getPaginatedPetrols(Map<String, String> uriParams);

    StationResource getPetrolStationById(String petrolId);
}
