package com.woqod.content.viewmodel.news;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.content.rest.FileUploadRestClient;
import com.woqod.content.service.news.NewsService;
import com.woqod.home.viewmodel.common.CommonViewModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.resources.FileUploadResource;
import wq.woqod.resources.resources.NewsResource;

import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.woqod.content.constant.ContentConstant.BACK_NEWS_URL;
import static com.woqod.content.constant.ContentConstant.NEWS_ID;
import static wq.woqod.resources.enumerations.FileSubjectEnum.NEWS;

@Data
@Slf4j
@Component
@Scope("view")
public class EditNewsViewModel extends CommonViewModel{
    /*
    Beans
     */
    private final NewsService newsService;
    private final DataFactory dataFactory;

    /*
   state
    */
    private String newsId;
    private List<String> oerderList;
    private NewsResource oldNewsResource;
    private List<NewsResource> activeNews;
    private Map<String, String> uriParams;
    private FileUploadResource fileUploadResource;
    private UploadedFile file;
    private UploadedFile detailsFile;
    private String encodedListPicture;
    private String encodedDetailsPicture;
    private final FileUploadRestClient restClient;
    private Boolean isNewPicture;
    private Boolean isNewPictureDetail;
    private String validationError = "Validation Error ";
    private String error = "Error ";
    private String errorMessage = "An error has occurred , Please try later";


    @Autowired
    public EditNewsViewModel(NewsService newsService, DataFactory dataFactory, FileUploadRestClient restClient) {
        this.newsService = newsService;
        this.dataFactory = dataFactory;
        this.restClient = restClient;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            newsId = request.getParameter(NEWS_ID);
            oldNewsResource = newsService.getById(newsId);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        //copy object vales's in other object
        uriParams = new HashMap<>();
        uriParams.put("active", "true");
        activeNews = newsService.getPaginatedList(uriParams).getList();
        NewsResource newsResource = newsService.getById(newsId);
        this.fileUploadResource = FileUploadResource.builder().subject(NEWS).extension(CommonViewModel.DEFAULT_PICTURE_EXTENSION).build();
        //do mapping
        mapNewsResourceToFileResource(newsResource);
        encodedListPicture = fileUploadResource.getFile();
        encodedDetailsPicture = fileUploadResource.getDetailsNewsPicture();
    }

    private void mapNewsResourceToFileResource(NewsResource newsResource) {
        this.fileUploadResource.setId(newsResource.getId());
        this.fileUploadResource.setTitle(newsResource.getTitle());
        this.fileUploadResource.setTitleArabic(newsResource.getTitleArabic());
        this.fileUploadResource.setDetails(newsResource.getDetails());
        this.fileUploadResource.setDetailsArabic(newsResource.getDetailsArabic());
        this.fileUploadResource.setLink(newsResource.getLink());
        this.fileUploadResource.setLinkAr(newsResource.getLinkAr());
        this.fileUploadResource.setActive(newsResource.getActive());
        this.fileUploadResource.setFile(newsResource.getListPicture());
        this.fileUploadResource.setDetailsNewsPicture(newsResource.getDetailsPicture());
    }

    public void clear() {
        init();
    }

    /**
     *
     * retrieve back url page
     * @return
     */
    public String backUrl() {
        return BACK_NEWS_URL;
    }

    public void update() {
        if (CommonViewModel.isValidUrl(fileUploadResource.getLink())) {

            if(BooleanUtils.isTrue(isNewPicture)) {
                fileUploadResource.setFile(encodedListPicture);
                fileUploadResource.setIsNewFile(isNewPicture);
            }

            if(BooleanUtils.isTrue(isNewPictureDetail)) {
                fileUploadResource.setIsNewVideo(isNewPictureDetail);
                fileUploadResource.setDetailsNewsPicture(encodedDetailsPicture);
            }

            try {
                restClient.addItem(fileUploadResource);
                BoUtils.showsuccesspopup();
            } catch (RestBackendException e) {
                BoUtils.showErrorPopup(error, errorMessage);
            }
            dataFactory.redirect("news");
        } else {
            BoUtils.showErrorPopup(error, "Link invalid, News Link must be a valid URL");
        }

    }

    public void handleListPicture(FileUploadEvent fileUploadEvent) {
        file = fileUploadEvent.getFile();
        byte[] image = file.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error("An error has occured when uploading file : " + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
            int width = bi.getWidth();
            int height = bi.getHeight();
            if (700 > height && width < 700) {
                BoUtils.showErrorPopup("Image ", "Kindly attach an image with 700 height and width");
            } else {
                encodedListPicture = Base64
                        .getEncoder()
                        .encodeToString(file.getContent());

                isNewPicture = Boolean.TRUE;

                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
            }
        }
    }

    public void handleDetailsPicture(FileUploadEvent fileUploadEvent) {
        detailsFile = fileUploadEvent.getFile();
        byte[] image = detailsFile.getContent();
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new ByteArrayInputStream(image));
        } catch (IOException e) {
            log.error("An error has occured when uploading file : " + e.getMessage());
            BoUtils.showErrorPopup(error, errorMessage);
        }
        if(bi != null) {
        int width = bi.getWidth();
        int height = bi.getHeight();
            if (height < 700 && width < 700) {
                BoUtils.showErrorPopup("Image ", "Kindly attach an image with 700 height and width");
            } else {
                encodedDetailsPicture = Base64
                        .getEncoder()
                        .encodeToString(detailsFile.getContent());

                isNewPictureDetail = Boolean.TRUE;

                BoUtils.showInfoPopup("Successful", fileUploadEvent.getFile().getFileName() + " is uploaded.");
            }
        }
    }

}
