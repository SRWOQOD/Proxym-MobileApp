package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.StockPricesRessource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class StockPricesRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String stockPrices;

    @Autowired
    public StockPricesRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.stockPrices}") String stockPrices) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.stockPrices = stockPrices;
    }

    public PaginatedListResponse<StockPricesRessource> paginatedParams(Map<String, String> uriParams) {
        String uri = stockPrices.concat("/filtred");
        return (PaginatedListResponse<StockPricesRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<StockPricesRessource>>>() {
                        });
    }


    public List<StockPricesRessource> getList() {
        String uri = stockPrices;
        return ((ListResponse<StockPricesRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<StockPricesRessource>>>() {
                        })).getList();
    }
}
