package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PromotionResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface PromotionService {

    PaginatedListResponse<PromotionResource> getPaginatedPromotions(Map<String, String> uriParams);

    PromotionResource getPromotionByID(String id);

    void deletePromotion(HashMap<String, Object> serviceData);

    void edit(HashMap<String, Object> serviceData);

    List<PromotionResource> promotions(Map<String, String> uriParams);

}
