package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.PromotionResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/promotion.properties")
public class PromotionRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String promotion;

    @Autowired
    public PromotionRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.promotion}") String promotion) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.promotion = promotion;
    }

    public PaginatedListResponse<PromotionResource> paginatedParams(Map<String, String> uriParams) {
        String uri = "promotions/filtred";
        return (PaginatedListResponse<PromotionResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<PromotionResource>>>() {
                        });
    }

    public Boolean delete(String promotionId) {
        String uri = promotion + promotionId;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public PromotionResource getPromotionByID(String promotionId) {
        String uri = promotion + promotionId;
        ObjectResponse<PromotionResource> response = (ObjectResponse<PromotionResource>) customRestTemplate.getGenericResponseBody(baseUrlProvider.getUrl(uri), new ParameterizedTypeReference<GenericResponse<ObjectResponse<PromotionResource>>>() {
        });
        return response.getObject();
    }

    public Boolean editPromotion(PromotionResource promotionResource) {
        String uri = promotion;
        BooleanResponse response = (BooleanResponse) customRestTemplate.putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), promotionResource, new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
        });
        return response.isSuccess();
    }

    public List<PromotionResource> getPromotions(Map<String, String> uriParams) {
        String uri = "/promotions/promotions";
        return ((ListResponse<PromotionResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<PromotionResource>>>() {
                        })).getList();

    }
}
