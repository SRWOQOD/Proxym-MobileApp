package com.woqod.content.viewmodel.news;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.NewsLazyModel;
import com.woqod.content.models.HomeBoModel;
import com.woqod.content.service.news.NewsService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.NewsResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;


@Data
@Slf4j
@Component
@Scope("view")
public class NewsViewModel {

    private static final String SERVICE_NAME = "Survey";
    /*
    Beans
     */
    private final NewsService newsService;
    private final DataFactory factory;

    /*
    state
     */
    private NewsResource newsResource;

    private LazyDataModel<NewsResource> lazyModel;
    private String newsId;
    private final Permissions permissions;
    private HomeBoModel homeBoModel;
    Map<String, String> uriParams;
    private Integer newsNumber;

    @Autowired
    public NewsViewModel(NewsService newsService, Permissions permissions, DataFactory factory) {
        this.newsService = newsService;
        this.factory = factory;
        this.permissions = permissions;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("NEWS_VIEW_MODEL init");
        lazyModel = new NewsLazyModel(newsService);
        newsResource = new NewsResource();
        uriParams = new HashMap<>();
        homeBoModel = new HomeBoModel();
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                .getRequest();
        this.newsId = request.getParameter("id");
        newsNumber= newsService.count();
        homeBoModel = new HomeBoModel();
        search();

    }

    public void clear() {
        init();
    }

    public void search() {
        uriParams.put("dateFrom", DateFormatter.DateToString(homeBoModel.getDateFrom()));
        uriParams.put("dateTo", DateFormatter.DateToString(homeBoModel.getDateTo()));
        uriParams.put("active", homeBoModel.getActive());
        uriParams.put("title", homeBoModel.getTitle());
        ((NewsLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public String getDisplayNewsFeature() {
        return MenuEnum.DISPLAY_NEWS.name();
    }


    public String viewUrl(long id) {
        return ContentConstant.VIEW_URL.concat(String.valueOf(id));
    }

    public String editUrl(long id) {
        return ContentConstant.EDIT_URL.concat(String.valueOf(id));
    }

    public String getEditNewsFeature() {
        return MenuEnum.EDIT_NEWS.name();
    }

    public void delete(String id){
        newsService.delete(id);
        factory.redirect("news");
    }

    public String shorten(String title){
        if (title.length() < 45){
            return title;
        }
        return title.substring(0,45);
    }

    public static String html2text(String html) {
        return Jsoup.parse(html).text();
    }
}
