package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.TendersResource;

import java.util.List;
import java.util.Map;

public interface TendersService {
    void deleteTender(Map<String, Object> serviceData);

    PaginatedListResponse<TendersResource> getPaginatedTenders(Map<String, String> uriParams);

    List<TendersResource> tenders(Map<String, String> uriParams);
}
