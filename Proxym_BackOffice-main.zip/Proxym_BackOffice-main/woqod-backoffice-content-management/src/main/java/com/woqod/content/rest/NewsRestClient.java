package com.woqod.content.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.NewsResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/news.properties")
public class NewsRestClient {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private String news;
    private String count;


    @Autowired
    public NewsRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.news}") String news, @Value("${uri.ws.news.count}") String count) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.news = news;
        this.count = count;
    }


    /**
     * used to get parameters paginated and filtered
     */
    public PaginatedListResponse<NewsResource> paginatedParams(Map<String, String> uriParams) {
        String uri = news.concat("/filtered");
        return (PaginatedListResponse<NewsResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<NewsResource>>>() {
                        });
    }

    /*
      used to save News
     */
    public Boolean save(NewsResource newsResource) {
        String uri = news;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), newsResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }
     /**
     * used to update Parameter
     */
    public Boolean update(List<NewsResource> activeTop) {
        String uri = news;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), activeTop,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public Boolean update(NewsResource newsResources) {
        String uri = news;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), newsResources,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to get News By Id
     */
    public NewsResource getNewsById(String newsId) {
        String uri = news.concat("/").concat(newsId);
        ObjectResponse<NewsResource> response = (ObjectResponse<NewsResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<NewsResource>>>() {
                        });
        return response.getObject();
    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
    public Boolean delete(String id) {
        String uri = news + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

}
