package com.woqod.content.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.content.constant.PromotionConstant;
import com.woqod.content.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping(value = PromotionConstant.CONTENT_PROMOTOINS_MANAGEMENT_URL)
@Data
public class PromotionController {
    private final Permissions permissions;

    @Autowired
    public PromotionController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_PROMOTIONS.name(), PromotionConstant.PROMOTION_LIST);
    }

    @GetMapping("/edit")
    public ModelAndView editPromotion() {
        return permissions.getModelAndView(MenuEnum.EDIT_PROMOTION.name(), PromotionConstant.EDIT_PROMOTION);
    }
}
