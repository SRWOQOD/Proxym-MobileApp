package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.RetailersResource;

import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class RetailersRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String retailers;

    @Autowired
    public RetailersRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.retailers}") String retailers) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.retailers = retailers;
    }

    public PaginatedListResponse<RetailersResource> paginatedParams(Map<String, String> uriParams) {
        String uri = retailers.concat("/filtred");
        return (PaginatedListResponse<RetailersResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<RetailersResource>>>() {
                        });
    }
}
