package com.woqod.content.rest;


import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.ContentInfoResource;

import java.util.List;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class ContentRestClient {

    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String content;
    private String crons;

    @Value("${uri.ws.getArea}")
    private String area;

    @Autowired
    public ContentRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.content}") String content, @Value("${uri.ws.crons}") String crons) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.content = content;
        this.crons = crons;
    }

    public List<ContentInfoResource> getAllContents() {
        String uri = content;
        PaginatedListResponse<ContentInfoResource> response = (PaginatedListResponse<ContentInfoResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<ContentInfoResource>>>() {
                        });
        return response.getList();
    }

    public ContentInfoResource updateContentsInfoByCategory(String category) {
        String uri = content + "/" + category;
        ObjectResponse<ContentInfoResource> response = (ObjectResponse<ContentInfoResource>) customRestTemplate.getGenericResponseBody(baseUrlProvider.getUrl(uri), new ParameterizedTypeReference<GenericResponse<ObjectResponse<ContentInfoResource>>>() {
        });
        return response.getObject();
    }

    public Boolean updateContentsByCategory(ContentCategoryEnum category) {
        String uri = crons + "?category=" + category;
        BooleanResponse response = (BooleanResponse) customRestTemplate.putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                });
        return response.isSuccess();
    }

    public Boolean updateAllContent() {
        String uri = crons + "/all";
        BooleanResponse response = (BooleanResponse) customRestTemplate.putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                });
        return response.isSuccess();
    }

    public ListResponse<AreaResource> getArea() {
        String uri = area;
        return (ListResponse<AreaResource>) this.customRestTemplate.getGenericResponseBody(this.baseUrlProvider.getUrl(uri), new ParameterizedTypeReference<GenericResponse<ListResponse<AreaResource>>>() {
        });
    }
}
