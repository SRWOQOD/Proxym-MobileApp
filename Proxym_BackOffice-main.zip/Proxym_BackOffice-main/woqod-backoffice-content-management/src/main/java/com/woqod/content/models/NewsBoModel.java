package com.woqod.content.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsBoModel {
    private String title;
    private Date creationDate;
    private String views;
    private String active;

}