package com.woqod.content.service.news;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.NewsResource;

import java.util.List;
import java.util.Map;

public interface NewsService {


    void save(NewsResource newsResource);

    PaginatedListResponse<NewsResource> getPaginatedList(Map<String, String> uriParams);


    NewsResource getById(String adsId);

    void update(List<NewsResource> activeNews);

    void update(NewsResource newsResource);

    Integer count();

    void delete(String id);
}
