package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.PromotionConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.service.PromotionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.resources.PromotionResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

@Data
@Slf4j
@Component
@Scope("view")
public class EditPromotionViewModel {

    private final PromotionService promotionService;
    private String promotionID;
    private PromotionResource promotionResource;
    private UploadedFile file;
    private PromotionResource oldpromotionResource;
    private String myFileName;

    @Autowired
    public EditPromotionViewModel(PromotionService promotionService) {
        this.promotionService = promotionService;
    }

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            promotionID = request.getParameter(PromotionConstant.PROMOTIONID);
            oldpromotionResource = promotionService.getPromotionByID(promotionID);
            init();
        }
    }

    public void init() {
        promotionResource = promotionService.getPromotionByID(promotionID);
    }

    public void save() {
        if (checkValidity()) {
            HashMap<String, Object> serviceData = new HashMap<>();
            serviceData.put(UtilsConstants.POST_DATA, promotionResource);
            serviceData.put(UtilsConstants.OLD_DATA, oldpromotionResource);
            serviceData.put(UtilsConstants.FEATURE, MenuEnum.EDIT_PROMOTION.name());
            promotionService.edit(serviceData);
        }
    }

    public void handleFileUpload(FileUploadEvent event) {
        myFileName = event.getFile().getFileName();
        FacesMessage message = new FacesMessage("Succesful", myFileName + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public boolean checkValidity() {
        boolean checkValidity = true;
        if (promotionResource != null && !promotionResource.getBriefDescription().isEmpty() && !promotionResource.getTitle().isEmpty()) {
            if (promotionResource.getBriefDescription().length() > 2048) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(PromotionConstant.BUNDLE_NAME, "InvalidMinMaxMessage"), "");
            }
            if (promotionResource.getTitle().length() > 1024) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(PromotionConstant.BUNDLE_NAME, "InvalidMinMaxTitle"), "");
            }
        } else {
            checkValidity = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(PromotionConstant.BUNDLE_NAME, "RequiredElements"), "");
        }
        return checkValidity;
    }

    public void clear() {
        promotionResource = null;
        oldpromotionResource = null;
        init();
    }

    public String getEditPromotionFeature() {
        return MenuEnum.EDIT_PROMOTION.name();
    }

}
