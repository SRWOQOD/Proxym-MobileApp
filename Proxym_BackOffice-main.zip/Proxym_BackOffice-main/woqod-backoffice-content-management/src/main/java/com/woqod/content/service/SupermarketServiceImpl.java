package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.SupermarketRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
public class SupermarketServiceImpl implements SupermarketService {

    private final SupermarketRestClient supermarketRestClient;

    @Autowired
    public SupermarketServiceImpl(SupermarketRestClient supermarketRestClient) {
        this.supermarketRestClient = supermarketRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedSupermarkets(Map<String, String> uriParams) {
        return supermarketRestClient.paginatedParams(uriParams);
    }
}
