package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PetrolResource;

import java.util.List;
import java.util.Map;

public interface PricesService {

    PaginatedListResponse<PetrolResource> getPaginatedPetrolPrices(Map<String, String> uriParams);

    List<PetrolResource> getList();

}
