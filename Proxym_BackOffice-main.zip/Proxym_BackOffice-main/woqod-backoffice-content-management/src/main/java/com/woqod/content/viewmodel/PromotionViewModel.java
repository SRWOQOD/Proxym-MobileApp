package com.woqod.content.viewmodel;

import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.PromotionConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.PromotionLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.PromotionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.enumerations.PromotionCategoryEnum;
import wq.woqod.resources.resources.PromotionResource;
import wq.woqod.resources.resources.RetailersResource;

import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class PromotionViewModel {

    private final PromotionService promotionService;
    private final ContentService contentService;
    private Map<String, String> uriParams = new HashMap<>();

    private PromotionResource filterPromotionResource;
    private PromotionResource promotionResource;
    private LazyDataModel<PromotionResource> lazyModel;
    private List<PromotionCategoryEnum> category;
    private StreamedContent fileCSV;
    private StreamedContent file;


    @Autowired
    public PromotionViewModel(PromotionService promotionService, ContentService contentService) {
        this.promotionService = promotionService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        uriParams = new HashMap<>();
        filterPromotionResource = new PromotionResource();
        promotionResource = new PromotionResource();
        category = Arrays.asList(PromotionCategoryEnum.values());
        lazyModel = new PromotionLazyModel(promotionService);
    }

    public void updateContentCategory(String category) {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.valueOf(category));
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());
        contentService.updateContentCategory(serviceData);
    }

    public void deletePromotion(long id) {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, String.valueOf(id));
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_PROMOTION.name());
        promotionService.deletePromotion(serviceData);
    }

    public void search() {
        uriParams = new HashMap<>();
        if (filterPromotionResource.getPromotionsId() != null) {
            uriParams.put(PromotionConstant.PROMOTION_ID, filterPromotionResource.getPromotionsId().toString());
        }

        if (filterPromotionResource.getTitle() != null) {
            uriParams.put(PromotionConstant.PROMOTION_TITLE, filterPromotionResource.getTitle());
        }

        if (filterPromotionResource.getBriefDescription() != null) {
            uriParams.put(PromotionConstant.PROMOTION_DESCRIPTION, filterPromotionResource.getBriefDescription());
        }

        ((PromotionLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filterPromotionResource = new PromotionResource();
        init();
        search();
    }

    public String getDisplayPromotionsFeature() {
        return MenuEnum.DISPLAY_PROMOTIONS.name();
    }

    public String getEditPromotionFeature() {
        return MenuEnum.EDIT_PROMOTION.name();
    }

    public String getDeletePromotionFeature() {
        return MenuEnum.DELETE_PROMOTION.name();
    }

    public String getExportPromotionFeature() {
        return MenuEnum.EXPORT_PROMOTIONS.name();
    }

    public String updatePromotion(long id) {
        return PromotionConstant.EDIT_PROMOTION_URL.concat(String.valueOf(id));
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(promotionService.promotions(uriParams), "export/promotions.jrxml", "Promotions List", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Promotions.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(promotionService.promotions(uriParams), "contents/promotions.jrxml", "Promotions List", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Promotions.pdf").stream(() -> is).build();

    }
}
