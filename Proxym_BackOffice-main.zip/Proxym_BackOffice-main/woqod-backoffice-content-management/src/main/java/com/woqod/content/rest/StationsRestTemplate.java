package com.woqod.content.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.StationResource;
import wq.woqod.resources.resources.StationUpdateResources;

import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/content.properties")
public class StationsRestTemplate {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private String paginatedListStation;

    @Autowired
    public StationsRestTemplate(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.station.paginated}")
            String paginatedListStation) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.paginatedListStation = paginatedListStation;
    }

    /**
     * used to get parameters paginated and filtred
     */
    public PaginatedListResponse<StationResource> paginatedParams(Map<String, String> filters) {
        String uri = paginatedListStation.concat("/filtred");
        return (PaginatedListResponse<StationResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, filters),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<StationResource>>>() {
                        });
    }

    public BooleanResponse updateStationsServicesState(StationUpdateResources stationUpdateResources) {
        String uri = paginatedListStation.concat("/update");

        return (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri),
                        stationUpdateResources,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });


    }

}
