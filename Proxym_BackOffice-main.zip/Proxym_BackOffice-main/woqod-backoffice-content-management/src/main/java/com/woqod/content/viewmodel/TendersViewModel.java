package com.woqod.content.viewmodel;

import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.TendersConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.TendersLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.TendersService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.TendersResource;

import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class TendersViewModel {

    private final TendersService tendersService;
    private final ContentService contentService;

    private TendersResource filterTendersResource;
    private Map<String, String> uriParams = new HashMap<>();
    private TendersResource tendersResource;
    private LazyDataModel<TendersResource> lazyModel;
    private LocalDate collectionDateFrom;
    private LocalDate collectionDateTo;
    private LocalDate closingDateFrom;
    private LocalDate closingDateTo;
    private String details;
    private String fee;
    private Boolean activeTenders;
    private StreamedContent fileCSV;
    private StreamedContent file;


    @Autowired
    public TendersViewModel(TendersService tendersService, ContentService contentService) {
        this.tendersService = tendersService;
        this.contentService = contentService;
    }


    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        activeTenders = false;
        filterTendersResource = new TendersResource();
        tendersResource = new TendersResource();
        lazyModel = new TendersLazyModel(tendersService);
        search();
    }

    public void clear() {
        filterTendersResource = new TendersResource();
        collectionDateFrom = null;
        collectionDateTo = null;
        closingDateFrom = null;
        closingDateTo = null;
        init();
    }

    public void search() {
        uriParams = new HashMap<>();

        if (filterTendersResource.getCategory() != null) {
            uriParams.put(TendersConstant.TENDERS_CATEGORY, filterTendersResource.getCategory());
        }

        if (filterTendersResource.getDescription() != null) {
            uriParams.put(TendersConstant.TENDERS_DESCRIPTION, filterTendersResource.getDescription());
        }

        if (filterTendersResource.getBond() != null) {
            uriParams.put(TendersConstant.TENDERS_BOND, filterTendersResource.getBond());
        }

        if (collectionDateFrom != null) {
            uriParams.put(TendersConstant.COLLECTION_DATE_FROM, DateFormatter.localDateToStringDate(collectionDateFrom));
        }
        if (collectionDateTo != null) {
            uriParams.put(TendersConstant.COLLECTION_DATE_TO, DateFormatter.localDateToStringDate(collectionDateTo));
        }
        if (closingDateFrom != null) {
            uriParams.put(TendersConstant.CLOSING_DATE_FROM, DateFormatter.localDateToStringDate(closingDateFrom));
        }
        if (closingDateTo != null) {
            uriParams.put(TendersConstant.CLOSING_DATE_TO, DateFormatter.localDateToStringDate(closingDateTo));
        }
        if (activeTenders != null) {
            uriParams.put("active", String.valueOf(activeTenders));
        }
        ((TendersLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public LocalDateTime convertToLocalDateTimeViaInstant(Date dateToConvert) {
        return dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    public void deleteTender(long id) {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, String.valueOf(id));
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_TENDER.name());
        tendersService.deleteTender(serviceData);
    }

    public String getDisplayTendersFeature() {
        return MenuEnum.DISPLAY_TENDERS.name();
    }

    public String getEditTenderFeature() {
        return MenuEnum.EDIT_TENDER.name();
    }

    public String getDeleteTenderFeature() {
        return MenuEnum.DELETE_TENDER.name();
    }

    public String getExportTendersFeature() {
        return MenuEnum.EXPORT_TENDERS.name();
    }

    public String updateTender(long id) {
        return TendersConstant.EDIT_TENDER_URL.concat(String.valueOf(id));
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(tendersService.tenders(uriParams), "export/tenders.jrxml", "Tenders List", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Tenders.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(tendersService.tenders(uriParams), "contents/tenders.jrxml", "Tenders List", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Tenders.pdf").stream(() -> is).build();
    }

    public String shorten(String description) {
        if (description.length() < 50) {
            return description;
        }
        return description.substring(0, 50);
    }

    public Double convertToDouble(String varibale) {
        if(varibale != null && !varibale.isEmpty()){
            return Double.parseDouble(varibale);
        } else {
            return null;
        }

    }
}
