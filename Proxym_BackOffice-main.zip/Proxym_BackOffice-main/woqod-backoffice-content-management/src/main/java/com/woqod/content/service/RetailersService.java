package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.RetailersResource;

import java.util.Map;

public interface RetailersService {

    PaginatedListResponse<RetailersResource> getPaginatedRetailers(Map<String, String> uriParams);

}
