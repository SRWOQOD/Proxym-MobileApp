package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.rest.PromotionRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.PromotionResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class PromotionServiceImpl implements PromotionService {

    private final PromotionRestClient promotionRestClient;

    @Autowired
    public PromotionServiceImpl(PromotionRestClient promotionRestClient) {
        this.promotionRestClient = promotionRestClient;
    }

    @Override
    public PaginatedListResponse<PromotionResource> getPaginatedPromotions(Map<String, String> uriParams) {
        return promotionRestClient.paginatedParams(uriParams);
    }

    @Override
    public PromotionResource getPromotionByID(String id) {
        return promotionRestClient.getPromotionByID(id);
    }


    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void deletePromotion(HashMap<String, Object> serviceData) {
        String promotionId = (String) serviceData.get(UtilsConstants.POST_DATA);
        promotionRestClient.delete(promotionId);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void edit(HashMap<String, Object> serviceData) {
        PromotionResource promotionResource = (PromotionResource) serviceData.get(UtilsConstants.POST_DATA);
        promotionRestClient.editPromotion(promotionResource);
    }

    @Override
    public List<PromotionResource> promotions(Map<String, String> uriParams) {
        return promotionRestClient.getPromotions(uriParams);
    }
}
