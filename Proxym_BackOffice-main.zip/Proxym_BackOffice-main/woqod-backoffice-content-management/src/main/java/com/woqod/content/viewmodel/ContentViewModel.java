package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.PromotionService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.ContentInfoResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Data
@Slf4j
@Component
@Scope("view")
public class ContentViewModel {

    private static final String SERVICE_NAME = "LIS_CONTENT";
    private final PromotionService promotionService;
    private final ContentService contentService;

    private List<ContentInfoResource> contentInfoResources;
    private ContentInfoResource updatedInfoResource;
    private List<ContentCategoryEnum> contentCategoryEnum;
    private HttpSession session = BoUtils.getSession();


    @Autowired
    public ContentViewModel(PromotionService promotionService, ContentService contentService) {
        this.promotionService = promotionService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        contentCategoryEnum = Arrays.asList(ContentCategoryEnum.values());
        updatedInfoResource = new ContentInfoResource();
        contentInfoResources = contentService.getAllContents();
    }

    public String viewContent(String category) {
        return ContentConstant.SUB_CONTENT_MANAGEMENT_URL.concat("/").concat(category.toLowerCase());
    }

    public void updateContentCategory(String category) {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_CATEGORY.name());
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.valueOf(category));

        contentService.updateContentCategory(serviceData);
        init();
        BoUtils.showsuccesspopup();
    }

    public void updateAllContent() {
        contentService.updateAllContent();
        contentInfoResources = contentService.getAllContents();
    }


    public String getDisplayContentsFeature() {
        return MenuEnum.DISPLAY_CONTENTS.name();
    }

    public String getDisplayRetailesContentsFeature() {
        return MenuEnum.DISPLAY_RETAILERS_CONTENT.name();
    }

    public String getDisplaySupermarketsContentsFeature() {
        return MenuEnum.DISPLAY_SUPERMARKET_CONTENT.name();
    }

    public String getDisplayPricesContentsFeature() {
        return MenuEnum.DISPLAY_PRICES_CONTENT.name();
    }

    public String getDisplayFahesContentsFeature() {
        return MenuEnum.DISPLAY_FAHES_CONTENT.name();
    }

    public String getDisplayPetrolsContentsFeature() {
        return MenuEnum.DISPLAY_PETROL_CONTENT.name();
    }

    public String getViewPetrolContentsFeature() {
        return MenuEnum.VIEW_PETROL_CONTENT.name();
    }

    public String getViewTendersFeature() {
        return MenuEnum.VIEW_PETROL_CONTENT.name();
    }

    public String getViewStationsFeature() { return MenuEnum.DISPLAY_STATIONS.name(); }

    public String getViewStockPricesFeature() { return MenuEnum.DISPLAY_STOCK_PRICES.name(); }

}
