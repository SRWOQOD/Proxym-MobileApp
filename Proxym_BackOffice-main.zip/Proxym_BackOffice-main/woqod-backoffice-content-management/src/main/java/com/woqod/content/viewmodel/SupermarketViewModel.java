package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.SupermarketLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.SupermarketService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.SuperMarketResource;

import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class SupermarketViewModel {

    private final SupermarketService supermarketService;
    private final ContentService contentService;

    private List<AreaResource> areaResources;
    private SuperMarketResource superMarketResource;
    private SuperMarketResource filtersuperMarketResource;
    private LazyDataModel<SuperMarketResource> lazyModel;
    private String areaId;


    @Autowired
    public SupermarketViewModel(SupermarketService supermarketService, ContentService contentService) {
        this.supermarketService = supermarketService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        areaId = "";
        superMarketResource = new SuperMarketResource();
        filtersuperMarketResource = new SuperMarketResource();
        areaResources = contentService.getAllAreas();

        lazyModel = new SupermarketLazyModel(supermarketService);
    }

    public void search() {

        Map<String, String> uriParams = new HashMap<>();

        if (filtersuperMarketResource.getMarketId() != null) {
            uriParams.put(ContentConstant.SUPERMARKET_ID, filtersuperMarketResource.getMarketId().toString());

        }

        if (filtersuperMarketResource.getTitle() != null) {
            uriParams.put(ContentConstant.SUPERMARKET_TITLE, filtersuperMarketResource.getTitle());
        }

        if (filtersuperMarketResource.getContactPerson() != null) {
            uriParams.put(ContentConstant.SUPERMARKET_CONTACT_PERSON, filtersuperMarketResource.getContactPerson());
        }
        if (areaId != null && !areaId.isEmpty()) {
            uriParams.put("areaId", areaId);
        }
        ((SupermarketLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void clear() {
        filtersuperMarketResource = new SuperMarketResource();
        init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.SUPERMARKET);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());

        contentService.updateContentCategory(serviceData);
    }


    public String getDisplaySupermarketsFeature() {
        return MenuEnum.DISPLAY_RETAILERS_CONTENT.name();
    }


}
