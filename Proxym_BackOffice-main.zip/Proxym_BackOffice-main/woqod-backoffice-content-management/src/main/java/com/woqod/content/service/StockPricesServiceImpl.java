package com.woqod.content.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.content.rest.PricesRestClient;
import com.woqod.content.rest.StockPricesRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.PetrolResource;
import wq.woqod.resources.resources.StockPricesRessource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class StockPricesServiceImpl implements StockPricesService {

    private final StockPricesRestClient stockPricesRestClient;

    @Autowired
    public StockPricesServiceImpl(StockPricesRestClient stockPricesRestClient) {
        this.stockPricesRestClient = stockPricesRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedStockPrices(Map<String, String> uriParams) {
        return stockPricesRestClient.paginatedParams(uriParams);
    }

    @Override
    public List<StockPricesRessource> getList() {
        return stockPricesRestClient.getList();
    }
}
