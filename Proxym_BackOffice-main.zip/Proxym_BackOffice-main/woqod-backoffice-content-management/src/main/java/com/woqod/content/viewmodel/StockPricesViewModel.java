package com.woqod.content.viewmodel;

import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.content.constant.ContentConstant;
import com.woqod.content.enums.MenuEnum;
import com.woqod.content.lazymodel.StockPricesLazyModel;
import com.woqod.content.service.ContentService;
import com.woqod.content.service.StockPricesService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.StockPricesRessource;

import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class StockPricesViewModel {

    private final StockPricesService stockPricesService;
    private final ContentService contentService;
    private Map<String, String> uriParams = new HashMap<>();

    private StockPricesRessource stockPricesResource;
    private StockPricesRessource filterStockPricesResource;
    private LazyDataModel<StockPricesRessource> lazyModel;
    private List<StockPricesRessource> list;

    @Autowired
    public StockPricesViewModel(ContentService contentService, StockPricesService stockPricesService) {
        this.stockPricesService = stockPricesService;
        this.contentService = contentService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        stockPricesResource = new StockPricesRessource();
        filterStockPricesResource = new StockPricesRessource();
        list = stockPricesService.getList();
        lazyModel = new StockPricesLazyModel(stockPricesService);

    }

    public void search() {
        if (filterStockPricesResource.getMarketName() != null) {
            uriParams.put(ContentConstant.STOCK_PRICES_MARKET_NAME, filterStockPricesResource.getMarketName());
        }

        if (filterStockPricesResource.getVolume() != null) {
            uriParams.put(ContentConstant.STOCK_PRICES_VOLUME, filterStockPricesResource.getVolume());
        }

        if (filterStockPricesResource.getDateStock() != null) {
            uriParams.put(ContentConstant.STOCK_PRICES_SYNC_DATE, filterStockPricesResource.getDateStock().toString());
        }

        ((StockPricesLazyModel) lazyModel).setLazyModelParams(uriParams);

    }

    public void clear() {
        filterStockPricesResource = new StockPricesRessource();
        init();
        search();
    }

    public void updateContent() {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, ContentCategoryEnum.STOCKPRICES);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.UPDATE_CONTENT_INFO.name());

        contentService.updateContentCategory(serviceData);
    }

    public String getDisplayStockPricesFeature() {
        return MenuEnum.DISPLAY_STOCK_PRICES.name();
    }


}
