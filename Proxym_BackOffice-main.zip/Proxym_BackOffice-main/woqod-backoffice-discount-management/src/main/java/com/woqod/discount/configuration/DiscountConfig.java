package com.woqod.discount.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author OTHMANI Lazhar
 * on 08/04/2019
 */
@Configuration
@ComponentScan(basePackages = {"com.woqod.discount"})
public class DiscountConfig {
}
