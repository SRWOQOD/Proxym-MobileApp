package com.woqod.discount;


import org.springframework.stereotype.Component;


@Component
public class DiscountBootstrap {
    private static final String DISCOUNT_MANAGEMENT = "Discount_Management";

}
