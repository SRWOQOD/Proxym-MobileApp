package com.woqod.discount.rest;

import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import com.woqod.discount.constant.DiscountConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.DiscountResource;

import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/discount.properties")
public class DiscountRestClient {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private String discount;
    private String saveDiscount;
    private String updateDiscount;


    @Autowired
    public DiscountRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.discount}") String discount, @Value("${uri.ws.updateDiscount}") String updateDiscount, @Value("${uri.ws.saveDiscount}") String saveDiscount) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.discount = discount;
        this.updateDiscount = updateDiscount;
        this.saveDiscount = saveDiscount;
    }

    /**
     * used to get parameters paginated and filtred
     *
     * @return
     * @throws RestBackendException
     */
    public PaginatedListResponse<DiscountResource> paginatedParams(Map<String, String> uriParams) {
        log.debug("{} paginatedParams", DiscountConstant.DISCOUNT_REST_CLIENT);
        String uri = discount.concat("/filtred");
        PaginatedListResponse<DiscountResource> listResponse = (PaginatedListResponse<DiscountResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<DiscountResource>>>() {
                        });

        return listResponse;

    }

    /*
       used to save discount
       @return
     * @throws RestBackendException

      */
    public Boolean save(DiscountResource discountResource) {
        log.debug("{} save", DiscountConstant.DISCOUNT_REST_CLIENT);
        String uri = saveDiscount;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), discountResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to delete discount
     *
     * @param id
     * @return
     */
    public Boolean delete(String id) {
        log.debug("{} delete", DiscountConstant.DISCOUNT_REST_CLIENT);
        String uri = discount + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to update Parameter
     *
     * @param object
     * @return
     */
    public Boolean update(DiscountResource object) {
        log.debug("{} update", DiscountConstant.DISCOUNT_REST_CLIENT);
        String uri = updateDiscount;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), object,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to get Discount By Id
     *
     * @param discountId
     * @return
     */
    public DiscountResource getDiscountById(String discountId) {
        log.debug("{} getDiscountById", DiscountConstant.DISCOUNT_REST_CLIENT);
        String uri = discount.concat("/").concat(discountId);
        ObjectResponse<DiscountResource> response = (ObjectResponse<DiscountResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<DiscountResource>>>() {
                        });
        return response.getObject();
    }
}
