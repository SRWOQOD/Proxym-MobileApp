package com.woqod.discount.viewmodel;


import com.woqod.discount.constant.DiscountConstant;
import com.woqod.discount.lazymodel.DiscountLazyModel;
import com.woqod.discount.service.DiscountService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.enumerations.PaymentTypeEnum;
import wq.woqod.resources.resources.DiscountResource;

import javax.faces.context.FacesContext;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class DiscountViewModel {

    /*
    Beans
     */
    private final DiscountService discountService;

    /*
    state
     */
    private DiscountResource filterDiscountResource;
    private DiscountResource discountResource;
    private LazyDataModel<DiscountResource> lazyModel;
    private List<FahesServiceEnum> fahesServiceEnums;
    private List<PaymentMethodEnum> paymentMethodEnums;
    private List<PaymentTypeEnum> paymentTypeEnums;

    @Autowired
    public DiscountViewModel(DiscountService discountService) {
        this.discountService = discountService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", DiscountConstant.DISCOUNT_VIEW_MODEL);
        lazyModel = new DiscountLazyModel(discountService);
        discountResource = new DiscountResource();
        fahesServiceEnums = Arrays.asList(FahesServiceEnum.values());
        paymentMethodEnums = Arrays.asList(PaymentMethodEnum.values());
        paymentTypeEnums = Arrays.asList(PaymentTypeEnum.values());
        filterDiscountResource = new DiscountResource();
        filterDiscountResource.setStatus(null);

    }

    public void clear() {
        log.debug("{} clear", DiscountConstant.DISCOUNT_VIEW_MODEL);
        filterDiscountResource = new DiscountResource();
        search();
    }

    public void search() {
        log.debug("{} search", DiscountConstant.DISCOUNT_VIEW_MODEL);
        Map<String, String> uriParams = new HashMap<>();
        if (filterDiscountResource.getPaymentMethodEnum() != null) {
            uriParams.put(DiscountConstant.PAYMENT_METHOD, filterDiscountResource.getPaymentMethodEnum().name());
        }
        if (filterDiscountResource.getPaymentTypeEnum() != null) {
            uriParams.put(DiscountConstant.PAYMENT_TYPE, filterDiscountResource.getPaymentTypeEnum().name());
        }
        if (filterDiscountResource.getFahesServiceEnum() != null) {
            uriParams.put(DiscountConstant.SERVICE, filterDiscountResource.getFahesServiceEnum().name());
        }
        if (filterDiscountResource.getStatus() != null) {
            uriParams.put(DiscountConstant.STATUS, String.valueOf(filterDiscountResource.getStatus()));
        }

        ((DiscountLazyModel) lazyModel).setSearchData(true);
        ((DiscountLazyModel) lazyModel).setLazyModelParams(uriParams);
    }


    public String editUrl(long id) {
        return DiscountConstant.EDIT_URL.concat(String.valueOf(id));
    }

}
