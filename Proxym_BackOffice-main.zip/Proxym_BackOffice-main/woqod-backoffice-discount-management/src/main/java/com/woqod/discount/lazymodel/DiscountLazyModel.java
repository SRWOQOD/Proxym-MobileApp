package com.woqod.discount.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.discount.constant.DiscountConstant;
import com.woqod.discount.service.DiscountService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.DiscountResource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class DiscountLazyModel extends LazyDataModel<DiscountResource> {

    private DiscountService discountService;

    private Map<String, String> uriParams;

    private Boolean searchData = false;

    public DiscountLazyModel(DiscountService discountService) {
        this.discountService = discountService;
        this.uriParams = new HashMap<>();
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtred and paginated data
     *
     * @param first
     * @param pageSize
     * @param sortField
     * @param sortOrder
     * @param filters
     * @return
     */
    @Override
    public List<DiscountResource> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                       Map<String, FilterMeta> filters) {

        try {
            if (searchData) first = 0;
            PaginatedListResponse<DiscountResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, first, pageSize));
            response = discountService.getPaginatedDiscount(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchData = false;
            return response.getList();
        } catch (Exception e) {
            log.error("{} {} {}", DiscountConstant.DISCOUNT_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, DiscountConstant.DISCOUNTS);
            return new ArrayList<>();
        }

    }
}