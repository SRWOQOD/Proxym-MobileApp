package com.woqod.discount.viewmodel;

import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.discount.constant.DiscountConstant;
import com.woqod.discount.service.DiscountService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.enumerations.PaymentTypeEnum;
import wq.woqod.resources.resources.DiscountResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;

@Data
@Slf4j
@Component
@Scope("view")
public class EditDiscountViewModel {
    /*
    Beans
     */
    private final DiscountService discountService;

    /*
   state
    */
    private DiscountResource discountResource;
    private DiscountResource oldDiscountResource;
    private List<FahesServiceEnum> fahesServiceEnums;
    private List<PaymentMethodEnum> paymentMethodEnums;
    private List<PaymentTypeEnum> paymentTypeEnums;
    private String discountId;

    @Autowired
    public EditDiscountViewModel(DiscountService discountService) {
        this.discountService = discountService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            discountId = request.getParameter(DiscountConstant.DISCOUNT_ID);
            oldDiscountResource = discountService.getDiscountById(discountId);
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", DiscountConstant.EDIT_DISCOUNT_VIEW_MODEL);
        fahesServiceEnums = Arrays.asList(FahesServiceEnum.values());
        paymentMethodEnums = Arrays.asList(PaymentMethodEnum.values());
        paymentTypeEnums = Arrays.asList(PaymentTypeEnum.values());
        //copy object vales's in other object
        discountResource = discountService.getDiscountById(discountId);
    }

    public void clear() {
        log.debug("{} clear ", DiscountConstant.EDIT_DISCOUNT_VIEW_MODEL);
        init();
    }


    public Boolean checkValidity(DiscountResource discountResource) {
        Boolean isValid = true;
        if (discountResource.getMax() < discountResource.getMin()) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidMinMax"), "");
        }

        if (discountResource.getPaymentTypeEnum().equals(PaymentTypeEnum.PERCENT) && ((discountResource.getAmount() < DiscountConstant.MIN_PERCENT) || (discountResource.getAmount() > DiscountConstant.MAX_PERCENT))) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidAmountWithPercent"), "");
        }

        if ((discountResource.getAmount() > discountResource.getMin())) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidAmount"), "");
        }
        return isValid;
    }

    /**
     * retreive back url page
     *
     * @return
     */
    public String backUrl() {
        return DiscountConstant.BACK_URL;
    }

}
