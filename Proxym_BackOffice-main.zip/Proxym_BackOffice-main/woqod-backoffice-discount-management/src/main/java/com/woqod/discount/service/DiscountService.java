package com.woqod.discount.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.DiscountResource;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public interface DiscountService extends Serializable {

    PaginatedListResponse<DiscountResource> getPaginatedDiscount(Map<String, String> uriParams);

    void save(HashMap<String, Object> serviceData);

    void delete(HashMap<String, Object> serviceData);

    void edit(HashMap<String, Object> serviceData);

    DiscountResource getDiscountById(String id);

}
