package com.woqod.discount.viewmodel;


import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.discount.constant.DiscountConstant;
import com.woqod.discount.service.DiscountService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.enumerations.PaymentTypeEnum;
import wq.woqod.resources.resources.DiscountResource;

import javax.faces.context.FacesContext;
import java.util.Arrays;
import java.util.List;

@Data
@Slf4j
@Component
@Scope("view")
public class AddDiscountViewModel {

    /*
     Beans
     */
    private final DiscountService discountService;

    /*
      state
      */
    private DiscountResource filter;
    private DiscountResource discountResource;
    private List<FahesServiceEnum> fahesServiceEnums;
    private List<PaymentMethodEnum> paymentMethodEnums;
    private List<PaymentTypeEnum> paymentTypeEnums;

    @Autowired
    public AddDiscountViewModel(DiscountService discountService) {
        this.discountService = discountService;
    }


    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primefaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * used to initialize filter before display view
     */
    public void init() {
        log.debug("{} init ", DiscountConstant.ADD_DISCOUNT_VIEW_MODEL);
        discountResource = new DiscountResource();
        fahesServiceEnums = Arrays.asList(FahesServiceEnum.values());
        paymentMethodEnums = Arrays.asList(PaymentMethodEnum.values());
        paymentTypeEnums = Arrays.asList(PaymentTypeEnum.values());
    }

    /**
     * Clear function
     */
    public void clear() {
        log.debug("{} clear ", DiscountConstant.ADD_DISCOUNT_VIEW_MODEL);
        init();
    }


    public Boolean checkValidity(DiscountResource discountResource) {
        Boolean isValid = true;
        if (discountResource.getMax() < discountResource.getMin()) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidMinMax"), "");
        }

        if ((discountResource.getPaymentTypeEnum().equals(PaymentTypeEnum.PERCENT)) && ((discountResource.getAmount() < DiscountConstant.MIN_PERCENT) || (discountResource.getAmount() > DiscountConstant.MAX_PERCENT))) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidAmountWithPercent"), "");
        }

        if ((discountResource.getAmount() > discountResource.getMin())) {
            isValid = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(DiscountConstant.BUNDLE_NAME, "InvalidAmount"), "");
        }
        return isValid;
    }

}
