package com.woqod.discount.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.discount.constant.DiscountConstant;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Data
@Slf4j
@Controller
@RequestMapping(value = DiscountConstant.DISCOUNT_MANAGEMENT_URL)
public class DiscountController {

    private final Permissions permissions;

    @Autowired
    public DiscountController(Permissions permissions) {
        this.permissions = permissions;
    }


}
