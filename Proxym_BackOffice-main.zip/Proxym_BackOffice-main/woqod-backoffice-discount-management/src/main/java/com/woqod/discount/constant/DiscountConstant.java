package com.woqod.discount.constant;

public final class DiscountConstant {
    public static final String SERVICE = "fahesServiceEnum";
    public static final String PAYMENT_TYPE = "paymentTypeEnum";
    public static final String PAYMENT_METHOD = "paymentMethodEnum";
    public static final String STATUS = "status";
    public static final String DISCOUNTS_LIST = "listDiscounts";
    public static final String ADD_DISCOUNT = "addDiscount";
    public static final String EDIT_DISCOUNT = "editDiscount";
    public static final String DISCOUNT_LAZY_MODEL = "DiscountLazyModel";
    public static final String DISCOUNTS = "discounts";
    public static final String DISCOUNT_REST_CLIENT = "DiscountRestClient";
    public static final String DISCOUNT_SERVICE_IMPL = "DiscountServiceImpl";
    public static final String DISCOUNT_MANAGEMENT_URL = "/discount";
    public static final String ADD_DISCOUNT_URL = "/discount/add";
    public static final String ADD_DISCOUNT_VIEW_MODEL = "[AddDiscountViewModel]";
    public static final int MIN_PERCENT = 0;
    public static final int MAX_PERCENT = 100;
    public static final String DISCOUNT_VIEW_MODEL = "[DiscountViewModel]";
    public static final String EDIT_DISCOUNT_VIEW_MODEL = "[EditViewModel]";
    public static final String BUNDLE_NAME = "discount_messages";
    public static final String EDIT_URL = "discount/edit?id=";
    public static final String DISCOUNT_ID = "id";
    public static final String BACK_URL = "discount";

    public DiscountConstant() {
    }
}
