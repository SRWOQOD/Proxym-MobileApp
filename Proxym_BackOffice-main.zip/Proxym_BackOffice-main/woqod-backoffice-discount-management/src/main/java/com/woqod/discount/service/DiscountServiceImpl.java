package com.woqod.discount.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.discount.constant.DiscountConstant;
import com.woqod.discount.rest.DiscountRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.DiscountResource;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class DiscountServiceImpl implements DiscountService {

    private final DiscountRestClient discountRestClient;

    @Autowired
    public DiscountServiceImpl(DiscountRestClient discountRestClient) {
        this.discountRestClient = discountRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedDiscount(Map<String, String> uriParams) {
        log.debug("{} getPaginatedDiscount ", DiscountConstant.DISCOUNT_SERVICE_IMPL);
        return discountRestClient.paginatedParams(uriParams);
    }


    @Override
    @StepExecutor(redirect = true, redirectTo = "discount", saveLog = true)
    public void save(HashMap<String, Object> serviceData) {
        log.debug("{} save ", DiscountConstant.DISCOUNT_SERVICE_IMPL);
        DiscountResource discountResource = (DiscountResource) serviceData.get(UtilsConstants.POST_DATA);
        discountRestClient.save(discountResource);
    }

    @Override
    @StepExecutor(redirect = true, redirectTo = "discount", saveLog = true)
    public void delete(HashMap<String, Object> serviceData) {
        log.debug("{} delete", DiscountConstant.DISCOUNT_SERVICE_IMPL);
        String discountId = (String) serviceData.get(UtilsConstants.POST_DATA);
        discountRestClient.delete(discountId);
    }

    @Override
    @StepExecutor(redirect = true, redirectTo = "discount", saveLog = true)
    public void edit(HashMap<String, Object> serviceData) {
        log.debug("{} edit", DiscountConstant.DISCOUNT_SERVICE_IMPL);
        DiscountResource discountResource = (DiscountResource) serviceData.get(UtilsConstants.POST_DATA);
        discountRestClient.update(discountResource);
    }

    @Override
    public DiscountResource getDiscountById(String id) {
        log.debug("{} getDiscountById", DiscountConstant.DISCOUNT_SERVICE_IMPL);
        return discountRestClient.getDiscountById(id);

    }
}
