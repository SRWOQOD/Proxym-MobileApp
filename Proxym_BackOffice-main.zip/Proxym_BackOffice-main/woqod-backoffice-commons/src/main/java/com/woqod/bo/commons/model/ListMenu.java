package com.woqod.bo.commons.model;

import com.woqod.bo.commons.enums.Menu;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ListMenu {
    private List<Menu> menus = new ArrayList<>();
}
