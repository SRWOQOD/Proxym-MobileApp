package com.woqod.bo.commons.enums;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:18
 */
public enum MessagesTypeEnum {
    ERROR,
    INFO,
    WARNING
}
