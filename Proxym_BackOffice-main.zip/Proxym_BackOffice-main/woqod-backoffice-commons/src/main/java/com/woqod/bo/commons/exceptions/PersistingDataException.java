package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:37
 */
public class PersistingDataException extends AccessDataException {


    private static final long serialVersionUID = 1L;

    public PersistingDataException(String entityName, Throwable exception) {
        super(ProxymError.PERSIST_VIOLATION_CONSTRAINT, entityName, exception);
    }

}
