package com.woqod.bo.commons.security;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.model.FeatureModel;
import lombok.Data;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

/**
 * User: Nasreddine.Jrebi
 * Date: 27/11/2018 09:15
 */
@Component
@Data
public class Permissions {

    private final DataFactory dataFactory;

    @Autowired
    public Permissions(DataFactory dataFactory) {
        this.dataFactory = dataFactory;
    }

    /**
     * check if feature is permitted or no from session if exist else from DB
     */
    public Boolean isFeaturePermitted(String feature) {
        for (FeatureModel featureModel : dataFactory.getFeatureList()) {
            if (featureModel.getCode().equals(feature)) {
                return true;
            }
            for (FeatureModel featureModelN1 : featureModel.getChildrenFeatures()) {
                if (featureModelN1.getCode().equals(feature)) {
                    return true;
                }

                for (FeatureModel featureModelN2 : featureModelN1.getChildrenFeatures()) {
                    if (featureModelN2.getCode().equals(feature)) {
                        return true;
                    }

                    for (FeatureModel featureModelN3 : featureModelN2.getChildrenFeatures()) {
                        if (featureModelN3.getCode().equals(feature)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public ModelAndView getModelAndView(String feature, String viewPath) {
        ModelAndView modelAndView = new ModelAndView();
        if (BooleanUtils.isTrue(isFeaturePermitted(feature))) {
                modelAndView.setViewName(viewPath);
        } else {
            modelAndView.setViewName("/access");
        }
        return modelAndView;
    }
}

