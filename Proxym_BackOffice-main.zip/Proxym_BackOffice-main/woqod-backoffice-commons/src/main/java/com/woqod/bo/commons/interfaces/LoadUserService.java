package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.ExternalUser;
import com.woqod.bo.commons.model.UserRoleForm;

import java.util.List;

public interface LoadUserService {

    List<ExternalUser> getAllUsers();

    List<ExternalUser> getUsersWithFilter(UserRoleForm filter);

}
