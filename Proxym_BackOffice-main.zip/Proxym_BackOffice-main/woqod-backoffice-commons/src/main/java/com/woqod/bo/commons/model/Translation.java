package com.woqod.bo.commons.model;

/**
 * User: Nasreddine.Jrebi
 * Date: 11/12/2018 17:04
 */
public class Translation {

    private String key;
    private String value;

    public Translation(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public Translation() {
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
