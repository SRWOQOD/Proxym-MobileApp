/**
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 * @author MedAmine
 */
/**
 * @author MedAmine
 *
 */
package com.woqod.bo.commons.response.body;