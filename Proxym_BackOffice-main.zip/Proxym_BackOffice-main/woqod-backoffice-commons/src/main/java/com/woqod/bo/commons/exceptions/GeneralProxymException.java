package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;

/**
 * User: Nasreddine.Jrebi
 * Date: 27/11/2018 09:53
 */
public class GeneralProxymException extends ProxymException {

    public GeneralProxymException() {
        super(ProxymError.ERROR_GENERAL_FAILURE);
    }
}
