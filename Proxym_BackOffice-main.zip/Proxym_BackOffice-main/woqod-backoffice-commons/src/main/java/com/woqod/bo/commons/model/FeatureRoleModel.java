package com.woqod.bo.commons.model;


/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
public class FeatureRoleModel {
    private Long id;

    private FeatureModel feature;

    private RoleModel role;

    public FeatureRoleModel() {

    }

    public FeatureRoleModel(FeatureModel feature, RoleModel role) {
        this.feature = feature;
        this.role = role;
    }

    public FeatureRoleModel(Long id, FeatureModel feature, RoleModel role) {
        super();
        this.id = id;
        this.feature = feature;
        this.role = role;
    }

    public FeatureModel getFeature() {
        return feature;
    }

    public void setFeature(FeatureModel feature) {
        this.feature = feature;
    }

    public RoleModel getRole() {
        return role;
    }

    public void setRole(RoleModel role) {
        this.role = role;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
