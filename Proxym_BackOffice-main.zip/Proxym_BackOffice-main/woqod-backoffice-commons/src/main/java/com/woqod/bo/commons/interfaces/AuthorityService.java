package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.AuthorityModel;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.commons.model.UserRoleForm;

import java.time.LocalDate;
import java.util.List;

public interface AuthorityService {
    void save(String roleName, UserModel userModel);

    /**
     * Save a new Authorities list
     *
     * @param autorities
     */
    void save(List<AuthorityModel> autorities);

    void save(AuthorityModel authorityModel);

    /**
     * Return Authorities
     *
     * @return
     */
    List<AuthorityModel> getAuthorities();

    void updateAuthority(UserRoleForm userRoleForm);

    /**
     * @param userName
     */
    void deleteAuthority(String userName);

    /**
     * Get Authority By roleName
     *
     * @param roleName
     */
    List<AuthorityModel> getAuthorityByRoleName(String roleName);

    /**
     * Get Authority By userName
     *
     * @param userName
     */
    AuthorityModel getAuthorityByUserName(String userName);

    List<AuthorityModel> search(UserRoleForm filter, LocalDate startCreatedAtDate, LocalDate endCreatedAtDate);


}
