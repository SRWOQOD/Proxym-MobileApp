package com.woqod.bo.commons.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ErrorController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorController.class);

    @GetMapping(value = "/access")
    public ModelAndView accessdenied() {
        LOGGER.info("[ErrorController] accessdenied ");
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName("/access");
        return modelView;
    }

    @GetMapping(value = "/notfound")
    public ModelAndView notfound() {
        LOGGER.info("[ErrorController] notfound ");
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName("/404");
        return modelView;
    }
}
