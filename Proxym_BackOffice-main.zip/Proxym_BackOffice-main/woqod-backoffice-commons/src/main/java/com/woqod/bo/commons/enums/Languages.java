package com.woqod.bo.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Languages {
    ENGLISH("EN", "ENGLISH"),
    GERMAN("DE", "DEUTSCH"),
    FRENCH("FR", "FRANCAIS");
    private String code;
    private String name;
}
