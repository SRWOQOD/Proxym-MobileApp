package com.woqod.bo.commons;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * User: Nasreddine.Jrebi
 * Date: 04/12/2018 16:08
 */

/**
 * used in AutoConfiguration
 */
@Configuration
@ComponentScan(basePackages = {"com.woqod.bo.commons"})
public class CommonConfig {
}
