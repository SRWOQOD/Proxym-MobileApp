package com.woqod.bo.commons.restclient;

import com.woqod.bo.commons.utils.BoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

@Component
public class BaseUrlProvider {

    private final String server;
    private final String module;
    private final String uploadhost;

    @Autowired
    public BaseUrlProvider(@Value("${uri.ws.server}") String server,
                           @Value("${uri.ws.module}") String module,
                           @Value("${upload.host}") String uploadhost) {
        this.server = server;
        this.module = module;
        this.uploadhost = uploadhost;
    }

    /**
     * form the backend baseUrl
     *
     * @return baseUrl
     */
    public String getPath(String uri) {
        String baseUrl = "";

        if (!BoUtils.isEmptyOrNull(module)) {
            baseUrl = baseUrl.concat("/").concat(module);
        }
        baseUrl = baseUrl.concat("/").concat(uri);
        return baseUrl;
    }

    /**
     * form the backend baseUrl
     *
     * @return
     */
    public String getUrl(String uri) {
        return getUriComponent(uri, new LinkedMultiValueMap<>());
    }

    /**
     * form the backend baseUrl
     *
     * @return
     */
    public String getUrl(String uri, Map<String, String> uriParams) {
        LinkedMultiValueMap<String, String> linkedMultiValueMap = retreiveParamsFromUriParams(uriParams);
        return getUriComponent(uri, linkedMultiValueMap);
    }


    private String getUriComponent(String uri, LinkedMultiValueMap<String, String> linkedMultiValueMap) {
        UriComponents uriComponents;
        uriComponents = UriComponentsBuilder.newInstance()
                .host(server)
                .path(getPath(uri))
                .queryParams(linkedMultiValueMap)
                .build();
        return uriComponents.toUriString().replaceFirst("//", "");
    }

    private LinkedMultiValueMap<String, String> retreiveParamsFromUriParams(Map<String, String> uriParams) {
        LinkedMultiValueMap<String, String> linkedMultiValueMap = new LinkedMultiValueMap<>();

        if(uriParams != null) {
            uriParams.entrySet().forEach(entry -> {
                if (!BoUtils.isEmptyOrNull(entry.getValue())) {
                    linkedMultiValueMap.add(entry.getKey(), entry.getValue());
                }
            });
        }
        return linkedMultiValueMap;
    }

    public String getUriUpload() {
        return module + "/" + uploadhost;
    }
}
