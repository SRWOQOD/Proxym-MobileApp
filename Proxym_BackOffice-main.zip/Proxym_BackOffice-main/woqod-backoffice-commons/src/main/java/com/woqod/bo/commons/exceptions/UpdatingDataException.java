package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:32
 */
public class UpdatingDataException extends AccessDataException {

    private static final long serialVersionUID = 1L;

    public UpdatingDataException(String entityName, Throwable exception) {
        super(ProxymError.UPDATE_VIOLATION_CONSTRAINT, entityName, exception);
    }
}
