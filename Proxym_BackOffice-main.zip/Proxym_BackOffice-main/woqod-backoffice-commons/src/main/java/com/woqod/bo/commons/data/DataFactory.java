package com.woqod.bo.commons.data;

import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 27/11/2018 09:22
 */
@Slf4j
@Component
public class DataFactory {

    /**
     * static attributs
     */
    public static final String ADD = "ADD";
    /**
     * Beans
     */
    private final FeatureService featureService;

    /**
     * Simple attributs
     */

    private String context;


    /**
     * @param featureService
     * @param customRestTemplate
     * @param baseUrlProvider
     * @param context
     */
    @Autowired
    public DataFactory(FeatureService featureService, CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${server.servlet.context-path}") String context) {
        this.featureService = featureService;
        this.context = context;
    }


    /**
     * get authorised features from session if exist else we will get it from DB
     */
    public  List<FeatureModel> getFeatureList() {
        HttpSession session = BoUtils.getSession();
        List<FeatureModel> list;
        // Get authorised List of features from session
        list = (List<FeatureModel>) session.getAttribute("features");

        if (list == null || list.isEmpty()) {
            // if session is empty we will get it from DB
            list = featureService.findAllParentByRole(getAuthenticatedRole());
            session.setAttribute("features", new ArrayList<>(list));
        }
        return list;
    }

    /**
     * get display nem of connected user
     */
    public String getAuthenticatedUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }


    public String getAuthenticatedRole() {
        return SecurityContextHolder.getContext().getAuthentication().getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");
    }

    /**
     * retreieve redirect url to change lang
     **/
    public String changeLangUrl(String language) {
        return retreiveContext() + "/login?lang=" + language;
    }


    /**
     * redirect to the path
     *
     * @param path
     * @throws IOException
     */
    public void redirect(String path) {
        try {
            FacesContext.getCurrentInstance().getExternalContext().redirect(retreiveContext() + "/" + path);
        } catch (RuntimeException | IOException e) {
            log.error(e.getMessage());
        }
    }

    public String retreiveContext() {
        if (this.context.equals("/")) {
            return "";
        } else {
            return this.context;
        }
    }

    public FeatureService getFeatureService() {
        return featureService;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }


    public static Logger getLog() {
        return log;
    }
}
