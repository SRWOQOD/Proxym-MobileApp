package com.woqod.bo.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bundle {
    private String bundleName;

    private String bundleKey;

}
