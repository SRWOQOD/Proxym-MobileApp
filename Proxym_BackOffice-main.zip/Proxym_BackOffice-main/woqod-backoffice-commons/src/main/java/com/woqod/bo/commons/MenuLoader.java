package com.woqod.bo.commons;

import com.woqod.bo.commons.enums.Menu;
import com.woqod.bo.commons.enums.ModuleLevel;
import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.bo.commons.utils.BoUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class MenuLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger(MenuLoader.class);

    private final FeatureService featureService;

    private static Map<String, ListMenu> menuHashMap = new HashMap<>();

    private static HashMap<String, List<FeatureModel>> savedMenuHashMap = new HashMap<>();

    @Autowired
    public MenuLoader(FeatureService featureService) {
        this.featureService = featureService;
    }

    @EventListener
    public void handleContextRefreshEvent(ApplicationReadyEvent applicationReadyEvent) {
        LOGGER.debug("[MenuLoader] start load features and actions in database");

        long startTime = System.currentTimeMillis();

        List<Menu> baseLevelMenu = new ArrayList<>();
        List<Menu> firstLevelMenu = new ArrayList<>();
        List<Menu> secondLevelMenu = new ArrayList<>();
        List<Menu> thirdLevelMenu = new ArrayList<>();

        // loop menuHash and retreive feature level
        // note that we should save the levels one by one to acheive entities relations
        for (Map.Entry<String, ListMenu> mapentry : menuHashMap.entrySet()) {

            ListMenu listMenu = mapentry.getValue();
            // retreive features with level 0 : parent modules
            baseLevelMenu.addAll(listMenu.getMenus().stream().filter(menu -> menu.getMenuPosition().getLevel().equals(ModuleLevel.BASE.name())).collect(Collectors.toList()));
            // retreive features with level 1 : child of parent modules
            firstLevelMenu.addAll(listMenu.getMenus().stream().filter(menu -> menu.getMenuPosition().getLevel().equals(ModuleLevel.FIRST.name())).collect(Collectors.toList()));
            // retreive features with level 2 : child of child of parent modules
            secondLevelMenu.addAll(listMenu.getMenus().stream().filter(menu -> menu.getMenuPosition().getLevel().equals(ModuleLevel.SECOND.name())).collect(Collectors.toList()));
            // retreive features with level 3 : child of child of child of parent modules
            thirdLevelMenu.addAll(listMenu.getMenus().stream().filter(menu -> menu.getMenuPosition().getLevel().equals(ModuleLevel.THIRD.name())).collect(Collectors.toList()));
        }

        // #############################################################
        List<FeatureModel> baseLevelfeatureModelList = new ArrayList<>();
        baseLevelMenu.forEach(menu -> baseLevelfeatureModelList.add(mapMenu(menu, null)));
        // save the base level into data base
        savedMenuHashMap.put(ModuleLevel.BASE.name(), featureService.saveAll(baseLevelfeatureModelList));
        // #############################################################
        List<FeatureModel> firstevelfeatureModelList = new ArrayList<>();
        firstLevelMenu.forEach(menu -> firstevelfeatureModelList.add(mapMenu(menu, ModuleLevel.BASE.name())));
        // save the first level into data base
        savedMenuHashMap.put(ModuleLevel.FIRST.name(), featureService.saveAll(firstevelfeatureModelList));
        // #############################################################
        List<FeatureModel> secondevelfeatureModelList = new ArrayList<>();
        secondLevelMenu.forEach(menu -> secondevelfeatureModelList.add(mapMenu(menu, ModuleLevel.FIRST.name())));
        // save the second level into data base
        savedMenuHashMap.put(ModuleLevel.SECOND.name(), featureService.saveAll(secondevelfeatureModelList));
        // #############################################################
        List<FeatureModel> thirdLevelfeatureModelList = new ArrayList<>();
        thirdLevelMenu.forEach(menu -> thirdLevelfeatureModelList.add(mapMenu(menu, ModuleLevel.SECOND.name())));
        // save the second level into data base
        savedMenuHashMap.put(ModuleLevel.THIRD.name(), featureService.saveAll(thirdLevelfeatureModelList));
        // #############################################################

        LOGGER.debug("[MenuLoader] load features in database finished in {} milliseconds", (System.currentTimeMillis() - startTime));
    }

    private FeatureModel mapMenu(Menu menu, String parentLevel) {
        FeatureModel featureModel = new FeatureModel();
        featureModel.setCode(menu.getName(menu.getBundle().getBundleName(), menu.getBundle().getBundleKey()));
        featureModel.setHtmlId(menu.getHtmlId());
        featureModel.setIcon(menu.getIcon());
        featureModel.setName(menu.getName(menu.getBundle().getBundleName(), menu.getBundle().getBundleKey()));
        featureModel.setDisplayedInMenu(menu.getEnabled());
        featureModel.setOrder(menu.getMenuPosition().getOrder());
        featureModel.setBundleName(menu.getBundle().getBundleName());
        featureModel.setBundleKey(menu.getBundle().getBundleKey());

        if (!BoUtils.isEmptyOrNull(menu.getPath())) {
            featureModel.setPath(menu.getPath());
        } else {
            featureModel.setPath("");
        }

        if (!BoUtils.isEmptyOrNull(parentLevel)) {
            featureModel.setParentFeature(retreiveParentFeature(menu.getParent(), parentLevel));
        }
        return featureModel;
    }

    private FeatureModel retreiveParentFeature(String parent, String parentLevel) {
        Optional<FeatureModel> parentFeatureModel = savedMenuHashMap.get(parentLevel).stream().filter(item -> item.getName().equals(parent)).findFirst();
        return (parentFeatureModel.orElse(null));
    }

    public static Map<String, ListMenu> getMenuHashMap() {
        return menuHashMap;
    }

    public static void setMenuHashMap(Map<String, ListMenu> menuHashMap) {
        MenuLoader.menuHashMap = menuHashMap;
    }
}