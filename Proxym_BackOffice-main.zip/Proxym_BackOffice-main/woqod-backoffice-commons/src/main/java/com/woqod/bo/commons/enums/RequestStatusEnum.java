package com.woqod.bo.commons.enums;

/**
 * User: Nasreddine.Jrebi
 * Date: 29/01/2019 11:32
 */
public enum RequestStatusEnum {

    TREATED("Treated"),
    CANCELED("Cancelled"),
    IN_PROGRESS("In Progress"),
    REJECTED("Rejected");

    private String desc;

    public String getDesc() {
        return desc;
    }

    RequestStatusEnum(String desc) {
        this.desc = desc;
    }
}
