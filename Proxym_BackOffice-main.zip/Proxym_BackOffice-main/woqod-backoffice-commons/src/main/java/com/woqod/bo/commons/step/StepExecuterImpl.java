package com.woqod.bo.commons.step;

import com.woqod.bo.commons.exceptions.AccessDeniedException;
import com.woqod.bo.commons.exceptions.RestBackendException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Slf4j
@Aspect
@Component
public class StepExecuterImpl {
    /**
     * Static attributs
     */
    public static final String STEP_EXECUTER_IMPL = "[ StepExecuterImpl ]";
    public static final String INFO = "INFO";
    public static final String ERROR_LEVEL = "ERROR";
    public static final String ERROR = "error";
    public static final String ACCESS = "access";
    public static final String ACCESS_DENIED = "ACCESS_DENIED";
    /**
     * BEANS
     */
    private final Step step;

    /**
     * @param step
     */
    @Autowired
    public StepExecuterImpl(Step step) {
        this.step = step;
    }

    @Around("@annotation(stepExecutor)")
    public void execute(ProceedingJoinPoint joinPoint, StepExecutor stepExecutor) throws Throwable {

        log.debug("{} start execute steps ", STEP_EXECUTER_IMPL);

        HashMap<String, Object> serviceData = (HashMap<String, Object>) joinPoint.getArgs()[0];

        try {
            // check if the user has the permission to do this action
            step.checkPermission(serviceData);
            joinPoint.proceed();
            if (stepExecutor.saveLog()) {
                // save success log request
                step.saveLog(Boolean.TRUE, serviceData, null);
            }
            // redirect if redirection is enabled
            if (stepExecutor.redirect()) {
                step.redirect(stepExecutor.redirectTo());
            }

        } catch (AccessDeniedException e) {
            // save access denied log if it enable
            if (stepExecutor.saveLog()) {
                // save log
                step.saveLog(false,
                        serviceData,
                        ACCESS_DENIED);
            }
            // redirect to access denied page
            step.redirect(ACCESS);
        } catch (RestBackendException e) {
            // save error log if it enable
            if (stepExecutor.saveLog()) {
                step.saveLog(Boolean.TRUE, serviceData, e.getTitleEn());
            }
            // show error pop up
        } catch (Exception e) {
            // save error log if it enable
            if (stepExecutor.saveLog()) {
                step.saveLog(Boolean.TRUE, serviceData, e.getMessage());
            }
            // redirect to error page
            step.redirect(ERROR);
        }
    }
}
