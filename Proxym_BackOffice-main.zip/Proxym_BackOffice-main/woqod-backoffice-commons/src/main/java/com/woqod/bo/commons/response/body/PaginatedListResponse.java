package com.woqod.bo.commons.response.body;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.woqod.bo.commons.response.GenericResponseBody;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.PagedModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * this class is used to render a list of objects response with pagination
 */
public class PaginatedListResponse<T extends Object> extends GenericResponseBody {
    private long size; // Total of elements
    private long count; // Total of pages
    private long page;
    @JsonProperty("result")
    private List<T> list;
    private PagedModel<T> pagedModel;

    public PaginatedListResponse() {
        super();
    }

    /**
     * @param size
     * @param count
     * @param page
     * @param list
     */
    public PaginatedListResponse(long size, long count, long page, List<T> list) {
        this.size = size;
        this.count = count;
        this.page = page;
        this.list = list != null ? list : new ArrayList<>();
    }

    public PaginatedListResponse(PagedModel<T> pagedModel, List<T> data) {
        this.pagedModel = pagedModel;
        PagedModel.PageMetadata metadata = pagedModel.getMetadata();
        if (metadata != null) {
            this.size = metadata.getTotalElements();
            this.count = metadata.getTotalPages();
            this.page = metadata.getNumber();
        }
        this.list = data != null ? data : new ArrayList<>();
    }

    /**
     * @return the count
     */
    public long getCount() {
        return count;
    }

    /**
     * @return the page
     */
    public long getPage() {
        return page;
    }

    /**
     * @return the size
     */
    public long getSize() {
        return size;
    }

    /**
     * @return the list
     */
    public List<T> getList() {
        return list != null ? list : new ArrayList<>();
    }


    public String getNextHref() {
        Optional<Link> link;

        if (pagedModel != null) {
            link = pagedModel.getLink("next");
            link.ifPresent(Link::getHref);

        }
        return null;
    }

    public String getPreviousHref() {
        Optional<Link> link;

        if (pagedModel != null) {
            link = pagedModel.getLink("prev");
            link.ifPresent(Link::getHref);

        }
        return null;
    }

    public String getFirstHref() {
        Optional<Link> link;

        if (pagedModel != null) {
            link = pagedModel.getLink("first");
            link.ifPresent(Link::getHref);

        }
        return null;
    }

    public String getLastHref() {
        Optional<Link> link;

        if (pagedModel != null) {
            link = pagedModel.getLink("last");
            link.ifPresent(Link::getHref);

        }
        return null;
    }

    public void setList(List<T> list) {
        this.list = list != null ? list : new ArrayList<>();
    }
}