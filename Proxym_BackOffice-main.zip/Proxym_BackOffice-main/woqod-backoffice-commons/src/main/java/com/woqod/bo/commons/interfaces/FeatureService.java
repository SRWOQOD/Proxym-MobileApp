package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.FeatureModel;

import java.util.List;

public interface FeatureService {
    List<FeatureModel> findAllParentByRole(String roleName);

    /**
     * save list of feature
     *
     * @param features
     */
    void save(List<FeatureModel> features);

    List<FeatureModel> saveAll(List<FeatureModel> featureModels);

    /**
     * save one feature
     *
     * @param feature
     */
    void save(FeatureModel feature);

    /**
     * get all features
     *
     * @return
     */
    List<FeatureModel> getFeatures();

    /**
     * delete list of features
     *
     * @param features
     * @return
     */
    Boolean delete(List<FeatureModel> features);

    /**
     * update list of features
     *
     * @param features
     */
    void update(List<FeatureModel> features);

    /**
     * retrieve list of feature parent
     *
     * @param feature
     * @return
     */
    List<FeatureModel> findByParent(FeatureModel feature);

    /**
     * used to retrieve feature bu code
     *
     * @param code
     * @return
     */
    FeatureModel findOneByCode(String code);


    /**
     * Used to retrieve Feature  by name
     *
     * @return
     */
    FeatureModel findOneByName(String name);

    /**
     * used to retrive feature by role name
     *
     * @param role
     * @return
     */
    List<FeatureModel> findAllParent(String role);


}
