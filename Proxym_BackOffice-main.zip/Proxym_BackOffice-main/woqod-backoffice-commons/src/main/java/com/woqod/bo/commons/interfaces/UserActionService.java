package com.woqod.bo.commons.interfaces;

import com.woqod.bo.commons.model.UserActionModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

public interface UserActionService {

    /**
     * used to get user actions filtred and paginated
     *
     * @param userAction
     * @param pageable
     * @param start
     * @param end
     * @return
     */
    Page<UserActionModel> getFilteredUserAction(UserActionModel userAction, Pageable pageable, LocalDate start, LocalDate end);

    /**
     * used to save user action
     *
     * @param userAction
     */
    void saveUserAction(UserActionModel userAction);

    /**
     * get all action names
     *
     * @return
     */
    List<String> findAllActions();

    Long count();
}
