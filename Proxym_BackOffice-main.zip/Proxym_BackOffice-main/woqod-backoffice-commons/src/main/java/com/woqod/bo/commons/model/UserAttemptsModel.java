package com.woqod.bo.commons.model;

import java.time.LocalDate;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
public class UserAttemptsModel {
    private Long id;

    private String username;

    private Long attempts;

    private LocalDate lastModified;

    public UserAttemptsModel() {
    }

    public UserAttemptsModel(String username, Long attempts, LocalDate lastModified) {
        this.username = username;
        this.attempts = attempts;
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }

    public UserAttemptsModel(Long id, String username, Long attempts, LocalDate lastModified) {
        this.id = id;
        this.username = username;
        this.attempts = attempts;
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getAttempts() {
        return attempts;
    }

    public void setAttempts(Long attempts) {
        this.attempts = attempts;
    }

    public LocalDate getLastModified() {
        return lastModified != null ? LocalDate.now() : null;
    }

    public void setLastModified(LocalDate lastModified) {
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }


}
