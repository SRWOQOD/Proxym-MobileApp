package com.woqod.bo.commons.restclient;


import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.GenericResponseBody;
import com.woqod.bo.commons.response.GenericResponseHeader;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.Objects;

@Component
public class CustomRestTemplate {

    // Create a Rest template
    private final RestTemplate restTemplate = RestTemplateBuilder.build();

    public BooleanResponse getBooleanResponse(String uri) {
        return (BooleanResponse) getGenericResponseBody(uri, new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
        });
    }

    public <T> ListResponse<T> getListResponse(String uri, Map<String, String> filters) {
        if (filters != null) {
            uri += filtersToUri(filters);
        }
        return (ListResponse<T>) getGenericResponseBody(uri, new ParameterizedTypeReference<GenericResponse<ListResponse<T>>>() {
        });
    }


    public <T> void delete(String uri) {
        HttpEntity<T> httpEntity = new HttpEntity<>(RestTemplateBuilder.getHeaders());
        HttpEntity<GenericResponse> genericResponse = restTemplate.exchange(uri, HttpMethod.DELETE, httpEntity, GenericResponse.class);
        testHeader(Objects.requireNonNull(genericResponse.getBody()).getHeader());
    }

    public <T, R extends GenericResponseBody> GenericResponseBody postObjectGetGenericResponseBody(String uri, T obj, ParameterizedTypeReference<GenericResponse<R>> typeReference) {
        HttpEntity<T> httpEntity = new HttpEntity<>(obj, RestTemplateBuilder.getHeaders());
        HttpEntity<GenericResponse<R>> responseHttpEntity = restTemplate.exchange(uri, HttpMethod.POST, httpEntity, typeReference);
        testHeader(Objects.requireNonNull(responseHttpEntity.getBody()).getHeader());
        return responseHttpEntity.getBody().getBody();
    }

    public <T, R extends GenericResponseBody> GenericResponseBody putObjectGetGenericResponseBody(String uri, T obj, ParameterizedTypeReference<GenericResponse<R>> typeReference) {
        HttpEntity<T> httpEntity = new HttpEntity<>(obj, RestTemplateBuilder.getHeaders());
        HttpEntity<GenericResponse<R>> responseHttpEntity = restTemplate.exchange(uri, HttpMethod.PUT, httpEntity, typeReference);
        testHeader(Objects.requireNonNull(responseHttpEntity.getBody()).getHeader());
        return responseHttpEntity.getBody().getBody();
    }

    public <T extends GenericResponseBody> GenericResponseBody getGenericResponseBody(String uri, ParameterizedTypeReference<GenericResponse<T>> typeReference) {
        HttpEntity<String> httpEntity = new HttpEntity<>(RestTemplateBuilder.getHeaders());
        ResponseEntity<GenericResponse<T>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, httpEntity, typeReference);
        GenericResponse<T> genericResponse = responseEntity.getBody();
        testHeader(Objects.requireNonNull(genericResponse).getHeader());
        return genericResponse.getBody();
    }

    public <T, R extends GenericResponseBody> GenericResponseBody deleteObjectGetGenericResponseBody(String uri, T obj, ParameterizedTypeReference<GenericResponse<R>> typeReference) {
        HttpEntity<T> httpEntity = new HttpEntity<>(obj, RestTemplateBuilder.getHeaders());
        HttpEntity<GenericResponse<R>> responseHttpEntity = restTemplate.exchange(uri, HttpMethod.DELETE, httpEntity, typeReference);
        testHeader(Objects.requireNonNull(responseHttpEntity.getBody()).getHeader());
        return responseHttpEntity.getBody().getBody();
    }

    public <T, R extends GenericResponseBody> GenericResponseBody deleteObjectGetGenericResponse(String uri, ParameterizedTypeReference<GenericResponse<R>> typeReference) {
        HttpEntity<T> httpEntity = new HttpEntity<>(RestTemplateBuilder.getHeaders());
        HttpEntity<GenericResponse<R>> responseHttpEntity = restTemplate.exchange(uri, HttpMethod.DELETE, httpEntity, typeReference);
        testHeader(Objects.requireNonNull(responseHttpEntity.getBody()).getHeader());
        return responseHttpEntity.getBody().getBody();
    }

    public void testHeader(GenericResponseHeader genericResponseHeader) {

        if (!genericResponseHeader.getStatusCode().equals("000")) {
            throw new RestBackendException(genericResponseHeader);
        }
    }

    public String filtersToUri(Map<String, String> filters) {
        String params = "";
        if (filters.isEmpty()) {
            boolean first = true;
            StringBuilder buf = new StringBuilder();
            for (Map.Entry<String, String> entry : filters.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (first) {
                    buf.append("?").append(key).append("=").append(value);
                    first = false;
                } else {
                    buf.append("&").append(key).append("=").append(value);
                }
            }
            params = buf.toString();
        }
        return params;
    }
}