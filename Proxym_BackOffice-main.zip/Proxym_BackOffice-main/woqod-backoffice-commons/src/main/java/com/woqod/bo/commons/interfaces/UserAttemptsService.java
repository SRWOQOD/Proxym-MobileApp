package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.UserAttemptsModel;

public interface UserAttemptsService {

    /**
     * used to increment by 1 user attemts
     *
     * @param username
     */
    void updateFailAttempts(String username);

    /**
     * used to reset user attempts
     *
     * @param username
     */
    void resetFailAttempts(String username);

    /**
     * used to retrieve user attempts by username
     */
    UserAttemptsModel getUserAttempts(String username);
}
