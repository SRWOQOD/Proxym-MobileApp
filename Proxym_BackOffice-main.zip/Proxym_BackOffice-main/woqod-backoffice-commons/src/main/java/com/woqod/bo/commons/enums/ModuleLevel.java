package com.woqod.bo.commons.enums;

public enum ModuleLevel {

    BASE,
    FIRST,
    SECOND,
    THIRD

}
