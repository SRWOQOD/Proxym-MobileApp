package com.woqod.bo.commons.enums;


import com.woqod.bo.commons.constant.CommonsConstant;

import java.util.Arrays;
import java.util.Optional;

/**
 * User: Nasreddine.Jrebi
 * Date: 26/11/2018 12:03
 */
public enum ParentModuleEnum implements Menu {


//    DASHBOARD_MANAGEMENTS(
//            CommonsConstant.BUNDLE_NAME,
//            "",
//            "",
//            "fas fa-chart-line",
//            "",
//            false,
//            null,
//            ModuleLevel.BASE.name(),
//            1L),

    DASHBOARD_MANAGEMENTS(new Bundle(
            CommonsConstant.BUNDLE_NAME,
            "dashboard"),
            "",
            "fas fa-chart-line",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    2L)),
    USER_MANAGEMENT(new Bundle(
            CommonsConstant.BUNDLE_NAME,
            "userManagementmsg"),
            "",
            "fa fa-fw fa-user",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    3L)),
    ROLE_MANAGEMENT(new Bundle(
            CommonsConstant.BUNDLE_NAME,
            "roleManagementParentModule"),
            "",
            "fa fa-fw fa-sitemap",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    4L)),
    //    DISCOUNT_MANAGEMENT(CommonsConstant.BUNDLE_NAME,
//            "BoDiscountManagement",
//            "",
//            "fa fa-money-check-alt",
//            CommonsConstant.OM_NAME,
//            true,
//            null,
//            ModuleLevel.BASE.name(),
//            4L),
    TOPUP(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoTopUp"),
            "",
            "icon-woqode",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    5L)),

    AMOUNT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoAmount"),
            "",
            "fas fa-sort-numeric-down",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    6L)),
    FAHES(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoFahes"),
            "",
            "icon-fahes",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    7L)),
    FEEDBACK_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoFeedbackManagement"),
            "",
            "fa fa-comments",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    9L)),
    LOGS_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoLogs"),
            "",
            "far fa-newspaper",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    10L)),

    SURVEY_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoSurvey"),
            "",
            "fas fa-poll-h",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    11L)),
/*    TAG_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoTagManagements"),
            "",
            "fa fa-tag",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    12L)),*/

    CONTENT_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoContentManagement"),
            "",
            "fas fa-blender-phone",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    13L)),
    PUSH_NOTIF_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "notification"),
            "",
            "fas fa-bell",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    14L)),
        EXPORT_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
                "export"),
                "",
                "fas fa-chart-area",
                CommonsConstant.OM_NAME,
                true,
                null,
                new MenuPosition(ModuleLevel.BASE.name(),
                        16L)),
//    DYNAMIC_HOME(new Bundle(CommonsConstant.BUNDLE_NAME,
//            "DisplayHome"),
//            "",
//            "fas fa-chart-area",
//            CommonsConstant.OM_NAME,
//            true,
//            null,
//            new MenuPosition(ModuleLevel.BASE.name(),
//                    17L)),
//    TEXT_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
//            "AboutManagement"),
//            "",
//            "fas fa-text-width",
//            CommonsConstant.OM_NAME,
//            true,
//            null,
//            new MenuPosition(ModuleLevel.BASE.name(),
//                    18L)),
    AREA_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoAreaManagements"),
            "",
            "fas fa-map-marker",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    19L)),
    RESERVATION_MANAGEMENT(new Bundle(CommonsConstant.BUNDLE_NAME,
            "BoReservationManagements"),
            "",
            "fas fa-ticket-alt",
            CommonsConstant.OM_NAME,
            true,
            null,
            new MenuPosition(ModuleLevel.BASE.name(),
                    20L));

    ParentModuleEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<ParentModuleEnum> menu = Arrays.stream(ParentModuleEnum.values()).filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.map(Enum::name).orElse(""));
    }


}
