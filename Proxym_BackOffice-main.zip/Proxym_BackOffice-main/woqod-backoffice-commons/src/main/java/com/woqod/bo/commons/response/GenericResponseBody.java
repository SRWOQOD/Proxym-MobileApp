package com.woqod.bo.commons.response;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type", visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = BooleanResponse.class, name = "BOOLEAN_RESPONSE"),
        @JsonSubTypes.Type(value = ListResponse.class, name = "LIST_RESPONSE"),
        @JsonSubTypes.Type(value = ObjectResponse.class, name = "OBJECT_RESPONSE"),
        @JsonSubTypes.Type(value = PaginatedListResponse.class, name = "PAGINATED_LIST_RESPONSE")}
)
public abstract class GenericResponseBody {
}
