package com.woqod.bo.commons.enums;

public interface Menu {

    String getName(String bundleName, String bundleKey);

    String getPath();

    String getIcon();

    String getHtmlId();

    Boolean getEnabled();

    String getParent();

    Bundle getBundle();

    MenuPosition getMenuPosition();
}
