package com.woqod.bo.commons.utils;

public final class UtilsConstants {

    public static final String ERROR_OCCURRED_WHEN_LOADING_DATA = "error occurred when loading ";

    public static final String DISABLE_ICON = "fa fa-power-off";
    public static final String ENABLE_ICON = "fa fa-check";

    public static final String EMPTY_FILE_ICON = "far fa-file";
    public static final String FULL_FILE_ICON = "fas fa-pencil-alt";

    public static final String POST_DATA = "postData";
    public static final String OLD_DATA = "oldData";

    public static final String FEATURE = "feature";

    public static final String AR = "ar";
    public static final String EN = "en";
    public static final String FR = "fr";


    //    ########################## start bundle names ##################################
    public static final String COMMON_MESSAGES_BUNDLE_NAME = "common_messages";
    //    ########################## end bundle names ##################################

    //    ########################## start bundle keys ##################################
    public static final String ENABLED_BUNDLE_KEY = "enabled";
    public static final String DISABLED_BUNDLE_KEY = "disabled";

    public static final String ENABLE_BUNDLE_KEY = "enable";
    public static final String DISABLE_BUNDLE_KEY = "disable";


    public static final String REQUEST_FINISH_WITH_SUCCESS_BUNDLE_KEY = "requestFinishWithSuccess";
    public static final String REQUEST_FINISH_WITH_FAILURE_BUNDLE_KEY = "requestFinishWithFailure";

    public static final String YES_BUNDLE_KEY = "yes";
    public static final String NO_BUNDLE_KEY = "no";
    //    ########################## end bundle keys ##################################

    private UtilsConstants() {
    }
}
