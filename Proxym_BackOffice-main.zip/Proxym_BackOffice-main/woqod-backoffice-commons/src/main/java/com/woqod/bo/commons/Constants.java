package com.woqod.bo.commons;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:34m
 */
public final class Constants {
    public static final String BO_ACTION = "bo_action_new";
    public static final String BO_AUTHORITY = "bo_authority_new";
    public static final String BO_FEATURE = "bo_feature_new";
    public static final String BO_FEATURE_ROLE = "bo_feature_role_new";
    public static final String BO_ROLE = "bo_role_new";
    public static final String BO_USER = "bo_user_new";
    public static final String BO_USER_ATTEMPTS = "bo_user_attempts_new";
    public static final String BO_USER_ACTION = "bo_user_action_new";
    public static final String BO_ACCESS_LOGS = "bo_access_logs";

    private Constants() {
    }

}
