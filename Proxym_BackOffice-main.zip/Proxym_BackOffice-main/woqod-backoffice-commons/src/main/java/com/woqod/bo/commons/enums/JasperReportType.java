package com.woqod.bo.commons.enums;

public enum JasperReportType {
    CSV,
    PDF,
    EXCEL
}
