package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:33
 */
public class AccessDataException extends ProxymException {


    private static final long serialVersionUID = 1L;

    public AccessDataException(ProxymError error, String key, Throwable exception) {
        super(error, exception, key);
        this.key = key;
    }


}
