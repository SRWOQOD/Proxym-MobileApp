package com.woqod.bo.commons.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
@Data
@NoArgsConstructor
public class UserActionModel {
    private long id;
    private String username;
    private Boolean isSuccess;
    private LocalDate actionDate;
    private String action;
    private String firstName;
    private String ipAddress;
    private String oldData;
    private String role;
    private String actionData;
    private String exceptionData;


    public static Builder newBuilder() {
        return new Builder();
    }

    public UserActionModel(Builder builder) {
        if (builder.id != null) {
            this.id = builder.id;
        }
        this.username = builder.username;
        this.isSuccess = builder.isSuccess;
        this.actionDate = builder.actionDate;
        this.firstName = builder.firstName;
        this.ipAddress = builder.ipAddress;
        this.oldData = builder.oldData;
        this.role = builder.role;
        this.actionData = builder.actionData;
        this.action = builder.action;
        this.exceptionData = builder.exceptionData;
    }

    public static class Builder {
        private Long id;
        private String username;
        private String firstName;
        private String ipAddress;
        private String oldData;
        private String role;
        private Boolean isSuccess;
        private String action;
        private String actionData;
        private LocalDate actionDate;
        private String exceptionData;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder id(long id) {
            this.id = id;
            return this;
        }

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder actionData(String actionData) {
            this.actionData = actionData;
            return this;
        }

        public Builder oldData(String oldData) {
            this.oldData = oldData;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Builder ipAddress(String ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }

        public Builder exceptionData(String exceptionData) {
            this.exceptionData = exceptionData;
            return this;
        }

        public Builder isSuccess(Boolean isSuccess) {
            this.isSuccess = isSuccess;
            return this;
        }

        public Builder action(String action) {
            this.action = action;
            return this;
        }

        public Builder actionDate(LocalDate actionDate) {
            this.actionDate = actionDate != null ? LocalDate.now() : null;
            return this;
        }

        public UserActionModel build() {
            return new UserActionModel(this);
        }

    }
}
