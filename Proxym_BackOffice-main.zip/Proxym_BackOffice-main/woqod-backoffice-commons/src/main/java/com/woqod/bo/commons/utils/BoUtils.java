package com.woqod.bo.commons.utils;


import com.google.common.base.Strings;
import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.model.Translation;
import com.woqod.bo.commons.model.UserActionModel;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.primefaces.model.SortOrder;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;


/**
 * User: Nasreddine.Jrebi
 * Date: 29/11/2018 17:48
 */
@Slf4j
@Component
@Scope(value = "session")
public class BoUtils {

    private static final ModelMapper modelMapper = new ModelMapper();
    private static final String LANG = "language";
    private static final String SESSION_FILTERS = "SESSION_FILTERS";

    public static String getLocale() {
        String language = "fr";
        HttpSession session = getSession();
        if (session != null) {
            language = (String) session.getAttribute(LANG);
            if (BoUtils.isEmptyOrNull(language)) {
                session.setAttribute(LANG, "fr");
            }
        }
        return language;
    }

    public static void setLocale(String locale) {
        HttpSession session = getSession();
        if (!BoUtils.isEmptyOrNull(locale)) {
            session.setAttribute(LANG, locale);
        } else {
            session.setAttribute(LANG, "fr");
        }
    }

    public static String retreiveByBundleNameAndBundleKey(String resourceBundleName, String resourceBundleKey) {
        try {
            Locale locale = new Locale(getLocale());
            ResourceBundle bundle = ResourceBundle.getBundle(resourceBundleName, locale);
            return bundle.getString(resourceBundleKey);
        } catch (RuntimeException e) {
            log.error(e.getMessage());
            return "";
        }
    }

    public void redirect(String path) throws IOException {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        externalContext.redirect(path);
    }


    /**
     * show error popup in the view
     *
     * @param summary
     * @param message
     */
    public static void showErrorPopup(String summary, String message) {
        if (FacesContext.getCurrentInstance() != null) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, message);
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

    /**
     * @param bundelName
     * @param summaryKey
     * @param messageKey
     */
    public static void errorPopup(String bundelName, String summaryKey, String messageKey) {
        if (FacesContext.getCurrentInstance() != null) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, retreiveByBundleNameAndBundleKey(bundelName, summaryKey), retreiveByBundleNameAndBundleKey(bundelName, messageKey));
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }


    /**
     * show Info popup in the view
     *
     * @param summary
     * @param message
     */
    public static void showInfoPopup(String summary, String message) {
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                summary, message);
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, msg);
        context.getExternalContext().getFlash().setKeepMessages(true);
    }

    public static void showsuccesspopup() {
        String summary = retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.REQUEST_FINISH_WITH_SUCCESS_BUNDLE_KEY);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                summary, "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    public static void showFailurePopup() {
        String summary = retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.REQUEST_FINISH_WITH_FAILURE_BUNDLE_KEY);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                summary, "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    /**
     * show success popup in the view
     *
     * @param summary
     * @param message
     */
    public static void showSuccessPopup(String summary, String message) {
        if (FacesContext.getCurrentInstance() != null) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, message);
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

    /**
     * Save Log in the DB Async
     *
     * @param isSuccess
     * @param action
     * @param actionData
     * @param userActionService
     * @param exception
     */
    public static void saveLog(Boolean isSuccess, String action, String actionData, UserActionService userActionService, String exception) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserActionModel userAction = UserActionModel.newBuilder()
                .username(authentication.getName())
                .isSuccess(isSuccess)
                .actionDate(LocalDate.now())
                .actionData(actionData)
                .exceptionData(exception)
                .action(action)
                .build();

        userActionService.saveUserAction(userAction);
    }

    /**
     * map list of translation object to hashmap
     */
    public static Map<String, String> mapListToMap(List<Translation> list) {
        Map<String, String> map = new HashMap<>();
        list.forEach(item -> map.put(item.getKey(), item.getValue()));
        return map;
    }

    public static Map<String, String> mapListToHashMap(List<Translation> list) {
        Map<String, String> map = new HashMap<>();
        list.forEach(item -> map.put(item.getKey(), item.getValue()));
        return map;
    }


    public static boolean isEmptyOrNull(String strValue) {
        return strValue == null || strValue.trim().length() == 0;
    }


    /**
     * get available session
     *
     * @return
     */
    public static HttpSession getSession() {
        Object object = RequestContextHolder.currentRequestAttributes();
        // initiate http session if request initiated by spring we will get session from spring else we will get it from JSF
        if (object instanceof ServletRequestAttributes) {
            ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            return attr.getRequest().getSession(true);
        } else {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            return (HttpSession) facesContext.getExternalContext().getSession(false);
        }
    }


    public static String formatDate(Date date) {
        if (date != null) {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return formatter.format(date);
        } else {
            return null;
        }
    }


    public static String formatDate(Date date, String format) {
        if (date != null) {
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            return formatter.format(date);
        } else {
            return null;
        }
    }


    public static String retreiveSortBehaviour(String sortField, String sortOrder) {
        if (BoUtils.isEmptyOrNull(sortOrder)) {
            sortOrder = "desc";
        } else {
            if (sortOrder.equals("ASCENDING")) {
                sortOrder = "asc";
            } else {
                sortOrder = "desc";
            }
        }
        return sortField.concat(",").concat(sortOrder);
    }

    public static String retreiveSortBehaviour(String sortField) {
        return sortField.concat(",").concat("desc");
    }

    public static Map<String, String> retreivebasicUriParametersForLazyLoading(String sortField, SortOrder sortOrder, int first, int pageSize) {

        Map<String, String> uriParams = new HashMap<>();

        if (!BoUtils.isEmptyOrNull(sortField)) {
            uriParams.put("sort", BoUtils.retreiveSortBehaviour(sortField, sortOrder.name()));
        }
        uriParams.put("page", String.valueOf(first / pageSize));
        uriParams.put("size", String.valueOf(pageSize));
        return uriParams;
    }


    public static Map<String, String> retreivebasicUriParametersForLazyLoading(String sortField, int first, int pageSize) {

        Map<String, String> uriParams = new HashMap<>();

        if (!BoUtils.isEmptyOrNull(sortField)) {
            uriParams.put("sort", BoUtils.retreiveSortBehaviour(sortField));
        }
        uriParams.put("page", String.valueOf(first / pageSize));
        uriParams.put("size", String.valueOf(pageSize));
        return uriParams;
    }

    /**
     * this method is used to retreive time under format HH:mm
     * note that the format retreive from the primefaces component is E MMM dd HH:mm:ss Z yyyy
     * exemple Thu Jan 01 02:17:00 WAT 1970
     *
     * @param dateAsString
     * @return
     */
    public static String retreiveTimeAsString(String dateAsString) {
        try {
            DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
            Date date = formatter.parse(dateAsString);
            DateFormat formatt = new SimpleDateFormat("HH:mm");
            return formatt.format(date);
        } catch (ParseException e) {
            return "";
        }
    }


    public static <T, R> R copyProperties(T t, R r) {
        modelMapper.map(t, r);
        return r;
    }


    public static String getIpHostAddress() {
        String ipHost = "";
        try {
            ipHost = InetAddress.getLocalHost().toString();
        } catch (UnknownHostException e) {
            log.error(e.getMessage());
        }
        return ipHost;
    }

    public static String randomPassword(String username) {
        final String pass = randomUsername();
        log.info("random password generated" + pass + " for user : " + username);
        return pass;

    }

    public static String randomUsername() {
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@";

        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();


        for (int i = 0; i < 12; i++) {
            int randomIndex = random.nextInt(chars.length());
            sb.append(chars.charAt(randomIndex));
        }
        return sb.toString();

    }

    public static int setIndex(int rowIndex, int page) {
        if (rowIndex == -1 || page == 0) {
            return -1;
        } else {
            return (rowIndex % page);
        }

    }

    public static void setSessionFilter(HttpSession session,String serviceName, Object filter) {
        Map<String,Object> sessionFilters = (Map<String,Object>) session.getAttribute(SESSION_FILTERS);

        if(sessionFilters == null) {
            sessionFilters = new HashMap<>();
        }

        sessionFilters.put(serviceName, filter);
        session.setAttribute(SESSION_FILTERS , sessionFilters);
    }

    public static Object getSessionFilter(HttpSession session,String serviceName) {
        Map<String,Object> sessionFilters = (Map<String,Object>) session.getAttribute(SESSION_FILTERS);

        if(sessionFilters == null) {
            return null;
        }

        return  sessionFilters.get(serviceName);
    }

    public static void clearSessionFilter(HttpSession session, String serviceName) {

        Map<String,Object> sessionFilters = (Map<String,Object>) session.getAttribute(SESSION_FILTERS);

        if(sessionFilters != null) {
            sessionFilters.keySet().removeIf(key -> !key.equals(serviceName));
        }
    }

    public static String decodeFromBase64(String data) {
        if (!Strings.isNullOrEmpty(data)) {
            return new String(Base64.getDecoder().decode(data));
        }
        return data;
    }

}
