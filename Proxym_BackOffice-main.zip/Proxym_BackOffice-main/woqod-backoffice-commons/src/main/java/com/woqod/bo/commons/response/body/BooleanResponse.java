package com.woqod.bo.commons.response.body;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.woqod.bo.commons.response.GenericResponseBody;

/**
 * this class is used to render a boolean response
 *
 * @author Radhouene
 */
public class BooleanResponse extends GenericResponseBody {
    @JsonProperty(value = "result")
    private boolean success;

    public BooleanResponse() {
        super();
    }

    public BooleanResponse(boolean success) {
        this.success = success;
    }

    public boolean isSuccess() {
        return success;
    }

}
