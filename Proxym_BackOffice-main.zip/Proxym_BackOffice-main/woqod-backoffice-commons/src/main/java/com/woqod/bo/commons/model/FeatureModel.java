package com.woqod.bo.commons.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
@Data
public class FeatureModel {


    private String code;

    private String bundleName;

    private String bundleKey;

    private String designation;

    private String name;

    private String path;

    private String icon;

    private String htmlId;

    private Long order;

    private boolean displayedInMenu;

    private FeatureModel parentFeature;

    private List<FeatureModel> childrenFeatures = new ArrayList<>();

    private List<ActionModel> actions = new ArrayList<>();

    private List<FeatureRoleModel> featureRoles = new ArrayList<>();

    public FeatureModel(String code, String bundleName, String bundleKey, String designation, String path, FeatureModel parentFeature, List<FeatureModel> childrenFeatures,
                        List<ActionModel> actions) {
        super();
        this.code = code;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.designation = designation;
        this.path = path;
        this.parentFeature = parentFeature;
        this.childrenFeatures = childrenFeatures != null ? childrenFeatures : new ArrayList<>();
        this.actions = actions;
    }

    public FeatureModel(String code, String bundleName, String bundleKey, String designation, String name, String path, List<FeatureModel> childrenFeatures, String icon, String htmlId, Long order, boolean displayedInMenu) {
        super();
        this.code = code;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.designation = designation;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.name = name;
        this.childrenFeatures = childrenFeatures != null ? childrenFeatures : new ArrayList<>();
        this.order = order;
        this.displayedInMenu = displayedInMenu;

    }


    public FeatureModel(String code, String name, String designation, String bundleName, String bundleKey, String path, FeatureModel parentFeature) {
        super();
        this.code = code;
        this.name = name;
        this.designation = designation;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.path = path;
        this.parentFeature = parentFeature;
    }


    public FeatureModel(String code, String name, String designation, String bundleName, String bundleKey, String path, List<FeatureModel> childrenFeatures, List<ActionModel> actions) {
        super();
        this.code = code;
        this.name = name;
        this.designation = designation;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.path = path;
        this.childrenFeatures = childrenFeatures != null ? childrenFeatures : new ArrayList<>();
        this.actions = actions;
    }

    public FeatureModel() {
        super();
    }

    public FeatureModel(String code, String name, String designation, String bundleName, String bundleKey) {
        super();
        this.code = code;
        this.name = name;
        this.designation = designation;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
    }

    public FeatureModel(String code, String name) {
        super();
        this.code = code;
        this.name = name;
    }


}
