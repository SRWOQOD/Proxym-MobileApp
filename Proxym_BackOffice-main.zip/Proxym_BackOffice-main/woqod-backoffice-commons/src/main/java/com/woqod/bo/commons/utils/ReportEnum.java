package com.woqod.bo.commons.utils;

public enum ReportEnum {
    SURVEY("Survey"),
    USERS_MANAGEMENT("Users Management"),
    WOQODE_TRANSACTION("WOQODe Transaction"),
    FAHES_TRANSACTION("FAHES Transactions"),
    WOQODE_REQUEST_FOR_TAG("WOQODe Requests for tag"),
    NO_SELECTED_SERVICE("SELECT SERVICE NAME"),
    FAHES_BOOKING("FAHES Booking");

    private String description;

    ReportEnum(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

}
