package com.woqod.bo.commons.utils;

import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportResource {
    private String qid;
    private String phone;
    private String requestId;
    private String transactionUUID;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate creationDate;
    private String referenceNumber;
    private String transactionID;
    private String rpsStatus;
    private String apiStatus;
    private String email;
    private String username;
    private String  userStatus;
    private Boolean isWoqodeUser;
    private String surveyStatus;
    private String fahesBookingStatus;
    private String surveyTitle;
    private String plateNumber;
}
