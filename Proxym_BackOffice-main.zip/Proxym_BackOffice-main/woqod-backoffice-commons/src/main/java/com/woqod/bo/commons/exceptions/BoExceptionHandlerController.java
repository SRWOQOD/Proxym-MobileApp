package com.woqod.bo.commons.exceptions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;

/**
 * Created by nasreddine.jrebi on 16-mars-17. This class used to handle
 * exception in the BO exception in order to redirect
 */
@ControllerAdvice
@Slf4j
public class BoExceptionHandlerController extends ResponseEntityExceptionHandler {


    private static final String ERROR = "/error";

    /**
     * handle rest backedn exception
     *
     * @param e
     * @return
     */
    @ExceptionHandler(RestBackendException.class)
    public ModelAndView handleRestBackendExceptionExceptions(RestBackendException e) {
        log.debug("Error backend {}", e.getDescription());
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName(ERROR);
        return modelView;
    }


    /**
     * handle IOException
     *
     * @param e
     * @return
     */
    @ExceptionHandler(IOException.class)
    public ModelAndView handleIOExceptionExceptions(IOException e) {
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName(ERROR);
        return modelView;
    }

    /**
     * Handle Access Denied Exception
     *
     * @param e
     * @return
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ModelAndView handleAccessDeniedExceptions(AccessDeniedException e) {
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName("/access");
        return modelView;
    }


    /**
     * Handle other type of exception
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView badRequesthandler(Exception ex) {
        log.debug(ex.getMessage());
        ModelAndView modelView = new ModelAndView();
        modelView.setViewName(ERROR);
        return modelView;
    }
}
