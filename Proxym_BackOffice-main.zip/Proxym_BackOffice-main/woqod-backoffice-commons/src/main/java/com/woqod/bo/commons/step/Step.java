package com.woqod.bo.commons.step;

import java.util.HashMap;

public interface Step {

    void checkPermission(HashMap<String, Object> serviceData);

    void saveLog(Boolean isSuccess, HashMap<String, Object> data, String exception);

    String retrievePostDataAsString(HashMap<String, Object> serviceData);

    String retrieveOldDataAsString(Object oldData);

    void redirect(String uri);

    void showPopup(String level, String sumary, String msg);
}