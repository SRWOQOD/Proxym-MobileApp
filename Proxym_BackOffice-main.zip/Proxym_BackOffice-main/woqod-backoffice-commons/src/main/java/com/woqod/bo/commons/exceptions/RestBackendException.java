package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.response.GenericResponseHeader;

/**
 * User: Nasreddine.Jrebi
 * Date: 26/11/2018 09:12
 */
public class RestBackendException extends RuntimeException {

    private String code;
    private String description;
    private String providerCode;
    private String providerDescription;
    private String titleEn;
    private String titleAr;
    private String[] errors;

    public RestBackendException(String message) {
        super(message);
    }

    public RestBackendException(GenericResponseHeader genericResponseHeader) {
        this.code = genericResponseHeader.getStatusCode();
        this.description = genericResponseHeader.getDescription();
        this.providerCode = genericResponseHeader.getProviderCode();
        this.providerDescription = genericResponseHeader.getProviderDescription();
        this.errors = genericResponseHeader.getErrors();
        this.titleAr = genericResponseHeader.getTitleAR();
        this.titleEn = genericResponseHeader.getTitleEN();
    }

    // Getters & Setters
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderDescription() {
        return providerDescription;
    }

    public void setProviderDescription(String providerDescription) {
        this.providerDescription = providerDescription;
    }

    public String[] getErrors() {
        return errors != null ? errors : new String[]{};
    }

    public void setErrors(String[] errors) {
        this.errors = errors != null ? errors : new String[]{};
    }

    public String getTitleEn() {
        return titleEn;
    }

    public void setTitleEn(String titleEn) {
        this.titleEn = titleEn;
    }

    public String getTitleAr() {
        return titleAr;
    }

    public void setTitleAr(String titleAr) {
        this.titleAr = titleAr;
    }

}
