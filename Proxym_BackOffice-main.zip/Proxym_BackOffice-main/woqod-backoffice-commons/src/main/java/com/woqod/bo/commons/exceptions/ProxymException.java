package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;
import com.woqod.bo.commons.enums.MessagesTypeEnum;


/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:16
 */
public class ProxymException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private  ProxymError error;
    private  String[] tokens;
    private String originalMessage;
    private Throwable exception;
    protected String key;
    protected String errorMsg;
    private MessagesTypeEnum messagesType;


    public ProxymException(ProxymError error, Throwable exception, String... tokens) {
        super(exception);
        this.originalMessage = exception.getMessage();
        this.error = error;
        this.exception = exception;
        this.tokens = tokens != null ? tokens : new String[]{};
        this.key = null;
    }

    public ProxymException(ProxymError error, String... tokens) {
        super();
        this.error = error;
        this.tokens = tokens != null ? tokens : new String[]{};
    }

    public String getOriginalMessage() {
        return originalMessage;
    }

    public String getKey() {
        return key;
    }

    public Throwable getException() {
        return exception;
    }

    public String getCode() {
        return error.getCode();
    }


    public String getErrorMsg() {
        return errorMsg != null ? error.getMsgEN(tokens) : errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }


    public String[] getTokens() {
        return tokens != null ? tokens : new String[]{};
    }

    public void setTokens(String[] tokens) {
        this.tokens = tokens != null ? tokens : new String[]{};
    }


    public MessagesTypeEnum getMessagesType() {
        return messagesType;
    }

    public void setMessagesType(MessagesTypeEnum messagesType) {
        this.messagesType = messagesType;
    }

}
