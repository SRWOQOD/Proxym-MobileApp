package com.woqod.bo.commons.utils;


import org.apache.commons.lang3.BooleanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "session")
public class ViewUtils {

    public String retreiveByBundleNameAndBundleKey(String resourceBundleName, String resourceBundleKey) {
        return BoUtils.retreiveByBundleNameAndBundleKey(resourceBundleName, resourceBundleKey);
    }

    public String retreiveStatusValue(Boolean enabled) {
        if (enabled == null) {
            return "";
        } else if (enabled) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.ENABLED_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.DISABLED_BUNDLE_KEY);
        }
    }


    public String retreiveStatusTitle(Boolean enabled) {
        if (BooleanUtils.isTrue(enabled)) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.DISABLED_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.ENABLED_BUNDLE_KEY);
        }
    }

    public String retreiveStatus(Boolean status) {
        if (status == null) {
            return "";
        } else if (!status) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.DISABLED_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.ENABLED_BUNDLE_KEY);
        }
    }

    public String retreiveIcon(Boolean status) {
        if (status == null) {
            return "";
        } else if (status) {
            return UtilsConstants.DISABLE_ICON;
        } else {
            return UtilsConstants.ENABLE_ICON;
        }
    }

    public String retreiveFileIcon(String content) {
        if (BoUtils.isEmptyOrNull(content)) {
            return UtilsConstants.EMPTY_FILE_ICON;
        } else {
            return UtilsConstants.FULL_FILE_ICON;
        }
    }

    public String getStatus(boolean status) {
        if (status) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.DISABLED_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.ENABLED_BUNDLE_KEY);
        }
    }

    public String getIcon(boolean status) {
        if (status) {
            return UtilsConstants.ENABLE_ICON;
        } else {
            return UtilsConstants.DISABLE_ICON;
        }
    }

    public String getStatusTitle(boolean enabled) {
        if (enabled) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.ENABLE_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.DISABLE_BUNDLE_KEY);
        }
    }

    public String getYesOrNoFromStatus(boolean enabled) {
        if (enabled) {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.NO_BUNDLE_KEY);
        } else {
            return retreiveByBundleNameAndBundleKey(UtilsConstants.COMMON_MESSAGES_BUNDLE_NAME, UtilsConstants.YES_BUNDLE_KEY);
        }
    }

    public String retreiveLimitedString(int characterNumber, String content) {
        if (content.length() < characterNumber) {
            return content;
        } else {
            return content.substring(0, characterNumber).concat("...");
        }
    }
}
