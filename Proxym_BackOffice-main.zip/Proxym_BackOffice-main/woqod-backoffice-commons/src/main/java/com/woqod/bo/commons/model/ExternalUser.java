package com.woqod.bo.commons.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ExternalUser {

    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String fullName;
    private String password;
    private RoleModel role;

    public ExternalUser(String userName, String password, String fullName, RoleModel role) {
        this.userName = userName;
        this.password = password;
        this.fullName = fullName;
        this.role = role;
    }
}
