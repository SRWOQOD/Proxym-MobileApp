package com.woqod.bo.commons.response;

/**
 * Created by med-amine.ben-ahmed on 20/11/2017.
 */
public class SuccessResponse extends RuntimeException {
}
