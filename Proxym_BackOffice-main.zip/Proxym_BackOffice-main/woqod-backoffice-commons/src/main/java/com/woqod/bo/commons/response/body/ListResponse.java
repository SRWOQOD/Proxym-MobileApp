package com.woqod.bo.commons.response.body;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.woqod.bo.commons.response.GenericResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * this class is used to render a list of objects response
 *
 * @author Radhouene
 */
public class ListResponse<T> extends GenericResponseBody {
    @JsonProperty(value = "result")
    private List<T> list;

    public ListResponse() {
        super();
    }

    /**
     * @param list
     */
    public ListResponse(List<T> list) {
        super();
        this.list = list != null ? list : new ArrayList<>();
    }

    /**
     * @return the list
     */
    public List<T> getList() {
        return list != null ? list : new ArrayList<>();
    }

    /**
     * @param list the list to set
     */
    public void setList(List<T> list) {
        this.list = list != null ? list : new ArrayList<>();
    }

}
