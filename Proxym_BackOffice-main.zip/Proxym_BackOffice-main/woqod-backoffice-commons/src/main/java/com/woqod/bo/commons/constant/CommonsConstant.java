package com.woqod.bo.commons.constant;

public final class CommonsConstant {
    private CommonsConstant() {
    }

    public static final String BUNDLE_NAME = "common_messages";

    public static final String OM_NAME = "om_components";
}
