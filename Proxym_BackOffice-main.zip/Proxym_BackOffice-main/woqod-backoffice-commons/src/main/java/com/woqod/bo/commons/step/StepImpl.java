package com.woqod.bo.commons.step;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.AccessDeniedException;
import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.util.HashMap;

@Data
@Slf4j
@Component
public class StepImpl implements Step {

    public static final String ACCESS_DENIED = "Access Denied";
    public static final String ACCESS = "access";
    public static final String FEATURE = "feature";

    private final Permissions permissions;
    public final UserService userService;
    private final UserActionService userActionService;
    private final DataFactory dataFactory;
    private ObjectMapper objectMapper;

    @Autowired
    public StepImpl(Permissions permissions, UserActionService userActionService, UserService userService, DataFactory dataFactory) {
        this.permissions = permissions;
        this.dataFactory = dataFactory;
        this.userService = userService;
        this.userActionService = userActionService;
        objectMapper = new ObjectMapper();
    }

    @Override
    public void checkPermission(HashMap<String, Object> serviceData) {
        if (!permissions.isFeaturePermitted(serviceData.get(FEATURE).toString())) {
            throw new AccessDeniedException();
        }
    }

    @Override
    public void saveLog(Boolean isSuccess, HashMap<String, Object> postData, String exception) {
        HttpSession session = BoUtils.getSession();
        UserModel user = (UserModel) session.getAttribute("User");
        if (user == null) {
            user = new UserModel();
            user.setUserName(FacesContext.getCurrentInstance().getExternalContext().getRemoteUser());
            user.setEnabled(true);
        }
        UserActionModel userAction = UserActionModel.newBuilder()
                .username(user.getUserName())
                .firstName(user.getFirstName())
                .isSuccess(isSuccess)
                .ipAddress(BoUtils.getIpHostAddress())
                .oldData(retrieveOldDataAsString(postData.get(UtilsConstants.OLD_DATA)))
                .actionDate(LocalDate.now())
                .role(dataFactory.getAuthenticatedRole())
                .actionData(retrieveOldDataAsString(postData.get(UtilsConstants.POST_DATA)))
                .exceptionData(exception)
                .action(postData.get(FEATURE).toString())
                .build();

        userActionService.saveUserAction(userAction);
    }

    @Override
    public void redirect(String uri) {
        permissions.getDataFactory().redirect(uri);
    }

    @Override
    public void showPopup(String level, String sumary, String msg) {
        switch (level) {
            case "INFO": {
                BoUtils.showInfoPopup(sumary, msg);
                break;
            }
            case "ERROR": {
                BoUtils.showErrorPopup(sumary, msg);
                break;
            }
            default:
                break;
        }
    }

    @Override
    public String retrievePostDataAsString(HashMap<String, Object> postData) {
        if (postData == null) {
            return "";
        } else {
            try {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(postData);
            } catch (JsonProcessingException e) {
                return "";
            }
        }
    }

    @Override
    public String retrieveOldDataAsString(Object oldData) {
        if (oldData == null) {
            return "";
        } else {
            try {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(oldData);
            } catch (JsonProcessingException e) {
                return "";
            }
        }
    }
}
