package com.woqod.bo.commons.utils;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportItemResource {
    private List<ReportEnum> list;
}
