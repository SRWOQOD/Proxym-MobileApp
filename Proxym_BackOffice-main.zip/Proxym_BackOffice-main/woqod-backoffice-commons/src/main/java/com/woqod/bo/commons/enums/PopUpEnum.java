package com.woqod.bo.commons.enums;


public enum PopUpEnum {
    ADD,
    EDIT,
    DELETE
}
