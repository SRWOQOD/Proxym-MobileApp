package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.ExternalUser;
import com.woqod.bo.commons.model.UserModel;

import java.util.List;

public interface UserService {

    /**
     * used to save user
     *
     * @param users
     */
    void save(List<UserModel> users);

    void update(UserModel user);

    /**
     * used to retrieve user by username
     *
     * @param userName
     * @return
     */
    UserModel findOneByUserName(String userName);

    UserModel findOneUserByName(String userName);

    /**
     * used to retrive all users
     *
     * @return
     */
    List<UserModel> findAll();

    List<String> findAllUserName();

    /**
     * used to save external user
     *
     * @param externalUser
     */
    UserModel saveExternalUser(ExternalUser externalUser);

    UserModel save(UserModel userModel);

    long count();
}
