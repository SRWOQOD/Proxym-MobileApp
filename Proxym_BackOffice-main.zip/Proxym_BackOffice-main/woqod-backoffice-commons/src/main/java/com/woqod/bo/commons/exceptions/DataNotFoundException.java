package com.woqod.bo.commons.exceptions;


import com.woqod.bo.commons.ProxymError;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:15
 */
public class DataNotFoundException extends ProxymException {

    private static final long serialVersionUID = 1L;

    public DataNotFoundException(String item, String key, String tableName) {
        super(ProxymError.DATA_NOT_FOUND, item, key, tableName);
        this.key = item;
    }

}
