package com.woqod.bo.commons.interfaces;


import com.woqod.bo.commons.model.FeatureRoleModel;

import java.util.List;

public interface FeatureRoleService {

    /**
     * used to save feature role
     *
     * @param featureRoles
     */
    void save(List<FeatureRoleModel> featureRoles);

    /**
     * used to retrieve feature role
     */
    List<FeatureRoleModel> getFeatureRoles();

    /**
     * used to delete list of feature role
     */
    void deleteFeatureRoles(List<FeatureRoleModel> list);

    /**
     * used to delete feature role by role name
     *
     * @param role
     */
    void deleteFeatureRoles(String role);

    /**
     * used to get list of feature role by role name
     */
    List<FeatureRoleModel> getFeatureRolesByRoleName(String roleName);

    /**
     * used to retrieve feature role by feature code
     */
    List<FeatureRoleModel> getFeatureRoleByFeatureCode(String code);

    /**
     * used to retrieve feature role by feature code and role name
     */
    FeatureRoleModel findOneByFeatureAndRole(String code, String roleName);

    List<FeatureRoleModel> findAllByRoleName(String roleName);

}
