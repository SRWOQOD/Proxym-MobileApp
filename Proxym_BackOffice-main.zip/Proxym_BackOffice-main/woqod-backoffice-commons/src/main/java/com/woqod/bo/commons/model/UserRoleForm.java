package com.woqod.bo.commons.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Created by haithem.ben-chaaben on 29/11/2018.
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserRoleForm {
    private Integer id;
    private String userName;
    private String roleName;
    private String roleDescription;
    private Boolean enabled;
    private String firstName;
    private String lastName;
    private String fullName;
    private String email;
    private LocalDate createdAt;
}