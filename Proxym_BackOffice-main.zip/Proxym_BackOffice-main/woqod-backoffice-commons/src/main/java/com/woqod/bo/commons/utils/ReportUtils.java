package com.woqod.bo.commons.utils;

import org.apache.commons.lang3.BooleanUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public final class ReportUtils {

    private ReportUtils() {

    }

    public static Boolean checkFiled(List<String> filed, Object object) {
        for (String s : filed
        ) {
            if (BooleanUtils.isTrue(checkFiled(s, object))) {
                return true;
            }
        }
        return false;
    }

    /*
     Check if class has the given filed
     */
    public static Boolean checkFiled(String filed, Object object) {
        List<String> sourceFieldList = getAllFields(object.getClass());
        return ifPropertpresent(sourceFieldList, filed);

    }

    /**
     * Check if field is present for the class
     */
    private static boolean ifPropertpresent(final List<String> properties, final String propertyName) {
        return properties.contains(propertyName);
    }

    /**
     * Recursive method to get fields
     */
    private static List<String> getAllFields(final Class<?> type) {
        List<String> fields = new ArrayList<>();
        //loop the fields using Java Reflections
        for (Field field : type.getDeclaredFields()) {
            fields.add(field.getName());
        }

        //recursive call to getAllFields
        if (type.getSuperclass() != null) {
            fields.addAll(getAllFields(type.getSuperclass()));
        }
        return fields;
    }

    /*
      Get filed not empty in Report Resource
     */
    public static List<String> getNotEmptyFiled(ReportResource reportResource) {
        List<String> list = new ArrayList<>();

        if (reportResource.getPhone() != null && !(reportResource.getPhone().isEmpty())) {
            list.add("phone");
        }
        if (reportResource.getQid() != null && !(reportResource.getQid().isEmpty())) {
            list.add("qid");
        }
        if (reportResource.getRequestId() != null && !(reportResource.getRequestId().isEmpty())) {
            list.add("transactionID");
        }
        if (reportResource.getTransactionUUID() != null && !(reportResource.getTransactionUUID().isEmpty())) {
            list.add("transactionUUID");
        }
        if (reportResource.getStartDate() != null) {
            list.add("startDate");
            list.add("createdDate");
            list.add("createdAt");
        }
        if (reportResource.getEndDate() != null) {
            list.add("endDate");
            list.add("createdDate");
            list.add("createdAt");
        }

        return list;
    }

    public static Boolean ifItemSelected(List<ReportEnum> selected, String item) {
        for (ReportEnum s : selected
        ) {
            if ((s.getDescription()).equals(item)) {
                return true;
            }
        }
        return false;
    }

    public static String getExportString(List<ReportEnum> list) {
        String x = "";
        StringBuilder buf = new StringBuilder();
        for (ReportEnum report : list
        ) {
            if ((report.getDescription()).equals("Survey")) {
                buf.append("Survey,");
            }
            if ((report.getDescription()).equals("Users Management")) {
                buf.append("Users_Management,");
            }
            if ((report.getDescription()).equals("WOQODe Transaction")) {
                buf.append("WOQODE_Transaction,");
            }
            if ((report.getDescription()).equals("FAHES Transactions")) {
                buf.append("FAHES_Transactions,");
            }

            if ((report.getDescription()).equals("FAHES Booking")) {
                buf.append("FAHES_Booking,");
            }

            if ((report.getDescription()).equals("SELECT SERVICE NAME")) {
                buf.append("No_Selected_Service,");
            }

        }
        x = buf.toString();
        return x.substring(0, x.length() - 1);
    }
}
