package com.woqod.bo.commons.response.body.header;


import com.woqod.bo.commons.response.GenericResponseHeader;

/**
 * Created by med-amine.ben-ahmed on 02-Jun-17.
 */
public class OtpRequiredHeader extends GenericResponseHeader {

    private String uuid;
    private String challengeKey;


    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getChallengeKey() {
        return challengeKey;
    }

    public void setChallengeKey(String challengeKey) {
        this.challengeKey = challengeKey;
    }


}
