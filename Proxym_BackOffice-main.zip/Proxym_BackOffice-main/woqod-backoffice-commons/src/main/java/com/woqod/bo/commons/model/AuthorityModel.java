package com.woqod.bo.commons.model;

import java.time.LocalDate;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
public class AuthorityModel {

    private UserModel user;
    private RoleModel role;
    private LocalDate createdAt;

    public AuthorityModel() {

    }

    public AuthorityModel(UserModel user, RoleModel role) {
        this.user = user;
        this.role = role;
    }

    public UserModel getUser() {
        return user;
    }

    public void setUser(UserModel user) {
        this.user = user;
    }

    public RoleModel getRole() {
        return role;
    }

    public void setRole(RoleModel role) {
        this.role = role;
    }

    public LocalDate getCreatedAt() {
        return createdAt != null ? LocalDate.now() : null;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt != null ? LocalDate.now() : null;
    }
}
