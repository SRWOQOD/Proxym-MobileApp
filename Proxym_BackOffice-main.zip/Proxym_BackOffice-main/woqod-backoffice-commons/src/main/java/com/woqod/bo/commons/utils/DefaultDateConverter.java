package com.woqod.bo.commons.utils;

import javax.faces.convert.DateTimeConverter;
import javax.faces.convert.FacesConverter;
import java.util.TimeZone;

/**
 * User: Nasreddine.Jrebi
 * Date: 30/11/2018 10:33
 */
@FacesConverter("defaultDateConverter")
public class DefaultDateConverter extends DateTimeConverter {

    /**
     * is an converter used in xhtml to convert date format
     */
    public DefaultDateConverter() {
        setTimeZone(TimeZone.getDefault());
        setPattern("yyyy-MM-dd HH:mm:ss");

    }

}
