package com.woqod.bo.commons.model;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */

@Data
public class UserModel implements Serializable {
    private static final long serialVersionUID = 1;

    private String userName;
    private String firstName;
    private String fullName;
    private String lastName;
    private String email;
    private String password;
    private Boolean enabled;
    private Boolean accountNonLocked;

    private transient List<AuthorityModel> autorities = new ArrayList<>();

    public UserModel() {

    }

    public UserModel(String userName, String password, Boolean enabled, Boolean accountNonLocked, String firstName, String lastName, String email, String fullName) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.enabled = enabled;
        this.fullName = fullName;
        this.accountNonLocked = accountNonLocked;
    }

    public UserModel(String userName, String password, Boolean enabled, List<AuthorityModel> autorities, String firstName, String lastName, String email, String fullName) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.enabled = enabled;
        this.autorities = autorities;
    }


}