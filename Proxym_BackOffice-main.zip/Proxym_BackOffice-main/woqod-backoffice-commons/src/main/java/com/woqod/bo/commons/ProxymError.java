package com.woqod.bo.commons;

import java.text.MessageFormat;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:16
 */
public enum ProxymError {

    ERROR_GENERAL_FAILURE(100, "General error not handled", ""),
    DATA_NOT_FOUND(101, "No {0} with key {1} found in table {2}", ""),
    UPDATE_VIOLATION_CONSTRAINT(102, "Error when updating {0}", ""),
    PERSIST_VIOLATION_CONSTRAINT(103, "Error when persisting {0}", ""),
    SYSTEM_EXCEPTION(104, "System Exception have been Occurred", ""),
    ;

    private final int code;
    private final String msgEN;
    private final String msgAR;

    ProxymError(int code, String msgEN, String msgAR) {
        this.code = code;
        this.msgEN = msgEN;
        this.msgAR = msgAR;
    }

    public String getMsgEN(Object... args) {
        return MessageFormat.format(msgEN, args);
    }

    public String getMsgAR(Object... args) {
        return MessageFormat.format(msgAR, args);
    }

    public String getCode() {
        return String.valueOf(this.code);
    }

    public String getMsgEN() {
        return msgEN;
    }

    public String getMsgAR() {
        return msgAR;
    }

}
