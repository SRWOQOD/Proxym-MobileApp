package com.woqod.bo.commons.response;

public enum ResponseEnum {
    BOOLEAN_RESPONSE,
    LIST_RESPONSE,
    OBJECT_RESPONSE,
    PAGINATED_LIST_RESPONSE
}
