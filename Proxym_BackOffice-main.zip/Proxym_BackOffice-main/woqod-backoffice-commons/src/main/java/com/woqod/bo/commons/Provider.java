package com.woqod.bo.commons;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:23
 */
public enum Provider {
    BO("01", "Backoffice"),
    BACKEND("02", "Backend");

    private String code;
    private String description;

    Provider(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
