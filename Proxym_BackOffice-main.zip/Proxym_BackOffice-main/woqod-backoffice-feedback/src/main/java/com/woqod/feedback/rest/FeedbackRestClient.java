package com.woqod.feedback.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import com.woqod.feedback.constant.FeedbackConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;
import wq.woqod.resources.resources.FeedbackResponseResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/feedback.properties")
public class FeedbackRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String feedback;
    private String count;

    @Autowired
    public FeedbackRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.feedback}") String feedback, @Value("${uri.ws.feedback.count}") String count) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.feedback = feedback;
        this.count = count;
    }

    /**
     * used to get parameters paginated and filtered
     */

    public PaginatedListResponse<FeedbackResourceWithoutPhoto> paginatedParams(Map<String, String> uriParams) {
        log.debug("{} paginatedParams", FeedbackConstant.FEEDBACK_REST_CLIENT);
        String uri = feedback.concat("/filtred");
        return (PaginatedListResponse<FeedbackResourceWithoutPhoto>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<FeedbackResourceWithoutPhoto>>>() {
                        });
    }


    public Boolean save(FeedbackResource feedbackResource) {
        log.debug("{} save", FeedbackConstant.FEEDBACK_REST_CLIENT);
        String uri = feedback;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), feedbackResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to delete discount
     */
    public Boolean delete(String id) {
        String uri = feedback + "/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to update Parameter
     */
    public Boolean close(FeedbackResource object) {
        String uri = feedback + "/close";
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), object,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to update Parameter
     */
    public Boolean createResponse(FeedbackResponseResource object) {
        String uri = feedback + "/response";
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), object,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public Boolean createResponseAnonym(FeedbackResponseResource object) {
        String uri = feedback + "/responseAnonym";
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), object,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to update Parameter
     */
    public FeedbackResource getFeedback(String id) {
        log.debug("{} getFeedback", FeedbackConstant.FEEDBACK_REST_CLIENT);
        String uri = feedback.concat("/feedback/").concat(id);
        ObjectResponse<FeedbackResource> response = (ObjectResponse<FeedbackResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<FeedbackResource>>>() {
                        });
        return response.getObject();
    }

    public List<FeedbackResource> getFeedbacks(Map<String, String> uriParams) {
        String uri = "/feedbacks/feedbacks";
        ListResponse<FeedbackResource> listResponse = (ListResponse<FeedbackResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<FeedbackResource>>>() {
                        });

        return listResponse.getList();
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
}
