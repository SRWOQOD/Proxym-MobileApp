package com.woqod.feedback.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.service.TemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.woqod.bo.commons.utils.UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA;

@Data
@Slf4j
public class TemplateLazyModel extends LazyDataModel<FeedbackTemplateResource> {

    private static final long serialVersionUID = 1;
    private final transient TemplateService templateService;
    private Map<String, String> uriParams;
    private Boolean searchFlag = false;

    public TemplateLazyModel(TemplateService templateService) {
        this.templateService = templateService;
        this.uriParams = new HashMap<>();
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtred and paginated data
     */
    @Override
    public List<FeedbackTemplateResource> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                               Map<String, FilterMeta> filters) {
        if (BooleanUtils.isTrue(searchFlag)) {
            first = 0;
        }
        try {
            if (sortField == null) {
                sortField = "createdDate";
            }
            PaginatedListResponse<FeedbackTemplateResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

            response = templateService.getPaginatedTemplate(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            setSearchFlag(false);
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", TemplateConstant.TEMPLATE_LAZY_MODEL, ERROR_OCCURRED_WHEN_LOADING_DATA, TemplateConstant.TEMPLATES);
            return new ArrayList<>();
        }
    }
}
