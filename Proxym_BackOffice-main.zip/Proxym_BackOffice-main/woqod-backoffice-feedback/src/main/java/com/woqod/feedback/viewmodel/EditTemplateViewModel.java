package com.woqod.feedback.viewmodel;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.enums.MenuEnum;
import com.woqod.feedback.service.TemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

@Data
@Slf4j
@Component
@Scope("view")
public class EditTemplateViewModel {
    /*
Beans
*/
    private final TemplateService templateService;
    /*
 state
  */
    private FeedbackTemplateResource templateResource;
    private FeedbackTemplateResource oldTemplateResource;
    private String templateId;
    private final DataFactory dataFactory;

    @Autowired
    public EditTemplateViewModel(TemplateService templateService, DataFactory dataFactory) {
        this.templateService = templateService;
        this.dataFactory = dataFactory;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            templateId = request.getParameter(TemplateConstant.TEMPLATE_ID);
            oldTemplateResource = templateService.findTemplate(templateId);
            init();
        }
    }

    public void init() {
        log.debug("{} init", TemplateConstant.EDIT_TEMPLATE_VIEW_MODEL);
        templateResource = new FeedbackTemplateResource();
        templateResource = templateService.findTemplate(templateId);
        log.debug("{} init", TemplateConstant.EDIT_TEMPLATE_VIEW_MODEL);
    }

    /**
     * Clear function
     */
    public void clear() {
        log.debug("{} clear ", TemplateConstant.EDIT_TEMPLATE_VIEW_MODEL);
        templateResource.setContent("");
        templateResource.setTitle("");
    }

    /**
     * checkValidity function
     */
    public boolean checkValidity() {
        boolean checkValidity = true;
        if (templateResource != null && !templateResource.getContent().isEmpty() && !templateResource.getTitle().isEmpty()) {
            if (templateResource.getContent().length() > 255) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "InvalidMinMaxMessage"), "");
            }
            if (templateResource.getTitle().length() > 255) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "InvalidMinMaxTitle"), "");
            }
        } else {
            checkValidity = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "RequiredElements"), "");
        }
        return checkValidity;
    }

    /**
     * checkExistence function
     */
    public boolean checkExistence() {
        boolean checkExistence = false;
        FeedbackTemplateResource existentTemplate = templateService.findTemplateByTitle(templateResource.getTitle());
        if (existentTemplate != null && !existentTemplate.getId().equals(templateResource.getId())) {
            checkExistence = true;
        }
        return checkExistence;
    }

    /**
     * Edit function
     */

    public void editTemplate() {
        log.debug("{} editTemplate", TemplateConstant.EDIT_TEMPLATE_VIEW_MODEL);
        if (checkValidity()) {
            if (!checkExistence()) {
                HashMap<String, Object> serviceData = new HashMap<>();
                serviceData.put(UtilsConstants.POST_DATA, templateResource);
                serviceData.put(UtilsConstants.OLD_DATA, oldTemplateResource);
                serviceData.put(UtilsConstants.FEATURE, MenuEnum.EDIT_FEEDBACKS.name());
                templateService.edit(serviceData);
                dataFactory.redirect("templates");

            } else {
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "ExistedElement"), "");
            }
        }
    }

    public String getViewTemplateFeature() {
        return MenuEnum.VIEW_TEMPLATE.name();
    }
}
