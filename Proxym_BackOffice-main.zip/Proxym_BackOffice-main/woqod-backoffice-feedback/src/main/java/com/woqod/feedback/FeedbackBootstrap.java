package com.woqod.feedback;


import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.feedback.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Component
public class FeedbackBootstrap {
    private static final String FEEDBACK_MANAGEMENT = "Feedback_Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(FEEDBACK_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }

}
