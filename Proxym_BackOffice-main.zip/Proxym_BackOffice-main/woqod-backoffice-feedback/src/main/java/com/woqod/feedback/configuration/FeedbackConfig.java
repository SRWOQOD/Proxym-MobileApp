package com.woqod.feedback.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author OTHMANI Lazhar
 * on 08/04/2019
 */
@Configuration
@ComponentScan(basePackages = {"com.woqod.feedback"})
public class FeedbackConfig {
}
