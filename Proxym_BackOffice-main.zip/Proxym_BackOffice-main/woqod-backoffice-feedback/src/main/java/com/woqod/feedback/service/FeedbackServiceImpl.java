package com.woqod.feedback.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.rest.FeedbackRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;
import wq.woqod.resources.resources.FeedbackResponseResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class FeedbackServiceImpl implements FeedbackService {

    private final FeedbackRestClient feedbackRestClient;

    @Autowired
    public FeedbackServiceImpl(FeedbackRestClient feedbackRestClient) {
        this.feedbackRestClient = feedbackRestClient;
    }

    @Override
    public PaginatedListResponse<FeedbackResourceWithoutPhoto> getPaginatedFeedback(Map<String, String> uriParams) {
        log.debug("{} getPaginatedDiscount ", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        return feedbackRestClient.paginatedParams(uriParams);
    }


    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void save(Map<String, Object> serviceData) {
        log.debug("{} save ", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        FeedbackResource feedbackResource = (FeedbackResource) serviceData.get(UtilsConstants.POST_DATA);
        feedbackRestClient.save(feedbackResource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void delete(Map<String, Object> serviceData) {
        log.debug("{} delete", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        String feedbackId = (String) serviceData.get(UtilsConstants.POST_DATA);
        feedbackRestClient.delete(feedbackId);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void close(Map<String, Object> serviceData) {
        log.debug("{} close", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        FeedbackResource feedbackResourceToClose = (FeedbackResource) serviceData.get(UtilsConstants.POST_DATA);
        feedbackRestClient.close(feedbackResourceToClose);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void newResponse(Map<String, Object> serviceData) {
        log.debug("{} newResponse", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        FeedbackResponseResource feedbackResponseResource = (FeedbackResponseResource) serviceData.get(UtilsConstants.POST_DATA);
        feedbackRestClient.createResponse(feedbackResponseResource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void newResponseAnonym(Map<String, Object> serviceData) {
        log.debug("{} newResponseAnonym", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        FeedbackResponseResource feedbackResponseResource = (FeedbackResponseResource) serviceData.get(UtilsConstants.POST_DATA);
        feedbackRestClient.createResponseAnonym(feedbackResponseResource);
    }

    @Override
    public FeedbackResource getFeedbackById(String id) {
        log.debug("{} getFeedbackById", FeedbackConstant.FEEDBACK_SERVICE_IMPL);
        return feedbackRestClient.getFeedback(id);
    }

    @Override
    public List<FeedbackResource> feedbacks(Map<String, String> uriParams) {
        return feedbackRestClient.getFeedbacks(uriParams);
    }

    @Override
    public Integer count() {
        return feedbackRestClient.count();
    }
}
