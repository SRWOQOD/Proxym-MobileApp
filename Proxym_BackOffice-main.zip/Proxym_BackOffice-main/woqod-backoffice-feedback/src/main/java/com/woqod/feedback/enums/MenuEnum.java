package com.woqod.feedback.enums;

import com.woqod.bo.commons.enums.*;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.constant.TemplateConstant;

import java.util.Arrays;
import java.util.Optional;

public enum MenuEnum implements Menu {

    DISPLAY_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "DisplayFeedbacks"), FeedbackConstant.FEEDBACK_MANAGEMENT_URL, "", "", true, ParentModuleEnum.FEEDBACK_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    VIEW_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "ViewFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    REPLY_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "ReplyFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    DELETE_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "DeleteFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    CLOSE_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "CloseFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 5L)),
    EDIT_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "EditFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 6L)),
    EXPORT_FEEDBACKS(new Bundle(FeedbackConstant.BUNDLE_NAME, "ExportFeedback"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 7L)),
    VIEW_FEEDBACK_IMAGE(new Bundle(FeedbackConstant.BUNDLE_NAME, "viewFeedbackImage"), "", "", "", true, DISPLAY_FEEDBACKS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 8L)),

    DISPLAY_TEMPLATES(new Bundle(FeedbackConstant.BUNDLE_NAME, "DisplayTemplates"), TemplateConstant.TEMPLATES_MANAGEMENT_URL, "", "", true, ParentModuleEnum.FEEDBACK_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    VIEW_TEMPLATE(new Bundle(FeedbackConstant.BUNDLE_NAME, "ViewTemplate"), "", "", "", true, DISPLAY_TEMPLATES.name(), new MenuPosition(ModuleLevel.SECOND.name(), 9L)),
    ADD_TEMPLATE(new Bundle(FeedbackConstant.BUNDLE_NAME, "AddTemplate"), "", "", "", true, DISPLAY_TEMPLATES.name(), new MenuPosition(ModuleLevel.SECOND.name(), 10L)),
    DELETE_TEMPLATE(new Bundle(FeedbackConstant.BUNDLE_NAME, "DeleteTemplate"), "", "", "", true, DISPLAY_TEMPLATES.name(), new MenuPosition(ModuleLevel.SECOND.name(), 11L)),
    EXPORT_TEMPLATE(new Bundle(FeedbackConstant.BUNDLE_NAME, "ExportTemplate"), "", "", "", true, DISPLAY_TEMPLATES.name(), new MenuPosition(ModuleLevel.SECOND.name(), 12L));

    MenuEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }


}
