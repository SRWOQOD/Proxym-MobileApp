package com.woqod.feedback.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping(value = FeedbackConstant.FEEDBACK_MANAGEMENT_URL)
@Data
public class FeedbackController {

    private final Permissions permissions;

    @Autowired
    public FeedbackController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_FEEDBACKS.name(), FeedbackConstant.FEEDBACK_LIST);
    }

    /**
     * used to display add feedback view
     */
    @GetMapping("/close")
    public ModelAndView closeDisplay() {
        return permissions.getModelAndView(MenuEnum.REPLY_FEEDBACKS.name(), FeedbackConstant.REPLY_FEEDBACK);
    }

    /**
     * used to display add feedback view
     */
    @GetMapping("/reply")
    public ModelAndView replyDisplay() {
        return permissions.getModelAndView(MenuEnum.REPLY_FEEDBACKS.name(), FeedbackConstant.REPLY_FEEDBACK);
    }

    /**
     * used to display update feedback view
     */
    @GetMapping("/viewFeedback")
    public ModelAndView viewDisplay() {
        return permissions.getModelAndView(MenuEnum.VIEW_FEEDBACKS.name(), FeedbackConstant.VIEW_FEEDBACK);
    }
    @GetMapping("/viewFeedbackImage")
    public ModelAndView viewFeedbackImage() {
        return permissions.getModelAndView(MenuEnum.VIEW_FEEDBACK_IMAGE.name(), FeedbackConstant.VIEW_FEEDBACK_IMAGE);
    }


}
