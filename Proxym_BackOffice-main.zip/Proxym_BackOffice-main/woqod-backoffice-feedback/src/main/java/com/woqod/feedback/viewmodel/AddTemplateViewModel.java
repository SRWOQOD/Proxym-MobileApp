package com.woqod.feedback.viewmodel;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.enums.MenuEnum;
import com.woqod.feedback.service.TemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import javax.faces.context.FacesContext;
import java.util.HashMap;

@Data
@Slf4j
@Component
@Scope("view")
public class AddTemplateViewModel {

    /*
 Beans
  */
    private final TemplateService templateService;
    private final DataFactory dataFactory;
    /*
 state
  */
    private FeedbackTemplateResource templateResource;
    private String template;

    @Autowired
    public AddTemplateViewModel(TemplateService templateService, DataFactory dataFactory) {
        this.templateService = templateService;
        this.dataFactory = dataFactory;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();

        }
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public void init() {
        log.debug("{} init", TemplateConstant.ADD_TEMPLATE_VIEW_MODEL);
        templateResource = new FeedbackTemplateResource();
    }

    /**
     * Clear function
     */
    public void clear() {
        log.debug("{} clear ", TemplateConstant.ADD_TEMPLATE_VIEW_MODEL);
        init();
    }

    public boolean checkValidity() {
        boolean checkValidity = true;
        if (templateResource != null && !templateResource.getContent().isEmpty() && !templateResource.getTitle().isEmpty()) {
            if (templateResource.getContent().length() > 255) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "InvalidMinMaxMessage"), "");
            }
            if (templateResource.getTitle().length() > 255) {
                checkValidity = false;
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "InvalidMinMaxTitle"), "");
            }
        } else {
            checkValidity = false;
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "RequiredElements"), "");
        }
        return checkValidity;
    }

    public boolean checkExistence() {
        boolean checkExistence = false;
        FeedbackTemplateResource existentTemplate = templateService.findTemplateByTitle(templateResource.getTitle());
        if (existentTemplate != null) {
            checkExistence = true;
        }
        return checkExistence;
    }

    public void createTemplate() {
        if (checkValidity()) {
            if (!checkExistence()) {
                HashMap<String, Object> serviceData = new HashMap<>();
                serviceData.put(UtilsConstants.FEATURE, MenuEnum.ADD_TEMPLATE.name());
                serviceData.put(UtilsConstants.POST_DATA, templateResource);
                templateService.save(serviceData);
                BoUtils.showsuccesspopup();
                dataFactory.redirect("templates");
            } else {
                BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(TemplateConstant.BUNDLE_NAME, "ExistedElement"), "");
            }
        }
    }

    public String getViewTemplateFeature() {
        return MenuEnum.VIEW_TEMPLATE.name();
    }

    public String getCreateTemplateFeature() {
        return MenuEnum.ADD_TEMPLATE.name();
    }

}
