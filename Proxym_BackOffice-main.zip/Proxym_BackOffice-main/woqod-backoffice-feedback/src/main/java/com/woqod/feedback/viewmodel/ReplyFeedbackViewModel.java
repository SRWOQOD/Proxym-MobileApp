package com.woqod.feedback.viewmodel;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.enums.MenuEnum;
import com.woqod.feedback.service.FeedbackService;
import com.woqod.feedback.service.TemplateService;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.event.CloseEvent;
import org.primefaces.event.ToggleEvent;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.enumerations.FeedbackCategoryEnum;
import wq.woqod.resources.enumerations.FeedbackSectorEnum;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResponseResource;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;


@Data
@Slf4j
@Component
@Scope("view")
public class ReplyFeedbackViewModel {
    /*
Beans
*/
    private final FeedbackService feedbackService;
    private final DataFactory dataFactory;
    private final TemplateService templateService;

    /*
    state
     */
    private List<FeedbackResponseResource> feedbackResponseResource;
    private FeedbackResource feedbackResource;
    private String feedbackImage;
    private List<FeedbackCategoryEnum> category;
    private List<FeedbackSectorEnum> sector;
    private String feedbackId;
    private String ticketNumber;
    private StreamedContent getmyImage;
    private String reply;
    private FeedbackResponseResource newReplyResponse;
    private String usernameByType;
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private byte[] imageBytes;
    private boolean staticMsgThanking;
    private List<FeedbackTemplateResource> templates;
    private List<SelectItem> selecttemplates;
    private String[] selectedTemplates;

    public byte[] getImageBytes() {
        return imageBytes != null ? imageBytes : new byte[0];
    }

    public void setImageBytes(byte[] imageBytes) {
        this.imageBytes = imageBytes != null ? imageBytes : new byte[0];
    }

    @Autowired
    public ReplyFeedbackViewModel(FeedbackService feedbackService, DataFactory dataFactory, TemplateService templateService) {
        this.feedbackService = feedbackService;
        this.dataFactory = dataFactory;
        this.templateService = templateService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            feedbackId = request.getParameter(FeedbackConstant.FEEDBACK_ID);
            init();
        }
    }

    public void initializeImage() {
        this.feedbackImage = this.feedbackResource.getFile();
    }

    public String[] getSelectedTemplates() {
        return selectedTemplates != null ? selectedTemplates : new String[]{};
    }

    public void setSelectedTemplates(String[] selectedTemplates) {
        this.selectedTemplates = selectedTemplates != null ? selectedTemplates : new String[]{};
    }

    public boolean isStaticMsgThanking() {
        return staticMsgThanking;
    }

    public void setStaticMsgThanking(boolean staticMsgThanking) {
        this.staticMsgThanking = staticMsgThanking;
    }

    public void addMessage() {
        if (isStaticMsgThanking()) {
            setReply(this.reply + "\n\n\r " + FeedbackConstant.THANKMSG);
        } else {
            setReply("");
        }
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", FeedbackConstant.REPLY_FEEDBACK_VIEW_MODEL);
        ticketNumber = "";
        feedbackResource = new FeedbackResource();
        feedbackImage = null;
        newReplyResponse = new FeedbackResponseResource();
        feedbackResponseResource = Arrays.asList(new FeedbackResponseResource());
        templates = new ArrayList<>();
        category = Arrays.asList(FeedbackCategoryEnum.values());
        sector = Arrays.asList(FeedbackSectorEnum.values());
        //copy object vales's in other object
        feedbackResource = feedbackService.getFeedbackById(feedbackId);
        if (feedbackResource != null) {
            if (BooleanUtils.isTrue(feedbackResource.getConnected()) && feedbackResource.getUserName() != null) {
                usernameByType = feedbackResource.getUserName();
            }
            if (BooleanUtils.isTrue(feedbackResource.getConnected()) && feedbackResource.getName() != null) {
                usernameByType = feedbackResource.getName();
            }
            Comparator<FeedbackResponseResource> comparator = Comparator.comparing(FeedbackResponseResource::getCreationDate).reversed();
            feedbackResponseResource = feedbackResource.getFeedbackResponseResources().stream().sorted(comparator).collect(Collectors.toList());
        }
        this.reply = "";
        setReply("");
        selectedTemplates = null;
        templates = templateService.getAllTemplates(new HashMap<>());
        getTemplateModels();
    }

    public void getTemplateModels() {

        selecttemplates = new ArrayList<>();

        SelectItemGroup group = new SelectItemGroup("List of Templates");

        SelectItem[] mytemplates = new SelectItem[templates.size()];
        List<SelectItem> options = new ArrayList<>();
        for (FeedbackTemplateResource template : templates) {
            options.add(new SelectItem(template.getTitle(), template.getTitle()));
        }
        group.setSelectItems(options.toArray(mytemplates));

        selecttemplates.add(group);
    }

    public void refreshTemplatesList() {
        FeedbackTemplateResource template = null;
        StringBuilder messageTemplate = new StringBuilder();
        for (String selectedTemplate : selectedTemplates) {
            template = templateService.findTemplateByTitle(selectedTemplate);
            messageTemplate.append(template.getContent());
        }
        setReply(messageTemplate.toString());
    }

    public String asString(Long id) {
        return String.valueOf(id);
    }

    public void onClose(CloseEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Panel Closed", "Closed panel id:'" + event.getComponent().getId() + "'");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void onToggle(ToggleEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, event.getComponent().getId() + " toggled", "Status:" + (event.getVisibility().name()));
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void clear() {
        log.debug("{} clear ", FeedbackConstant.VIEW_FEEDBACK_VIEW_MODEL);
        init();
    }


    public void newReply() {
        log.debug("{} newReply", FeedbackConstant.REPLY_FEEDBACK_VIEW_MODEL);
        if (reply == null || reply.equals("")) {
            BoUtils.showErrorPopup(BoUtils.retreiveByBundleNameAndBundleKey(FeedbackConstant.BUNDLE_NAME, "RequiredMessage"), "");
        } else {
            newReplyResponse.setAdminName(feedbackResponseResource.isEmpty() ? "Admin" : feedbackResponseResource.get(0).getAdminName());
            newReplyResponse.setCreationDate(DateFormatter.localDateToDate(LocalDate.now()));
            newReplyResponse.setContent(reply);
            newReplyResponse.setFeedbackId(Long.parseLong(feedbackId));
        }
    }

    public void reply() {
        log.debug("{} reply", FeedbackConstant.REPLY_FEEDBACK_VIEW_MODEL);
        if (reply.length() > 255) {
            throw new IllegalArgumentException(FeedbackConstant.RESPONSELENGTH);
        }
        newReply();
        replyResponse();
        dataFactory.redirect(FeedbackConstant.REPLY_URL.concat(feedbackId));
    }

    public void replyResponse() {
        log.debug("{} replyResponse", FeedbackConstant.REPLY_FEEDBACK_VIEW_MODEL);
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, newReplyResponse);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.REPLY_FEEDBACKS.name());
        if (ticketNumber !=null && !ticketNumber.isEmpty()){
            newReplyResponse.setTicketNumber(ticketNumber);
        }
            if (BooleanUtils.isTrue(feedbackResource.getConnected())) {
                feedbackService.newResponse(serviceData);
            } else {
                feedbackService.newResponseAnonym(serviceData);
            }
    }

    public String getViewFeedbackFeature() {
        return MenuEnum.VIEW_FEEDBACKS.name();
    }

    public String getReplyFeedbackFeature() {
        return MenuEnum.REPLY_FEEDBACKS.name();
    }

    public String getDeleteFeedbackFeature() {
        return MenuEnum.DELETE_FEEDBACKS.name();
    }

    public TimeZone getTimeZone() {
        return TimeZone.getDefault();
    }

    public String resizeImage(String image) throws IOException {
        if (image != null && !image.isEmpty()){
            byte[] imageByte = org.apache.commons.codec.binary.Base64.decodeBase64(image);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            BufferedImage bufferedImage = ImageIO.read(bis);
            int width = bufferedImage.getWidth();
            int height = bufferedImage.getHeight();
            double ratioW = bufferedImage.getWidth() / (double) width ;
            double ratioH = bufferedImage.getHeight() / (double)height;
            double newWidth = width;
            double newHeight = height;
            int fitW = 0;
            int fitH = 0;
            BufferedImage resultImage;
            Image resize;

            if (ratioW < ratioH) {
                newWidth =  bufferedImage.getWidth() / ratioH;
                newHeight = bufferedImage.getHeight() / ratioH;
                fitW = (int) ((width - newWidth) / 2.0);

            }
            else if (ratioH < ratioW) {
                newWidth = bufferedImage.getWidth() / ratioW;
                newHeight = bufferedImage.getHeight() / ratioW;
                fitH = (int) ((height - newHeight) / 2.0);
            }

            resize = bufferedImage.getScaledInstance((int) newWidth, (int) newHeight, Image.SCALE_SMOOTH);
            resultImage = new BufferedImage(width, height, bufferedImage.getType());
            Graphics g = resultImage.getGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, width,  height);
            g.drawImage(resize, fitW, fitH, null);
            g.dispose();
            return encodeToString(resultImage);
        } else {
            return null;
        }
    }

    public String encodeToString(BufferedImage image) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, "PNG", bos);
            byte[] imageBytesVar = bos.toByteArray();

            Base64.Encoder encoder = Base64.getEncoder();
            imageString = encoder.encodeToString(imageBytesVar);

            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
}
