package com.woqod.feedback.viewmodel;


import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.enums.MenuEnum;
import com.woqod.feedback.lazymodel.TemplateLazyModel;
import com.woqod.feedback.service.TemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.PrimeFaces;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class TemplateViewModel {

    private static final String SERVICE_NAME ="FEEDBACK_TEMPLATE_NOTIFICATIONS";
    /*
   Beans
    */
    private final TemplateService templateService;

    /*
   state
    */
    private FeedbackTemplateResource filterTemplateResource;
    private FeedbackTemplateResource templateResource;
    private LazyDataModel<FeedbackTemplateResource> lazyModel;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private Integer numberOfTemplates;

    @Autowired
    public TemplateViewModel(TemplateService templateService) {
        this.templateService = templateService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", TemplateConstant.TEMPLATE_VIEW_MODEL);
        lazyModel = new TemplateLazyModel(templateService);
        templateResource = new FeedbackTemplateResource();
        uriParams = new HashMap<>();
        numberOfTemplates = templateService.count();
        filterTemplateResource = new FeedbackTemplateResource();
        search();
    }

    public void click() {
        PrimeFaces.current().ajax().update("form:display");
        PrimeFaces.current().executeScript("PF('dlg').show()");
    }

    public void clear() {
        log.debug("{} clear", TemplateConstant.TEMPLATE_VIEW_MODEL);
        filterTemplateResource = new FeedbackTemplateResource();
        uriParams = new HashMap<>();

        search();
    }

    public void search() {
        log.debug("{} search", TemplateConstant.TEMPLATE_VIEW_MODEL);
        uriParams = new HashMap<>();

        if (filterTemplateResource.getCreatedDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String dateString = format.format(filterTemplateResource.getCreatedDate());
            uriParams.put(TemplateConstant.TEMPLATE_DATE, dateString);
        }
        if (filterTemplateResource.getContent() != null) {
            uriParams.put(TemplateConstant.TEMPLATE_MESSAGE, String.valueOf(filterTemplateResource.getContent()));
        }
        if (filterTemplateResource.getTitle() != null) {
            uriParams.put(TemplateConstant.TEMPLATE_TITLE, String.valueOf(filterTemplateResource.getTitle()));
        }

        ((TemplateLazyModel) lazyModel).setSearchFlag(true);
        ((TemplateLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void delete(Long id) {
        log.debug("{} delete", TemplateConstant.TEMPLATE_VIEW_MODEL);
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, String.valueOf(id));
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_TEMPLATE.name());
        templateService.delete(serviceData);
        numberOfTemplates = templateService.count();
        BoUtils.showsuccesspopup();
    }

    public String getDisplayTemplateFeature() {
        return MenuEnum.DISPLAY_TEMPLATES.name();
    }

    public String getViewTemplateFeature() {
        return MenuEnum.VIEW_TEMPLATE.name();
    }

    public String getCreateTemplateFeature() {
        return MenuEnum.ADD_TEMPLATE.name();
    }

    public String getDeleteTemplateFeature() {
        return MenuEnum.DELETE_TEMPLATE.name();
    }

    public String getExportTemplateFeature() {
        return MenuEnum.EXPORT_TEMPLATE.name();
    }

    public String editUrl(long id) {
        return TemplateConstant.EDIT_URL.concat(String.valueOf(id));
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(templateService.getAllTemplates(uriParams), "export/feedbackTemplateResponses.jrxml", "Template Responses", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Template Responses.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(templateService.getAllTemplates(uriParams), "feedback/templateResponses.jrxml", "Template Responses", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Template Responses.pdf").stream(() -> is).build();
    }

    public String shorten(String content){
        if (content.length() < 50){
            return content;
        }
        return content.substring(0,50);
    }

}
