package com.woqod.feedback.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import com.woqod.feedback.constant.TemplateConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/feedback.properties")
public class TemplateRestClient {
    /**
     * Beans
     */

    private BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    private String template;
    private String count;

    @Autowired
    public TemplateRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.template}") String template, @Value("${uri.ws.template.count}") String count) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.template = template;
        this.count = count;
    }

    /**
     * used to get parameters paginated and filtred
     */
    public PaginatedListResponse<FeedbackTemplateResource> paginatedParams(Map<String, String> uriParams) {
        log.debug("{} paginatedParams", TemplateConstant.TEMPLATE_REST_CLIENT);
        String uri = template.concat("/filtred");
        return (PaginatedListResponse<FeedbackTemplateResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<FeedbackTemplateResource>>>() {
                        });
    }

    /**
     * used to update Parameter
     **/
    public Boolean update(FeedbackTemplateResource feedbackTemplateResource) {
        log.debug("{} update", TemplateConstant.TEMPLATE_REST_CLIENT);
        String uri = template;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), feedbackTemplateResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /*
       used to save FeedbackTemplate

      */
    public Boolean save(FeedbackTemplateResource feedbackTemplateResource) {
        log.debug("{} save", TemplateConstant.TEMPLATE_REST_CLIENT);
        String uri = template;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), feedbackTemplateResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to delete template
     */
    public Boolean delete(String id) {
        String uri = template + "/template/" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to find template
     */
    public FeedbackTemplateResource findTemplateByID(String id) {
        String uri = template + "/template/" + id;
        ObjectResponse<FeedbackTemplateResource> response = (ObjectResponse<FeedbackTemplateResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<FeedbackTemplateResource>>>() {
                        });
        return response.getObject();
    }

    public FeedbackTemplateResource findTemplateByTitle(String title) {
        String uri = template + "/templatebytitle/" + title;
        ObjectResponse<FeedbackTemplateResource> response = (ObjectResponse<FeedbackTemplateResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<FeedbackTemplateResource>>>() {
                        });
        return response.getObject();
    }

    public List<FeedbackTemplateResource> getAllTemplates(Map<String, String> uriParams) {
        String uri = template;
        ListResponse<FeedbackTemplateResource> response = (ListResponse<FeedbackTemplateResource>) customRestTemplate.getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams), new ParameterizedTypeReference<GenericResponse<ListResponse<FeedbackTemplateResource>>>() {
        });
        return response.getList();
    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
}
