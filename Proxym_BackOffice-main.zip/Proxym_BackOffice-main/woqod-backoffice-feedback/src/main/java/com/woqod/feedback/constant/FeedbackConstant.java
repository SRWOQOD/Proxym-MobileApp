package com.woqod.feedback.constant;

public final class FeedbackConstant {
    private FeedbackConstant() {
        //
    }

    public static final String FEEDBACK_MANAGEMENT_URL = "/feedback";
    public static final String FEEDBACK_LAZY_MODEL = "FeedbackLazyModel";
    public static final String FEEDBACKS = "feedbacks";
    public static final String FEEDBACK_LIST = "listFeedbacks";
    public static final String REPLY_FEEDBACK = "replyFeedback";
    public static final String VIEW_FEEDBACK = "viewFeedback";
    public static final String VIEW_FEEDBACK_IMAGE = "viewImage";
    public static final String FEEDBACK_CATEGORY_ENUM = "category";
    public static final String FEEDBACK_SECTOR_ENUM = "sector";
    public static final String FEEDBACK_NUMBER = "feedbackNumber";
    public static final String FEEDBACK_IS_CONNECTED = "connected";
    public static final String FEEDBACK_VIEW_MODEL = "[FeedbackViewModel]";
    public static final String VIEW_FEEDBACK_VIEW_MODEL = "[ViewFeedbackViewModel]";
    public static final String REPLY_FEEDBACK_VIEW_MODEL = "[ReplyFeedbackViewModel]";
    public static final String FEEDBACK_REST_CLIENT = "FeedbackRestClient";
    public static final String FEEDBACK_SERVICE_IMPL = "FeedbackServiceImpl";
    public static final String FEEDBACK_ID = "id";
    public static final String REPLY_URL = "feedback/reply?id=";
    public static final String SHOW_IMAGE_URL = "feedback/show?id=";
    public static final String STATUS = "status";
    public static final String QID = "QID";
    public static final String CREATIONDATE = "creationDate";
    public static final String BUNDLE_NAME = "feedback_messages";
    public static final String RESPONSELENGTH = "Response content too large";
    public static final String THANKMSG = "Thank you for getting in touch! We try to respond as soon as possible, so one of our Customer Service colleagues will get back to you within a few hours. Have a great day ahead!";
}
