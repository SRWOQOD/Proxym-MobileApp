package com.woqod.feedback.constant;

public final class TemplateConstant {
    private TemplateConstant() {
    }

    public static final String TEMPLATES_MANAGEMENT_URL = "/templates";
    public static final String ADD_TEMPLATE = "AddTemplate";
    public static final String UPDATE_TEMPLATE = "UpdateTemplate";
    public static final String VIEW_TEMPLATE = "ViewTemplate";
    public static final String TEMPLATES_LIST = "listTemplates";
    public static final String TEMPLATE_LAZY_MODEL = "TemplateLazyModel";
    public static final String TEMPLATES = "templates";
    public static final String TEMPLATE_REST_CLIENT = "TemplateRestClient";
    public static final String TEMPLATE_SERVICE_IMPL = "TemplateServiceImpl";
    public static final String TEMPLATE_VIEW_MODEL = "[TemplateViewModel]";
    public static final String ADD_TEMPLATE_VIEW_MODEL = "[AddTemplateViewModel]";
    public static final String EDIT_TEMPLATE_VIEW_MODEL = "[EditTemplateViewModel]";
    public static final String TEMPLATE_DATE = "createdDate";
    public static final String TEMPLATE_MESSAGE = "content";
    public static final String TEMPLATE_TITLE = "title";
    public static final String BUNDLE_NAME = "feedback_messages";
    public static final String EDIT_URL = "templates/edit?id=";
    public static final String TEMPLATE_ID = "id";
    public static final String RESPONSELENGTH = "Template content too large";
}
