package com.woqod.feedback.viewmodel;


import com.google.common.base.Strings;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.enums.MenuEnum;
import com.woqod.feedback.lazymodel.FeedbackLazyModel;
import com.woqod.feedback.service.FeedbackService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.FeedbackCategoryEnum;
import wq.woqod.resources.enumerations.FeedbackSectorEnum;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class FeedbackViewModel {

    private static final String SERVICE_NAME = "FEEDBACK_LIST";
    /*
    Beans
     */
    private final FeedbackService feedbackService;

    /*
    state
     */
    private FeedbackResource filterFeedbackResource;
    private FeedbackResource feedbackResource;
    private LazyDataModel<FeedbackResourceWithoutPhoto> lazyModel;
    private List<FeedbackCategoryEnum> category;
    private List<FeedbackSectorEnum> sector;
    private DataFactory dataFactory;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private Integer numberOfFeedbacks;

    @Autowired
    public FeedbackViewModel(FeedbackService feedbackService, DataFactory dataFactory) {
        this.dataFactory = dataFactory;
        this.feedbackService = feedbackService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", FeedbackConstant.FEEDBACK_VIEW_MODEL);
        lazyModel = new FeedbackLazyModel(feedbackService);
        feedbackResource = new FeedbackResource();
        category = Arrays.asList(FeedbackCategoryEnum.values());
        sector = Arrays.asList(FeedbackSectorEnum.values());
        uriParams = new HashMap<>();
        numberOfFeedbacks=feedbackService.count();

        filterFeedbackResource = new FeedbackResource();
        filterFeedbackResource.setStatus(null);
        filterFeedbackResource.setConnected(null);
        filterFeedbackResource.setQid(null);

        search();
    }

    public void clear() {
        log.debug("{} clear", FeedbackConstant.FEEDBACK_VIEW_MODEL);
        uriParams = new HashMap<>();
        filterFeedbackResource = new FeedbackResource();
        search();
    }

    public void search() {
        log.debug("{} search", FeedbackConstant.FEEDBACK_VIEW_MODEL);
        uriParams = new HashMap<>();
        if (filterFeedbackResource.getCategory() != null) {
            uriParams.put(FeedbackConstant.FEEDBACK_CATEGORY_ENUM, filterFeedbackResource.getCategory().name());
        }
        if (filterFeedbackResource.getSector() != null) {
            uriParams.put(FeedbackConstant.FEEDBACK_SECTOR_ENUM, filterFeedbackResource.getSector().name());
        }
        if (filterFeedbackResource.getConnected() != null) {
            uriParams.put(FeedbackConstant.FEEDBACK_IS_CONNECTED, String.valueOf(filterFeedbackResource.getConnected()));
        }
        if (filterFeedbackResource.getStatus() != null) {
            uriParams.put(FeedbackConstant.STATUS, String.valueOf(filterFeedbackResource.getStatus()));
        }
        if (filterFeedbackResource.getQid() != null) {
            uriParams.put("Qid", Base64.getEncoder().encodeToString(filterFeedbackResource.getQid().trim().getBytes()));
        }
        if (filterFeedbackResource.getFeedbackNumber() != null) {
            uriParams.put(FeedbackConstant.FEEDBACK_NUMBER, String.valueOf(filterFeedbackResource.getFeedbackNumber()));
        }
        if (filterFeedbackResource.getCreationDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String dateString = format.format(filterFeedbackResource.getCreationDate());
            uriParams.put(FeedbackConstant.CREATIONDATE, dateString);
        }

        ((FeedbackLazyModel) lazyModel).setSearchFlag(true);
        ((FeedbackLazyModel) lazyModel).setLazyModelParams(uriParams);
    }

    public void delete(Long id) {
        log.debug("{} delete", FeedbackConstant.FEEDBACK_VIEW_MODEL);
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, String.valueOf(id));
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_FEEDBACKS.name());
        try {
            feedbackService.delete(serviceData);
            BoUtils.showsuccesspopup();
        } catch (Exception e) {
            BoUtils.showErrorPopup("Error ", "An error has occurred , please try later");
        }
        numberOfFeedbacks = feedbackService.count();
    }

    public void close(Long id) {
        log.debug("{} close", FeedbackConstant.FEEDBACK_VIEW_MODEL);
        FeedbackResource feedbackResourceToClose = feedbackService.getFeedbackById(String.valueOf(id));
        feedbackResourceToClose.setStatus(false);
        Map<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, feedbackResourceToClose);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.CLOSE_FEEDBACKS.name());
        feedbackService.close(serviceData);
        dataFactory.redirect("feedback");
    }

    public String getDisplayFeedbackFeature() {
        return MenuEnum.DISPLAY_FEEDBACKS.name();
    }

    public String getViewFeedbackFeature() {
        return MenuEnum.VIEW_FEEDBACKS.name();
    }

    public String getReplyFeedbackFeature() {
        return MenuEnum.REPLY_FEEDBACKS.name();
    }

    public String getDeleteFeedbackFeature() {
        return MenuEnum.DELETE_FEEDBACKS.name();
    }

    public String getExportFeedbackFeature() {
        return MenuEnum.EXPORT_FEEDBACKS.name();
    }

    public String editUrl(long id) {
        return FeedbackConstant.REPLY_URL.concat(String.valueOf(id));
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(feedbackService.feedbacks(uriParams), "export/feedbacks.jrxml", "Feedbacks List", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Feedbacks List.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        List<FeedbackResource> feedbackResources = feedbackService.feedbacks(uriParams);
        for(FeedbackResource feedback : feedbackResources) {
            feedback.setQid(BoUtils.decodeFromBase64(feedback.getQid()));
        }
        String base64 = GenerateJasperReport.generateReport(feedbackResources, "feedback/feedbacks.jrxml", "Feedbacks List", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Feedbacks List.pdf").stream(() -> is).build();
    }

    public TimeZone getTimeZone() {
        return TimeZone.getDefault();
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            byte[] valueDecoded = Base64.getDecoder().decode(qid);
            return new String(valueDecoded);
        } else {
            return qid;
        }
    }
}
