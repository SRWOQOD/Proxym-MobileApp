package com.woqod.feedback.service;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;

import java.util.List;
import java.util.Map;


/**
 * Created by Samia DHAHRI on 08/2020.
 */
public interface FeedbackService {

    PaginatedListResponse<FeedbackResourceWithoutPhoto> getPaginatedFeedback(Map<String, String> uriParams);

    void save(Map<String, Object> serviceData);

    void delete(Map<String, Object> serviceData);

    void close(Map<String, Object> uriParams);

    void newResponse(Map<String, Object> uriParams);

    void newResponseAnonym(Map<String, Object> uriParams);

    FeedbackResource getFeedbackById(String id);

    List<FeedbackResource> feedbacks(Map<String, String> uriParams);

    Integer count();
}
