package com.woqod.feedback.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import java.util.List;
import java.util.Map;

public interface TemplateService {

    PaginatedListResponse<FeedbackTemplateResource> getPaginatedTemplate(Map<String, String> uriParams);

    void save(Map<String, Object> serviceData);

    void edit(Map<String, Object> uriParams);

    void delete(Map<String, Object> uriParams);

    FeedbackTemplateResource findTemplate(String id);

    FeedbackTemplateResource findTemplateByTitle(String title);

    List<FeedbackTemplateResource> getAllTemplates(Map<String, String> uriParams);

    Integer count();

}
