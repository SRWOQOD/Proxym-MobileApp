package com.woqod.feedback.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.FeedbackConstant;
import com.woqod.feedback.service.FeedbackService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class FeedbackLazyModel extends LazyDataModel<FeedbackResourceWithoutPhoto> {

    private final transient FeedbackService feedbackService;
    private static final long serialVersionUID = 1;
    private Map<String, String> uriParams;

    private Boolean searchFlag = false;

    public FeedbackLazyModel(FeedbackService feedbackService) {
        this.feedbackService = feedbackService;
        this.uriParams = new HashMap<>();
    }

    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtred and paginated data
     */
    @Override
    public List<FeedbackResourceWithoutPhoto> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {

        if (BooleanUtils.isTrue(searchFlag)) {
            first = 0;
        }
        try {
            PaginatedListResponse<FeedbackResourceWithoutPhoto> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));
            response = feedbackService.getPaginatedFeedback(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchFlag = false;
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", FeedbackConstant.FEEDBACK_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, FeedbackConstant.FEEDBACKS);
            return new ArrayList<>();
        }

    }
}