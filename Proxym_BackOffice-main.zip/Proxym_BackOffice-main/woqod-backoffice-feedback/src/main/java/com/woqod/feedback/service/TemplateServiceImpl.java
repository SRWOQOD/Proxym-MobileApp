package com.woqod.feedback.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.rest.TemplateRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.FeedbackTemplateResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class TemplateServiceImpl implements TemplateService {

    private final TemplateRestClient templateRestClient;

    @Autowired
    public TemplateServiceImpl(TemplateRestClient templateRestClient) {
        this.templateRestClient = templateRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedTemplate(Map<String, String> uriParams) {
        log.debug("{}getPaginatedFeedback", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        return templateRestClient.paginatedParams(uriParams);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void save(Map<String, Object> serviceData) {
        log.debug("{}save", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        FeedbackTemplateResource feedbackTemplateResource = (FeedbackTemplateResource) serviceData.get(UtilsConstants.POST_DATA);
        templateRestClient.save(feedbackTemplateResource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void edit(Map<String, Object> serviceData) {
        log.debug("{} edit", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        FeedbackTemplateResource feedbackTemplateResource = (FeedbackTemplateResource) serviceData.get(UtilsConstants.POST_DATA);
        templateRestClient.update(feedbackTemplateResource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void delete(Map<String, Object> serviceData) {
        log.debug("{}delete", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        String templateId = (String) serviceData.get(UtilsConstants.POST_DATA);
        templateRestClient.delete(templateId);
    }

    @Override
    public FeedbackTemplateResource findTemplate(String id) {
        log.debug("{}findTemplate", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        return templateRestClient.findTemplateByID(id);
    }

    @Override
    public FeedbackTemplateResource findTemplateByTitle(String title) {
        log.debug("{}findTemplateByTitle", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        return templateRestClient.findTemplateByTitle(title);
    }

    @Override
    public List<FeedbackTemplateResource> getAllTemplates(Map<String, String> uriParams) {
        log.debug("{} getAllTemplates", TemplateConstant.TEMPLATE_SERVICE_IMPL);
        return templateRestClient.getAllTemplates(uriParams);
    }

    @Override
    public Integer count() {
        return templateRestClient.count();
    }

}
