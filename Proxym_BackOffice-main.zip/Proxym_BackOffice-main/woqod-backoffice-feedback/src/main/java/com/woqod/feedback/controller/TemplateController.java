package com.woqod.feedback.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.feedback.constant.TemplateConstant;
import com.woqod.feedback.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
@RequestMapping(value = TemplateConstant.TEMPLATES_MANAGEMENT_URL)
@Data
public class TemplateController {
    private final Permissions permissions;

    @Autowired
    public TemplateController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_TEMPLATES.name(), TemplateConstant.TEMPLATES_LIST);
    }

    /**
     * used to display add template response view
     */
    @GetMapping("/new")
    public ModelAndView addDisplay() {
        return permissions.getModelAndView(MenuEnum.ADD_TEMPLATE.name(), TemplateConstant.ADD_TEMPLATE);
    }

    /**
     * used to display add template response view
     */
    @GetMapping("/edit")
    public ModelAndView editDisplay() {
        return permissions.getModelAndView(MenuEnum.VIEW_TEMPLATE.name(), TemplateConstant.VIEW_TEMPLATE);
    }

    /**
     * used to display add template response view
     */
    @GetMapping("/viewtemplate")
    public ModelAndView viewDisplay() {
        return permissions.getModelAndView(MenuEnum.VIEW_TEMPLATE.name(), TemplateConstant.VIEW_TEMPLATE);
    }

}
