package com.woqod.area.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AreaBoModel {
    private String areaNameEn;
    private String areaNameAr;

}
