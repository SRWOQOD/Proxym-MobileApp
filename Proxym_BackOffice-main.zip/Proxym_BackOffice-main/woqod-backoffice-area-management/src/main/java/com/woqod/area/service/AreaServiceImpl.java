package com.woqod.area.service;


import com.woqod.area.constant.AreaConstant;
import com.woqod.area.rest.AreaRestTemplate;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.AreaCheckResource;
import wq.woqod.resources.resources.AreaResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class AreaServiceImpl implements AreaService {

    private final AreaRestTemplate areaRestTemplate;

    @Autowired
    public AreaServiceImpl(AreaRestTemplate areaRestTemplate) {
        this.areaRestTemplate = areaRestTemplate;
    }

    @Override
    public PaginatedListResponse<AreaResource> getPaginatedArea(Map<String, String> uriParams) {
        log.debug("{} getPaginatedArea ", AreaConstant.AREA_SERVICE_IMPL);
        return areaRestTemplate.paginatedParams(uriParams);
    }

    @Override
//    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void save(HashMap<String, Object> serviceData) {
        AreaResource areaResource = (AreaResource) serviceData.get(UtilsConstants.POST_DATA);
        areaRestTemplate.save(areaResource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void edit(HashMap<String, Object> serviceData) {
        AreaResource areaResource = (AreaResource) serviceData.get(UtilsConstants.POST_DATA);
        areaRestTemplate.update(areaResource);
    }

    @Override
    public AreaResource getAreaById(Long id) {
        return areaRestTemplate.getAreaById(id);

    }

    @Override
    public List<AreaResource> areas(Map<String, String> uriParams) {
        return areaRestTemplate.getAreas(uriParams);
    }

    @Override
    public void checkArea(String areaNameAr, String areaNameEn) {
        AreaCheckResource areaCheckResource = new AreaCheckResource();
        areaCheckResource.setAreaNameAr(areaNameAr);
        areaCheckResource.setAreaNameEn(areaNameEn);
        areaRestTemplate.checkArea(areaCheckResource);
    }

    @Override
    public Integer count() {
        return areaRestTemplate.count();
    }

}
