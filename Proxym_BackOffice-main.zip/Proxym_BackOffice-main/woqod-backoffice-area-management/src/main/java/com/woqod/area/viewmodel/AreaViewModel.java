package com.woqod.area.viewmodel;


import com.woqod.area.constant.AreaConstant;
import com.woqod.area.enums.MenuEnum;
import com.woqod.area.lazymodel.AreaLazyModel;
import com.woqod.area.models.AreaBoModel;
import com.woqod.area.service.AreaService;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AreaResource;

import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
@Component
@Scope("view")
public class AreaViewModel {

    private static final String SERVICE_NAME = "AREA";
    /*
   Beans
    */
    private final AreaService areaService;

    /*
    state
    */
    private AreaBoModel filterAreaResource;
    private LazyDataModel<AreaResource> lazyModel;
    private final Permissions permissions;
    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private Integer areasNumber;

    @Autowired
    public AreaViewModel(AreaService areaService, Permissions permissions) {
        this.areaService = areaService;
        this.permissions = permissions;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        log.debug("{} init", AreaConstant.AREA_VIEW_MODEL);
        lazyModel = new AreaLazyModel(areaService);
        uriParams = new HashMap<>();
        areasNumber = areaService.count();
        filterAreaResource = new AreaBoModel();
        search();
    }

    public void clear() {
        filterAreaResource = new AreaBoModel();
        uriParams = new HashMap<>();
        search();
    }

    public void search() {
        log.debug("{} search", AreaConstant.AREA_VIEW_MODEL);
        uriParams = new HashMap<>();

        if (filterAreaResource.getAreaNameEn() != null && !filterAreaResource.getAreaNameEn().isEmpty()) {
            uriParams.put(AreaConstant.ENGLISH_TITLE, filterAreaResource.getAreaNameEn().trim());
        }
        if (filterAreaResource.getAreaNameAr() != null && !filterAreaResource.getAreaNameAr().isEmpty()) {
            uriParams.put(AreaConstant.ARABIC_TITLE, filterAreaResource.getAreaNameAr().trim());
        }

        ((AreaLazyModel) lazyModel).setSearchData(true);
        ((AreaLazyModel) lazyModel).setLazyModelParams(uriParams);

    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(areaService.areas(uriParams), "export/area.jrxml", "Area of Residence", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));

        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Area.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(areaService.areas(uriParams), "area/area.jrxml", "Area of Residence", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));

        file = DefaultStreamedContent.builder().contentType("text/plain").name("Area.pdf").stream(() -> is).build();

    }

    public String getDisplayAreaFeature() {
        return MenuEnum.DISPLAY_AREAS.name();
    }

    public String editUrl(long id) {
        return AreaConstant.EDIT_URL.concat(String.valueOf(id));
    }


}
