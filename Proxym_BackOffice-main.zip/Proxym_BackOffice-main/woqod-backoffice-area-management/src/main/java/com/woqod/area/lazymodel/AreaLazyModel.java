package com.woqod.area.lazymodel;

import com.woqod.area.constant.AreaConstant;
import com.woqod.area.service.AreaService;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.AreaResource;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class AreaLazyModel extends LazyDataModel<AreaResource> implements Serializable {

    private final transient AreaService areaService;
    private static final long serialVersionUID = 1;
    private Boolean searchData = false;
    private Map<String, String> uriParams;

    public AreaLazyModel(AreaService areaService) {
        this.areaService = areaService;
        this.uriParams = new HashMap<>();
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        if (rowIndex == -1 || getPageSize() == 0) {
                super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % getPageSize());

        }
    }

    /**
     * used to get filtered and paginated data
     */
    @Override
    public List<AreaResource> load(int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            if (BooleanUtils.isTrue(searchData)) {
                first = 0;
            }
            PaginatedListResponse<AreaResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));
            response = areaService.getPaginatedArea(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            setSearchData(false);
            return response.getList();

        } catch (Exception e) {
            log.error("{} {} {}", AreaConstant.AREA_LAZY_MODEL, UtilsConstants.ERROR_OCCURRED_WHEN_LOADING_DATA, AreaConstant.AREAS);
            return new ArrayList<>();
        }

    }
}
