package com.woqod.area.constant;

public final class AreaConstant {
    private AreaConstant() {
    }

    public static final String AREA_URL = "/area";
    public static final String AREAS_LIST = "listAreas";
    public static final String AREA_LAZY_MODEL = "AreaLazyModel";
    public static final String AREAS = "areas";
    public static final String AREA_REST_CLIENT = "AreaRestTemplate";
    public static final String AREA_VIEW_MODEL = "AreaViewModel";
    public static final String ADD_AREA_VIEW_MODEL = "AddAreaViewModel";
    public static final String AREA_SERVICE_IMPL = "AreaServiceImpl";
    public static final String ENGLISH_TITLE = "title";
    public static final String ARABIC_TITLE = "arabicTitle";
    public static final String ADD_AREA = "addArea";
    public static final String EDIT_AREA = "editArea";
    public static final String ADD_AREA_URL = "/area/add";
    public static final String EDIT_URL = "area/edit?id=";
    public static final String BUNDLE = "area_messages";


}
