package com.woqod.area.viewmodel;


import com.woqod.area.enums.MenuEnum;
import com.woqod.area.service.AreaService;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AreaResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

@Data
@Slf4j
@Component
@NoArgsConstructor
@Scope("view")
public class EditAreaViewModel {

    /*
     Beans
     */
    private AreaService areaService;
    private DataFactory dataFactory;

    /*
      state
      */

    private String validationError = "Validation Error";

    private AreaResource areaResource;
    private AreaResource initialAreaResource;
    private Long areaId;


    @Autowired
    public EditAreaViewModel(AreaService areaService, DataFactory dataFactory) {
        this.areaService = areaService;
        this.dataFactory = dataFactory;
    }


    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primefaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * used to initialize filter before display view
     */
    public void init() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                .getRequest();
        this.areaId = Long.parseLong(request.getParameter("id"));
        areaResource = areaService.getAreaById(areaId);
        initialAreaResource = areaService.getAreaById(areaId);
    }

    /**
     * Clear function
     */
    public void clear() {
        init();
    }


    public String getEditAreaFeature() {
        return MenuEnum.EDIT_AREA.name();
    }

    public void save() {

        if (!StringUtils.isNumeric(areaResource.getId().toString())) {
            BoUtils.showErrorPopup(validationError, "Id must be a digital number");
            return;
        }
        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLongitude()))) {
            BoUtils.showErrorPopup(validationError, "Longitude must be a digital number");
            return;
        }
        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLatitude()))) {
            BoUtils.showErrorPopup(validationError, "Latitude must be a digital number");
            return;
        }

        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, areaResource);
        serviceData.put(UtilsConstants.OLD_DATA, initialAreaResource);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.EDIT_AREA.name());
        try {

            if (!(areaResource.getAreaNameAr().equals(initialAreaResource.getAreaNameAr()))) {
                areaService.checkArea(areaResource.getAreaNameAr(), null);
            }
            if (!(areaResource.getAreaNameEn().equals(initialAreaResource.getAreaNameEn()))) {
                areaService.checkArea(null, areaResource.getAreaNameEn());
            }

            areaService.edit(serviceData);
            dataFactory.redirect("area");

        } catch (RestBackendException e) {
            if (e.getCode().equals("203")) {
                BoUtils.showErrorPopup("Area", "Area already exist");
            } else {
                BoUtils.showErrorPopup("Error ", "An error has occurred , please try later");

            }
        }

    }

    public Boolean checkFloat(String str) {
        try {
            Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }

}
