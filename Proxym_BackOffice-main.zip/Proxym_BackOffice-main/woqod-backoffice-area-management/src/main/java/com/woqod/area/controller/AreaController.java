package com.woqod.area.controller;


import com.woqod.area.constant.AreaConstant;
import com.woqod.area.enums.MenuEnum;
import com.woqod.bo.commons.security.Permissions;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Data
@Slf4j
@Controller
@RequestMapping(value = AreaConstant.AREA_URL)
public class AreaController {

    private final Permissions permissions;

    @Autowired
    public AreaController(Permissions permissions) {
        this.permissions = permissions;
    }

    /**
     * used to display area view
     */

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_AREAS.name(), AreaConstant.AREAS_LIST);
    }

    /**
     * used to display add area view
     */
    @GetMapping("/add")
    public ModelAndView addDisplay() {
        return permissions.getModelAndView(MenuEnum.ADD_AREA.name(), AreaConstant.ADD_AREA);
    }

    @GetMapping("/edit")
    public ModelAndView edit() {
        return permissions.getModelAndView(MenuEnum.EDIT_AREA.name(), AreaConstant.EDIT_AREA);
    }
}
