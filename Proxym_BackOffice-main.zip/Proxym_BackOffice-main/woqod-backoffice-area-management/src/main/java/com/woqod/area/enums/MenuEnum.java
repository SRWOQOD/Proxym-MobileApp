package com.woqod.area.enums;


import com.woqod.area.constant.AreaConstant;
import com.woqod.bo.commons.enums.*;

import java.util.Arrays;
import java.util.Optional;


public enum MenuEnum implements Menu {


    DISPLAY_AREAS(new Bundle(AreaConstant.BUNDLE, "DisplayAreas"), AreaConstant.AREA_URL, "", "", true, ParentModuleEnum.AREA_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    ADD_AREA(new Bundle(AreaConstant.BUNDLE, "AddArea"), AreaConstant.ADD_AREA_URL, "", "", true, ParentModuleEnum.AREA_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 2L)),
    EDIT_AREA(new Bundle(AreaConstant.BUNDLE, "EditArea"), "", "", "", true, DISPLAY_AREAS.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    ;

    MenuEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }
}
