package com.woqod.area.viewmodel;


import com.woqod.area.constant.AreaConstant;
import com.woqod.area.enums.MenuEnum;
import com.woqod.area.service.AreaService;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AreaResource;

import javax.faces.annotation.ManagedProperty;
import javax.faces.context.FacesContext;
import java.util.HashMap;

@Data
@Slf4j
@Component
@NoArgsConstructor
@Scope("view")
public class AddAreaViewModel {

    /*
     Beans
     */
    private AreaService areaService;
    private DataFactory dataFactory;

    /*
      state
      */

    private String validationError = "Validation Error";
    @ManagedProperty("#{param.area}")
    private AreaResource areaResource;


    @Autowired
    public AddAreaViewModel(AreaService areaService, DataFactory dataFactory) {
        this.areaService = areaService;
        this.dataFactory = dataFactory;
    }


    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primefaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * used to initialize filter before display view
     */
    public void init() {

        log.debug("{} init ", AreaConstant.ADD_AREA_VIEW_MODEL);
        areaResource = new AreaResource();

    }

    /**
     * Clear function
     */
    public void clear() {
        log.debug("{} clear ", AreaConstant.ADD_AREA_VIEW_MODEL);
        init();
    }


    public String getAddAreaFeature() {
        return MenuEnum.ADD_AREA.name();
    }


    public void save() {
        log.debug(String.valueOf(this.areaResource));

        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLongitude()))) {
            BoUtils.showErrorPopup(validationError, "Longitude must be a digital number");
            return;
        }
        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLatitude()))) {
            BoUtils.showErrorPopup(validationError, "Latitude must be a digital number");
            return;
        }
        if (areaResource.getAreaNameEn() == null) {
            BoUtils.showErrorPopup(validationError, "English Area Name is Required !");
            return;
        }
        if (areaResource.getAreaNameAr() == null) {
            BoUtils.showErrorPopup(validationError, "Arabic Area Name is Required !");
            return;
        }
        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLatitude()))) {
            BoUtils.showErrorPopup(validationError, " Area Latitude is Required !");
            return;
        }
        if (!BooleanUtils.isTrue(checkFloat(areaResource.getLongitude()))) {
            BoUtils.showErrorPopup(validationError, " Area Longitude is Required !");
            return;
        }

        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.POST_DATA, areaResource);
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.ADD_AREA.name());

        try {
            areaService.save(serviceData);
            dataFactory.redirect("area");

        } catch (
                RestBackendException e) {
            if (e.getCode().equals("203")) {
                BoUtils.showErrorPopup("Area", "Area already exists");
            } else {
                BoUtils.showErrorPopup("Error ", "An error has occurred , please try later");

            }
        }

    }

    public Boolean checkFloat(String str) {
        try {
            Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }

}

