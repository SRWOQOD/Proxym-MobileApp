package com.woqod.area.service;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.AreaResource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface AreaService {
    PaginatedListResponse<AreaResource> getPaginatedArea(Map<String, String> uriParams);

    void save(HashMap<String, Object> serviceData);

    void edit(HashMap<String, Object> serviceData);

    AreaResource getAreaById(Long id);

    List<AreaResource> areas(Map<String, String> uriParams);

    void checkArea(String areaNameAr, String areaNameEn);

    Integer count();
}
