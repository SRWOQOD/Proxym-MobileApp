package com.woqod.area;


import com.woqod.area.enums.MenuEnum;
import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;


@Component
public class AreaBootStrap {
    private static final String AREAS_MANAGEMENT = "Area_Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(AREAS_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }

}
