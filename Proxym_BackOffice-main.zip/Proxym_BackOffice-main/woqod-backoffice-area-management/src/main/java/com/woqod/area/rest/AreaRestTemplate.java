package com.woqod.area.rest;

import com.woqod.area.constant.AreaConstant;
import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.AreaCheckResource;
import wq.woqod.resources.resources.AreaResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/area.properties")
public class AreaRestTemplate {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private String area;
    private String checkArea;
    private String count;

    @Autowired
    public AreaRestTemplate(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.area.paginated}")
            String area, @Value("${uri.ws.area.check}") String checkArea, @Value("${uri.ws.area.count}") String count) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.area = area;
        this.checkArea = checkArea;
        this.count = count;
    }

    /**
     * used to get parameters paginated and filtered
     */
    public PaginatedListResponse<AreaResource> paginatedParams(Map<String, String> filters) {
        log.debug("{} paginatedParams", AreaConstant.AREA_REST_CLIENT);
        String uri = area.concat("/filtered");

        return (PaginatedListResponse<AreaResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, filters),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<AreaResource>>>() {
                        });
    }

    public Boolean save(AreaResource areaResource) {
        String uri = area;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), areaResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to update Parameter
     */
    public Boolean update(AreaResource areaResource) {
        String uri = area + "/update";
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), areaResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    /**
     * used to get Area By Id
     */
    public AreaResource getAreaById(Long areaId) {
        String uri = area.concat("/").concat(areaId.toString());
        ObjectResponse<AreaResource> response = (ObjectResponse<AreaResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<AreaResource>>>() {
                        });
        return response.getObject();
    }

    public Boolean checkArea(AreaCheckResource areaResource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(checkArea), areaResource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public List<AreaResource> getAreas(Map<String, String> uriParams) {
        String uri = "/area";
        return ((ListResponse<AreaResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<AreaResource>>>() {
                        })).getList();

    }
    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
}
