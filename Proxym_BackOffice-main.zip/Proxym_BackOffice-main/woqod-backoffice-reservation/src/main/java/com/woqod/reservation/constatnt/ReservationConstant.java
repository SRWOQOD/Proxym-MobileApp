package com.woqod.reservation.constatnt;

public final class ReservationConstant {
    public static final String BUNDLE_NAME = "reservation_messages";
    public static final String HIDE_RESERVATION_URL = "/reservation/hide";
    public static final String RESERVATION_URL = "/reservation";
    public static final String HIDE_RESERVATION_VIEW = "hide-reservation";
    public static final String LIST_RESERVATION_VIEW = "reservation-list";

    private ReservationConstant() {
    }


}
