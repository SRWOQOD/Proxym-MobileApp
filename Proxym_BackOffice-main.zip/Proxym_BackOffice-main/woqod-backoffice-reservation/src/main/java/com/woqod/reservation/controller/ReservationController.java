package com.woqod.reservation.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.reservation.constatnt.ReservationConstant;
import com.woqod.reservation.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@Data
@Slf4j
public class ReservationController {
    private final Permissions permissions;

    @Autowired
    public ReservationController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping(value = ReservationConstant.RESERVATION_URL)
    public ModelAndView displayReservations() {
        return permissions.getModelAndView(MenuEnum.RESERVATION_LIST.name(), ReservationConstant.LIST_RESERVATION_VIEW);
    }

    @GetMapping(ReservationConstant.HIDE_RESERVATION_URL)
    public ModelAndView displayHideReservation() {
        return permissions.getModelAndView(MenuEnum.HIDE_RESERVATION.name(), ReservationConstant.HIDE_RESERVATION_VIEW);
    }
}
