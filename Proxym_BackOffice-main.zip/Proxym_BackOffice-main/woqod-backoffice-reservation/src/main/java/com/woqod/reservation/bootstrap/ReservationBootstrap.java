package com.woqod.reservation.bootstrap;


import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.reservation.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Component
public class ReservationBootstrap {
    private static final String RESERVATION_MANAGEMENT = "reservation_Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(RESERVATION_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }

}
