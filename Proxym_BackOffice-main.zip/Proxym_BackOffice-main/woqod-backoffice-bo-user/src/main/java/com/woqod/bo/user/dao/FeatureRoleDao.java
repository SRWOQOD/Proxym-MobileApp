package com.woqod.bo.user.dao;


import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.dao.entity.FeatureRole;
import com.woqod.bo.user.dao.entity.Role;

import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:49
 */
public interface FeatureRoleDao {
    List<FeatureRole> findAllByRoleName(String code);

    /**
     * Used to save Feature Role list
     *
     * @param featureRole
     */
    void save(List<FeatureRole> featureRole);

    /**
     * Used to update FeatureRole list
     *
     * @param featureRole
     */
    void update(List<FeatureRole> featureRole);

    /**
     * Used to retrieve Feature Role list
     */
    List<FeatureRole> getFeatureRoles();

    /**
     * Return role' FeatureRole
     */
    List<FeatureRole> getFeatureRoleByRole(Role role);

    /**
     * Used to delete role'FeatureRole
     */
    void deleteFeatureRoleByRole(Role role);

    /**
     * Used to delete role'FeatureRole
     */
    void deleteFeatureRoles(List<FeatureRole> frs);

    /**
     * Get FeatureRole By featureCode
     */
    List<FeatureRole> getFeatureRoleByFeature(Feature feature);

    /**
     * Used to retieve one feature role by feature and role
     */
    FeatureRole findOneByFeatureAndRole(Feature feature, Role role);

    /**
     * used to retieve one feature role by feature name and role name
     */
    FeatureRole getByFeatureNameAndRoleName(String feature, String role);


}
