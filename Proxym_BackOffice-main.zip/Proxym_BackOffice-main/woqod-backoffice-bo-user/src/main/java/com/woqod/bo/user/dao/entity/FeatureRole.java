package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;

@Entity
@Table(name = Constants.BO_FEATURE_ROLE, uniqueConstraints = @UniqueConstraint(columnNames = {"code", "role"}))
public class FeatureRole extends Audit {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "code", nullable = false, referencedColumnName = "code")
    private Feature feature;

    @ManyToOne(cascade = {CascadeType.MERGE})
    @JoinColumn(name = "role", nullable = false, referencedColumnName = "role_name")
    private Role role;

    public FeatureRole() {

    }


    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public FeatureRole(Feature feature, Role role) {
        this.feature = feature;
        this.role = role;
    }

    public Feature getFeature() {
        return feature;
    }

    public void setFeature(Feature feature) {
        this.feature = feature;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
