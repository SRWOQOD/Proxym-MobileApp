package com.woqod.bo.user.controller;


import com.woqod.bo.commons.interfaces.FeatureRoleService;
import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.user.enums.MenuEnum;
import com.woqod.bo.user.service.RoleService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by haithem.ben-chaaben on 28/11/2018.
 */

@Slf4j
@Controller
@RequestMapping(value = "/borolemanagement")
@Data
public class RoleManagementController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RoleManagementController.class);
    private static final String SERVICE_NAME = "BO_ROLES";

    private final Permissions permissions;
    private final RoleService roleService;
    private final FeatureService featureService;
    private final FeatureRoleService featureRoleService;

    private RoleModel role;
    private RoleModel editRole = new RoleModel();
    private RoleModel filter;
    private List<RoleModel> roles = new ArrayList<>();
    private List<RoleModel> filtredRoles = new ArrayList<>();
    private List<FeatureModel> listFeatureParent = new ArrayList<>();
    private FeatureModel featureParentModel = new FeatureModel();
    private FeatureModel featureChild = new FeatureModel();
    private long numberOfRoles;

    @Autowired
    public RoleManagementController(Permissions permissions, RoleService roleService, FeatureService featureService, FeatureRoleService featureRoleService) {
        this.permissions = permissions;
        this.roleService = roleService;
        this.featureService = featureService;
        this.featureRoleService = featureRoleService;
    }

    @GetMapping(value = "")
    public ModelAndView display() {
        MenuEnum menuEnum = MenuEnum.DISPLAY_BO_ROLE_MANAGEMENT;
        ModelAndView modelAndView = new ModelAndView();
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            LOGGER.info("[RoleManagementController] display ");
            init();
            modelAndView.setViewName("roles/boroles");
        } else {
            modelAndView.setViewName("access");
        }
        return modelAndView;
    }

    /**
     *
     */
    public void init() {
        LOGGER.info("[RoleManagementController] init ");

        role = new RoleModel();
        filter = new RoleModel();
        filtredRoles = new ArrayList<>();
        roles = roleService.getAllRoles();
        roles = roles.stream().filter(item -> !item.getName().equals("SUPER_ADMIN")).collect(Collectors.toList());
        filtredRoles = roles;
        numberOfRoles = roles.size();
    }

    /**
     *
     */
    public void search() {
        LOGGER.info("[RoleManagementController] search role ");
        List<RoleModel> frole = roleService.search(filter.getName());
        roles = new ArrayList<>();
        if (frole != null) {
            roles = frole;
            roles = roles.stream().filter(item -> !item.getName().equals("SUPER_ADMIN")).collect(Collectors.toList());
        }
    }


    public Boolean delete(RoleModel r) {
        LOGGER.info("[RoleManagementController] delete role ");
        MenuEnum menuEnum = MenuEnum.DELETE_ROLE_BO_USER;
        try {
            if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
                 // effacer le role de BD
                Boolean isSuccess = roleService.delete(r);
                // si la procédure de suppression se passe convenablement affiché pop up de
                // success
                if (BooleanUtils.isTrue(isSuccess)) {
                    FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Role deleted successfully.",
                            "");
                    FacesContext.getCurrentInstance().addMessage(null, msg);
                    roles.remove(r);
                    filtredRoles.remove(r);
                    BoUtils.showsuccesspopup();
                    numberOfRoles = roleService.count();
                    return true;
                }
                // si non affiché Error pop up
                else {
                    FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error when deleting the role",
                            "");
                    FacesContext.getCurrentInstance().addMessage(null, msg);
                    init();
                    return false;
                }

            } else {
// access denied
                init();
                permissions.getDataFactory().redirect("access");
                return false;
            }
         // dans le cas ou un erreur est rencontré affiché Error Pop up
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            init();
            return false;
        }
    }

    /**
     *
     */
    public void clear() {
        init();
    }


}
