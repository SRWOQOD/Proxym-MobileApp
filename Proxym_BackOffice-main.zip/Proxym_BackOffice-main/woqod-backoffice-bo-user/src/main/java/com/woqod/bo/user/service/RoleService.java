package com.woqod.bo.user.service;


import com.woqod.bo.commons.model.RoleModel;

import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:07
 */
public interface RoleService {

    /**
     * used to save role
     *
     * @param role
     * @return
     */
    RoleModel save(RoleModel role);

    /**
     * used to retrive all roles
     *
     * @return
     */
    List<RoleModel> getAllRoles();

    /**
     * used to retrieve role by name
     *
     * @param name
     * @return
     */
    RoleModel findOneByName(String name);

    RoleModel findOneRoleByName(String name);

    /**
     * used to delete role
     *
     * @param role
     * @return
     */
    Boolean delete(RoleModel role);

    List<RoleModel> search(String name);

    long count();
}
