package com.woqod.bo.user.service.impl;


import com.woqod.bo.commons.interfaces.AuthorityService;
import com.woqod.bo.commons.model.AuthorityModel;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.commons.model.UserRoleForm;
import com.woqod.bo.user.dao.AuthorityDao;
import com.woqod.bo.user.dao.RoleDao;
import com.woqod.bo.user.dao.UserDao;
import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.entity.User;
import com.woqod.bo.user.mapper.AuthorityMapper;
import com.woqod.bo.user.mapper.UserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@EnableTransactionManagement
public class AuthorityServiceImpl implements AuthorityService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorityServiceImpl.class);
    private final AuthorityDao authorityDao;
    private final UserDao userDao;
    private final RoleDao roleDao;

    @Autowired
    public AuthorityServiceImpl(AuthorityDao authorityDao, UserDao userDao,
                                RoleDao roleDao) {
        this.authorityDao = authorityDao;
        this.userDao = userDao;
        this.roleDao = roleDao;
    }

    @Override
    public List<AuthorityModel> search(UserRoleForm filter, LocalDate startCreatedAtDate, LocalDate endCreatedAtDate) {
        return AuthorityMapper
                .listAuthorityEntityToListAuthorityModel(authorityDao
                        .search(filter, startCreatedAtDate, endCreatedAtDate));
    }

    @Override
    @Transactional
    public void save(String roleName, UserModel userModel) {
        // retreive role from db
        Role role = roleDao.findOneRoleByName(roleName);
        // save user
        User user = userDao.saveUser(UserMapper.userModelToUserEntity(userModel));
        // prepare authority
        Authority authority = new Authority(user, role);
        authorityDao.save(authority);
    }

    @Override
    public void save(List<AuthorityModel> authoritiesModel) {
        LOGGER.info("[AuthorityServiceImpl] save");
        authorityDao.save(AuthorityMapper
                .listAuthorityModelToListAuthorityEntity(authoritiesModel));
    }

    @Override
    public void save(AuthorityModel authorityModel) {
        authorityDao.save(AuthorityMapper.authorityModelToAuthorityEntity(authorityModel));
    }

    @Override
    public List<AuthorityModel> getAuthorities() {
        LOGGER.info("[AuthorityServiceImpl] getAuthorities");
        return AuthorityMapper
                .listAuthorityEntityToListAuthorityModel(authorityDao
                        .getAuthorities());
    }

    @Override
    public void updateAuthority(UserRoleForm userRoleForm) {
        LOGGER.debug(
                "[AuthorityServiceImpl] updateAuthority userName {}, new role {}",
                userRoleForm.getUserName(), userRoleForm.getRoleName());
        User userEntity = userDao.findOneByUserName(userRoleForm.getUserName());

        userEntity.setFirstName(userRoleForm.getFirstName());
        userEntity.setLastName(userRoleForm.getLastName());
        userEntity.setEmail(userRoleForm.getEmail());

        Role roleEntity = roleDao.findOneByName(userRoleForm.getRoleName());
        authorityDao.updateAuthority(userEntity, roleEntity);
    }

    @Override
    public void deleteAuthority(String userName) {
        LOGGER.info("[AuthorityServiceImpl] deleteAuthority userName {}", userName);
        User userEntity = userDao.findOneByUserName(userName);

        authorityDao.deleteAuthorityByUser(userEntity);
        userDao.delete(userEntity);
    }

    @Override
    public List<AuthorityModel> getAuthorityByRoleName(String roleName) {
        Role roleEntity = roleDao.findOneByName(roleName);
        return AuthorityMapper.listAuthorityEntityToListAuthorityModel(authorityDao.getAuthorityByRole(roleEntity));
    }

    @Override
    public AuthorityModel getAuthorityByUserName(String userName) {
        User userEntity = userDao.findOneByUserName(userName);
        return AuthorityMapper.authorityEntityToAuthorityModel(authorityDao.getAuthorityByUser(userEntity));
    }
}
