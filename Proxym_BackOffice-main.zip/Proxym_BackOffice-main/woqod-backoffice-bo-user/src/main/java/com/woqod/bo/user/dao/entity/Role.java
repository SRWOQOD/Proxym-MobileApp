package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = Constants.BO_ROLE)
public class Role extends Audit {

    @Id
    @Column(name = "role_name", nullable = false)
    private String roleName;

    @Column(name = "designation")
    private String designation;

    @OneToMany(mappedBy = "role", fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Authority> autorities = new ArrayList<>();

    @OneToMany(mappedBy = "role", fetch = FetchType.LAZY, orphanRemoval = true)
    private List<FeatureRole> featureRole = new ArrayList<>();

    public Role() {

    }

    public Role(String roleName, String designation) {
        this.roleName = roleName;
        this.designation = designation;

    }

    public Role(String roleName, String designation, List<Authority> autorities) {
        this.roleName = roleName;
        this.designation = designation;
        this.autorities = autorities;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public List<Authority> getAutorities() {
        return autorities;
    }

    public void setAutorities(List<Authority> autorities) {
        this.autorities = autorities;
    }


    public List<FeatureRole> getFeatureRole() {
        return featureRole;
    }

    public void setFeatureRole(List<FeatureRole> featureRole) {
        this.featureRole = featureRole;
    }
}