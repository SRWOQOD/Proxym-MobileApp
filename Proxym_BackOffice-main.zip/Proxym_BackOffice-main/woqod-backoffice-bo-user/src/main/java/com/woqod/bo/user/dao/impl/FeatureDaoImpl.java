package com.woqod.bo.user.dao.impl;


import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.exceptions.UpdatingDataException;
import com.woqod.bo.user.dao.FeatureDao;
import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.dao.repository.FeatureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class FeatureDaoImpl implements FeatureDao {

    private final FeatureRepository featureRepository;

    @Autowired
    public FeatureDaoImpl(final FeatureRepository featureRepository) {
        this.featureRepository = featureRepository;
    }

    @Override
    public void save(List<Feature> features) {
        featureRepository.saveAll(features);
    }

    @Override
    public List<Feature> saveAll(List<Feature> features) {
        return featureRepository.saveAll(features);
    }

    @Override
    public List<Feature> getFeatures() {
        return featureRepository.findAll();
    }

    @Override
    public Boolean delete(List<Feature> features) {
        try {
            featureRepository.deleteAll(features);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public List<Feature> findByParent(Feature feature) {
        return featureRepository.findByParentFeature(feature);
    }

    @Override
    public void update(List<Feature> features) {
        try {
            featureRepository.saveAll(features);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("Feature :", ex);
        }

    }

    @Override
    public Feature findOneByCode(String code) {
        Optional<Feature> featureOptional = featureRepository.findOneByCode(code);
        return featureOptional.orElseThrow(() -> new DataNotFoundException("Feature ", code, "Feature"));
    }

    @Override
    public Feature findOneByName(String name) {
        Optional<Feature> featureOptional = featureRepository.findOneByFeatureName(name);
        return featureOptional.orElseThrow(() -> new DataNotFoundException("Feature ", name, "Feature"));
    }

    @Override
    public List<Feature> findAllParent() {
        return featureRepository.findParents();
    }

    @Override
    public void save(Feature feature) {
        featureRepository.save(feature);

    }

    @Override
    public Feature saveObject(Feature feature) {
        return featureRepository.save(feature);
    }

    @Override
    public Optional<Feature> findByCode(String code) {
        return featureRepository.findOneByCode(code);
    }

}
