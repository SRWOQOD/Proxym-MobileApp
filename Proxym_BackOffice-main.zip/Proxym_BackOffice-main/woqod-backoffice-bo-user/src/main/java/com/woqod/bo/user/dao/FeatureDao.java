package com.woqod.bo.user.dao;

import com.woqod.bo.user.dao.entity.Feature;

import java.util.List;
import java.util.Optional;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:47
 */
public interface FeatureDao {
    /**
     * Used to save Feature list
     *
     * @param features
     */
    void save(List<Feature> features);

    List<Feature> saveAll(List<Feature> features);

    /**
     * Used to save one feature
     *
     * @param feature
     */
    void save(Feature feature);

    /**
     * Used to save one feature
     *
     * @param feature
     */
    Feature saveObject(Feature feature);


    /**
     * Used to retrieve Feature list
     */
    List<Feature> getFeatures();


    /**
     * Used to delete Feature list
     *
     * @param features
     */
    Boolean delete(List<Feature> features);

    /**
     * Used to Update Feature list
     *
     * @param features
     */
    void update(List<Feature> features);


    /**
     * Used to retrieve Feature list by parent
     */
    List<Feature> findByParent(Feature feature);

    /**
     * Used to retrieve Feature  by code
     */
    Feature findOneByCode(String code);

    /**
     * Used to retrieve Feature  by name
     */
    Feature findOneByName(String name);


    /**
     * Used to retrieve all feature parent
     */
    List<Feature> findAllParent();

    /**
     * Used to retrieve feature by here code
     */
    Optional<Feature> findByCode(String code);
}
