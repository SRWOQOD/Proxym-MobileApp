package com.woqod.bo.user.dao.impl;


import com.querydsl.core.types.ExpressionUtils;
import com.querydsl.core.types.Predicate;
import com.woqod.bo.user.dao.UserActionDao;
import com.woqod.bo.user.dao.entity.QUserAction;
import com.woqod.bo.user.dao.entity.UserAction;
import com.woqod.bo.user.dao.repository.UserActionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
@Slf4j
public class UserActionDaoImpl implements UserActionDao {

    private UserActionRepository userActionRepository;

    @Autowired
    public UserActionDaoImpl(UserActionRepository userActionRepository) {
        this.userActionRepository = userActionRepository;
    }

    @Override
    public Page<UserAction> getFilteredUserAction(UserAction userAction, Pageable pageable, LocalDate start, LocalDate end) {
        log.debug("[UserActionDaoImpl] getFilteredUserAction");

        QUserAction qUserAction = QUserAction.userAction;
        Predicate userActionPredicate = qUserAction.isNotNull();
        Predicate predicate = null;

        if (start != null) {
            predicate = qUserAction.actionDate.after(start.minusDays(1));
            userActionPredicate = ExpressionUtils.allOf(userActionPredicate, predicate);
        }

        if (end != null) {
            predicate = qUserAction.actionDate.before(end.plusDays(1));
            userActionPredicate = ExpressionUtils.allOf(userActionPredicate, predicate);
        }
        if (userAction.getIsSuccess() != null) { // Add predicate in is success field
            predicate = qUserAction.isSuccess.eq(userAction.getIsSuccess());
            userActionPredicate = ExpressionUtils.allOf(userActionPredicate, predicate);
        }
        if (userAction.getAction() != null && !(userAction.getAction()).isEmpty()) { // Add predicated in action
            predicate = qUserAction.action.containsIgnoreCase(userAction.getAction());
            userActionPredicate = ExpressionUtils.allOf(userActionPredicate, predicate);
        }
        if (userAction.getUsername() != null && !userAction.getUsername().isEmpty()) { // Add predicate to filter per username
            predicate = qUserAction.username.contains(userAction.getUsername());
            userActionPredicate = ExpressionUtils.allOf(userActionPredicate, predicate);
        }

        return userActionRepository.findAll(userActionPredicate, pageable);

    }

    @Override
    public void saveUserAction(UserAction userAction) {
        log.debug("[UserActionDaoImpl] getFiltredUserAction");
        userActionRepository.save(userAction);
    }

    @Override
    public List<String> findAllActions() {
        log.debug("[UserActionDaoImpl] findAllActions");
        return userActionRepository.findActionDistinct();
    }


    @Override
    public Long count() {
        return userActionRepository.count();
    }

}
