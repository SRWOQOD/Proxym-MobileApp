package com.woqod.bo.user.service;

import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.commons.model.RoleModel;
import org.primefaces.model.TreeNode;

import java.util.List;

/**
 * Created By Farouk-kraiem
 *
 * @date 10/06/2020
 * @Time 09:58
 **/
public interface ServiceRole {
    void checkAll(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR);

    void unCheckAll(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR);

    void setSelectedItem(List<FeatureRoleModel> featureRoles, TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR);

    void putFeatureInList(TreeNode[] selectedFeatures, RoleModel editRole, List<FeatureRoleModel> list);

    void drowFeatureNodeStatus(TreeNode node, String code, boolean status);

    void setSelectedItemForDisplayView(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR);

    void changeStatusByName(TreeNode node, String name, boolean status);

    void setExpandedRecursively(final TreeNode node, final boolean expanded);


    void changeNodeStatus(TreeNode node, boolean status);

    List<FeatureRoleModel> deleteDuplication(List<FeatureRoleModel> list);

    Boolean validateFields(RoleModel r, TreeNode[] selectedFeaturesR, TreeNode[] selectedFeaturesL);

    void createNodeTree(FeatureModel featureModel, TreeNode root);

}
