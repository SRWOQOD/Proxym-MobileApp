package com.woqod.bo.user.service.impl;


import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.model.ExternalUser;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.user.dao.AuthorityDao;
import com.woqod.bo.user.dao.RoleDao;
import com.woqod.bo.user.dao.UserDao;
import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.entity.User;
import com.woqod.bo.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    private final UserDao userDao;
    private final RoleDao roleDao;
    private final AuthorityDao authorityDao;

    @Autowired
    public UserServiceImpl(UserDao userDao, RoleDao roleDao, AuthorityDao authorityDao) {
        this.userDao = userDao;
        this.roleDao = roleDao;
        this.authorityDao = authorityDao;
    }

    @PostConstruct
    public void init() {
        String username = "mobileapp_ldap_test";
        User superAdminBoUser = new User(username, " ", true, true, "mobileapp_ldap_test ", "mobileapp_ldap_test ", "mobileapp_ldap_test@gmail.com","mobileapp ldap test");
        superAdminBoUser.setCreatedAt(LocalDate.now());
        superAdminBoUser.setUpdatedAt(LocalDate.now());
        Role boRole = new Role("SUPER_ADMIN", "SUPER_ADMIN ");
        boRole.setCreatedAt(LocalDate.now());
        boRole.setUpdatedAt(LocalDate.now());
        if (!userDao.checkIFExistUserByUserName(username)) {
            userDao.saveUser(superAdminBoUser);
        }

        if (!roleDao.checkExistingRoleByCode("SUPER_ADMIN")) {
            roleDao.save(boRole);
        }
        if (!authorityDao.checkAuthorityExistByUser(username)) {
            Authority authority = new Authority(superAdminBoUser, boRole);
            authority.setCreatedAt(LocalDate.now());
            authority.setUpdatedAt(LocalDate.now());
            authorityDao.save(authority);
        }
    }

    @Override
    public void save(List<UserModel> users) {
        userDao.save(UserMapper.listUserModelToListUserEntity(users));
    }

    @Override
    public void update(UserModel user) {
        userDao.update(UserMapper.userModelToUserEntity(user));
    }

    @Override
    public UserModel findOneByUserName(String userName) {
        return UserMapper.userEntityToUserModel(userDao.findOneByUserName(userName));
    }

    @Override
    public UserModel findOneUserByName(String userName) {
        return UserMapper.userEntityToUserModel(userDao.findOneUserByName(userName));
    }

    @Override
    public List<UserModel> findAll() {
        return UserMapper.listUserEntityToListUserModel(userDao.findAll());
    }

    @Override
    public List<String> findAllUserName() {
        return userDao.findAllUserName();
    }

    @Override
    public UserModel saveExternalUser(ExternalUser externalUser) {
        UserModel userModel = UserMapper.externalUserToUserModel(externalUser);
        User user = UserMapper.userModelToUserEntity(userModel);
        return UserMapper.userEntityToUserModel(userDao.saveUser(user));
    }

    @Override
    public UserModel save(UserModel userModel) {
        return UserMapper.userEntityToUserModel(userDao.saveUser(UserMapper.userModelToUserEntity(userModel)));
    }

    @Override
    public long count() {
        return userDao.count();
    }
}
