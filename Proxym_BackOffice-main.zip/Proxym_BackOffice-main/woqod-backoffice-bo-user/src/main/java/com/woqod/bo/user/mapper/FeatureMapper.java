package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.user.dao.entity.Feature;

import java.util.List;
import java.util.stream.Collectors;

public final class FeatureMapper {
    private FeatureMapper() {
        //
    }

    /**
     * map entity to model
     *
     * @param feature
     * @return
     */
    public static FeatureModel featureEntityToFeatureModel(Feature feature) {
        return new FeatureModel(feature.getCode(), feature.getBundleName(), feature.getBundleKey(), BoUtils.retreiveByBundleNameAndBundleKey(feature.getBundleName(), feature.getBundleKey()), feature.getFeatureName(), feature.getPath(), FeatureMapper.listFeatureEntityToListFeatureModel(feature.getChildrenFeatures()), feature.getIcon(), feature.getHtmlId(), feature.getOrder(), feature.isDisplayedInMenu());
    }

    /**
     * map model to entity
     *
     * @param featureModel
     * @return
     */
    public static Feature featureModelToFeatureEntity(FeatureModel featureModel) {
        Feature f = null;
        if (featureModel.getParentFeature() != null) {
            f = featureModelToFeatureEntity(featureModel.getParentFeature());
        }
        return new Feature(featureModel.getCode(), featureModel.getName(), featureModel.getBundleName(), featureModel.getBundleKey(), featureModel.getPath(), f, featureModel.getOrder(), featureModel.getIcon(), featureModel.getHtmlId(), featureModel.isDisplayedInMenu());
    }

    /**
     * map lisy of entities to model list
     *
     * @param features
     * @return
     */
    public static List<FeatureModel> listFeatureEntityToListFeatureModel(List<Feature> features) {
        return features.stream().map(FeatureMapper::featureEntityToFeatureModel).collect(Collectors.toList());
    }

    /**
     * map models to entities
     *
     * @param featureModels
     * @return
     */
    public static List<Feature> listFeatureModelToListFeatureEntity(List<FeatureModel> featureModels) {
        return featureModels.stream().map(FeatureMapper::featureModelToFeatureEntity).collect(Collectors.toList());
    }


}
