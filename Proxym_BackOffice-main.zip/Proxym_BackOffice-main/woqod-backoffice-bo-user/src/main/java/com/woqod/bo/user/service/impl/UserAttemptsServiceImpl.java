package com.woqod.bo.user.service.impl;

import com.woqod.bo.commons.interfaces.UserAttemptsService;
import com.woqod.bo.commons.model.UserAttemptsModel;
import com.woqod.bo.user.dao.UserAttemptsDao;
import com.woqod.bo.user.mapper.UserAttemptsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserAttemptsServiceImpl implements UserAttemptsService {

    private final UserAttemptsDao userAttemptsDao;

    @Autowired
    public UserAttemptsServiceImpl(UserAttemptsDao userAttemptsDao) {
        this.userAttemptsDao = userAttemptsDao;
    }

    @Override
    public void updateFailAttempts(String username) {
        userAttemptsDao.updateFailAttempts(username);
    }

    @Override
    public void resetFailAttempts(String username) {
        userAttemptsDao.resetFailAttempts(username);
    }

    @Override
    public UserAttemptsModel getUserAttempts(String username) {
        return UserAttemptsMapper.mapToModel(userAttemptsDao.getUserAttempts(username));
    }
}
