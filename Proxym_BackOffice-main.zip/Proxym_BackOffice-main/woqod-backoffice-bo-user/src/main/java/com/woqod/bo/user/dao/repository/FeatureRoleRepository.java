package com.woqod.bo.user.dao.repository;


import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.dao.entity.FeatureRole;
import com.woqod.bo.user.dao.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface FeatureRoleRepository extends JpaRepository<FeatureRole, Long> {
    /**
     * Find FeatureRole by feature
     *
     * @param feature
     * @return
     */
    Optional<List<FeatureRole>> findOneByFeature(Feature feature);

    /**
     * Find FeatureRole by role
     *
     * @param role
     * @return
     */
    Optional<List<FeatureRole>> findOneByRole(Role role);


    /**
     * used to retrive feature role by feature and role
     *
     * @param feature
     * @param role
     * @return
     */
    Optional<FeatureRole> findOneByFeatureAndRole(Feature feature, Role role);

    /**
     * used to retrieve feature role by feature name and role name
     *
     * @param feature
     * @param role
     * @return
     */
    @Query(value = "select fr from FeatureRole fr , Role r , Feature f where f.code LIKE :feature and r.roleName LIKE :role and fr.feature.code LIKE :feature and fr.role.roleName LIKE :role ")
    Optional<FeatureRole> getOneByFeatureAndRole(@Param("feature") String feature, @Param("role") String role);


    List<FeatureRole> findAllByRole_RoleNameAndFeature_DisplayedInMenu(String roleName, Boolean displayedInMenu);

}
