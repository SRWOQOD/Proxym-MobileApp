package com.woqod.bo.user.dao.repository;

import com.woqod.bo.user.dao.entity.UserAttempts;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserAttemptsRepository extends JpaRepository<UserAttempts, Long> {
    /**
     * Used to retrieve User Attempts by username
     *
     * @param username
     * @return
     */
    Optional<UserAttempts> findByUsername(String username);
}
