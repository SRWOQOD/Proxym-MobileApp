package com.woqod.bo.user.service.impl;


import com.woqod.bo.user.dao.UserDao;
import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;

@Transactional
@Service
@Slf4j
public class SSUserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {


    @Autowired
    private UserDao userDao;

    @Override
    public UserDetails loadUserByUsername(String username) {
        try {
            User user = userDao.findOneByUserName(username);
            if (user == null) {
                log.debug("user not found with the provided username");
                return null;
            }
            log.debug(" user from username {} ", user.getUserName());
            return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), user.getEnabled(), true, true, user.getAccountNonLocked(), getAuthorities(user));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UsernameNotFoundException("User not found");
        }
    }

    private Set<GrantedAuthority> getAuthorities(User user) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        for (Authority authority : user.getAutorities()) {
            GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(authority.getRole().getRoleName());
            authorities.add(grantedAuthority);
        }
        log.debug("user authorities are {}", authorities);
        return authorities;
    }
}
