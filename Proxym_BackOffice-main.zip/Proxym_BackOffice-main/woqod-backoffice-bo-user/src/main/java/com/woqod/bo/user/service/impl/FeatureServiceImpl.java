package com.woqod.bo.user.service.impl;

import com.woqod.bo.commons.interfaces.FeatureRoleService;
import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.user.dao.FeatureDao;
import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.mapper.FeatureMapper;
import org.apache.commons.lang3.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FeatureServiceImpl implements FeatureService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FeatureServiceImpl.class);
    public static final String SUPER_ADMIN = "SUPER_ADMIN";
    private final FeatureDao featureDao;
    private final FeatureRoleService featureRoleService;

    @Autowired
    public FeatureServiceImpl(FeatureDao featureDao, FeatureRoleService featureRoleService) {
        this.featureDao = featureDao;
        this.featureRoleService = featureRoleService;
    }

    @Override
    public List<FeatureModel> findAllParentByRole(String roleName) {
        LOGGER.debug("[FeatureServiceImpl] findAllParentByRole ");
        // Get all feature parent from DB
        List<FeatureModel> featureList = FeatureMapper.listFeatureEntityToListFeatureModel(featureDao.findAllParent());

        List<FeatureRoleModel> featureRoleList = featureRoleService.findAllByRoleName(roleName);
        List<FeatureModel> permettedFeature = new ArrayList<>();

        List<FeatureModel> tmpFeature;

        // get permitted feature and delete other
        for (FeatureModel featureModel : featureList) {
            tmpFeature = new ArrayList<>();
            if (BooleanUtils.isTrue(featureModel.isDisplayedInMenu()) && BooleanUtils.isTrue(isFeaturePermettedDB(featureRoleList, roleName, featureModel.getCode()))) {
                    getFeatureModel(featureModel, tmpFeature, featureRoleList, roleName);
                featureModel.setChildrenFeatures(tmpFeature);
                permettedFeature.add(featureModel);
            }
        }
        return permettedFeature;

    }

    private void getFeatureModel (FeatureModel featureModel, List<FeatureModel> tmpFeature, List<FeatureRoleModel> featureRoleList, String roleName) {
        List<FeatureModel> tmpFeatureN3;

        for (FeatureModel featureModelN2 : featureModel.getChildrenFeatures()) {
            tmpFeatureN3 = new ArrayList<>();
            if (BooleanUtils.isTrue(featureModel.isDisplayedInMenu()) && BooleanUtils.isTrue(isFeaturePermettedDB(featureRoleList, roleName, featureModelN2.getCode()))) {

                    for (FeatureModel featureModelN3 : featureModelN2.getChildrenFeatures()) {
                        if (BooleanUtils.isTrue(featureModel.isDisplayedInMenu()) && BooleanUtils.isTrue(isFeaturePermettedDB(featureRoleList, roleName, featureModelN3.getCode()))) {
                            tmpFeatureN3.add(featureModelN3);
                        }

                    }

                featureModelN2.setChildrenFeatures(tmpFeatureN3);
                tmpFeature.add(featureModelN2);
            }
        }
    }

    private static Boolean isFeaturePermettedDB(List<FeatureRoleModel> featureRoleList, String role, String feature) {
        if (!role.equals(SUPER_ADMIN)) {
            return featureRoleList.stream().anyMatch(featureRole -> featureRole.getFeature().getCode().equalsIgnoreCase(feature));
        }
        return true;
    }

    @Override
    public void save(List<FeatureModel> features) {
        LOGGER.debug("[FeatureServiceImpl] save ");
        featureDao.save(FeatureMapper.listFeatureModelToListFeatureEntity(features));
    }

    @Override
    public List<FeatureModel> saveAll(List<FeatureModel> featureModels) {
        List<Feature> featureList = featureDao.saveAll(FeatureMapper.listFeatureModelToListFeatureEntity(featureModels));
        return FeatureMapper.listFeatureEntityToListFeatureModel(featureList);
    }

    @Override
    public List<FeatureModel> getFeatures() {
        LOGGER.debug("[FeatureServiceImpl] getFeatures ");
        return FeatureMapper.listFeatureEntityToListFeatureModel(featureDao.getFeatures());
    }

    @Override
    public Boolean delete(List<FeatureModel> features) {
        LOGGER.debug("[FeatureServiceImpl] delete ");
        return featureDao.delete(FeatureMapper.listFeatureModelToListFeatureEntity(features));
    }

    @Override
    public void update(List<FeatureModel> features) {
        LOGGER.debug("[FeatureServiceImpl] update ");
        featureDao.update(FeatureMapper.listFeatureModelToListFeatureEntity(features));
    }

    @Override
    public List<FeatureModel> findByParent(FeatureModel feature) {
        LOGGER.debug("[FeatureServiceImpl] findByParent ");
        return FeatureMapper.listFeatureEntityToListFeatureModel(
                featureDao.findByParent(FeatureMapper.featureModelToFeatureEntity(feature)));
    }

    @Override
    public FeatureModel findOneByCode(String code) {
        LOGGER.debug("[FeatureServiceImpl] findOneByCode ");
        return FeatureMapper.featureEntityToFeatureModel(featureDao.findOneByCode(code));
    }

    @Override
    public FeatureModel findOneByName(String name) {
        LOGGER.debug("[FeatureServiceImpl] findOneByName ");
        return FeatureMapper.featureEntityToFeatureModel(featureDao.findOneByName(name));
    }

    @Override
    @Cacheable(cacheNames = "parents", key = "#role")
    public List<FeatureModel> findAllParent(String role) {
        LOGGER.debug("[FeatureServiceImpl] findAllParent ");
        return FeatureMapper.listFeatureEntityToListFeatureModel(featureDao.findAllParent());
    }

    @Override
    public void save(FeatureModel feature) {
        LOGGER.debug("[FeatureServiceImpl] save ");
        featureDao.save(FeatureMapper.featureModelToFeatureEntity(feature));

    }

}
