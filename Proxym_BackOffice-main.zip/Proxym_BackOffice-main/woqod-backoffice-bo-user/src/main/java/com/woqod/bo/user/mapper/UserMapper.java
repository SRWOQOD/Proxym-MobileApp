package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.ExternalUser;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.user.dao.entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:33
 */
public final class UserMapper {

    private UserMapper() {
    }

    /**
     * map entity to model
     *
     * @param user
     * @return
     */
    public static UserModel userEntityToUserModel(User user) {
        return new UserModel(user.getUserName(), user.getPassword(), user.getEnabled(), user.getAccountNonLocked(), user.getFirstName(), user.getLastName(), user.getEmail(),user.getFullName());
    }

    /**
     * map model to entity
     *
     * @param userModel
     * @return
     */
    public static User userModelToUserEntity(UserModel userModel) {
        return new User(userModel.getUserName(), userModel.getPassword(), userModel.getAccountNonLocked(), userModel.getEnabled(), userModel.getFirstName(), userModel.getLastName(), userModel.getEmail(),userModel.getFullName());
    }


    /**
     * map entities to models
     *
     * @param users
     * @return
     */
    public static List<UserModel> listUserEntityToListUserModel(List<User> users) {
        return users.stream().map(UserMapper::userEntityToUserModel).collect(Collectors.toList());
    }

    /**
     * map models to entities
     *
     * @param userModels
     * @return
     */
    public static List<User> listUserModelToListUserEntity(List<UserModel> userModels) {
        return userModels.stream().map(UserMapper::userModelToUserEntity).collect(Collectors.toList());
    }

    /**
     * map list of external user to  list of user model
     *
     * @param externalUsers
     * @return
     */
    public static List<UserModel> listExternalUserToListUserEntity(List<ExternalUser> externalUsers) {
        List<UserModel> users = new ArrayList<>();
        for (ExternalUser externalUser : externalUsers) {
            users.add(externalUserToUserModel(externalUser));
        }
        return users;
    }

    public static List<ExternalUser> listUserModelListToListExternalUser(List<UserModel> userModelList) {
        List<ExternalUser> users = new ArrayList<>();
        for (UserModel userModel : userModelList) {
            users.add(userEntityToExternalUser(userModel));
        }
        return users;
    }


    /**
     * map external user to user model
     *
     * @param externalUser
     * @return
     */
    public static UserModel externalUserToUserModel(ExternalUser externalUser) {
        return new UserModel(externalUser.getUserName(), externalUser.getPassword(), true, true, externalUser.getFirstName(), externalUser.getLastName(), externalUser.getEmail(),externalUser.getFullName());
    }

    public static ExternalUser userEntityToExternalUser(UserModel userModel) {
        ExternalUser externalUser = new ExternalUser();
        externalUser.setUserName(userModel.getUserName());
        return externalUser;
    }
}
