package com.woqod.bo.user.dao;

import com.woqod.bo.user.dao.entity.UserAction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

public interface UserActionDao {

    /**
     * Used to retieve all user action filtred and paginated
     */
    Page<UserAction> getFilteredUserAction(UserAction userAction, Pageable pageable, LocalDate start, LocalDate end);

    /**
     * used to save user action
     */
    void saveUserAction(UserAction userAction);

    /**
     * get all action names
     */
    List<String> findAllActions();

    Long count();
}
