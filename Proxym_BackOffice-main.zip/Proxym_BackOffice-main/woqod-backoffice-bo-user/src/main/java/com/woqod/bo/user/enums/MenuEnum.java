package com.woqod.bo.user.enums;

import com.woqod.bo.commons.enums.Bundle;
import com.woqod.bo.commons.enums.Menu;
import com.woqod.bo.commons.enums.MenuPosition;
import com.woqod.bo.commons.enums.ModuleLevel;
import com.woqod.bo.user.constant.UserConstant;

import java.util.Arrays;
import java.util.Optional;

public enum MenuEnum implements Menu {


    DISPLAY_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "displayBoUser"), "/bousermanagement", "", "", true, "USER_MANAGEMENT", new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    ADD_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "addBoUser"), "/bousermanagement/add", "", "", true, UserConstant.DISPLAY_BO_USER, new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    EDIT_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "editBoUser"), "/bousermanagement/edit", "", "", true, UserConstant.DISPLAY_BO_USER, new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    DELETE_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "deleteBoUser"), "", "", "", true, UserConstant.DISPLAY_BO_USER, new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    EXPORT_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "exportBoUser"), "", "", "", true, UserConstant.DISPLAY_BO_USER, new MenuPosition(ModuleLevel.SECOND.name(), 5L)),
    STATUS_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "statusBoUser"), "", "", "", true, UserConstant.DISPLAY_BO_USER, new MenuPosition(ModuleLevel.SECOND.name(), 6L)),

    DISPLAY_BO_ROLE_MANAGEMENT(new Bundle(UserConstant.BUNDLE_NAME, "displayBoRole"), UserConstant.PATH, "", "", true, "ROLE_MANAGEMENT", new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    ADD_ROLE_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "addBoRole"), UserConstant.PATH, "", "", true, UserConstant.DISPLAY_BO_ROLE_MANAGEMENT, new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    EDIT_ROLE_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "editBoRole"), UserConstant.PATH, "", "", true, UserConstant.DISPLAY_BO_ROLE_MANAGEMENT, new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    DELETE_ROLE_BO_USER(new Bundle(UserConstant.BUNDLE_NAME, "deleteBoRole"), "", "", "", true, UserConstant.DISPLAY_BO_ROLE_MANAGEMENT, new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    ;


    MenuEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }

}
