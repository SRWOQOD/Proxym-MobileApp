package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = Constants.BO_USER_ACTION)
public class UserAction extends Audit {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String username;

    private Boolean isSuccess;

    private LocalDate actionDate;

    private String firstName;

    private String ipAddress;
    private String role;

    private String action;
    @Lob
    private String oldData;
    @Lob
    private String actionData;
    @Lob
    private String exceptionData;


    public long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public Boolean getIsSuccess() {
        return isSuccess;
    }

    public LocalDate getActionDate() {
        return actionDate != null ? actionDate : LocalDate.now();
    }

    public String getAction() {
        return action;
    }

    public String getActionData() {
        return actionData;
    }


    public String getFirstName() {
        return firstName;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public String getOldData() {
        return oldData;
    }

    public String getExceptionData() {
        return exceptionData;
    }

    public String getRole() {
        return role;
    }

    public UserAction() {
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public UserAction(Builder builder) {
        this.id = builder.id;
        this.username = builder.username;
        this.action = builder.action;
        this.isSuccess = builder.isSuccess;
        this.actionDate = builder.actionDate;
        this.ipAddress = builder.ipAddress;
        this.actionData = builder.actionData;
        this.oldData = builder.oldData;
        this.role = builder.role;
        this.firstName = builder.firstName;
        this.exceptionData = builder.exceptionData;
    }

    public static class Builder {
        private Long id;
        private String username;
        private Boolean isSuccess;
        private String action;
        private String actionData;
        private LocalDate actionDate;
        private String exceptionData;
        private String firstName;
        private String ipAddress;
        private String oldData;
        private String role;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder id(long id) {
            this.id = id;
            return this;
        }

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder actionData(String actionData) {
            this.actionData = actionData;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Builder exceptionData(String exceptionData) {
            this.exceptionData = exceptionData;
            return this;
        }

        public Builder isSuccess(Boolean isSuccess) {
            this.isSuccess = isSuccess;
            return this;
        }

        public Builder action(String action) {
            this.action = action;
            return this;
        }

        public Builder actionDate(LocalDate actionDate) {
            this.actionDate = actionDate != null ? LocalDate.now() : null;
            return this;
        }

        public Builder oldData(String oldData) {
            this.oldData = oldData;
            return this;
        }

        public Builder ipAddress(String ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }

        public Builder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public UserAction build() {
            return new UserAction(this);
        }

    }
}
