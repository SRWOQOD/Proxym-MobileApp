package com.woqod.bo.user.service.impl;

import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.user.dao.UserActionDao;
import com.woqod.bo.user.mapper.UserActionMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class UserActionServiceImpl implements UserActionService {

    @Autowired
    private UserActionDao userActionDao;

    private final ModelMapper mapper = new ModelMapper();

    @Override
    public Page<UserActionModel> getFilteredUserAction(UserActionModel userAction, Pageable pageable, LocalDate start,
                                                                               LocalDate end) {


        return userActionDao.getFilteredUserAction(UserActionMapper.mapToUserAction(userAction), pageable, start, end)
                .map(userActionTmp -> mapper.map(userActionTmp, UserActionModel.class));
    }

    @Override
    @Async
    public void saveUserAction(UserActionModel userAction) {
        userActionDao.saveUserAction(UserActionMapper.mapToUserAction(userAction));
    }

    @Override
    public List<String> findAllActions() {
        return userActionDao.findAllActions();
    }

    @Override
    public Long count() {
        return userActionDao.count();
    }
}
