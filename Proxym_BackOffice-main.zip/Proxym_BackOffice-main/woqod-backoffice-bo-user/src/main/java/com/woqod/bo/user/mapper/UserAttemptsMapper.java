package com.woqod.bo.user.mapper;

import com.woqod.bo.commons.model.UserAttemptsModel;
import com.woqod.bo.user.dao.entity.UserAttempts;

import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * User: Nasreddine.Jrebi
 * Date: 23/11/2018 11:29
 */
public final class UserAttemptsMapper {
    private UserAttemptsMapper() {
    }

    /**
     * used to map entity to model
     *
     * @param userAttempts
     * @return
     */
    public static UserAttemptsModel mapToModel(UserAttempts userAttempts) {

        return new UserAttemptsModel(userAttempts.getId(), userAttempts.getUsername(), userAttempts.getAttempts(), userAttempts.getLastModified());
    }

    /**
     * used to map list of entities to models
     *
     * @param userAttempts
     * @return
     */
    public static List<UserAttemptsModel> mapToModels(List<UserAttempts> userAttempts) {
        List<UserAttemptsModel> list = new ArrayList<>();
        if (userAttempts != null && !userAttempts.isEmpty()) {
            list.addAll(userAttempts.stream().map(action -> mapToModel(action)).collect(toList()));
        }
        return list;
    }


    /**
     * used to map model to entity
     *
     * @param userAttempts
     * @return
     */
    public static UserAttempts mapToEntity(UserAttemptsModel userAttempts) {

        return new UserAttempts(userAttempts.getId(), userAttempts.getUsername(), userAttempts.getAttempts(), userAttempts.getLastModified());
    }

    /**
     * used to map list of models to entities
     *
     * @param userAttempts
     * @return
     */
    public static List<UserAttempts> maptoEntities(List<UserAttemptsModel> userAttempts) {
        List<UserAttempts> list = new ArrayList<>();
        if (userAttempts != null && !userAttempts.isEmpty()) {
            list.addAll(userAttempts.stream().map(UserAttemptsMapper::mapToEntity).collect(toList()));
        }
        return list;
    }
}
