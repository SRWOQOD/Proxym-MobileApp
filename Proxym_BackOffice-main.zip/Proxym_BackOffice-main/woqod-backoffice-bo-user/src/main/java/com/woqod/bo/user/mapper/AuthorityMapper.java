package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.AuthorityModel;
import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.commons.model.UserModel;
import com.woqod.bo.user.dao.entity.Authority;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public final class AuthorityMapper {

    private AuthorityMapper() {
    }

    /**
     * map entity to model
     *
     * @param authority
     * @return
     */
    public static AuthorityModel authorityEntityToAuthorityModel(Authority authority) {
        AuthorityModel autho = new AuthorityModel();
        UserModel user = UserMapper.userEntityToUserModel(authority.getUser());
        RoleModel role = RoleMapper.roleEntityToRoleModel(authority.getRole());
        autho.setRole(role);
        autho.setUser(user);
        autho.setCreatedAt(authority.getCreatedAt());
        return autho;
    }

    /**
     * map model to entity
     *
     * @param authorityModel
     * @return
     */
    public static Authority authorityModelToAuthorityEntity(AuthorityModel authorityModel) {
        return new Authority(UserMapper.userModelToUserEntity(authorityModel.getUser()), RoleMapper.roleModelToRoleEntity(authorityModel.getRole()));
    }


    /**
     * map list of entities to model list
     *
     * @param authorities
     * @return
     */
    public static List<AuthorityModel> listAuthorityEntityToListAuthorityModel(List<Authority> authorities) {
        List<AuthorityModel> models = new ArrayList<>();
        for (Authority entity : authorities) {
            models.add(authorityEntityToAuthorityModel(entity));
        }
        return models;
    }


    /**
     * map list of model to entity list
     *
     * @param authorityModels
     * @return
     */
    public static List<Authority> listAuthorityModelToListAuthorityEntity(List<AuthorityModel> authorityModels) {
        return authorityModels.stream().map(AuthorityMapper::authorityModelToAuthorityEntity).collect(Collectors.toList());
    }
}