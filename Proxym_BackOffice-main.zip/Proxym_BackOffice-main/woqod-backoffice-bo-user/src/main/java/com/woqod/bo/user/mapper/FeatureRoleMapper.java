package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.dao.entity.FeatureRole;
import com.woqod.bo.user.dao.entity.Role;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public final class FeatureRoleMapper {
    private FeatureRoleMapper() {
    }

    /**
     * map entity to model
     *
     * @param featureRole
     * @return
     */
    public static FeatureRoleModel featureRoleEntityToFeatureRoleModel(FeatureRole featureRole) {
        FeatureRoleModel fr = new FeatureRoleModel();
        FeatureModel feature = FeatureMapper.featureEntityToFeatureModel(featureRole.getFeature());
        RoleModel role = RoleMapper.roleEntityToRoleModel(featureRole.getRole());
        fr.setRole(role);
        fr.setFeature(feature);
        fr.setId(featureRole.getId());
        return fr;
    }

    /**
     * map model to entity
     *
     * @param featureRoleModel
     * @return
     */
    public static FeatureRole featureRoleModelToFeatureRoleEntity(FeatureRoleModel featureRoleModel) {
        FeatureRole fr = new FeatureRole();
        Feature feature = FeatureMapper.featureModelToFeatureEntity(featureRoleModel.getFeature());
        Role role = RoleMapper.roleModelToRoleEntity(featureRoleModel.getRole());
        fr.setFeature(feature);
        fr.setRole(role);
        fr.setId(featureRoleModel.getId());
        return fr;
    }

    /**
     * map entities to models
     *
     * @param featureRoles
     * @return
     */
    public static List<FeatureRoleModel> listFeatureRoleEntityToListFeatureRoleModel(List<FeatureRole> featureRoles) {
        List<FeatureRoleModel> models = new ArrayList<>();
        for (FeatureRole entity : featureRoles) {
            models.add(featureRoleEntityToFeatureRoleModel(entity));
        }
        return models;
    }

    /**
     * map models to entities
     *
     * @param featureRoleModels
     * @return
     */
    public static List<FeatureRole> listFeatureRoleModelToListFeatureRoleEntity(List<FeatureRoleModel> featureRoleModels) {
        return featureRoleModels.stream().map(FeatureRoleMapper::featureRoleModelToFeatureRoleEntity).collect(Collectors.toList());
    }

}
