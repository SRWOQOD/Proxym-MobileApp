package com.woqod.bo.user;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

@Configuration
@ComponentScan(basePackages = {"com.woqod.bo.user"})
@EnableJpaRepositories(basePackages = {"com.woqod.bo.user.dao.repository"})
@EntityScan(basePackages = {"com.woqod.bo.user.dao.entity"})
@EnableSpringDataWebSupport
public class BoUserConfig {
}
