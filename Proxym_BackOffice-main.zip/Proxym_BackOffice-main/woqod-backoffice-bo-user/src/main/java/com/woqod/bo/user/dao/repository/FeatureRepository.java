package com.woqod.bo.user.dao.repository;

import com.woqod.bo.user.dao.entity.Feature;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface FeatureRepository extends JpaRepository<Feature, Long> {

    /**
     * retrive list of feature by parent
     *
     * @param feature
     * @return
     */
    List<Feature> findByParentFeature(Feature feature);


    /**
     * retrive feature by code
     *
     * @param code
     * @return
     */
    Optional<Feature> findOneByCode(String code);

    /**
     * retrive feature by name
     *
     * @param name
     * @return
     */
    Optional<Feature> findOneByFeatureName(String name);

    /**
     * retrive list of parent feature
     *
     * @return
     */
    @Query("select f from Feature f left join f.parentFeature f1 where f1.code is null order by f.order ASC")
    List<Feature> findParents();
}
