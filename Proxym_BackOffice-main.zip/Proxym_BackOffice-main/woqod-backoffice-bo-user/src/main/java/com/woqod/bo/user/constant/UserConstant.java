package com.woqod.bo.user.constant;

public final class UserConstant {
    public static final String BUNDLE_NAME = "bo_user_messages";
    public static final String DISPLAY_BO_USER = "DISPLAY_BO_USER";
    public static final String PATH = "/borolemanagement";
    public static final String DISPLAY_BO_ROLE_MANAGEMENT = "DISPLAY_BO_ROLE_MANAGEMENT";

    private UserConstant() {
    }
}