package com.woqod.bo.user.service.impl;


import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.user.dao.RoleDao;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.mapper.RoleMapper;
import com.woqod.bo.user.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    private final RoleDao roleDao;

    @Autowired
    public RoleServiceImpl(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    public List<RoleModel> getAllRoles() {
        return RoleMapper.listRoleEntityToListRoleModel(roleDao.findAll());
    }

    @Override
    public RoleModel findOneByName(String name) {
        Role role = roleDao.findOneByName(name);
        if (role == null) {
            return null;
        } else {
            return RoleMapper.roleEntityToRoleModel(role);
        }
    }

    @Override
    public RoleModel findOneRoleByName(String name) {
        Role role = roleDao.findOneRoleByName(name);
        if (role == null) {
            return null;
        } else {
            return RoleMapper.roleEntityToRoleModel(role);
        }
    }

    @Override
    public RoleModel save(RoleModel role) {
        Role r = roleDao.save(RoleMapper.roleModelToRoleEntity(role));
        if (r == null) {
            return null;
        } else {
            return RoleMapper.roleEntityToRoleModel(r);
        }
    }

    @Override
    public Boolean delete(RoleModel role) {

        return roleDao.delete(RoleMapper.roleModelToRoleEntity(role));
    }

    @Override
    public List<RoleModel> search(String name) {
        List<Role> roles = roleDao.search(name);
        if (roles == null) {
            return new ArrayList<>();
        } else {
            return RoleMapper.listRoleEntityToListRoleModel(roles);
        }
    }

    @Override
    public long count() {
        return roleDao.count();
    }
}
