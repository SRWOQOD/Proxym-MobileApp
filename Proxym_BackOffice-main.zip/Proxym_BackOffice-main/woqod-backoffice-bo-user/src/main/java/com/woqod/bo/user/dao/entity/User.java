package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = Constants.BO_USER)
public class User extends Audit {

    @Id
    @Column(name = "username", unique = true, nullable = false)
    private String userName;

    private String firstName;
    private String lastName;
    private String fullName;
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "account_non_locked", nullable = false)
    private Boolean accountNonLocked;

    @Column(name = "enabled", nullable = false)
    private Boolean enabled;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Authority> autorities = new ArrayList<>();

    public User() {

    }

    public User(String userName, String password, Boolean accountNonLocked, Boolean enabled, String firstName, String lastName, String email, String fullName) {
        this.userName = userName;
        this.password = password;
        this.accountNonLocked = accountNonLocked;
        this.fullName = fullName;
        this.enabled = enabled;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public User(String userName, String password, Boolean enabled, List<Authority> autorities, String firstName, String lastName, String email, String fullName) {
        this.userName = userName;
        this.password = password;
        this.enabled = enabled;
        this.fullName = fullName;
        this.autorities = autorities;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Authority> getAutorities() {
        return autorities;
    }

    public void setAutorities(List<Authority> autorities) {
        this.autorities = autorities;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean getAccountNonLocked() {
        return accountNonLocked;
    }

    public void setAccountNonLocked(Boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}