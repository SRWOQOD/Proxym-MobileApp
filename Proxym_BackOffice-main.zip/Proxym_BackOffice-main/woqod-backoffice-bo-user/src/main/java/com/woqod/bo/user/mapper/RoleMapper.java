package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.user.dao.entity.Role;

import java.util.List;
import java.util.stream.Collectors;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:33
 */
public final class RoleMapper {
    private RoleMapper() {
    }

    /**
     * map entity to model
     *
     * @param role
     * @return
     */
    public static RoleModel roleEntityToRoleModel(Role role) {
        return new RoleModel(role.getRoleName(), role.getDesignation());
    }

    /**
     * map model to entity
     *
     * @param roleModel
     * @return
     */
    public static Role roleModelToRoleEntity(RoleModel roleModel) {
        return new Role(roleModel.getName(), roleModel.getDesignation());
    }

    /**
     * map entities to models
     *
     * @param roles
     * @return
     */
    public static List<RoleModel> listRoleEntityToListRoleModel(List<Role> roles) {
        return roles.stream().map(RoleMapper::roleEntityToRoleModel).collect(Collectors.toList());
    }

    /**
     * map models to entities
     *
     * @param roleModels
     * @return
     */
    public static List<Role> listRoleModelToListRoleEntity(List<RoleModel> roleModels) {
        return roleModels.stream().map(RoleMapper::roleModelToRoleEntity).collect(Collectors.toList());
    }
}
