package com.woqod.bo.user.dao.repository;

import com.woqod.bo.user.dao.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {
    /**
     * used to retrieve all roles
     *
     * @return
     */
    List<Role> findAll();

    /**
     * used to retrieve one role by name
     *
     * @param name
     * @return
     */
    Optional<Role> findOneByRoleName(String name);

    Optional<List<Role>> findByRoleNameContainingIgnoreCase(String name);
}
