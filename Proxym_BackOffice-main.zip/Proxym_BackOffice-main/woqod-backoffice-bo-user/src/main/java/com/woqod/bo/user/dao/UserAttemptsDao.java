package com.woqod.bo.user.dao;


import com.woqod.bo.user.dao.entity.UserAttempts;

public interface UserAttemptsDao {

    /**
     * used to increment by 1 user attemts
     *
     * @param username
     */
    void updateFailAttempts(String username);

    /**
     * used to reset user attempts
     */
    void resetFailAttempts(String username);

    /**
     * used to retrieve user attempts by username
     */
    UserAttempts getUserAttempts(String username);
}
