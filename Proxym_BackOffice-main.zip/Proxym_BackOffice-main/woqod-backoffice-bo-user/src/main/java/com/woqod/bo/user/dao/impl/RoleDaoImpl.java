package com.woqod.bo.user.dao.impl;

import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.user.dao.RoleDao;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class RoleDaoImpl implements RoleDao {

    private final RoleRepository roleRepository;

    @Autowired
    public RoleDaoImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public List<Role> findAll() {
        return roleRepository.findAll();
    }

    @Override
    public Role findOneByName(String name) {
        Optional<Role> roleOptional = roleRepository.findOneByRoleName(name);
        return roleOptional.orElseThrow(() -> new DataNotFoundException("role", name, "Role"));
    }

    @Override
    public Boolean checkExistingRoleByCode(String code) {
        Optional<Role> roleOptional = roleRepository.findOneByRoleName(code);
        return roleOptional.isPresent();
    }

    @Override
    public Role save(Role role) {
        return roleRepository.save(role);
    }

    @Override
    public Boolean delete(Role role) {
        try {
            roleRepository.delete(role);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public Role findOneRoleByName(String name) {
        Optional<Role> roleOptional = roleRepository.findOneByRoleName(name);
        return roleOptional.orElse(null);
    }

    @Override
    public List<Role> search(String name) {
        Optional<List<Role>> roleOptional = roleRepository.findByRoleNameContainingIgnoreCase(name);
        return roleOptional.orElseGet(ArrayList::new);
    }

    @Override
    public long count() {
        return roleRepository.count();
    }

}
