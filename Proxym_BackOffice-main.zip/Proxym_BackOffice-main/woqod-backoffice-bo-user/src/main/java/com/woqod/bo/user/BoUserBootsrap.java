package com.woqod.bo.user;


import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.bo.user.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Component
public class BoUserBootsrap {
    private static final String BO_USER_MODULE = "bo_user";

    /**
     * used to save menu features and action in menu loader in order to save them in db
     */
    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap()
                .put(BO_USER_MODULE,
                        ListMenu.builder()
                                .menus(Arrays.asList(MenuEnum.values()))
                                .build());
    }
}
