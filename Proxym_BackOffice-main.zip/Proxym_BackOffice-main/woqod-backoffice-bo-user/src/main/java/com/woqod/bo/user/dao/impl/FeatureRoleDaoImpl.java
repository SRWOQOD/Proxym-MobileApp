package com.woqod.bo.user.dao.impl;


import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.exceptions.PersistingDataException;
import com.woqod.bo.commons.exceptions.UpdatingDataException;
import com.woqod.bo.user.dao.FeatureRoleDao;
import com.woqod.bo.user.dao.entity.Feature;
import com.woqod.bo.user.dao.entity.FeatureRole;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.repository.FeatureRoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class FeatureRoleDaoImpl implements FeatureRoleDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeatureRoleDaoImpl.class);
    private final FeatureRoleRepository featureRoleRepository;

    @Autowired
    public FeatureRoleDaoImpl(final FeatureRoleRepository featureRoleRepository) {
        this.featureRoleRepository = featureRoleRepository;
    }

    @Override
    public void save(List<FeatureRole> featureRole) {
        LOGGER.info("[FeatureRoleDaoImpl] save ");
        for (FeatureRole f : featureRole) {
            try {
                featureRoleRepository.save(f);
            } catch (DataIntegrityViolationException ex) {
                throw new PersistingDataException("Feature ::", ex);
            }
        }

    }

    @Override
    public void update(List<FeatureRole> featureRole) {
        LOGGER.info("[FeatureRoleDaoImpl] update ");
        featureRoleRepository.saveAll(featureRole);
        try {
            LOGGER.info("[FeatureRoleDaoImpl] update ");
            featureRoleRepository.saveAll(featureRole);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("FeatureRole :", ex);
        }
    }

    @Override
    public List<FeatureRole> getFeatureRoles() {
        LOGGER.info("[FeatureRoleDaoImpl] getFeatureRoles ");
        return featureRoleRepository.findAll();
    }

    @Override
    public List<FeatureRole> getFeatureRoleByRole(Role role) {
        LOGGER.info("[FeatureRoleDaoImpl] getFeatureRoleByRole ");
        Optional<List<FeatureRole>> featureRoles = featureRoleRepository.findOneByRole(role);
        if (!featureRoles.isPresent()) {
            throw new DataNotFoundException("Authority", null, "Authority");
        }
        return featureRoles.get();
    }

    @Override
    public void deleteFeatureRoleByRole(Role role) {
        LOGGER.info("[FeatureRoleDaoImpl] deleteFeatureRoleByRole ");
        Optional<List<FeatureRole>> featureRole = featureRoleRepository.findOneByRole(role);
        if (!featureRole.isPresent()) {
            throw new DataNotFoundException("FeatureRole :", null, "FeatureRole ");
        }
        List<FeatureRole> featureRoles = featureRole.get();
        featureRoleRepository.deleteAll(featureRoles);
    }

    @Override
    public List<FeatureRole> getFeatureRoleByFeature(Feature feature) {
        LOGGER.info("[FeatureRoleDaoImpl] getFeatureRoleByFeature ");
        Optional<List<FeatureRole>> featureRoles = featureRoleRepository.findOneByFeature(feature);
        if (!featureRoles.isPresent()) {
            throw new DataNotFoundException("FeatureRole ::", null, "FeatureRole  ");
        }
        return featureRoles.get();
    }

    @Override
    public FeatureRole findOneByFeatureAndRole(Feature feature, Role role) {
        LOGGER.info("[FeatureRoleDaoImpl] findOneByFeatureAndRole ");
        Optional<FeatureRole> featureRoleOptional = featureRoleRepository.findOneByFeatureAndRole(feature, role);
        return featureRoleOptional.orElseThrow(() -> new DataNotFoundException("FeatureRole",
                feature.getCode() + "   " + role.getRoleName(), "FeatureRole  "));
    }

    @Override
    public FeatureRole getByFeatureNameAndRoleName(String feature, String role) {
        LOGGER.info("[FeatureRoleDaoImpl] getByFeatureNameAndRoleName ");
        Optional<FeatureRole> featureRoleOptional = featureRoleRepository.getOneByFeatureAndRole(feature, role);
        return featureRoleOptional.orElseThrow(() -> new DataNotFoundException("FeatureRole ",
                feature + "   " + role, "FeatureRole"));
    }

    @Override
    public void deleteFeatureRoles(List<FeatureRole> frs) {
        LOGGER.info("[FeatureRoleDaoImpl] deleteFeatureRoles ");
        featureRoleRepository.deleteAll(frs);
    }

    @Override
    public List<FeatureRole> findAllByRoleName(String code) {
        LOGGER.info("[FeatureRoleDaoImpl] findAllByRoleCode ");
        return featureRoleRepository.findAllByRole_RoleNameAndFeature_DisplayedInMenu(code, Boolean.TRUE);
    }

}
