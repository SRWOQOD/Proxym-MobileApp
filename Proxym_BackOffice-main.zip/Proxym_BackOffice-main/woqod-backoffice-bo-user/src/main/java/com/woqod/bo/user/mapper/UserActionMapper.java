package com.woqod.bo.user.mapper;


import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.user.dao.entity.UserAction;

import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2019 16:33
 */
public final class UserActionMapper {
    private UserActionMapper() {
    }

    /**
     * Map UserAction to UserActionModel
     *
     * @param userAction
     * @return
     */
    public static UserActionModel mapToUserActionModel(UserAction userAction) {

        return UserActionModel.newBuilder()
                .id(userAction.getId())
                .action(userAction.getAction())
                .actionData(userAction.getActionData())
                .oldData(userAction.getOldData())
                .role(userAction.getRole())
                .ipAddress(userAction.getIpAddress())
                .firstName(userAction.getFirstName())
                .exceptionData(userAction.getExceptionData())
                .actionDate(userAction.getActionDate())
                .username(userAction.getUsername())
                .isSuccess(userAction.getIsSuccess())
                .build();

    }

    /**
     * Map list of UserAction to UserActionModel list
     *
     * @param userActions
     * @return
     */
    public static List<UserActionModel> mapToUserActionModels(List<UserAction> userActions) {
        List<UserActionModel> list = new ArrayList<>();
        if (userActions != null && !userActions.isEmpty()) {
            list.addAll(userActions.stream().map(action -> mapToUserActionModel(action)).collect(toList()));
        }
        return list;
    }


    /**
     * Map UserActionModel to UserAction
     *
     * @param userActionModel
     * @return
     */
    public static UserAction mapToUserAction(UserActionModel userActionModel) {

        return (userActionModel == null ? null : UserAction.newBuilder()
                .id(userActionModel.getId())
                .action(userActionModel.getAction())
                .ipAddress(userActionModel.getIpAddress())
                .oldData(userActionModel.getOldData())
                .firstName(userActionModel.getFirstName())
                .role(userActionModel.getRole())
                .actionData(userActionModel.getActionData())
                .exceptionData(userActionModel.getExceptionData())
                .actionDate(userActionModel.getActionDate())
                .username(userActionModel.getUsername())
                .isSuccess(userActionModel.getIsSuccess())
                .build());

    }

    /**
     * Map list of UserAction to UserActionModel list
     *
     * @param userActions
     * @return
     */
    public static List<UserAction> mapToUserActionEntities(List<UserActionModel> userActions) {
        List<UserAction> list = new ArrayList<>();
        if (userActions != null && !userActions.isEmpty()) {
            list.addAll(userActions.stream().map(UserActionMapper::mapToUserAction).collect(toList()));
        }
        return list;
    }
}
