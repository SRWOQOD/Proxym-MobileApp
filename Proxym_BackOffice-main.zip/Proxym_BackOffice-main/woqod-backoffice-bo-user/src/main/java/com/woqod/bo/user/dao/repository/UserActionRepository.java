package com.woqod.bo.user.dao.repository;


import com.querydsl.core.types.dsl.StringPath;
import com.woqod.bo.user.dao.entity.QUserAction;
import com.woqod.bo.user.dao.entity.UserAction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.List;

public interface UserActionRepository extends JpaRepository<UserAction, Long>, QueryByExampleExecutor<UserAction>, QuerydslPredicateExecutor<UserAction>, QuerydslBinderCustomizer<QUserAction> {
    @Override
    default void customize(QuerydslBindings bindings, QUserAction userAction) {
        bindings.bind(String.class).first((StringPath path, String value) -> path.containsIgnoreCase(value));
    }

    @Query("SELECT DISTINCT action from UserAction")
    List<String> findActionDistinct();

}
