package com.woqod.bo.user.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import java.time.LocalDate;

@NoArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(
        value = {"createdAt", "updatedAt"},
        allowGetters = true
)
public abstract class Audit {
    @Column(name = "created_at", nullable = true, updatable = false)
    @CreatedDate
    private LocalDate createdAt;

    @Column(name = "updated_at", nullable = true)
    @LastModifiedDate
    private LocalDate updatedAt;

    public LocalDate getCreatedAt() {
        return createdAt != null ? LocalDate.now() : null;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt != null ? LocalDate.now() : null;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt != null ? LocalDate.now() : null;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt != null ? LocalDate.now() : null;
    }
}