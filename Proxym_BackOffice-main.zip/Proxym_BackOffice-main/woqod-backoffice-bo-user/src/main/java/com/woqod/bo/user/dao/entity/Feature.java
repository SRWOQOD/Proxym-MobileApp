package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = Constants.BO_FEATURE)
public class Feature extends Audit {
    @Id
    @Column(name = "code", unique = true, nullable = false)
    private String code;

    @Column(name = "feature_name", nullable = false)
    private String featureName;

    private String bundleName;

    private String bundleKey;

    @Column(name = "path", nullable = true)
    private String path;

    @Column(name = "icon", nullable = true)
    private String icon;

    @Column(name = "html_id", nullable = true)
    private String htmlId;

    @ManyToOne
    @JoinColumn(name = "parent_code")
    private Feature parentFeature;

    @OneToMany(mappedBy = "parentFeature", fetch = FetchType.LAZY)
    @OrderBy("order")
    private List<Feature> childrenFeatures = new ArrayList<>();

    @OneToMany(mappedBy = "feature", fetch = FetchType.LAZY)
    private List<FeatureRole> featureRole = new ArrayList<>();

    @Column(name = "feature_order")
    private Long order;
    @Column(nullable = true)
    private boolean displayedInMenu;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Feature getParentFeature() {
        return parentFeature;
    }

    public void setParentFeature(Feature parentFeature) {
        this.parentFeature = parentFeature;
    }

    public List<Feature> getChildrenFeatures() {
        return childrenFeatures != null ? childrenFeatures : new ArrayList<>();
    }


    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }

    public List<FeatureRole> getFeatureRole() {
        return featureRole;
    }

    public void setFeatureRole(List<FeatureRole> featureRole) {
        this.featureRole = featureRole;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getHtmlId() {
        return htmlId;
    }

    public void setHtmlId(String htmlId) {
        this.htmlId = htmlId;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public String getBundleKey() {
        return bundleKey;
    }

    public void setBundleKey(String bundleKey) {
        this.bundleKey = bundleKey;
    }

    public boolean isDisplayedInMenu() {
        return displayedInMenu;
    }

    public void setDisplayedInMenu(boolean displayedInMenu) {
        this.displayedInMenu = displayedInMenu;
    }

    public Feature(String code, String featureName) {
        super();
        this.code = code;
        this.featureName = featureName;
    }

    public Feature() {
        super();
    }

    public Feature(String code, String featureName, String bundleName, String bundleKey, String path, Feature parentFeature, Long order, String icon, String htmlId, boolean displayedInMenu) {
        super();
        this.code = code;
        this.featureName = featureName;
        this.parentFeature = parentFeature;
        this.path = path;
        this.order = order;
        this.icon = icon;
        this.htmlId = htmlId;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.displayedInMenu = displayedInMenu;
    }

    public Feature(String code, String featureName, String bundleName, String bundleKey, String path, Feature parentFeature, List<FeatureRole> featureRole) {
        super();
        this.code = code;
        this.featureName = featureName;
        this.bundleName = bundleName;
        this.bundleKey = bundleKey;
        this.parentFeature = parentFeature;
        this.featureRole = featureRole;
        this.path = path;
    }

}
