package com.woqod.bo.user.dao.impl;

import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.user.dao.UserAttemptsDao;
import com.woqod.bo.user.dao.UserDao;
import com.woqod.bo.user.dao.entity.UserAttempts;
import com.woqod.bo.user.dao.repository.UserAttemptsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.LockedException;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public class UserAttemptsDaoImpl implements UserAttemptsDao {

    private static final long MAX_ATTEMPTS = 3;
    private final UserAttemptsRepository userAttemptsRepository;

    private final UserDao userDao;

    @Autowired
    public UserAttemptsDaoImpl(UserAttemptsRepository userAttemptsRepository, UserDao userDao) {
        this.userAttemptsRepository = userAttemptsRepository;
        this.userDao = userDao;
    }


    @Override
    public void updateFailAttempts(String username) {
        Optional<UserAttempts> user = userAttemptsRepository.findByUsername(username);
        UserAttempts userAttempts;
        if (!user.isPresent()) { // user doesn't exist in user attempts table
            if (isUserExists(username)) { // check if user exist in user table
                // if no record, insert a new with attempts = 1
                userAttempts = new UserAttempts(username, 1L, LocalDate.now());
                userAttemptsRepository.save(userAttempts);
            }
        } else { // user exist in user attempts table
            userAttempts = user.get();
            if (isUserExists(username)) { // check if user exist in user table if exist increment attempt per 1
                // update attempts count, +1
                userAttempts.incrementAttempts(1);
                userAttemptsRepository.save(userAttempts);
            }

            if (userAttempts.getAttempts() >= getMaxAttempts()) { // check if attempts >= to max  attempts if true block and disable user
                // locked user
                userDao.blockUser(username);
                // throw exception
                throw new LockedException("User Account is locked!");
            }
        }

    }

    @Override
    public void resetFailAttempts(String username) {
        Optional<UserAttempts> userAttempts = userAttemptsRepository.findByUsername(username);
        if (userAttempts.isPresent()) { // if user attempts exist then reset it to 0
            UserAttempts userAttemptsObject = userAttempts.get();
            userAttemptsObject.setAttempts(0L);
            userAttemptsObject.setLastModified(LocalDate.now());
            userAttemptsRepository.save(userAttemptsObject);
        }
    }

    @Override
    public UserAttempts getUserAttempts(String username) {
        Optional<UserAttempts> userAttempts = userAttemptsRepository.findByUsername(username);
        return userAttempts.orElseThrow(() -> new DataNotFoundException("userAttempts", username, "UserAttempts"));
    }


    /**
     * used to test if user exist
     */
    private boolean isUserExists(String username) {

        boolean result = false;

        Long count = userDao.countByUserName(username);
        if (count > 0) { // user exist
            result = true;
        }

        return result;
    }

    /**
     * used to get Max attemts from DB if exist
     *
     * @return
     */
    public static long getMaxAttempts() {
        return MAX_ATTEMPTS;
    }
}
