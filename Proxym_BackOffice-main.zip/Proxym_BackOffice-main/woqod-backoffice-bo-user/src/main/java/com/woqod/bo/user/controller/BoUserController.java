package com.woqod.bo.user.controller;

import com.google.common.base.Strings;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.interfaces.AuthorityService;
import com.woqod.bo.commons.interfaces.LoadUserService;
import com.woqod.bo.commons.interfaces.UserAttemptsService;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.model.*;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.user.enums.MenuEnum;
import com.woqod.bo.user.mapper.UserMapper;
import com.woqod.bo.user.service.RoleService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.commons.utils.DateFormatter;

import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Controller
@RequestMapping("/bousermanagement")
@Data
public class BoUserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BoUserController.class);
    private static final String SERVICE_NAME = "BO_USERS";

    private static final String SUPER_ADMIN = "SUPER_ADMIN";

    /**
     * Beans
     **/
    private final Permissions permissions;
    private final DataFactory dataFactory;
    private final AuthorityService authorityService;
    private final LoadUserService loadUserService;
    private final RoleService roleService;
    private final UserService userService;
    private final UserAttemptsService userAttemptsService;

    /**
     * Attributes
     **/
    private List<UserRoleForm> userRoleList;
    private List<RoleModel> roles;
    private UserRoleForm userRoleFormToEdit;
    private UserRoleForm userRoleFormToAdd;
    private UserRoleForm filterList;
    private UserRoleForm filterAdd;
    private UserModel userEdit;
    private LocalDate startCreatedAtDate;
    private LocalDate endCreatedAtDate;
    private String secretPass = "letMeIn!";
    private static final String ACCESS = "access";
    private StreamedContent fileCSV;
    private StreamedContent file;
    private long numberOfBoUsers;

    @Autowired
    public BoUserController(Permissions permissions,
                            DataFactory dataFactory,
                            AuthorityService authorityService,
                            LoadUserService loadUserService,
                            RoleService roleService,
                            UserService userService,
                            UserAttemptsService userAttemptsService) {
        this.permissions = permissions;
        this.dataFactory = dataFactory;
        this.authorityService = authorityService;
        this.loadUserService = loadUserService;
        this.roleService = roleService;
        this.userService = userService;
        this.userAttemptsService = userAttemptsService;
    }

    @GetMapping("")
    public ModelAndView display() {
        LOGGER.debug("[RoleManagementController] display ");
        MenuEnum menuEnum = MenuEnum.DISPLAY_BO_USER;
        ModelAndView modelAndView = new ModelAndView();
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            init();
            modelAndView.setViewName("bousers/bousers");
        } else {
            modelAndView.setViewName(ACCESS);
        }
        return modelAndView;
    }

    @GetMapping(value = "addbouser")
    public ModelAndView addUser() {
        LOGGER.debug("[AddUserBoController] addUser");
        ModelAndView modelView = new ModelAndView();
        MenuEnum menuEnum = MenuEnum.ADD_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            initAdd();
            modelView.setViewName("bousers/addbouser");
        } else {
            modelView.setViewName(ACCESS);
        }
        return modelView;
    }

    @GetMapping(value = "editbouser")
    public ModelAndView editUser() {
        LOGGER.debug("[AddUserBoController] addUser");
        ModelAndView modelView = new ModelAndView();
        HttpSession session = BoUtils.getSession();
        userEdit = (UserModel) session.getAttribute("User");
        MenuEnum menuEnum = MenuEnum.ADD_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            initAdd();
            modelView.setViewName("bousers/editbouser");
        } else {
            modelView.setViewName(ACCESS);
        }
        return modelView;
    }

    @GetMapping(value = "editadmin")
    public ModelAndView editAdministrator() {
        LOGGER.debug("[AddUserBoController] editUser");
        ModelAndView modelView = new ModelAndView();
        MenuEnum menuEnum = MenuEnum.EDIT_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            modelView.setViewName("bousers/editadministrator");
        } else {
            modelView.setViewName(ACCESS);
        }
        return modelView;
    }

    /**
     * initialisation avant l'affichage de la page list des bo users
     */

    public void init() {
        userRoleFormToEdit = new UserRoleForm();
        userRoleList = new ArrayList<>();
        initUsers();
        initRoles();
        numberOfBoUsers = userService.count();
        filterList = new UserRoleForm();
        search();
    }

    /**
     * init add page
     */
    public void initAdd() {
        LOGGER.debug("[BoUserController] init");
        filterAdd = new UserRoleForm();
        userRoleFormToAdd = new UserRoleForm();
        // retreive ldap users
        List<ExternalUser> userLdapList = loadUserService.getAllUsers();
        // filter with existing user in data base
        List<ExternalUser> externalUserList = loadUsers(userLdapList);
        // prepare user role list from external user
        retreiveUserRoleList(externalUserList);
        initRoles();
    }

    /**
     * search filter in bo user list page
     */
    public void search() {
        LOGGER.debug("[BoUserController] search with filter ");
        // search with selected filter
        List<AuthorityModel> authorities = authorityService.search(filterList, startCreatedAtDate, endCreatedAtDate);
        userRoleList = retreiveAllBoUsers(authorities);
        numberOfBoUsers = userRoleList.size();
    }

    /**
     * search Filter in add bo user page
     */
    public void searchAdd() {
        List<ExternalUser> externalUserList = null;
        if (filterAdd != null && !Strings.isNullOrEmpty(filterAdd.getUserName())) {
            externalUserList = loadUserService.getUsersWithFilter(filterAdd);
        } else {
            externalUserList = loadUserService.getAllUsers();
        }
        List<ExternalUser> filteredExternalUsers = loadUsers(externalUserList);
        retreiveUserRoleList(filteredExternalUsers);
        initRoles();
    }

    /**
     * save new user
     *
     * @throws IOException
     */
    public void saveUser() {
        LOGGER.debug("[ BoUserController ] saveUser");
        MenuEnum menuEnum = MenuEnum.ADD_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            if (userRoleFormToAdd.getRoleName() == null || userRoleFormToAdd.getRoleName().isEmpty()) {
                BoUtils.showErrorPopup("Roles", "Select one role at least");
                return;
            }
            // prepare external user from userRoleFormToAdd
            ExternalUser externaluser = mapUserRoleFormToExternalUser(userRoleFormToAdd);
            // save user
            UserModel userModel = userService.save(UserMapper.externalUserToUserModel(externaluser));
            // retreive role from data base by name
            RoleModel roleModel = roleService.findOneRoleByName(userRoleFormToAdd.getRoleName());
            // save authority
            authorityService.save(new AuthorityModel(userModel, roleModel));
            initAdd();
            BoUtils.showsuccesspopup();
            dataFactory.redirect("bousermanagement");
        } else {
            // access denied
            initAdd();
            permissions.getDataFactory().redirect(ACCESS);
        }
    }


    /**
     * edit profile of  current user
     */
    public void editUsers() {
        LOGGER.debug("[ BoUserController ] saveUser");
        MenuEnum menuEnum = MenuEnum.EDIT_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            userService.update(userEdit);
            BoUtils.showsuccesspopup();
        } else {
            // access denied
            initAdd();
            permissions.getDataFactory().redirect(ACCESS);
        }

    }


    /**
     * delete user
     */
    public Boolean delete(UserRoleForm userRole) {
        LOGGER.debug("[RoleManagementController] delete ");
        MenuEnum menuEnum = MenuEnum.DELETE_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            if (userRole != null) {
                try {
                    authorityService.deleteAuthority(userRole.getUserName());
                    userRoleList.remove(userRole);
                    BoUtils.showsuccesspopup();
                    init();
                } catch (RuntimeException e) {
                    log.error(e.getMessage());
                    BoUtils.showFailurePopup();
                    return false;
                }
            }
        } else {
            // access denied
            permissions.getDataFactory().redirect(ACCESS);
            return false;
        }
        return true;
    }

    /**
     * edit user
     *
     * @throws IOException
     */
    public void edit() {
        LOGGER.debug("[BOUserController] edit ");
        MenuEnum menuEnum = MenuEnum.EDIT_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            try {
                authorityService.updateAuthority(userRoleFormToEdit);
                init();
                BoUtils.showsuccesspopup();
            } catch (DataNotFoundException e) {
                // error user not found
                init();
                BoUtils.showErrorPopup("", e.getErrorMsg());
            }
        } else {
            // access denied
            init();
            permissions.getDataFactory().redirect(ACCESS);
        }

    }

    /**
     * edit user status
     *
     * @param ur
     * @throws IOException
     */
    public void editStatus(UserRoleForm ur) {
        MenuEnum menuEnum = MenuEnum.EDIT_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            Boolean newStatus = !ur.getEnabled();
            UserModel userModel = userService.findOneUserByName(ur.getUserName());
            if (userModel != null) {
                userModel.setEnabled(newStatus);
                userModel.setAccountNonLocked(newStatus);
                userService.update(userModel);
                userAttemptsService.resetFailAttempts(ur.getUserName());

            } else {
                BoUtils.showErrorPopup("noUserFound", "bo_user_messages");
            }
            init();

        } else {
            // access denied
            init();
            permissions.getDataFactory().redirect(ACCESS);
        }
    }


    /**
     * generate pdf
     *
     * @param document
     * @throws IOException
     */
    /**
     * generate pdf
     *
     * @param document
     * @throws IOException
     */
    public void preProcessPDF(Object document) {
        MenuEnum menuEnum = MenuEnum.EXPORT_BO_USER;
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            Document pdf = (Document) document;
            pdf.open();
            pdf.setPageSize(PageSize.A4);
        } else {
            // access denied
            init();
            permissions.getDataFactory().redirect(ACCESS);
        }
    }

    /**
     * clear filter for bo user list page
     */
    public void clear() {
        userRoleFormToEdit = new UserRoleForm();
        filterList = new UserRoleForm();
        startCreatedAtDate = null;
        endCreatedAtDate = null;
        search();
    }

    /**
     * clear filter for bo user add page
     */
    public void clearAdd() {
        initAdd();
    }


    /**
     * initialisation des users
     */
    public void initUsers() {
        // retreive bo users from database
        List<AuthorityModel> authorities = authorityService.getAuthorities();
        userRoleList = retreiveAllBoUsers(authorities);
    }

    /**
     * initialisation des roles
     */
    public void initRoles() {
        roles = roleService.getAllRoles();
    }

    public void retreiveUserRoleList(List<ExternalUser> externalUserList) {
        userRoleList = new ArrayList<>();
        externalUserList.forEach(externalUser ->
                userRoleList.add(UserRoleForm.builder()
                        .userName(externalUser.getUserName())
                        .fullName(externalUser.getFullName())
                        .roleName("")
                        .roleDescription("")
                        .build()));
    }

    /**
     * retreive users roles from authorities
     */
    public List<UserRoleForm> retreiveUsersRoles(List<AuthorityModel> authorities) {
        List<UserRoleForm> userRoleL = new ArrayList<>();
        // retreive authenticated user in order to be removed from list to show
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserName = "";
        if (!(authentication instanceof AnonymousAuthenticationToken) && authentication != null) {
            currentUserName = authentication.getName();
        }
        if (authentication != null) {
            // loop list of users in order to remove authenticated user and super admin user
            for (AuthorityModel authority : authorities) {
                if(!authority.getUser().getUserName().equals(currentUserName)
                        && !authority.getRole().getName().equals(SUPER_ADMIN)) {
                    UserRoleForm userRole = new UserRoleForm();

                    userRole.setRoleName(authority.getRole().getName());
                    userRole.setUserName(authority.getUser().getUserName());
                    userRole.setFirstName(authority.getUser().getFirstName());
                    userRole.setLastName(authority.getUser().getLastName());
                    userRole.setEmail(authority.getUser().getEmail());
                    userRole.setEnabled(authority.getUser().getEnabled());
                    userRole.setFullName(authority.getUser().getFullName());
                    userRole.setCreatedAt(authority.getCreatedAt());
                    userRole.setRoleDescription(authority.getRole().getDesignation());

                    // add userRole to the list to shown
                    userRoleL.add(userRole);
                }
            }
        }
        return userRoleL;
    }

    /**
     * retreive all bo users
     */
    public List<UserRoleForm> retreiveAllBoUsers(List<AuthorityModel> authorities) {
        List<UserRoleForm> userRoleL = new ArrayList<>();
        // retreive authenticated user in order to be removed from list to show
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            // loop list of users in order to remove authenticated user and super admin user
            for (AuthorityModel authority : authorities) {
                UserRoleForm userRole = new UserRoleForm();

                userRole.setRoleName(authority.getRole().getName());
                userRole.setUserName(authority.getUser().getUserName());
                userRole.setFirstName(authority.getUser().getFirstName());
                userRole.setLastName(authority.getUser().getLastName());
                userRole.setEmail(authority.getUser().getEmail());
                userRole.setEnabled(authority.getUser().getEnabled());
                userRole.setFullName(authority.getUser().getFullName());
                userRole.setCreatedAt(authority.getCreatedAt());
                userRole.setRoleDescription(authority.getRole().getDesignation());

                // add userRole to the list to shown
                userRoleL.add(userRole);
            }
        }
        return userRoleL;
    }


    /**
     * load users
     */
    public List<ExternalUser> loadUsers(List<ExternalUser> userLdapList) {
        LOGGER.debug("[AddUserBoController] loadUsers");
        // retreive existing users from data base
        List<UserModel> userList = userService.findAll();
        // retreive existing name list
        List<String> names = userList.stream().map(UserModel::getUserName).collect(Collectors.toList());
        List<ExternalUser> externalUserList;
        // filter name list
        if (!names.isEmpty() && !userLdapList.isEmpty()) {
            externalUserList = userLdapList.stream().filter(externalUser ->
                    !names.contains(externalUser.getUserName())).collect(Collectors.toList());
        } else {
            externalUserList = new ArrayList<>(userLdapList);
        }
        return externalUserList;
    }

    /**
     * mapUserRoleFormToExternalUser
     */
    public ExternalUser mapUserRoleFormToExternalUser(UserRoleForm userRoleForm) {
        LOGGER.debug("[ BoUserController ] mapUserRoleFormToExternalUser");
        return ExternalUser.builder()
                .userName(userRoleForm.getUserName())
                .firstName(userRoleForm.getFirstName())
                .lastName(userRoleForm.getLastName())
                .email(userRoleForm.getEmail())
                .fullName(userRoleForm.getFullName())
                .password(secretPass)
                .build();
    }

    public void exportCSV() throws IOException, JRException {
        List<AuthorityModel> authorities = authorityService.search(filterList, startCreatedAtDate, endCreatedAtDate);
        userRoleList = retreiveAllBoUsers(authorities);
        String base64 = GenerateJasperReport.generateReport(retreiveAllBoUsers(authorities), "export/boUser.jrxml", "Backoffice Users List", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV =
                DefaultStreamedContent.builder().contentType("text/plain").name("BO_USERS.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        List<AuthorityModel> authorities = authorityService.search(filterList, startCreatedAtDate, endCreatedAtDate);
        userRoleList = retreiveAllBoUsers(authorities);
        String base64 = GenerateJasperReport.generateReport(userRoleList, "user/boUser.jrxml", "Backoffice Users List", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file =
                DefaultStreamedContent.builder().contentType("text/plain").name("BO_USERS.pdf").stream(() -> is).build();

    }
}
