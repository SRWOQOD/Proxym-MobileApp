package com.woqod.bo.user.dao;

import com.woqod.bo.commons.model.UserRoleForm;
import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.entity.User;

import java.time.LocalDate;
import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:44
 */
public interface AuthorityDao {

    Boolean checkAuthorityExistByUser(String userName);

    void save(Authority authority);

    /**
     * Used to save Authority list
     **/
    void save(List<Authority> authorities);

    /**
     * Used to update Authority list
     **/
    void update(List<Authority> authorities);

    /**
     * Used to retrieve Authority list
     */
    List<Authority> getAuthorities();

    /**
     * Used to update Authority for giving user
     *
     * @param user
     * @param role
     */
    void updateAuthority(User user, Role role);

    /**
     * Return user' authority
     */
    Authority getAuthorityByUser(User user);

    /**
     * Used to delete user'Authority
     *
     * @param user
     */
    void deleteAuthorityByUser(User user);

    /**
     * Get Authority By roleName
     *
     * @param role
     */
    List<Authority> getAuthorityByRole(Role role);

    List<Authority> search(UserRoleForm filter, LocalDate startCreatedAtDate, LocalDate endCreatedAtDate);


}
