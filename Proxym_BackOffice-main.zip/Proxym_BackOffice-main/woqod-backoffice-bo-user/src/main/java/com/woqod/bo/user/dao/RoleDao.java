package com.woqod.bo.user.dao;


import com.woqod.bo.user.dao.entity.Role;

import java.util.List;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 16:52
 */
public interface RoleDao {
    Boolean checkExistingRoleByCode(String code);

    /**
     * Used to save one role
     */
    Role save(Role role);


    /**
     * Used to retrieve all roles
     */
    List<Role> findAll();

    /**
     * used to retrieve one role by name
     */
    Role findOneByName(String name);

    Role findOneRoleByName(String name);

    /**
     * used to delete role
     */
    Boolean delete(Role role);

    List<Role> search(String name);

    long count();

}
