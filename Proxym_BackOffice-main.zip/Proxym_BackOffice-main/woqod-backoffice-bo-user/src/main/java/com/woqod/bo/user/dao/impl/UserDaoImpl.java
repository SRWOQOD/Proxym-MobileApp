package com.woqod.bo.user.dao.impl;

import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.exceptions.UpdatingDataException;
import com.woqod.bo.user.dao.UserDao;
import com.woqod.bo.user.dao.entity.User;
import com.woqod.bo.user.dao.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserDaoImpl implements UserDao {

    private final UserRepository userRepository;

    @Autowired
    public UserDaoImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void save(List<User> users) {
        userRepository.saveAll(users);
    }

    @Override
    public Boolean checkIFExistUserByUserName(String userName) {
        Optional<User> userOptional = userRepository.findOneByUserName(userName);
        return userOptional.isPresent();
    }

    @Override
    public User saveUser(User user) {

        try {
            return userRepository.save(user);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("BO_USER", ex);
        }
    }

    @Override
    public User findOneByUserName(String userName) {
        Optional<User> userOptional = userRepository.findOneByUserName(userName);
        return userOptional.orElseThrow(() -> new DataNotFoundException("user", userName, "User"));
    }

    @Override
    public User findOneUserByName(String userName) {
        Optional<User> userOptional = userRepository.findOneByUserName(userName);
        return userOptional.orElse(null);
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    public List<String> findAllUserName() {
        return userRepository.findAllUserName();
    }

    @Override
    public void update(User user) {
        userRepository.save(user);

    }

    @Override
    public void delete(User user) {
        userRepository.delete(user);
    }

    @Override
    public Long countByUserName(String username) {
        return userRepository.countByUserName(username);
    }

    @Override
    public void blockUser(String username) {
        Optional<User> userOptional = userRepository.findOneByUserName(username);
        if (userOptional.isPresent()) { // disable and block user if exist
            User user = userOptional.get();
            user.setEnabled(false);
            user.setAccountNonLocked(false);
            userRepository.save(user);
        }
    }

    @Override
    public long count() {
        return userRepository.count();
    }
}
