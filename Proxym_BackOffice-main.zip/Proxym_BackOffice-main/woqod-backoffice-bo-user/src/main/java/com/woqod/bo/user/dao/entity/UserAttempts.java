package com.woqod.bo.user.dao.entity;

import com.woqod.bo.commons.Constants;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = Constants.BO_USER_ATTEMPTS)
public class UserAttempts {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @Column(name = "attempts")
    private Long attempts;

    private LocalDate lastModified;

    public UserAttempts() {
    }

    public UserAttempts(String username, Long attempts, LocalDate lastModified) {
        this.username = username;
        this.attempts = attempts;
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }

    public UserAttempts(Long id, String username, Long attempts, LocalDate lastModified) {
        this.id = id;
        this.username = username;
        this.attempts = attempts;
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getAttempts() {
        return attempts;
    }

    public void setAttempts(Long attempts) {
        this.attempts = attempts;
    }

    public LocalDate getLastModified() {
        return lastModified != null ? LocalDate.now() : null;
    }

    public void setLastModified(LocalDate lastModified) {
        this.lastModified = lastModified != null ? LocalDate.now() : null;
    }

    /**
     * used to increment  attempts by a number
     *
     * @param number
     */
    public void incrementAttempts(int number) {
        this.attempts = this.attempts + number;
    }
}
