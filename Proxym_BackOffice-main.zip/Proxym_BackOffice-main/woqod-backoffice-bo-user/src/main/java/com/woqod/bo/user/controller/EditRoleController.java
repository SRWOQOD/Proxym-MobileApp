package com.woqod.bo.user.controller;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.interfaces.FeatureRoleService;
import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.user.enums.MenuEnum;
import com.woqod.bo.user.service.RoleService;
import com.woqod.bo.user.service.ServiceRole;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@Data
@RequestMapping("/borolemanagement")
public class EditRoleController {
    private static final Logger LOGGER = LoggerFactory.getLogger(EditRoleController.class);

    private Permissions permissions;
    private final FeatureRoleService featureRoleService;
    private final RoleService roleService;
    private final ServiceRole serviceRole;
    private final FeatureService featureService;
    private final DataFactory dataFactory;

    private List<RoleModel> rolesForTemplate = new ArrayList<>();
    private List<String> listTemplateName;
    private RoleModel edittRole;
    private RoleModel editRole;
    private String templateSelected = "";
    private List<FeatureRoleModel> featureRoles;
    private  List<FeatureModel> listFeatureParent = new ArrayList<>();
    private TreeNode featuresTreeNodeL = null;
    private TreeNode featuresTreeNodeR = null;
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private TreeNode[] selectedFeaturesR;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private TreeNode[] selectedFeaturesL;

    public TreeNode[] getSelectedFeaturesL() {
        return selectedFeaturesL != null ? selectedFeaturesL : new TreeNode[]{};
    }

    public TreeNode[] getSelectedFeaturesR() {
        return selectedFeaturesR != null ? selectedFeaturesR : new TreeNode[]{};
    }

    public void setSelectedFeaturesR(TreeNode[] selectedFeaturesR) {
        this.selectedFeaturesR = selectedFeaturesR != null ? selectedFeaturesR : new TreeNode[]{};
    }

    public void setSelectedFeaturesL(TreeNode[] selectedFeaturesL) {
        this.selectedFeaturesL = selectedFeaturesL != null ? selectedFeaturesL : new TreeNode[]{};
    }

    @Autowired
    public EditRoleController(Permissions permissions, FeatureRoleService featureRoleService, ServiceRole serviceRole,
                              RoleService roleService, FeatureService featureService, DataFactory dataFactory) {
        this.permissions = permissions;
        this.featureRoleService = featureRoleService;
        this.roleService = roleService;
        this.featureService = featureService;
        this.dataFactory = dataFactory;
        this.serviceRole = serviceRole;

    }

    @GetMapping("/editrole")
    public ModelAndView displayEditRolePage(@RequestParam("name") String name) {
        MenuEnum menuEnum = MenuEnum.EDIT_ROLE_BO_USER;
        ModelAndView modelAndView = new ModelAndView();
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            LOGGER.info("[EditRoleController] display edit Role Page ");
            edittRole = roleService.findOneRoleByName(name);
            initEditPage();
            modelAndView.setViewName("roles/editboroles");
        } else {
            modelAndView.setViewName("access");
        }
        return modelAndView;
    }

    /**
     *
     */
    public void initEditPage() {
        LOGGER.info("[EditRoleController] initEditPage ");
        editRole = edittRole;
        if (rolesForTemplate == null || rolesForTemplate.isEmpty()) {
            rolesForTemplate = roleService.getAllRoles();
        }

        listTemplateName = new ArrayList<>();
        listTemplateName.add("Display_View");

        for (RoleModel item : rolesForTemplate) {
            if (!item.getName().equals("SUPER_ADMIN")) {
                listTemplateName.add(item.getName());
            }
        }
        //get all features list from session
        listFeatureParent = dataFactory.getFeatureList();
        listToTreeNode();
        if (templateSelected.equals("Display_View")) {
            featureRoles = featureRoleService.getFeatureRolesByRoleName(editRole.getName());
            serviceRole.setSelectedItemForDisplayView(featuresTreeNodeL, featuresTreeNodeR);
        } else {
            String selectedRoleName = BoUtils.isEmptyOrNull(templateSelected) ? editRole.getName() : templateSelected;
            featureRoles = featureRoleService.getFeatureRolesByRoleName(selectedRoleName);
            serviceRole.setSelectedItem(featureRoles, featuresTreeNodeL, featuresTreeNodeR);
        }

    }

    /**
     *
     */
    public void reset() {
        templateSelected = "";
        initEditPage();
    }

    public Boolean editRoleConfiguration() {
        MenuEnum menuEnum = MenuEnum.EDIT_ROLE_BO_USER;
        LOGGER.info("[EditRoleController] editRoleConfiguration ");
        try {
            if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {

                // tester les champs du role et les check des permissions
                if (BooleanUtils.isTrue(serviceRole.validateFields(editRole, selectedFeaturesL, selectedFeaturesR))) {

                    // save role
                    RoleModel srole = roleService.save(editRole);
                    // si l'enregistrement passe convenablement on passe à enregistrer les permissions
                    if (srole != null) {
                        List<FeatureRoleModel> list = new ArrayList<>();

                        serviceRole.putFeatureInList(selectedFeaturesL, editRole, list);
                        serviceRole.putFeatureInList(selectedFeaturesR, editRole, list);

                        list = serviceRole.deleteDuplication(list);
                        featureRoleService.deleteFeatureRoles(editRole.getName());
                        // save permissions
                        featureRoleService.save(list);
                        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                "Edit Role With Permissions finish with success ", "");
                        FacesContext.getCurrentInstance().addMessage(null, msg);
                        BoUtils.showsuccesspopup();
                        permissions.getDataFactory().redirect("borolemanagement");
                        return true;
                    } else {
                        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                "Error When editing the role '" + editRole.getName() + "'", "");
                        FacesContext.getCurrentInstance().addMessage(null, msg);
                        templateSelected = "";
                        initEditPage();
                        return false;
                    }

                } else {
                    // si les champs ne sont pas vérifier affiché un pop up de vérification
                    return false;
                }
            } else {
                // access denied
                FacesContext.getCurrentInstance().getExternalContext().redirect(dataFactory.getContext() + "/access.xhtml");
                return false;
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            initEditPage();
            return false;
        }
    }

    /**
     *
     */
    public void unCheckAll() {
        listToTreeNode();
        serviceRole.unCheckAll(featuresTreeNodeL, featuresTreeNodeR);
    }

    /**
     *
     */
    public void checkAll() {
        listToTreeNode();
        serviceRole.checkAll(featuresTreeNodeL, featuresTreeNodeR);
    }

    /**
     * @param selectedRoleName
     */
    public void echangeTemplateVisibility(String selectedRoleName) {
        featureRoles = featureRoleService.getFeatureRolesByRoleName(selectedRoleName);
        serviceRole.setSelectedItem(featureRoles, featuresTreeNodeL, featuresTreeNodeR);
    }

    /**
     * @param featureModel
     * @param root
     */
    private static void createNodeTree(FeatureModel featureModel, TreeNode root) {

        TreeNode node = new CheckboxTreeNode(featureModel, root);
        List<FeatureModel> childrenFeatures = featureModel.getChildrenFeatures();
        if (childrenFeatures != null && !childrenFeatures.isEmpty()) {
            node.setExpanded(true);
            for (FeatureModel feature : childrenFeatures) {
                createNodeTree(feature, node);
            }
        }

    }

    /**
     *
     */
    private void listToTreeNode() {
        LOGGER.info("[EditRoleController] listToTreeNode");
        TreeNode root = new CheckboxTreeNode(new FeatureModel("11111", "ALL"), null);

        int half = listFeatureParent.size() / 2;
        FeatureModel featureModel;
        for (int i = 0; i < listFeatureParent.size(); i++) {
            featureModel = listFeatureParent.get(i);
            createNodeTree(featureModel, root);
            if (half == i) {
                featuresTreeNodeL = root;
                root = new CheckboxTreeNode(new FeatureModel("11111", "ALL"), null);
            }
        }
        featuresTreeNodeR = root;


    }

}
