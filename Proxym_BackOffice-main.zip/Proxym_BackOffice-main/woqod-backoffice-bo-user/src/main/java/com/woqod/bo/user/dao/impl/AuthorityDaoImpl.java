package com.woqod.bo.user.dao.impl;


import com.querydsl.core.types.Predicate;
import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.exceptions.PersistingDataException;
import com.woqod.bo.commons.exceptions.UpdatingDataException;
import com.woqod.bo.commons.model.UserRoleForm;
import com.woqod.bo.user.dao.AuthorityDao;
import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.QAuthority;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.entity.User;
import com.woqod.bo.user.dao.repository.AuthorityRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * User: Nasreddine.Jrebi
 * Date: 22/11/2018 17:35
 */
@Repository
public class AuthorityDaoImpl implements AuthorityDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorityDaoImpl.class);
    private final AuthorityRepository authorityRepository;
    private static final String AUTHORITY = "Authority";

    @Autowired
    public AuthorityDaoImpl(final AuthorityRepository authorityRepository) {
        this.authorityRepository = authorityRepository;
    }

    public Predicate getPredicateRoleName( QAuthority qauth, UserRoleForm filter) {
        Predicate predicateRoleName = null;

        if ((filter.getRoleName() != null) && !(filter.getRoleName().isEmpty())) {
            predicateRoleName = qauth.role.roleName.contains(filter.getRoleName().trim());
        }

        if ((filter.getFirstName() != null) && !(filter.getFirstName().isEmpty())) {
            predicateRoleName = qauth.user.firstName.contains(filter.getFirstName().trim());
        }

        if ((filter.getLastName() != null) && !(filter.getLastName().isEmpty())) {
            predicateRoleName = qauth.user.lastName.contains(filter.getLastName().trim());
        }

        if ((filter.getEmail() != null) && !(filter.getEmail().isEmpty())) {
            predicateRoleName = qauth.user.email.contains(filter.getEmail().trim());
        }

        return predicateRoleName;
    }

    @Override
    public List<Authority> search(UserRoleForm filter, LocalDate startCreatedAtDate, LocalDate endCreatedAtDate) {

        LOGGER.info("[AuthorityDaoImpl] search ");
        Predicate predicateUserName = null;
        Predicate predicateFirstName = null;
        Predicate predicateLastName = null;
        Predicate predicateEmail = null;
        Predicate predicateStatus = null;
        Predicate predicateCreatedAt = null;

        QAuthority qauth = QAuthority.authority;


        if ((filter.getUserName() != null) && !(filter.getUserName().isEmpty())) {
            predicateUserName = qauth.user.userName.contains(filter.getUserName().trim());
        }

        Predicate predicateRoleName = getPredicateRoleName(qauth, filter);

        if ((filter.getRoleName() != null) && !(filter.getRoleName().isEmpty()) && (startCreatedAtDate != null || endCreatedAtDate != null)) {
            if (startCreatedAtDate != null && endCreatedAtDate != null) {
                predicateCreatedAt = qauth.createdAt.between(startCreatedAtDate, endCreatedAtDate);
            }
            if (startCreatedAtDate != null && endCreatedAtDate == null) {
                predicateCreatedAt = qauth.createdAt.after(startCreatedAtDate);
            }
            if (startCreatedAtDate == null) {
                predicateCreatedAt = qauth.createdAt.before(endCreatedAtDate);
            }
        }
        if (filter.getEnabled() != null) {
            predicateStatus = qauth.user.enabled.eq(filter.getEnabled());
        }
        Predicate authPredicate = qauth.isNotNull().and(predicateUserName).and(predicateStatus).and(predicateRoleName).and(predicateCreatedAt).and(predicateFirstName).and(predicateLastName).and(predicateEmail);
        return (List<Authority>) authorityRepository.findAll(authPredicate);
    }



    @Override
    public void save(List<Authority> authorities) {
        try {
            LOGGER.info("[AuthorityDaoImpl] save ");
            authorityRepository.saveAll(authorities);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException(AUTHORITY, ex);
        }
    }

    @Override
    public Boolean checkAuthorityExistByUser(String userName) {
        LOGGER.info("[AuthorityDaoImpl] checkAuthorityExistByUser user {} ", userName);
        Optional<Authority> authority = authorityRepository.findOneByUserUserName(userName);
        return authority.isPresent();
    }

    @Override
    public void save(Authority authority) {
        try {
            LOGGER.info("[AuthorityDaoImpl] save ");
            authorityRepository.saveAndFlush(authority);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException(AUTHORITY, ex);
        }
    }

    @Override
    public void update(List<Authority> authorities) {
        LOGGER.info("[AuthorityDaoImpl] update ");
        authorityRepository.saveAll(authorities);
        try {
            LOGGER.info("[AuthorityDaoImpl] update ");
            authorityRepository.saveAll(authorities);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException(AUTHORITY, ex);
        }
    }

    @Override
    public List<Authority> getAuthorities() {
        LOGGER.info("[AuthorityDaoImpl] getAuthorities ");
        return authorityRepository.findAll();

    }

    @Override
    public void updateAuthority(User user, Role role) {
        LOGGER.info("[AuthorityDaoImpl] updateAuthority ");
        try {
            Optional<Authority> authority = authorityRepository.findOneByUser(user);
            if (!authority.isPresent()) {
                throw new DataNotFoundException(AUTHORITY, null, AUTHORITY);
            } else {

                Authority auth = authority.get();
                auth.setRole(role);
                authorityRepository.save(auth);
            }
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException(AUTHORITY, ex);
        }

    }

    @Override
    public Authority getAuthorityByUser(User user) {
        LOGGER.info("[AuthorityDaoImpl] getAuthorityByUser user {} ", user.getUserName());
        Optional<Authority> authority = authorityRepository.findOneByUser(user);
        if (!authority.isPresent()) {
            throw new DataNotFoundException(AUTHORITY, null, AUTHORITY);
        }
        return authority.get();
    }

    @Override
    public void deleteAuthorityByUser(User user) {
        LOGGER.info("[AuthorityDaoImpl] deleteAuthority for user {} ", user.getUserName());
        Optional<Authority> authority = authorityRepository.findOneByUser(user);
        if (!authority.isPresent()) {
            throw new DataNotFoundException(AUTHORITY, null, AUTHORITY);
        }
        Authority auth = authority.get();
        authorityRepository.delete(auth);

    }

    @Override
    public List<Authority> getAuthorityByRole(Role role) {
        LOGGER.info("[AuthorityDaoImpl] getAuthorityByRole user {} ", role.getRoleName());
        Optional<List<Authority>> authority = authorityRepository.findOneByRole(role);
        if (!authority.isPresent()) {
            throw new DataNotFoundException(AUTHORITY, null, AUTHORITY);
        }
        return authority.get();
    }
}
