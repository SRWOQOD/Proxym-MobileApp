package com.woqod.bo.user.dao.repository;


import com.woqod.bo.user.dao.entity.Authority;
import com.woqod.bo.user.dao.entity.Role;
import com.woqod.bo.user.dao.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;
import java.util.Optional;

public interface AuthorityRepository extends JpaRepository<Authority, Long>, QuerydslPredicateExecutor<Authority> {
    Optional<Authority> findOneByUserUserName(String userName);

    /**
     * Find Authority by user
     *
     * @param user
     * @return
     */
    Optional<Authority> findOneByUser(User user);

    /**
     * Find Authority by role
     *
     * @param role
     * @return
     */
    Optional<List<Authority>> findOneByRole(Role role);


}
