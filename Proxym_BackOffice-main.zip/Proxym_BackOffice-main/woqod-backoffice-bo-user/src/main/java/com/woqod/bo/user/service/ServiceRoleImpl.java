package com.woqod.bo.user.service;


import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.commons.model.RoleModel;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;
import org.springframework.stereotype.Service;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;

/**
 * Created By Farouk-Kraiem
 *
 * @Date 10/06/2020
 * @Time 10:39
 **/
@Service
public class ServiceRoleImpl implements ServiceRole {

    @Override
    public void checkAll(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR) {

        changeNodeStatus(featuresTreeNodeL, true);
        changeNodeStatus(featuresTreeNodeR, true);
    }

    @Override
    public void unCheckAll(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR) {
        changeNodeStatus(featuresTreeNodeL, false);
        changeNodeStatus(featuresTreeNodeR, false);
    }

    @Override
    public void setSelectedItem(List<FeatureRoleModel> featureRoles, TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR) {
        for (FeatureRoleModel featureRoleModel : featureRoles) {
            String code = featureRoleModel.getFeature().getCode();
            List<TreeNode> leftTreeNodes = featuresTreeNodeL.getChildren();
            if (leftTreeNodes != null && !leftTreeNodes.isEmpty()) {
                for (TreeNode node : leftTreeNodes) {
                    drowFeatureNodeStatus(node, code, true);
                }
            }
            List<TreeNode> rightTreeNodes = featuresTreeNodeR.getChildren();
            if (rightTreeNodes != null && !rightTreeNodes.isEmpty()) {
                for (TreeNode node : rightTreeNodes) {
                    drowFeatureNodeStatus(node, code, true);
                }
            }
        }
    }

    @Override
    public void putFeatureInList(TreeNode[] selectedFeatures, RoleModel editRole, List<FeatureRoleModel> list) {

        for (TreeNode feature : selectedFeatures) {
            FeatureModel f = (FeatureModel) feature.getData();
            list.add(new FeatureRoleModel(f, editRole));

            if (feature.getParent() != null && feature.getParent().isPartialSelected()
                    && !((FeatureModel) feature.getParent().getData()).getCode().equals("11111")) {
                FeatureModel ff = (FeatureModel) feature.getParent().getData();
                list.add(new FeatureRoleModel(ff, editRole));

                if (feature.getParent().getParent() != null
                        && feature.getParent().getParent().isPartialSelected()
                        && !((FeatureModel) feature.getParent().getParent().getData()).getCode()
                        .equals("11111")) {

                    FeatureModel fff = (FeatureModel) feature.getParent().getParent().getData();
                    list.add(new FeatureRoleModel(fff, editRole));

                }
            }
        }
    }

    @Override
    public void drowFeatureNodeStatus(TreeNode node, String code, boolean status) {
        FeatureModel featureModel = (FeatureModel) node.getData();
        if (featureModel.getCode().equals(code) && (featureModel.getChildrenFeatures() == null || featureModel.getChildrenFeatures().isEmpty())) {
            node.setSelected(status);
        }

        List<TreeNode> subChild = node.getChildren();
        for (TreeNode treeNode : subChild) {
            drowFeatureNodeStatus(treeNode, code, status);
        }

    }


    @Override
    public void setSelectedItemForDisplayView(TreeNode featuresTreeNodeL, TreeNode featuresTreeNodeR) {
        changeStatusByName(featuresTreeNodeL, "DISPLAY", true);
        changeStatusByName(featuresTreeNodeR, "DISPLAY", true);
    }

    @Override
    public void changeStatusByName(TreeNode node, String name, boolean status) {
        if (node != null) {
            FeatureModel featureNode = (FeatureModel) node.getData();
            if (featureNode.getName().contains(name)) {
                node.setSelected(status);
            }
            List<TreeNode> children = node.getChildren();
            if (children != null && !children.isEmpty()) {
                for (TreeNode child : node.getChildren()) {
                    changeStatusByName(child, name, status);
                }
            }
        }
    }

    @Override
    public void setExpandedRecursively(final TreeNode node, final boolean expanded) {
        for (final TreeNode child : node.getChildren()) {
            setExpandedRecursively(child, expanded);
        }
        node.setExpanded(expanded);
    }


    @Override
    public void changeNodeStatus(TreeNode node, boolean status) {
        if (node != null) {
            node.setSelected(status);
            List<TreeNode> children = node.getChildren();
            if (children != null && !children.isEmpty()) {
                for (TreeNode child : node.getChildren()) {
                    changeNodeStatus(child, status);
                }
            }
        }
    }

    @Override
    public List<FeatureRoleModel> deleteDuplication(List<FeatureRoleModel> list) {
        List<FeatureRoleModel> result = new ArrayList<>();
        Boolean test = false;
        for (FeatureRoleModel feature : list) {
            test = false;
            for (FeatureRoleModel featureResult : result) {
                if (feature.getFeature().getCode().equals(featureResult.getFeature().getCode())) {
                    test = true;
                }
            }
            if (!BooleanUtils.isTrue(test)) {
                result.add(feature);
            }
        }
        return result;
    }

    @Override
    public Boolean validateFields(RoleModel r, TreeNode[] selectedFeaturesR, TreeNode[] selectedFeaturesL) {
        boolean bol = true;
        if (r.getDesignation().equals("") || r.getDesignation() == null || r.getName().equals("")
                || r.getName() == null) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Name and description of the role must be not empty", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            bol = false;
        }
        if (selectedFeaturesL.length == 0 && selectedFeaturesR.length == 0) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "At least one permission is required", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            bol = false;
        }
        return bol;
    }

    @Override
    public void createNodeTree(FeatureModel featureModel, TreeNode root) {
        TreeNode node = new CheckboxTreeNode(featureModel, root);
        List<FeatureModel> childrenFeatures = featureModel.getChildrenFeatures();
        if (childrenFeatures != null && !childrenFeatures.isEmpty()) {
            node.setExpanded(true);
            for (FeatureModel feature : childrenFeatures) {
                createNodeTree(feature, node);
            }
        }
    }

}
