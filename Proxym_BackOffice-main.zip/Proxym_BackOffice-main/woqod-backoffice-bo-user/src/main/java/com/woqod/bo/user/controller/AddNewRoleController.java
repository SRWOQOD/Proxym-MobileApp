package com.woqod.bo.user.controller;


import com.woqod.bo.commons.interfaces.FeatureRoleService;
import com.woqod.bo.commons.interfaces.FeatureService;
import com.woqod.bo.commons.model.FeatureModel;
import com.woqod.bo.commons.model.FeatureRoleModel;
import com.woqod.bo.commons.model.RoleModel;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.user.enums.MenuEnum;
import com.woqod.bo.user.service.RoleService;
import com.woqod.bo.user.service.ServiceRole;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@RequestMapping("/borolemanagement")
@Data
public class AddNewRoleController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AddNewRoleController.class);

    private final Permissions permissions;
    private final FeatureService featureService;
    private final RoleService roleService;
    private final FeatureRoleService featureRoleService;
    private final ServiceRole serviceRole;

    private RoleModel newRole = new RoleModel();
    private List<FeatureModel> listFeatureParent = new ArrayList<>();
    private List<String> listTemplateName;
    private List<RoleModel> rolesForTemplate = new ArrayList<>();

    private List<FeatureRoleModel> featureRoles;
    private TreeNode featuresTreeNodeL = null;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private TreeNode[] selectedFeaturesR;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private TreeNode[] selectedFeaturesL;

    private TreeNode featuresTreeNodeR = null;
    private String templateSelected = "";


    public TreeNode[] getSelectedFeaturesL() {
        return selectedFeaturesL != null ? selectedFeaturesL : new TreeNode[]{};
    }

    public TreeNode[] getSelectedFeaturesR() {
        return selectedFeaturesR != null ? selectedFeaturesR : new TreeNode[]{};
    }

    public void setSelectedFeaturesR(TreeNode[] selectedFeaturesR) {
        this.selectedFeaturesR = selectedFeaturesR != null ? selectedFeaturesR : new TreeNode[]{};
    }

    public void setSelectedFeaturesL(TreeNode[] selectedFeaturesL) {
        this.selectedFeaturesL = selectedFeaturesL != null ? selectedFeaturesL : new TreeNode[]{};
    }

    @Autowired
    public AddNewRoleController(Permissions permissions, FeatureService featureService, RoleService roleService,
                                FeatureRoleService featureRoleService, ServiceRole serviceRole) {
        this.permissions = permissions;
        this.featureService = featureService;
        this.roleService = roleService;
        this.featureRoleService = featureRoleService;
        this.serviceRole = serviceRole;
    }

    @GetMapping("/addNewRole")
    public ModelAndView displayAddNewRolePage() {
        MenuEnum menuEnum = MenuEnum.ADD_ROLE_BO_USER;
        ModelAndView modelAndView = new ModelAndView();
        if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {
            LOGGER.info("[AddNewRoleController] display Add New Role Page ");
            initAddPage();
            modelAndView.setViewName("roles/addboroles");
        } else {
            modelAndView.setViewName("access");
        }
        return modelAndView;
    }

    /**
     *
     */
    public void initAddPage() {
        LOGGER.debug("[AddNewRoleController] initAddPage ");
        newRole = new RoleModel();
        featuresTreeNodeL = new CheckboxTreeNode();
        featuresTreeNodeR = new CheckboxTreeNode();
        rolesForTemplate = roleService.getAllRoles();
        listTemplateName = new ArrayList<>();
        listTemplateName.add("Display_View");
        for (RoleModel item : rolesForTemplate) {
            if (!item.getName().equals("SUPER_ADMIN")) {
                listTemplateName.add(item.getName());
            }
        }
        listFeatureParent = featureService.findAllParent("none");
        // mapper les features dans une tree node
        listToTreeNode();
        featureRoles = new ArrayList<>();
        // si la template sélectionner est Display_View
        if (templateSelected.equals("Display_View")) {
            serviceRole.setSelectedItemForDisplayView(featuresTreeNodeL, featuresTreeNodeR);
        } else if (!templateSelected.equals("")) {
            featureRoles = featureRoleService.getFeatureRolesByRoleName(templateSelected);
            serviceRole.setSelectedItem(featureRoles, featuresTreeNodeL, featuresTreeNodeR);
        }

        serviceRole.setExpandedRecursively(featuresTreeNodeL, true);
        serviceRole.setExpandedRecursively(featuresTreeNodeR, true);
    }

    /**
     *
     */
    public void unChekAll() {
        templateSelected = "";
        listToTreeNode();
        serviceRole.unCheckAll(featuresTreeNodeL, featuresTreeNodeR);
    }

    /**
     *
     */
    public void chekAll() {
        templateSelected = "";
        listToTreeNode();
        serviceRole.checkAll(featuresTreeNodeL, featuresTreeNodeR);
    }


    public Boolean addNewRole() {
        MenuEnum menuEnum = MenuEnum.ADD_ROLE_BO_USER;
        LOGGER.info("[AddNewRoleController] addNewRole ");
        try {
            if (BooleanUtils.isTrue(permissions.isFeaturePermitted(menuEnum.name()))) {

                // tester les champs du nouveau role et les check des permissions
                if (BooleanUtils.isTrue(serviceRole.validateFields(newRole, selectedFeaturesL, selectedFeaturesR))) {
                    // vérifier si le nouveau role existe déja dans la BD ou non
                    RoleModel frole = roleService.findOneRoleByName(newRole.getName());
                    if (frole == null) {
                        // le nouveau role n'existe pas dans la BD
                        RoleModel srole = roleService.save(newRole);
                        // si l'enregistrement passe convenablement on passe à enregistrer les
                        // permissions
                        if (srole != null) {
                            List<FeatureRoleModel> list = new ArrayList<>();

                            serviceRole.putFeatureInList(selectedFeaturesL, newRole, list);
                            serviceRole.putFeatureInList(selectedFeaturesR, newRole, list);
                            list = serviceRole.deleteDuplication(list);
                            // save permissions

                            featureRoleService.save(list);
                            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Add new Role With Permissions finish with success ", "");
                            FacesContext.getCurrentInstance().addMessage(null, msg);
                            templateSelected = "";
                            permissions.getDataFactory().redirect("borolemanagement");
                            return true;
                        } else {
                            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
                                    "Error When adding the new role '" + newRole.getName() + "'", "");
                            FacesContext.getCurrentInstance().addMessage(null, msg);
                            return false;
                        }
                    } else {
                        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Role with name " + newRole.getName() + " already exists", "");
                        FacesContext.getCurrentInstance().addMessage(null, msg);
                        return false;
                    }
                } else {
                    // si les champs ne sont pas vérifier affiché un pop up de vérification
                    // les pop up sont déclarés dans la méthode validateFields
                    return false;
                }
            } else {
                permissions.getDataFactory().redirect("access");
                return false;
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            initAddPage();
            return false;
        }
    }

    /**
     *
     */
    public void clearAddNewRolePage() {
        templateSelected = "";
        initAddPage();
    }


    public void echangeTemplateVisibility(String s) {
        LOGGER.info("[AddNewRoleController] echangeTemplateVisibility to {} ", s);
        templateSelected = s;
        initAddPage();
    }

    private void listToTreeNode() {
        TreeNode root = new CheckboxTreeNode(new FeatureModel("11111", "ALL"), null);

        int half = listFeatureParent.size() / 2;
        FeatureModel featureModel;
        for (int i = 0; i < listFeatureParent.size(); i++) {
            featureModel = listFeatureParent.get(i);
            createNodeTree(featureModel, root);
            if (half == i) {
                featuresTreeNodeL = root;
                root = new CheckboxTreeNode(new FeatureModel("11111", "ALL"), null);
            }
        }
        featuresTreeNodeR = root;


    }

    private static void createNodeTree(FeatureModel featureModel, TreeNode root) {

        TreeNode node = new CheckboxTreeNode(featureModel, root);
        List<FeatureModel> childrenFeatures = featureModel.getChildrenFeatures();
        if (childrenFeatures != null && !childrenFeatures.isEmpty()) {
            node.setExpanded(true);
            for (FeatureModel feature : childrenFeatures) {
                createNodeTree(feature, node);
            }
        }

    }
}
