package com.woqod.bo.user.dao;


import com.woqod.bo.user.dao.entity.User;

import java.util.List;

public interface UserDao {

    Boolean checkIFExistUserByUserName(String userName);

    User saveUser(User user);

    /**
     * used to save user list
     */
    void save(List<User> users);

    /**
     * used to retrieve one user by username
     */
    User findOneByUserName(String userName);

    User findOneUserByName(String userName);

    /**
     * used retrieve all users
     */
    List<User> findAll();

    List<String> findAllUserName();

    /**
     * used to update one user
     */
    void update(User user);

    /**
     * used to delete one user
     */
    void delete(User user);

    /**
     * used to get number of row by username
     */
    Long countByUserName(String username);

    /**
     * used to block user
     */
    void blockUser(String username);

    long count();
}
