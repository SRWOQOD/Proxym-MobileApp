package com.woqod.bo.user.dao.repository;

import com.woqod.bo.user.dao.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * used to retrive one user by username
     *
     * @param userName
     * @return
     */
    Optional<User> findOneByUserName(String userName);

    /**
     * used to get number of row by username
     *
     * @param username
     * @return
     */
    Long countByUserName(String username);

    @Query("select u.userName from User u")
    List<String> findAllUserName();


}
