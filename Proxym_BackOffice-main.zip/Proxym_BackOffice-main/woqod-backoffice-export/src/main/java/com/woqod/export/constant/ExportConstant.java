package com.woqod.export.constant;

public final class ExportConstant {
    public static final String EXPORT_MANAGEMENT_URL = "/export";
    public static final String EXPORT_LIST = "exportOnePage";
    public static final String EXPORT_VIEW_MODEL = "exportViewModel";

    private ExportConstant() {

    }
}
