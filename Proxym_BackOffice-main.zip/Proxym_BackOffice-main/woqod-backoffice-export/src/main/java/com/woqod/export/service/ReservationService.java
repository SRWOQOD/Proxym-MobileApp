package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.reservation.ReservationResource;

import java.util.List;
import java.util.Map;

public interface ReservationService {

    PaginatedListResponse<ReservationResource> getPaginatedList(Map<String, String> uriParams);

    List<ReservationResource> getReservations(Map<String, String> uriParams);
}
