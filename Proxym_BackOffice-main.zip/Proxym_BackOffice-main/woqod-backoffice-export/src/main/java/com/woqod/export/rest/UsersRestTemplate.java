package com.woqod.export.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.UserResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/export.properties")
public class UsersRestTemplate {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private final String users;


    public UsersRestTemplate(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.getAllUsers}") String users) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.users = users;

    }

    /**
     * used to get parameters paginated and filtred
     */
    public PaginatedListResponse<UserResource> paginatedParams(Map<String, String> uriParams) {
        String uri = users.concat("/filtred");
        return (PaginatedListResponse<UserResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<UserResource>>>() {
                        });
    }

    public List<UserResource> getUsers(Map<String, String> uriParams) {
        String uri = users.concat("/users");
        return ((ListResponse<UserResource>) this.customRestTemplate.getGenericResponseBody(this.baseUrlProvider.getUrl(uri, uriParams), new ParameterizedTypeReference<GenericResponse<ListResponse<UserResource>>>() {
        })).getList();
    }

}

