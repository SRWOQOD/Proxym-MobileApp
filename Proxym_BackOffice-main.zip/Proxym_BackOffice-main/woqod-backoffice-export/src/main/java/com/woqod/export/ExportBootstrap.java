package com.woqod.export;

import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.export.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Component
public class ExportBootstrap {
    private static final String EXPORT_MANAGEMENT = "Export_Management";

    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(EXPORT_MANAGEMENT, ListMenu.builder()
                .menus(Arrays.asList(MenuEnum.values()))
                .build());
    }
}
