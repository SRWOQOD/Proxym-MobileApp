package com.woqod.export.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.export.service.ReservationService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.reservation.ReservationResource;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@Slf4j
public class ReservationLazyModels extends LazyDataModel<ReservationResource> {

    private static final long serialVersionUID = 1;
    private final transient ReservationService reservationService;
    private Map<String, String> uriParams;

    private Boolean searchData = false;

    public ReservationLazyModels(ReservationService reservationService, Map<String, String> uriParams) {
        this.reservationService = reservationService;
        this.uriParams = uriParams;
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtred and paginated data
     *
     * @param first
     * @param pageSize
     * @param sortField
     * @param sortOrder
     * @param filters
     * @return
     */
    @Override
    public List<ReservationResource> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                          Map<String, FilterMeta> filters) {

        try {
            if (BooleanUtils.isTrue(searchData)) {
                first = 0;
            }
            PaginatedListResponse<ReservationResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, first, pageSize));
            response = reservationService.getPaginatedList(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            searchData = false;
            Comparator<ReservationResource> comparator = Comparator.comparing(ReservationResource::getCreationDate).reversed();
            return response.getList().stream().sorted(comparator).collect(Collectors.toList());
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

}
