package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.TransactionLogResource;

import java.util.List;
import java.util.Map;

public interface TransactionLogService {
    List<TransactionLogResource> transactions(Map<String, String> uriParams);

    PaginatedListResponse<TransactionLogResource> getPaginatedTopUP(Map<String, String> uriParams);
}
