package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.export.rest.UsersRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.UserResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class UsersManagementServiceImpl implements UserService {

    private final UsersRestTemplate usersRestTemplate;

    public UsersManagementServiceImpl(UsersRestTemplate usersRestTemplate) {
        this.usersRestTemplate = usersRestTemplate;
    }

    @Override
    public List<UserResource> getUsers(Map<String, String> uriParams) {
        return usersRestTemplate.getUsers(uriParams);
    }

    @Override
    public PaginatedListResponse<UserResource> getPaginatedUser(Map<String, String> uriParams) {
        return usersRestTemplate.paginatedParams(uriParams);
    }
}
