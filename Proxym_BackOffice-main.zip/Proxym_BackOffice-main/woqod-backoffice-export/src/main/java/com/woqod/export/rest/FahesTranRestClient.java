package com.woqod.export.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.List;
import java.util.Map;


@Component
@Slf4j
@PropertySource("classpath:properties/fahes.properties")
public class FahesTranRestClient {

    private final CustomRestTemplate topUpRestTemplate = new CustomRestTemplate();
    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.transaction.paginated}")
    private String paginatedList;

    public FahesTranRestClient(BaseUrlProvider baseUrlProvider) {
        this.baseUrlProvider = baseUrlProvider;
    }


    public PaginatedListResponse<PRTransactionLogResource> paginatedListTransactions(Map<String, String> uriParams) {
        log.debug("[TopUpRestClient] paginatedListTransactions");
        String uri = paginatedList;

        return (PaginatedListResponse<PRTransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<PRTransactionLogResource>>>() {
                        });
    }

    public List<PRTransactionLogResource> getTransactions(Map<String, String> uriParams) {
        String uri = "/prtransactionlog";
        return ((ListResponse<PRTransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<PRTransactionLogResource>>>() {
                        })).getList();

    }
}
