package com.woqod.export.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.export.service.SurveyService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.SurveysResource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class SurveyLazyModels extends LazyDataModel<SurveysResource> {

    private final SurveyService surveyService;
    private static final long serialVersionUID = 1;

    private Map<String, String> uriParams;

    public SurveyLazyModels(SurveyService surveyService, Map<String, String> uriParams) {
        this.surveyService = surveyService;
        this.uriParams = uriParams;
    }


    /**
     * used to set uriParams and displayData in the lazy model instance
     *
     * @param uriParams
     */
    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    /**
     * used to get filtered and paginated data
     *
     * @param first
     * @param pageSize
     * @param sortField
     * @param sortOrder
     * @param filters
     * @return
     */
    @Override
    public List<SurveysResource> load(final int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            PaginatedListResponse<SurveysResource> response;
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));
            response = surveyService.getPaginatedSurvey(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();

        } catch (Exception e) {
            log.error(e.getMessage());
            return new ArrayList<>();
        }

    }
}