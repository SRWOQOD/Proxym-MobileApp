package com.woqod.export.viewmodel;


import com.google.common.base.Strings;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.*;
import com.woqod.export.constant.ExportConstant;
import com.woqod.export.lazymodel.*;
import com.woqod.export.service.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.TransactionLogResource;
import wq.woqod.resources.resources.UserResource;
import wq.woqod.resources.resources.reservation.ReservationResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class ExportOnePageViewModel {

    private static final String SERVICE_NAME = "REPORTING";
    /*
    Beans
     */
    private final ExportService exportService;
    private DataFactory dataFactory;
    private final TransactionLogService transactionLogService;
    private final UserService userService;
    private final SurveyService surveyService;
    private final TransactionService prTransactionService;
    private final ReservationService resevationService;
    private static final String USERS_MANAGEMENT = "USERS_MANAGEMENT";
    private static final String SURVEY = "SURVEY";
    private static final String CONTENT_TYPE = "text/plain";
    private static final String WOQODE_TRANSACTION = "WOQODE_TRANSACTION";
    private static final String FAHES_TRANSACTION = "FAHES_TRANSACTION";
    private static final String FAHES_BOOKING = "FAHES_BOOKING";
    private static final String MOBILE = "mobile";
    private static final String START_DATE = "startDate";
    private static final String END_DATE = "endDate";

    /*
    state
     */
    List<ReportEnum> enumValues;
    List<ReportEnum> selectedValues;
    List<ReportEnum> selectedValuesInit;
    ReportEnum selectedValue;
    private List<TransactionLogResource> transactionLogResources = new ArrayList<>();
    private List<ReservationResource> fahesBookingList = new ArrayList<>();
    private PaginatedListResponse<SurveysResource> surveysResources = new PaginatedListResponse<>();
    private List<wq.woqod.resources.resources.UserResource> userResources = new ArrayList<>();
    private List<PRTransactionLogResource> prTransactionLogResources = new ArrayList<>();
    private String selectedItem  = "NO_SELECTED_SERVICE";
    private ReportResource reportResource = new ReportResource();
    private String reportString = "";
    private StreamedContent file;
    private StreamedContent fileCSV;
    private StreamedContent fileExcel;
    private LazyDataModel<TransactionLogResource> lazyModel;
    private LazyDataModel<wq.woqod.resources.resources.UserResource> lazyModelUser;
    private LazyDataModel<SurveysResource> lazyModelSurvey;
    private LazyDataModel<ReservationResource> lazyModelFahesBooking;
    private LazyDataModel<PRTransactionLogResource> lazyModelFahes;
    private Map<String, String> uriParams;
    private Boolean error = false;
    private String errorMsg;
    private String transactionStatus = "";
    private String rpsStatus;
    private String apiStatus;
    private String userStatus;
    private String surveyStatus;
    private String fahesBookingStatus;

    @Autowired
    public ExportOnePageViewModel(ExportService exportService, TransactionLogService transactionLogService, UserService userService,
                                  SurveyService surveyService, TransactionService prTransactionService, ReservationService resevationService) {
        this.exportService = exportService;
        this.transactionLogService = transactionLogService;
        this.userService = userService;
        this.surveyService = surveyService;
        this.prTransactionService = prTransactionService;
        this.resevationService = resevationService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        reportResource = new ReportResource();
        selectedValuesInit = Arrays.asList(ReportEnum.values());
        log.debug("{} init", ExportConstant.EXPORT_VIEW_MODEL);
        enumValues = Arrays.asList(ReportEnum.values());
        selectedValues=new ArrayList<>();
        uriParams = new HashMap<>();
        transactionStatus = "";
        rpsStatus = "";
        apiStatus = "";
        userStatus = "";
        surveyStatus = "";
        fahesBookingStatus = "";
        search();
    }


    public void search() {
        if (selectedItem == null) {
             return;
        }
        reportString = "";
        if (reportResource.getStartDate() != null && reportResource.getEndDate() != null && !BooleanUtils.isTrue(checkDates())) {
            BoUtils.showErrorPopup("Error", "Start date must be smaller then end date");
            return;
        }
        if(selectedItem.equals(WOQODE_TRANSACTION)) {
            getWoqodTransactionParms();
        }

        if(selectedItem.equals(FAHES_TRANSACTION)) {
            getFahesTransactionParams();
        }

        if(selectedItem.equals(USERS_MANAGEMENT)) {
            getUserParams();
        }
        if(selectedItem.equals(SURVEY)){
            getSurveyParams();
        }
        if(selectedItem.equals(FAHES_BOOKING)){
            getFahesBookingParams();
        }
        selectedValues.add(ReportEnum.valueOf(selectedItem));
        reportString = ReportUtils.getExportString(selectedValues);
        update();
    }

    public void clear() {
        log.debug("{} clear", ExportConstant.EXPORT_VIEW_MODEL);
        init();
    }

    public void clear2(){
        reportResource = new ReportResource();
        uriParams = new HashMap<>();
        lazyModelUser = new UsersLazyModel(userService, uriParams);
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateExportReport(surveyService.surveys(uriParams), transactionLogResources, userResources, prTransactionLogResources, JasperReportType.CSV, selectedValuesInit);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Reporting.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {

        if(selectedItem.equals(SURVEY)) {
            String base64 = GenerateJasperReport.generateReport(surveyService.surveys(uriParams), "export/pdf/survey.jrxml", "Survey List", JasperReportType.PDF);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
            file = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Surveys.pdf").stream(() -> is).build();
        }
        if(selectedItem.equals(USERS_MANAGEMENT)) {
            List<UserResource> listUsers = userService.getUsers(uriParams);
            for (UserResource user : listUsers) {
                user.setQid(decryptQid(user.getQid()));
            }

            String base64 = GenerateJasperReport.generateReport(listUsers, "user/mobileUser.jrxml", "LIST OF USERS", JasperReportType.PDF);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
            file = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Users.pdf").stream(() -> is).build();
        }
        if(selectedItem.equals(WOQODE_TRANSACTION)) {

            List<TransactionLogResource> listTransactions = transactionLogService.transactions(uriParams);
            for (TransactionLogResource listTransaction : listTransactions) {
                listTransaction.setQid(BoUtils.decodeFromBase64(listTransaction.getQid()));
            }
            String base64 = GenerateJasperReport.generateReport(listTransactions, "woqodeTopup/transactionHistory.jrxml", "Topups", JasperReportType.PDF);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
            file = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Woqode_TOPUP.pdf").stream(() -> is).build();
        }
        if(selectedItem.equals(FAHES_TRANSACTION)) {

            List<PRTransactionLogResource> listTransactions = prTransactionService.transactions(uriParams);
            for (PRTransactionLogResource listTransaction : listTransactions) {
                listTransaction.setQid(BoUtils.decodeFromBase64(listTransaction.getQid()));
            }
            String base64 = GenerateJasperReport.generateReport(listTransactions, "fahes/fahesTransaction.jrxml", "Fahes Transactions", JasperReportType.PDF);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
            file = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Fahes Transactions.pdf").stream(() -> is).build();
        }

        if(selectedItem.equals(FAHES_BOOKING)) {

            List<ReservationResource> listReservation = resevationService.getPaginatedList(uriParams).getList();
            for (ReservationResource reservationResource : listReservation) {
                reservationResource.setQid(BoUtils.decodeFromBase64(reservationResource.getQid()));
            }

            String base64 = GenerateJasperReport.generateReport(listReservation, "booking/bookings.jrxml", "Booking List", JasperReportType.PDF);
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
            file = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Booking List.pdf").stream(() -> is).build();
        }
    }

    public void exportExcel() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateExportReport(surveyService.surveys(uriParams), transactionLogResources, userResources, prTransactionLogResources, JasperReportType.EXCEL, selectedValuesInit);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileExcel = DefaultStreamedContent.builder().contentType(CONTENT_TYPE).name("Reporting.xlsx").stream(() -> is).build();
    }

    public Boolean checkDates() {
        return reportResource.getStartDate().compareTo(reportResource.getEndDate()) <= 0;
    }

    private void getWoqodTransactionParms() {
        uriParams = new HashMap<>();
        if (reportResource.getQid() != null && !reportResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(reportResource.getQid().trim().getBytes()));

        }

        if (reportResource.getTransactionUUID() != null && !reportResource.getTransactionUUID().isEmpty()) {
            uriParams.put("transactionUUID", reportResource.getTransactionUUID().trim());
        }

        if (reportResource.getTransactionID() != null && !reportResource.getTransactionID().isEmpty()) {
            uriParams.put("transactionID", reportResource.getTransactionID().trim());
        }

        if (reportResource.getReferenceNumber() != null && !reportResource.getReferenceNumber().isEmpty()) {
            uriParams.put("referenceNumber", reportResource.getReferenceNumber().trim());
        }

        if (rpsStatus != null && !rpsStatus.isEmpty()) {
            uriParams.put("rpsStatus", rpsStatus.trim());
        }

        if (transactionStatus != null && !transactionStatus.isEmpty()) {
            uriParams.put("transactionStatus", transactionStatus);
        }
        this.getUriParams(uriParams);
        ((WoqodeLazyModel) lazyModel).setSearch(uriParams);
    }

    private void getFahesTransactionParams () {

        uriParams = new HashMap<>();
        if (reportResource.getTransactionUUID() != null && !reportResource.getTransactionUUID().isEmpty()) {
            uriParams.put("transactionUUID", reportResource.getTransactionUUID().trim());
        }
        if (reportResource.getReferenceNumber() != null && !reportResource.getReferenceNumber().isEmpty()) {
            uriParams.put("referenceNumber", reportResource.getReferenceNumber().trim());
        }
        if (transactionStatus != null && !transactionStatus.isEmpty()) {
            uriParams.put("transactionStatus", transactionStatus);
        }
        if (reportResource.getQid() != null && !reportResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(reportResource.getQid().trim().getBytes()));

        }
        if (reportResource.getTransactionID() != null && !reportResource.getTransactionID().isEmpty()) {
            uriParams.put("transactionID", reportResource.getTransactionID().trim());
        }
        if (apiStatus != null && !apiStatus.isEmpty()) {
            uriParams.put("apiStatus", apiStatus.trim());
        }
        if (reportResource.getPlateNumber() != null && !reportResource.getPlateNumber().isEmpty()) {
            uriParams.put("plateNumber", reportResource.getPlateNumber().trim());
        }
        this.getUriParams(uriParams);

        ((FahesLazyModel) lazyModelFahes).setSearch(uriParams);
    }

    public void getUriParams( Map<String, String> uriParams) {
        if (reportResource.getPhone() != null && !reportResource.getPhone().isEmpty()) {
            uriParams.put(MOBILE, reportResource.getPhone().trim());
        }

        if (reportResource.getStartDate() != null) {
            uriParams.put(START_DATE, DateFormatter.localDateToStringDate(reportResource.getStartDate()));
        }
        if (reportResource.getEndDate() != null) {
            uriParams.put(END_DATE, DateFormatter.localDateToStringDate(reportResource.getEndDate()));
        }
    }

    private void getUserParams() {
        uriParams = new HashMap<>();
        if (reportResource.getQid() != null && !reportResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(reportResource.getQid().trim().getBytes()));
        }

        if (reportResource.getEmail() != null && !reportResource.getEmail().isEmpty()) {
            if (!EmailValidator.getInstance().isValid(reportResource.getEmail())) {
                BoUtils.showErrorPopup("Email format not valid", "");
                return;
            }
            uriParams.put("email", reportResource.getEmail().trim());
        }

        if (reportResource.getPhone() != null && !reportResource.getPhone().isEmpty()) {
            uriParams.put(MOBILE, reportResource.getPhone().trim());
        }

        if (reportResource.getUsername() != null && !reportResource.getUsername().isEmpty()) {
            uriParams.put("username", reportResource.getUsername().trim());
        }
        if (userStatus != null && !userStatus.isEmpty()) {
            uriParams.put("status", userStatus.trim());
        }
        if (reportResource.getStartDate() != null) {
            uriParams.put(START_DATE, DateFormatter.localDateToStringDate(reportResource.getStartDate()));
        }
        if (reportResource.getEndDate() != null) {
            uriParams.put(END_DATE, DateFormatter.localDateToStringDate(reportResource.getEndDate()));
        }
        uriParams.put("isWoqodeUser", String.valueOf(reportResource.getIsWoqodeUser()));

        ((UsersLazyModel) lazyModelUser).setLazyModelParams(uriParams);
        ((UsersLazyModel) lazyModelUser).setSearch(true);
    }

    private void getSurveyParams() {
        uriParams = new HashMap<>();
        if (reportResource.getStartDate() != null) {
            uriParams.put(START_DATE, DateFormatter.localDateToStringDate(reportResource.getStartDate()));
        }
        if (reportResource.getEndDate() != null) {
            uriParams.put(END_DATE, DateFormatter.localDateToStringDate(reportResource.getEndDate()));
        }
        if (reportResource.getCreationDate() != null) {
            uriParams.put("creationDate", DateFormatter.localDateToStringDate(reportResource.getCreationDate()));
        }
        if (reportResource.getSurveyTitle() != null && !reportResource.getSurveyTitle().isEmpty()) {
            uriParams.put("title", reportResource.getSurveyTitle().trim());
        }
        if (surveyStatus != null && !surveyStatus.isEmpty()) {
            uriParams.put("type", surveyStatus.trim());
        }
        ((SurveyLazyModels) lazyModelSurvey).setLazyModelParams(uriParams);
    }

    private void getFahesBookingParams(){
        uriParams = new HashMap<>();

        if (reportResource.getQid() != null && !reportResource.getQid().isEmpty()) {
            uriParams.put("qid", Base64.getEncoder().encodeToString(reportResource.getQid().trim().getBytes()));
        }
        if (reportResource.getPhone() != null && !reportResource.getPhone().isEmpty()) {
            uriParams.put("mobileNumber", reportResource.getPhone().trim());
        }
        if (reportResource.getPlateNumber() != null && !reportResource.getPlateNumber().isEmpty()) {
            uriParams.put("licencePlate", reportResource.getPlateNumber().trim());
        }
        if (fahesBookingStatus != null && !fahesBookingStatus.isEmpty()) {
            uriParams.put("status", fahesBookingStatus.trim());
        }
        ((ReservationLazyModels) lazyModelFahesBooking).setLazyModelParams(uriParams);
    }

    public void update() {
        switch (selectedItem) {
            case SURVEY:
                lazyModelSurvey = new SurveyLazyModels(surveyService, uriParams);
                break;
            case USERS_MANAGEMENT:
                lazyModelUser = new UsersLazyModel(userService, uriParams);
                break;
            case WOQODE_TRANSACTION:
                lazyModel = new WoqodeLazyModel(transactionLogService, uriParams);
                break;
            case FAHES_TRANSACTION:
                lazyModelFahes = new FahesLazyModel(prTransactionService, uriParams);
                break;
            case FAHES_BOOKING:
                lazyModelFahesBooking = new ReservationLazyModels(resevationService, uriParams);
                break;
        }
    }

    public int calculateResponses(SurveysResource surveyResource) {
        if (surveyResource.getSurveysResponses() == null) {
            return 0;
        } else {
            return surveyResource.getSurveysResponses().size();
        }
    }

    public static TransactionStatusEnum[] getTransactionStatusEnums() {
        return TransactionStatusEnum.values();
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            return new String(Base64.getDecoder().decode(qid));
        } else {
            return qid;
        }
    }
}
