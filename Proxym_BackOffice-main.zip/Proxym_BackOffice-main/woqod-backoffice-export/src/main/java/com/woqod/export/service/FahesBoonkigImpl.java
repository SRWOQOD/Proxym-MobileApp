package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.export.rest.FahesBookingRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.reservation.ReservationResource;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class FahesBoonkigImpl implements ReservationService{

    private final FahesBookingRestClient fahesBookingRestClient;

    public FahesBoonkigImpl(FahesBookingRestClient fahesBookingRestClient) {
        this.fahesBookingRestClient = fahesBookingRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedList(Map<String, String> uriParams) {
        return fahesBookingRestClient.paginatedParams(uriParams);
    }

    @Override
    public List<ReservationResource> getReservations(Map<String, String> uriParams) {
        return fahesBookingRestClient.getReservations(uriParams);
    }

}
