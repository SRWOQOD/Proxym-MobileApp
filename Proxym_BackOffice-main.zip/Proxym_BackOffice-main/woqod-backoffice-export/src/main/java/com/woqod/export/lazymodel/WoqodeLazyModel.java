package com.woqod.export.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.export.service.TransactionLogService;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.TransactionLogResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */

@Slf4j
public class WoqodeLazyModel extends LazyDataModel<TransactionLogResource> {
    private static final long serialVersionUID = 1;
    private final transient TransactionLogService topUpService;

    private Map<String, String> search;

    public WoqodeLazyModel(TransactionLogService topUpService, Map<String, String> search) {
        this.topUpService = topUpService;
        this.search = search;
    }


    @Override
    public Object getRowKey(TransactionLogResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }

    @Override
    public List<TransactionLogResource> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                             Map<String, FilterMeta> filters) {
        search.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

        try {
            PaginatedListResponse<TransactionLogResource> response;
            response = topUpService.getPaginatedTopUP(search);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();
        } catch (Exception e) {
            log.error(e.getMessage());
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return new ArrayList<>();
        }
    }

    public void setSearch(Map<String, String> search) {
        this.search = search;
    }

    public Map<String, String> getSearch() {
        return search;
    }
}