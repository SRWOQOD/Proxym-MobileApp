package com.woqod.export.service;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.SurveysResource;

import java.util.List;
import java.util.Map;

public interface SurveyService {

    PaginatedListResponse<SurveysResource> getPaginatedSurvey(Map<String, String> uriParams);

    List<SurveysResource> surveys(Map<String, String> uriParams);

}
