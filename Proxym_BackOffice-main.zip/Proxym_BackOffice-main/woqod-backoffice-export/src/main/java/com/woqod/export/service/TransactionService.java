package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.List;
import java.util.Map;

public interface TransactionService {

    PaginatedListResponse<PRTransactionLogResource> getPaginatedTransactions(Map<String, String> uriParams);

    List<PRTransactionLogResource> transactions(Map<String, String> uriParams);

}
