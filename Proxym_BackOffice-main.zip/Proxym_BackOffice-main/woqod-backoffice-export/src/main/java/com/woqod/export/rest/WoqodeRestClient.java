package com.woqod.export.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.TransactionLogResource;

import java.util.List;
import java.util.Map;

@Component
@Slf4j
@PropertySource("classpath:properties/export.properties")
public class WoqodeRestClient {

    private final CustomRestTemplate topUpRestTemplate = new CustomRestTemplate();
    @Autowired
    private BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.topUp.paginated}")
    private String paginatedList;


    public PaginatedListResponse<TransactionLogResource> paginatedListTransactions(Map<String, String> uriParams) {
        log.debug("[TopUpRestClient] paginatedListTransactions");
        String uri = paginatedList;
        return (PaginatedListResponse<TransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<TransactionLogResource>>>() {
                        });

    }


    public List<TransactionLogResource> getAllTransactions(Map<String, String> uriParams) {
        String uri = "transactionLog/all";
        return ((ListResponse<TransactionLogResource>) topUpRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<TransactionLogResource>>>() {
                        })).getList();

    }
}
