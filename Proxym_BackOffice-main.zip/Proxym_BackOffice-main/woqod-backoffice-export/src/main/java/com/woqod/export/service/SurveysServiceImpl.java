package com.woqod.export.service;


import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.export.rest.SurveysRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.SurveysResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SurveysServiceImpl implements SurveyService {

    private final SurveysRestClient surveysRestClient;

    public SurveysServiceImpl(SurveysRestClient surveysRestClient) {
        this.surveysRestClient = surveysRestClient;
    }

    @Override
    public PaginatedListResponse<SurveysResource> getPaginatedSurvey(Map<String, String> uriParams) {
        return surveysRestClient.paginatedParams(uriParams);
    }

    @Override
    public List<SurveysResource> surveys(Map<String, String> uriParams) {
        return surveysRestClient.getAllSurveys(uriParams);
    }


}
