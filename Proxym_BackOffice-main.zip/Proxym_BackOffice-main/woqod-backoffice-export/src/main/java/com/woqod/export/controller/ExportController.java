package com.woqod.export.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.export.constant.ExportConstant;
import com.woqod.export.enums.MenuEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Data
@Slf4j
@Controller
@RequestMapping(value = ExportConstant.EXPORT_MANAGEMENT_URL)
public class ExportController {
    private final Permissions permissions;

    @Autowired
    public ExportController(Permissions permissions) {
        this.permissions = permissions;
    }

    @GetMapping("")
    public ModelAndView display() {
        return permissions.getModelAndView(MenuEnum.DISPLAY_EXPORT.name(), ExportConstant.EXPORT_LIST);

    }
}
