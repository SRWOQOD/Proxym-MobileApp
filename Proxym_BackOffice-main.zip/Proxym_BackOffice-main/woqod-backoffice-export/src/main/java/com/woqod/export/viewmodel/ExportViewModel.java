package com.woqod.export.viewmodel;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.*;
import com.woqod.export.constant.ExportConstant;
import com.woqod.export.lazymodel.FahesLazyModel;
import com.woqod.export.lazymodel.SurveyLazyModels;
import com.woqod.export.lazymodel.UsersLazyModel;
import com.woqod.export.lazymodel.WoqodeLazyModel;
import com.woqod.export.service.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.TransactionLogResource;
import wq.woqod.resources.resources.UserResource;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
public class ExportViewModel {

    private static final String ERROR = "Error";
    /*
    Beans
     */
    private final ExportService exportService;
    private DataFactory dataFactory;
    private final TransactionLogService transactionLogService;
    private final UserService userService;
    private final SurveyService surveyService;
    private final TransactionService prTransactionService;

    /*
    state
     */
    List<ReportEnum> enumValues;
    List<ReportEnum> selectedValues;
    ReportEnum selectedValue;
    private List<TransactionLogResource> transactionLogResources = new ArrayList<>();
    private List<SurveysResource> surveysResources = new ArrayList<>();
    private List<UserResource> userResources = new ArrayList<>();
    private List<PRTransactionLogResource> prTransactionLogResources = new ArrayList<>();
    private String selectedItem;
    private ReportResource reportResource = new ReportResource();
    private String reportString = "";
    private StreamedContent file;
    private StreamedContent fileCSV;
    private StreamedContent fileExcel;
    private LazyDataModel<TransactionLogResource> lazyModel;
    private LazyDataModel<UserResource> lazyModelUser;
    private LazyDataModel<SurveysResource> lazyModelSurvey;
    private LazyDataModel<PRTransactionLogResource> lazyModelFahes;
    private static String contentType = "text/plain";
    private Map<String, String> uriParams;
    private Boolean errorResponse = false;
    private String errorMsg;

    @Autowired
    public ExportViewModel(ExportService exportService, TransactionLogService transactionLogService, UserService userService, SurveyService surveyService, TransactionService prTransactionService) {
        this.exportService = exportService;
        this.transactionLogService = transactionLogService;
        this.userService = userService;
        this.surveyService = surveyService;
        this.prTransactionService = prTransactionService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        init();
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        reportResource = new ReportResource();
        selectedValues = Arrays.asList(ReportEnum.values());
        log.debug("{} init", ExportConstant.EXPORT_VIEW_MODEL);
        enumValues = Arrays.asList(ReportEnum.values());
    }


    public void next() {
        if (selectedValues.isEmpty()) {
            BoUtils.showErrorPopup(ERROR, "Please select at least one service");
            errorResponse = true;
        }
        if (!getParms()) return;
        if (reportResource.getStartDate() != null && reportResource.getEndDate() != null && BooleanUtils.isFalse(checkDates())) {
            BoUtils.showErrorPopup(ERROR, "Start date must be smaller then end date");
        }
        if ((reportResource.getQid() == null || reportResource.getQid().isEmpty()) &&
                (reportResource.getPhone() == null || reportResource.getPhone().isEmpty()) &&
                (reportResource.getTransactionUUID() == null || reportResource.getTransactionUUID().isEmpty()) &&
                (reportResource.getRequestId() == null || reportResource.getRequestId().isEmpty()) &&
                (reportResource.getEndDate() == null) &&
                (reportResource.getStartDate() == null)) {
            BoUtils.showErrorPopup(ERROR, "Please select at least one filter option");
        }
        update();
        reportString = "";
        reportString = ReportUtils.getExportString(selectedValues);
    }

    public void clear() {
        log.debug("{} clear", ExportConstant.EXPORT_VIEW_MODEL);
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateExportReport(surveysResources, transactionLogResources, userResources, prTransactionLogResources, JasperReportType.CSV, selectedValues);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType(contentType).name("Reporting.csv").stream(() -> is).build();
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateExportReport(surveysResources, transactionLogResources, userResources, prTransactionLogResources, JasperReportType.PDF, selectedValues);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType(contentType).name("Reporting.pdf").stream(() -> is).build();


    }

    public void exportExcel() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateExportReport(surveysResources, transactionLogResources, userResources, prTransactionLogResources, JasperReportType.EXCEL, selectedValues);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileExcel = DefaultStreamedContent.builder().contentType(contentType).name("Reporting.xlsx").stream(() -> is).build();


    }

    public Boolean checkDates() {
        return reportResource.getStartDate().compareTo(reportResource.getEndDate()) <= 0;
    }

    public boolean getParms() {
        uriParams = new HashMap<>();
        if (reportResource.getQid() != null && !reportResource.getQid().isEmpty()) {
            uriParams.put("qid", reportResource.getQid().trim());
            return true;
        }

        if (reportResource.getTransactionUUID() != null && !reportResource.getTransactionUUID().isEmpty()) {
            uriParams.put("transactionUUID", reportResource.getQid().trim());
            return true;
        }

        if (reportResource.getRequestId() != null && !reportResource.getRequestId().isEmpty()) {
            uriParams.put("transactionID", reportResource.getQid().trim());
            return true;
        }

        if (reportResource.getPhone() != null && !reportResource.getPhone().isEmpty()) {
            uriParams.put("mobile", reportResource.getPhone().trim());
            return true;
        }

        if (reportResource.getStartDate() != null) {
            uriParams.put("startDate", DateFormatter.localDateToStringDate(reportResource.getStartDate()));
            return true;
        }
        if (reportResource.getEndDate() != null) {
            uriParams.put("endDate", DateFormatter.localDateToStringDate(reportResource.getEndDate()));
            return true;
        }
        return false;
    }

    public void update() {
        if (BooleanUtils.isTrue(ReportUtils.ifItemSelected(selectedValues, "Survey"))) {
            lazyModelSurvey = new SurveyLazyModels(surveyService, uriParams);
            surveysResources = surveyService.surveys(uriParams);
        } else {
            surveysResources = new ArrayList<>();
        }
        if (BooleanUtils.isTrue(ReportUtils.ifItemSelected(selectedValues, "Users Management"))) {
            lazyModelUser = new UsersLazyModel(userService, uriParams);
            userResources = userService.getUsers(uriParams);
        } else {
            userResources = new ArrayList<>();
        }
        if (BooleanUtils.isTrue(ReportUtils.ifItemSelected(selectedValues, "WOQODe Transaction"))) {
            lazyModel = new WoqodeLazyModel(transactionLogService, uriParams);
            transactionLogResources = transactionLogService.transactions(uriParams);
        } else {
            transactionLogResources = new ArrayList<>();
        }

        if (BooleanUtils.isTrue(ReportUtils.ifItemSelected(selectedValues, "FAHES Transactions"))) {
            lazyModelFahes = new FahesLazyModel(prTransactionService, uriParams);
            prTransactionLogResources = prTransactionService.transactions(uriParams);
        } else {
            prTransactionLogResources = new ArrayList<>();
        }
    }
}
