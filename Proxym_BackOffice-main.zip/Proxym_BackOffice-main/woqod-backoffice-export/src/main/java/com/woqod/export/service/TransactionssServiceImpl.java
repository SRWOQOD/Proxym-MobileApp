package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.export.rest.FahesTranRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.PRTransactionLogResource;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class TransactionssServiceImpl implements TransactionService {

    private final FahesTranRestClient fahesTranRestClient;

    public TransactionssServiceImpl(FahesTranRestClient fahesTranRestClient) {
        this.fahesTranRestClient = fahesTranRestClient;
    }

    @Override
    public PaginatedListResponse getPaginatedTransactions(Map<String, String> uriParams) {
        return fahesTranRestClient.paginatedListTransactions(uriParams);
    }

    @Override
    public List<PRTransactionLogResource> transactions(Map<String, String> uriParams) {
        return fahesTranRestClient.getTransactions(uriParams);
    }
}
