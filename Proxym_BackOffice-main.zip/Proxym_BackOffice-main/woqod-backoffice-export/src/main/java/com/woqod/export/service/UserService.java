package com.woqod.export.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.UserResource;

import java.util.List;
import java.util.Map;

public interface UserService {

    PaginatedListResponse<UserResource> getPaginatedUser(Map<String, String> uriParams);

    List<UserResource> getUsers(Map<String, String> uriParams);

}
