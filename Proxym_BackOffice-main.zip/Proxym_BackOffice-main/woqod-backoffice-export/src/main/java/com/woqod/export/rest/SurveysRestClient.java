package com.woqod.export.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.SurveysResource;

import java.util.List;
import java.util.Map;

@Data
@Slf4j
@Component
@PropertySource("classpath:properties/export.properties")
public class SurveysRestClient {
    /**
     * Beans
     */
    private final CustomRestTemplate customRestTemplate;
    private final BaseUrlProvider baseUrlProvider;

    /*
     external config attributes

     */
    private String survey;
    private String publishToUsersUri;

    @Autowired
    public SurveysRestClient(CustomRestTemplate customRestTemplate, BaseUrlProvider baseUrlProvider, @Value("${uri.ws.survey}") String survey, @Value("${uri.ws.publishToUsersUri}") String publishToUsersUri) {
        this.customRestTemplate = customRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
        this.survey = survey;
        this.publishToUsersUri = publishToUsersUri;
    }


    /**
     * used to get parameters paginated and filtered
     */
    public PaginatedListResponse<SurveysResource> paginatedParams(Map<String, String> uriParams) {
        String uri = survey.concat("/filtered");
        return (PaginatedListResponse<SurveysResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<SurveysResource>>>() {
                        });

    }

    public List<SurveysResource> getAllSurveys(Map<String, String> uriParams) {
        String uri = survey.concat("/all");
        return ((ListResponse<SurveysResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<SurveysResource>>>() {
                        })).getList();

    }

}
