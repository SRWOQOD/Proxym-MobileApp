package com.woqod.export.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.export.service.TransactionService;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.PRTransactionLogResource;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class FahesLazyModel extends LazyDataModel<PRTransactionLogResource> {
    private static final long serialVersionUID = 1;
    private final transient TransactionService iTransactionService;
    private Map<String, String> search;

    public FahesLazyModel(TransactionService iTransactionService, Map<String, String> search) {
        this.iTransactionService = iTransactionService;
        this.search = search;
    }


    @Override
    public Object getRowKey(final PRTransactionLogResource object) {
        return object.getId();
    }

    @Override
    public void setRowIndex(final int rowIndex) {
        if (rowIndex == -1 || this.getPageSize() == 0) {
            super.setRowIndex(-1);
        } else {
            super.setRowIndex(rowIndex % this.getPageSize());
        }
    }

    @Override
    public List<PRTransactionLogResource> load(final int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        search.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

        try {
            final PaginatedListResponse<PRTransactionLogResource> response = this.iTransactionService.getPaginatedTransactions(this.search);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();
        } catch (Exception e) {
            log.error(e.getMessage());
            final FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Server Error", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return new ArrayList<>();
        }
    }

    public void setSearch(final Map<String, String> search) {
        this.search = search;
    }
}
