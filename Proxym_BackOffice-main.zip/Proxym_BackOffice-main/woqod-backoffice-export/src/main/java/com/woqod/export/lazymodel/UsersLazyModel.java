package com.woqod.export.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.export.service.UserService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.UserResource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Data
@Slf4j
public class UsersLazyModel extends LazyDataModel<UserResource> {

    private final transient UserService userService;
    private static final long serialVersionUID = 1;

    private Map<String, String> uriParams;

    private transient List<UserResource> data = new ArrayList<>();

    private Boolean search = false;
    private Boolean selection = false;

    public UsersLazyModel(UserService userService, Map<String, String> uriParams) {
        this.userService = userService;
        this.uriParams = uriParams;
    }

    @Override
    public UserResource getRowData(String rowKey) {
        Optional<UserResource> userResourceOptional = data.stream().filter(r -> r.getId().equals(Long.parseLong(rowKey))).findFirst();
        return userResourceOptional.orElse(null);
    }

    public void setLazyModelParams(Map<String, String> uriParams) {
        this.uriParams = uriParams;
    }

    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));

    }


    @Override
    public List<UserResource> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                                   Map<String, FilterMeta> filters) {

        try {
            if (search && selection) {
                first = 0;
            }
            this.data.clear();
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, first, pageSize));
            PaginatedListResponse<UserResource> response = userService.getPaginatedUser(uriParams);
            this.data.addAll(response.getList());
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();

        } catch (Exception e) {
            log.error(e.getMessage());
            return new ArrayList<>();
        }

    }
}