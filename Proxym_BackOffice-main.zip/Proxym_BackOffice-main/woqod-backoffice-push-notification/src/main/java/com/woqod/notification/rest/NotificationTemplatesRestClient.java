package com.woqod.notification.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.BooleanResponse;
import com.woqod.bo.commons.response.body.ListResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.notifications.NotificationLogResource;
import wq.woqod.resources.resources.notifications.SendDeviceNotificationResource;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@PropertySource("classpath:properties/notif.properties")
public class NotificationTemplatesRestClient {
    /**
     * Beans
     */

    private final BaseUrlProvider baseUrlProvider;
    private final CustomRestTemplate customRestTemplate;

    /*
     external config attributes
     */
    @Value("${uri.ws.filter}")
    private String filter;

    @Value("${uri.ws.filterLogs}")
    private String filterLogsUrl;


    @Value("${uri.ws.save}")
    private String save;

    @Value("${uri.ws.update}")
    private String update;

    @Value("${uri.ws.delete}")
    private String delete;

    @Value("${uri.ws.deleteLogs}")
    private String deleteLogs;

    @Value("${uri.ws.findById}")
    private String findById;

    @Value("${uri.ws.sendNotificationTemplate}")
    private String sendNotificationTemplate;

    private String count;

    private String countNotification;

    public NotificationTemplatesRestClient(BaseUrlProvider baseUrlProvider, CustomRestTemplate customRestTemplate, @Value("${uri.ws.count.notification}") String count, @Value("${uri.ws.count.notification.report}") String countNotification) {
        this.baseUrlProvider = baseUrlProvider;
        this.customRestTemplate = customRestTemplate;
        this.count = count;
        this.countNotification = countNotification;
    }

    public PaginatedListResponse<NotificationTemplateRessource> filter(Map<String, String> uriParams) {
        return ((PaginatedListResponse<NotificationTemplateRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(filter, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<NotificationTemplateRessource>>>() {
                        }));
    }

    public PaginatedListResponse<NotificationLogResource> filterLogs(Map<String, String> uriParams) {
        return ((PaginatedListResponse<NotificationLogResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(filterLogsUrl, uriParams),
                        new ParameterizedTypeReference<GenericResponse<PaginatedListResponse<NotificationLogResource>>>() {
                        }));
    }


    public Boolean save(NotificationTemplateRessource notificationTemplateRessource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(save), notificationTemplateRessource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public Boolean update(NotificationTemplateRessource notificationTemplateRessource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .putObjectGetGenericResponseBody(baseUrlProvider.getUrl(update), notificationTemplateRessource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public Boolean delete(String id) {
        String uri = delete + "?id=" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public NotificationTemplateRessource findById(String id) {
        String uri = findById.concat("?id=").concat(id);
        ObjectResponse<NotificationTemplateRessource> response = (ObjectResponse<NotificationTemplateRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<NotificationTemplateRessource>>>() {
                        });
        return response.getObject();
    }


    public Boolean sendNotification(SendDeviceNotificationResource usersAndNotificationTemplateRessource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(sendNotificationTemplate), usersAndNotificationTemplateRessource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public Boolean sendNotificationToWoqode(SendDeviceNotificationResource usersAndNotificationTemplateRessource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(sendNotificationTemplate), usersAndNotificationTemplateRessource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();

    }
    public Boolean sendNotificationToAll(SendDeviceNotificationResource usersAndNotificationTemplateRessource) {
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .postObjectGetGenericResponseBody(baseUrlProvider.getUrl(sendNotificationTemplate), usersAndNotificationTemplateRessource,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();

    }

    public Boolean deleteNotification(String id) {
        String uri = deleteLogs + "?id=" + id;
        BooleanResponse response = (BooleanResponse) customRestTemplate
                .deleteObjectGetGenericResponseBody(baseUrlProvider.getUrl(uri), null,
                        new ParameterizedTypeReference<GenericResponse<BooleanResponse>>() {
                        });
        return response.isSuccess();
    }

    public List<NotificationLogResource> notificationLogs(Map<String, String> uriParams) {
        String uri = "/notification/notificationLogs";
        ListResponse<NotificationLogResource> listResponse = (ListResponse<NotificationLogResource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<NotificationLogResource>>>() {
                        });
        return listResponse.getList();
    }

    public List<NotificationTemplateRessource> getAllNotifications(Map<String, String> uriParams) {
        String uri = "/notification/template";
        ListResponse<NotificationTemplateRessource> listResponse = (ListResponse<NotificationTemplateRessource>) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, uriParams),
                        new ParameterizedTypeReference<GenericResponse<ListResponse<NotificationTemplateRessource>>>() {
                        });
        return listResponse.getList();
    }

    public Integer count() {
        String uri = count;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }

    public Integer countNotificationReports() {
        String uri = countNotification;
        ObjectResponse<Integer> response = (ObjectResponse) customRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<Integer>>>() {
                        });
        return response.getObject();
    }
}
