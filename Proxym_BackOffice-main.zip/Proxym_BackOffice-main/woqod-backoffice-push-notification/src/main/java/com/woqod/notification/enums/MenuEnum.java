package com.woqod.notification.enums;

import com.woqod.bo.commons.enums.*;

import java.util.Arrays;
import java.util.Optional;

import static com.woqod.notification.constant.PushConstant.*;

public enum MenuEnum implements Menu {
    DISPLAY_PN_TEMPLATE(new Bundle(BUNDLE_NAME, "DisplayTemplates"), PUSH_URL + TEMPLATE_URL, "", "", true, ParentModuleEnum.PUSH_NOTIF_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    DISPLAY_ADD_TEMPLATE(new Bundle(BUNDLE_NAME, "AddTemplateNotif"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 1L)),
    DISPLAY_EDIT_TEMPLATE(new Bundle(BUNDLE_NAME, "EditTemplateNotif"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 2L)),
    DISPLAY_USERS_TEMPLATE(new Bundle(BUNDLE_NAME, "users"), PUSH_URL + NOTIF_USER_URL, "", "", true, ParentModuleEnum.PUSH_NOTIF_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),
    DISPLAY_REPORT_TEMPLATE(new Bundle(BUNDLE_NAME, "report"), PUSH_URL + NOTIF_REPORT_URL, "", "", true, ParentModuleEnum.PUSH_NOTIF_MANAGEMENT.name(), new MenuPosition(ModuleLevel.FIRST.name(), 1L)),


    ADD_TEMPLATE(new Bundle(BUNDLE_NAME, "addNewTemplate"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 3L)),
    EDIT_TEMPLATE(new Bundle(BUNDLE_NAME, "EditTemplateNotif"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 4L)),
    SEND_NOTIFICATION(new Bundle(BUNDLE_NAME, "sendTemplate"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 5L)),
    DELETE_TEMPLATE(new Bundle(BUNDLE_NAME, "deleteTemplate"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 6L)),
    DELETE_NOTIFICATION(new Bundle(BUNDLE_NAME, "deleteNotif"), "", "", "", true, DISPLAY_PN_TEMPLATE.name(), new MenuPosition(ModuleLevel.SECOND.name(), 7L));

    MenuEnum(Bundle bundle, String path, String icon, String htmlId, Boolean enabled, String parent, MenuPosition menuPosition) {
        this.bundle = bundle;
        this.path = path;
        this.icon = icon;
        this.htmlId = htmlId;
        this.enabled = enabled;
        this.parent = parent;
        this.menuPosition = menuPosition;
    }

    /**
     * Position config
     */
    private transient MenuPosition menuPosition;
    /**
     * Bundle config
     */

    private transient Bundle bundle;
    /**
     * the feature path
     */
    private String path;

    /**
     * used in html to define html
     */
    private String icon;

    /**
     * used in html to define id of submenu
     */
    private String htmlId;


    /**
     * sync this module in DB yes or no
     */
    private Boolean enabled;

    /**
     * used to define feature parent
     */
    private String parent;


    @Override
    public String getName(String bundleName, String bundleKey) {
        Optional<MenuEnum> menu = Arrays.asList(MenuEnum.values()).stream().filter(item -> item.getBundle().getBundleName().equals(bundleName) && item.getBundle().getBundleKey().equals(bundleKey)).findFirst();
        return (menu.isPresent() ? menu.get().name() : "");
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getHtmlId() {
        return htmlId;
    }


    @Override
    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Bundle getBundle() {
        return bundle;
    }

    @Override
    public MenuPosition getMenuPosition() {
        return menuPosition;
    }

    @Override
    public String getParent() {
        return parent;
    }


}
