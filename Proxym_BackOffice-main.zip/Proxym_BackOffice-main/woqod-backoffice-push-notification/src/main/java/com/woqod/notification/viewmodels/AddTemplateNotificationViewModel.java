package com.woqod.notification.viewmodels;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.notification.enums.MenuEnum;
import com.woqod.notification.service.NotificationTemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.NotificationTemplateRessource;

import javax.faces.context.FacesContext;
import java.util.HashMap;

import static com.woqod.notification.constant.PushConstant.PUSH_URL;
import static com.woqod.notification.constant.PushConstant.TEMPLATE_URL;

@Data
@Slf4j
@Component
@Scope("view")
public class AddTemplateNotificationViewModel {


    private final NotificationTemplateService notificationTemplateService;
    private final DataFactory dataFactory;

    private NotificationTemplateRessource notificationTemplateRessource;

    public AddTemplateNotificationViewModel(NotificationTemplateService notificationTemplateService, DataFactory dataFactory) {
        this.notificationTemplateService = notificationTemplateService;
        this.dataFactory = dataFactory;
    }

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    public void init() {
        notificationTemplateRessource = new NotificationTemplateRessource();

    }

    public String getDisplayAddPnTemplateFeature() {
        return MenuEnum.DISPLAY_ADD_TEMPLATE.name();
    }


    public String getAbortPage() {
        return PUSH_URL.substring(1) + TEMPLATE_URL;
    }

    public void save() {

        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.ADD_TEMPLATE.name());
        serviceData.put(UtilsConstants.POST_DATA, notificationTemplateRessource);
        try {
            notificationTemplateService.save(serviceData);
            BoUtils.showsuccesspopup();
            dataFactory.redirect("notification/templates");

        } catch (
                RestBackendException e) {
            if (e.getCode().equals("158")) {
                BoUtils.showErrorPopup("Template", "Template with this title already exist!");
            } else if (e.getCode().equals("103")) {
                BoUtils.showErrorPopup("Template", "Template contents are missing");
            } else {
                BoUtils.showErrorPopup("Error ", "An error has occurred , please try later");

            }
        }
    }


}
