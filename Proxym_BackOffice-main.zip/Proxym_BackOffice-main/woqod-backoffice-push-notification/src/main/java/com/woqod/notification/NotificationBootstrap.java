package com.woqod.notification;

import com.woqod.bo.commons.MenuLoader;
import com.woqod.bo.commons.enums.ParentModuleEnum;
import com.woqod.bo.commons.model.ListMenu;
import com.woqod.notification.enums.MenuEnum;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;

@Component
public class NotificationBootstrap {
    @PostConstruct
    public void init() {
        MenuLoader.getMenuHashMap().put(ParentModuleEnum.PUSH_NOTIF_MANAGEMENT.name(), ListMenu.builder().menus((List) Arrays.asList(MenuEnum.values())).build());
    }
}
