package com.woqod.notification.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.step.StepExecutor;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.notification.rest.NotificationTemplatesRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.notifications.NotificationLogResource;
import wq.woqod.resources.resources.notifications.SendDeviceNotificationResource;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class NotificationTemplateServiceImpl implements NotificationTemplateService {

    private final NotificationTemplatesRestClient notificationTemplatesRestClient;

    public NotificationTemplateServiceImpl(NotificationTemplatesRestClient notificationTemplatesRestClient) {
        this.notificationTemplatesRestClient = notificationTemplatesRestClient;
    }

    @Override
    public PaginatedListResponse<NotificationTemplateRessource> filter(Map<String, String> uriParams) {
        return notificationTemplatesRestClient.filter(uriParams);
    }

    @Override
    public PaginatedListResponse<NotificationLogResource> filterLogs(Map<String, String> uriParams) {
        return notificationTemplatesRestClient.filterLogs(uriParams);
    }

    @Override
    //@StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public void save(Map<String, Object> serviceData) {
        NotificationTemplateRessource notificationTemplateRessource = (NotificationTemplateRessource) serviceData.get(UtilsConstants.POST_DATA);
        notificationTemplatesRestClient.save(notificationTemplateRessource);
    }

    @Override
//    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public Boolean update(Map<String, Object> serviceData) {
        NotificationTemplateRessource notificationTemplateRessource = (NotificationTemplateRessource) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.update(notificationTemplateRessource);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public Boolean deleteNotification(Map<String, Object> serviceData) {
        String id = (String) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.deleteNotification(id);
    }

    @Override
    @StepExecutor(redirect = false, redirectTo = "", saveLog = true)
    public Boolean delete(Map<String, Object> serviceData) {
        String id = (String) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.delete(id);
    }

    @Override
    public NotificationTemplateRessource findById(String id) {
        return notificationTemplatesRestClient.findById(id);
    }


    @Override
    public List<NotificationLogResource> notificationLogs(Map<String, String> uriParams) {
        return notificationTemplatesRestClient.notificationLogs(uriParams);
    }

    @Override
    public List<NotificationTemplateRessource> notifications(Map<String, String> uriParams) {
        return notificationTemplatesRestClient.getAllNotifications(uriParams);
    }

    @Override
    public Boolean sendNotification(Map<String, Object> serviceData) {
        SendDeviceNotificationResource usersAndNotificationTemplateRessource = (SendDeviceNotificationResource) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.sendNotification(usersAndNotificationTemplateRessource);
    }


    @Override
    public Boolean sendNotificationToAll(Map<String, Object> serviceData) {
        SendDeviceNotificationResource usersAndNotificationTemplateRessource = (SendDeviceNotificationResource) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.sendNotificationToAll(usersAndNotificationTemplateRessource);
    }

    @Override
    public Boolean sendNotificationToWoqode(Map<String, Object> serviceData) {
        SendDeviceNotificationResource usersAndNotificationTemplateRessource = (SendDeviceNotificationResource) serviceData.get(UtilsConstants.POST_DATA);
        return notificationTemplatesRestClient.sendNotificationToWoqode(usersAndNotificationTemplateRessource);

    }

    @Override
    public Integer count() {
        return notificationTemplatesRestClient.count();
    }


    @Override
    public Integer countNotificationReports() {
        return notificationTemplatesRestClient.countNotificationReports();
    }
}
