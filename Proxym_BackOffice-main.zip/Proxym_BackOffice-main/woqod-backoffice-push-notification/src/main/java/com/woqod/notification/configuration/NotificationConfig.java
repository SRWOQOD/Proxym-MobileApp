package com.woqod.notification.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.woqod.notification"})
public class NotificationConfig {
}
