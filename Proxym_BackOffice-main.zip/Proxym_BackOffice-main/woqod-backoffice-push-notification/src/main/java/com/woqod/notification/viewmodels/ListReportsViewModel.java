package com.woqod.notification.viewmodels;

import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.notification.enums.MenuEnum;
import com.woqod.notification.lazymodel.NotificationLogLazyModel;
import com.woqod.notification.service.NotificationTemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.notifications.NotificationLogResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static com.woqod.notification.constant.PushConstant.NOTIF_USER_URL;
import static com.woqod.notification.constant.PushConstant.PUSH_URL;

@Data
@Slf4j
@Component
@Scope("view")
public class ListReportsViewModel {


    private static final String SERVICE_NAME = "LIST_SENT_NOTIFICATION";
    private final NotificationTemplateService notificationTemplateService;

    private LazyDataModel<NotificationLogResource> lazyModel;

    private NotificationLogResource notificationLogResource;

    private StreamedContent fileCSV;
    private StreamedContent file;
    private Map<String, String> uriParams = new HashMap<>();
    private Integer numberOfReports;

    public ListReportsViewModel(NotificationTemplateService notificationTemplateService) {
        this.notificationTemplateService = notificationTemplateService;
    }

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    public void init() {
        lazyModel = new NotificationLogLazyModel(notificationTemplateService);
        uriParams = new HashMap<>();
        numberOfReports = notificationTemplateService.countNotificationReports();
        notificationLogResource = new NotificationLogResource();
        search();
    }

    public void search() {
        uriParams = new HashMap<>();
        if (notificationLogResource.getTitle() != null) {
            uriParams.put("title", notificationLogResource.getTitle());
        }

        if (notificationLogResource.getMessage() != null) {
            uriParams.put("description", notificationLogResource.getMessage());
        }
        ((NotificationLogLazyModel) lazyModel).setUriParams(uriParams);
    }

    public String getDisplayPnTemplateFeature() {
        return MenuEnum.DISPLAY_REPORT_TEMPLATE.name();
    }

    public void clear() {
        uriParams = new HashMap<>();
        notificationLogResource = new NotificationLogResource();
        search();
    }

    public String getUrl(String title, String content) {
        return PUSH_URL.substring(1) + NOTIF_USER_URL + "?title=" + title + "&content=" + content;
    }

    public void delete(String id) {
        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_NOTIFICATION.name());
        serviceData.put(UtilsConstants.POST_DATA, id);

        notificationTemplateService.deleteNotification(serviceData);
        BoUtils.showsuccesspopup();
        numberOfReports = notificationTemplateService.count();
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(notificationTemplateService.notificationLogs(uriParams), "export/reports.jrxml", "List Reports", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV =
                DefaultStreamedContent.builder().contentType("text/plain").name("List_Reports.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(notificationTemplateService.notificationLogs(uriParams), "pushNotification/reports.jrxml", "List Reports", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file =
                DefaultStreamedContent.builder().contentType("text/plain").name("List_Reports.pdf").stream(() -> is).build();

    }


}
