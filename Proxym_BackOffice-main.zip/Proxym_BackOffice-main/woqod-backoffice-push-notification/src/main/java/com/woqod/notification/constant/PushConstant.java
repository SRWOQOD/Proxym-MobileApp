package com.woqod.notification.constant;

public final class PushConstant {
    private PushConstant() {
    }

    public static final String PUSH_URL = "/notification";
    public static final String REDIRECT_URL = "/notification/templates";


    public static final String TEMPLATE_URL = "/templates";
    public static final String TEMPLATE_VIEW = "templates";

    public static final String ADD_TEMPLATE_URL = "/AddTemplate";
    public static final String ADD_TEMPLATE_VIEW = "addTemplate";


    public static final String EDIT_TEMPLATE_URL = "/EditTemplate";
    public static final String EDIT_TEMPLATE_VIEW = "editTemplate";

    public static final String NOTIF_USER_URL = "/users";
    public static final String NOTIF_USER_VIEW = "PushToUsers";

    public static final String NOTIF_NOTIF_SELECTION_URL = "templatesSelection";
    public static final String NOTIF_NOTIF_SELECTION_VIEW = "templatesSelection";

    public static final String NOTIF_REPORT_URL = "/report";
    public static final String NOTIF_REPORT_VIEW = "report";
    public static final String BUNDLE_NAME = "notif_messages";

}
