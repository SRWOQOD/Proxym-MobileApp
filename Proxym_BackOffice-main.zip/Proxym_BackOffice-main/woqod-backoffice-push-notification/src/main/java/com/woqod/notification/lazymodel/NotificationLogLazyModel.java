package com.woqod.notification.lazymodel;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.notification.service.NotificationTemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import wq.woqod.resources.resources.notifications.NotificationLogResource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@Slf4j
public class NotificationLogLazyModel extends LazyDataModel<NotificationLogResource> {

    private static final long serialVersionUID = 1;
    private final transient NotificationTemplateService notificationTemplateService;
    private transient PaginatedListResponse<NotificationLogResource> response;
    private Map<String, String> uriParams = new HashMap<>();


    @Override
    public void setRowIndex(int rowIndex) {
        super.setRowIndex(BoUtils.setIndex(rowIndex, getPageSize()));
    }

    @Override
    public NotificationLogResource getRowData(String rowIndex) {
        return this.response.getList().stream().filter(item -> item.getId().equals(Long.parseLong(rowIndex))).collect(Collectors.toList()).get(0);
    }


    @Override
    public List<NotificationLogResource> load(final int first, final int pageSize, final String sortField, final SortOrder sortOrder, final Map<String, FilterMeta> filters) {
        try {
            uriParams.putAll(BoUtils.retreivebasicUriParametersForLazyLoading(sortField, sortOrder, first, pageSize));

            response = notificationTemplateService.filterLogs(uriParams);
            this.setRowCount((int) response.getSize());
            this.setPageSize(pageSize);
            return response.getList();

        } catch (Exception e) {
            log.error(e.getMessage());
            return new ArrayList<>();
        }

    }
}