package com.woqod.notification.controllers;

import com.woqod.bo.commons.security.Permissions;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import static com.woqod.notification.constant.PushConstant.*;


@Controller
@RequestMapping(value = PUSH_URL)
@Data
@Slf4j
public class PushNotificationController {

    private final Permissions permissions;

    public PushNotificationController(Permissions permissions) {
        this.permissions = permissions;
    }


    @GetMapping(TEMPLATE_URL)
    public ModelAndView displayTemplates() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(TEMPLATE_VIEW);
        return modelAndView;
    }

    @GetMapping(ADD_TEMPLATE_URL)
    public ModelAndView displayAddTemplates() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(ADD_TEMPLATE_VIEW);
        return modelAndView;
    }

    @GetMapping(EDIT_TEMPLATE_URL)
    public ModelAndView displayEditTemplates() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(EDIT_TEMPLATE_VIEW);
        return modelAndView;
    }


    @GetMapping(NOTIF_USER_URL)
    public ModelAndView displayUsers() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(NOTIF_USER_VIEW);
        return modelAndView;
    }


    @GetMapping(NOTIF_REPORT_URL)
    public ModelAndView displayReport() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(NOTIF_REPORT_VIEW);
        return modelAndView;
    }

    @GetMapping(NOTIF_NOTIF_SELECTION_URL)
    public ModelAndView displaySendNotif() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(NOTIF_NOTIF_SELECTION_VIEW);
        return modelAndView;
    }


}
