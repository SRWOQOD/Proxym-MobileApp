package com.woqod.notification.viewmodels;

import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.notification.enums.MenuEnum;
import com.woqod.notification.lazymodel.NotificationTemplateLazyModel;
import com.woqod.notification.service.NotificationTemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.NotificationTemplateRessource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static com.woqod.notification.constant.PushConstant.*;

@Data
@Slf4j
@Component
@Scope("view")
public class ListTemplateViewModel {


    private static final String SERVICE_NAME = "NOTIFICATION_TEMPLATE";

    private final NotificationTemplateService notificationTemplateService;
    private LazyDataModel<NotificationTemplateRessource> lazyModel;

    private NotificationTemplateRessource filterNotificationTemplateRessource;

    private StreamedContent fileCSV;
    private StreamedContent file;
    Map<String, String> uriParams = new HashMap<>();
    private Integer numberOfNotificationTemplates;

    public ListTemplateViewModel(NotificationTemplateService notificationTemplateService) {
        this.notificationTemplateService = notificationTemplateService;
    }

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    public void init() {
        lazyModel = new NotificationTemplateLazyModel(notificationTemplateService);
        uriParams = new HashMap<>();
        numberOfNotificationTemplates = notificationTemplateService.count();
        filterNotificationTemplateRessource = new NotificationTemplateRessource();
        search();
    }

    public void search() {
        uriParams = new HashMap<>();
        if (filterNotificationTemplateRessource.getContent() != null) {
            uriParams.put("content", filterNotificationTemplateRessource.getContent());
        }

        if (filterNotificationTemplateRessource.getContent() != null) {
            uriParams.put("title", filterNotificationTemplateRessource.getTitle());
        }
        ((NotificationTemplateLazyModel) lazyModel).setUriParams(uriParams);
    }

    public String getDisplayPnTemplateFeature() {
        return MenuEnum.DISPLAY_PN_TEMPLATE.name();
    }

    public void clear() {
        filterNotificationTemplateRessource = new NotificationTemplateRessource();
        uriParams = new HashMap<>();
        search();
    }


    public String getAddPage() {
        return PUSH_URL.substring(1) + ADD_TEMPLATE_URL;
    }

    public String getUrl(String id) {
        return PUSH_URL.substring(1) + EDIT_TEMPLATE_URL + "?id=" + id;
    }

    public void delete(String id) {

        HashMap<String, Object> serviceData = new HashMap<>();
        serviceData.put(UtilsConstants.FEATURE, MenuEnum.DELETE_TEMPLATE.name());
        serviceData.put(UtilsConstants.POST_DATA, id);

        notificationTemplateService.delete(serviceData);
        BoUtils.showsuccesspopup();
        numberOfNotificationTemplates = notificationTemplateService.count();
    }

    public void exportCSV() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(notificationTemplateService.notifications(uriParams), "export/templateResponses.jrxml", "Push Notification", JasperReportType.CSV);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        fileCSV = DefaultStreamedContent.builder().contentType("text/plain").name("Push Notifications.csv").stream(() -> is).build();

    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReport(notificationTemplateService.notifications(uriParams), "pushNotification/templateResponses.jrxml", "Push Notification", JasperReportType.PDF);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = DefaultStreamedContent.builder().contentType("text/plain").name("Push Notifications.pdf").stream(() -> is).build();
    }

}
