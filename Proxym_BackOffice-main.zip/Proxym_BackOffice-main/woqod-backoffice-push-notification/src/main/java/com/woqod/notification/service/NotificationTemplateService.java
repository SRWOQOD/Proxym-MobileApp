package com.woqod.notification.service;

import com.woqod.bo.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.notifications.NotificationLogResource;

import java.util.List;
import java.util.Map;

public interface NotificationTemplateService {
    PaginatedListResponse<NotificationTemplateRessource> filter(Map<String, String> uriParams);

    PaginatedListResponse<NotificationLogResource> filterLogs(Map<String, String> uriParams);

    void save(Map<String, Object> serviceData);

    Boolean update(Map<String, Object> serviceData);

    Boolean deleteNotification(Map<String, Object> serviceData);

    Boolean delete(Map<String, Object> serviceData);

    NotificationTemplateRessource findById(String id);

    Boolean sendNotification(Map<String, Object> uriParams);

    List<NotificationLogResource> notificationLogs(Map<String, String> uriParams);

    List<NotificationTemplateRessource> notifications(Map<String, String> uriParams);

    Boolean sendNotificationToAll(Map<String, Object> uriParams);

    Boolean sendNotificationToWoqode(Map<String, Object> uriParams);

    Integer count();

    Integer countNotificationReports();

}
