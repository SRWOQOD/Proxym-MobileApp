package com.woqod.notification.viewmodels;


import com.google.common.base.Strings;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.exceptions.RestBackendException;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.UtilsConstants;
import com.woqod.notification.enums.MenuEnum;
import com.woqod.notification.lazymodel.NotificationTemplateLazyModel;
import com.woqod.notification.service.NotificationTemplateService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.event.FlowEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.LazyDataModel;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wq.woqod.resources.enumerations.LangTagName;
import wq.woqod.resources.enumerations.PushNotifEnum;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.UserResource;
import wq.woqod.resources.resources.notifications.SendDeviceNotificationResource;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static com.woqod.notification.constant.PushConstant.*;
import static com.woqod.notification.enums.MenuEnum.DISPLAY_USERS_TEMPLATE;


@Data
@Slf4j
@Component
@Scope("view")
public class PublishToUsersTemplateViewModel {

    /*
    Beans
     */
    private final DataFactory factory;
    private final NotificationTemplateService notificationTemplateService;
    private final Permissions permissions;
    private LazyDataModel<NotificationTemplateRessource> lazyModel;
    private Boolean isAll;
    private Boolean isWoqodeUser;
    /*
    state
     */
    private List<UserResource> selectedUsers = new ArrayList<>();
    private NotificationTemplateRessource selectedTemplates;
    private NotificationTemplateRessource filterNotificationTemplateRessource;
    private NotificationTemplateRessource notificationTemplateRessource;
    private static String titleString = "title";
    private static String contentString = "content";
    private static String selectedString = "selected";

    public PublishToUsersTemplateViewModel(Permissions permissions, DataFactory factory, NotificationTemplateService notificationTemplateService) {
        this.factory = factory;
        this.permissions = permissions;
        this.notificationTemplateService = notificationTemplateService;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    public String onFlowProcess(FlowEvent event) {
        if (BooleanUtils.isTrue(selectedUsers.isEmpty()) && !BooleanUtils.isTrue(isAll) && !BooleanUtils.isTrue(isWoqodeUser)) {
            BoUtils.showErrorPopup("Empty user list", "please select at least one user");
            return event.getOldStep();

        } else {
            return event.getNewStep();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        lazyModel = new NotificationTemplateLazyModel(notificationTemplateService);
        filterNotificationTemplateRessource = new NotificationTemplateRessource();
        notificationTemplateRessource = NotificationTemplateRessource.builder().content("").title("").arabicTitle("").arabicContent("").build();
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();

        if (request.getParameter(titleString) != null) {
            notificationTemplateRessource.setTitle(request.getParameter(titleString));
        }

        if (request.getParameter(contentString) != null) {
            notificationTemplateRessource.setContent(request.getParameter(contentString));
        }

        if ((request.getParameter(selectedString) == null || request.getParameter(selectedString).isEmpty()) && selectedUsers == null) {
            factory.redirect(getAbortPage());
        }


    }

    public void clear() {
        filterNotificationTemplateRessource = new NotificationTemplateRessource();
        filterNotificationTemplateRessource.setTitle(null);
        filterNotificationTemplateRessource.setContent(null);
        lazyModel = new NotificationTemplateLazyModel(notificationTemplateService);

    }


    public String publish() {
        if (selectedUsers.isEmpty()) {
            BoUtils.showErrorPopup("Empty user list", "please select at least one user");
            return null;
        }
        try {
            BoUtils.showsuccesspopup();
            return NOTIF_NOTIF_SELECTION_VIEW;
        } catch (RuntimeException e) {
            log.error(e.getMessage());
            BoUtils.showErrorPopup("Publish Failed", e.toString());
        }
        return null;
    }


    public void deselectRows() {
        this.selectedUsers.clear();
    }

    public String getFeature() {
        return DISPLAY_USERS_TEMPLATE.name();
    }


    public void search() {
        Map<String, String> uriParams = new HashMap<>();
        if (filterNotificationTemplateRessource.getContent() != null) {
            uriParams.put(contentString, filterNotificationTemplateRessource.getContent());
        }

        if (filterNotificationTemplateRessource.getContent() != null) {
            uriParams.put(titleString, filterNotificationTemplateRessource.getTitle());
        }

        ((NotificationTemplateLazyModel) lazyModel).setUriParams(uriParams);
    }

    public void onRowSelect(SelectEvent event) {
        this.notificationTemplateRessource.setContent(notificationTemplateRessource.getContent().concat(((NotificationTemplateRessource) event.getObject()).getContent()));
        this.notificationTemplateRessource.setTitle(notificationTemplateRessource.getTitle().concat(((NotificationTemplateRessource) event.getObject()).getTitle()));
        this.notificationTemplateRessource.setArabicContent(notificationTemplateRessource.getArabicContent().concat(((NotificationTemplateRessource) event.getObject()).getArabicContent()));
        this.notificationTemplateRessource.setArabicTitle(notificationTemplateRessource.getArabicTitle().concat(((NotificationTemplateRessource) event.getObject()).getArabicTitle()));
    }

    public void onRowUnselect(UnselectEvent event) {
        this.notificationTemplateRessource.setContent(notificationTemplateRessource.getContent().replace(((NotificationTemplateRessource) event.getObject()).getContent(), ""));
        this.notificationTemplateRessource.setTitle(notificationTemplateRessource.getTitle().replace(((NotificationTemplateRessource) event.getObject()).getTitle(), ""));
        this.notificationTemplateRessource.setArabicContent(notificationTemplateRessource.getArabicContent().replace(((NotificationTemplateRessource) event.getObject()).getArabicContent(), ""));
        this.notificationTemplateRessource.setArabicTitle(notificationTemplateRessource.getArabicTitle().replace(((NotificationTemplateRessource) event.getObject()).getArabicTitle(), ""));
    }

    public void save(List<UserResource> selectedUsers) {

        log.info("selectedUsers: {}", selectedUsers);
        if (notificationTemplateRessource.getTitle() == null || notificationTemplateRessource.getTitle().isEmpty()) {
            BoUtils.showErrorPopup("English Title is required", "English Title is required");
        }
        if (notificationTemplateRessource.getContent() == null || notificationTemplateRessource.getContent().isEmpty()) {
            BoUtils.showErrorPopup("English Content is required", "English Content is required");
        }
        if (notificationTemplateRessource.getArabicTitle() == null || notificationTemplateRessource.getArabicTitle().isEmpty()) {
            BoUtils.showErrorPopup("Arabic Title is required", "Arabic Title is required");
        }
        if (notificationTemplateRessource.getContent() == null || notificationTemplateRessource.getContent().isEmpty()) {
            BoUtils.showErrorPopup("Arabic Content is required", "Arabic Content is required");
        }

        SendDeviceNotificationResource usersAndNotificationTemplateRessource = SendDeviceNotificationResource.builder().build();
        usersAndNotificationTemplateRessource.setType(PushNotifEnum.BO);
        usersAndNotificationTemplateRessource.setLangTagName(LangTagName.EN);
        usersAndNotificationTemplateRessource.setTitleEn(notificationTemplateRessource.getTitle());
        usersAndNotificationTemplateRessource.setTitleAr(notificationTemplateRessource.getArabicTitle());
        usersAndNotificationTemplateRessource.setDescriptionEn(notificationTemplateRessource.getContent());
        usersAndNotificationTemplateRessource.setDescriptionAr(notificationTemplateRessource.getArabicContent());
        usersAndNotificationTemplateRessource.setForWoqode(isWoqodeUser);
        usersAndNotificationTemplateRessource.setForAll(isAll);
        try {
            if (!BooleanUtils.isTrue(isAll) && !BooleanUtils.isTrue(isWoqodeUser)) {
                log.info("!isAll && !isWoqodeUser");
                usersAndNotificationTemplateRessource.setUserIds(getUserIds(selectedUsers));
            }
            HashMap<String, Object> serviceData = new HashMap<>();
            serviceData.put(UtilsConstants.FEATURE, MenuEnum.SEND_NOTIFICATION.name());
            log.info("usersAndNotificationTemplateRessource: {}", usersAndNotificationTemplateRessource.getSendTo());
            serviceData.put(UtilsConstants.POST_DATA, usersAndNotificationTemplateRessource);
            log.info("serviceData : {}", serviceData);
            notificationTemplateService.sendNotification(serviceData);
            BoUtils.showSuccessPopup("SUCCESS", "Notification sent successfully.");
            factory.redirect("notification/users");
        } catch (RestBackendException e) {
            BoUtils.showErrorPopup("Failed", e.getDescription());
        }

    }

    private static List<String> getUserIds(List<UserResource> selectedUsers) {
        List<String> list = new ArrayList<>();
        for (UserResource user : selectedUsers) {
            list.add(user.getId().toString());
        }
        return list;
    }

    public String getAbortPage() {
        return PUSH_URL.substring(1) + NOTIF_USER_URL;
    }

    public String decryptQid(String qid) {
        if (!Strings.isNullOrEmpty(qid)) {
            byte[] valueDecoded = Base64.getDecoder().decode(qid);
            return new String(valueDecoded);
        } else {
            return qid;
        }
    }
}
