package com.woqod.notification.viewmodels;


import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.event.FlowEvent;
import org.primefaces.model.LazyDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.UserResource;

import javax.annotation.ManagedBean;
import javax.faces.context.FacesContext;
import java.util.ArrayList;
import java.util.List;

import static com.woqod.notification.enums.MenuEnum.DISPLAY_USERS_TEMPLATE;


@Data
@Slf4j
@Component
@Scope("view")
@ManagedBean
public class PublishToUsersViewModel {

    /*
    Beans
     */
    private final Permissions permissions;
    private final DataFactory factory;
    private LazyDataModel<NotificationTemplateRessource> lazyModel;
    private Boolean isAll;
    private Boolean isWoqode;

    /*
    state
     */
    private List<UserResource> selectedUsers = new ArrayList<>();
    private Boolean checked = true;

    @Autowired
    public PublishToUsersViewModel(Permissions permissions, DataFactory factory) {
        this.factory = factory;
        this.permissions = permissions;
    }

    /**
     * this method is used to initialize the view for the first time
     * it's invoked by the preRenderView primeFaces components in the tab
     */
    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    /**
     * initialize Parameters
     * initialize data before displaying view
     */
    public void init() {
        selectedUsers.clear();
    }

    public void clear() {
        this.init();
    }


    public Boolean publish() {
        if (selectedUsers.isEmpty() && !BooleanUtils.isTrue(checked)) {
            BoUtils.showErrorPopup("Empty user list", "please select at least one user");
            return false;
        }
        return true;
    }

    public void deselectRows() {
        this.selectedUsers.clear();
    }

    public String getFeature() {
        return DISPLAY_USERS_TEMPLATE.name();
    }

    public void revert() {
        this.checked = !checked;
    }

    public String onFlowProcess(FlowEvent event) {
        if (selectedUsers.isEmpty() || !BooleanUtils.isTrue(isAll) || !BooleanUtils.isTrue(isWoqode)) {
            BoUtils.showErrorPopup("Empty user list", "please select at least one user");
            return event.getOldStep();

        } else {
            return event.getNewStep();
        }

    }
}
