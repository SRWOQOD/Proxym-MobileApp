package com.woqod.auth.dao.entity;

import com.woqod.bo.commons.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.resources.enumerations.LoginStatusEnum;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by nada.achour on 11/11/2022.
 */
@Entity
@Table(name = Constants.BO_ACCESS_LOGS)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoAccessLogs {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Date creationDate;

    @Enumerated(EnumType.STRING)
    private LoginStatusEnum loginStatusEnum;

    private String userName;

    private String ipAddress;
}
