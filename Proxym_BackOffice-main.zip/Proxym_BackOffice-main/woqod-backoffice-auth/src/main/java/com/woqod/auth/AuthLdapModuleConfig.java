package com.woqod.auth;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

@Configuration
@ComponentScan(basePackages = {"com.woqod.auth"})
@EnableSpringDataWebSupport
public class AuthLdapModuleConfig {
}
