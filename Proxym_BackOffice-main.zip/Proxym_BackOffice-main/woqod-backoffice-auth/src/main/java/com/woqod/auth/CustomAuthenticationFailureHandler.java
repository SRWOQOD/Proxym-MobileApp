package com.woqod.auth;

import com.woqod.auth.service.BoAccessLogsService;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.interfaces.UserAttemptsService;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.LoginStatusEnum;
import wq.woqod.resources.resources.BoAccessLogsResource;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@Component
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    private final UserAttemptsService userAttemptsService;

    private final DataFactory dataFactory;
    private final Boolean blockAdministratorEnabled;
    private final BoAccessLogsService boAccessLogsService;
    private static final String REDERROR = "/login?error=true";
    private static final String REDBLOCK = "/login?blocked=true";

    @Autowired
    public CustomAuthenticationFailureHandler(UserAttemptsService userAttemptsService, DataFactory dataFactory,
                                              @Value("${block.administrator.enabled}") Boolean blockAdministratorEnabled, BoAccessLogsService boAccessLogsService) {
        this.userAttemptsService = userAttemptsService;
        this.dataFactory = dataFactory;
        this.blockAdministratorEnabled = blockAdministratorEnabled;
        this.boAccessLogsService = boAccessLogsService;
    }

    /**
     * @param request
     * @param response
     * @param e
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException e) throws IOException, ServletException {
        BoAccessLogsResource boAccessLogsResource = new BoAccessLogsResource();
        boAccessLogsResource.setCreationDate(new Date());
        boAccessLogsResource.setIpAddress(request.getRemoteAddr() == null ? "" : request.getRemoteAddr());

        try {
            if (BooleanUtils.isTrue(blockAdministratorEnabled)) {
                //invalid login, update to user_attempts
                String username = request.getParameter("username");
                boAccessLogsResource.setUserName(username);
                userAttemptsService.updateFailAttempts(username);
                boAccessLogsResource.setLoginStatusEnum(LoginStatusEnum.INVALID_CREDENTIAL);
                boAccessLogsService.save(boAccessLogsResource);
            }
            response.sendRedirect(dataFactory.getContext() + REDERROR);

        } catch (LockedException ex) {
            response.sendRedirect(dataFactory.getContext() + REDBLOCK);
            boAccessLogsResource.setLoginStatusEnum(LoginStatusEnum.OTHERS);
            boAccessLogsService.save(boAccessLogsResource);
        }
    }

}