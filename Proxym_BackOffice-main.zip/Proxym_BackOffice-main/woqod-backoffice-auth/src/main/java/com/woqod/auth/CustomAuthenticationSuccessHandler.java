package com.woqod.auth;

import com.woqod.auth.service.BoAccessLogsService;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.interfaces.UserAttemptsService;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.model.UserModel;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.LdapUserDetailsImpl;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import wq.woqod.resources.enumerations.LoginStatusEnum;
import wq.woqod.resources.resources.BoAccessLogsResource;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.Objects;

@Component
public class CustomAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    private final UserService userService;
    private final DataFactory dataFactory;
    private final UserAttemptsService userAttemptsService;
    private final BoAccessLogsService boAccessLogsService;
    private final Boolean blockAdministratorEnabled;
    private static final String REDERROR = "/login?error=true";
    private static final String REDBLOCK = "/login?blocked=true";

    @Autowired
    public CustomAuthenticationSuccessHandler(UserService userService, DataFactory dataFactory, UserAttemptsService userAttemptsService, BoAccessLogsService boAccessLogsService, @Value("${block.administrator.enabled}") Boolean blockAdministratorEnabled) {
        this.userService = userService;
        this.dataFactory = dataFactory;
        this.userAttemptsService = userAttemptsService;
        this.boAccessLogsService = boAccessLogsService;
        this.blockAdministratorEnabled = blockAdministratorEnabled;
    }


    /**
     * executed login succeded
     *
     * @param request
     * @param response
     * @param authentication
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        BoAccessLogsResource boAccessLogsResource = new BoAccessLogsResource();
        boAccessLogsResource.setCreationDate(new Date());
        boAccessLogsResource.setIpAddress(request.getRemoteAddr() == null ? "" : request.getRemoteAddr());
        if (BooleanUtils.isTrue(blockAdministratorEnabled)) {
            String red = dataFactory.getContext();
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            LdapUserDetailsImpl principal = (LdapUserDetailsImpl) auth.getPrincipal();
            UserModel user = userService.findOneByUserName(principal.getUsername());
            if (user != null) {
                request.getSession().setAttribute("User", user);
                boAccessLogsResource.setUserName(user.getUserName());
            }
            if (!BooleanUtils.isTrue(Objects.requireNonNull(user).getAccountNonLocked())) {
                HttpSession session = request.getSession(false);
                if (request.isRequestedSessionIdValid() && session != null) {
                    session.invalidate();
                }
                boAccessLogsResource.setLoginStatusEnum(LoginStatusEnum.INVALID_CREDENTIAL);
                dataFactory.redirect(red + REDERROR);

            } else if (!BooleanUtils.isTrue(user.getEnabled())) {
                HttpSession session = request.getSession(false);
                if (request.isRequestedSessionIdValid() && session != null) {
                    session.invalidate();
                }
                boAccessLogsResource.setLoginStatusEnum(LoginStatusEnum.OTHERS);
                dataFactory.redirect(red + REDBLOCK);
            }
            userAttemptsService.resetFailAttempts(authentication.getName());
        }
        boAccessLogsResource.setLoginStatusEnum(LoginStatusEnum.SUCCESS);
        boAccessLogsService.save(boAccessLogsResource);
        super.onAuthenticationSuccess(request, response, authentication);
    }
}