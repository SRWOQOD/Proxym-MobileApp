package com.woqod.auth;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

@Configuration
public class LdapClientConfig {

    @Value("${ldap.url}")
    private String ldapUrl;
    @Value("${ldap.managerDn}")
    private String managerDn;
    @Value("${ldap.userSearchBase}")
    private String ldapBase;
    @Value("${ldap.password}")
    private String password;

    /**
     * set ldap config manager dn url and password
     *
     * @return
     */
    @Bean
    public LdapContextSource contextSource() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(ldapUrl);
        contextSource.setUserDn(managerDn);
        contextSource.setBase(ldapBase);
        contextSource.setPassword(password);
        return contextSource;
    }

    /**
     * create ldaptemplate bean
     *
     * @return
     */
    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

}
