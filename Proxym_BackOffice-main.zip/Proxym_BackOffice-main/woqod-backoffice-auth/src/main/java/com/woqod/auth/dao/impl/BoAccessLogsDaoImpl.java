package com.woqod.auth.dao.impl;


import com.woqod.auth.dao.BoAccessLogsDao;
import com.woqod.auth.dao.entity.BoAccessLogs;
import com.woqod.auth.dao.repository.BoAccessLogsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;
import wq.woqod.commons.exception.PersistingDataException;

/**
 * Created by nada.achour on 11/11/2022.
 */
@Repository
@Slf4j
public class BoAccessLogsDaoImpl implements BoAccessLogsDao {

    private final BoAccessLogsRepository boAccessLogsRepository;

    @Autowired
    public BoAccessLogsDaoImpl(BoAccessLogsRepository boAccessLogsRepository) {
        this.boAccessLogsRepository = boAccessLogsRepository;
    }

    @Override
    public BoAccessLogs save(BoAccessLogs boAccessLogs) {
        try {
            return boAccessLogsRepository.save(boAccessLogs);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("BoAccessLogs", ex);
        }
    }
}
