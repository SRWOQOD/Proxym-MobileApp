package com.woqod.auth.dao.repository;


import com.woqod.auth.dao.entity.BoAccessLogs;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by nada.achour on 11/11/2022.
 */
public interface BoAccessLogsRepository extends JpaRepository<BoAccessLogs, Long> {


}
