package com.woqod.auth.service;


import wq.woqod.resources.resources.BoAccessLogsResource;

public interface BoAccessLogsService {

    BoAccessLogsResource save(BoAccessLogsResource boAccessLogsResource);

}
