package com.woqod.auth.dao;

import com.woqod.auth.dao.entity.BoAccessLogs;

/**
 * Created by nada.achour on 11/11/2022.
 */
public interface BoAccessLogsDao {

    /**
     * used to save BoUser Access logs
     */
    BoAccessLogs save(BoAccessLogs boAccessLogs);
}