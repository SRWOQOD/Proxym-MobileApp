package com.woqod.auth;

import com.woqod.bo.commons.interfaces.LoadUserService;
import com.woqod.bo.commons.model.ExternalUser;
import com.woqod.bo.commons.model.UserRoleForm;
import com.woqod.bo.commons.utils.BoUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.AbstractContextMapper;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class LdapClientService implements LoadUserService {

    private static final String LDAP_KEY_CLASS = "objectclass";
    private static final String LDAP_KEY_PERSON = "person";
    private static final String LDAP_KEY_USERNAME = "sAMAccountName";
    private static final String LDAP_KEY_FULLNAME = "cn";
    private static final String LDAP_KEY_PWD = "userPassword";

    private LdapTemplate ldapTemplate;

    @Autowired
    public LdapClientService(LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }


    @Override
    public List<ExternalUser> getAllUsers() {
        List<ExternalUser> users = null;
        try {
            LdapQuery query = LdapQueryBuilder.query()
                    .where(LDAP_KEY_CLASS)
                    .is(LDAP_KEY_PERSON);
            users = ldapTemplate.search(query, new PersonContextMapper());
        } catch (RuntimeException e) {
            log.error(e.getMessage());
        }
        return users;
    }

    @Override
    public List<ExternalUser> getUsersWithFilter(UserRoleForm filter) {
        LdapQuery query = null;
        if (BoUtils.isEmptyOrNull(filter.getUserName()))
            return new ArrayList<>();
        if (!BoUtils.isEmptyOrNull(filter.getUserName()))
            query = LdapQueryBuilder.query()
                    .where(LDAP_KEY_CLASS)
                    .is(LDAP_KEY_PERSON)
                    .and("cn").like("*".concat(filter.getUserName()).concat("*"))
                    ;
        return ldapTemplate.search(query, new PersonContextMapper());
    }

    private static class PersonContextMapper extends AbstractContextMapper {

        public Object doMapFromContext(DirContextOperations context) {
            byte[] pwdByte = (byte[])context.getObjectAttribute(LDAP_KEY_PWD);
            String password = context.getObjectAttribute(LDAP_KEY_PWD) != null ? new String(pwdByte, Charset.defaultCharset()) : null ;
            return new ExternalUser(context.getStringAttribute(LDAP_KEY_USERNAME), password,context.getStringAttribute(LDAP_KEY_FULLNAME), null);
        }
    }
}