package com.woqod.auth.controller;

import com.google.common.base.Strings;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.woqod.auth.service.BoAccessLogsService;
import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.commons.enums.JasperReportType;
import com.woqod.bo.commons.exceptions.DataNotFoundException;
import com.woqod.bo.commons.interfaces.AuthorityService;
import com.woqod.bo.commons.interfaces.LoadUserService;
import com.woqod.bo.commons.interfaces.UserAttemptsService;
import com.woqod.bo.commons.interfaces.UserService;
import com.woqod.bo.commons.model.*;
import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.bo.user.enums.MenuEnum;
import com.woqod.bo.user.mapper.UserMapper;
import com.woqod.bo.user.service.RoleService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.BoAccessLogsResource;

import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by nada.achour  on 11/11/2022.
 */
@RestController
@Slf4j
@RequestMapping(value = "/boAccessLogsController")
public class BoAccessLogsController {

    private final BoAccessLogsService boAccessLogsService;

    @Autowired
    public BoAccessLogsController(BoAccessLogsService boAccessLogsService) {
        this.boAccessLogsService = boAccessLogsService;
    }

    @PostMapping(value = "/save")
    public GenericResponse<ObjectResponse<BoAccessLogsResource>> save(@RequestBody BoAccessLogsResource boAccessLogsResource) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(boAccessLogsService.save(boAccessLogsResource)), Provider.WOQOD);
    }

}

