package com.woqod.auth;

import com.woqod.bo.user.service.impl.SSUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.ldap.authentication.UserDetailsServiceLdapAuthoritiesPopulator;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@ComponentScan(basePackages = {"com.woqod.auth"})
@EnableJpaRepositories(basePackages = {"com.woqod.auth.dao.repository"})
@EntityScan(basePackages = {"com.woqod.auth.dao.entity"})
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
@Order(SecurityProperties.BASIC_AUTH_ORDER)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
  //prod version
  @Autowired
   SSUserDetailsService userDetailsService;

    private final CustomAuthenticationFailureHandler customAuthenticationFailureHandler;
    private final CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;


    @Autowired
    public SecurityConfig(CustomAuthenticationFailureHandler customAuthenticationFailureHandler, CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler) {
        this.customAuthenticationFailureHandler = customAuthenticationFailureHandler;
        this.customAuthenticationSuccessHandler = customAuthenticationSuccessHandler;
    }

    /**
     * @param http
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/webjars/**").permitAll()
                .antMatchers("/resources/**", "/javax.faces.resource/**").permitAll()
                .antMatchers("/uploads/**").permitAll()
                .antMatchers("/login").permitAll()
                .anyRequest()
                .authenticated().and().formLogin()
                .loginPage("/login.xhtml")
                .successHandler(customAuthenticationSuccessHandler)
                .failureHandler(customAuthenticationFailureHandler)
                .permitAll()
                .and()
                .logout().logoutUrl("/logout")
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .permitAll()
                .and()
                .rememberMe();
    }


    /**
     * @param web
     * @throws Exception
     */
    @Override
    public void configure(WebSecurity web) {
        web.ignoring().antMatchers("/resources/**");
        web.ignoring().antMatchers("/uploads/**");
    }

    /**
     * @param url
     * @param managerDn
     * @param password
     * @param field
     * @param auth
     * @throws Exception
     */
    @Autowired
    public void configureGlobal(@Value("${ldap.url}") String url, @Value("${ldap.managerDn}") String managerDn,
                                @Value("${ldap.password}") String password, @Value("${ldap.userSearchBase}") String userSearchBase,
                                @Value("${ldap.auth.field}") String field, AuthenticationManagerBuilder auth) throws Exception {

        auth.ldapAuthentication().
                userSearchFilter(field + "={0}").
                contextSource().url(url)
                .managerDn(managerDn)
                .managerPassword(password)
                .and()
                //prod mode
                .userSearchBase(userSearchBase)
                .ldapAuthoritiesPopulator(new UserDetailsServiceLdapAuthoritiesPopulator(userDetailsService));
                //DEVmode
              //  .ldapAuthoritiesPopulator(new UserDetailsServiceLdapAuthoritiesPopulator(getUserDetailsService()));
    }

//devMode

    @Bean
    public UserDetailsService getUserDetailsService() {
        return new SSUserDetailsService();
    }
}