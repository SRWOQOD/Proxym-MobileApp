package com.woqod.auth;

import com.woqod.bo.commons.data.DataFactory;
import com.woqod.bo.user.dao.FeatureRoleDao;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import wq.woqod.resources.enumerations.LoginStatusEnum;
import wq.woqod.resources.resources.BoAccessLogsResource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.Optional;


@Controller
@RequestMapping("/")
@Data
@Slf4j
public class LoginController {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    private final DataFactory dataFactory;

    @Autowired
    private FeatureRoleDao featureRoleDao;

    public LoginController(DataFactory dataFactory) {
        this.dataFactory = dataFactory;
    }

    /**
     * After success or failed login
     **/
    @GetMapping(value = {"/login", ""})
    public ModelAndView login(@RequestParam(required = false) Optional<String> error, @RequestParam(required = false) Optional<String> blocked, @RequestParam(required = false) Optional<String> lang) {
        LOGGER.debug("[LoginController] login ");
        if (error.isPresent()) {
            return new ModelAndView("login", "error", error);
        } else if (blocked.isPresent()
        ) {
            return new ModelAndView("login", "blocked", blocked);
        } else {
            return new ModelAndView("redirect:/dashboard");
        }

    }


    /**
     * Logout End Point
     */
    @GetMapping(value = "/logout")
    public String logout(HttpServletRequest request) {
        LOGGER.info("[LoginController] logout ");
        HttpSession session = request.getSession(false);
        if (request.isRequestedSessionIdValid() && session != null) {
            session.invalidate();
        }
        return "redirect:/login";
    }

    @GetMapping(value = "/accessDenied")
    public ModelAndView access() {
        return new ModelAndView("access");
    }

    @GetMapping(value = "/processError")
    public ModelAndView processError() {
        return new ModelAndView("error");
    }
}

