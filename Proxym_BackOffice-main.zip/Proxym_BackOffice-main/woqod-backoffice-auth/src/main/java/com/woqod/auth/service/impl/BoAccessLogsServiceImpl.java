package com.woqod.auth.service.impl;

import com.woqod.auth.dao.BoAccessLogsDao;
import com.woqod.auth.dao.entity.BoAccessLogs;
import com.woqod.auth.service.BoAccessLogsService;
import com.woqod.bo.commons.interfaces.UserActionService;
import com.woqod.bo.commons.model.UserActionModel;
import com.woqod.bo.user.dao.UserActionDao;
import com.woqod.bo.user.mapper.UserActionMapper;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.BoAccessLogsResource;

import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
public class BoAccessLogsServiceImpl implements BoAccessLogsService {

    private final BoAccessLogsDao boAccessLogsDao;

    private final ModelMapper mapper = new ModelMapper();

    @Autowired
    public BoAccessLogsServiceImpl(BoAccessLogsDao boAccessLogsDao) {
        this.boAccessLogsDao = boAccessLogsDao;
    }

    @Override
    public BoAccessLogsResource save(BoAccessLogsResource boAccessLogsResource) {
        return mapper.map(boAccessLogsDao.save(mapper.map(boAccessLogsResource, BoAccessLogs.class)), BoAccessLogsResource.class);
    }

}