package com.woqod.dashboard.configuration;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
@Configuration
@ComponentScan(basePackages = {"com.woqod.dashboard"})
public class DashboardConfig {
}
