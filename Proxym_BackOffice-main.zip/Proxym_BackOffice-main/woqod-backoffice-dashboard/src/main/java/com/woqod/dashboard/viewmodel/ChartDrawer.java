package com.woqod.dashboard.viewmodel;


import com.woqod.bo.commons.security.Permissions;
import com.woqod.bo.commons.utils.BoUtils;
import com.woqod.bo.commons.utils.GenerateJasperReport;
import com.woqod.dashboard.service.StaticsService;
import com.woqod.dashboard.utils.FilterResource;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.BooleanUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.resources.resources.StaticsResource;

import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.*;

@Data
@Slf4j
@Component
@Scope("view")
@ManagedBean
public class ChartDrawer {

    private final StaticsService staticsService;
    private Boolean showDash;
    private Boolean notShowDash;
    private Boolean showLogin;
    private Boolean showTotalFahes;
    private Boolean showTotalWoqod;
    private Boolean showUser;
    private Boolean showUserL;
    private Boolean showTransactionFahes;
    private Boolean showTransationWoqod;
    private int sommeLogin;
    private StaticsResource statics;
    private final Permissions permissions;
    private FilterResource filterResource = new FilterResource();
    private StreamedContent file;
    private String currentDate;

    public ChartDrawer(StaticsService staticsService, Permissions permissions) {
        this.staticsService = staticsService;
        this.permissions = permissions;
    }

    @PostConstruct
    public void init() {
        showLogin = true;
        showTotalFahes = true;
        showTotalWoqod = true;
        showUser = true;
        showUserL = true;
        showTransactionFahes = true;
        showTransationWoqod = true;
        currentDate = DateFormatter.localDateToStringDate(LocalDate.now());
        Map<String, String> map = new HashMap<>();
        map.put("dateFrom", DateFormatter.localDateToStringDate(LocalDate.now()));
        map.put("dateTo", DateFormatter.localDateToStringDate(LocalDate.now()));

        this.statics = this.staticsService.getStatics(map);
        filterResource = new FilterResource();
        filterResource.setDateFrom(LocalDate.now());
        filterResource.setDateTo(LocalDate.now());
    }

    public void filter() {
        Map<String, String> uriParams = new HashMap<>();
            if (filterResource.getDateFrom() != null) {
                uriParams.put("dateFrom", DateFormatter.localDateToStringDate(filterResource.getDateFrom()));
            }
            if (filterResource.getDateTo() != null) {
                uriParams.put("dateTo", DateFormatter.localDateToStringDate(filterResource.getDateTo()));
            }
            if (filterResource.getDateTo() != null && filterResource.getDateFrom() != null && !BooleanUtils.isTrue(checkDates())) {
                BoUtils.showErrorPopup("Dates", "Start date must be smaller then end date");
                return;
            }
        this.statics = this.staticsService.getStatics(uriParams);
    }

    public Boolean checkDates() {
        return filterResource.getDateFrom().compareTo(filterResource.getDateTo()) <= 0;
    }


    public void clear() {
        filterResource = new FilterResource();
        init();
    }

    public void initializeView() {
        if (!FacesContext.getCurrentInstance().isPostback()) {
            init();
        }
    }

    @PostConstruct
    public void showDashboard() {
        this.showDash = permissions.isFeaturePermitted("DASHBOARD_MANAGEMENTS");
        if (!BooleanUtils.isTrue(showDash)) {
            notShowDash = true;
        }
    }

    public String getSommeLogin() {
        return NumberFormat.getNumberInstance(Locale.US).format(
                statics.getSuccessLogin().add(statics.getInvalid()).add(statics.getOtherErrors()));
    }

    public String getSommeTransactions() {
        return NumberFormat.getNumberInstance(Locale.US).format(
                statics.getSuccessTrans().add(statics.getFailTrans()).add(statics.getSuccessQpayTrans()).add(statics.getFailQpayTrans()));
    }

    public String getSommeTransactionsFahes() {
        return NumberFormat.getNumberInstance(Locale.US).format(
                statics.getFailTransFahes().add(statics.getSuccessTransFahes()).add(statics.getFailQpayTransFahes()).add(statics.getSuccessQpayTransFahes()));
    }

    public String getAllRegistredUsers() {
        return NumberFormat.getNumberInstance(Locale.US).format(
                statics.getRegistredUsers().add(statics.getWaqodeUsers()).add(statics.getActiveUsers()));
    }

    public LocalDate getDate() {
        return LocalDate.now();
    }

    public void exportPDF() throws IOException, JRException {
        String base64 = GenerateJasperReport.generateReportDashb(statics);
        ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
        file = new DefaultStreamedContent(is, "text/plain", "Dashboard_" + new Date() + ".pdf");
    }

}
