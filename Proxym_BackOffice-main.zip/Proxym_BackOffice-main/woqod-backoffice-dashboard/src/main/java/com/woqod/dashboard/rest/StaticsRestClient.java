package com.woqod.dashboard.rest;

import com.woqod.bo.commons.response.GenericResponse;
import com.woqod.bo.commons.response.body.ObjectResponse;
import com.woqod.bo.commons.restclient.BaseUrlProvider;
import com.woqod.bo.commons.restclient.CustomRestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import wq.woqod.resources.resources.StaticsResource;

import java.util.Map;

@Component
@Slf4j
@PropertySource({"classpath:properties/statics.properties"})
public class StaticsRestClient {

    private final CustomRestTemplate staticRestTemplate;

    private final BaseUrlProvider baseUrlProvider;

    @Value("${uri.ws.statics}")
    private String statics;

    public StaticsRestClient(CustomRestTemplate staticRestTemplate, BaseUrlProvider baseUrlProvider) {
        this.staticRestTemplate = staticRestTemplate;
        this.baseUrlProvider = baseUrlProvider;
    }


    public StaticsResource getStatics(Map<String, String> params) {
        String uri = statics;
        ObjectResponse<StaticsResource> response = (ObjectResponse<StaticsResource>) staticRestTemplate
                .getGenericResponseBody(baseUrlProvider.getUrl(uri, params),
                        new ParameterizedTypeReference<GenericResponse<ObjectResponse<StaticsResource>>>() {
                        });
        return response.getObject();
    }
}
