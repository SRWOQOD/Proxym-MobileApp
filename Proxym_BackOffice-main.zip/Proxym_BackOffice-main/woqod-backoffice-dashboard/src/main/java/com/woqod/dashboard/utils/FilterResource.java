package com.woqod.dashboard.utils;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilterResource {
    private String qid;
    private LocalDate dateFrom;
    private LocalDate dateTo;
}
