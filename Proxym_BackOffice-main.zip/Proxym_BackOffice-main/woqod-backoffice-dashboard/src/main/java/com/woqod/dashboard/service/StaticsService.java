package com.woqod.dashboard.service;

import wq.woqod.resources.resources.StaticsResource;

import java.util.Map;

public interface StaticsService {

    StaticsResource getStatics(Map<String, String> uri);
}
