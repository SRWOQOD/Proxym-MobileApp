package com.woqod.dashboard;

import org.springframework.stereotype.Component;

/**
 * @author med-amine.dahmen
 * on 06/30/2020
 */
@Component
public class DashboardBootstrap {


}
