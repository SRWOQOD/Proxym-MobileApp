package com.woqod.dashboard.service;

import com.woqod.dashboard.rest.StaticsRestClient;
import org.springframework.stereotype.Service;
import wq.woqod.resources.resources.StaticsResource;

import java.util.Map;

@Service
public class StaticsServiceImpl implements StaticsService {
    private final StaticsRestClient staticsRestClient;

    public StaticsServiceImpl(StaticsRestClient staticsRestClient) {
        this.staticsRestClient = staticsRestClient;
    }


    @Override
    public StaticsResource getStatics(Map<String, String> uri) {
        return staticsRestClient.getStatics(uri);
    }
}
