package com.woqod.dashboard.utils;

public final class Constants {
    public static final String DASHBOARD_URL = "/dashboard";
    public static final String DASHBOARD_VIEW = "dashboard";
    public static final String BUNDLE_NAME = "dashboard_messages";

    private Constants() {
    }

}
