package com.woqod.dashboard.controller;

import com.woqod.bo.commons.security.Permissions;
import com.woqod.dashboard.utils.Constants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import static com.woqod.dashboard.utils.Constants.DASHBOARD_VIEW;

@Controller
@RequestMapping(value = Constants.DASHBOARD_URL)
@Data
@Slf4j
public class DashboardController {

    private final Permissions permissions;
    String displayDash = "DISPLAY_DASHBOARD";

    public DashboardController(Permissions permissions) {
        this.permissions = permissions;
    }


    @GetMapping
    public ModelAndView display() {
        return new ModelAndView(DASHBOARD_VIEW);

    }


}
