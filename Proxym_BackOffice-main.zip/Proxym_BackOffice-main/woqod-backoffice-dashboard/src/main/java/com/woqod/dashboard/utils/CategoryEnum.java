package com.woqod.dashboard.utils;

public enum CategoryEnum {

    //    LOGIN("Login"),
    WOQODE_TRANSACTION("WOQODe Transaction"),
    FAHES_TRANSACTION("Fahes Transaction"),
    FAHES_AMOUNT("Fahes Total Amount Transaction"),
    WOQODE_AMOUNT("WOQODe Total Amount Transaction"),
    USERS("Users");

    private String description;

    CategoryEnum(String description) {

        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
