package com.woqod.fahes.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.fahes.domain.models.FahesReceiptModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class FahesReceiptResponse(
    val reference: String?,
    val receipt: String?,
    val decision: String?,
    val transactionUUID: String?,
    @SerializedName("Response") val response: String?,
    @SerializedName("Response_AR") val responseAr: String?,
    @SerializedName("API_AR") val apiAr: String?,
    @SerializedName("API") val api: String?
) : DomainMapper<FahesReceiptModel> {
    override fun mapToDomainModel() = FahesReceiptModel(
        reference = reference ?: "",
        receipt = receipt ?: "",
        decision = decision ?: "",
        transactionUUID = transactionUUID ?: "",
        response = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) responseAr else response) ?: "",
        api = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) apiAr else api) ?: ""
    )
}