package com.woqod.fahes.presentation.booking

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.view.children
import androidx.core.view.isVisible
import com.kizitonwose.calendarview.model.CalendarDay
import com.kizitonwose.calendarview.model.DayOwner
import com.kizitonwose.calendarview.ui.DayBinder
import com.kizitonwose.calendarview.ui.ViewContainer
import com.kizitonwose.calendarview.utils.next
import com.kizitonwose.calendarview.utils.previous
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.CalendarDayLayoutBinding
import com.woqod.fahes.databinding.FragmentFahesBookingDateBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.AvailableStationModel
import com.woqod.fahes.domain.models.InspectionRegisterModel
import com.woqod.fahes.domain.models.ReservationModel
import com.woqod.fahes.presentation.utils.*
import com.woqod.shared.R
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import com.woqod.shared.utils.FAHES_BOOK_DATE_ARGS
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.*

class FahesBookingDateFragment :
    BaseViewModelFragment<FahesBookingViewModel, FragmentFahesBookingDateBinding>(
        FragmentFahesBookingDateBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesBookingViewModel by injectViewModel()

    private val container: ViewGroup by lazy { activity.findViewById<View>(android.R.id.content) as ViewGroup }
    private lateinit var popUpBookingDetails: BookingDetailsPopUp

    private var navigationModel: FahesBookingNavigationModel? = null
    private var vehicleShape: String = EMPTY_FIELD
    private var preReservationId: Long? = null
    private var availableStationsList: List<AvailableStationModel>? = null
    private var selectedStationsId: Int? = null
    private var selectedTimeSlotId: String? = null
    private var selectedTimeSlot: String = ""
    private lateinit var inspectionCar: CarModel
    private var canPayOnlineClicked = false

    private var selectedDate: LocalDate? = null
    private val today = LocalDate.now()
    private val monthTitleFormatter = DateTimeFormatter.ofPattern("MMMM")

    private val timeSlotsAdapter: TimeSlotsAdapter by lazy {
        TimeSlotsAdapter(mutableListOf()) { slot, time ->
            selectedTimeSlotId = slot.id
            selectedTimeSlot = time
        }
    }

    fun newInstance(model: FahesBookingNavigationModel): FahesBookingDateFragment {
        val args = Bundle()
        args.putSerializable(FAHES_BOOK_DATE_ARGS, model)
        val fragment = FahesBookingDateFragment()
        fragment.arguments = args
        return fragment
    }

    override fun onBackPressCustomAction() {
        if (this::popUpBookingDetails.isInitialized && !popUpBookingDetails.isVisible) {
            viewModel.navigate(Navigation.FAHES, null)
        }
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        fahesComponent.inject(this)
        disableDefaultBackPress(disable = true)
        arguments?.let {
            navigationModel =
                it.getSerializable(FAHES_BOOK_DATE_ARGS) as FahesBookingNavigationModel
            preReservationId = navigationModel?.preReservationId
            vehicleShape = navigationModel?.vehicleShape ?: EMPTY_FIELD
        }
        popUpBookingDetails = BookingDetailsPopUp(requireContext()).apply {
            container.addView(this)
            hide()
        }
        viewModel.getAvailableStations(preReservationId.toString())
        initCalendar()
        initClickListeners()

    }

    private fun initSpinner(list: List<AvailableStationModel>?) {
        list?.let { listStations ->
            availableStationsList = listStations
            binding.spinnerFahesBookingStation.initSpinner(
                activity,
                listStations.map { it.name }) { onSelectStations(it) }
        }
    }

    private fun resetSlots() {
        selectedTimeSlotId = null
        selectedTimeSlot = ""
    }

    private fun onSelectStations(name: String) {
        binding.spinnerFahesBookingStation.setValue(name)
        resetSlots()
        selectedStationsId = availableStationsList?.find { it.name == name }?.id ?: 0
        viewModel.getAppointmentDates(
            hashMapOf(
                PRE_RESERVATION_ID to preReservationId.toString(),
                STATION_ID to selectedStationsId.toString()
            )
        )
        selectedDate = today
        getSLots()
    }

    override fun initObservers() {
        viewModel.resultAvailableStations.observe(viewLifecycleOwner, {
            it.result?.let { list -> initSpinner(list) }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        })

        viewModel.resultAppointmentDates.observe(viewLifecycleOwner, { result ->
            result.result?.let { list -> initCalendar(list.map { it.date }) }
                ?: initCalendar(listOf())
            result.error?.let { error -> togglePopUp(error, isFahes = true) }
        })

        viewModel.resultTimeSlots.observe(viewLifecycleOwner, {
            it.result?.let { list ->
                if (list.isEmpty()) {
                    binding.tvFahesBookingTimeTip.show()
                    binding.tvFahesBookingTimeTip.text =
                        getString(com.woqod.fahes.R.string.FahesBookingNoSlotsAvailable)
                    binding.tvFahesBookingTimeTitle.hide()
                    timeSlotsAdapter.resetList()
                } else {
                    binding.tvFahesBookingTimeTip.show()
                    binding.tvFahesBookingTimeTip.hide()
                    binding.tvFahesBookingTimeTitle.show()
                    binding.recyclerFahesBookingTime.show()
                    binding.recyclerFahesBookingTime.adapter = timeSlotsAdapter
                    timeSlotsAdapter.updateList(list)
                }
            }
            it.error?.let {
                binding.recyclerFahesBookingTime.hide()
            }
        })

        viewModel.resultReservation.observe(viewLifecycleOwner, {
            it.result?.let { handleReservationSuccess() }
            it.error?.let { error ->
                popUpBookingDetails.hide()
                    togglePopUp(error.getTitle(), isFahes = true, action = {
                        if ( error.statusCode == DUPLICATE_RESERVATION_ERROR_CODE) {
                            viewModel.navigate(Navigation.FAHES,null)
                        } else {
                            getSLots()
                        }
                         })
                }
            }
        )

        viewModel.resultReservationRescheduling.observe(this) {
            it.result?.let { newReservationId ->
                popUpBookingDetails.hide()
                viewModel.getAvailableStations(newReservationId.toString())
            }
            it.error?.let { error ->
                togglePopUp(
                    error,
                    isFahes = true,
                    action = { viewModel.navigate(Navigation.FAHES, null) })
            }
        }

        viewModel.onCheckIsOwnerCar.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetCarDetails(result) }
            it.error?.let { error ->
                togglePopUp(
                    error,
                    isFahes = true,
                    action = { viewModel.navigate(Navigation.FAHES, null) })
            }
        })

        viewModel.onGetFee.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetFee(result) }
            it.error?.let { error ->
                togglePopUp(
                    error,
                    isFahes = true,
                    action = { viewModel.navigate(Navigation.FAHES, null) })
            }
        })

        viewModel.onGetCanPayOnline.observe(viewLifecycleOwner) {
            it.result?.let { canPayOnline -> toggleDetailsPopUp(createReservationModel(canPayOnline)) }
            it.error?.let { toggleDetailsPopUp(createReservationModel(canPayOnline = false)) }
        }
    }

    private fun initClickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }

        binding.tvFahesBookingProceed.setOnClickListener { onProceed() }
        calendarNavigationArrows()
    }

    private fun handleReservationSuccess() {
        if (canPayOnlineClicked)
            onPaymentProcess()
        else
            confirmAndExit()
    }


    private fun createReservationModel(canPayOnline: Boolean = true) = ReservationModel(
        reservationId = "",
        stationName = binding.spinnerFahesBookingStation.getValue(),
        appointmentDate = selectedDate.toString(),
        time = selectedTimeSlot,
        canPayOnline = canPayOnline,
        plateNumber = "",
        plateTypeName = "",
        slotTime = selectedTimeSlot
    )


    private fun createReservation() {
        viewModel.postReservation(
            hashMapOf(
                PRE_RESERVATION_ID to preReservationId.toString(),
                SLOT_ID to selectedTimeSlotId.toString(),
                USER_TYPE to (navigationModel?.customerType ?: ""),
                VEHICLE_SHAPE_NAME to vehicleShape
            )
        )
    }

    private fun onProceed() {

        whileNotNull(selectedTimeSlot, selectedDate, selectedTimeSlotId,
            action = {
                viewModel.canPayOnline(
                    hashMapOf(
                        PRE_RESERVATION_ID to preReservationId.toString(),
                        SLOT_ID to selectedTimeSlotId.toString()
                    )
                )
            },
            ifNull = {
                togglePopUp(
                    getString(com.woqod.fahes.R.string.FahesBookingTimeTip),
                    isFahes = true
                )
            }
        )
    }

    private fun toggleDetailsPopUp(details: ReservationModel) {
        popUpBookingDetails.show()
        popUpBookingDetails.initBookingDetailsPopUpComponent(
            BookingDetailsModel(
                station = details.stationName,
                date = selectedDate.toString().toFormattedDate(DateTimeFormatter.ISO_LOCAL_DATE),
                time = details.slotTime,
                isNewBooking = true,
                canPayOnline = details.canPayOnline
            ),
            actionFirstButton = {
                canPayOnlineClicked = false
                createReservation()
            },
            actionSecondButton = { popUpBookingDetails.hide() },
            actionThirdButton = {
                canPayOnlineClicked = true
                createReservation()
            },
            actionText = { viewModel.navigate(Navigation.FAHES, null) }
        )
    }

    private fun calendarNavigationArrows() {
        goToNextMonth()
        goToPreviousMonth()
    }

    private fun goToNextMonth() {
        with(binding) {
            icCalendarNextArrow.setOnClickListener {
                calendarView.findFirstVisibleMonth()?.let {
                    calendarView.smoothScrollToMonth(it.yearMonth.next)
                }
            }

        }
    }

    private fun goToPreviousMonth() {
        with(binding) {
            icCalendarBackArrow.setOnClickListener {
                calendarView.findLastVisibleMonth()?.let {
                    calendarView.smoothScrollToMonth(it.yearMonth.previous)
                }
            }

        }
    }

    private fun getSLots() = viewModel.getTimeSlots(
        hashMapOf(
            PRE_RESERVATION_ID to preReservationId.toString(),
            STATION_ID to selectedStationsId.toString(),
            DATE to selectedDate.toString()
        )
    )

    private fun initCalendar(dates: List<String> = listOf()) {
        val daysOfWeek = daysOfWeekFromLocale()
        binding.legendLayout.root.children.forEachIndexed { index, view ->
            (view as TextView).apply {
                text = daysOfWeek[index].getDisplayName(
                    TextStyle.SHORT,
                    Locale(activity.resources.configuration.locales[0].displayLanguage)
                )
                    .toUpperCase(Locale.ENGLISH)
            }
        }

        val currentMonth = YearMonth.now()
        val startMonth = currentMonth.minusMonths(0)
        val endMonth = currentMonth.plusMonths(11)
        binding.calendarView.setup(startMonth, endMonth, daysOfWeek.first())
        binding.calendarView.scrollToMonth(currentMonth)

        class DayViewContainer(view: View) : ViewContainer(view) {
            // Will be set when this container is bound. See the dayBinder.
            lateinit var day: CalendarDay
            val textView = CalendarDayLayoutBinding.bind(view).root

            init {
                view.setOnClickListener {
                    if (day.owner == DayOwner.THIS_MONTH && day.date.toString() in dates) {
                        selectedDate = day.date
                        binding.calendarView.notifyCalendarChanged()
                        viewModel.getTimeSlots(
                            hashMapOf(
                                PRE_RESERVATION_ID to preReservationId.toString(),
                                STATION_ID to selectedStationsId.toString(),
                                DATE to selectedDate.toString()
                            )
                        )
                    }
                }
            }
        }

        binding.calendarView.dayBinder = object : DayBinder<DayViewContainer> {
            override fun create(view: View) = DayViewContainer(view)
            override fun bind(container: DayViewContainer, day: CalendarDay) {
                container.day = day
                val textView = container.textView
                textView.text = day.day.toString()

                if (day.owner == DayOwner.THIS_MONTH && day.date.toString() in dates) {
                    when (day.date) {
                        selectedDate -> {
                            textView.setSelectedDayColor(
                                R.color.colorWhite,
                                com.woqod.fahes.R.drawable.bg_calendar_selected_date
                            )
                        }
                        else -> {
                            textView.textColor(R.color.color_222222)
                            textView.background = null
                        }
                    }
                } else if (today == day.date) {
                    textView.setSelectedDayColor(
                        R.color.color_222222_40,
                        com.woqod.fahes.R.drawable.bg_calendar_today
                    )
                } else if (day.owner == DayOwner.THIS_MONTH) {
                    textView.textColor(R.color.color_222222_40)
                    textView.background = null
                } else {
                    textView.textColor(R.color.colorWhite)
                    textView.background = null
                }
            }
        }

        binding.calendarView.monthScrollListener = {
            binding.exOneMonthText.text =
                "${monthTitleFormatter.format(it.yearMonth)} ${it.yearMonth.year}"
        }
    }

    private fun TextView.setSelectedDayColor(
        @DrawableRes textColor: Int,
        @DrawableRes backgroundColor: Int? = null
    ) {
        textColor(textColor)
        if (backgroundColor != null) setBackgroundResource(backgroundColor) else background =
            backgroundColor
    }

    private fun confirmAndExit() {
        container.removeView(popUpBookingDetails)
        viewModel.navigate(Navigation.FAHES, null)
    }

    private fun onPaymentProcess() {
        viewModel.checkIsOwnerCar(
            hashMapOf(
                QID to (FahesCache.bookingDetails?.qid ?: ""),
                PLATE_NUMBER to (FahesCache.bookingDetails?.plateNumber ?: ""),
                PLATE_TYPE_ID to (FahesCache.bookingDetails?.plateType ?: "")
            )
        )
    }

    private fun onGetCarDetails(car: CarModel) {
        inspectionCar = car
        viewModel.getCarInspectionFee(
            hashMapOf(
                QID to (FahesCache.bookingDetails?.qid ?: ""),
                PLATE_NUMBER to (FahesCache.bookingDetails?.plateNumber ?: ""),
                PLATE_TYPE_ID to (FahesCache.bookingDetails?.plateType ?: "")
            )
        )
    }

    private fun onGetFee(preRegistrationFeeModel: PreRegistrationFeeModel) {
        container.removeView(popUpBookingDetails)
        with(preRegistrationFeeModel) {
            if (category.fee >= 0.0) {
                if (sharedPreferences.isUserLoggedIn()) {
                    FahesCache.inspectionDetails =
                        InspectionRegisterModel(
                            sharedPreferences.user?.let {
                                inspectionCar.copy(owner = it, ownerQid = it.qid.encode64())
                            } ?: inspectionCar
                            , preRegistrationFeeModel, null)
                } else {
                    FahesCache.inspectionDetails = InspectionRegisterModel(
                        inspectionCar,
                        preRegistrationFeeModel,
                        FahesCache.guestDetails
                    )
                }
                viewModel.navigate(
                    Navigation.FAHES_PRE_REGISTRATION_CONFIRMATION,
                    FahesPreRegisterNavigationModel(true)
                )
            } else {
                toast("navigate to payment directly")
            }
        }
    }

}