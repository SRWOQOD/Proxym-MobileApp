package com.woqod.fahes.domain.models

import com.google.gson.annotations.SerializedName
import com.woqod.shared.commun.CURRENCY_QAR
import java.util.*


data class FahesTransactionUUIDModel(
    @SerializedName("userID")
    val userID: String,
    @SerializedName("qid")
    val qid: String,
    @SerializedName("mobile")
    val mobile: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("amount")
    val amount: String,
    @SerializedName("inspection_type")
    val inspectionType: String,
    @SerializedName("service_category")
    val serviceCategory: String,
    @SerializedName("category_id")
    val categoryId: String,
    @SerializedName("category_name_en")
    val categoryNameEn: String,
    @SerializedName("category_name_ar")
    val categoryNameAr: String,
    @SerializedName("category_fee")
    val categoryFee: String,
    @SerializedName("plate_number")
    val plateNumber: String,
    @SerializedName("plate_type")
    val plateType: String,
    @SerializedName("referenceNumber")
    val referenceNumber: String,
    @SerializedName("currency")
    val currency: String = CURRENCY_QAR,
    @SerializedName("transactionUUID")
    val transactionUUID: String = UUID.randomUUID().toString(),
    @SerializedName("anonym")
    val anonym: Boolean,
    @SerializedName("mobileNumber")
    val mobileNumber: String
)

