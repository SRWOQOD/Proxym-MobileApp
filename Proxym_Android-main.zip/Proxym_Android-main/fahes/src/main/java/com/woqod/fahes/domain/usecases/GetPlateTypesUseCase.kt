package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.FahesPlateTypesModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


typealias GetFahesPlateTypesBaseUseCase = BaseUseCase<WoqodResult<SharedResponse<List<FahesPlateTypesModel>>>>

class GetFahesPlateTypesUseCase @Inject constructor(
    private val fahesRepository: FahesRepository
) : GetFahesPlateTypesBaseUseCase {

    override suspend operator fun invoke() =
        fahesRepository.getFahesPlateTypes()
}