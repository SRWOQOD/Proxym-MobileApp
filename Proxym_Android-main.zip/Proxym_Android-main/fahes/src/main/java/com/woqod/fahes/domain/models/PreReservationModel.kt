package com.woqod.fahes.domain.models

data class PreReservationModel(
    val otpRetriesLeftCount: String,
    val preReservationReferenceId: Long?
)
