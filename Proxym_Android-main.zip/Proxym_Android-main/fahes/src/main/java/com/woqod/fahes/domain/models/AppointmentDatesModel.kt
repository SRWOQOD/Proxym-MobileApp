package com.woqod.fahes.domain.models

data class AppointmentDatesModel(val date: String)
