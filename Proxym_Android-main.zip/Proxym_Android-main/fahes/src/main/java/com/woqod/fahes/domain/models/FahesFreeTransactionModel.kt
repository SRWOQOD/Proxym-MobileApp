package com.woqod.fahes.domain.models

import com.woqod.shared.commun.CURRENCY_QAR
import java.util.*


data class FahesFreeTransactionModel(
    val userID: String,
    val qid: String,
    val mobile: String,
    val email: String,
    val amount: Double,
    val inspectionType: Int,
    val serviceCategory: String,
    val categoryId: Int,
    val categoryNameEn: String,
    val categoryNameAr: String,
    val categoryFee: Double,
    val plateNumber: String,
    val plateType: Int,
    val currency: String = CURRENCY_QAR,
    val transactionUUID: String = UUID.randomUUID().toString()
)