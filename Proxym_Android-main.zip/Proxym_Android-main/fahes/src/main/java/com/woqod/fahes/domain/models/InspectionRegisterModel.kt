package com.woqod.fahes.domain.models

import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import java.io.Serializable


data class InspectionRegisterModel(
    val carModel: CarModel,
    val preRegistrationFee: PreRegistrationFeeModel,
    var guestDetails: GuestInspectionRequestModel?
) : Serializable