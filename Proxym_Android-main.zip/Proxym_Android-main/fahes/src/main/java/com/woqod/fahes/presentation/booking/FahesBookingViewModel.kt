package com.woqod.fahes.presentation.booking

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.fahes.domain.models.*
import com.woqod.fahes.domain.usecases.*
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.encode64
import com.woqod.shared.commun.extensions.toStringHashMap
import com.woqod.shared.commundata.models.Header
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import kotlinx.coroutines.launch
import javax.inject.Inject

class FahesBookingViewModel @Inject constructor(
    private val getPlateTypeWithShapeUseCase: GetPlateTypeWithShapeUseCase,
    private val postPreReservationUseCase: PostPreReservationUseCase,
    private val postFahesOtpUseCase: PostFahesOtpUseCase,
    private val getAvailableStationsUseCase: GetAvailableStationsUseCase,
    private val getAppointmentDatesUseCase: GetAppointmentDatesUseCase,
    private val getTimeSlotsUseCase: GetTimeSlotsUseCase,
    private val postReservationUseCase: PostReservationUseCase,
    private val getReservationsUseCase: GetReservationsUseCase,
    private val getReservationGuestUseCase: GetReservationGuestUseCase,
    private val getReservationsReschedulingUseCase: GetReservationsReschedulingUseCase,
    private val cancelReservationUseCase: CancelReservationUseCase,
    private val getCheckIsOwnerCarUseCase: GetCheckIsOwnerCarUseCase,
    private val getCarInspectionFeeUseCase: GetCarInspectionFeeUseCase,
    private val postCanPayOnline: PostCanPayOnline,
    private val resendReservationOtp: ResendReservationOtp,
    private val getCarsListUseCase: GetCarsListUseCase,
    private val checkRegistrationValidity: PostCheckRegistrationValidity
) : BaseViewModel() {

    private val _onCheckValiditySuccess = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckValiditySuccess: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckValiditySuccess
    fun checkQidValidity(query: HashMap<String, Any>) {
        viewModelScope.launch {

            _onCheckValiditySuccess.postValue(ResultUseCase(true, null))
        }
    }


    private val _resultPlateTypesWithShape =
        SingleLiveEvent<ResultUseCase<List<PlateTypeWithShapeModel>?, String?>>()
    val resultPlateTypesWithShape: LiveData<ResultUseCase<List<PlateTypeWithShapeModel>?, String?>> =
        _resultPlateTypesWithShape

    fun getPlateTypeWithShape() {
        viewModelScope.launch {
            _resultPlateTypesWithShape.postValue(executeUseCase(getPlateTypeWithShapeUseCase))
        }
    }

    private val _resultPreReservation =
        SingleLiveEvent<ResultUseCase<PreReservationModel?, String?>>()
    val resultPreReservation: LiveData<ResultUseCase<PreReservationModel?, String?>> =
        _resultPreReservation

    fun postPreReservation(data: PreReservationRequest) {
        val query = hashMapOf(
            MOBILE_NUMBER to data.mobileNumber,
            PLATE_NUMBER_UPPER to data.plateNumber,
            RESERVATION_PLATE_TYPE_ID to data.plateTypeId,
            VEHICLE_SHAPE_ID to data.vehicleShapeId,
            CUSTOMER_ID to data.customerId.encode64()
        )

        viewModelScope.launch {
            _resultPreReservation.postValue(
                executeUseCase(
                    postPreReservationUseCase,
                    query.toStringHashMap()
                )
            )
        }
    }

    private val _resultOtp = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultOtp: LiveData<ResultUseCase<Boolean?, String?>> = _resultOtp
    fun postOtp(preReservationId: String, otp: String) {
        val query = hashMapOf(
            PRE_RESERVATION_ID to preReservationId,
            OTP to otp
        )

        viewModelScope.launch {
            _resultOtp.postValue(executeUseCase(postFahesOtpUseCase, query))
        }
    }

    private val _resultAvailableStations =
        SingleLiveEvent<ResultUseCase<List<AvailableStationModel>?, String?>>()
    val resultAvailableStations: LiveData<ResultUseCase<List<AvailableStationModel>?, String?>> =
        _resultAvailableStations

    fun getAvailableStations(preReservationId: String) {
        viewModelScope.launch {
            _resultAvailableStations.postValue(
                executeUseCase(
                    getAvailableStationsUseCase,
                    hashMapOf(PRE_RESERVATION_ID to preReservationId)
                )
            )
        }
    }

    private val _resultAppointmentDates =
        SingleLiveEvent<ResultUseCase<List<AppointmentDatesModel>?, String?>>()
    val resultAppointmentDates: LiveData<ResultUseCase<List<AppointmentDatesModel>?, String?>> =
        _resultAppointmentDates

    fun getAppointmentDates(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultAppointmentDates.postValue(executeUseCase(getAppointmentDatesUseCase, query))
        }
    }

    private val _resultTimeSlots = SingleLiveEvent<ResultUseCase<List<TimeSlotsModel>?, String?>>()
    val resultTimeSlots: LiveData<ResultUseCase<List<TimeSlotsModel>?, String?>> = _resultTimeSlots
    fun getTimeSlots(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultTimeSlots.postValue(executeUseCase(getTimeSlotsUseCase, query))
        }
    }

    private val _resultReservation = SingleLiveEvent<ResultUseCase<ReservationModel?, Header?>>()
    val resultReservation: LiveData<ResultUseCase<ReservationModel?, Header?>> = _resultReservation
    fun postReservation(query: HashMap<String, String>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            postReservationUseCase(query)
                .onSuccess {
                    showLoadingToggle(false)
                    _resultReservation.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultReservation.postValue(ResultUseCase(null, it.errorHeader))
                }
        }
    }

    private val _resultAvailableReservation =
        SingleLiveEvent<ResultUseCase<List<ReservationModel>?, String?>>()
    val resultAvailableReservation: LiveData<ResultUseCase<List<ReservationModel>?, String?>> =
        _resultAvailableReservation

    fun getAvailableReservation(qid: String) {
        viewModelScope.launch {
            _resultAvailableReservation.postValue(executeUseCase(getReservationsUseCase, qid))
        }
    }
    private val _resultAvailableReservationGuest =
        SingleLiveEvent<ResultUseCase<ReservationModel?, String?>>()
    val resultAvailableReservationGuest: LiveData<ResultUseCase<ReservationModel?, String?>> =
        _resultAvailableReservationGuest

    fun getAvailableReservationGuest(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultAvailableReservationGuest.postValue(executeUseCase(getReservationGuestUseCase, query))
        }
    }

    private val _resultReservationRescheduling = SingleLiveEvent<ResultUseCase<Long?, String?>>()
    val resultReservationRescheduling: LiveData<ResultUseCase<Long?, String?>> =
        _resultReservationRescheduling

    fun rescheduleReservation(reservationId: String) {
        viewModelScope.launch {
            _resultReservationRescheduling.postValue(
                executeUseCase(
                    getReservationsReschedulingUseCase,
                    reservationId
                )
            )
        }
    }

    private val _resultCancelReservation = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultCancelReservation: LiveData<ResultUseCase<Boolean?, String?>> =
        _resultCancelReservation

    fun cancelReservation(query: HashMap<String, String>) {
        viewModelScope.launch {
            _resultCancelReservation.postValue(executeUseCase(cancelReservationUseCase, query))
        }
    }

    private val _onCheckIsOwnerCar = SingleLiveEvent<ResultUseCase<CarModel?, String?>>()
    val onCheckIsOwnerCar: LiveData<ResultUseCase<CarModel?, String?>> = _onCheckIsOwnerCar
    fun checkIsOwnerCar(query: HashMap<String, Any>) {
        viewModelScope.launch {
            getCheckIsOwnerCarUseCase(query)
                .onSuccess {
                    showLoadingToggle(false)
                    _onCheckIsOwnerCar.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onCheckIsOwnerCar.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    private val _onGetFee = SingleLiveEvent<ResultUseCase<PreRegistrationFeeModel?, String?>>()
    val onGetFee: LiveData<ResultUseCase<PreRegistrationFeeModel?, String?>> = _onGetFee
    fun getCarInspectionFee(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetFee.postValue(executeUseCase(getCarInspectionFeeUseCase, query))
        }
    }

    private val _onResendOtp = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onResendOtp: LiveData<ResultUseCase<Boolean?, String?>> = _onResendOtp
    fun resendOpt(query: HashMap<String, String>) {
        viewModelScope.launch {
            _onResendOtp.postValue(executeUseCase(resendReservationOtp, query))
        }
    }

    private val _onGetOwnerListCars = SingleLiveEvent<ResultUseCase<List<CarModel>?, String?>>()
    val onGetOwnerListCars: LiveData<ResultUseCase<List<CarModel>?, String?>> = _onGetOwnerListCars

    fun getCarsList(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetOwnerListCars.postValue(executeUseCase(getCarsListUseCase, query))
        }
    }

    private val _onGetCanPayOnline = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onGetCanPayOnline: LiveData<ResultUseCase<Boolean?, String?>> = _onGetCanPayOnline

    fun canPayOnline(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetCanPayOnline.postValue(executeUseCase(postCanPayOnline, query))
        }
    }

    private val _onCheckRegistrationValidity = SingleLiveEvent<ResultUseCase<VehiculeRegistrationModel?, String?>>()
    val onCheckRegistrationValidity: LiveData<ResultUseCase<VehiculeRegistrationModel?, String?>> = _onCheckRegistrationValidity
    fun checkRegistrationValidity(query: HashMap<String, Any>){
        viewModelScope.launch {
            _onCheckRegistrationValidity.postValue(executeUseCase(checkRegistrationValidity,query))
        }
    }
}