package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.PlateTypeWithShapeModel
import com.woqod.fahes.domain.models.VehicleShapeModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class PlateTypeWithShapeResponse(
    val plateTypeId: String?,
    val plateTypeNameAr: String?,
    val plateTypeNameEn: String?,
    val vehicleShapes: List<VehicleShapeResponse>?
) : DomainMapper<PlateTypeWithShapeModel> {
    override fun mapToDomainModel() = PlateTypeWithShapeModel(
        plateTypeId = plateTypeId,
        plateTypeName = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) plateTypeNameAr else plateTypeNameEn) ?: "",
        vehicleShapes = vehicleShapes?.map { it.mapToDomainModel() } ?: listOf()
    )
}

data class VehicleShapeResponse(
    val id: String = "",
    val nameAr: String?,
    val nameEn: String?
) : DomainMapper<VehicleShapeModel> {
    override fun mapToDomainModel() = VehicleShapeModel(
        id = id,
        name = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) nameAr else nameEn) ?: ""
    )
}