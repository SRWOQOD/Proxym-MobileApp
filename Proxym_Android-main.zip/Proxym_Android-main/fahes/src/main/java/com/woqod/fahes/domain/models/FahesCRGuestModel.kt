package com.woqod.fahes.domain.models

import com.woqod.shared.commun.INDIVIDUAL_CUSTOMER
import java.io.Serializable

data class FahesCRGuestModel(
    val qid : String,
    val mobile : String,
    val carPlate : String,
    val plateType : String,
    val customerType : String
):Serializable {
    constructor() : this("","","","", INDIVIDUAL_CUSTOMER)


}
