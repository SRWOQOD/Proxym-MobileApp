package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.DefectModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

open class GetInspectionDetailsUseCase @Inject constructor(
    private val fahesRepository: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<SharedResponse<List<DefectModel>>>> {

    override suspend operator fun invoke(request: HashMap<String, Any>) =
        fahesRepository.getFahesInspectionDetails(request)
}