package com.woqod.fahes.domain.models

import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.UserDetailsModel
import java.io.Serializable

data class FahesInspectionModel(
    val id: Long,
    val error: String,
    val inspectedOn: String,
    val legalEvaluation: String,
    val mileage: String,
    val owner: UserDetailsModel,
    val station: InspectionStationModel,
    val technicalEvaluation: String,
    val vehicle: CarModel
) : Serializable

data class InspectionStationModel(
    val _id: String,
    val id: String,
    val name: String
) : Serializable {
    constructor() : this("", "", "")
}

data class InspectionDetailsModel(
    val defectTypeLegal: List<DefectModel>,
    val defectTypeTechnial: List<DefectModel>,
    val defectTypeComment: List<DefectModel>,
) : Serializable

data class DefectModel(
    val defectTypeId : Long,
    val defectCode: String,
    val defectCommentName: String,
    val defectCommentDescp: String,
    val additionalComment: String,
    val location: String,
    val evaluation: Evaluation

) : Serializable

data class Evaluation(
    val id: Long,
    val name: String
)
