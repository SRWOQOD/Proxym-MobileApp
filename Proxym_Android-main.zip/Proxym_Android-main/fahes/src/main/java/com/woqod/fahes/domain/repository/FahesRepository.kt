package com.woqod.fahes.domain.repository

import com.woqod.fahes.domain.models.*
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel


interface FahesRepository {


    suspend fun getPlateTypeWithShape(): WoqodResult<SharedResponse<List<PlateTypeWithShapeModel>>>
    suspend fun postPreReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<PreReservationModel>>
    suspend fun postFahesOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getAvailableStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AvailableStationModel>>>
    suspend fun getAppointmentDatesByStation(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AppointmentDatesModel>>>
    suspend fun getReservationTimeSlots(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TimeSlotsModel>>>
    suspend fun postReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<ReservationModel>>

    suspend fun getFahesPlateTypes(): WoqodResult<SharedResponse<List<FahesPlateTypesModel>>>
    suspend fun checkCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>>
    suspend fun checkIsOwnerCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>>
    suspend fun getIsOwnerAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>>
    suspend fun getCarsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<CarModel>>>
    suspend fun updateCarStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getCarInspectionFee(request: HashMap<String, Any>): WoqodResult<SharedResponse<PreRegistrationFeeModel>>

    suspend fun getFahesInspection(query: HashMap<String, Any>): WoqodResult<SharedResponse<FahesInspectionModel>>
    suspend fun getFahesInspectionDetails(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<DefectModel>>>
    suspend fun getFahesListReceipts(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<ReceiptModel>>>

    suspend fun postAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postUpdateCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun createTransactionUUID(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun createTransactionUUIDForDebitCard(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendMail(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun createFreeTransaction(request: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptModel>>
    suspend fun paymentSuccess(query: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptModel>>

    suspend fun updateTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getGeneratePDF(refNumber : String) : WoqodResult<SharedResponse<String>>

    suspend fun  getAvailableReservation(qid : String) : WoqodResult<SharedResponse<List<ReservationModel>>>
    suspend fun  getAvailableReservationGuest(query: HashMap<String, Any>) : WoqodResult<SharedResponse<ReservationModel>>
    suspend fun rescheduleReservation(reservationId: String): WoqodResult<SharedResponse<Long>>
    suspend fun cancelReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun resendReservationOtp(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun canPayOnline(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun checkRegistrationValidity(query: HashMap<String, Any>): WoqodResult<SharedResponse<VehiculeRegistrationModel>>
    suspend fun canProceedToBooking(query: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>>
    suspend fun cancelTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

}