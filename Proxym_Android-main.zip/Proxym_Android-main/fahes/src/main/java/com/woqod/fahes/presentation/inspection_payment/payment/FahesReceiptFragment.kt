package com.woqod.fahes.presentation.inspection_payment.payment

import android.os.Build
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import androidx.annotation.RequiresApi
import com.woqod.fahes.R
import com.woqod.fahes.databinding.FragmentFahesReceiptBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.presentation.utils.FahesReceiptNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.RECEIPT_DETAILS
import com.woqod.shared.utils.PermissionsUtils
import com.woqod.shared.widget.PopUpType
import java.util.*


class FahesReceiptFragment :
    BaseViewModelFragment<FahesPaymentViewModel, FragmentFahesReceiptBinding>(
        FragmentFahesReceiptBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
//        if (requestCode == RC_READ_STOARGE || requestCode == RC)
    }

    override val viewModel: FahesPaymentViewModel by injectViewModel()

    private var navigationModel: FahesReceiptNavigationModel? = null
    private var goToFahesText: SpannableString? = null

    fun newInstance(model: FahesReceiptNavigationModel): FahesReceiptFragment {
        val args = Bundle()
        args.putSerializable(RECEIPT_DETAILS, model)
        val fragment = FahesReceiptFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        fahesComponent.inject(this)
        arguments?.let {
            navigationModel = it.getSerializable(RECEIPT_DETAILS) as FahesReceiptNavigationModel
        }
        goToFahesText = SpannableString(getString(R.string.FahesReceiptBackToFahesMenu))
        goToFahesText?.setSpan(UnderlineSpan(), 0, goToFahesText?.length ?: 0, 0)
        binding.tvBackToFahesMenu.text = goToFahesText
        initCLickListeners()
        initReceipt()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initReceipt() {
        navigationModel?.let {
            if (it.pdfFile.isBlank()) {
                viewModel.generatePDF(it.reference)
            } else {
                showReceipt(it.pdfFile)
            }
        }
        binding.receiptPopupImage.minZoom = 2F
    }

    private fun showReceipt(receipt: String) {
        binding.receiptPopupImage.fromBytes(Base64.getDecoder().decode(receipt))
            .onRender { _, _, _ ->
                binding.receiptPopupImage.fitToWidth()
            }
            .enableAnnotationRendering(true)
            .enableSwipe(true)
            .load()
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.FAHES, null)
    }

    override fun initObservers() {
        //  fahes_payment_receipt.onReceiveReceipt.observe(this, ::onReceiveReceipt)
        viewModel.onEmailSent.observe(this) {
            it.result?.let { result ->
                if (result) togglePopUp(
                    getString(R.string.CommonPaymentEmailSent),
                    popUpType = PopUpType.POPUP_SUCCESS,
                    isFahes = true,
                    description = if (sharedPreferences.isUserLoggedIn()) sharedPreferences.user!!.email else navigationModel?.guestEmail
                        ?: ""
                )
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
        viewModel.onTransactionUpdated.observe(this) {
            it.result?.let {
                togglePopUp(
                    getString(com.woqod.shared.R.string.PaymentCancelled),
                    isFahes = true,
                    action = { viewModel.navigate(Navigation.FAHES, null) })
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }

        viewModel.resultGeneratePDF.observe(this) { filePDF ->
            filePDF.result?.let {
                navigationModel?.pdfFile = it
                showReceipt(it)
            }

            filePDF.error?.let { error ->
                togglePopUp(
                    message = error,
                    action = { viewModel.navigate(Navigation.FAHES, null) },
                    isFahes = true
                )
            }


        }
    }


    private fun downloadFile() {
        if (PermissionsUtils().hasWriteStoragePermission(activity)) {
            com.woqod.shared.utils.downloadFileByVersion(
                navigationModel?.pdfFile,
                navigationModel?.reference
            )
            onDownloadComplete()
        } else {
            PermissionsUtils().requestWritePermission(activity)
        }
    }

    private fun onDownloadComplete() {
        togglePopUp(
            getString(R.string.CommonDownloadCompleted),
            popUpType = PopUpType.POPUP_SUCCESS,
            isFahes = true
        )
        toggleLoading(false)
    }

    private fun onSendReceiptByEmail() {
        if (sharedPreferences.isUserLoggedIn()) {
            val email = sharedPreferences.user?.email
            navigationModel?.let {
                viewModel.sendMail(it.reference, email, isConnected = true)
            }
        } else {
            navigationModel?.let {
                viewModel.sendMail(it.reference, it.guestEmail, isConnected = false)
            }
        }

    }

    private fun initCLickListeners() {
        binding.btnFahesDownloadReceipt.setOnClickListener {
            downloadFile()
        }
        binding.btnFahesSendByMail.setOnClickListener { onSendReceiptByEmail() }
        binding.toolbarFahesReceipt.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
        binding.tvBackToFahesMenu.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
    }


}