package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.AppointmentDatesModel
import com.woqod.shared.commundata.DomainMapper

data class AppointmentDatesResponse(val appointmentDate: String?) : DomainMapper<AppointmentDatesModel> {
    override fun mapToDomainModel() = AppointmentDatesModel(
        date = appointmentDate?.let { it.substring(0, it.indexOf('T')) } ?: "0"
    )
}
