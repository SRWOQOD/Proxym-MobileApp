package com.woqod.fahes.domain.models

import java.io.Serializable


data class FahesReceiptModel(
    val reference: String,
    val receipt: String,
    val decision: String,
    val transactionUUID: String,
    val response: String,
    val api:String
) : Serializable