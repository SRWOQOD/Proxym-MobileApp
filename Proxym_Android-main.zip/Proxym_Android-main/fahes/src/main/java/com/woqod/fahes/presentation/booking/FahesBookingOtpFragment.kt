package com.woqod.fahes.presentation.booking

import android.annotation.SuppressLint
import android.os.Bundle
import com.woqod.fahes.R
import com.woqod.fahes.databinding.FragmentFahesBookingOtpBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.presentation.utils.FahesBookingNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PRE_RESERVATION_ID
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.utils.FAHES_BOOK_OTP_ARGS
import com.woqod.shared.widget.PopUpType

class FahesBookingOtpFragment :
    BaseViewModelFragment<FahesBookingViewModel, FragmentFahesBookingOtpBinding>(FragmentFahesBookingOtpBinding::inflate) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesBookingViewModel by injectViewModel()

    private var preReservationId: Long? = null
    private var navigationModel: FahesBookingNavigationModel? = null

    fun newInstance(model: FahesBookingNavigationModel): FahesBookingOtpFragment {
        val args = Bundle()
        args.putSerializable(FAHES_BOOK_OTP_ARGS, model)
        val fragment = FahesBookingOtpFragment()
        fragment.arguments = args
        return fragment
    }


    @SuppressLint("SetTextI18n")
    override fun initViews() {
        fahesComponent.inject(this)
        disableDefaultBackPress(true)
        arguments?.let {
            navigationModel = it.getSerializable(FAHES_BOOK_OTP_ARGS) as FahesBookingNavigationModel
            preReservationId = navigationModel?.preReservationId
        }
        binding.pinCodeComponent.initPinCodeObservers(this,
            doOnResend = { resendActivateCode() },
            doOnConfirm = { verifyOtp() },
            doOnHideKeyBoard = { hideKeyboard() })

        binding.toolbarOtp.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
    }

    override fun initObservers() {
        viewModel.resultOtp.observe(viewLifecycleOwner, {
            it.result?.let { success ->
                if (success) viewModel.navigate(Navigation.FAHES_BOOKING_DATE, navigationModel)
                else { togglePopUp(
                    getString(com.woqod.shared.R.string.OtpWrongPingCodeError),
                    action = {
                             binding.pinCodeComponent.resetValues()
                    },
                    isFahes = true
                )

                }
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        })

        viewModel.onResendOtp.observe(viewLifecycleOwner) {

            it.result?.let { success ->
                if (success) togglePopUp(
                    getString(R.string.please_enter_the_code_sent_to_your_phone),
                    popUpType = PopUpType.POPUP_SUCCESS, isFahes = true
                )
                else togglePopUp(
                    getString(com.woqod.shared.R.string.OtpWrongPingCodeError),
                    action = {
                        binding.pinCodeComponent.resetValues()
                    },
                    isFahes = true
                )
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }

        }
    }

    private fun verifyOtp() {
        viewModel.postOtp(preReservationId.toString(), binding.pinCodeComponent.pinCode())
    }

    private fun resendActivateCode() {
        binding.pinCodeComponent.resetValues()
        viewModel.resendOpt(
            hashMapOf(
                PRE_RESERVATION_ID to preReservationId.toString()
            )
        )
    }


}