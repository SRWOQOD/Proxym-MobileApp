package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.PlateTypeWithShapeModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetPlateTypeWithShapeUseCase @Inject constructor(
    private val fahesRepository: FahesRepository
) : BaseUseCase<WoqodResult<SharedResponse<List<PlateTypeWithShapeModel>>>> {

    override suspend operator fun invoke() = fahesRepository.getPlateTypeWithShape()
}