package com.woqod.fahes.presentation.inspection_payment.pre_registration

import android.text.InputType
import com.woqod.fahes.R
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.FragmentFahesGuestPreRegisterBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.FahesPlateTypesModel
import com.woqod.fahes.domain.models.GuestInspectionRequestModel
import com.woqod.fahes.domain.models.InspectionRegisterModel
import com.woqod.fahes.presentation.utils.FahesPreRegisterNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.AuthenticationErrorCodes.CODE_INSPECTION_FEE_ALREADY_PAID
import com.woqod.shared.commun.AuthenticationErrorCodes.CODE_INSPECTION_FEE_PAYMENT_IN_PROGRESS
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel


class
FahesGuestPreRegisterFragment :
    BaseViewModelFragment<FahesPreRegisterViewModel, FragmentFahesGuestPreRegisterBinding>(FragmentFahesGuestPreRegisterBinding::inflate) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesPreRegisterViewModel by injectViewModel()

    private var customerType: String = INDIVIDUAL_CUSTOMER
    private var plateType: String = EMPTY_FIELD
    private var plateTypeList = listOf<FahesPlateTypesModel>()
    private lateinit var guestInspectionRequest: GuestInspectionRequestModel
    private lateinit var inspectionCar: CarModel


    override fun initViews() {
        fahesComponent.inject(this)
        disableDefaultBackPress(true)
        initCLickListeners()
        viewModel.getPlateTypes()
        initCustomerTypeSpinner()
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.FAHES, null)
    }

    private fun initCLickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            onBackPressCustomAction()
        }
        binding.tvFahesGuestSubmit.setOnClickListener { onSubmit() }
        binding.clFahesGuest.setOnClickListener { hideKeyboard() }
    }

    override fun initObservers() {
        viewModel.resultListPlateTypes.observe(viewLifecycleOwner, {
            it.result?.let { plates ->
                plateTypeList = plates
                initPLateSpinners(plates.map { plate -> plate.name })
            }
            it.error?.let { error -> onError(error, isPop = false) }
        })
        viewModel.onCheckValiditySuccess.observe(viewLifecycleOwner, {
            it.result?.let { result -> onCheckValiditySuccess(result) }
            it.error?.let { error -> onError(error, isPop = false) }
        })
        viewModel.onCheckIsOwnerCar.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetCarDetails(result) }
            it.error?.let { error -> onError(error.getTitle(), isPop = false) }
        })
        viewModel.onGetFee.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetFee(result) }
            it.error?.let { error -> onError(error) }
        })
    }

    private fun initPLateSpinners(plateTypes: List<String>) {
        val customerType = arrayListOf(
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual),
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        )
        binding.spinnerFahesGuestCustomerType.initSpinner(activity, customerType) { onSelectCustomerType(it) }
        binding.spinnerFahesGuestPlateType.initSpinner(activity, plateTypes) { onSelectPlateType(it) }
        binding.spinnerFahesGuestCustomerType.setValue(customerType.first())
        binding.spinnerFahesGuestPlateType.setValue(plateTypes.first())
        onSelectPlateType(plateTypes.first())
    }

    private fun initCustomerTypeSpinner(){
        val customerType = arrayListOf(
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual),
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        )
        binding.spinnerFahesGuestCustomerType.initSpinner(activity, customerType) { onSelectCustomerType(it) }
        binding.spinnerFahesGuestCustomerType.setValue(customerType.first())
    }


    private fun onSelectCustomerType(customer: String) {
        if (customer == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesGuestQid.invisible()
            binding.etFahesGuestCompanyId.show()
        } else {
            binding.etFahesGuestQid.show()
            binding.etFahesGuestCompanyId.hide()
        }.also {
            resetCustomerType()
            customerType = customer
        }
    }

    private fun resetCustomerType() {
        binding.etFahesGuestCompanyId.resetValue()
        binding.etFahesGuestQid.resetValue()
        resetErrors(
            binding.etFahesGuestQid,
            binding.etFahesGuestCompanyId
        )
    }

    private fun onSelectPlateType(plate: String) {
        plateTypeList.find { it.name == plate }?.apply {
            if (id == 1) binding.tvFahesGuestPrivatePlateTip.show()
            else binding.tvFahesGuestPrivatePlateTip.hide()
        }
        plateType = plate
        binding.etFahesGuestCarPlate.hideError()
        if (plateType == context?.resources?.getString(com.woqod.shared.R.string.FahesDiplomaticTypeTitle)) {
            binding.etFahesGuestCarPlate.setInputType(InputType.TYPE_CLASS_TEXT)
            binding.etFahesGuestCarPlate.setMaxInputLength(7)
        } else {
            binding.etFahesGuestCarPlate.setInputType(InputType.TYPE_CLASS_NUMBER)
            binding.etFahesGuestCarPlate.setMaxInputLength(7)
        }
    }

    private fun onSubmit() {
        binding.spinnerFahesGuestCustomerType.hideSpinnerDropDown()
        binding.spinnerFahesGuestPlateType.hideSpinnerDropDown()
        GuestInspectionRequestModel(
            customerType = customerType,
            qid = appropriateId(),
            mobile = binding.etFahesGuestMobile.getValue(),
            carPlate = binding.etFahesGuestCarPlate.getValue(),
            plateTypeId = plateTypeList.find { it.name == plateType }?.id ?: 1,
            email = binding.etFahesGuestEmail.getValue(),
            isCorporate = customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        ).also {
            guestInspectionRequest = it
            if (validateInputs(guestInspectionRequest)) viewModel.onGuestSubmit()
        }
    }

    private fun appropriateId(): String {
        return if (customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesGuestCompanyId.getValue()
        } else {
            binding.etFahesGuestQid.getValue()
        }
    }

    private fun validateInputs(guestInspectionRequestModel: GuestInspectionRequestModel): Boolean {
        var validate = true
        with(guestInspectionRequestModel) {
            val qidError = ValidationsUtils.isIdValid(qid, isCorporate)
            val mobileError = ValidationsUtils.isMobileValid(mobile)
            val carPlateError = ValidationsUtils.isCarPlateValid(carPlate,plateType,context)
            val emailError = ValidationsUtils.isEmailValid(email)
            if (qidError != 0) {
                validate = false
                showQidError(qidError,customerType)
            }
            if (mobileError != 0) {
                validate = false
                binding.etFahesGuestMobile.showError(getString(mobileError))
            }
            if (carPlateError != 0) {
                validate = false
                binding.etFahesGuestCarPlate.showError(getString(carPlateError))
            }
            if (emailError != 0) {
                validate = false
                binding.etFahesGuestEmail.showError(getString(emailError))
            }
        }
        return validate
    }

    private fun showQidError(qidError: Int) {
        if (qidError == R.string.FahesBookingCarPlateTypeError || qidError == R.string.CommonQidNotValid) {
            binding.etFahesGuestQid.showError(getString(qidError))
        } else {
            binding.etFahesGuestCompanyId.showError(getString(qidError))
        }
    }

    private fun showQidError(qidError: Int,customerType : String) {
        when (qidError) {
            R.string.FahesBookingCarPlateTypeError -> {
                setUserIdErrorMsg(customerType,qidError)
            }
            R.string.CommonQidNotValid -> binding.etFahesGuestQid.showError(getString(qidError))
            R.string.CommonCompanyIdInvalid ->   binding.etFahesGuestCompanyId.showError(getString(qidError))
        }
    }

    private fun setUserIdErrorMsg(customerType: String ,error : Int){
        if(customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)){
            binding.etFahesGuestCompanyId.showError(getString(error))
        }else {
            binding.etFahesGuestQid.showError(getString(error))
        }
    }

    private fun onError(message: String, isPop: Boolean = true) {
        val errorMsg = when (message) {
            CODE_INSPECTION_FEE_ALREADY_PAID -> getString(R.string.FahesInspectionPreRegistrationInspectionFeeAlreadyPaid)
            CODE_INSPECTION_FEE_PAYMENT_IN_PROGRESS -> getString(R.string.FahesInspectionPreRegistrationInspectionFeePaymentInProgress)
            else -> message
        }
        togglePopUp(errorMsg, isFahes = true, action = { if (isPop) viewModel.navigate(Navigation.FAHES,null)})
    }

    private fun onCheckValiditySuccess(state: Boolean) {
        if (state) viewModel.checkIsOwnerCar(
            hashMapOf(
                QID to guestInspectionRequest.qid,
                PLATE_NUMBER to guestInspectionRequest.carPlate,
                PLATE_TYPE_ID to guestInspectionRequest.plateTypeId
            )
        )
    }

    private fun onGetCarDetails(car: CarModel) {
            inspectionCar = car
            with(guestInspectionRequest) { viewModel.getCarInspectionFee(qid, carPlate, plateTypeId) }
    }

    private fun onGetFee(preRegistrationFeeModel: PreRegistrationFeeModel) {
        with(preRegistrationFeeModel) {
            if (category.fee >= 0.0) {
                FahesCache.inspectionDetails = InspectionRegisterModel(inspectionCar, preRegistrationFeeModel, guestInspectionRequest)
                viewModel.navigate(Navigation.FAHES_PRE_REGISTRATION_CONFIRMATION, FahesPreRegisterNavigationModel(false))
                viewModel.resetGetFee()
            } else {
                toast("navigate to payment directly")
            }
        }
    }

}