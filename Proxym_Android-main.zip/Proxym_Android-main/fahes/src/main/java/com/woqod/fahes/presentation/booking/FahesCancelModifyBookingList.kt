package com.woqod.fahes.presentation.booking


import com.woqod.fahes.databinding.FragmentCancelModifyBookingListBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.ReservationModel
import com.woqod.fahes.domain.models.UserCancelReservationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.extensions.encode64
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show

class FahesCancelModifyBookingList :
    BaseViewModelFragment<FahesBookingViewModel, FragmentCancelModifyBookingListBinding>(FragmentCancelModifyBookingListBinding::inflate) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }
    override val viewModel: FahesBookingViewModel by injectViewModel()
    private val reservationAdapter: UserReservationsAdapter by lazy {
        UserReservationsAdapter(::onReservationClicked)
    }

    override fun initViews() {
        fahesComponent.inject(this)
        initCLickListeners()
        disableDefaultBackPress(true)
        sharedPreferences.user?.let {
            viewModel.getAvailableReservation(it.qid.encode64())
        }
    }

    override fun initObservers() {
        viewModel.resultAvailableReservation.observe(this) {
            it.result?.let { reservations -> initRecyclerView(reservations) }
            it.error?.let { error ->
                binding.tvNoReservation.hide()
                togglePopUp(error, isFahes = true)
            }
        }
    }


    private fun initCLickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
    }

    private fun initRecyclerView(reservations: List<ReservationModel>) {
        if (reservations.isEmpty()) {
            binding.tvNoReservation.show()
        } else {
            binding.tvNoReservation.hide()
            binding.rvUserReservation.adapter = reservationAdapter
            reservationAdapter.submitList(reservations)
        }
    }

    private fun onReservationClicked(reservationModel: ReservationModel) {
        sharedPreferences.user?.let { user ->

            UserCancelReservationModel(
                fullName = user.fullName(),
                qid = user.qid,
                mobile = user.mobileNumber,
                user.type,
                reservation = reservationModel,

            ).also {
                viewModel.navigate(Navigation.FAHES_CANCEL_BOOKING, it)
            }
        }
    }

    override fun onBackPressCustomAction() {
         viewModel.navigate(Navigation.FAHES, null)
    }
}