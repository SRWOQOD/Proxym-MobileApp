package com.woqod.fahes.presentation.about


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.StaticScreenModel
import com.woqod.shared.commundomain.sharedusecases.GetStaticScreenTextUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class AboutFahesViewModel @Inject constructor(private val getStaticScreenTextUseCase: GetStaticScreenTextUseCase) : BaseViewModel() {

    private val _resultStaticScreen = SingleLiveEvent<ResultUseCase<StaticScreenModel?, String?>>()
    val resultStaticScreen: LiveData<ResultUseCase<StaticScreenModel?, String?>> = _resultStaticScreen

    fun getStaticText(section: String) {
        viewModelScope.launch {
            _resultStaticScreen.postValue(executeUseCase(getStaticScreenTextUseCase, section))
        }
    }
}