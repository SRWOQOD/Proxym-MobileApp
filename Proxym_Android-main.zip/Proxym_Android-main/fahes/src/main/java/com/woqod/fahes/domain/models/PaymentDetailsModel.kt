package com.woqod.fahes.domain.models

import com.woqod.shared.commundomain.models.PaymentRequestModel
import java.io.Serializable


data class PaymentDetailsModel(
    val receiptModel: FahesReceiptModel?,
    val paymentRequest: PaymentRequestModel?,
    val inspectionDetails: InspectionRegisterModel?
):Serializable