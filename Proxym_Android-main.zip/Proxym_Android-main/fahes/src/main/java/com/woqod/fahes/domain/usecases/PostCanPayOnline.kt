package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


class PostCanPayOnline @Inject constructor(
    private val fahesRepository: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<SharedResponse<Boolean>>> {

    override suspend operator fun invoke(request: HashMap<String, Any>) = fahesRepository.canPayOnline(request)
}