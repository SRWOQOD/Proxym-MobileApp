package com.woqod.fahes.presentation.booking

import android.os.Bundle
import android.text.InputType
import com.woqod.fahes.R
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.FragmentFahesBookingCarInfoBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.*
import com.woqod.fahes.presentation.utils.FahesBookingNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.UserDetailsModel
import com.woqod.shared.commundomain.models.UserInspectionRequestModel
import com.woqod.shared.utils.FAHES_BOOK_ARGS

class FahesBookingCarInfoFragment :
    BaseViewModelFragment<FahesBookingViewModel, FragmentFahesBookingCarInfoBinding>(
        FragmentFahesBookingCarInfoBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesBookingViewModel by injectViewModel()

    private var customerType: String = INDIVIDUAL_CUSTOMER
    private var params: UserInspectionRequestModel? = null
    private var plateTypeList = listOf<PlateTypeWithShapeModel>()
    private var vehicleShapeList = listOf<VehicleShapeModel>()
    private var plateType: String = EMPTY_FIELD
    private var vehicleShape: String = EMPTY_FIELD
    private var preReservationId: Long? = null
    private var reservationRequest: PreReservationRequest? = null


    fun newInstance(params: UserInspectionRequestModel): FahesBookingCarInfoFragment {
        val args = Bundle()
        args.putSerializable(FAHES_BOOK_ARGS, params)
        val fragment = FahesBookingCarInfoFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        fahesComponent.inject(this)
        arguments?.let {
            params = it.getSerializable(FAHES_BOOK_ARGS) as UserInspectionRequestModel
        }
        viewModel.getPlateTypeWithShape()
        initClickListeners()
        if (sharedPreferences.isUserLoggedIn()) {
            addUserInformation(sharedPreferences.user)
        } else {
            initSpinners()
            binding.etFahesBookingCustomerType.hide()
        }

    }

    override fun initObservers() {
        viewModel.resultPlateTypesWithShape.observe(viewLifecycleOwner, {
            it.result?.let { platesWithShape ->
                plateTypeList = platesWithShape
                if (!sharedPreferences.isUserLoggedIn()) initPLateTypes(platesWithShape)
                else selectPlateType(
                    params?.plateTypeId.toString() ?: getString(R.string.CommonUndefinedValue)
                )

            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        })




        viewModel.resultPreReservation.observe(viewLifecycleOwner, {
            it.result?.let { response ->
                if (response.otpRetriesLeftCount.toInt() > 0) {
                    preReservationId = response.preReservationReferenceId
                    viewModel.navigate(
                        Navigation.FAHES_OTP,
                        FahesBookingNavigationModel(preReservationId, getCustomerType(),vehicleShape)
                    )
                } else {
                    togglePopUp(getString(R.string.FahesPreReservationError), isFahes = true)
                }
            }
            it.error?.let { error ->
                togglePopUp(
                    error,
                    isFahes = true,
                    action = { viewModel.navigate(Navigation.FAHES, null) })
            }
        })

        viewModel.onCheckRegistrationValidity.observe(viewLifecycleOwner) {
            it.result?.let { VehiculeRegistrationl ->
                if (!VehiculeRegistrationl.shouldGetUserConfirmationToProceed)
                    reservationRequest?.let {
                        viewModel.postPreReservation(it)
                    }
                else checkReservationValidityPopUp(VehiculeRegistrationl.confirmationPromptMsg)
            }

            it.error?.let { error -> togglePopUp(message = error, isFahes = true) }
        }

    }

    private fun checkReservationValidityPopUp(message: String) {
        togglePopUpChoice(
            message = getString(R.string.FahesBookingTitle),
            description = message,
            firstOption = { viewModel.navigate(Navigation.FAHES, null) },
            secondOption = {
                reservationRequest?.let {
                    viewModel.postPreReservation(it)
                }
            },
            isFahes = true,
            secondButtonTitle = getString(R.string.CommonContinue)
        )
    }

    private fun initPLateTypes(plateTypes: List<PlateTypeWithShapeModel>) {
        var platTypesList = plateTypes.map { it.plateTypeName }
        binding.spinnerFahesBookingPlateType.initSpinner(
            activity,
            platTypesList
        ) {
            selectPlateType(it)
        }
        //  binding.spinnerFahesBookingPlateType.setValue(platTypesList.first())
    }


    private fun selectPlateType(plateType: String) {
        this.plateType = plateType
        binding.etFahesBookingCarPlate.hideError()
        if (plateType ==context?.resources?.getString(com.woqod.shared.R.string.FahesDiplomaticTypeTitle)) {
            binding.etFahesBookingCarPlate.setInputType(InputType.TYPE_CLASS_TEXT)
            binding.etFahesBookingCarPlate.setMaxInputLength(7)
        } else {
            binding.etFahesBookingCarPlate.setInputType(InputType.TYPE_CLASS_NUMBER)
            binding.etFahesBookingCarPlate.setMaxInputLength(6)
        }
        if (sharedPreferences.isUserLoggedIn()) {
            binding.etFahesBookingCarPlate.setFilledBackground(true)
        }
        initVehicleShapeSpinner()
    }

    private fun initVehicleShapeSpinner() {
        binding.spinnerFahesBookingVehicleShape.show()
        binding.spinnerFahesBookingVehicleShape.hideSpinnerDropDown()
        var plateTypeId = plateTypeList.find { it.plateTypeName == plateType }?.plateTypeId
        vehicleShapeList = getVehicleShapeList(
            plateTypeList,
            if (sharedPreferences.isUserLoggedIn()) plateType else plateTypeId
        )
        binding.spinnerFahesBookingVehicleShape.initSpinner(
            activity,
            vehicleShapeList.map { it.name }) {
            selectVehicleShape(it)
        }
        if (vehicleShapeList.size == 1) {
            vehicleShape = vehicleShapeList.first().name
            binding.spinnerFahesBookingVehicleShape.setSelection(vehicleShape, 0)
        } else {
            vehicleShape = EMPTY_FIELD
            binding.spinnerFahesBookingVehicleShape.setValue(vehicleShape)

        }
    }


    private fun getVehicleShapeList(
        plateTypes: List<PlateTypeWithShapeModel>,
        plateTypeId: String?
    ): List<VehicleShapeModel> {
        return plateTypes.find { it.plateTypeId == plateTypeId }?.vehicleShapes ?: listOf()
    }

    private fun selectVehicleShape(shape: String) {
        vehicleShape = shape
    }

    private fun initSpinners() {
        val customerType = arrayListOf(
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual),
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        )
        binding.spinnerFahesBookingCustomerType.initSpinner(
            activity,
            customerType
        ) { onSelectCustomerType(it) }
        binding.spinnerFahesBookingCustomerType.setValue(customerType.first())
    }

    private fun onSelectCustomerType(customer: String) {
        if (customer == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesBookingQid.invisible()
            binding.etFahesBookingCompanyId.show()
        } else {
            binding.etFahesBookingQid.show()
            binding.etFahesBookingCompanyId.hide()
        }.also {
            resetCustomerType()
            customerType = customer
        }
    }

    private fun getCustomerType(type: String) = when (type) {
        getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual) -> getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual)
        getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate) -> getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        else -> getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual)
    }

    private fun resetCustomerType() {
        binding.etFahesBookingCompanyId.resetValue()
        binding.etFahesBookingQid.resetValue()
        resetErrors(
            binding.etFahesBookingQid,
            binding.etFahesBookingCompanyId
        )
    }

    private fun addUserInformation(user: UserDetailsModel?) {
        user?.let {
            with(binding) {
                spinnerFahesBookingCustomerType.hide()
                etFahesBookingCompanyId.hide()
                etFahesGuestEmail.hide()
                etFahesBookingQid.show()
                spinnerFahesBookingPlateType.invisible()
                etFahesBookingPlateType.show()
                binding.etFahesBookingCustomerType.show()
                etFahesBookingCustomerType.setValue(getCustomerType(user.type.split("_").first()))
                etFahesBookingCustomerType.isEnabled(false)
                etFahesBookingCustomerType.setFilledBackground(true)
                etFahesBookingCustomerType.setIsMandatory(false)
                etFahesBookingQid.setValue(it.qid)
                etFahesBookingQid.isEnabled(false)
                etFahesBookingQid.setFilledBackground(true)
                etFahesBookingQid.setIsMandatory(false)

                etFahesBookingMobile.setValue(it.mobileNumber)
                etFahesBookingMobile.isEnabled(false)
                etFahesBookingMobile.setFilledBackground(true)
                etFahesBookingMobile.setIsMandatory(false)
                etFahesBookingCarPlate.setValue(
                    params?.carPlate ?: getString(R.string.CommonUndefinedValue)
                )
                etFahesBookingCarPlate.isEnabled(false)
                etFahesBookingCarPlate.setFilledBackground(true)
                etFahesBookingCarPlate.setIsMandatory(false)
                etFahesBookingPlateType.setValue(
                    params?.plateTypeName ?: getString(R.string.CommonUndefinedValue)
                )
                etFahesBookingPlateType.isEnabled(false)
                etFahesBookingPlateType.setFilledBackground(true)
                etFahesBookingPlateType.setIsMandatory(false)
                selectVehicleShapeForLoggedInUser(params?.plateTypeId ?: 1)
            }
        } ?: run { toast("User not found") }

    }


    private fun selectVehicleShapeForLoggedInUser(plateId: Int) {
        binding.spinnerFahesBookingVehicleShape.show()
        vehicleShapeList =
            plateTypeList.find { it.plateTypeId == plateId.toString() }?.vehicleShapes ?: listOf()
        binding.spinnerFahesBookingVehicleShape.initSpinner(
            activity,
            vehicleShapeList.map { it.id }) { selectVehicleShape(it) }
    }

    private fun initClickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
        binding.tvFahesBookingProceed.setOnClickListener {
            onProceed()
        }
    }

    private fun onProceed() {
        if (sharedPreferences.isUserLoggedIn()) {
            binding.spinnerFahesBookingVehicleShape.hideSpinnerDropDown()
            PreReservationRequest(
                mobileNumber = binding.etFahesBookingMobile.getValue(),
                plateNumber = binding.etFahesBookingCarPlate.getValue(),
                plateTypeId = params?.plateTypeId.toString(),
                vehicleShapeId = vehicleShapeList.find { it.name == vehicleShape }?.id ?: "1",
                customerId = binding.etFahesBookingQid.getValue()
            ).also {
                FahesCache.bookingDetails =
                    BookingDetailsModel(
                        sharedPreferences.user?.fullName() ?: "",
                        it.mobileNumber,
                        it.customerId,
                        it.plateNumber,
                        it.plateTypeId
                    )
                if (validateVehicleShape()) viewModel.postPreReservation(it)
            }
        } else {
            binding.spinnerFahesBookingVehicleShape.hideSpinnerDropDown()
            binding.spinnerFahesBookingPlateType.hideSpinnerDropDown()
            binding.spinnerFahesBookingCustomerType.hideSpinnerDropDown()
            reservationRequest = PreReservationRequest(
                mobileNumber = binding.etFahesBookingMobile.getValue(),
                plateNumber = binding.etFahesBookingCarPlate.getValue(),
                plateTypeId = plateTypeList.find { it.plateTypeName == plateType }?.plateTypeId
                    ?: "1",
                vehicleShapeId = vehicleShapeList.find { it.name == vehicleShape }?.id ?: "1",
                customerId = appropriateId()
            )
                .also {
                    val guestDetails = GuestInspectionRequestModel(
                        customerType,
                        appropriateId(),
                        binding.etFahesBookingMobile.getValue(),
                        binding.etFahesBookingCarPlate.getValue(),
                        plateTypeList.find { it.plateTypeName == plateType }?.plateTypeId?.toInt()
                            ?: 1,
                        binding.etFahesGuestEmail.getValue(),
                        customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
                    )

                    FahesCache.guestDetails = guestDetails
                    FahesCache.bookingDetails =
                        BookingDetailsModel(
                            "",
                            binding.etFahesBookingMobile.getValue(),
                            it.customerId,
                            it.plateNumber,
                            it.plateTypeId
                        )
                    if (validateInputs(it))
                        viewModel.checkRegistrationValidity(
                            hashMapOf(
                                CUSTOMER_ID to getUserIdValue().encode64(),
                                PLATE_NUMBER_UPPER to binding.etFahesBookingCarPlate.getValue(),
                                RESERVATION_PLATE_TYPE_ID to plateTypeList.find { it.plateTypeName == plateType }?.plateTypeId.toString()
                            )
                        )

                }
        }

    }

    private fun getUserIdValue(): String {
        return if (customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate))
            binding.etFahesBookingCompanyId.getValue() else binding.etFahesBookingQid.getValue()
    }

    private fun validateInputs(request: PreReservationRequest): Boolean {
        var validate = true
        with(request) {
            val qidError =
                ValidationsUtils.isIdValid(
                    customerId,
                    customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
                )
            val mobileError = ValidationsUtils.isMobileValid(mobileNumber)
            val carPlateError = ValidationsUtils.isCarPlateValid(plateNumber, plateType,context)
            val carPLateError = ValidationsUtils.isCarPlateTypeValid(plateType)
            val vehicleShapeError = ValidationsUtils.isCarShapeValid(vehicleShape)
            val emailError = if (binding.etFahesGuestEmail.getValue().isNotEmpty()) {ValidationsUtils.isEmailValid(binding.etFahesGuestEmail.getValue())}
             else 0
            if (qidError != 0) {
                validate = false
                showQidError(qidError, customerType)
            }
            if (mobileError != 0) {
                validate = false
                binding.etFahesBookingMobile.showError(getString(mobileError))
            }
            if (carPlateError != 0) {
                validate = false
                binding.etFahesBookingCarPlate.showError(getString(carPlateError))
            }
            if (carPLateError != 0) {
                validate = false
                binding.spinnerFahesBookingPlateType.setError(getString(carPLateError))
            }
            if (vehicleShapeError != 0) {
                validate = false
                binding.spinnerFahesBookingVehicleShape.setError(getString(vehicleShapeError))
            }
            if (emailError != 0) {
                validate = false
                binding.etFahesGuestEmail.showError(getString(emailError))
            }

        }
        return validate
    }

    private fun validateVehicleShape(): Boolean {
        val vehicleShapeError = ValidationsUtils.isCarShapeValid(vehicleShape)
        if (vehicleShapeError != 0) {
            binding.spinnerFahesBookingVehicleShape.setError(getString(vehicleShapeError))
            return false
        }
        return true
    }

    private fun appropriateId(): String {
        return if (customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesBookingCompanyId.getValue()
        } else {
            binding.etFahesBookingQid.getValue()
        }
    }

    private fun getCustomerType(): String {
        return if (customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            CORPORATE_CUSTOMER
        } else {
            INDIVIDUAL_CUSTOMER
        }
    }

    private fun showQidError(qidError: Int, customerType: String) {
        when (qidError) {
            R.string.FahesBookingCarPlateTypeError -> {
                setUserIdErrorMsg(customerType, qidError)
            }
            R.string.CommonQidNotValid -> binding.etFahesBookingQid.showError(getString(qidError))
            R.string.CommonCompanyIdInvalid -> binding.etFahesBookingCompanyId.showError(
                getString(
                    qidError
                )
            )
        }
    }

    private fun setUserIdErrorMsg(customerType: String, error: Int) {
        if (customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesBookingCompanyId.showError(getString(error))
        } else {
            binding.etFahesBookingQid.showError(getString(error))
        }
    }

}