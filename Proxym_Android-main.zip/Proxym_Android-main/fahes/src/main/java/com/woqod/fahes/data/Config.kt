package com.woqod.fahes.data

import com.woqod.shared.commundata.BASE_API_ADAPTER_URL


const val GET_FAHES_BOOKING_PLATE_TYPE_WITH_SHAPE_URL = "$BASE_API_ADAPTER_URL/reservation/getPlateTypeWithShape"
const val POST_FAHES_PRE_RESERVATION = "$BASE_API_ADAPTER_URL/reservation/getPreReservationReference"
const val POST_FAHES_OTP = "$BASE_API_ADAPTER_URL/reservation/otpValidation"
const val GET_AVAILABLE_STATIONS = "$BASE_API_ADAPTER_URL/reservation/getAvailableStations"
const val GET_APPOINTMENT_DATES_BY_STATION = "$BASE_API_ADAPTER_URL/reservation/getAppointmentDates"
const val GET_RESERVATION_TIME_SLOTS = "$BASE_API_ADAPTER_URL/reservation/getSlots"
const val POST_FAHES_RESERVATION = "$BASE_API_ADAPTER_URL/reservation/reservation"
const val POST_FAHES_RESERVATION_RESEND_OTP = "$BASE_API_ADAPTER_URL/reservation/resendOtp"


const val GET_FAHES_PLATE_TYPES_URL = "$BASE_API_ADAPTER_URL/fahes/platetypes"
const val GET_CHECK_CAR = "$BASE_API_ADAPTER_URL/fahes/checkCar"
const val POST_ADD_CAR = "$BASE_API_ADAPTER_URL/fahes/addCar"
const val POST_UPDATE_CAR = "$BASE_API_ADAPTER_URL/fahes/updateCar"
const val GET_CHECK_IS_OWNER_CAR = "$BASE_API_ADAPTER_URL/fahes/isOwner"
const val GET_CHECK_IS_OWNER_ADD_CAR = "$BASE_API_ADAPTER_URL/fahes/isOwnerAddCar"
const val GET_FAHES_INSPECTION_DETAILS = "$BASE_API_ADAPTER_URL/fahes/inspection/detailInspection"
const val GET_FAHES_INSPECTION_FEE = "$BASE_API_ADAPTER_URL/fahes/inspection/fee"
const val GET_FAHES_CARS_LIST = "$BASE_API_ADAPTER_URL/fahes/listCars"
const val PUT_FAHES_UPDATE_CAR_STATUS = "$BASE_API_ADAPTER_URL/fahes/updateStatusCar"
const val GET_FAHES_LIST_RECEIPTS_URL = "$BASE_API_ADAPTER_URL/fahes/preRegistration/findByQid"
const val GET_FAHES_INSPECTION_DETAILS_URL = "$BASE_API_ADAPTER_URL/fahes/inspection/historyInspectionsByPlate"
const val POST_CREATE_TRANSACTION_UUID = "$BASE_API_ADAPTER_URL/createTransactionUUID"
const val GET_FAHES_INSPECTION_DISCOUNT = "$BASE_API_ADAPTER_URL/fahes/discount/byType"
//CYBERSOURCE
const val SAVE_PRE_REGISTRATION = "$BASE_API_ADAPTER_URL/fahes/prtransactionlog/creditcard/save"
const val FAHES_TRANSACTION_FREE = "$BASE_API_ADAPTER_URL/fahes/prtransactionlog/free/save"
//QPAY
const val SAVE_PRE_REGISTRATION_DEBIT_CARD = "$BASE_API_ADAPTER_URL/fahes/qpaytransaction/debitcard/save"
const val FAHES_PAYMENT_SUCCESS = "$BASE_API_ADAPTER_URL/fahes/success"
const val FAHES_SEND_MAIL = "$BASE_API_ADAPTER_URL/fahes/preRegistration/sendMail"
const val PUT_UPDATE_TRANSACTION_UUID = "$BASE_API_ADAPTER_URL/fahes/prtransactionlog/updateTransactionUUID"
const val GET_FAHES_GENERATE_PDF = "$BASE_API_ADAPTER_URL/fahes/preregistration/generatePDF"
const val GET_RESERVATION_DETAILS_BY_CUSTOMER = "$BASE_API_ADAPTER_URL/reservation/detailsByCustomer"
const val GET_RESERVATION_DETAILS_BY_CUSTOMER_GUEST = "$BASE_API_ADAPTER_URL/reservation/getDetails"
const val GET_RESERVATION_RESCHEDULING = "$BASE_API_ADAPTER_URL/reservation/rescheduling"
const val POST_CANCEL_RESERVATION = "$BASE_API_ADAPTER_URL/reservation/cancellation"
const val GET_CAN_PAY_ONLINE = "$BASE_API_ADAPTER_URL/reservation/canPayOnline"
const val POST_CHECK_REGISTRATION_VALIDITY = "$BASE_API_ADAPTER_URL/reservation/vehiculeRegistrationValidity"
const val POST_CAN_PROCEED_TO_BOOKING = "$BASE_API_ADAPTER_URL/reservation/vehiculeDetails"
const val PUT_CANCEL_TRANSACTION = "$BASE_API_ADAPTER_URL/fahesregistration/qpay/cancelTransactionPost"