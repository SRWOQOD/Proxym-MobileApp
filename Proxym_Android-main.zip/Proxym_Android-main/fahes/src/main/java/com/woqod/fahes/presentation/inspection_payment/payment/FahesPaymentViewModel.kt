package com.woqod.fahes.presentation.inspection_payment.payment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.woqod.fahes.domain.models.FahesQPayTransactionModel
import com.woqod.fahes.domain.models.FahesReceiptModel
import com.woqod.fahes.domain.models.FahesTransactionUUIDModel
import com.woqod.fahes.domain.usecases.*
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.toStringHashMap
import com.woqod.shared.commundata.PARAMS
import com.woqod.shared.commundata.QPayPageResponse
import com.woqod.shared.commundata.SECRET_KEY
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.models.*
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import com.woqod.shared.commundomain.sharedusecases.*
import kotlinx.coroutines.launch
import javax.inject.Inject


class FahesPaymentViewModel @Inject constructor(
    private val postCreateTransactionUseCase: PostCreateTransactionUseCase,
    private val getSignatureUseCase: GetSignatureUseCase,
    private val postCreateFreeTransactionUseCase: PostCreateFreeTransactionUseCase,
    private val getPaymentParamsUseCase: GetPaymentParamsUseCase,
    private val sendMailUseCase: SendMailUseCase,
    private val updateTransactionUseCase: UpdateTransactionUseCase,
    private val generatePDFUseCase: GeneratePDFUseCase,
    private val getStaticScreenTextUseCase: GetStaticScreenTextUseCase,
    private val checkQidValidityUseCase: CheckMobileValidityUseCase,
    private val getQPayPaymentParamsUseCase: GetQPayPaymentParamsUseCase,
    private val createTransactionForDebitCardUseCase: PostCreateTransactionForDebitCardUseCase,
    private val getQPayPaymentPageUseCase: GetQPayPaymentPageUseCase,
    private val cancelTransactionUseCase: CancelTransactionUseCase,
    private val getServerDateUseCase: GetServerDateUseCase,
    private val isDebitCardHiddenUseCase: IsDebitCardHiddenUseCase
) : BaseViewModel() {

    private val _onEmailSent = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onEmailSent: LiveData<ResultUseCase<Boolean?, String?>> = _onEmailSent

    fun sendMail(referenceNumber: String, email: String?, isConnected: Boolean) {
        viewModelScope.launch {
            val query = hashMapOf<String, Any>(
                REFERENCE_NUMBER to referenceNumber,
                CONNECTED to isConnected
            )
            email?.let { query[EMAIL] = it }
            _onEmailSent.postValue(executeUseCase(sendMailUseCase, query))
        }
    }


    private val _onTransactionUpdated = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onTransactionUpdated: LiveData<ResultUseCase<Boolean?, String?>> = _onTransactionUpdated

    fun updateTransaction(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onTransactionUpdated.postValue(executeUseCase(updateTransactionUseCase, query))
        }
    }

    private val _onTransactionCanceled = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onTransactionCanceled: LiveData<ResultUseCase<Boolean?, String?>> = _onTransactionCanceled

    fun cancelTransaction(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onTransactionCanceled.postValue(executeUseCase(cancelTransactionUseCase, query))
        }
    }


    private val _onGetSignature = SingleLiveEvent<ResultUseCase<SignatureModel?, String?>>()
    val onGetSignature: LiveData<ResultUseCase<SignatureModel?, String?>> = _onGetSignature

    fun getSignature(paymentRequest: PaymentRequestModel, secretKey: String) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getSignatureUseCase(hashMapOf(PARAMS to paymentRequest.createSignatureParams(), SECRET_KEY to secretKey))
                .onSuccess {
                    _onGetSignature.postValue(ResultUseCase(it, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onGetSignature.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }


    private val _onFreeTransactionCreated = SingleLiveEvent<ResultUseCase<FahesReceiptModel?, String?>>()
    val onFreeTransactionCreated: LiveData<ResultUseCase<FahesReceiptModel?, String?>> = _onFreeTransactionCreated

    fun createFreeTransaction(fahesTransactionUUIDModel: FahesTransactionUUIDModel) {
        viewModelScope.launch {
            _onFreeTransactionCreated.postValue(executeUseCase(postCreateFreeTransactionUseCase, fahesTransactionUUIDModel.toStringHashMap()))
        }
    }


    private val _onTransactionUUIDCreated = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onTransactionUUIDCreated: LiveData<ResultUseCase<Boolean?, String?>> = _onTransactionUUIDCreated

    fun createFahesTransactionUUIDInspection(fahesTransactionUUIDModel: FahesTransactionUUIDModel) {
        viewModelScope.launch {
            postCreateTransactionUseCase(fahesTransactionUUIDModel.toStringHashMap())
                .onSuccess {
                    showLoadingToggle(false)
                    _onTransactionUUIDCreated.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onTransactionUUIDCreated.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    private val _onQpayTransactionCreated = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onQpayTransactionCreated: LiveData<ResultUseCase<Boolean?, String?>> = _onQpayTransactionCreated

    fun createFahesQPayTransactionInspection(fahesQPayTransactionModel: FahesQPayTransactionModel) {
        viewModelScope.launch {
            createTransactionForDebitCardUseCase(fahesQPayTransactionModel.toStringHashMap())
                .onSuccess {
                    showLoadingToggle(false)
                    _onQpayTransactionCreated.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onQpayTransactionCreated.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    private val _onGetPaymentParams = SingleLiveEvent<ResultUseCase<PaymentParamsModel?, String?>>()
    val onGetPaymentParams: LiveData<ResultUseCase<PaymentParamsModel?, String?>> = _onGetPaymentParams

    fun getPaymentParams() {
        viewModelScope.launch {
            _onGetPaymentParams.postValue(executeUseCase(getPaymentParamsUseCase, hashMapOf(NAME to PaymentSignatureTypes.Fahes)))
        }
    }


    private val _resultGeneratePDF = SingleLiveEvent<ResultUseCase<String?, String?>>()
    val resultGeneratePDF: LiveData<ResultUseCase<String?, String?>> = _resultGeneratePDF
    fun generatePDF(refNumber: String) {
        viewModelScope.launch {
            _resultGeneratePDF.postValue(executeUseCase(generatePDFUseCase, refNumber))
        }
    }


    private val _resultStaticScreen = SingleLiveEvent<ResultUseCase<StaticScreenModel?, String?>>()
    val resultStaticScreen: LiveData<ResultUseCase<StaticScreenModel?, String?>> = _resultStaticScreen

    fun getStaticText(section : String) {
        viewModelScope.launch {
            _resultStaticScreen.postValue(executeUseCase(getStaticScreenTextUseCase,section))
        }
    }

    private val _onCheckValiditySuccess = MutableLiveData<ResultUseCase<Boolean?, String?>>()
    val onCheckValiditySuccess: LiveData<ResultUseCase<Boolean?, String?>>
        get() = _onCheckValiditySuccess

    fun checkQidValidity(query: HashMap<String, Any>) {
        viewModelScope.launch(ioDispatcher) {
            _onCheckValiditySuccess.postValue(executeUseCase(checkQidValidityUseCase, query))
        }
    }

    private val _resultServerDate = SingleLiveEvent<ResultUseCase<ServerDateModel?, String?>>()
    val resultServerDate: LiveData<ResultUseCase<ServerDateModel?, String?>> = _resultServerDate

    fun getServerDate() {
        viewModelScope.launch {
            _resultServerDate.postValue(
                executeUseCase(
                    useCase = getServerDateUseCase
                )
            )
        }
    }

    private val _onGetQpayPaymentParams = SingleLiveEvent<ResultUseCase<QPayPaymentRequestModel?, String?>>()
    val onGetQpayPaymentParams: LiveData<ResultUseCase<QPayPaymentRequestModel?, String?>>
        get() = _onGetQpayPaymentParams

    fun getQpayPaymentParams(query: HashMap<String, String>) {
        viewModelScope.launch {
            query[NAME] = PaymentSignatureTypes.Fahes.toString()
            _onGetQpayPaymentParams.postValue(executeUseCase(useCaseWithoutSharedResponse = getQPayPaymentParamsUseCase, query = query))
        }
    }

    private val _resultPaymentPage = SingleLiveEvent<ResultUseCase<QPayPageResponse?, String?>>()
    val resultPaymentPage: LiveData<ResultUseCase<QPayPageResponse?, String?>> = _resultPaymentPage

    fun getQpayPaymentPage(query: QPayPaymentRequestModel) {
        viewModelScope.launch {
            _resultPaymentPage.postValue(executeUseCase(useCaseWithoutSharedResponse = getQPayPaymentPageUseCase, query = query))
        }
    }

    private val _isDebitCardHidden =
        SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val isDebitCardHidden: LiveData<ResultUseCase<Boolean?, String?>>
        get() = _isDebitCardHidden
    fun isDebitCardHidden() {
        viewModelScope.launch {
            _isDebitCardHidden.postValue(executeUseCase(useCase = isDebitCardHiddenUseCase))
        }
    }
}