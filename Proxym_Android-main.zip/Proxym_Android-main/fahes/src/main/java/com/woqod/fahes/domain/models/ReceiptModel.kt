package com.woqod.fahes.domain.models

import com.woqod.shared.commundomain.models.CarModel
import java.io.Serializable


data class ReceiptModel(
    val id: Int,
    val wsStatus: String,
    val discountInfo: String,
    val serviceCategory: String,
    val userName: String,
    val initialAmount: Int,
    val creationDate: String,
    val referenceNumber: String,
    val qid: String,
    val errorNo: String,
    val transactionUUID: String,
    val payStatus: String,
    val car: CarModel,
    val error: String,
    val finalAmount: Int,
    val category: CategoryModel,
    val mobileNumber: Int,
    val receiptUrl: String,
    val barcodeReference: String,
    val inspectionType: String,
    val barcode: String
) : Serializable


data class CategoryModel(
    val preRegistrations: String,
    val fee: Int,
    val _id: Int,
    val id: String,
    val name: String
) : Serializable {
    constructor() : this("", 0, 0, "", "")
}

enum class ReceiptStatus { PAID, FAILED, CANCELED,PAIED }