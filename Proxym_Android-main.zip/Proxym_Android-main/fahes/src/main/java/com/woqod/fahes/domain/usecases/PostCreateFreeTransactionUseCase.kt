package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.FahesReceiptModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


open class PostCreateFreeTransactionUseCase @Inject constructor(
    private val appRepository: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, String>, WoqodResult<SharedResponse<FahesReceiptModel>>> {

    override suspend fun invoke(request: HashMap<String, String>) = appRepository.createFreeTransaction(request)
}