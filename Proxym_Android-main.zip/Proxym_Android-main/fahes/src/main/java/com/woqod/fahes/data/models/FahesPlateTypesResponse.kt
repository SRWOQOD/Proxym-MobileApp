package com.woqod.fahes.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.fahes.domain.models.FahesPlateTypesModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

/**
 * {"name_ar":"خصوصي",
 * "id":1,
 * "name_en":"PRIVATE"}
 */
data class FahesPlateTypesResponse(
    val id: Int?,
    @SerializedName("name_en") val nameEn: String?,
    @SerializedName("name_ar") val nameAr: String?
) : DomainMapper<FahesPlateTypesModel> {
    override fun mapToDomainModel(): FahesPlateTypesModel {
        val namePlateType = if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
            nameAr
        } else {
            nameEn
        }
        return FahesPlateTypesModel(
            id ?: 0,
            namePlateType ?: ""
        )
    }

}