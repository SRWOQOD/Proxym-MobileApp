package com.woqod.fahes.domain.models

data class BookingDetailsModel(
    var fullName: String = "",
    val mobileNumber: String = "",
    var qid: String,
    var plateNumber: String,
    var plateType: String
)
