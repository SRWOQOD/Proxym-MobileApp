package com.woqod.fahes.domain.models

import java.io.Serializable


data class InspectionDiscountModel(
    val id: Long,
    val amount: Double,
    val status: Boolean,
    val fahesService: String,
    val paymentMethod: String,
    val paymentType: String,
    val min: Double,
    val max: Double
):Serializable