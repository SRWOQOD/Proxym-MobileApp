package com.woqod.fahes.domain.models

data class PlateTypeWithShapeModel(
    val plateTypeId: String?,
    val plateTypeName: String,
    val vehicleShapes: List<VehicleShapeModel>
)

data class VehicleShapeModel(
    val id: String,
    val name: String
)
