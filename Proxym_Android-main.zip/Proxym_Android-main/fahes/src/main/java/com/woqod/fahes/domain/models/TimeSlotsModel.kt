package com.woqod.fahes.domain.models

data class TimeSlotsModel(
    val hourFrom: String,
    val hourTo: String,
    val slotTime: String,
    val id: String
)