package com.woqod.fahes.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.fahes.domain.models.DefectModel
import com.woqod.fahes.domain.models.Evaluation
import com.woqod.fahes.domain.models.FahesInspectionModel
import com.woqod.fahes.domain.models.InspectionStationModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper
import com.woqod.shared.commundata.models.CarResponse
import com.woqod.shared.commundata.models.UserDetailsResponse
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.UserDetailsModel
import java.io.Serializable

data class FahesInspectionResponse(
    val id: Long?,
    @SerializedName("error_ar") val errorAr: String?,
    @SerializedName("error_en") val errorEn: String?,
    @SerializedName("inspected_on") val inspectedOn: String?,
    @SerializedName("legal_evaluation") val legalEvaluation: String?,
    val mileage: String?,
    @SerializedName("owner__") val owner: UserDetailsResponse?,
    val station: InspectionStationResponse?,
    @SerializedName("technical_evaluation") val technicalEvaluation: String?,
    val vehicle: CarResponse?
) : DomainMapper<FahesInspectionModel> {
    override fun mapToDomainModel() = FahesInspectionModel(
        id ?: 0L,
        (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) errorAr else errorEn) ?: "",
        inspectedOn ?: "",
        legalEvaluation ?: "",
        mileage ?: "",
        owner?.mapToDomainModel() ?: UserDetailsModel(),
        station?.mapToDomainModel() ?: InspectionStationModel(),
        technicalEvaluation ?: "",
        vehicle?.mapToDomainModel() ?: CarModel()
    )
}

data class InspectionStationResponse(
    @SerializedName("name_ar") val nameAr: String?,
    val _id: String?,
    val id: String?,
    @SerializedName("name_en") val nameEn: String?
) : DomainMapper<InspectionStationModel> {
    override fun mapToDomainModel() = InspectionStationModel(
        _id ?: "",
        id ?: "",
        (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) nameAr else nameEn) ?: ""
    )
}

data class InspectionDetailsResponse(
    @SerializedName("defect_type") val defectType: DefectResponse?,
    @SerializedName("defect_comment") val defectComment: DefectResponse?,
    @SerializedName("additional_comment") val additionalComment: String?,
    val location: DefectResponse?,
    val evaluation: DefectResponse?,
) : DomainMapper<DefectModel> {
    override fun mapToDomainModel() = DefectModel(
        defectTypeId = defectType?.id?:0L,
        defectCode = defectComment?.code ?: "",
        defectCommentName = getName(
            defectComment?.defectSub?.nameAr,
            defectComment?.defectSub?.nameEn
        ),
        defectCommentDescp = getName(defectComment?.nameAr, defectComment?.nameEn),
        location = getName(location?.nameAr, location?.nameEn),
        evaluation = Evaluation(
            evaluation?.id ?: 0L,
            getName(evaluation?.nameAr, evaluation?.nameEn)
        ),
        additionalComment = additionalComment ?: ""
    )


    private fun getName(nameAr: String?, nameEn: String?) =
        (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) nameAr else nameEn) ?: ""
}

data class DefectResponse(
    val id: Long?,
    val code: String?,
    @SerializedName("name_en") val nameEn: String?,
    @SerializedName("name_ar") val nameAr: String?,
    @SerializedName("defect_sub") val defectSub: DefectSub?,

    ) : Serializable {
    data class DefectSub(
        @SerializedName("name_en") val nameEn: String?,
        @SerializedName("name_ar") val nameAr: String?
    ) : Serializable

}


enum class InspectionDefectType(val id: Long) {
    Comment(3L),
    Technical(1L),
    Legal(2L)
}

