package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.AvailableStationModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class AvailableStationResponse(
    val stationNameEn: String?,
    val stationId: Int?,
    val stationNameAr: String?
) : DomainMapper<AvailableStationModel> {
    override fun mapToDomainModel() = AvailableStationModel(
        name = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) stationNameAr else stationNameEn) ?: "",
        id = stationId ?: 0
    )
}
