package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.ReservationModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.extensions.formatTime
import com.woqod.shared.commundata.DomainMapper

/**
"result": {
"licencePlate": "196661",
"mobileNumber": "55928265",
"stationNameEn": "FAHES - MAZROOUA",
"licencePlateTypeId": "9",
"pid": "11-4548-00",
"creationDate": 1628247503204,
"qid": "11-4548-00",
"hourFrom": "6",
"reservationId": "2021080600000007",
"hourTo": "7",
"canPayOnline": "false",
"vehicleShapeId": "7",
"vin": "MAT41206580L02485",
"userType": "Corporate_Manager_Customer",
"appointmentDate": "2021-08-07T00:00:00",
"apiStatus": "SUCCESS",
"stationNameAr": "المزروعة",
"cancellationDate": null,
"status": "RESERVED"
}*/
data class ReservationResponse(
    val reservationId: String?,
    val stationNameEn: String?,
    val stationNameAr: String?,
    val appointmentDate: String?,
    val hourFrom: String?,
    val hourTo: String?,
    val slotTimeEn: String?,
    val slotTimeAr: String?,
    val canPayOnline: String?,
    val plateNumber: String?,
    val plateTypeNameEn: String?,
    val plateTypeNameAr: String?
) : DomainMapper<ReservationModel> {
    override fun mapToDomainModel() = ReservationModel(
        reservationId = reservationId ?: "",
        stationName = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) stationNameAr else stationNameEn) ?: "",
        appointmentDate = appointmentDate?.let { it.substring(0, it.indexOf('T')) } ?: "0",
        time = "${hourFrom?.toInt()?.formatTime() ?: ""} - ${hourTo?.toInt()?.formatTime() ?: ""}",
        canPayOnline = (canPayOnline ?: "false") == "true",
        plateTypeName = (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) plateTypeNameAr else plateTypeNameEn) ?: "",
        plateNumber = plateNumber ?: "",
        slotTime = (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) slotTimeAr else slotTimeEn) ?: ""
    )

}
