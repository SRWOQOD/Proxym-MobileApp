package com.woqod.fahes.presentation.inspection_payment.payment

import android.os.Handler
import android.os.Looper
import androidx.core.view.isVisible
import com.woqod.fahes.R
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.FragmentFahesPaymentBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.*
import com.woqod.fahes.presentation.utils.FahesReceiptNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundata.fromJsonToObject
import com.woqod.shared.commundomain.models.*
import com.woqod.shared.utils.getDecision
import com.woqod.shared.utils.onQPayUrlChanges
import com.woqod.shared.utils.onUrlFahesChange
import com.woqod.shared.widget.PopUpType
import java.util.*


class FahesPaymentFragment :
    BaseViewModelFragment<FahesPaymentViewModel, FragmentFahesPaymentBinding>(
        FragmentFahesPaymentBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesPaymentViewModel by injectViewModel()

    private lateinit var inspectionDetails: InspectionRegisterModel
    private lateinit var paymentParams: PaymentParamsModel
    private var paymentRequest: PaymentRequestModel? = null
    private lateinit var paymentDateModel: ServerDateModel
    private val isUserLoggedIn: Boolean by lazy { sharedPreferences.isUserLoggedIn() }
    private var loadingHandler = Handler(Looper.getMainLooper())
    private var transactionUUID: String? = null
    private lateinit var pun: String
    private var guestEmail = ""
    private var transactionCreated = false
    private var isDebitCard = false
    private var fahesQpayPaymentRequest: QPayPaymentRequestModel? = null

    override fun initViews() {
        fahesComponent.inject(this)
        disableDefaultBackPress(disable = true)
        FahesCache.inspectionDetails?.let { inspectionDetails = it }
        initClickListeners()
        viewModel.getStaticText(SideMenuItem.TERMS_AND_CONDITIONS_PAYMENT_FAHES.name)
    }


    private fun initClickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }
        binding.btnFahesChoosePaymentCredit.setOnClickListener {
            isDebitCard = false
            viewModel.getServerDate()
        }
        binding.btnFahesChoosePaymentDebit.setOnClickListener {
            isDebitCard = true
            viewModel.getServerDate()
        }
        binding.tvFahesChoosePaymentContinue.setOnClickListener {
            onContinue()
        }
    }

    private fun handlePaymentMethod(isDebitCard: Boolean) {
        if (!isDebitCard) {
            viewModel.getPaymentParams()
        } else {
            pun = generateRequestPun()
            GetQPayParamsModel(
                amount = "${inspectionDetails.preRegistrationFee.category.fee.toInt() * 100}",
                pun = pun,
                transactionRequestDate = paymentDateModel.getTransactionsDate()
            ).also {
                viewModel.getQpayPaymentParams(it.toStringHashMap())
            }
        }
    }

    private fun showButtons() {
        binding.tvDebit.text = getString(R.string.CommonDebitCard)
        binding.tvCredit.text = getString(R.string.CommonCreditCard)
        binding.tvFahesChoosePaymentContinue.text = getString(R.string.CommonContinue)
        if (inspectionDetails.preRegistrationFee.category.fee == 0.0) {
            binding.tvFahesChoosePaymentContinue.show()
            binding.btnFahesChoosePaymentCredit.hide()
            binding.btnFahesChoosePaymentDebit.hide()
            binding.tvPaymentDescDesc.show()
        }
    }

    override fun initObservers() {
        initPaymentObservers()
        viewModel.resultStaticScreen.observe(viewLifecycleOwner) {
            it.result?.let { staticText ->
                binding.tvPaymentDescDesc.loadStaticWebView(
                    staticText.content,
                    isArabicLanguage = languageUtils.isArabicLanguage()
                )
                viewModel.isDebitCardHidden()
            }
            it.error?.let { error ->
                viewModel.isDebitCardHidden()
                togglePopUp(error, isFahes = true)
            }
        }


        viewModel.onTransactionUUIDCreated.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                transactionCreated = result
                goToFahesPayment(isTransactionCreated = result)
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }

        viewModel.onQpayTransactionCreated.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                if (result)

                    goToFahesPayment(isTransactionCreated = result, isDebitCard = true)
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
        viewModel.onFreeTransactionCreated.observe(viewLifecycleOwner) {
            it.result?.let { result -> onFreeTransactionCreated(result) }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
        viewModel.onGetSignature.observe(viewLifecycleOwner) {
            it.result?.let { result -> onGetSignature(result) }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
        viewModel.onGetPaymentParams.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                paymentParams = result
                onQnbPayment()
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
        viewModel.onTransactionUpdated.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                if (result)
                    togglePopUp(
                        getString(com.woqod.shared.R.string.PaymentCancelled),
                        isFahes = true,
                        action = { viewModel.navigate(Navigation.FAHES, null) },
                        popUpType = PopUpType.POPUP_SUCCESS
                    )

            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }

        viewModel.onTransactionCanceled.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                if (result)
                    togglePopUp(
                        getString(com.woqod.shared.R.string.PaymentCancelled),
                        isFahes = true,
                        action = { viewModel.navigate(Navigation.FAHES, null) },
                        popUpType = PopUpType.POPUP_SUCCESS
                    )

            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }

        viewModel.onGetQpayPaymentParams.observe(viewLifecycleOwner) {
            it.result?.let { requestParams ->
                fahesQpayPaymentRequest = requestParams
                viewModel.createFahesQPayTransactionInspection(createFahesQpayTransactionModel())
            }
        }

        viewModel.resultPaymentPage.observe(viewLifecycleOwner) {
            it.result?.let {
                fahesQpayPaymentRequest?.let { qPayPaymentRequestModel ->
                    binding.webViewFahesPayment.loadQPayUrl(it, qPayPaymentRequestModel)
                    toggleWebView(true)
                }

            }
        }

        viewModel.resultServerDate.observe(viewLifecycleOwner) {
            it.result?.let { dates ->
                paymentDateModel = dates
                handlePaymentMethod(isDebitCard)
            }

            it.error?.let {
                paymentDateModel = ServerDateModel()
                handlePaymentMethod(isDebitCard)
            }
        }
        viewModel.isDebitCardHidden.observe(viewLifecycleOwner) {
            it.result?.let { isShown ->
                if (!isShown) {
                    binding.btnFahesChoosePaymentDebit.show()
                } else
                    binding.btnFahesChoosePaymentDebit.hide()

                binding.screenContent.show()

                showButtons()

            }
            it.error?.let {
                binding.screenContent.show()
                binding.btnFahesChoosePaymentDebit.hide()
                showButtons()
            }
        }
    }

    private fun initPaymentObservers() {
        with(binding.webViewFahesPayment) {
            onChangeUrl.observe(viewLifecycleOwner) { onUrlChanged(it) }
            onError.observe(viewLifecycleOwner) { toggleWebView() }
            onFinishLoading.observe(viewLifecycleOwner) {
                toggleWebView(showWebView = true)
                toggleLoading(false)
            }
        }
    }

    private fun onQnbPayment() {
        if (::paymentParams.isInitialized) {
            transactionUUID = UUID.randomUUID().toString()
            paymentRequest = PaymentRequestModel(
                access_key = paymentParams.accessKey,
                signed_date_time = paymentDateModel.getServerDate(),
                profile_id = paymentParams.profileId,
                amount = inspectionDetails.preRegistrationFee.category.fee.toString(),
                transaction_uuid = transactionUUID!!,
                reference_number = paymentDateModel.getReferenceNUmber()
            ).also { viewModel.getSignature(it, paymentParams.secretKey) }
        }
    }

    private fun onGetSignature(signatureModel: SignatureModel) {
        paymentRequest = paymentRequest?.copy(signature = signatureModel.signature)
        createFahesTransactionUUIDModel().also { viewModel.createFahesTransactionUUIDInspection(it) }
    }


    private fun onContinue() {
        createFahesTransactionUUIDModel().also { viewModel.createFreeTransaction(it) }
    }

    private fun onFreeTransactionCreated(receiptDetails: FahesReceiptModel?) {
        receiptDetails?.let {
            if (it.decision != PAID) {
                togglePopUp(it.api, isFahes = true)
                return
            }
        }
        goToFahesPayment(isTransactionCreated = true, receiptDetails = receiptDetails)
    }

    private fun handleLoading(show: Boolean) {
        if (show) {
            binding.whiteSecreen.show()
            binding.fahesLoading.show()
        } else {
            binding.whiteSecreen.show()
            binding.fahesLoading.hide()
        }
    }

    private fun goToFahesPaymentDebitCard(

    ) {
        fahesQpayPaymentRequest?.let {
            viewModel.getQpayPaymentPage(it)
        }

    }

    private fun goToFahesPayment(
        isDebitCard: Boolean = false,
        isTransactionCreated: Boolean,
        receiptDetails: FahesReceiptModel? = null
    ) {
        FahesCache.paymentDetails =
            PaymentDetailsModel(receiptDetails, paymentRequest, inspectionDetails)
        if (isTransactionCreated) {
            receiptDetails?.let {
                viewModel.navigate(
                    Navigation.FAHES_RECEIPT,
                    FahesReceiptNavigationModel(
                        it.reference,
                        it.receipt,
                        fromPayment = true,
                        inspectionDetails.guestDetails?.email ?: ""
                    )
                )
            } ?: run {
                handlePaymentSource(isDebitCard)
            }
        } else {
            togglePopUp(getString(R.string.CommonErrorUnexpectedMessage), isFahes = true)
        }
    }

    private fun handlePaymentSource(isDebitCard: Boolean) {
        if (isDebitCard) {
            goToFahesPaymentDebitCard()
        } else {
            paymentRequest?.let {
                toggleLoading(true)
                binding.webViewFahesPayment.loadUrl(createPaymentPage(it))
            }
        }
    }

    private fun createFahesTransactionUUIDModel() =
        with(inspectionDetails) {
            guestEmail = guestDetails?.email ?: ""
            FahesTransactionUUIDModel(
                userID = if (sharedPreferences.isUserLoggedIn()) carModel.owner.fullName() else (guestDetails?.qid
                    ?: ""),
                qid = if (isUserLoggedIn) carModel.ownerQid.decode64() else guestDetails!!.qid,
                mobile = if (isUserLoggedIn) carModel.owner.mobileNumber else guestDetails!!.mobile,
                email = if (isUserLoggedIn) carModel.owner.email else guestDetails!!.email,
                amount = preRegistrationFee.category.fee.toInt().toString(),
                inspectionType = preRegistrationFee.inspectionType.toString(),
                serviceCategory = preRegistrationFee.serviceCategory,
                categoryId = preRegistrationFee.category.id.toString(),
                categoryNameEn = preRegistrationFee.category.nameEn,
                categoryNameAr = preRegistrationFee.category.nameAr,
                categoryFee = preRegistrationFee.category.fee.toString(),
                plateNumber = carModel.plateNumber,
                plateType = carModel.plateType.id.toString(),
                referenceNumber = paymentRequest?.reference_number
                    ?: run { Date().time.toString() },
                anonym = !isUserLoggedIn,
                transactionUUID = transactionUUID ?: UUID.randomUUID().toString(),
                mobileNumber = if (isUserLoggedIn) carModel.owner.mobileNumber else guestDetails!!.mobile
            )
        }


    private fun createFahesQpayTransactionModel() =
        with(inspectionDetails) {
            guestEmail = guestDetails?.email ?: ""
            FahesQPayTransactionModel(
                userID = if (sharedPreferences.isUserLoggedIn()) carModel.owner.fullName() else (guestDetails?.qid
                    ?: ""),
                qid = if (isUserLoggedIn) carModel.ownerQid.decode64() else guestDetails!!.qid,
                mobile = if (isUserLoggedIn) carModel.owner.mobileNumber else guestDetails!!.mobile,
                email = if (isUserLoggedIn) carModel.owner.email else guestDetails!!.email,
                amount = preRegistrationFee.category.fee.toInt().toString(),
                inspectionType = preRegistrationFee.inspectionType.toString(),
                serviceCategory = preRegistrationFee.serviceCategory,
                categoryId = preRegistrationFee.category.id.toString(),
                categoryNameEn = preRegistrationFee.category.nameEn,
                categoryNameAr = preRegistrationFee.category.nameAr,
                categoryFee = preRegistrationFee.category.fee.toString(),
                plateNumber = carModel.plateNumber,
                plateType = carModel.plateType.id.toString(),
                referenceNumber = paymentDateModel.getReferenceNUmber(),
                anonym = !isUserLoggedIn,
                pun = pun,
                mobileNumber = if (isUserLoggedIn) carModel.owner.mobileNumber else guestDetails!!.mobile
            )
        }

    private var getResponsePayment = false

    private fun onUrlChanged(url: String) {
        if (!isDebitCard) {
            onCreditCardUrlChanged(url)
        } else {
            onDebitCardUrlCHanged(url)
        }
    }

    private fun onDebitCardUrlCHanged(url: String) {
        if (url.contains("Submit")) {
            handleLoading(true)
            loadingHandler.postDelayed({
                if (!getResponsePayment) {
                    handlePaymentInProgressPopUp()
                }
            }, 45000)
        }

        onQPayUrlChanges(
            binding.webViewFahesPayment,
            url,
            fahesQpayPaymentRequest?.extraFields_f14,
            PaymentSignatureTypes.Fahes,
            onAccept = {
                getResponsePayment = true
                it.fromJsonToObject(FahesPaymentResponse::class.java)?.let { fahes ->
                    if (fahes.isSuccessful == false) {
                        handleLoading(false)
                        toggleInProgressPopUp()
                    } else {
                        when (val decision: Int = getDecision(fahes.body?.result?.decision)) {
                            com.woqod.shared.R.string.PaymentSuccessful -> {
                                handleLoading(false)
                                togglePopUp(
                                    getString(decision),
                                    isFahes = true,
                                    action = {
                                        viewModel.navigate(
                                            Navigation.FAHES_RECEIPT,
                                            fahes.body?.result?.reference?.let { reference ->
                                                fahes.body?.result?.receipt?.let { receipt ->
                                                    FahesReceiptNavigationModel(
                                                        reference,
                                                        receipt,
                                                        fromPayment = true,
                                                        guestEmail
                                                    )
                                                }
                                            }
                                        )
                                    },
                                    popUpType = PopUpType.POPUP_SUCCESS,
                                    description = "${getString(R.string.transactionReferenceNumber)}\n ${fahes.body?.result?.pun}\n${
                                        String.format(
                                            Locale.ENGLISH,
                                            getString(R.string.QPayAmount),
                                            "${fahes.body?.result?.amount?.toInt() ?: inspectionDetails.preRegistrationFee.category.fee.toInt()}"
                                        )
                                    }\n${getString(R.string.transactionDate)} ${
                                        fahes.body?.result?.responseDate?.toFormattedDateString(
                                            oldDate = QPay_TRANSACTION_DATE_FORMAT,
                                            newDate = QPAY_DATE_FORMAT,
                                            addNewLine = true
                                        )
                                    }"
                                )
                            }

                            R.string.CommonPaymentInProgress -> {
                                handlePaymentInProgressPopUp()
                            }
                            R.string.PaymentCancelled -> {
                                handleLoading(false)
                                togglePopUp(
                                    getString(com.woqod.shared.R.string.PaymentCancelled),
                                    action = { viewModel.navigate(Navigation.FAHES, null) },
                                    popUpType = PopUpType.POPUP_SUCCESS
                                )
                            }
                            else -> {
                                handleLoading(false)
                                handlePaymentFailurePopUp(decision)

                            }
                        }
                    }
                } ?: run {
                    handlePaymentInProgressPopUp()

                }
            },
            onCancel = {
                getResponsePayment = true
                cancelQpayTransaction()
            }
        )
    }

    private fun onCreditCardUrlChanged(url: String) {
        if (url.contains(CLICK_ONPAY) || url.contains(CHECK_UPDATE)) {
            handleLoading(true)
            getResponsePayment = false
            loadingHandler.postDelayed({
                if (!getResponsePayment) {
                    handlePaymentInProgressPopUp()
                }
            }, 45000)
        }
        if (url.contains(PAYMENT_URL_ACTION_LOAD)) {
            getResponsePayment = true
            binding.fahesLoading.hide()
            binding.whiteSecreen.hide()
        }
        onUrlFahesChange(url, binding.webViewFahesPayment,
            onAccept = {
                getResponsePayment = true
                it.fromJsonToObject(FahesPaymentResponse::class.java)?.let { fahes ->
                    if (fahes.isSuccessful == false) {
                        handleLoading(false)
                        toggleInProgressPopUp()
                    } else {
                        when (val decision: Int = getDecision(fahes.body?.result?.decision)) {
                            com.woqod.shared.R.string.PaymentSuccessful -> {

                                binding.whiteSecreen.show()
                                handleLoading(false)
                                togglePopUp(
                                    getString(decision),
                                    isFahes = true,
                                    action = {
                                        viewModel.navigate(
                                            Navigation.FAHES_RECEIPT,
                                            fahes.body?.result?.reference?.let { reference ->
                                                fahes.body?.result?.receipt?.let { receipt ->
                                                    FahesReceiptNavigationModel(
                                                        reference,
                                                        receipt,
                                                        fromPayment = true,
                                                        guestEmail
                                                    )
                                                }
                                            }
                                        )
                                    },
                                    popUpType = PopUpType.POPUP_SUCCESS,
                                )
                            }
                            R.string.CommonPaymentInProgress -> {
                                handleLoading(false)
                                handlePaymentInProgressPopUp()
                            }
                            else -> {
                                handlePaymentFailurePopUp(decision)
                            }
                        }
                    }
                } ?: run {
                    handlePaymentInProgressPopUp()

                }
            },
            onCancel = {
                getResponsePayment = true
                cancelTransaction()


            }
        )
    }

    private fun handlePaymentFailurePopUp(decision: Int) {
        togglePopUp(getString(decision),
            isFahes = true,
            popUpType = PopUpType.POP_ERROR,
            action = {
                viewModel.navigate(Navigation.FAHES, null)
            })
    }

    private fun handlePaymentInProgressPopUp() {
        handleLoading(false)
        togglePopUp(
            getString(R.string.CommonPaymentInProgress),
            buttonTitle = getString(R.string.BoNotificationok),
            isFahes = true,
            popUpType = PopUpType.POP_WARNING,
            action = {
                viewModel.navigate(Navigation.FAHES, null)
            }
        )
    }

    private fun toggleInProgressPopUp() {
        togglePopUp(
            getString(R.string.CommonPaymentInProgress),
            buttonTitle = getString(R.string.BoNotificationok),
            popUpType = PopUpType.POP_WARNING,
            isFahes = true,
            action = {
                viewModel.navigate(Navigation.FAHES, null)
            }
        )
    }

    private fun cancelTransaction() {
        paymentRequest?.transaction_uuid?.let {
            viewModel.updateTransaction(hashMapOf(TRANSACTION_UUID to it, STATUS to CANCELED))
        }
    }

    private fun cancelQpayTransaction() {
        fahesQpayPaymentRequest?.let {
            viewModel.cancelTransaction(hashMapOf(TRANSACTION_PUN to it.pun, STATUS to CANCELED))
        }
    }

    private fun toggleWebView(showWebView: Boolean = false) {
        if (showWebView) {
            binding.webViewFahesPayment.show()
            binding.containerFahesChoosePayment.hide()
            showWebViewTitle()
        } else {
            binding.webViewFahesPayment.hide()
            binding.containerFahesChoosePayment.show()
            binding.webViewTitle.hide()
            binding.titleBackground.hide()
        }
    }

    private fun showWebViewTitle() {
        if (isDebitCard) {
            binding.titleBackground.show()
            binding.webViewTitle.show()
        }
    }

    override fun onPause() {
        super.onPause()
        loadingHandler.removeCallbacksAndMessages(null)
    }

    override fun onBackPressCustomAction() {
        when {
            binding.webViewFahesPayment.isVisible || activity.isPopUpShown() || binding.whiteSecreen.isVisible -> {
                //do nothing
            }

            !binding.webViewFahesPayment.isVisible && transactionCreated -> {
                handlePaymentCancellation()
            }


            else -> {
                viewModel.navigate(Navigation.FAHES, null)
            }
        }


    }

    private fun handlePaymentCancellation() {
        if (!isDebitCard) {
            paymentRequest?.transaction_uuid?.let {
                viewModel.updateTransaction(
                    hashMapOf(
                        TRANSACTION_UUID to it,
                        STATUS to CANCELED
                    )
                )
            }
        } else {
            cancelQpayTransaction()
        }
    }
}