package com.woqod.fahes.presentation.inspection_payment.pre_registration

import android.os.Bundle
import com.woqod.fahes.R
import com.woqod.fahes.databinding.FragmentInspectionCarConfirmationBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.presentation.utils.FahesNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.extensions.toFormattedDate
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.utils.FAHES_ARGS
import com.woqod.shared.widget.PopUpType
import java.time.format.DateTimeFormatter


class CarRegistrationConfirmationFragment :
    BaseViewModelFragment<FahesPreRegisterViewModel, FragmentInspectionCarConfirmationBinding>(
        FragmentInspectionCarConfirmationBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override val viewModel: FahesPreRegisterViewModel by injectViewModel()


    private var params: FahesNavigationModel? = null
    private var car: CarModel? = null

    fun newInstance(params: FahesNavigationModel): CarRegistrationConfirmationFragment {
        val args = Bundle()
        args.putSerializable(FAHES_ARGS, params)
        val fragment = CarRegistrationConfirmationFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        fahesComponent.inject(this)
        initCLickListeners()
        arguments?.let {
            params = it.getSerializable(FAHES_ARGS) as FahesNavigationModel
            sharedPreferences.user?.let { user ->
                car = params?.car?.copy(ownerQid = user.qid, owner = user)
                initValues()
            }
        }

    }

    override fun initObservers() {
        viewModel.onAddCar.observe(this) {
            it.result?.let { onAddNewCar() }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }


    }

    private fun initCLickListeners() {
        with(binding) {
            toolbarFahes.btnToolbar.setOnClickListener {
                viewModel.navigate(Navigation.FAHES, null)
            }
            tvFahesInspectionCarConfirmationConfirm.setOnClickListener {
                params?.let {
                    car?.let { car ->
                        viewModel.addCar(car, it.pinCode)
                    }

                }
            }
            tvFahesInspectionCarConfirmationCancel.setOnClickListener {
                viewModel.navigate(Navigation.FAHES_USER_CAR_LIST, params)
            }
        }
    }

    private fun initValues() {
        with(binding) {
            car?.let {
                tvFahesInspectionCarConfirmationOwner.setValue(it.owner.fullName())
                tvFahesInspectionCarConfirmationQid.setValue(it.owner.qid)
                tvFahesInspectionCarConfirmationPlateType.setValue(it.plateType.name())
                tvFahesInspectionCarConfirmationPlateNumber.setValue(it.plateNumber)
                tvFahesInspectionCarConfirmationCarModel.setValue(it.model.name())
                tvFahesInspectionCarConfirmationRegistrationDate.setValue(
                    it.registrationExpiresOn.toFormattedDate(
                        DateTimeFormatter.ISO_LOCAL_DATE
                    )
                )
            }
        }
    }

    private fun onAddNewCar() {
        togglePopUp(
            message = getString(R.string.FahesSuccessAddCar),
            popUpType = PopUpType.POPUP_SUCCESS,
            isFahes = true,
            action = { viewModel.navigate(Navigation.FAHES_USER_CAR_LIST, params) })


    }


}