package com.woqod.fahes.presentation.about


import com.woqod.fahes.databinding.FragmentAboutFahesBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.SideMenuItem.ABOUT_FAHES


class AboutFahesFragment :
    BaseViewModelFragment<AboutFahesViewModel, FragmentAboutFahesBinding>(FragmentAboutFahesBinding::inflate) {

    override val viewModel: AboutFahesViewModel by injectViewModel()
    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    override fun initViews() {
        fahesComponent.inject(this)
        disableDefaultBackPress(true)
        initClickListeners()
        viewModel.getStaticText(ABOUT_FAHES.name)
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.FAHES, null)
    }

    override fun initObservers() {
        viewModel.resultStaticScreen.observe(this) {
            it.result?.let { staticText ->
                binding.tvAboutFahesDesc.loadStaticWebView(
                    staticText.content,
                    isArabicLanguage = languageUtils.isArabicLanguage()
                )
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }
    }

    private fun initClickListeners() {
        binding.toolbarAboutFahes.btnToolbar.setOnClickListener {
            onBackPressCustomAction()
        }
    }
}