package com.woqod.fahes.domain.models

data class VehiculeRegistrationModel(
    val shouldGetUserConfirmationToProceed: Boolean,
    val confirmationPromptMsg: String,

)
