package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.AppointmentDatesModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetAppointmentDatesUseCase @Inject constructor(
    private val fahesRepo: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<SharedResponse<List<AppointmentDatesModel>>>> {

    override suspend operator fun invoke(request: HashMap<String, Any>) =
        fahesRepo.getAppointmentDatesByStation(request)
}