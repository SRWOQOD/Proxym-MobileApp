package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


class GetReservationsReschedulingUseCase @Inject constructor(
    private val fahesRepository: FahesRepository
) : BaseUseCaseWithRequest<String, WoqodResult<SharedResponse<Long>>> {

    override suspend operator fun invoke(reservationId: String) =
        fahesRepository.rescheduleReservation(reservationId)

}