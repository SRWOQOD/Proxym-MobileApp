package com.woqod.fahes.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.fahes.domain.models.CategoryModel
import com.woqod.fahes.domain.models.ReceiptModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper
import com.woqod.shared.commundata.models.CarResponse
import com.woqod.shared.commundomain.models.CarModel

data class ReceiptResponse(
    val id: Int?,
    @SerializedName("ws_status") val wsStatus: String?,
    @SerializedName("discount_info") val discountInfo: String?,
    @SerializedName("service_category") val serviceCategory: String?,
    val userNameAr: String?,
    @SerializedName("initial_amount") val initialAmount: Int?,
    @SerializedName("creation_date") val creationDate: String?,
    @SerializedName("reference_number") val referenceNumber: String?,
    val qid: String?,
    @SerializedName("error_no") val errorNo: String?,
    val userNameEn: String?,
    val transactionUUID: String?,
    @SerializedName("pay_status") val payStatus: String?,
    val car: CarResponse?,
    @SerializedName("error_en") val errorEn: String?,
    @SerializedName("final_amount") val finalAmount: Int?,
    val category: CategoryResponse?,
    @SerializedName("mobile_number") val mobileNumber: Int?,
    val receipturl: String?,
    @SerializedName("barcode_reference") val barcodeReference: String?,
    @SerializedName("inspection_type") val inspectionType: String?,
    val barcode: String?,
    @SerializedName("error_ar") val errorAr: String?
) : DomainMapper<ReceiptModel> {
    override fun mapToDomainModel() = ReceiptModel(
        id ?: 0,
        wsStatus ?: "",
        discountInfo ?: "",
        serviceCategory ?: "",
        (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) userNameAr else userNameEn) ?: "",
        initialAmount ?: 0,
        creationDate ?: "",
        referenceNumber ?: "",
        qid ?: "",
        errorNo ?: "",
        transactionUUID ?: "",
        payStatus ?: "",
        car?.mapToDomainModel() ?: CarModel(),
        (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) errorAr else errorEn) ?: "",
        finalAmount ?: 0,
        category?.mapToDomainModel() ?: CategoryModel(),
        mobileNumber ?: 0,
        receipturl ?: "",
        barcodeReference ?: "",
        inspectionType ?: "",
        barcode ?: ""
    )
}

data class CategoryResponse(
    @SerializedName("pre_registrations") val preRegistrations: String?,
    @SerializedName("name_ar") val nameAr: String?,
    @SerializedName("name_en") val nameEn: String?,
    val fee: Int?,
    val _id: Int?,
    val id: String?
) : DomainMapper<CategoryModel> {
    override fun mapToDomainModel() = CategoryModel(
        preRegistrations ?: "",
        fee ?: 0,
        _id ?: 0,
        id ?: "",
        (if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) nameAr else nameEn) ?: ""
    )

}