package com.woqod.fahes.di.module

import com.woqod.fahes.data.datasource.FahesDataSourceImpl
import com.woqod.fahes.data.repository.FahesRepositoryImpl
import com.woqod.fahes.di.scope.FahesScope
import com.woqod.fahes.domain.repository.FahesRepository
import dagger.Module
import dagger.Provides

@Module
object RepositoriesModule {

    @Provides
    @FahesScope
    fun provideFahesRepository(): FahesRepository {
        val fahesDataSourceImpl = FahesDataSourceImpl()
        return FahesRepositoryImpl(fahesDataSourceImpl)
    }

}