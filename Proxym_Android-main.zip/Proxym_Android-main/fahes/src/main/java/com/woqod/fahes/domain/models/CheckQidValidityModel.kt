package com.woqod.fahes.domain.models

import java.io.Serializable


data class CheckQidValidityModel(
    val type: String,
    val success: Boolean
): Serializable