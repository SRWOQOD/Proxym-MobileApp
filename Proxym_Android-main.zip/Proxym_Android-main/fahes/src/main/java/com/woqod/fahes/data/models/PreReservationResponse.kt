package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.PreReservationModel
import com.woqod.shared.commundata.DomainMapper

data class PreReservationResponse(
    val otpRetriesLeftCount: String?,
    val preReservationReferenceId: Long?
) : DomainMapper<PreReservationModel> {
    override fun mapToDomainModel() = PreReservationModel(
        otpRetriesLeftCount = otpRetriesLeftCount ?: "1",
        preReservationReferenceId = preReservationReferenceId
    )
}
