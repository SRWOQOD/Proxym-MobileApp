package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


open class SendMailUseCase @Inject constructor(
    private val appRepository: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<SharedResponse<Boolean>>> {

    override suspend fun invoke(request: HashMap<String, Any>) = appRepository.sendMail(request)
}