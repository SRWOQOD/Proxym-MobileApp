package com.woqod.fahes.domain.models

import com.woqod.shared.commundomain.models.CarModel


data class AddCarModel(
    val car:CarModel,
    val qid:String,
    val pinCode:String
)