package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import javax.inject.Inject


class GetCarInspectionFeeUseCase @Inject constructor(
    private val fahesRepository: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<SharedResponse<PreRegistrationFeeModel>>> {

    override suspend operator fun invoke(request: HashMap<String, Any>) = fahesRepository.getCarInspectionFee(request)
}