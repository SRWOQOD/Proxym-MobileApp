package com.woqod.fahes.data.datasource

import com.woqod.fahes.data.models.*
import com.woqod.shared.commundata.models.CarResponse
import com.woqod.shared.commundata.models.PreRegistrationFeeResponse
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult


interface FahesDataSource {

    suspend fun getPlateTypeWithShape(): WoqodResult<SharedResponse<List<PlateTypeWithShapeResponse>>>
    suspend fun postPreReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<PreReservationResponse>>
    suspend fun postFahesOtp(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getBookingAvailableStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AvailableStationResponse>>>
    suspend fun getAppointmentDatesByStation(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AppointmentDatesResponse>>>
    suspend fun getReservationTimeSlots(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TimeSlotsResponse>>>
    suspend fun postReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<ReservationResponse>>

    suspend fun getFahesPlateTypes(): WoqodResult<SharedResponse<List<FahesPlateTypesResponse>>>
    suspend fun getFahesInspection(query: HashMap<String, Any>): WoqodResult<SharedResponse<FahesInspectionResponse>>
    suspend fun getFahesInspectionDetails(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<InspectionDetailsResponse>>>
    suspend fun getFahesListReceipts(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<ReceiptResponse>>>
    suspend fun getCheckCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>>
    suspend fun checkIsOwnerCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>>
    suspend fun getIsOwnerAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>>
    suspend fun getCarsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<CarResponse>>>
    suspend fun updateCarStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getCarInspectionFee(request: HashMap<String, Any>): WoqodResult<SharedResponse<PreRegistrationFeeResponse>>
    suspend fun postAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postUpdateCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun createTransactionUUID(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun createTransactionUUIDForDebitCard(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendMail(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun createFreeTransaction(request: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptResponse>>
    suspend fun paymentSuccess(query: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptResponse>>
    suspend fun updateTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun generatePDF(refNumber : String) :WoqodResult<SharedResponse<String>>
    suspend fun  getAvailableReservation(qid : String) : WoqodResult<SharedResponse<List<ReservationResponse>>>
    suspend fun  getAvailableReservationGuest(query: HashMap<String, Any>) : WoqodResult<SharedResponse<ReservationResponse>>
    suspend fun rescheduleReservation(reservationId : String) : WoqodResult<SharedResponse<Long>>
    suspend fun cancelReservation(query : HashMap<String,String>) :  WoqodResult<SharedResponse<Boolean>>
    suspend fun resendReservationOtp(query : HashMap<String,String>) :  WoqodResult<SharedResponse<Boolean>>
    suspend fun canPayOnline(query : HashMap<String,Any>) :  WoqodResult<SharedResponse<Boolean>>
    suspend fun checkRegistrationValidity(query : HashMap<String,Any>) :  WoqodResult<SharedResponse<VehiculeRegistrationResponse>>
    suspend fun canProceedToBooking(query : HashMap<String,Any>) : WoqodResult<SharedResponse<CarResponse>>
    suspend fun cancelTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>


}