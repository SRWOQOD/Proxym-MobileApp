package com.woqod.fahes.presentation.booking


import android.text.InputType
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.woqod.fahes.R
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.FragmentCancelModifyBookingGuestBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.GuestInspectionRequestModel
import com.woqod.fahes.domain.models.InspectionRegisterModel
import com.woqod.fahes.domain.models.PlateTypeWithShapeModel
import com.woqod.fahes.domain.models.ReservationModel
import com.woqod.fahes.presentation.utils.BookingDetailsModel
import com.woqod.fahes.presentation.utils.BookingDetailsPopUp
import com.woqod.fahes.presentation.utils.FahesBookingNavigationModel
import com.woqod.fahes.presentation.utils.FahesPreRegisterNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import com.woqod.shared.utils.FAHES_RESERVATION_ID
import com.woqod.shared.widget.PopUpType
import java.time.format.DateTimeFormatter

class FahesCancelModifyGuest :
    BaseViewModelFragment<FahesBookingViewModel, FragmentCancelModifyBookingGuestBinding>(
        FragmentCancelModifyBookingGuestBinding::inflate
    ) {

    private var plateType: String = EMPTY_FIELD
    private var plateTypeId: String = EMPTY_FIELD
    private var customerType: String = INDIVIDUAL_CUSTOMER
    private var inspectionCar: CarModel? = null
    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }

    private val container: ViewGroup by lazy { activity.findViewById<View>(android.R.id.content) as ViewGroup }
    private lateinit var popUpBookingDetails: BookingDetailsPopUp

    override val viewModel: FahesBookingViewModel by injectViewModel()


    override fun initObservers() {
        viewModel.resultPlateTypesWithShape.observe(this) {
            it.result?.let { platesWithShape -> initPLateTypes(platesWithShape) }
        }

        viewModel.onCheckValiditySuccess.observe(this, {
            it.result?.let { result -> onCheckValiditySuccess(result) }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        })

        viewModel.resultReservationRescheduling.observe(this) {
            FahesCache.bookingDetails = com.woqod.fahes.domain.models.BookingDetailsModel(
             "",
                binding.etFahesCancelBookingMobile.getValue()?:"",
                binding.etFahesCancelBookingQid.getValue() ?:"",
                binding.etFahesCancelBookingCarPlate.getValue() ?:"",
                plateTypeId

            )
            it.result?.let { newReservationId ->
                viewModel.navigate(
                    Navigation.FAHES_BOOKING_DATE,
                    FahesBookingNavigationModel(newReservationId, customerType)
                )

            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }


        viewModel.resultAvailableReservationGuest.observe(this) {
            it.result?.let { reservation ->
                if (listOf(reservation).isEmpty()) togglePopUp(
                    getString(R.string.FahesListOfReservationNoReservationFound),
                    action = {
                        viewModel.navigate(Navigation.FAHES, null)
                    }) else
                    onGetReservationSuccess(listOf(reservation))
            
            }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true)
            }
        }

        viewModel.resultCancelReservation.observe(this) {
            it.result?.let { isCanceled ->
                if (isCanceled)
                    togglePopUp(
                        message = getString(R.string.FahesBookingDetailsCancelBookingSuccessMessage),
                        { viewModel.navigate(Navigation.FAHES, null) },
                        popUpType = PopUpType.POPUP_SUCCESS
                    )
                else {
                    viewModel.navigate(Navigation.FAHES, null)
                }

            }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true, action = {  viewModel.navigate(Navigation.FAHES, null)
                })

            }
        }

        viewModel.onCheckIsOwnerCar.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetCarDetails(result) }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true, action = {
                    viewModel.navigate(Navigation.FAHES, null)
                })
            }
        })

        viewModel.onGetFee.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetFee(result) }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true, action = {
                    viewModel.navigate(Navigation.FAHES, null)
                })
            }
        })
    }

    private fun onGetFee(preRegistrationFeeModel: PreRegistrationFeeModel) {
        container.removeView(popUpBookingDetails)
        with(preRegistrationFeeModel) {
            if (category.fee >= 0.0) {
                FahesCache.inspectionDetails = InspectionRegisterModel(
                    inspectionCar!!,
                    preRegistrationFeeModel,
                    createGuestModel()
                )
                viewModel.navigate(
                    Navigation.FAHES_PRE_REGISTRATION_CONFIRMATION,
                    FahesPreRegisterNavigationModel(false)
                )
            } else {
                toast("navigate to payment directly")
            }
        }
    }

    private fun onGetCarDetails(car: CarModel) {
            inspectionCar = car
            viewModel.getCarInspectionFee(
                hashMapOf(
                    QID to (binding.etFahesCancelBookingQid),
                    PLATE_NUMBER to (binding.etFahesCancelBookingCarPlate),
                    PLATE_TYPE_ID to (plateTypeId)
                )
            )
    }

    private fun onGetReservationSuccess(reservations: List<ReservationModel>) {

        toggleDetailsPopUp(reservations.first())

    }

    private fun initPLateTypes(plateTypes: List<PlateTypeWithShapeModel>) {
        val plateTypeList =  plateTypes.map { it.plateTypeName }
        with(binding.spinnerFahesGuestPlateType) {
            initSpinner(
                activity,
                plateTypeList) {
                plateType = it
                if (plateType == context?.resources?.getString(com.woqod.shared.R.string.FahesDiplomaticTypeTitle)) {
                    binding.etFahesCancelBookingCarPlate.setInputType(InputType.TYPE_CLASS_TEXT)
                    binding.etFahesCancelBookingCarPlate.setMaxInputLength(7)
                } else {
                    binding.etFahesCancelBookingCarPlate.setInputType(InputType.TYPE_CLASS_NUMBER)
                    binding.etFahesCancelBookingCarPlate.setMaxInputLength(6)
                }
                binding.etFahesCancelBookingCarPlate.hideError()
                plateTypeId =
                    plateTypes.find { it.plateTypeName == plateType }?.plateTypeId.toString()
            }
          // setValue(plateTypeList.first())
        }

    }

    override fun initViews() {
        fahesComponent.inject(this)
        popUpBookingDetails = BookingDetailsPopUp(requireContext()).apply {
            container.addView(this)
            hide()
        }
        viewModel.getPlateTypeWithShape()
        disableDefaultBackPress(true)
        initCustomerTypeSpinners()
        initCLickListeners()

    }

    override fun onBackPressCustomAction() {
        if(this::popUpBookingDetails.isInitialized &&!popUpBookingDetails.isVisible){
            viewModel.navigate(Navigation.FAHES, null)
        }
    }

    private fun initCustomerTypeSpinners() {
        val customerType = arrayListOf(
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeIndividual),
            getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
        )
        binding.spinnerFahesCrGuestCustomerType.initSpinner(
            activity,
            customerType
        ) { onSelectCustomerType(it) }
        binding.spinnerFahesCrGuestCustomerType.setValue(customerType.first())
    }

    private fun toggleDetailsPopUp(reservation: ReservationModel) {
        popUpBookingDetails.show()
        popUpBookingDetails.initBookingDetailsPopUpComponent(
            BookingDetailsModel(
                station = reservation.stationName,
                date = reservation.appointmentDate.toFormattedDate(DateTimeFormatter.ISO_LOCAL_DATE),
                time = reservation.slotTime,
                isNewBooking = false,
                canPayOnline = reservation.canPayOnline
            ),
            actionFirstButton = { viewModel.cancelReservation(hashMapOf(FAHES_RESERVATION_ID to reservation.reservationId)) },
            actionSecondButton = {
               viewModel.rescheduleReservation(reservation.reservationId)

            },
            actionThirdButton = { onPaymentProcess() },
            actionText = { viewModel.navigate(Navigation.FAHES, null) }
        )
    }

    private fun onPaymentProcess() {
        viewModel.checkIsOwnerCar(
            hashMapOf(
                QID to (binding.etFahesCancelBookingQid),
                PLATE_NUMBER to (binding.etFahesCancelBookingCarPlate),
                PLATE_TYPE_ID to (plateTypeId)
            )
        )

    }

    private fun onSelectCustomerType(customer: String) {
        if (customer == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)) {
            binding.etFahesCancelBookingQid.setTitle(getString(R.string.FahesInspectionPreRegistrationCompanyId))
            binding.etFahesCancelBookingQid.setMaxInputLength(10)
            binding.etFahesCancelBookingQid.setInputType(InputType.TYPE_CLASS_TEXT)
            customerType = CORPORATE_CUSTOMER

        } else {
            binding.etFahesCancelBookingQid.setTitle(getString(R.string.CommonQid))
            binding.etFahesCancelBookingQid.setMaxInputLength(11)
            binding.etFahesCancelBookingQid.setInputType(InputType.TYPE_CLASS_NUMBER)
            customerType = INDIVIDUAL_CUSTOMER
        }.also {
            resetCustomerType()

        }
    }

    private fun resetCustomerType() {
        binding.etFahesCancelBookingQid.resetValue()
        resetErrors(
            binding.etFahesCancelBookingQid
        )
    }


    private fun initCLickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }

        binding.tvFahesCancelBookingProceed.setOnClickListener {
            if (validateInputs()) {
                FahesCache.guestDetails = createGuestModel()
                viewModel.checkQidValidity(
                    hashMapOf(
                        QID to binding.etFahesCancelBookingQid,
                        NUMBER to binding.etFahesCancelBookingMobile
                    )
                )
            }
        }
    }

    private fun createGuestModel() = GuestInspectionRequestModel(
        customerType,
        binding.etFahesCancelBookingQid.getValue(),
        binding.etFahesCancelBookingMobile.getValue(),
        binding.etFahesCancelBookingCarPlate.getValue(),
        plateTypeId.toInt(),
        FahesCache.guestDetails?.email ?: "",
        customerType == getString(R.string.FahesInspectionPreRegistrationCustomerTypeCorporate)
    )

    private fun onCheckValiditySuccess(state: Boolean) {

        if (state) viewModel.getAvailableReservationGuest(  hashMapOf(
            MOBILE_NUMBER to (binding.etFahesCancelBookingMobile.getValue()),
            CUSTOMER_ID to (binding.etFahesCancelBookingQid.getValue().encode64()),
            PLATE_NUMBER_UPPER to (binding.etFahesCancelBookingCarPlate.getValue()),
            RESERVATION_PLATE_TYPE_ID to (plateTypeId)
        ))
    }

    private fun validateInputs(): Boolean {
        var validate = true
        with(binding) {
            val qidError = ValidationsUtils.isIdValid(
                binding.etFahesCancelBookingQid.getValue(),
                customerType != INDIVIDUAL_CUSTOMER
            )
            val mobileError = ValidationsUtils.isMobileValid(etFahesCancelBookingMobile.getValue())
            val carPlateError =
                ValidationsUtils.isCarPlateValid(etFahesCancelBookingCarPlate.getValue(),spinnerFahesGuestPlateType.getValue(),context)
            val carPlateType =
                ValidationsUtils.isCarPlateTypeValid(spinnerFahesGuestPlateType.getValue())
            val emailError = if (binding.etFahesGuestCancelEmail.getValue().isNotEmpty()) {ValidationsUtils.isEmailValid(binding.etFahesGuestCancelEmail.getValue())}
            else 0
            if (qidError != 0) {
                validate = false
                etFahesCancelBookingQid.showError(getString(qidError))
            }
            if (mobileError != 0) {
                validate = false
                etFahesCancelBookingMobile.showError(getString(mobileError))
            }

            if (emailError != 0) {
                validate = false
                etFahesGuestCancelEmail.showError(getString(emailError))
            }
            if (carPlateError != 0) {
                validate = false
                etFahesCancelBookingCarPlate.showError(getString(carPlateError))
            }

            if (carPlateType != 0) {
                validate = false
                spinnerFahesGuestPlateType.setError(getString(carPlateType))
            }

        }
        return validate
    }


}
