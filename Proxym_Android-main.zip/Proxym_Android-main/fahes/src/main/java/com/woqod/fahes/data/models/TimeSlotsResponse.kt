package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.TimeSlotsModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class TimeSlotsResponse(
    val hourFrom: String?,
    val hourTo: String?,
    val slotTimeEn: String?,
    val slotTimeAr: String?,
    val id: Long?
) : DomainMapper<TimeSlotsModel> {
    override fun mapToDomainModel() = TimeSlotsModel(
        hourTo = hourTo ?: "0",
        hourFrom = hourFrom ?: "0",
        slotTime = (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) slotTimeAr else slotTimeEn) ?: "",
        id = id?.toString() ?: "0"
    )
}
