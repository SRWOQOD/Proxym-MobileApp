package com.woqod.fahes.di.component

import com.woqod.fahes.di.module.RepositoriesModule
import com.woqod.fahes.di.module.ViewModelModule
import com.woqod.fahes.di.scope.FahesScope
import com.woqod.fahes.presentation.about.AboutFahesFragment
import com.woqod.fahes.presentation.booking.*
import com.woqod.fahes.presentation.inspection_payment.payment.FahesPaymentFragment
import com.woqod.fahes.presentation.inspection_payment.payment.FahesReceiptFragment
import com.woqod.fahes.presentation.inspection_payment.pre_registration.*
import com.woqod.fahes.presentation.inspection_report.details.InspectionDetailsFragment
import com.woqod.fahes.presentation.inspection_report.list_cars.FahesInspectionReportFragment
import com.woqod.fahes.presentation.inspection_tips.InspectionTipsFragment
import com.woqod.fahes.presentation.list_receipts.ListReceiptsFragment
import com.woqod.fahes.presentation.menu.FahesMenuFragment
import com.woqod.shared.WoqodApplication
import com.woqod.shared.di.component.SharedComponent
import dagger.Component

@FahesScope
@Component(
    modules = [ViewModelModule::class, RepositoriesModule::class],
    dependencies = [SharedComponent::class]
)
interface FahesComponent {

    fun inject(aboutFahesFragment: AboutFahesFragment)
    fun inject(inspectionTipsFragment: InspectionTipsFragment)
    fun inject(fahesFragment: FahesMenuFragment)
    fun inject(inspectionDetailsFragment: InspectionDetailsFragment)
    fun inject(listReceiptsFragment: ListReceiptsFragment)
    fun inject(fahesInspectionReportFragment: FahesInspectionReportFragment)
    fun inject(guestInspectionRequestFragment: FahesGuestPreRegisterFragment)
    fun inject(userInspectionRequestFragment: UserVehicleListFragment)
    fun inject(carRegistrationConfirmationFragment: CarRegistrationConfirmationFragment)
    fun inject(fahesInspectionRegisterFragment: FahesPreRegisterConfirmFragment)
    fun inject(fahesInspectionPaymentMethodFragment: FahesPaymentFragment)
    fun inject(fahesPaymentFragment: FahesReceiptFragment)
    fun inject(fahesBookingCarInfoFragment: FahesBookingCarInfoFragment)
    fun inject(fahesBookingDateFragment: FahesBookingDateFragment)
    fun inject(fahesBookingOtpFragment: FahesBookingOtpFragment)
    fun inject(fahesCancelModifyBookingList: FahesCancelModifyBookingList)
    fun inject(fahesCancelModifyBooking: FahesCancelModifyBooking)
    fun inject(fahesPreRegistrationOtpFragment: FahesPreRegistrationOtpFragment)
    fun inject(fahesCancelModifyGuest: FahesCancelModifyGuest)

    @Component.Factory
    interface FahesComponentFactory {
        fun create(sharedComponent: SharedComponent): FahesComponent
    }

}


object GetFahesComponent {

    @Volatile
    private var INSTANCE: FahesComponent? = null

    fun getInstance(): FahesComponent =
        INSTANCE ?: synchronized(this) {
            INSTANCE ?: DaggerFahesComponent.factory().create(WoqodApplication.sharedComponent)
                .also { INSTANCE = it }
        }
}