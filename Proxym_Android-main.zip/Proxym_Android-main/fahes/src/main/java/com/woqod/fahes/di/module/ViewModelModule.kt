package com.woqod.fahes.di.module

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.woqod.fahes.presentation.about.AboutFahesViewModel
import com.woqod.fahes.presentation.booking.FahesBookingViewModel
import com.woqod.fahes.presentation.inspection_payment.payment.FahesPaymentViewModel
import com.woqod.fahes.presentation.inspection_payment.pre_registration.FahesPreRegisterViewModel
import com.woqod.fahes.presentation.inspection_report.details.InspectionDetailsViewModel
import com.woqod.fahes.presentation.inspection_report.list_cars.InspectionReportViewModel
import com.woqod.fahes.presentation.inspection_tips.InspectionTipsViewModel
import com.woqod.fahes.presentation.list_receipts.ListReceiptsViewModel
import com.woqod.fahes.presentation.menu.FahesViewModel
import com.woqod.shared.di.annotations.ViewModelKey
import com.woqod.shared.di.viewmodels.DaggerViewModelFactory
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap


@Module
@Suppress("UNUSED")
abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(FahesViewModel::class)
    abstract fun bindFahesVM(fahesViewModel: FahesViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(FahesPreRegisterViewModel::class)
    abstract fun bindFahesPreRegisterVM(fahesPreRegisterViewModel: FahesPreRegisterViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(AboutFahesViewModel::class)
    abstract fun bindAboutFahesVM(aboutFahesViewModel: AboutFahesViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(InspectionTipsViewModel::class)
    abstract fun bindInspectionTipsVM(inspectionTipsViewModel: InspectionTipsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(ListReceiptsViewModel::class)
    abstract fun bindListReceiptsVM(listReceiptsViewModel: ListReceiptsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(InspectionReportViewModel::class)
    abstract fun bindInspectionReportVM(inspectionReportViewModel: InspectionReportViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(InspectionDetailsViewModel::class)
    abstract fun bindInspectionDetailsVM(inspectionDetailsViewModel: InspectionDetailsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(FahesPaymentViewModel::class)
    abstract fun bindFahesPaymentVM(fahesPaymentViewModel: FahesPaymentViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(FahesBookingViewModel::class)
    abstract fun bindFahesBookingVM(fahesBookingViewModel: FahesBookingViewModel): ViewModel

    @Binds
    abstract fun bindViewModelFactory(factory: DaggerViewModelFactory): ViewModelProvider.Factory

}