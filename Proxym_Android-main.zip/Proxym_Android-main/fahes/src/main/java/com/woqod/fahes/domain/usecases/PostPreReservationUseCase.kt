package com.woqod.fahes.domain.usecases

import com.woqod.fahes.domain.models.PreReservationModel
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class PostPreReservationUseCase @Inject constructor(
    private val fahesRepo: FahesRepository
) : BaseUseCaseWithRequest<HashMap<String, String>, WoqodResult<SharedResponse<PreReservationModel>>> {

    override suspend fun invoke(request: HashMap<String, String>) = fahesRepo.postPreReservation(request)
}