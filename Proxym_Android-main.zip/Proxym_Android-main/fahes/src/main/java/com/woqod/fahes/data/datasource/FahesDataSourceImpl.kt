package com.woqod.fahes.data.datasource

import com.google.gson.Gson
import com.woqod.fahes.data.*
import com.woqod.fahes.data.models.*
import com.woqod.shared.commun.CUSTOMER_ID
import com.woqod.shared.commun.REFERENCE_NUMBER
import com.woqod.shared.commun.RESERVATION_ID
import com.woqod.shared.commundata.fromJsonToObjectType
import com.woqod.shared.commundata.getRequest
import com.woqod.shared.commundata.models.CarResponse
import com.woqod.shared.commundata.models.PreRegistrationFeeResponse
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundata.postRequest
import com.woqod.shared.commundata.verifySuccessCode
import com.woqod.shared.commundomain.WoqodResult
import com.worklight.wlclient.api.WLResourceRequest

class FahesDataSourceImpl : FahesDataSource {



    override suspend fun getPlateTypeWithShape(): WoqodResult<SharedResponse<List<PlateTypeWithShapeResponse>>> =
        when (val result = getRequest(GET_FAHES_BOOKING_PLATE_TYPE_WITH_SHAPE_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postPreReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<PreReservationResponse>> =
        when (val result = postRequest(POST_FAHES_PRE_RESERVATION, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postFahesOtp(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_FAHES_OTP, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getBookingAvailableStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AvailableStationResponse>>> =
        when (val result = postRequest(GET_AVAILABLE_STATIONS, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAppointmentDatesByStation(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AppointmentDatesResponse>>> =
        when (val result = postRequest(GET_APPOINTMENT_DATES_BY_STATION, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getReservationTimeSlots(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TimeSlotsResponse>>> =
        when (val result = postRequest(GET_RESERVATION_TIME_SLOTS, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<ReservationResponse>> =
        when (val result = postRequest(POST_FAHES_RESERVATION, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getFahesPlateTypes(): WoqodResult<SharedResponse<List<FahesPlateTypesResponse>>> =
        when (val result = getRequest(GET_FAHES_PLATE_TYPES_URL)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun getFahesInspection(query: HashMap<String, Any>): WoqodResult<SharedResponse<FahesInspectionResponse>> {
        return when (val result = postRequest(GET_FAHES_INSPECTION_DETAILS_URL, query)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getFahesInspectionDetails(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<InspectionDetailsResponse>>> {
        return when (val result = postRequest(GET_FAHES_INSPECTION_DETAILS, query)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getFahesListReceipts(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<ReceiptResponse>>> {
        return when (val result = postRequest(GET_FAHES_LIST_RECEIPTS_URL, query)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getCheckCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>> =
        when (val result = postRequest(GET_CHECK_CAR, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun checkIsOwnerCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>> =
        when (val result = postRequest(GET_CHECK_IS_OWNER_CAR, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getIsOwnerAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>> =
        when (val result = postRequest(GET_CHECK_IS_OWNER_ADD_CAR, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getCarsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<CarResponse>>> =
        when (val result = postRequest(GET_FAHES_CARS_LIST, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateCarStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result =
            postRequest(PUT_FAHES_UPDATE_CAR_STATUS, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getCarInspectionFee(request: HashMap<String, Any>): WoqodResult<SharedResponse<PreRegistrationFeeResponse>> =
        when (val result = postRequest(GET_FAHES_INSPECTION_FEE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_ADD_CAR, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postUpdateCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_UPDATE_CAR, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createTransactionUUID(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(SAVE_PRE_REGISTRATION, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createTransactionUUIDForDebitCard(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(SAVE_PRE_REGISTRATION_DEBIT_CARD, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun sendMail(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(FAHES_SEND_MAIL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createFreeTransaction(request: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptResponse>> =
        when (val result = postRequest(FAHES_TRANSACTION_FREE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun paymentSuccess(query: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptResponse>> =
        when (val result = postRequest(FAHES_PAYMENT_SUCCESS, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_UPDATE_TRANSACTION_UUID, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun cancelTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_CANCEL_TRANSACTION, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun generatePDF(refNumber: String): WoqodResult<SharedResponse<String>> =
        when (val result =
            postRequest(GET_FAHES_GENERATE_PDF, hashMapOf(REFERENCE_NUMBER to refNumber))) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAvailableReservation(qid: String): WoqodResult<SharedResponse<List<ReservationResponse>>> =
        when (val result = postRequest(GET_RESERVATION_DETAILS_BY_CUSTOMER, hashMapOf(CUSTOMER_ID to qid))) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAvailableReservationGuest(query: HashMap<String, Any>): WoqodResult<SharedResponse<ReservationResponse>> =
        when (val result = postRequest(GET_RESERVATION_DETAILS_BY_CUSTOMER_GUEST,  query)) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun rescheduleReservation(reservationId: String): WoqodResult<SharedResponse<Long>> =
        when (val result = postRequest(GET_RESERVATION_RESCHEDULING, hashMapOf(RESERVATION_ID to reservationId))) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun cancelReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_CANCEL_RESERVATION, query)) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun resendReservationOtp(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result =
            postRequest(POST_FAHES_RESERVATION_RESEND_OTP, query)) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun canPayOnline(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
    when (val result = postRequest(GET_CAN_PAY_ONLINE, query)) {
        is WoqodResult.Success ->
        verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
        is WoqodResult.Error -> WoqodResult.Error(result.exception)
    }

    override suspend fun checkRegistrationValidity(query: HashMap<String, Any>): WoqodResult<SharedResponse<VehiculeRegistrationResponse>> =
    when (val result = postRequest(POST_CHECK_REGISTRATION_VALIDITY, query)) {
        is WoqodResult.Success ->
        verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
        is WoqodResult.Error -> WoqodResult.Error(result.exception)
    }

    override suspend fun canProceedToBooking(query: HashMap<String, Any>): WoqodResult<SharedResponse<CarResponse>> =
        when (val result = postRequest(POST_CAN_PROCEED_TO_BOOKING, query)) {
            is WoqodResult.Success ->
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
}

