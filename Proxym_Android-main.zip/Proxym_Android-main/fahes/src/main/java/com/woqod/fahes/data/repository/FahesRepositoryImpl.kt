package com.woqod.fahes.data.repository

import com.woqod.fahes.data.datasource.FahesDataSource
import com.woqod.fahes.domain.models.*
import com.woqod.fahes.domain.repository.FahesRepository
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel

class FahesRepositoryImpl(private val fahesDataSource: FahesDataSource) : FahesRepository {

    override suspend fun getPlateTypeWithShape(): WoqodResult<SharedResponse<List<PlateTypeWithShapeModel>>> =
        when (val result = fahesDataSource.getPlateTypeWithShape()) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { plateTypeWithShape ->
                            plateTypeWithShape.mapToDomainModel()
                        })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postPreReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<PreReservationModel>> =
        when (val result = fahesDataSource.postPreReservation(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun postFahesOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.postFahesOtp(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAvailableStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AvailableStationModel>>> =
        when (val result = fahesDataSource.getBookingAvailableStations(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { it.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAppointmentDatesByStation(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<AppointmentDatesModel>>> =
        when (val result = fahesDataSource.getAppointmentDatesByStation(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { it.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getReservationTimeSlots(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TimeSlotsModel>>> =
        when (val result = fahesDataSource.getReservationTimeSlots(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { it.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<ReservationModel>> =
        when (val result = fahesDataSource.postReservation(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun getFahesPlateTypes(): WoqodResult<SharedResponse<List<FahesPlateTypesModel>>> {
        return when (val result = fahesDataSource.getFahesPlateTypes()) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { fahesPlateType -> fahesPlateType.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getFahesInspection(query: HashMap<String, Any>): WoqodResult<SharedResponse<FahesInspectionModel>> {
        return when (val result = fahesDataSource.getFahesInspection(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getFahesInspectionDetails(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<DefectModel>>> {
        return when (val result = fahesDataSource.getFahesInspectionDetails(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { it.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getFahesListReceipts(query: HashMap<String, Any>): WoqodResult<SharedResponse<List<ReceiptModel>>> {
        return when (val result = fahesDataSource.getFahesListReceipts(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { receipts -> receipts.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun checkCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>> =
        when (val result = fahesDataSource.getCheckCar(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun checkIsOwnerCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>> =
        when (val result = fahesDataSource.checkIsOwnerCar(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getIsOwnerAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>> =
        when (val result = fahesDataSource.getIsOwnerAddCar(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getCarsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<CarModel>>> =
        when (val result = fahesDataSource.getCarsList(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.map { it.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateCarStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.updateCarStatus(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getCarInspectionFee(request: HashMap<String, Any>): WoqodResult<SharedResponse<PreRegistrationFeeModel>> =
        when (val result = fahesDataSource.getCarInspectionFee(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postAddCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.postAddCar(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postUpdateCar(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.postUpdateCar(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createTransactionUUID(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.createTransactionUUID(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createTransactionUUIDForDebitCard(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.createTransactionUUIDForDebitCard(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun sendMail(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.sendMail(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun createFreeTransaction(request: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptModel>> =
        when (val result = fahesDataSource.createFreeTransaction(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun paymentSuccess(query: HashMap<String, String>): WoqodResult<SharedResponse<FahesReceiptModel>> =
        when (val result = fahesDataSource.paymentSuccess(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.updateTransaction(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun cancelTransaction(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.cancelTransaction(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getGeneratePDF(refNumber: String): WoqodResult<SharedResponse<String>> =
        when (val result = fahesDataSource.generatePDF(refNumber)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.substring(0))
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAvailableReservation(qid: String): WoqodResult<SharedResponse<List<ReservationModel>>> =
        when (val result = fahesDataSource.getAvailableReservation(qid)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.map { reservation -> reservation.mapToDomainModel() })
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAvailableReservationGuest(query: HashMap<String, Any>): WoqodResult<SharedResponse<ReservationModel>> =
        when (val result = fahesDataSource.getAvailableReservationGuest(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.mapToDomainModel()
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun rescheduleReservation(reservationId: String): WoqodResult<SharedResponse<Long>> =
        when (val result = fahesDataSource.rescheduleReservation(reservationId)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun cancelReservation(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.cancelReservation(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun resendReservationOtp(query: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.resendReservationOtp(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun canPayOnline(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = fahesDataSource.canPayOnline(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun checkRegistrationValidity(query: HashMap<String, Any>): WoqodResult<SharedResponse<VehiculeRegistrationModel>> =
        when (val result = fahesDataSource.checkRegistrationValidity(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun canProceedToBooking(query: HashMap<String, Any>): WoqodResult<SharedResponse<CarModel>> =
        when (val result = fahesDataSource.canProceedToBooking(query)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result.mapToDomainModel())
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
}

