package com.woqod.fahes.domain.models

data class AvailableStationModel(
    val name: String,
    val id: Int
)
