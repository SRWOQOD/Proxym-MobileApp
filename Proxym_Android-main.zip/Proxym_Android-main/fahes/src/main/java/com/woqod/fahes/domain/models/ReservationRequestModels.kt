package com.woqod.fahes.domain.models

data class PreReservationRequest(
    val mobileNumber: String,
    val plateNumber: String,
    val plateTypeId: String,
    val vehicleShapeId: String,
    val customerId: String
)