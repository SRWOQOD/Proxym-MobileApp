package com.woqod.fahes.cache

import com.woqod.fahes.domain.models.BookingDetailsModel
import com.woqod.fahes.domain.models.GuestInspectionRequestModel
import com.woqod.fahes.domain.models.InspectionRegisterModel
import com.woqod.fahes.domain.models.PaymentDetailsModel
import com.woqod.shared.commundomain.models.CarModel


object FahesCache {

    var inspectionDetails: InspectionRegisterModel? = null
    var paymentDetails: PaymentDetailsModel? = null
    var bookingDetails: BookingDetailsModel? = null
    var car: CarModel? = null
    var guestDetails : GuestInspectionRequestModel?= null


    fun clear() {
        inspectionDetails = null
        paymentDetails = null
        bookingDetails = null
        car = null
        guestDetails = null
    }

}