package com.woqod.fahes.presentation.booking

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.fahes.databinding.ItemReservationBinding
import com.woqod.fahes.domain.models.ReservationModel
import com.woqod.shared.baseui.BaseListAdapter
import com.woqod.shared.commun.extensions.toFormattedDate
import java.time.format.DateTimeFormatter


class UserReservationsAdapter(private val onClick: (ReservationModel) -> Unit) :
    BaseListAdapter<ReservationModel>(
        itemsSame = { old, new -> old == new },
        contentsSame = { old, new -> old == new }
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, inflater: LayoutInflater, viewType: Int) =
        ReservationViewHolder(ItemReservationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is ReservationViewHolder -> holder.bindTo(getItem(position))
            else -> throw IllegalStateException("Illegal ViewHolder Type")
        }
    }

    override fun submitList(list: List<ReservationModel>?) {
        super.submitList(list?.let { ArrayList(it) })
    }

    inner class ReservationViewHolder(view: ItemReservationBinding) : RecyclerView.ViewHolder(view.root) {

        private val tvReservationDate = view.tvReservationDate
        private val tvReservationTime = view.tvReservationTime
        private val tvStationName = view.tvStationNameValue
        private val tvCarPlate = view.tvCarPlateValue
        private val tvPlateType = view.tvPlateTypeValue

        fun bindTo(reservation: ReservationModel) {
            with(itemView) {
                tvReservationDate.text = reservation.appointmentDate.toFormattedDate(DateTimeFormatter.ISO_LOCAL_DATE)
                tvReservationTime.text = reservation.slotTime
                tvStationName.text = reservation.stationName
                tvCarPlate.text = reservation.plateNumber
                tvPlateType.text = reservation.plateTypeName


                setOnClickListener {
                    onClick(reservation)

                }
            }
        }
    }
}