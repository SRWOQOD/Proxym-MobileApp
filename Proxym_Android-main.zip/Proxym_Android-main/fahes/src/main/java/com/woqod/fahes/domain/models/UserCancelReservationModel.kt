package com.woqod.fahes.domain.models

import java.io.Serializable

data class UserCancelReservationModel(
    val fullName: String,
    val qid: String,
    val mobile: String,
    val customerType : String,
    val reservation : ReservationModel
):Serializable
