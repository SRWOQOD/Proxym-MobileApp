package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.VehiculeRegistrationModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class VehiculeRegistrationResponse(
    val shouldGetUserConfirmationToProceed: Boolean?,
    val confirmationPromptEn: String?,
    val confirmationPromptAr: String?
) : DomainMapper<VehiculeRegistrationModel> {
    override fun mapToDomainModel() = VehiculeRegistrationModel(
        shouldGetUserConfirmationToProceed = shouldGetUserConfirmationToProceed ?: false,
        confirmationPromptMsg = (if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) confirmationPromptAr else confirmationPromptEn) ?: ""
    )
}


