package com.woqod.fahes.presentation.booking


import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.woqod.fahes.R
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.databinding.FragmentCancelModifyBookingBinding
import com.woqod.fahes.di.component.FahesComponent
import com.woqod.fahes.di.component.GetFahesComponent
import com.woqod.fahes.domain.models.FahesCRGuestModel
import com.woqod.fahes.domain.models.InspectionRegisterModel
import com.woqod.fahes.domain.models.PlateTypeWithShapeModel
import com.woqod.fahes.domain.models.UserCancelReservationModel
import com.woqod.fahes.presentation.utils.BookingDetailsModel
import com.woqod.fahes.presentation.utils.BookingDetailsPopUp
import com.woqod.fahes.presentation.utils.FahesBookingNavigationModel
import com.woqod.fahes.presentation.utils.FahesPreRegisterNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commun.extensions.toFormattedDate
import com.woqod.shared.commun.extensions.toast
import com.woqod.shared.commundomain.models.CarModel
import com.woqod.shared.commundomain.models.PreRegistrationFeeModel
import com.woqod.shared.commundomain.models.UserDetailsModel
import com.woqod.shared.utils.FAHES_BOOK_ARGS
import com.woqod.shared.utils.FAHES_RESERVATION_ID
import com.woqod.shared.widget.PopUpType
import java.time.format.DateTimeFormatter

class FahesCancelModifyBooking :
    BaseViewModelFragment<FahesBookingViewModel, FragmentCancelModifyBookingBinding>(
        FragmentCancelModifyBookingBinding::inflate
    ) {

    private val fahesComponent: FahesComponent by lazy {
        GetFahesComponent.getInstance()
    }
    private val container: ViewGroup by lazy { activity.findViewById<View>(android.R.id.content) as ViewGroup }
    private lateinit var popUpBookingDetails: BookingDetailsPopUp
    override val viewModel: FahesBookingViewModel by injectViewModel()
    private var params: UserCancelReservationModel? = null
    private var guestUser: FahesCRGuestModel? = null
    private var inspectionCar: CarModel? = null
    private var plateTypeList = listOf<PlateTypeWithShapeModel>()

    fun newInstance(params: UserCancelReservationModel): FahesCancelModifyBooking {
        val args = Bundle()
        args.putSerializable(FAHES_BOOK_ARGS, params)
        val fragment = FahesCancelModifyBooking()
        fragment.arguments = args
        return fragment
    }

    override fun initObservers() {
        viewModel.resultPlateTypesWithShape.observe(viewLifecycleOwner, {
            it.result?.let { platesWithShape ->
                plateTypeList = platesWithShape
                   }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        })
        viewModel.resultReservationRescheduling.observe(this) {
            it.result?.let { newReservationId ->
                FahesCache.bookingDetails = com.woqod.fahes.domain.models.BookingDetailsModel(
                   params?.fullName?:"",
                    params?.mobile?:"",
                    params?.qid ?:"",
                    params?.reservation?.plateNumber?:"",
                    plateTypeList.find { it.plateTypeName == params?.reservation?.plateTypeName }?.plateTypeId.toString()

                )
                viewModel.navigate(
                    Navigation.FAHES_BOOKING_DATE,
                    FahesBookingNavigationModel(
                        newReservationId,
                        params?.customerType ?: INDIVIDUAL_CUSTOMER
                    )
                )
                // viewModel.navigate(Navigation.FAHES_BOOKING_DATE, FahesBookingNavigationModel(newReservationId, params?.customerType ?: INDIVIDUAL_CUSTOMER))
            }
            it.error?.let { error -> togglePopUp(error, isFahes = true) }
        }

        viewModel.resultCancelReservation.observe(this) {
            it.result?.let { isCanceled ->
                if (isCanceled)
                    togglePopUp(
                        message = getString(R.string.FahesBookingDetailsCancelBookingSuccessMessage),
                        {   viewModel.navigate(
                            Navigation.FAHES_CANCEL_BOOKING_LIST,
                            guestUser ?: FahesCRGuestModel()
                        ) },
                        popUpType = PopUpType.POPUP_SUCCESS
                    )

                else {
                    togglePopUp( getString(R.string.FahesBookingDetailsCancelBookingErrorMessage),{  viewModel.navigate(
                        Navigation.FAHES_CANCEL_BOOKING_LIST,
                        guestUser ?: FahesCRGuestModel()
                    )}, isFahes = true)


                }

            }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true)
                //viewModel.navigate(Navigation.FAHES_CANCEL_BOOKING_LIST, FahesCRGuestModel())
            }
        }
        viewModel.onGetFee.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetFee(result) }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true, action = {
                    viewModel.navigate(Navigation.FAHES, null)
                })
            }
        })
    }

    override fun initViews() {
        fahesComponent.inject(this)
        arguments?.let {
            params = it.getSerializable(FAHES_BOOK_ARGS) as UserCancelReservationModel
        }
        popUpBookingDetails = BookingDetailsPopUp(requireContext()).apply {
            container.addView(this)
            hide()
        }
        viewModel.getPlateTypeWithShape()

        disableDefaultBackPress(true)
        initFields()
        initCLickListeners()

    }

    override fun onBackPressCustomAction() {
        if(this::popUpBookingDetails.isInitialized && !popUpBookingDetails.isVisible){
            viewModel.navigate(Navigation.FAHES, null)
        }
    }

    private fun initCLickListeners() {
        binding.toolbarFahes.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.FAHES, null)
        }

        binding.tvFahesCancelBookingProceed.setOnClickListener {
            params?.let { toggleDetailsPopUp(it) }
        }
    }

    private fun toggleDetailsPopUp(details: UserCancelReservationModel) {
        popUpBookingDetails.show()
        popUpBookingDetails.initBookingDetailsPopUpComponent(
            BookingDetailsModel(
                station = details.reservation.stationName,
                date = details.reservation.appointmentDate.toFormattedDate(DateTimeFormatter.ISO_LOCAL_DATE),
                time = details.reservation.slotTime,
                isNewBooking = false,
                canPayOnline = details.reservation.canPayOnline
            ),
            actionFirstButton = { viewModel.cancelReservation(hashMapOf(FAHES_RESERVATION_ID to details.reservation.reservationId)) },
            actionSecondButton = { viewModel.rescheduleReservation(details.reservation.reservationId) },
            actionThirdButton = { onPaymentProcess() },
            actionText = { viewModel.navigate(Navigation.FAHES, null) }
        )
    }

    private fun onPaymentProcess() {
        viewModel.checkIsOwnerCar(
            hashMapOf(
                QID to (params?.qid ?: ""),
                PLATE_NUMBER to (params?.reservation?.plateNumber ?: ""),
                PLATE_TYPE_ID to (FahesCache.bookingDetails?.plateType ?: "")
            )
        )

        viewModel.onCheckIsOwnerCar.observe(viewLifecycleOwner, {
            it.result?.let { result -> onGetCarDetails(result) }
            it.error?.let { error ->
                togglePopUp(error, isFahes = true, action = {
                    viewModel.navigate(Navigation.FAHES, null)
                })
            }
        })
    }

    private fun onGetCarDetails(car: CarModel) {
            inspectionCar = car
            viewModel.getCarInspectionFee(
                hashMapOf(
                    QID to (params?.qid ?: ""),
                    PLATE_NUMBER to (params?.reservation?.plateNumber ?: ""),
                    PLATE_TYPE_ID to (FahesCache.bookingDetails?.plateType ?: "")
                )
            )
    }

    private fun onGetFee(preRegistrationFeeModel: PreRegistrationFeeModel) {
        container.removeView(popUpBookingDetails)
        with(preRegistrationFeeModel) {
            if (category.fee >= 0.0) {
                FahesCache.inspectionDetails =
                    InspectionRegisterModel(FahesCache.car!!, preRegistrationFeeModel, null)
                viewModel.navigate(
                    Navigation.FAHES_PRE_REGISTRATION_CONFIRMATION,
                    FahesPreRegisterNavigationModel(true)
                )
            } else {
                toast("navigate to payment directly")
            }
        }
    }


    private fun addUserInfo(user: UserDetailsModel) {
        with(binding) {
            etFahesCancelBookingQid.setValue(user.qid)
            etFahesCancelBookingMobile.setValue(user.mobileNumber)
            etFahesCancelBookingCarPlate.setValue(
                params?.reservation?.plateNumber ?: getString(R.string.CommonUndefinedValue)
            )
            etFahesCancelBookingPlateType.setValue(
                params?.reservation?.plateTypeName ?: getString(R.string.CommonUndefinedValue)
            )
        }
    }

    private fun initFields() {

        with(binding) {
            etFahesBookingCompanyId.hide()
            etFahesCancelBookingQid.show()
            etFahesCancelBookingPlateType.show()
            etFahesCancelBookingQid.isEnabled(false)
            etFahesCancelBookingMobile.isEnabled(false)
            etFahesCancelBookingCarPlate.isEnabled(false)
            etFahesCancelBookingPlateType.isEnabled(false)

            etFahesCancelBookingQid.inputIsMandatory= false
            etFahesCancelBookingMobile.inputIsMandatory= false
            etFahesCancelBookingCarPlate.inputIsMandatory= false
            etFahesCancelBookingPlateType.inputIsMandatory= false
        }
        sharedPreferences.user?.let {
            addUserInfo(it)
        }
    }
}
