package com.woqod.fahes.domain.models

data class ReservationModel(
    val reservationId: String,
    val stationName: String,
    val appointmentDate: String,
    val time: String,
    val slotTime: String,
    val canPayOnline: Boolean,
    val plateNumber: String,
    val plateTypeName: String
)
