package com.woqod.fahes.domain.models

import java.io.Serializable


data class GuestInspectionRequestModel(
    val customerType: String,
    val qid: String,
    val mobile: String,
    val carPlate: String,
    val plateTypeId: Int,
    val email: String,
    val isCorporate: Boolean
):Serializable