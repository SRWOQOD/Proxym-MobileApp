package com.woqod.fahes.presentation.booking

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.woqod.fahes.R
import com.woqod.fahes.databinding.ItemFahesBookingTimeBinding
import com.woqod.fahes.domain.models.TimeSlotsModel

class TimeSlotsAdapter(
    private var list: MutableList<TimeSlotsModel>,
    private val action: (TimeSlotsModel,String) -> Unit
) :
    RecyclerView.Adapter<TimeSlotsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemFahesBookingTimeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position], position)
    }

    private var checkedPosition = -1

    override fun getItemCount() = list.size

    fun updateList(list: List<TimeSlotsModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        checkedPosition = -1
        notifyDataSetChanged()
    }

    fun resetList() {
        this.list.clear()
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: ItemFahesBookingTimeBinding) : RecyclerView.ViewHolder(view.root) {
        private val time: TextView = view.tvItemTime
        private val btn: ImageView = view.ivItemTime

        fun bindTo(item: TimeSlotsModel, position: Int) {
            time.text = item.slotTime
            itemView.setOnClickListener {
                notifyItemChanged(checkedPosition) // to reset the view of the previous selected item
                checkedPosition = absoluteAdapterPosition
                notifyItemChanged(checkedPosition) // to update the view of the newly selected item
                action(list[absoluteAdapterPosition],time.text.toString())
            }
            if (checkedPosition == position) {
                btn.setImageResource(R.drawable.ic_time_slot_selected)
            } else {
                btn.setImageResource(R.drawable.ic_time_slots_unselected)
            }
        }
    }

}