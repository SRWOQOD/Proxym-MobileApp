package com.woqod.fahes.domain.models

import java.io.Serializable

data class FahesPlateTypesModel(
    val id: Int,
    val name: String
) : Serializable