package com.woqod.fahes.data.models

import com.woqod.fahes.domain.models.InspectionDiscountModel
import com.woqod.shared.commundata.DomainMapper

data class InspectionDiscountResponse(
    val id: Long?,
    val amount: Double?,
    val status: Boolean?,
    val fahesServiceEnum: String?,
    val paymentMethodEnum: String?,
    val paymentTypeEnum: String?,
    val min: Double?,
    val max: Double?
) : DomainMapper<InspectionDiscountModel> {
    override fun mapToDomainModel() = InspectionDiscountModel(
        id = id ?: 0L,
        amount = amount ?: 0.0,
        status = status ?: false,
        fahesService = fahesServiceEnum ?: "",
        paymentMethod = paymentMethodEnum ?: "",
        paymentType = paymentTypeEnum ?: "",
        min = min ?: 0.0,
        max = max ?: 0.0
    )
}