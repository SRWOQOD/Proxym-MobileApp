/**
 * Created by Hamdi.BOUMAIZA on 09/30/2020
 */

object DefaultConfig {
    const val compileSdk = 31
    const val minSdk = 26
    const val targetSdk = 31
    const val buildTools = "30.0.0"
    const val applicationId = "com.woqod.app"
}

object Releases {
    const val versionCode = 10784
    const val versionName = "2.2.0"
}