/**
 * Created by Hamdi.BOUMAIZA on 09/30/2020
 */
object Modules {
    const val shared = ":shared"
    const val authentication = ":authentication"
    const val fahes = ":fahes"
    const val woqode = ":woqode"
    const val shafaf = ":shafaf"
    const val account = ":account"
    const val feedback = ":feedback"
    const val sharedTest = ":sharedTest"
}