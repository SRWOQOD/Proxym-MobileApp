object ProjectDependencies {
    const val gradle = "com.android.tools.build:gradle:${Versions.gradle}"
    const val kotlinGradle = "org.jetbrains.kotlin:kotlin-gradle-plugin:${Versions.kotlin}"
    const val sonarQube = "org.sonarsource.scanner.gradle:sonarqube-gradle-plugin:${Versions.sonar}"
    const val googleServices = "com.google.gms:google-services:${Versions.googleServices}"
    const val firebaseCrashlyticsGradle = "com.google.firebase:firebase-crashlytics-gradle:${Versions.firebaseCrashlyticsGradle}"
}

object Libs {
    //kotlin
    const val kotlin = "org.jetbrains.kotlin:kotlin-stdlib-jdk7:${Versions.kotlin}"

    //UI
    const val appCompact = "androidx.appcompat:appcompat:${Versions.appCompact}"
    const val fragment = "androidx.fragment:fragment:${Versions.fragment}"
    const val ktx = "androidx.core:core-ktx:${Versions.KtxCore}"
    const val activityKtx = "androidx.activity:activity-ktx:${Versions.activityKtx}"
    const val fragmentKtx = "androidx.fragment:fragment-ktx:${Versions.fragemntKtx}"
    const val cardview = "androidx.cardview:cardview:${Versions.cardView}"
    const val recyclerView = "androidx.recyclerview:recyclerview:${Versions.recyclerView}"
    const val constraintLayout = "androidx.constraintlayout:constraintlayout:${Versions.constraintLayout}"
    const val materialDesign = "com.google.android.material:material:${Versions.googleMaterial}"
    const val splashScreen =  "androidx.core:core-splashscreen:${Versions.splashScreen}"



    //dagger
    const val dagger = "com.google.dagger:dagger:${Versions.dagger}"
    const val daggerCompiler = "com.google.dagger:dagger-compiler:${Versions.dagger}"

    //lifecycle
    const val lifecycleExtension = "androidx.lifecycle:lifecycle-extensions:${Versions.lifecycle}"
    const val lifecycleViewModel = "androidx.lifecycle:lifecycle-viewmodel-ktx:${Versions.lifecycle}"
    const val lifecycleRuntime = "androidx.lifecycle:lifecycle-runtime-ktx:${Versions.lifecycle}"

    //Coroutines
    const val coroutinesCore = "org.jetbrains.kotlinx:kotlinx-coroutines-core:${Versions.coroutine}"
    const val coroutinesAndroid = "org.jetbrains.kotlinx:kotlinx-coroutines-android:${Versions.coroutine}"

    const val timber = "com.jakewharton.timber:timber:${Versions.timber}"

    const val coil = "io.coil-kt:coil:${Versions.coil}"

    const val gson = "com.google.code.gson:gson:${Versions.gson}"

    const val securityEncryption = "androidx.security:security-crypto:${Versions.securityCrypto}"

    //mobileFirstSDK
    const val ibmMobileFirst = "com.ibm.mobile.foundation:ibmmobilefirstplatformfoundation:${Versions.ibmMobileFirst}"
    const val ibmMobileFirstPushNotification = "com.ibm.mobile.foundation:ibmmobilefirstplatformfoundationpush:${Versions.ibmMobileFirstPush}"

    //play services
    const val googleMaps = "com.google.android.gms:play-services-maps:${Versions.googleMaps}"
    const val googleLocation = "com.google.android.gms:play-services-location:${Versions.googleMaps}"
    const val googleMapClustering = "com.google.maps.android:android-maps-utils:${Versions.mapCluster}"

    const val firebaseMessaging = "com.google.firebase:firebase-messaging:${Versions.firebaseMessaging}"

    const val firebaseCrashlytics = "com.google.firebase:firebase-crashlytics:${Versions.firebaseCrashlytics}"

    const val easyPermission = "pub.devrel:easypermissions:${Versions.easyPermission}"

    const val biometrics = "androidx.biometric:biometric:${Versions.biometrics}"

    const val photoView = "com.github.chrisbanes:PhotoView:${Versions.photoView}"

    const val fetch = "androidx.tonyodev.fetch2:xfetch2:${Versions.fetch}"

    const val imageCompressor = "id.zelory:compressor:${Versions.imageCompressor}"

    const val otpView = "com.github.mukeshsolanki:android-otpview-pinview:${Versions.otpView}"

    const val exoPlayer = "com.google.android.exoplayer:exoplayer:${Versions.exoPlayer}"

    const val dotsIndicator = "com.tbuonomo:dotsindicator:${Versions.dotsIndicator}"

    const val shimmer = "com.facebook.shimmer:shimmer:${Versions.shimmer}"

    const val progressView = "com.github.skydoves:progressview:${Versions.progressView}"
    const val pdfViewer = "com.github.barteksc:android-pdf-viewer:${Versions.pdfViewer}"


}

object TestLibs {
    //Unit tests
    const val junit = "junit:junit:${Versions.junit}"
    const val androidxJunit = "androidx.test.ext:junit:${Versions.androidxJunit}"
    const val androidxJunitExtension = "androidx.test.ext:junit-ktx:${Versions.androidxJunit}"
    const val googleTruth = "com.google.truth:truth:${Versions.googleTruth}"
    const val coreTesting = "android.arch.core:core-testing:${Versions.coreTesting}"
    const val coroutineTest = "org.jetbrains.kotlinx:kotlinx-coroutines-test:${Versions.coroutine}"
    const val robolectric = "org.robolectric:robolectric:${Versions.robolectric}"
    const val mockk = "io.mockk:mockk:${Versions.mockk}"

    //UI Android Test
    const val testRunner = "androidx.test:runner:${Versions.testCoreRunner}"
    const val espresso = "com.android.support.test.espresso:espresso-core:${Versions.espresso}"
    const val barista = "com.schibsted.spain:barista:${Versions.barista}"
    const val excludeKotlin = "org.jetbrains.kotlin"
    const val fragmentTests = "androidx.fragment:fragment-testing:${Versions.fragmentTesting}"
}