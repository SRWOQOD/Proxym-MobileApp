package com.woqod.app.data.models

data class SurveyResponseRequest(val questionId: Int, val responses: List<String>)