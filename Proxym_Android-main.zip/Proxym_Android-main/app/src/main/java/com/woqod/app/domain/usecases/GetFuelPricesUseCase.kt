package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


typealias GetFuelPricesBaseUseCase = BaseUseCase<WoqodResult<SharedResponse<List<FuelPriceModel>>>>

open class GetFuelPricesUseCase @Inject constructor(
    private val appRepository: AppRepository
) : GetFuelPricesBaseUseCase {

    override suspend operator fun invoke() = appRepository.getFuelPrices()
}