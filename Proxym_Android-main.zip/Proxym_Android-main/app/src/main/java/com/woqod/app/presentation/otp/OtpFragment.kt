package com.woqod.app.presentation.otp

import android.os.Bundle
import com.woqod.app.databinding.FragmentOtpBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.presentation.notifications.registerDevice
import com.woqod.authentication.R
import com.woqod.authentication.presentation.UserChallengeHandler
import com.woqod.authentication.presentation.login.BiometricPromptUtils
import com.woqod.authentication.presentation.login.LoginWorkFlow
import com.woqod.authentication.presentation.register.RegistrationWorkFlow
import com.woqod.authentication.presentation.register.RegistrationWorkFlow.clearRegistrationCache
import com.woqod.authentication.utils.AuthenticationType.Companion.BIO_AUTH
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.asMinAndSec
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundata.IPADDRESS
import com.woqod.shared.utils.*
import com.woqod.shared.widget.PopUpType
import org.json.JSONObject
import timber.log.Timber
import java.util.*

class OtpFragment :
    BaseViewModelFragment<OtpViewModel, FragmentOtpBinding>(FragmentOtpBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: OtpViewModel by injectViewModel()

    private var params: HashMap<String, String>? = null

    fun newInstance(params: HashMap<String, String>): OtpFragment {
        val args = Bundle()
        args.putSerializable(OTP_ARGS, params)
        val fragment = OtpFragment()
        fragment.arguments = args
        return fragment
    }

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        appComponent.inject(this)
        binding.pinCodeComponent.initPinCodeObservers(this,
            doOnResend = { resendActivateCode() },
            doOnConfirm = { verifyOtp() },
            doOnHideKeyBoard = { hideKeyboard() })
        arguments?.let {
            if (it.containsKey(OTP_ARGS))
                params = it.getSerializable(OTP_ARGS) as HashMap<String, String>
        }

        binding.toolbarOtp.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }

    }


    override fun handleFragmentArgs() {
        params?.let {
            when (it[OTP_SOURCE]) {
                OTP_FOR_LOGIN -> {
                    viewModel.getOtp(LoginWorkFlow.username, LoginWorkFlow.connectionType)
                }
                OTP_FOR_BIOMETRIC, OTP_FOR_LOGIN_BIOMETRIC -> {
                    viewModel.getOtp(sharedPreferences.username, BIO_AUTH)
                }

                OTP_FOR_FORGET_PWD -> {
                    viewModel.sendRecoveryCode(LoginWorkFlow.username to LoginWorkFlow.connectionType)
                }
                OTP_FOR_RESET -> {
                    viewModel.getSecurityCode(sharedPreferences.username)
                }
                OTP_FOR_REGISTER -> togglePopUp(
                    getString(R.string.please_enter_the_code_sent_to_your_phone),
                    popUpType = PopUpType.POPUP_SUCCESS
                )
            }
        }
    }

    private fun verifyOtp() {
        params?.let {
            when (it[OTP_SOURCE]) {
                OTP_FOR_LOGIN -> {
                    viewModel.sendOtp(
                        LoginWorkFlow.username,
                        LoginWorkFlow.connectionType,
                        binding.pinCodeComponent.pinCode()
                    )
                }
                OTP_FOR_BIOMETRIC, OTP_FOR_LOGIN_BIOMETRIC -> {
                    viewModel.sendOtp(
                        sharedPreferences.username,
                        BIO_AUTH,
                        binding.pinCodeComponent.pinCode()
                    )
                }
                OTP_FOR_FORGET_PWD -> {
                    viewModel.checkRecoveryCode(
                        LoginWorkFlow.username to LoginWorkFlow.connectionType,
                        binding.pinCodeComponent.pinCode()
                    )
                }

                OTP_FOR_RESET -> {
                    viewModel.checkSecurityCodeValidity(
                        sharedPreferences.username,
                        binding.pinCodeComponent.pinCode()
                    )
                }
                OTP_FOR_REGISTER -> {
                    viewModel.activateAccount(
                        hashMapOf(
                            USERNAME to RegistrationWorkFlow.userName,
                            PIN_CODE_UPPER to binding.pinCodeComponent.pinCode(),
                            DEVICE_SERIAL to sharedPreferences.deviceId,
                            DEVICE_TYPE to DEVICE_TYPE_VALUE
                        )
                    )
                }
            }
        }
    }

    private fun resendActivateCode() {
        binding.pinCodeComponent.resetValues()
        params?.let {
            when (it[OTP_SOURCE]) {
                OTP_FOR_REGISTER -> {
                    viewModel.resendActivationCode(
                        hashMapOf(
                            USERNAME to RegistrationWorkFlow.userName,
                            LANGUAGE to languageUtils.getAppLanguage()
                        )
                    )
                }
                else -> handleFragmentArgs()
            }
        }
    }


    private fun handleBiometricAuthenticationSource() {
        params?.let {
            when (it[OTP_SOURCE]) {

                OTP_FOR_BIOMETRIC -> {
                    togglePopUp(getString(com.woqod.app.R.string.BiometricActivated), {
                        viewModel.navigate(Navigation.SETTINGS, null)
                    }, popUpType = PopUpType.POPUP_SUCCESS)
                }
                OTP_FOR_LOGIN_BIOMETRIC -> {
                    togglePopUp(getString(com.woqod.app.R.string.BiometricActivated), {
                        getProfilePhotoAndRedirect()
                    }, popUpType = PopUpType.POPUP_SUCCESS)
                }

            }
        }
    }

    override fun initObservers() {
        viewModel.onReceiveOtpCode.observe(viewLifecycleOwner) {
            it.error?.let { error ->
                togglePopUp(message = error, popUpType = PopUpType.POP_ERROR)
            }
        }
        viewModel.updatedBiometricStatus.observe(viewLifecycleOwner) {
            it.result?.let { isUpdated ->
                sharedPreferences.isBiometricActivated = isUpdated
                sharedPreferences.user =
                    sharedPreferences.user?.copy(isBiometricActivated = sharedPreferences.isBiometricActivated)
                handleBiometricAuthenticationSource()
            }

        }


        viewModel.onReceiveRecoveryCode.observe(viewLifecycleOwner) {
            it.error?.let { errorMsg ->
                togglePopUp(errorMsg, popUpType = PopUpType.POP_ERROR, action = {
                    viewModel.navigate(Navigation.LOGIN, null)
                })
            }
        }

        viewModel.onReceiveResetPinCode.observe(viewLifecycleOwner) {
            it.error?.let { errorMsg ->
                togglePopUp(errorMsg, popUpType = PopUpType.POP_ERROR)
            }
        }

        viewModel.onCheckOtpCode.observe(viewLifecycleOwner) {
            it.result?.let { isValid ->
                handleCheckOtpResult(isValid)
            }
            it.error?.let { errorMsg ->
                togglePopUp(errorMsg)
                resetPinCodeFields()
            }
        }

        viewModel.onCheckResetPinCode.observe(viewLifecycleOwner) {
            it.result?.let { isValid ->
                handleCheckOtpResult(isValid)
            }
            it.error?.let { errorMsg ->
                togglePopUp(errorMsg)
                resetPinCodeFields()
            }
        }

        viewModel.onCheckRecoveryCode.observe(viewLifecycleOwner) {
            it.result?.let { isValid ->
                handleCheckOtpResult(isValid)
            }
            it.error?.let { errorMsg ->
                togglePopUp(errorMsg)
                resetPinCodeFields()
            }
        }
        viewModel.resultBalanceInquiry.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                if (result.envelope.body.accountInquiryResponse.accountInquiryResult.responseGeneral.responseCode == "1") {
                    sharedPreferences.user = sharedPreferences.user?.copy(isWoqodeUser= true,accountInquiryModel = result)
                    viewModel.navigate(
                        Navigation.WOQODE,
                        hashMapOf(FROM_HOME to true)
                    )
                }else navigateToAboutWoqode()
            }

            it.error?.let {
                navigateToAboutWoqode()
            }
        }

        observeOnLoginMfpResponse()
        observeOnProfilePhoto()
        observeAccountActivation()

    }

    private fun navigateToAboutWoqode() {
        sharedPreferences.isFromWoqode = false
        viewModel.navigate(Navigation.ABOUT_WOQODE, null)
    }

    private fun resetPinCodeFields() = binding.pinCodeComponent.resetValues()

    private fun handleCheckOtpResult(isValid: Boolean) {
        if (isValid) {
            proceed()
        } else {
            binding.pinCodeComponent.showError(getString(com.woqod.app.R.string.wrong_pincode))
            resetPinCodeFields()
        }
    }

    /**
     * Proceed to next step after OTP success
     */
    private fun proceed() {
        params?.let {
            when (it[OTP_SOURCE]) {
                OTP_FOR_LOGIN -> {
                    loginWithMfp()
                }
                OTP_FOR_BIOMETRIC, OTP_FOR_LOGIN_BIOMETRIC -> {
                    viewModel.updateBiometricStatus(
                        hashMapOf(
                            USERNAME to sharedPreferences.customPasswordForBiometric,
                            DEVICE_ID to sharedPreferences.deviceId
                        )
                    )
                    /*      togglePopUp(getString(com.woqod.app.R.string.BiometricActivated), {
                              viewModel.navigate(Navigation.SETTINGS, null)
                          }, popUpType = PopUpType.POPUP_SUCCESS)*/
                }
                OTP_FOR_FORGET_PWD -> {
                    viewModel.navigate(
                        Navigation.FORGET_PWD,
                        hashMapOf(
                            FRAGMENT_SOURCE to OTP_FOR_FORGET_PWD,
                            USERNAME to LoginWorkFlow.username,
                            TYPE to LoginWorkFlow.connectionType
                        )
                    )
                }
                OTP_FOR_RESET -> {
                    viewModel.navigate(
                        Navigation.FORGET_PWD,
                        hashMapOf(FRAGMENT_SOURCE to OTP_FOR_RESET)
                    )
                }
            }
        }
    }

    private fun loginWithMfp() {
        hideKeyboard()
        toggleLoading(true)
        UserChallengeHandler.getInstance().login(getLoginCredentials())
            .observe(this, (::manageLoginResult))
    }

    private fun getLoginCredentials(): JSONObject {
        val credentials = JSONObject()
        with(LoginWorkFlow) {
            credentials.put(USERNAME, username)
            credentials.put(PASSWORD, temporaryCachedCode)
            credentials.put(TYPE, connectionType)
            credentials.put(REMEMBER_ME, isRememberMe)
        }
        credentials.put(DEVICE_TYPE, DEVICE_TYPE_VALUE)
        credentials.put(DEVICE_ID, sharedPreferences.deviceId)
        credentials.put(IPADDRESS, getIpAddress())
        return credentials
    }

    private fun observeOnLoginMfpResponse() {
        UserChallengeHandler.isChallenged.observe(this) {
            toggleLoading(false)
        }
        UserChallengeHandler.errorStatusCode.observe(this, EventObserver { error, _ ->
            toggleLoading(false)
            handleLoginError(error)
        })
    }

    private fun handleLoginError(message: String) {
        if (message == ACCOUNT_BLOCKED) {
            if (sharedPreferences.blockedAccountTime == 0L) {
                sharedPreferences.blockedAccountTime = Date().time
                showCounterPopup()
            }
        } else togglePopUp(message, {
            viewModel.navigate(Navigation.LOGIN, null)
        })
    }

    private fun manageLoginResult(isLoginSuccessful: Boolean) {
        if (isLoginSuccessful) {
            if (!sharedPreferences.isBiometricActivated
                && biometricsExistOnDevice(activity)
                && !sharedPreferences.isBiometricPopUpShown
            ) {
                showBiometricCustomPopUp()
            } else {
                getProfilePhotoAndRedirect()
            }
        } else {
            toggleLoading(false)
            togglePopUp(getString(R.string.AuthenticationLoginLoginFail), {
                viewModel.navigate(Navigation.LOGIN, null)
            })
        }
    }


    private fun getProfilePhotoAndRedirect() {
        sharedPreferences.user?.let {
            viewModel.getProfilePhoto(hashMapOf(USERNAME to it.userName))
        } ?: run {
            Timber.d("User was not yet saved inside sharedPref")
        }
    }

    private fun observeOnProfilePhoto() {
        viewModel.onGetProfilePhoto.observe(this) {
            it.result?.let { photo ->
                sharedPreferences.userPhoto = photo
                redirect()
            } ?: run { redirect() }
            it.error?.let {
                redirect()
            }
        }
    }

    private fun showBiometricCustomPopUp() {
        sharedPreferences.isBiometricPopUpShown = true
        togglePopUpChoice(
            getString(R.string.AuthenticationSetupFingerprint),
            getString(R.string.AuthenticationSetupFingerprintMessage),
            popUpIcon = R.drawable.ic_popup_biometric,
            firstOption = {
                getProfilePhotoAndRedirect()
            }, secondOption = {
                showBiometricNativeDialog()
            }
        )
    }

    private fun showBiometricNativeDialog() {
        val biometricPrompt = BiometricPromptUtils.createBiometricPrompt(activity,
            processSuccess =
            {
                sharedPreferences.customPasswordForBiometric =
                    sharedPreferences.user?.customIdentification ?: ""
                sharedPreferences.isBiometricActivated = true
                viewModel.navigate(
                    Navigation.BIOMETRIC,
                    BiometricNavEntity(
                        BIOMETRIC_SOURCE_SETUP,
                        isSuccess = true,
                        isFromSettings = false
                    )
                )
            },
            processFailure = {
                sharedPreferences.isBiometricActivated = false
                viewModel.navigate(
                    Navigation.BIOMETRIC,
                    BiometricNavEntity(
                        BIOMETRIC_SOURCE_SETUP,
                        isSuccess = false,
                        isFromSettings = false
                    )
                )
            }
        )
        val promptInfo = BiometricPromptUtils.createPromptInfo(activity)
        biometricPrompt.authenticate(promptInfo)

    }

    /**
     * Show Blocked account popup
     */
    private fun showCounterPopup() {
        togglePopUp(getString(R.string.LoginAccountBlocked, ACCOUNT_BLOCKED_TIMER.asMinAndSec()), {
            viewModel.navigate(Navigation.LOGIN, null)
        })
        startCountDownTimer(ACCOUNT_BLOCKED_TIMER)
    }

    private fun observeAccountActivation() {
        viewModel.resultAccountActivation.observe(this) {
            it.result?.let { result ->
                if (result) {
                    clearRegistrationCache()
                    togglePopUp(
                        getString(R.string.AuthenticationActivationRegistrationWithSuccess),
                        {
                            sharedPreferences.isBiometricActivated = false
                            viewModel.navigate(Navigation.LOGIN, null)
                        },
                        popUpType = PopUpType.POPUP_SUCCESS
                    )
                } else {
                    togglePopUp(getString(R.string.CommonErrorUnexpectedMessage))
                }
            }
            it.error?.let { error ->
                togglePopUp(error)
                resetPinCodeFields()
            }
        }

        viewModel.resultResendActivationCode.observe(this) {
            it.result?.let { result ->
                if (result) {
                    resetPinCodeFields()
                } else {
                    togglePopUp(getString(R.string.CommonErrorUnexpectedMessage))
                }
            }
            it.error?.let { error ->
                togglePopUp(error)
                resetPinCodeFields()
            }
        }
    }

    private fun redirect() {
        registerDevice(activity)
        if (!LoginWorkFlow.isRedirect) {
            viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_OTP))
        } else if (LoginWorkFlow.isFahes) {
            viewModel.navigate(Navigation.FAHES, null)
        } else {
            sharedPreferences.user?.let {
                hashMapOf<String, Any>(
                    QID to it.qid,
                    MOBILE to it.mobileNumber
                ).also { query -> viewModel.getBalanceInquiry(query) }
            }
        }
        LoginWorkFlow.clearLoginCache()
    }

}