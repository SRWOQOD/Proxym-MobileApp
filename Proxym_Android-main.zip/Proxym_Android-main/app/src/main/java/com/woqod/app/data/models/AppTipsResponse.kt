package com.woqod.app.data.models

import com.woqod.app.domain.models.AppTipsModel
import com.woqod.shared.commundata.DomainMapper


/**
 *{
"orderItem": "4",
"active": true,
" fileUrl": "https://ftp.proxym-group.net/woqod/20210625121601599.PNG",
"id": 34674,
"creationDate": 1624612562449
}
 */
data class AppTipsResponse(
    val orderItem: Int?,
    val fileUrl: String?,
    val id: Long?
) : DomainMapper<AppTipsModel> {
    override fun mapToDomainModel() = AppTipsModel(
        orderItem = orderItem ?: 0,
        fileUrl = fileUrl,
        id = id ?: 0L
    )

}
