package com.woqod.app.presentation.home


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.*
import com.woqod.app.domain.usecases.*

import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import com.woqod.shared.commundomain.sharedusecases.GetBalanceInquiryUseCase
import com.woqod.shared.commundomain.sharedusecases.GetBookingStatusUseCase
import com.woqod.shared.utils.NotificationsStatusPin
import com.woqod.woqode.domain.models.AccountInquiryModel
import kotlinx.coroutines.launch
import javax.inject.Inject

class HomeViewModel @Inject constructor(
    private val getHomeTopBannerUseCase: GetHomeTopBannerUseCase,
    private val getFuelPricesUseCase: GetFuelPricesUseCase,
    private val getHomeAdsUseCase: GetHomeAdsUseCase,
    private val getHomeBusinessUseCase: GetHomeBusinessUseCase,
    private val getBalanceInquiryUseCase: GetBalanceInquiryUseCase,
    private val getHasNotif: GetHasNotif,
    private val getBookingStatusUseCase: GetBookingStatusUseCase,
    private val updateWoqodeUserUseCase: UpdateWoqodeUserUseCase,

    ) : BaseViewModel() {

    private val _resultHomeTopBanner = SingleLiveEvent<ResultUseCase<List<HomeTopBannerModel>?, String?>>()
    val resultHomeTopBanner: LiveData<ResultUseCase<List<HomeTopBannerModel>?, String?>> = _resultHomeTopBanner

    private val _resultFuelPrices = SingleLiveEvent<ResultUseCase<List<FuelPriceModel>?, String?>>()
    val resultFuelPrices: LiveData<ResultUseCase<List<FuelPriceModel>?, String?>> = _resultFuelPrices

    private val _resultHomeAds = SingleLiveEvent<ResultUseCase<List<HomeAdsModel>?, String?>>()
    val resultHomeAds: LiveData<ResultUseCase<List<HomeAdsModel>?, String?>> = _resultHomeAds

    private val _resultHomeBusiness = SingleLiveEvent<ResultUseCase<List<HomeBusinessSectionModel>?, String?>>()
    val resultHomeBusiness: LiveData<ResultUseCase<List<HomeBusinessSectionModel>?, String?>> = _resultHomeBusiness

    private val _resulBookingStatus = SingleLiveEvent<ResultUseCase<Pair<Boolean?,HomeBannerAppRedirection?>?, String?>>()
    val resulBookingStatus: LiveData<ResultUseCase<Pair<Boolean?,HomeBannerAppRedirection?>?, String?>> = _resulBookingStatus

    private val _resultBalanceInquiry = SingleLiveEvent<ResultUseCase<Pair<AccountInquiryModel?,Boolean>?, String?>>()
    val resultBalanceInquiry: LiveData<ResultUseCase<Pair<AccountInquiryModel?,Boolean>?, String?>> = _resultBalanceInquiry

    fun getHomeTopBannerList() {
        viewModelScope.launch {
            _resultHomeTopBanner.postValue(executeUseCase(getHomeTopBannerUseCase, showLoading = false))
        }
    }
    fun getHasNotif(request : HashMap<String , Any >) {
        viewModelScope.launch {
            NotificationsStatusPin.getInstance().notificationStatusPin.postValue(executeUseCase(getHasNotif,request, showLoading = false))
        }
    }

    fun getFuelPrices() {
        viewModelScope.launch {
            _resultFuelPrices.postValue(executeUseCase(getFuelPricesUseCase,showLoading = false))
        }
    }

    fun getHomeAdsList() {
        viewModelScope.launch {
            _resultHomeAds.postValue(executeUseCase(getHomeAdsUseCase,showLoading = false))
        }
    }

    fun getHomeBusinessSectionList() {
        viewModelScope.launch {
            _resultHomeBusiness.postValue(executeUseCase(getHomeBusinessUseCase,showLoading = false))
        }

    }

    fun getBookingStatus( source : HomeBannerAppRedirection) {
        viewModelScope.launch {
            getBookingStatusUseCase()
                .onSuccess {
                    _resulBookingStatus.postValue(ResultUseCase(Pair(it.body.result,source), null))
                }
                .onError {
                    _resulBookingStatus.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun getBalanceInquiry(query: HashMap<String, Any> , goToTopUp : Boolean = false) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getBalanceInquiryUseCase(query)
                .onSuccess {
                    showLoadingToggle(false)
                    _resultBalanceInquiry.postValue(ResultUseCase(Pair(it ,goToTopUp),null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultBalanceInquiry.postValue(ResultUseCase(null,it.getError()))
                }

        }
    }

    fun updateWoqodeUser(query: HashMap<String, Any>) {
        viewModelScope.launch {
            updateWoqodeUserUseCase(query)
        }
    }

}