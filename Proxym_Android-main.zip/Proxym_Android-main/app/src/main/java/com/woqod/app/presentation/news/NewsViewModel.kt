package com.woqod.app.presentation.news

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.NewsModel
import com.woqod.app.domain.usecases.GetNewsListUseCase
import com.woqod.app.domain.usecases.GetNewsViews
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import kotlinx.coroutines.launch
import javax.inject.Inject

class NewsViewModel @Inject constructor(
    private val getNewsListUseCase: GetNewsListUseCase,
    private val getNewsViews: GetNewsViews
) : BaseViewModel() {

    private val _resultNewsList =
        SingleLiveEvent<ResultUseCase<SharedBody<List<NewsModel>>?, String?>>()
    val resultNewsList: LiveData<ResultUseCase<SharedBody<List<NewsModel>>?, String?>> =
        _resultNewsList
    private val _resultGetNewsViews = MutableLiveData<ResultUseCase<Boolean?, String?>>()
    val resultGetNewsViews: LiveData<ResultUseCase<Boolean?, String?>> = _resultGetNewsViews

    fun getNewsList(request: HashMap<String, Any>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getNewsListUseCase(request)
                .onSuccess {
                    showLoadingToggle(false)
                    _resultNewsList.postValue(ResultUseCase(it.body, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultNewsList.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun incrementNewsViews(id: Long) {
        viewModelScope.launch {
            _resultGetNewsViews.postValue(executeUseCase(getNewsViews, id))
        }
    }
}