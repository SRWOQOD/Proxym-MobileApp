package com.woqod.app.presentation.tenders

import android.os.Bundle
import android.widget.TextView
import com.woqod.app.databinding.FragmentTendersDetailsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.TendersModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.TENDER_DETAILS
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commun.extensions.textInHtmlFormatted
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class TendersDetailsFragment : BaseViewModelFragment<TendersViewModel, FragmentTendersDetailsBinding>(
    FragmentTendersDetailsBinding::inflate) {

    private val  symbols =  DecimalFormatSymbols(Locale.ENGLISH)

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: TendersViewModel by injectViewModel()

    private var tenderModel: TendersModel? = null


    fun newInstance(model: TendersModel): TendersDetailsFragment {
        val args = Bundle()
        args.putSerializable(TENDER_DETAILS, model)
        val fragment = TendersDetailsFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            tenderModel = it.getSerializable(TENDER_DETAILS) as TendersModel
        }
        initClickListener()
        bindView()
    }


    private fun bindView() {

        tenderModel?.apply {

            showTenderProperty(binding.tvSrNumberTitle,binding.tvSrNumberValue, srNo ?: "-")

            showTenderProperty(binding.tvTenderNumberTitle,binding.tvTenderNumberValue,tenderNumber ?: "-")

            showTenderProperty(binding.tvDescriptionTitle,binding.tvDescriptionValue,description ?: "-")

            showTenderProperty(binding.tvLastCollectionTitle,binding.tvLastCollectionValue,getFormattedCollectionDate() ?: "-")

            showTenderProperty(binding.tvClosingDateTitle,binding.tvClosingDateValue,getFormattedClosingDate() ?: "-")

            showTenderProperty(binding.tvBondTitle,binding.tvBondValue,decimalFormat(bond))

            showTenderProperty(binding.tvFeeTitle,binding.tvFeeValue,decimalFormat(fee))

            showTenderProperty(binding.tvCategoryTitle,binding.tvCategoryValue,category ?: "-")

            details?.let {
                binding.tvDetailsValue.textInHtmlFormatted(it,activity)
            }
        }
    }

    private fun decimalFormat(value :String ?) : String {
        return if(!value.isNullOrEmpty()) {
            DecimalFormat("#,###,###",symbols).format(value.toDouble())
        }else "-"
    }

    /*
    private fun bindView() {
        tenderModel?.apply {
            srNo?.let {
                showTenderProperty(binding.tvSrNumberTitle,binding.tvSrNumberValue,it)
            }
            tenderNumber?.let {
                showTenderProperty(binding.tvTenderNumberTitle,binding.tvTenderNumberValue,it)
            }
            description?.let {
                showTenderProperty(binding.tvDescriptionTitle,binding.tvDescriptionValue,it)
            }
            getFormattedCollectionDate()?.let {
                showTenderProperty(binding.tvLastCollectionTitle,binding.tvLastCollectionValue,it)
            }
            getFormattedClosingDate()?.let {
                showTenderProperty(binding.tvClosingDateTitle,binding.tvClosingDateValue,it)
            }
            bond?.let {
                showTenderProperty(binding.tvBondTitle,binding.tvBondValue,it)
            }
            fee?.let {
                showTenderProperty(binding.tvFeeTitle,binding.tvFeeValue,it)
            }
            category?.let {
                showTenderProperty(binding.tvCategoryTitle,binding.tvCategoryValue,it)
            }
            details?.let {
                binding.tvDetailsValue.textInHtmlFormatted(it,activity)
            }
        }
    }
     */

    private fun  showTenderProperty(tvTitle: TextView, tvValue: TextView, value: String) {
        tvValue.text = value
        tvTitle.show()
        tvValue.show()
    }

    private fun initClickListener() {
        binding.toolbarTenderDetails.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }
    }


}