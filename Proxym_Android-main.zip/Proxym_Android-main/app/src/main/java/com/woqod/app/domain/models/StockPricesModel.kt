package com.woqod.app.domain.models

import java.util.*

data class StockPricesModel(
    val id : Long,
    val date : Long= Calendar.getInstance().time.time,
    val dateString : String?=null,
    val symbol : String,
    val change : String,
    val lastPrice : String,
    val open : String,
    val high : String,
    val low : String,
    val volume : String,
    val previousClose : String,
    val changePercent : String
)
