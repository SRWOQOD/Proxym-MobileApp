package com.woqod.app.presentation.biometric

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.usecases.GetProfilePhotoUseCase
import com.woqod.app.domain.usecases.UpdateBiometricStatusUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class BiometricViewModel @Inject constructor(
    private val updateBiometricStatusUseCase: UpdateBiometricStatusUseCase,
    private val getProfilePhotoUseCase: GetProfilePhotoUseCase
) : BaseViewModel() {

    private val _onGetProfilePhoto = SingleLiveEvent<ResultUseCase<String?, String?>>()
    val onGetProfilePhoto: LiveData<ResultUseCase<String?, String?>> = _onGetProfilePhoto

    fun getProfilePhoto(request: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetProfilePhoto.postValue(executeUseCase(getProfilePhotoUseCase, request))
        }
    }

}