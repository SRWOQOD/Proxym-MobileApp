package com.woqod.app.presentation.tenders

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.lifecycleScope
import com.woqod.app.R
import com.woqod.app.databinding.FragmentTendersBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.TendersModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.utils.FROM_HOME
import com.woqod.shared.widget.EditableComponent
import kotlinx.android.synthetic.main.fragment_tenders.*
import kotlinx.coroutines.launch
import java.util.*




class TendersFragment : BaseViewModelFragment<TendersViewModel, FragmentTendersBinding>(FragmentTendersBinding::inflate),
    TendersItemClickListener, View.OnClickListener {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: TendersViewModel by injectViewModel()
    var tendersList = mutableListOf<TendersModel>()
    private val tendersAdapter: TendersAdapter by lazy {
        TendersAdapter(tendersList, this)
    }

    var startDate: Date? = null
    var endDate: Date? = null
    var minBond = ""
    var maxBond = ""
    var isFiltered = false
    var isFromHome = false

    fun newInstance(params: HashMap<String, Boolean>) = TendersFragment().apply {
        arguments = Bundle().apply {
            putSerializable(FROM_HOME, params)
        }
        arguments?.let {
            isFromHome = (it.getSerializable(FROM_HOME) as HashMap<String, Boolean>)[FROM_HOME] == true
        }
    }


    override fun initViews() {
        appComponent.inject(this)
        if (isFromHome) {
            viewModel.resetPagingProperties()
            viewModel.isFetchedOnce = false
        }
        setClickListeners()
        disableDefaultBackPress(true)
        initRecyclerView()
        setFilterViewConstraints()
        hasSwipeToRefreshListener()
        if (viewModel.currentPage == 0) {
            getTendersList()
        }
        handleBackPressEvent()
        isFromHome = false
    }

    private fun handleBackPressEvent() {
        if (startDate != null || endDate != null || minBond != "" || maxBond != "") {
            handleFilterAction()
        }
    }

    private fun setFilterViewConstraints() {
        binding.tvFilterCollectionDatesStart.toggleEditableTitle(false)
        binding.tvFilterCollectionDatesEnd.toggleEditableTitle(false)
        binding.tvFilterBondFrom.toggleEditableTitle(false)
        binding.tvFilterBondTo.toggleEditableTitle(false)
    }

    private fun setClickListeners() {
        binding.tvFilterCollectionDatesStart.setEditableClickListener { showDatePicker(binding.tvFilterCollectionDatesStart) }
        binding.tvFilterCollectionDatesEnd.setEditableClickListener { showDatePicker(binding.tvFilterCollectionDatesEnd) }
        binding.btnFilterRefine.setOnClickListener(this)
        binding.btnFilterClear.setOnClickListener(this)
        binding.toolbarTenders.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

    private fun hasSwipeToRefreshListener() {
        binding.swipeRefreshTenders.setOnRefreshListener {
            tendersList.clear()
            resetBondValues()
            resetDateValues()
            tendersAdapter.resetList()
            viewModel.resetPagingProperties()
            getTendersList()
            binding.swipeRefreshTenders.isRefreshing = false
        }
    }

    override fun initObservers() {
        viewModel.resultGetTenders.observe(viewLifecycleOwner) {
            viewModel.isFetchedOnce = true
            it.result?.let { result ->
                handleTenderSuccess(result.result)
            }
            it.error?.let { error ->
                binding.tvNoTenders.show()
                binding.rvTenders.hide()
                togglePopUp(error) }
        }
        if (viewModel.resultGetTenders.value?.result?.result?.isEmpty() == true && viewModel.isFetchedOnce) {
            binding.tenderFilterGroup.hide()
            binding.tvNoTenders.text = getString(R.string.TendersFilterNoTendersFound)
            binding.tvNoTenders.show()
        } else if (viewModel.resultGetTenders.value?.result?.result?.isEmpty() == false && viewModel.isFetchedOnce)  {
            binding.tenderFilterGroup.show()
            binding.tvNoTenders.text = getString(R.string.TendersNoTendersFound)
            binding.tvNoTenders.hide()
        }
    }

    private fun handleTenderSuccess(tenders : List<TendersModel>) {
        if(tenders.isEmpty()){
            binding.tenderFilterGroup.hide()
            binding.tvNoTenders.text = getString(R.string.TendersFilterNoTendersFound)
            binding.tvNoTenders.show()

        }else{
            binding.tenderFilterGroup.show()
            binding.tvNoTenders.text = getString(R.string.TendersNoTendersFound)
            binding.tvNoTenders.hide()
            tenders.forEach { tender ->
                tendersList.add(tender)
            }
            handleFilterAction()
        }
    }

    private fun handleFilterAction() {
        lifecycleScope.launch {
            updateList(
                viewModel.filterByBond(
                    minBond,
                    maxBond,
                    viewModel.filterByDate(startDate, endDate, tendersList,isFiltered),
                    isFiltered
                )
            )
        }
    }

    fun updateList(list: List<TendersModel>) {
        if (list.isNotEmpty()) {
            binding.tvNoTenders.hide()
            binding.rvTenders.show()
            tendersAdapter.updateList(list)
        } else {
            binding.tvNoTenders.show()
            binding.rvTenders.hide()
        }
    }


    private fun initRecyclerView() {

        hasScrolledToBottomListener()

        binding.rvTenders.apply {
            adapter = tendersAdapter
        }
    }

    private fun hasScrolledToBottomListener() {
        binding.rootTenders.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, oldScrollY ->
            val recycler = binding.rvTenders
            if (scrollY > (recycler.measuredHeight - v.measuredHeight)
                && scrollY > oldScrollY
                && viewModel.toggleLoading.value == false
                && !viewModel.isLastPage ) {
                getTendersList()
            }
        })
    }


    override fun onDetailsItemClicked(item: TendersModel) {
        viewModel.navigate(Navigation.TENDER_DETAILS,item)
    }

    private fun initDatePicker(editText: EditableComponent): DatePickerDialog {
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        return DatePickerDialog(
            activity,
            com.woqod.feedback.R.style.DatePickerTheme,
            { _, selectedYear, selectedMonth, dayOfMonth ->
                val stringDate = getString(
                    com.woqod.feedback.R.string.CommonDateOfBirthForm,
                    dayOfMonth.formatDayAndMonthDate(),
                    (selectedMonth + 1).formatDayAndMonthDate(),
                    selectedYear.toString()
                )
                editText.getEditableView().setText(stringDate)
                if (editText == binding.tvFilterCollectionDatesStart) {
                    startDate = Date(stringDate.toTimeStamp() ?: 0L)
                } else {
                    endDate = Date(stringDate.toTimeStamp(true) ?: 0L)
                }
            },
            year,
            month,
            day
        )
    }

    private fun getTendersList() {
        viewModel.getWoqodTenders(hashMapOf(SIZE to viewModel.sizePerPage, PAGE to viewModel.currentPage))
    }

    private fun showDatePicker(editText: EditableComponent) {
        val calendar = Calendar.getInstance()

        if (editText == binding.tvFilterCollectionDatesStart) {

            with(getDatePickerDialog(editText)) {
                endDate?.let { datePicker.maxDate = it.time }
                startDate?.let {
                    calendar.time = it
                    datePicker.updateDate(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH))
                }
                show()
            }
        } else {
            with(getDatePickerDialog(editText)) {
                startDate?.let { datePicker.minDate = it.time }
                endDate?.let {
                    calendar.time = it
                    datePicker.updateDate(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH))
                }
                show()
            }
        }
    }

    private fun getDatePickerDialog(editText: EditableComponent): DatePickerDialog {
        return initDatePicker(editText)
    }

    override fun onClick(view: View?) {
        when (view) {
            btn_filter_refine -> {
                hideKeyboard()
                if (validateInput()) {
                    isFiltered = true
                    handleFilterAction()
                }
            }
            btn_filter_clear -> {
                resetBondValues()
                resetDateValues()
                isFiltered = false
                updateList(tendersList)
            }
        }
    }

    private fun validateInput(): Boolean {
        var valide = true
        maxBond = binding.tvFilterBondTo.getEditableView().text.toString()
        minBond = binding.tvFilterBondFrom.getEditableView().text.toString()
        if ( maxBond.isNotEmpty() && minBond.isNotEmpty() && maxBond.toInt() < minBond.toInt() ) {
            togglePopUp(getString(R.string.TendersVerifyBond))
            valide = false
        }
        return valide
    }

    private fun resetDateValues() {
        binding.tvFilterCollectionDatesStart.getEditableView().text = null
        binding.tvFilterCollectionDatesEnd.getEditableView().text = null
        startDate = null
        endDate = null
    }

    private fun resetBondValues() {
        binding.tvFilterBondTo.getEditableView().text = null
        binding.tvFilterBondFrom.getEditableView().text = null
        maxBond = ""
        minBond = ""
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)
    }
}
