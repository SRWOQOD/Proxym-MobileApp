package com.woqod.app.presentation.utils

import com.woqod.account.presentation.personalinformation.UserProfileFragment
import com.woqod.account.presentation.personalinformation.UserProfileOtpFragment
import com.woqod.app.presentation.biometric.BiometricFragment
import com.woqod.app.presentation.locations.map_filter.MapFilterFragment
import com.woqod.app.presentation.news.NewsFragmentDetails
import com.woqod.app.presentation.notifications.survey.NotificationSurveyFragment
import com.woqod.app.presentation.otp.OtpFragment
import com.woqod.app.presentation.promotions.PromotionsFragmentDetails
import com.woqod.app.presentation.tenders.TendersDetailsFragment
import com.woqod.authentication.presentation.forget_password.ForgetPasswordFragment
import com.woqod.fahes.presentation.about.AboutFahesFragment
import com.woqod.fahes.presentation.booking.*
import com.woqod.fahes.presentation.inspection_payment.payment.FahesPaymentFragment
import com.woqod.fahes.presentation.inspection_payment.payment.FahesReceiptFragment
import com.woqod.fahes.presentation.inspection_payment.pre_registration.*
import com.woqod.fahes.presentation.inspection_report.details.InspectionDetailsFragment
import com.woqod.fahes.presentation.inspection_report.list_cars.FahesInspectionReportFragment
import com.woqod.fahes.presentation.inspection_tips.InspectionTipsFragment
import com.woqod.fahes.presentation.list_receipts.ListReceiptsFragment
import com.woqod.fahes.presentation.menu.FahesMenuFragment
import com.woqod.feedback.presentation.details_feedback.DetailsFeedbackFragment
import com.woqod.feedback.presentation.form_feedback.FeedbackFormFragment
import com.woqod.feedback.presentation.list_feedback.ListFeedbackFragment
import com.woqod.shafaf.presentation.about.AboutShafafFragment
import com.woqod.shafaf.presentation.retailers.ShafafRetailersFragment
import com.woqod.woqode.presentation.about.AboutWoqodeFragment
import com.woqod.woqode.presentation.receipt.WoqodeReceiptFragment
import com.woqod.woqode.presentation.topup.WoqodeTermsOfUseFragment
import com.woqod.woqode.presentation.topup.WoqodeTopupFragment
import com.woqod.woqode.presentation.topup.WoqodeTopupGuestFragment
import com.woqod.woqode.presentation.transaction_history.TransactionHistoryFragment

val noBottomBarFragmentList: List<String> =
    listOf(
        OtpFragment::class.java.name,
        BiometricFragment::class.java.name,
        ForgetPasswordFragment::class.java.name,
        FahesPreRegisterConfirmFragment::class.java.name,
        FahesPaymentFragment::class.java.name,
        FahesReceiptFragment::class.java.name,
        FahesBookingOtpFragment::class.java.name,
        FahesBookingCarInfoFragment::class.java.name,
        FahesBookingDateFragment::class.java.name,
        UserProfileOtpFragment::class.java.name,
        UserProfileFragment::class.java.name,
        FahesCancelModifyBooking::class.java.name,
        FahesCancelModifyBookingList::class.java.name,
        FahesCancelModifyGuest::class.java.name,
        CarRegistrationConfirmationFragment::class.java.name,
        FahesGuestPreRegisterFragment::class.java.name,
        FahesPreRegistrationOtpFragment::class.java.name,
        UserVehicleListFragment::class.java.name,
        FahesInspectionReportFragment::class.java.name,
        InspectionDetailsFragment::class.java.name,
        ListReceiptsFragment::class.java.name,
        NewsFragmentDetails::class.java.name,
        MapFilterFragment::class.java.name,
        ShafafRetailersFragment::class.java.name,
        AboutShafafFragment::class.java.name,
        PromotionsFragmentDetails::class.java.name,
        WoqodeTopupFragment::class.java.name,
        WoqodeReceiptFragment::class.java.name,
        WoqodeTopupGuestFragment::class.java.name,
        TransactionHistoryFragment::class.java.name,
        NotificationSurveyFragment::class.java.name,
        DetailsFeedbackFragment::class.java.name,
        FeedbackFormFragment::class.java.name,
        ListFeedbackFragment::class.java.name,
        AboutWoqodeFragment::class.java.name,
        WoqodeTermsOfUseFragment::class.java.name,
        InspectionTipsFragment::class.java.name,
        AboutFahesFragment::class.java.name,
        TendersDetailsFragment::class.java.name

    )

val FahesFragmentList: List<String> =
    listOf(
        FahesMenuFragment::class.java.name,
        UserVehicleListFragment::class.java.name,
        FahesGuestPreRegisterFragment::class.java.name,
        FahesPaymentFragment::class.java.name,
        FahesPreRegisterConfirmFragment::class.java.name,
        FahesBookingCarInfoFragment::class.java.name,
        FahesReceiptFragment::class.java.name,
        FahesInspectionReportFragment::class.java.name,
        InspectionDetailsFragment::class.java.name,
        ListReceiptsFragment::class.java.name,
        FahesBookingOtpFragment::class.java.name,
        FahesBookingDateFragment::class.java.name,
        FahesCancelModifyBooking::class.java.name,
        FahesCancelModifyBookingList::class.java.name,
        CarRegistrationConfirmationFragment::class.java.name,
        FahesPreRegistrationOtpFragment::class.java.name,
        AboutFahesFragment::class.java.name,
        InspectionTipsFragment::class.java.name,
        FahesCancelModifyGuest::class.java.name,
        AboutFahesFragment::class.java.name
    )