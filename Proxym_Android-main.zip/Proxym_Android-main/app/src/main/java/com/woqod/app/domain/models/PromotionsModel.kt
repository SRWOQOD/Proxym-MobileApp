package com.woqod.app.domain.models

import java.io.Serializable

data class PromotionsModel(
    val id: Long,
    val title: String,
    val titleArabic: String,
    val briefDescription: String,
    val briefDescriptionArabic: String,
    val image: String?,
    val imageList: String?,
    val link: String,
    val category: String,
    val startDate: Long,
    val endDate: Long,
    val lastSynchronisationDate: Long,
    val promotionsId: Long
) : Serializable