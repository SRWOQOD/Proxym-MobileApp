package com.woqod.app.presentation.notifications


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.usecases.*
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.models.NotificationsModel
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import kotlinx.coroutines.launch
import javax.inject.Inject

class NotificationsViewModel @Inject constructor(
    private val getListNotificationsUseCase: GetListNotificationsUseCase,
    private val postSurveyResponseUseCase: PostSurveyResponseUseCase,
    private val updateAllNotificationsUseCase: UpdateAllNotificationsUseCase,
    private val updateNotificationUseCase: UpdateNotificationUseCase,
    private val getAnonymousListNotificationsUseCase: GetAnonymousListNotificationsUseCase,

    ) : BaseViewModel() {

    private val _onGetNotifications = SingleLiveEvent<ResultUseCase<SharedBody<List<NotificationsModel>>?, String?>>()
    val onGetNotifications: LiveData<ResultUseCase<SharedBody<List<NotificationsModel>>?, String?>> get() = _onGetNotifications


    fun getListNotifications(request: HashMap<String, Any>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getListNotificationsUseCase(request)
                .onSuccess {
                    showLoadingToggle(false)
                    _onGetNotifications.postValue(ResultUseCase(it.body, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onGetNotifications.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    private val _onGetAnonymousNotifications =
        SingleLiveEvent<ResultUseCase<SharedBody<List<NotificationsModel>>?, String?>>()
    val onGetAnonymousNotifications: LiveData<ResultUseCase<SharedBody<List<NotificationsModel>>?, String?>> get() = _onGetAnonymousNotifications

    fun getAnonymousListNotifications(request: HashMap<String, Any>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getAnonymousListNotificationsUseCase(request)
                .onSuccess {
                    showLoadingToggle(false)
                    _onGetAnonymousNotifications.postValue(ResultUseCase(it.body, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _onGetAnonymousNotifications.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    private val _onGetSurveyResponse = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onGetSurveyResponse: LiveData<ResultUseCase<Boolean?, String?>> get() = _onGetSurveyResponse

    fun postSurveyResponse(request: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetSurveyResponse.postValue(executeUseCase(postSurveyResponseUseCase, request))
        }
    }

    private val _onGetUpdateNotificationResponse = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onGetUpdateNotificationResponse: LiveData<ResultUseCase<Boolean?, String?>> get() = _onGetUpdateNotificationResponse

    fun updateNotification(request: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetUpdateNotificationResponse.postValue(executeUseCase(updateNotificationUseCase, request))
        }
    }

    private val _onGetUpdateAllNotificationsResponse = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onGetUpdateAllNotificationsResponse: LiveData<ResultUseCase<Boolean?, String?>> get() = _onGetUpdateAllNotificationsResponse

    fun updateAllNotifications(request: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetUpdateAllNotificationsResponse.postValue(executeUseCase(updateAllNotificationsUseCase, request))
        }
    }

}