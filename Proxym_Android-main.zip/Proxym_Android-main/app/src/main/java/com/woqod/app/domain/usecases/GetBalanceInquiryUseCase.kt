package com.woqod.app.domain.usecases

import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.woqode.domain.models.AccountInquiryModel
import javax.inject.Inject


open class GetBalanceInquiryUseCase @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCaseWithRequest<HashMap<String, Any>, WoqodResult<AccountInquiryModel>> {

    override suspend operator fun invoke(request: HashMap<String, Any>) =
        appRepository.getBalanceInquiry(request)
}