package com.woqod.app.presentation.applicationTips

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemAppTipsBinding
import com.woqod.app.domain.models.AppTipsModel
import com.woqod.shared.commun.extensions.load

class AppTipsAdapter(
    private var list: MutableList<AppTipsModel>
) : RecyclerView.Adapter<AppTipsAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemAppTipsBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    fun updateList(list: List<AppTipsModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: ItemAppTipsBinding) : RecyclerView.ViewHolder(view.root) {
        private val ivAppTip: ImageView = view.ivAppTipsItem
        private val shimmer: ShimmerFrameLayout = view.shimmerItemAppTips
        private val tvError: TextView = view.tvAppTipsItemError
        private val ivPlaceHolder: ImageView = view.ivPlaceholder

        fun bind(appTip: AppTipsModel) {

               appTip.fileUrl?.let {imgUrl->
                   shimmer.load(ivAppTip, imgUrl, tvError, ivPlaceHolder)
               }?:run {
                    ivAppTip.load(R.drawable.ic_placeholder) {
                        transformations(com.woqod.shared.commun.RoundedCornersTransformation(33F))
                    }
                }
        }
    }
}