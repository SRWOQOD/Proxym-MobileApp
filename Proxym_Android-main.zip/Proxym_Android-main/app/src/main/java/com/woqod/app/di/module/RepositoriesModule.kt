package com.woqod.app.di.module

import com.woqod.app.data.datasource.AppDataSourceImpl
import com.woqod.app.data.repository.AppRepositoryImpl
import com.woqod.app.di.scope.AppScope
import com.woqod.app.domain.repository.AppRepository
import dagger.Module
import dagger.Provides

@Module
object RepositoriesModule {

    @Provides
    @AppScope
    fun provideAppRepository(): AppRepository {
        val appRemoteDataSource = AppDataSourceImpl()
        return AppRepositoryImpl(appRemoteDataSource)
    }

}