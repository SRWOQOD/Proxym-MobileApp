package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.ItemHomeFuelBannerBinding
import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.models.FuelType
import com.woqod.app.presentation.utils.FUEL_FALLBACK_VALUE
import com.woqod.shared.commun.extensions.loadDrawable
import com.woqod.shared.commundata.context

class HomeFuelBannerAdapter(
    private var list: MutableList<FuelPriceModel>,
    private val action: (MutableList<FuelPriceModel>) -> Unit
) :
    RecyclerView.Adapter<HomeFuelBannerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemHomeFuelBannerBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    fun updateList(list: List<FuelPriceModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val view: ItemHomeFuelBannerBinding) :
        RecyclerView.ViewHolder(view.root) {

        fun bindTo(fuel: FuelPriceModel) {
            view.tvGasType.text = fuel.name()
            view.tvGasPrice.text = if (fuel.price == 0f) FUEL_FALLBACK_VALUE else  context.getString(R.string.FuelPriceFomatPrice,fuel.price)

            val background = when (fuel.fuelType) {
                FuelType.GASOLINE_PREMIUM -> itemView.context.loadDrawable(R.drawable.ic_home_fuel_premium)
                FuelType.GASOLINE_SUPER -> itemView.context.loadDrawable(R.drawable.ic_home_fuel_super)
                FuelType.DIESEL -> itemView.context.loadDrawable(R.drawable.ic_home_fuel_diesel)
            }

            view.root.background = background
        }
    }
}