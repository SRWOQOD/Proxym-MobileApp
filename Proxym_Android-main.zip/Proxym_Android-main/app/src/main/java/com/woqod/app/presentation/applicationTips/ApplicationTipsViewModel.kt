package com.woqod.app.presentation.applicationTips

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.AppTipsModel
import com.woqod.app.domain.usecases.GetAppTipsUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class ApplicationTipsViewModel @Inject constructor(
    private val appTipsUseCase: GetAppTipsUseCase
) : BaseViewModel() {

    private val _resultAppTips = SingleLiveEvent<ResultUseCase<List<AppTipsModel>?, String?>>()
    val resultAppTips: LiveData<ResultUseCase<List<AppTipsModel>?, String?>> = _resultAppTips

    fun getAppTips(device : String) {
        viewModelScope.launch {
            _resultAppTips.postValue(executeUseCase(appTipsUseCase,device))
        }
    }

}