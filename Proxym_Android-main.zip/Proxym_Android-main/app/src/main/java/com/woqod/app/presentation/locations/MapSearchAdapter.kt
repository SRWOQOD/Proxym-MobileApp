package com.woqod.app.presentation.locations

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.ItemSearchSuggestionsBinding
import com.woqod.app.domain.models.MapStationModel

class MapSearchAdapter(
    private var stationsList: MutableList<MapStationModel>,
    private val action: (MapStationModel) -> Unit
) : RecyclerView.Adapter<MapSearchAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemSearchSuggestionsBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(stationsList[position])
    }

    override fun getItemCount() = stationsList.size

    fun updateList(list: List<MapStationModel>) {
        stationsList.clear()
             stationsList.addAll(list.distinctBy { listOf(it.latitude,it.longitude,it.title) })

        notifyDataSetChanged()
    }

    inner class ViewHolder(view: ItemSearchSuggestionsBinding) :
        RecyclerView.ViewHolder(view.root) {
        private var stationName = view.tvSearchSuggestion

        init {
            itemView.setOnClickListener {
                action(stationsList[absoluteAdapterPosition])
            }
        }

        fun bindViewHolder(station: MapStationModel) {
            stationName.text = station.title
        }
    }
}
