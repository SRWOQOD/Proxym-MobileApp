package com.woqod.app.presentation.locations.map_cluster

import android.graphics.drawable.Drawable
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem
import com.woqod.app.domain.models.MapTypeStation
import com.woqod.app.domain.models.PetrolStationStatus

data class MarkerCluster(
    val name: String,
    val type: MapTypeStation,
    val petrolStationStatus: PetrolStationStatus?,
    val fahesStationStatus: PetrolStationStatus?,
    val drawable: Drawable?,
    val latLng: LatLng
) : ClusterItem {
    override fun getPosition() = latLng
    override fun getTitle() = name
    override fun getSnippet(): String? = null
}