package com.woqod.app.presentation.otp

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.usecases.*
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.encode64
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.sharedusecases.GetBalanceInquiryUseCase
import com.woqod.shared.commundomain.sharedusecases.SendPinCodeUseCase
import com.woqod.shared.commundomain.sharedusecases.ValidatePinCodeUseCase
import com.woqod.shared.utils.LanguageUtils
import com.woqod.woqode.domain.models.AccountInquiryModel
import kotlinx.coroutines.launch
import okio.ByteString.Companion.encode
import javax.inject.Inject

class OtpViewModel @Inject constructor(
    private val languageUtils: LanguageUtils,
    private val sendOtpCodeUseCase: SendOtpCodeUseCase,
    private val getOtpCodeUseCase: GetOtpCodeUseCase,
    private val getProfilePhotoUseCase: GetProfilePhotoUseCase,
    private val checkRecoveryCodeUseCase: GetCheckRecoveryCodeUseCase,
    private val getPinCodeUseCase: SendPinCodeUseCase,
    private val checkValidityPinCodeUseCase: ValidatePinCodeUseCase,
    private val getRecoveryCodeUseCase: PostRecoveryCodeUseCase,
    private val postAccountActivationUseCase: PostAccountActivationUseCase,
    private val resendActivationCodeUseCase: ResendActivationCodeUseCase,
    private val updateBiometricStatusUseCase: UpdateBiometricStatusUseCase,
    private val getBalanceInquiryUseCase: GetBalanceInquiryUseCase,

    ) : BaseViewModel() {
    private val _updatedBiometricStatus = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val updatedBiometricStatus: LiveData<ResultUseCase<Boolean?, String?>> = _updatedBiometricStatus

    private val _onReceiveOtpCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onReceiveOtpCode: LiveData<ResultUseCase<Boolean?, String?>> = _onReceiveOtpCode

    private val _onCheckOtpCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckOtpCode: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckOtpCode

    private val _onGetProfilePhoto = SingleLiveEvent<ResultUseCase<String?, String?>>()
    val onGetProfilePhoto: LiveData<ResultUseCase<String?, String?>> = _onGetProfilePhoto

    private val _resultAccountActivation = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultAccountActivation: LiveData<ResultUseCase<Boolean?, String?>> = _resultAccountActivation

    private val _resultResendActivationCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultResendActivationCode: LiveData<ResultUseCase<Boolean?, String?>> = _resultResendActivationCode

    private val _resultBalanceInquiry = SingleLiveEvent<ResultUseCase<AccountInquiryModel?, String?>>()
    val resultBalanceInquiry: LiveData<ResultUseCase<AccountInquiryModel?, String?>> = _resultBalanceInquiry

    fun updateBiometricStatus(query: HashMap<String, String>) {
        viewModelScope.launch {
            _updatedBiometricStatus.postValue(executeUseCase(updateBiometricStatusUseCase, query))
        }
    }


    //FORGET PASSWORD
    private val _onReceiveRecoveryCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onReceiveRecoveryCode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onReceiveRecoveryCode

    private val _onCheckRecoveryCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckRecoveryCode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onCheckRecoveryCode

    //RESET PASSWORD
    private val _onReceiveResetPinCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onReceiveResetPinCode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onReceiveResetPinCode

    private val _onCheckResetPinCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckResetPinCode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onCheckResetPinCode

    fun getOtp(userName: String?, connectionType: String?) {
        viewModelScope.launch {
            val requestArgs = hashMapOf(
                USERNAME to (encryptUsernameQid(userName,connectionType) ?: ""),
                TYPE to (connectionType ?: ""),
                LANGUAGE to languageUtils.getAppLanguage()
            )
            _onReceiveOtpCode.postValue(executeUseCase(getOtpCodeUseCase, requestArgs))
        }
    }

    private fun encryptUsernameQid(userName: String?, type: String?) : String? {
        if (type == "Qid_Auth") {
            return userName?.encode64()
        }
        return userName
    }

    fun sendOtp(userName: String?, connectionType: String?, pinCode: String) {
        viewModelScope.launch {
            val requestArgs = hashMapOf(
                USERNAME to (encryptUsernameQid(userName,connectionType) ?: ""),
                TYPE to (connectionType ?: ""),
                LANGUAGE to languageUtils.getAppLanguage(),
                PINCODE to pinCode
            )
            _onCheckOtpCode.postValue(executeUseCase(sendOtpCodeUseCase, requestArgs))
        }
    }

    fun getProfilePhoto(request: HashMap<String, Any>) {
        viewModelScope.launch {
            _onGetProfilePhoto.postValue(executeUseCase(getProfilePhotoUseCase, request))
        }
    }

    fun activateAccount(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultAccountActivation.postValue(executeUseCase(postAccountActivationUseCase, query))
        }
    }

    fun resendActivationCode(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultResendActivationCode.postValue(executeUseCase(resendActivationCodeUseCase, query))
        }
    }


    fun sendRecoveryCode(params: Pair<String, String>) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(USERNAME to (encryptUsernameQid(params.first,params.second) ?: ""), TYPE to params.second, LANGUAGE to languageUtils.getAppLanguage())
            _onReceiveRecoveryCode.postValue(executeUseCase(getRecoveryCodeUseCase, query))
        }
    }

    fun checkRecoveryCode(params: Pair<String, String>, pinCode: String) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(USERNAME to (encryptUsernameQid(params.first,params.second) ?: ""), TYPE to params.second, PIN_CODE to pinCode)
            _onCheckRecoveryCode.postValue(executeUseCase(checkRecoveryCodeUseCase, query))
        }
    }


    fun getSecurityCode(username: String) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(USERNAME to username, LANGUAGE to languageUtils.getAppLanguage())
            _onReceiveResetPinCode.postValue(executeUseCase(getPinCodeUseCase, query))
        }
    }

    fun checkSecurityCodeValidity(username: String, securityCode: String) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(PIN_CODE to securityCode, USERNAME to username)
            _onCheckResetPinCode.postValue(executeUseCase(checkValidityPinCodeUseCase, query))
        }
    }

    fun getBalanceInquiry(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultBalanceInquiry.postValue(executeUseCase(useCaseWithoutSharedResponse = getBalanceInquiryUseCase, query = query))
        }
    }

}