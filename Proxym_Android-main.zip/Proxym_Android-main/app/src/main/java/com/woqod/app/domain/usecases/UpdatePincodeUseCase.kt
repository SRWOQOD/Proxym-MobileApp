package com.woqod.app.domain.usecases

import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


open class UpdatePincodeUseCase @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCaseWithRequest<HashMap<String, String>, WoqodResult<SharedResponse<Boolean>>> {

    override suspend operator fun invoke(request: HashMap<String, String>) =
        appRepository.updateBiopin(request)
}