package com.woqod.app.presentation.static_screens.contact_Us

import com.woqod.shared.baseui.BaseViewModel
import javax.inject.Inject

class ContactUsViewModel @Inject constructor() : BaseViewModel()
