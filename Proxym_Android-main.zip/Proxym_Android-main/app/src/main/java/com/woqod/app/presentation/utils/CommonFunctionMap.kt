package com.woqod.app.presentation.utils

import android.content.Context
import com.woqod.app.R
import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.models.PetrolStationStatus
import com.woqod.app.presentation.locations.map_filter.MapFilterServiceModel
import com.woqod.shared.utils.ServiceStationType


// we need to pass context to respect instant change language
 fun getStationServicesList(context : Context) = listOf(
    MapFilterServiceModel(0, context.getString(R.string.MapFilterAutoWashService), ServiceStationType.AUTO_WASH),
    MapFilterServiceModel(1, context.getString(R.string.MapFilterManualWashService), ServiceStationType.MANUAL_WASH),
    MapFilterServiceModel(2, context.getString(R.string.MapFilterLubeBayService), ServiceStationType.LUBE),
    MapFilterServiceModel(3, context.getString(R.string.MapFilterVacuumBayService), ServiceStationType.VACCUM),
    MapFilterServiceModel(4, context.getString(R.string.MapFilterTireBayService), ServiceStationType.TIRE),
    MapFilterServiceModel(5, context.getString(R.string.MapFilterCarRepairService), ServiceStationType.REPAIR),
    MapFilterServiceModel(6, context.getString(R.string.MapFilterSidraService), ServiceStationType.SIDRA)
)
fun getServiceNameByType(type :ServiceStationType,context :Context) :String?{
   return getStationServicesList(context).find { it.type== type }?.name
}
fun getIconStatus(station: MapStationModel): String {
   return when (station.petrolStationModel?.status) {
      PetrolStationStatus.Under_Construction -> "http://www.woqod.com/PublishingImages/Mobile%20App%20Icons/woqod-ps-red.png"
      PetrolStationStatus.Active -> "http://www.woqod.com/PublishingImages/Mobile%20App%20Icons/woqod-ps.png"
      PetrolStationStatus.Opening_Soon, PetrolStationStatus.Upcoming -> "http://www.woqod.com/PublishingImages/Mobile%20App%20Icons/woqod-ps-yellow.png"
      else -> "http://www.woqod.com/PublishingImages/Mobile%20App%20Icons/woqod-ps-yellow.png"
   }
}