package com.woqod.app.presentation.menu

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.LayoutItemMenuBinding
import com.woqod.shared.commun.SideMenuModel

class MenuAdapter(
    private var menuItems: List<SideMenuModel>,
    private val itemClickListener: (SideMenuModel) -> Unit
) : RecyclerView.Adapter<MenuAdapter.ViewHolder>() {

    override fun getItemCount(): Int {
        return menuItems.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        LayoutItemMenuBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(menuItems[position])
    }

    inner class ViewHolder(view: LayoutItemMenuBinding) : RecyclerView.ViewHolder(view.root) {
        private val itemImage = view.itemMenuImage
        private val itemName = view.itemMenuName

        init {
            itemView.setOnClickListener {
                itemClickListener(menuItems[absoluteAdapterPosition])
            }
        }

        fun bindViewHolder(menuItems: SideMenuModel) {
            menuItems.apply {
                itemName.text = title
                itemImage.setImageResource(icon)
            }
        }
    }
}