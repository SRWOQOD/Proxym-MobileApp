package com.woqod.app.data.datasource

import com.google.gson.Gson
import com.woqod.app.data.*
import com.woqod.app.data.models.*
import com.woqod.authentication.data.*
import com.woqod.shared.commun.ID
import com.woqod.shared.commundata.*
import com.woqod.shared.commundata.models.*
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.woqode.data.models.AccountInquiry
import com.worklight.wlclient.api.WLResourceRequest

class AppDataSourceImpl : AppDataSource {
    override suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceResponse>>> {
        return when (val result = getRequest(GET_FUEL_PRICES_URL)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = postRequest(PUT_BIO_URL, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }


    override suspend fun getFahesStations(): WoqodResult<SharedResponse<List<FahesStationResponse>>> {
        return when (val result = getRequest(GET_FAHES_STATIONS_URL)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<PetrolStationResponse>>> {
        return when (val result = postRequest(GET_PETROL_STATIONS_URL)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun postRatingStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result =
            postRequest(POST_RATING_STATIONS_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
    }


    override suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<SuperMarketsResponse>>> {
        return when (val result = getRequest(GET_SUPER_MARKETS_URL)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsResponse>>> =
        when (val result = getRequest(GET_PROMOTIONS_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiry> {
        return when (val result = postRequest(GET_BALANCE_INQUIRY_URL, query)) {
            is WoqodResult.Success -> {
                WoqodResult.Success(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsResponse>>> =
        when (val result = getRequest(GET_CONTRACTORS_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(GET_SURVEY_STATUS_URL, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_SURVEY_STATUS_URL, query)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<TendersResponse>>> =
        when (val result = getRequest(GET_WOQOD_TENDERS_URL,request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>> =
        when (val result = postRequest(GET_LIST_NOTIFICATIONS_BY_USERNAME_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_SURVEY_RESPONSE_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result =
            postRequest(PUT_UPDATE_NOTIFICATION_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result =
            postRequest(PUT_UPDATE_ALL_NOTIFICATIONS_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = postRequest(GET_OTP_CODE, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = postRequest(VALIDATE_OTP_CODE, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result =
            postRequest(PUT_UPDATE_BIOMETRIC_STATUS, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>> {
        return when (val result = postRequest(GET_PROFILE_PHOTO_URL, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result =
            postRequest(PUT_RESEND_ACTIVATION_CODE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_ACCOUNT_ACTIVATION, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_RECOVERY_CODE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(GET_RECOVERY_CODE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerResponse>>> =
        when (val result = getRequest(GET_HOME_TOP_BANNER_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getHomeAds(): WoqodResult<SharedResponse<List<HomeAdsResponse>>> =
        when (val result = getRequest(GET_HOME_ADS_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getHomeBusinessSection(): WoqodResult<SharedResponse<List<HomeBusinessSectionResponse>>> =
        when (val result = getRequest(GET_HOME_BUSINESS_URL)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun getAppTips(device: String): WoqodResult<SharedResponse<List<AppTipsResponse>>> =
        when (val result = postRequest(GET_APP_TIPS_URL, hashMapOf(DEVICE to device))) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun getNewsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NewsResponse>>> =
        when (val result = postRequest(GET_NEWS_LIST_URL, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun incrementNewsViews(id: Long): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(GET_NEWS_BY_ID_URL, hashMapOf(ID to id))) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun getStockPrices(): WoqodResult<SharedResponse<List<StockPricesResponse>>> =
        when (val result = getRequest(GET_STOCK_PRICES)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun getStockPricesFromEuroland(): WoqodResult<SharedResponse<StockPricesEurolandResponse>> =
        when (val result = getJsonFromURL()) {
            is WoqodResult.Success -> {
                val sharedResponse = SharedResponse(
                    isSuccessful = true,
                    header = Header(),
                    body = SharedBody<StockPricesEurolandResponse>(
                        Gson().fromJsonToObjectType(result.data.toString())
                    )
                )
                WoqodResult.Success(sharedResponse)
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }


    override suspend fun getHasNotif(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(GET_HAS_NOTIF, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun logout(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_LOGOUT, request)) {
            is WoqodResult.Success -> {
                verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }

    override suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>> =
        when (val result = postRequest(GET_LIST_NOTIFICATIONS_ANONYMOUS, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
}

