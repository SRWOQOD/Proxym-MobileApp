package com.woqod.app.presentation.tenders

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.ItemTendersBinding
import com.woqod.app.domain.models.TendersModel

class TendersAdapter(
    var tendersList: MutableList<TendersModel>,
    private var tendersItemClickListener: TendersItemClickListener
) : RecyclerView.Adapter<TendersAdapter.ViewHolder>() {


    override fun getItemCount(): Int {
        return tendersList.size
    }

    fun updateList(tendersList: List<TendersModel>) {
        this.tendersList = tendersList as MutableList<TendersModel>
        notifyDataSetChanged()
    }

    fun resetList() {
        this.tendersList.clear()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ItemTendersBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(tendersList[position])
    }

    inner class ViewHolder(view: ItemTendersBinding) : RecyclerView.ViewHolder(view.root) {
        val tenderNum = view.tvTenderNumber
        val tenderDescription = view.tvDescription
        init {
            itemView.setOnClickListener {
                tendersItemClickListener.onDetailsItemClicked(tendersList[absoluteAdapterPosition])
            }
        }

        fun bindViewHolder(menuItems: TendersModel) {
            menuItems.apply {
                tenderNum.text = tenderNumber
                tenderDescription.text = description
            }
        }
    }
}