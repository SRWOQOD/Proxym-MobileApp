package com.woqod.app.data.models

import com.woqod.app.domain.models.*
import com.woqod.app.presentation.utils.MARINE_CATEGORY
import com.woqod.app.presentation.utils.MOBILE_PETROL_CATEGORY
import com.woqod.app.presentation.utils.Petrol_CATEGORY
import com.woqod.app.presentation.utils.SIDRA_CATEGORY
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.extensions.convertLocationToDouble
import com.woqod.shared.commundata.DomainMapper
import com.woqod.shared.commundata.models.AreaResponse
import com.woqod.shared.utils.ServiceStationType

/**
 * Created by Hamdi.BOUMAIZA on 07/03/2020
 */

/**
 * {"latitude":"25.25592",
 * "rating":0,
 * "title":"MUAITHER PETROL STATION",
 * "lastSynchronisationDate":1594688402820,
 * "arabicName":"محطة وقود - معيذر",
 * "facilityStations":[],
 * "phone":"40218576",
 * "serviceStations":[{"arabicName":"سدرة","openingHour":"6:00 AM","name":"SIDRA","closingHour":"6:00 AM","id":192569,"state":"UNKNOWN","status":null}],
 * "id":192568,
 * "arabicCategory":"بترول",
 * "category":"PETROL",
 * "stationId":1,
 * "longitude":"51.43037",
 * "status":"Active"}
 */
data class PetrolStationResponse(
    val area: AreaResponse?,
    val rating: Int?,
    val title: String?,
    val lastSynchronisationDate: Long?,
    val arabicName: String?,
    val facilityStations: List<String>?,
    val phone: String?,
    val serviceStations: List<ServiceStationResponse>?,
    val id: Int?,
    val arabicCategory: String?,
    val category: String?,
    val petrolCategory: String?,
    val stationId: Int?,
    val status: String?,
    val longitude: String?,
    val latitude: String?,
    val icon: String?,
    val isVisible: String?
) : DomainMapper<MapStationModel> {
    override fun mapToDomainModel(): MapStationModel {
        val categoryPetrolStation: String?
        val namePetrolStation: String?
        if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
            categoryPetrolStation = arabicCategory
            namePetrolStation = arabicName
        } else {
            categoryPetrolStation = category
            namePetrolStation = title
        }
        return MapStationModel(
            getStationCategory(petrolCategory ?: ""),
            stationId ?: 0,
            namePetrolStation ?: "",
            phone ?: "",
            latitude?.convertLocationToDouble() ?: 0.0,
            longitude?.convertLocationToDouble() ?: 0.0,
            lastSynchronisationDate ?: 0L,
            null,
            PetrolStationModel(
                area?.mapToDomainModel(),
                rating ?: 0,
                facilityStations ?: emptyList(),
                serviceStations?.map { sm ->
                    sm.mapToDomainModel()
                } ?: emptyList(),
                categoryPetrolStation ?: "",
                stationId ?: 0,
                PetrolStationStatus.valueOf(status ?: "Inactive")),
            null,
            icon = icon,
            isVisible = getStationVisibility()
        )
    }

    private fun getStationVisibility() =
        when (isVisible) {
            "Yes" -> true
            "No" -> false
            else -> false
        }


    private fun getStationCategory(category: String): MapTypeStation =
        when (category) {
            Petrol_CATEGORY -> MapTypeStation.PETROL_STATION
            SIDRA_CATEGORY -> MapTypeStation.SIDRA_STATION
            MOBILE_PETROL_CATEGORY -> MapTypeStation.MOBILE_PETROL_STATION
            MARINE_CATEGORY -> MapTypeStation.MARINE_STATION
            else -> MapTypeStation.PETROL_STATION
        }
}


data class ServiceStationResponse(
    val arabicName: String?,
    val name: String?,
    val openingHour: String?,
    val closingHour: String?,
    val state: String?,
    val status: String?,
    val id: Int?

) : DomainMapper<ServiceStationModel> {
    override fun mapToDomainModel(): ServiceStationModel {
        val nameService =
            if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
                arabicName ?: name
            } else {
                name
            }
        return ServiceStationModel(
            nameService ?: "",
            openingHour ?: "12:00 AM",
            closingHour ?: "12:00 AM",
            state ?: "",
            status ?: "",
            ServiceStationType.valueOf(name ?: "MANUAL_WASH"),
            id ?: 0
        )
    }

}
