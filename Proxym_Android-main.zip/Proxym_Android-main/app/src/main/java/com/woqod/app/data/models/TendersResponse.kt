package com.woqod.app.data.models

import com.woqod.app.domain.models.TendersModel
import com.woqod.shared.commundata.DomainMapper

data class TendersResponse(
    val tenderNumber: String?,
    val srNo: String?,
    val fee: String?,
    val description: String?,
    val details: String?,
    val id: Int?,
    val category: String?,
    val closingDate: Long?,
    val collectionDate: Long?,
    val bond: String?,
    val tenderFee: Boolean?
) : DomainMapper<TendersModel> {
    override fun mapToDomainModel() = TendersModel(
        tenderNumber,
        srNo,
        fee,
        description,
        details,
        id,
        category,
        closingDate,
        collectionDate,
        bond,
        tenderFee
    )

}