package com.woqod.app.domain.models

data class AppTipsModel(
    val orderItem: Int,
    val fileUrl: String?,
    val id: Long
) {
    constructor() : this(0,null,0)
}
