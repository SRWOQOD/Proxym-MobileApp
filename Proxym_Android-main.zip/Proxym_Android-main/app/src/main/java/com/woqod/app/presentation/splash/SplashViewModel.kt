package com.woqod.app.presentation.splash

import com.woqod.shared.baseui.BaseViewModel
import javax.inject.Inject

class SplashViewModel @Inject constructor() : BaseViewModel() {
}