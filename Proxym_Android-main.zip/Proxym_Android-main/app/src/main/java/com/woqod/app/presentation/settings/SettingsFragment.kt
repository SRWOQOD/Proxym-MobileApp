package com.woqod.app.presentation.settings

import android.content.Context.LOCATION_SERVICE
import android.content.Intent
import android.location.LocationManager
import android.provider.Settings
import com.woqod.app.BuildConfig
import com.woqod.app.databinding.FragmentSettingsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.authentication.R
import com.woqod.authentication.presentation.login.BiometricPromptUtils
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.CANCELE
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.USERNAME
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.utils.BIOMETRIC_SOURCE_SETUP
import com.woqod.shared.utils.BiometricNavEntity
import com.woqod.shared.utils.biometricsExistOnDevice


class SettingsFragment : BaseViewModelFragment<SettingsViewModel, FragmentSettingsBinding>(FragmentSettingsBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: SettingsViewModel by injectViewModel()
    private var isBioActivated = false
    private  val  bioPassword by lazy {
        sharedPreferences.user?.customIdentification ?:sharedPreferences.customPasswordForBiometric
    }
    override fun initViews() {
        appComponent.inject(this)
        handleBiometricButtonVisibility()
        binding.tvSettingsVersion.append(BuildConfig.VERSION_NAME)
        disableDefaultBackPress(true)
        setClickListeners()

    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME,null)
    }

    override fun onResume() {
        super.onResume()
        binding.switchSettingsLocation.initSwitch(isGpsEnabled(), true)
    }

    private fun setClickListeners() {
        binding.toolbarSettings.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }

        binding.tvSettingsBiometricBtn.setOnClickListener {
            if (sharedPreferences.user?.isBiometricActivated == true) {
                showDisableBiometricPopUp()
                isBioActivated = false

            } else {
                showBiometricCustomPopUp()
                isBioActivated = true
            }
        }
    }

    private fun showBiometricCustomPopUp() {
        sharedPreferences.isBiometricPopUpShown = true
        togglePopUpChoice(
            getString(R.string.AuthenticationSetupFingerprint),
            getString(R.string.AuthenticationSetupFingerprintMessage),
            popUpIcon = R.drawable.ic_popup_biometric,
            firstOption = {

            }, secondOption = {
                showBiometricNativeDialog()
            }
        )
    }

    private fun showDisableBiometricPopUp() {

        togglePopUpChoice(
            getString(com.woqod.app.R.string.SettingsDisableFingerprint),
            getString(com.woqod.app.R.string.SettingsDisableFingerprintMessage),
            popUpIcon = R.drawable.ic_popup_biometric,
            firstOption = {

            }, secondOption = {
                viewModel.updateBiometricStatus(
                    hashMapOf(
                        USERNAME to bioPassword,
                        DEVICE_ID to sharedPreferences.deviceId
                    )
                )
            }
        )
    }

    private fun showBiometricNativeDialog() {
        val biometricPrompt = BiometricPromptUtils.createBiometricPrompt(activity,
            processSuccess =
            {
                sharedPreferences.customPasswordForBiometric = sharedPreferences.user?.customIdentification?:""
                viewModel.navigate(
                    Navigation.BIOMETRIC,
                    BiometricNavEntity(BIOMETRIC_SOURCE_SETUP, isSuccess = true, isFromSettings = true)
                )
            },
            processFailure = {
                if(it != CANCELE)
                viewModel.navigate(
                    Navigation.BIOMETRIC,
                    BiometricNavEntity(BIOMETRIC_SOURCE_SETUP, isSuccess = false, isFromSettings = true)
                )
            }
        )
        val promptInfo = BiometricPromptUtils.createPromptInfo(activity)
        biometricPrompt.authenticate(promptInfo)

    }

    private fun handleBiometricButtonVisibility() {
        if (sharedPreferences.isUserLoggedIn() && biometricsExistOnDevice(activity)) {
            binding.groupSettingBiometric.show()
            sharedPreferences.user?.isBiometricActivated?.let {isActivated->
                if (isActivated) {
                    binding.tvSettingsBiometricBtn.text = getString(com.woqod.app.R.string.SettingsDisableBiometric)
                } else {
                    binding.tvSettingsBiometricBtn.text = getString(com.woqod.app.R.string.SettingsEnableBiometric)
                }
            }

        }
    }

    private fun isGpsEnabled(): Boolean {
        val locationManager = activity.getSystemService(LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    private fun openGpsSettings() {
        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    }

    override fun initObservers() {
        binding.switchSettingsLocation.switchValue.observe(viewLifecycleOwner) {
            openGpsSettings()
        }

        viewModel.updatedBiometricStatus.observe(viewLifecycleOwner) {
            it.result?.let {isUpdated->
              if(isUpdated)  {
                    sharedPreferences.isBiometricActivated = isBioActivated
                    sharedPreferences.user =
                        sharedPreferences.user?.copy(isBiometricActivated = sharedPreferences.isBiometricActivated)
                    handleBiometricButtonVisibility()
                }
            }

        }

    }

}