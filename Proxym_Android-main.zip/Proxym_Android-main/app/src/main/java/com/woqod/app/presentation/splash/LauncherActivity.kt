package com.woqod.app.presentation.splash


import com.woqod.app.databinding.ActivitySplashBinding
import com.woqod.shared.baseui.BaseActivity
import com.woqod.shared.commun.extensions.replaceFragment


class LauncherActivity : BaseActivity<ActivitySplashBinding>() {

    override fun getViewBinding() = ActivitySplashBinding.inflate(layoutInflater)

    override fun initViews() {
        replaceFragment(SplashFragment(), binding.fragmentLauncherContainer.id)
    }


}