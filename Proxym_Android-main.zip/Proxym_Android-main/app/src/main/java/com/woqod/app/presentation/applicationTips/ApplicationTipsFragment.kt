package com.woqod.app.presentation.applicationTips


import androidx.viewpager2.widget.ViewPager2
import com.woqod.app.R
import com.woqod.app.databinding.ActivityApplicationTipsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.AppTipsModel
import com.woqod.app.presentation.menu.MenuActivity
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.extensions.launchActivity

class ApplicationTipsFragment :
    BaseViewModelFragment<ApplicationTipsViewModel, ActivityApplicationTipsBinding>(
        ActivityApplicationTipsBinding::inflate
    ) {

    private val appComponent: AppComponent by lazy { GetAppComponent.getInstance() }

    override val viewModel: ApplicationTipsViewModel by injectViewModel()

    private var viewPagerPosition = 0
    private var pagesNumber = 0

    private val appTipsAdapter: AppTipsAdapter by lazy { AppTipsAdapter(mutableListOf(AppTipsModel())) }

    override fun initViews() {
        appComponent.inject(this)
        disableDefaultBackPress(true)
        initViewPager()
        setClickListeners()
        viewModel.getAppTips(sharedPreferences.deviceId)
    }

    override fun initObservers() {
        viewModel.resultAppTips.observe(this) {
            it.result?.let { appTips ->
                if (appTips.isNotEmpty()) {
                    pagesNumber = appTips.size - 1
                    appTipsAdapter.updateList(appTips.sortedBy { item -> item.orderItem })
                }
            }
        }
    }

    private fun initViewPager() {
        with(binding.pagerAppTips) {
            adapter = appTipsAdapter
            binding.indicatorAppTips.setViewPager2(this)
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    /*      if (position > 0) {
                              binding.tvAppTipsPrevious.text = getText(R.string.CommonPrevious)
                          } else*/
                    binding.tvAppTipsPrevious.text = getText(R.string.CommonSkip)
                    viewPagerPosition = position
                }
            })
            binding.indicatorAppTips.setViewPager2(binding.pagerAppTips)
        }
    }

    private fun goToNextPage() {
        when (viewPagerPosition) {
            in 0 until pagesNumber -> binding.pagerAppTips.currentItem = viewPagerPosition.inc()
            else -> onSkipAction()
        }
    }

    private fun onSkipAction() {
        sharedPreferences.isFirstLaunch = false
        activity.launchActivity<MenuActivity>(finish = true)
    }

    private fun goToPreviousPage() {
        onSkipAction()
/*
        when (viewPagerPosition) {
            in 1 until pagesNumber + 1 -> binding.pagerAppTips.currentItem = viewPagerPosition.dec()
            else ->
                onSkipAction()
        }*/
    }

    private fun setClickListeners() {
        binding.tvAppTipsNext.setOnClickListener { goToNextPage() }
        binding.tvAppTipsPrevious.setOnClickListener { goToPreviousPage() }
    }

}