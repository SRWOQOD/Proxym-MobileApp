package com.woqod.app.presentation.news

import androidx.core.widget.NestedScrollView
import com.woqod.app.databinding.FragmentNewsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.NewsModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PAGE
import com.woqod.shared.commun.SIZE
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show

class NewsFragment : BaseViewModelFragment<NewsViewModel, FragmentNewsBinding>(FragmentNewsBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: NewsViewModel by injectViewModel()

    private val newsAdapter: NewsAdapter by lazy {
        NewsAdapter(mutableListOf(), ::onItemDetailClicked)
    }

    private val numberOfNotificationsPerPage = 10
    private var pageNumber = 0
    private var isLastPage = SingleLiveEvent<Boolean>()

    override fun initViews() {
        disableDefaultBackPress(true)
        appComponent.inject(this)
        initClickListeners()
        initRecyclerView()
        getNewsList()
        binding.swipeRefreshNews.setOnRefreshListener {
        pageNumber = 0
           isLastPage = SingleLiveEvent<Boolean>()
            getNewsList()
            binding.swipeRefreshNews.isRefreshing = false

        }
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)

    }
    private fun initRecyclerView() {
        binding.rootNews.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, oldScrollY ->
            val recycler = binding.rcNewsList
            if (scrollY > (recycler.measuredHeight - v.measuredHeight) && scrollY > oldScrollY && viewModel.toggleLoading.value == false) {
                isLastPage.observe(activity) { lastPage ->
                    if (!lastPage) {
                        getNewsList()
                    }
                }
            }
        })

        binding.rcNewsList.apply {
            adapter = newsAdapter
        }

    }

    private fun getNewsList() {
        viewModel.getNewsList(hashMapOf(SIZE to numberOfNotificationsPerPage, PAGE to pageNumber))
    }

    private fun onItemDetailClicked(newsItem: NewsModel?) {
        viewModel.navigate(Navigation.NEWS_DETAILS, newsItem)
    }

    override fun initObservers() {
        viewModel.resultNewsList.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                binding.tvNoNews.hide()
                binding.rcNewsList.show()
                updateList(result.result, result.page)
                if ((result.count - 1) > pageNumber) {
                    isLastPage.postValue(false)
                    pageNumber = result.page + 1
                } else {
                    isLastPage.postValue(true)
                }
            }
            it.error?.let { error ->
                binding.tvNoNews.show()
                binding.rcNewsList.hide()
                togglePopUp(error) }
        }
    }

    private fun updateList(list: List<NewsModel>, page: Int) {
        if (page == 0) {
            newsAdapter.resetList()
        }
        if (list.isNotEmpty()) {
            binding.tvNoNews.hide()
            binding.rcNewsList.show()
            newsAdapter.updateList(list)

        } else {
            binding.tvNoNews.show()
            binding.rcNewsList.hide()
        }
    }

    private fun initClickListeners() {
        binding.toolbarNews.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

}