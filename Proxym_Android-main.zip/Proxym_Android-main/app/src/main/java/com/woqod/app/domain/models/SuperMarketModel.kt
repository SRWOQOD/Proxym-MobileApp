package com.woqod.app.domain.models

import com.woqod.shared.commundomain.models.AreaModel

data class SuperMarketModel(
    val xPortalAdress: String,
    val contactPerson: String,
    val marketId: Int,
    val area: AreaModel?,

    )