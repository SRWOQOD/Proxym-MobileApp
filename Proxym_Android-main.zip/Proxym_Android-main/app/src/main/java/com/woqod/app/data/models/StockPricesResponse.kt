package com.woqod.app.data.models

import com.woqod.app.domain.models.StockPricesModel
import com.woqod.shared.commundata.DomainMapper

/**
private Long id;
private String currency;
private String bid;
private String ask;
private String change;
private String changePercent;
private String last;
private String high;
private String low;
private String volume;
private String previousClose;
private String iSIN;
private String symbol;
private String marketName;
private String noShares;
private String marketCap;
private String open;
private Timestamp date;
 **/

data class StockPricesResponse(
    val id: Long,
    val dateStock: Long,
    val symbol: String,
    val change: String,
    val last: String,
    val open: String,
    val high: String,
    val low: String,
    val volume: String,
    val previousClose: String,
    val changePercent: String
) :DomainMapper<StockPricesModel>{
    override fun mapToDomainModel()  = StockPricesModel(
        id = id,
        date = dateStock,
        symbol = symbol,
        change = change,
        lastPrice = last,
        open = open,
        high = high,
        low = low,
        volume = volume,
        previousClose = previousClose,
        changePercent = changePercent
    )
}
