package com.woqod.app.presentation.locations.map_filter

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.sharedusecases.GetListAreasUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class MapFilterViewModel @Inject constructor(
    private val getListAreasUseCase: GetListAreasUseCase
) : BaseViewModel() {

    private val _onRequestAreas = SingleLiveEvent<ResultUseCase<List<AreaModel>?, String?>>()
    val onRequestAreas: LiveData<ResultUseCase<List<AreaModel>?, String?>> = _onRequestAreas

    fun requestAreas() {
        viewModelScope.launch {
            _onRequestAreas.postValue(executeUseCase(getListAreasUseCase))
        }
    }
}