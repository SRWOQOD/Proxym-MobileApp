package com.woqod.app.data.models

import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.models.FuelType
import com.woqod.shared.commundata.DomainMapper

/**
 * {"date":[2020,7,1,0,0],
 * "arabicName":"جازولين ممتاز (91)",
 * "price":1.1,
 * "name":"Gasoline Premium (91)",
 * "syncdate":[2020,7,14,4,0,15],
 * "id":193216}
 */
data class FuelPriceResponse(
    val date: Long?,
    val arabicName: String?,
    val price: Float?,
    val name: String?,
    val syncdate: Long?,
    val id: Int?
) : DomainMapper<FuelPriceModel> {
    override fun mapToDomainModel(): FuelPriceModel {

        return FuelPriceModel(
            date ?: 0L,
            price ?: 0f,
            nameEn =name  ?: "",
            nameAr =arabicName  ?: "",
            syncdate ?: 0L,
            id ?: 0,
            fuelType = mapToFuelType(name).first,
            itemOrder = mapToFuelType(name).second
        )
    }

    private fun mapToFuelType(name: String?): Pair<FuelType, Int> {
        name?.let {
            return when {
                it.contains("91") -> {
                    Pair(FuelType.GASOLINE_PREMIUM, 1)
                }
                it.contains("95") -> {
                    Pair(FuelType.GASOLINE_SUPER, 2)
                }
                else -> {
                    Pair(FuelType.DIESEL, 3)
                }
            }
        } ?: return Pair(FuelType.DIESEL, 3)
    }

}