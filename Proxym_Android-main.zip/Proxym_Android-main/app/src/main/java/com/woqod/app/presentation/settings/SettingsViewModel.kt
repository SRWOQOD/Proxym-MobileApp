package com.woqod.app.presentation.settings


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.usecases.GetSurveyStatusUseCase
import com.woqod.app.domain.usecases.PostSurveyStatusUseCase
import com.woqod.app.domain.usecases.UpdateBiometricStatusUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class SettingsViewModel @Inject constructor(
    private val getSurveyStatusUseCase: GetSurveyStatusUseCase,
    private val postSurveyStatusUseCase: PostSurveyStatusUseCase,
    private val updateBiometricStatusUseCase: UpdateBiometricStatusUseCase
) : BaseViewModel() {

    private val _resultGetSurveyStatus = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultGetSurveyStatus: LiveData<ResultUseCase<Boolean?, String?>> = _resultGetSurveyStatus

    private val _resultPostSurveyStatus = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultPostSurveyStatus: LiveData<ResultUseCase<Boolean?, String?>> = _resultPostSurveyStatus

    private val _updatedBiometricStatus = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val updatedBiometricStatus: LiveData<ResultUseCase<Boolean?, String?>> = _updatedBiometricStatus
    fun updateBiometricStatus(query: HashMap<String, String>) {
        viewModelScope.launch {
            _updatedBiometricStatus.postValue(executeUseCase(updateBiometricStatusUseCase, query))
        }
    }

    fun getSurveyStatus(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultGetSurveyStatus.postValue(executeUseCase(getSurveyStatusUseCase, query))
        }
    }

    fun postSurveyStatus(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultPostSurveyStatus.postValue(executeUseCase(postSurveyStatusUseCase, query))
        }
    }
}