package com.woqod.app.presentation.locations

import android.annotation.SuppressLint
import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.provider.Settings
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.view.isVisible
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.maps.android.clustering.Cluster
import com.google.maps.android.clustering.ClusterManager
import com.woqod.app.R
import com.woqod.app.databinding.FragmentLocationsBinding
import com.woqod.app.databinding.LayoutToolbarMapBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.models.MapTypeStation
import com.woqod.app.domain.models.PetrolStationStatus
import com.woqod.app.presentation.locations.map_cluster.MarkerCluster
import com.woqod.app.presentation.locations.map_cluster.MarkerClusterRenderer
import com.woqod.app.presentation.locations.map_filter.MapFilterFragment
import com.woqod.app.presentation.menu.MenuActivity
import com.woqod.app.presentation.utils.*
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.LocationRedirection.Companion.FROM_FAHES
import com.woqod.shared.commun.LocationRedirection.Companion.FROM_MAP_FILTER
import com.woqod.shared.commun.LocationRedirection.Companion.FROM_PETROL
import com.woqod.shared.commun.LocationRedirection.Companion.FROM_SHAFAF
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PHONE_NUMBERS_DIALOG_TAG
import com.woqod.shared.commun.STATION_ID
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundata.RATING
import com.woqod.shared.commundomain.models.MapFilterModel
import com.woqod.shared.commundomain.models.MapFilterNavigationModel
import com.woqod.shared.commundomain.models.MapNavigationModel
import com.woqod.shared.utils.MAPS_ARGS
import com.woqod.shared.utils.PermissionsUtils
import com.woqod.shared.utils.convertDPtoPixels
import com.woqod.shared.utils.showStandardDialog
import com.woqod.shared.widget.PopUpType
import com.woqod.shared.widget.phone_numbers_dialog.PhoneNumbersDialog
import kotlinx.coroutines.launch
import pub.devrel.easypermissions.AppSettingsDialog
import pub.devrel.easypermissions.EasyPermissions

class LocationsFragment :
    BaseViewModelFragment<LocationsViewModel, FragmentLocationsBinding>(FragmentLocationsBinding::inflate),
    EasyPermissions.PermissionCallbacks,
    GoogleMap.OnMapClickListener,
    ClusterManager.OnClusterClickListener<MarkerCluster>,
    ClusterManager.OnClusterItemClickListener<MarkerCluster> {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: LocationsViewModel by injectViewModel()

    private var mergedView: LayoutToolbarMapBinding? = null
    private var params: MapNavigationModel? = null
    private var currentLocation = SingleLiveEvent<Location?>()
    private var googleMap: GoogleMap? = null
    private var listStations = ArrayList<MapStationModel>()
    private var listAllStations = ArrayList<MapStationModel>()
    private var filteredListBySearch = emptyList<MapStationModel>()
    private var filteredListByFilter = mutableListOf<MapStationModel>()
    private var from: String? = null
    private var fromShafafRetailers: Boolean = false
    private var fromRating: Boolean = false
    private var fromOrigin: String? = null
    private var filter: MapFilterModel? = null
    private var fromFilter: Boolean = false
    private lateinit var clusterManager: ClusterManager<MarkerCluster>
    private lateinit var animScaleUp: Animation
    private lateinit var animScaleDown: Animation
    private var filterListStation = emptyList<MapStationModel>()
    private var filterMapModified = false
    private val callback = OnMapReadyCallback { googleMap ->
        this.googleMap = googleMap
        googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(context, R.raw.map_style))
        googleMap.uiSettings.isCompassEnabled = false
        googleMap.uiSettings.isMyLocationButtonEnabled = false
        getWebServices()
        moveCameraPosition(googleMap, QATAR_LOCATION)
        googleMap.setOnMapClickListener(this)
    }

    private val searchAdapter: MapSearchAdapter by lazy {
        MapSearchAdapter(mutableListOf()) {
            binding.toolbarMap.containerSearchSuggestions.hide()
            zoomToPosition(it.latitude, it.longitude, 18f)
            setStationDetails(it)
        }
    }

    fun newInstance(params: MapNavigationModel): LocationsFragment {
        val args = Bundle()
        args.putSerializable(MAPS_ARGS, params)
        val fragment = LocationsFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        disableDefaultBackPress(true)
        appComponent.inject(this)
        mergedView = LayoutToolbarMapBinding.bind(binding.root)
        if (params == null)
            handleFragmentArgs()
        val mapFragment =
            childFragmentManager.findFragmentById(R.id.map_fragment) as SupportMapFragment
        getUserLocation()
        mapFragment.getMapAsync(callback)
        setHasOptionsMenu(true)
        setAnimations()
        setupToolbar()
        initSearchByText()
        if (fromShafafRetailers) {
            binding.toolbarMap.mapFilter.hide()
            binding.toolbarMap.guidelineVertical80.setGuidelinePercent(
                1f
            )
        }
    }

    override fun onBackPressCustomAction() {
        MapFilterFragment.clearInstance()
        when (fromOrigin) {
            FROM_FAHES -> {
                viewModel.navigate(Navigation.FAHES, null)
            }
            FROM_SHAFAF -> {
                viewModel.navigate(Navigation.SHAFAF, null)
            }
            FROM_PETROL -> {
                viewModel.navigate(Navigation.HOME, null)
            }
            FROM_MAP_FILTER -> {
                if (fromShafafRetailers) viewModel.navigate(Navigation.SHAFAF_RETAILERS, null)
                else viewModel.navigate(Navigation.HOME, null)

            }

        }

    }

    private fun setToolbar() {
        when (fromOrigin) {
            FROM_FAHES, FROM_SHAFAF -> {
                binding.toolbarMap.btnMapToolbar.setImageResource(R.drawable.ic_toolbar_arrow_back)
                binding.toolbarMap.btnMapToolbar.setOnClickListener { onBackPressCustomAction() }
            }

            FROM_MAP_FILTER -> {
                if (fromShafafRetailers) {
                    binding.toolbarMap.btnMapToolbar.setImageResource(R.drawable.ic_toolbar_arrow_back)
                    binding.toolbarMap.btnMapToolbar.setOnClickListener { onBackPressCustomAction() }
                } else {
                    binding.toolbarMap.btnMapToolbar.setImageResource(R.drawable.ic_toolbar_open)
                    binding.toolbarMap.btnMapToolbar.setOnClickListener {
                        viewModel.navigate(Navigation.MENU, null)
                    }
                }

            }

            else -> {
                binding.toolbarMap.btnMapToolbar.setImageResource(R.drawable.ic_toolbar_open)
                binding.toolbarMap.btnMapToolbar.setOnClickListener {
                    viewModel.navigate(Navigation.MENU, null)
                }
            }
        }
    }

    override fun handleFragmentArgs() {
        arguments?.let {
            params = it.getSerializable(MAPS_ARGS) as MapNavigationModel
        }
        params?.let {
            from = it.from
            fromOrigin = it.fromOrigin ?: it.from
            filter = it.filterModel
            fromShafafRetailers = it.fromShafafRetailers
            fromRating = it.isFromRating
            if (it.isBackFromFilter) filterMapModified = true
        }
    }

    private fun setupToolbar() {
        binding.toolbarMap.rvSearchSuggestions.adapter = searchAdapter
        binding.toolbarMap.mapSearch.editableValue.clearFocus()
        binding.toolbarMap.mapFilter.setOnClickListener {
            googleMap?.clear()
            if (!filterMapModified) {
                MapFilterFragment.clearInstance()
                filterMapModified = true
            } else {
                MapFilterFragment.updateInstance(MapFilterNavigationModel(
                    from,
                    listAllStations.distinctBy { listOf(it.latitude, it.longitude, it.title) }
                        .map { it.title })
                )
            }
            viewModel.navigate(Navigation.MAP_FILTER, MapFilterNavigationModel(
                fromOrigin,
                listAllStations.distinctBy { listOf(it.latitude, it.longitude, it.title) }
                    .map { it.title }, isFromRating = fromRating
            )
            )
        }
        setToolbar()

    }

    private fun setAnimations() {
        animScaleUp =
            AnimationUtils.loadAnimation(activity.applicationContext, R.anim.scale_up)
        animScaleDown =
            AnimationUtils.loadAnimation(activity.applicationContext, R.anim.scale_down)
    }

    private fun addMarkersToCluster() {
        googleMap?.let {
            clusterManager = ClusterManager(activity, it)
            it.setOnCameraIdleListener(clusterManager)
            clusterManager.renderer = MarkerClusterRenderer(requireContext(), it, clusterManager)
            it.clear()
            clusterManager.clearItems()
            //clusterManager.addItems(viewModel.getMarkersFromStations(listStations.distinct() { item -> item.id }))
            clusterManager.addItems(viewModel.getMarkersFromStations(filterListStation.distinct()))
            clusterManager.cluster()
//            it.setOnMarkerClickListener(clusterManager)
            clusterManager.setOnClusterClickListener(this)
            clusterManager.setOnClusterItemClickListener(this)
        }
    }

    private fun getWebServices() {
        when (from) {
            FROM_FAHES -> {
                (activity as MenuActivity).toggleBottomBar(false)
                viewModel.getFahesStations()
            }
            FROM_SHAFAF -> {
                (activity as MenuActivity).toggleBottomBar(false)
                viewModel.getSuperMarkets()
            }
            FROM_PETROL -> {
                viewModel.getPetrolStations()
            }
            FROM_MAP_FILTER -> {
                if (fromShafafRetailers || fromOrigin != FROM_PETROL) {
                    (activity as MenuActivity).toggleBottomBar(false)
                }
                filter?.let { filter ->
                    viewModel.setMapFilter(filter)
                    listStations.clear()
                    listAllStations.clear()
                    filteredListBySearch = emptyList()
                    filteredListByFilter.clear()
                    checkSelectedFilters(filter)
                }
            }
        }
    }

    private fun checkSelectedFilters(filter: MapFilterModel) {
        // don't change the order of these conditions
        if (filter.isSuperMarketSelected) viewModel.getSuperMarkets()
        if (filter.isFahesStationSelected) viewModel.getFahesStations()
        if (filter.isPetrolStationSelected) viewModel.getPetrolStations()
        if (filter.isSidraMarketSelected) viewModel.getSidraStandelonesStations()
        if (filter.isMobilePetrolSelected) viewModel.getMobilePertolStations()
        if (filter.isMarineStationSelected) viewModel.getMarineStations()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun initObservers() {
        currentLocation.observe(this) { location ->
            location?.let {
                zoomToPosition(it.latitude, it.longitude)
                binding.imgMapsDirections.show()
            } ?: binding.imgMapsDirections.hide()
        }

        viewModel.resultLoadedStationImages.observe(viewLifecycleOwner) {
            if (!fromFilter) {
                listStations.clear()
                listStations.addAll(it)
                filterListStation = listStations
            } else {
                fromFilter = false
                filterListStation = it
            }
            toggleLoading(false)
            addMarkersToCluster()
        }
        observeListSupermarkets()
        observeListFahesStations()
        observeListPetrolStations()
        observeListSidraStations()
        observeListMobilePetrolStations()
        observeListMarineStations()
        observeRatingStations()
    }

    private fun observeRatingStations() {
        viewModel.resultPostRatingStation.observe(this) {
            it.result?.let {
                binding.cardMapRating.startAnimation(animScaleDown)
                binding.cardMapRating.hide()
                togglePopUp(
                    popUpType = PopUpType.POPUP_SUCCESS,
                    action = { viewModel.navigate(Navigation.HOME, null) },
                    message = getString(R.string.LocationRateSuccessMessage)
                )

            }
            it.error?.let { error ->
                binding.cardMapRating.startAnimation(animScaleDown)
                binding.cardMapRating.hide()
                togglePopUp(error)
            }
        }
    }

    private fun observeListPetrolStations() {
        viewModel.resultListPetrolStation.observe(this) {
            it.result?.distinct().let { listnotDistinct ->
                val list = listnotDistinct?.toMutableList()

                list?.let { it1 -> listAllStations.addAll(it1) }
                if (from == FROM_MAP_FILTER) {
                    lifecycleScope.launch {
                        filter?.let { filter ->
                            zoomToResult(filter)
                            if (filter.searchName.isEmpty() && filter.isPetrolStationSelected) {
                                list?.let { it1 -> filterPetrolStation(it1) }
                            } else {
                                list?.let { it1 -> filterStationsByName(it1) }
                            }
                        } ?: list?.let { it1 -> filterStationsByName(it1) }
                    }
                } else list?.let { it1 -> putStationOnMap(it1) }
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun zoomToResult(filter: MapFilterModel) {
        currentLocation.value?.latitude?.let { latitude ->
            currentLocation.value?.longitude?.let { longitude ->
                if (filter.zone != null)
                    zoomToPosition(
                        filter.zone?.latitude?.toDouble() ?: latitude,
                        filter.zone?.longitude?.toDouble() ?: longitude,
                        MAP_ZOOM_FILTER
                    )
                else
                    zoomToPosition(latitude, longitude, MAP_ZOOM_FILTER)
            }
        }
    }

    private fun observeListSidraStations() {
        viewModel.resultListSidraStation.observe(this) {
            it.result?.distinct().let { list ->
                list?.let { it1 -> listAllStations.addAll(it1) }
                if (from == FROM_MAP_FILTER) {
                    lifecycleScope.launch {
                        filter?.let { filter ->
                            zoomToResult(filter)
                            if (filter.searchName.isEmpty() && filter.isSidraMarketSelected) {
                                list?.let { it1 -> filterPetrolStation(it1, false) }
                            } else {
                                list?.let { it1 -> filterStationsByName(it1) }
                            }
                        } ?: list?.let { it1 -> filterStationsByName(it1) }
                    }
                } else list?.let { it1 -> putStationOnMap(it1) }
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }


    private fun observeListMobilePetrolStations() {
        viewModel.resultListMobilePertolStations.observe(this) {
            it.result?.distinct().let { list ->
                list?.let { it1 -> listAllStations.addAll(it1) }
                if (from == FROM_MAP_FILTER) {
                    lifecycleScope.launch {
                        filter?.let { filter ->
                            zoomToResult(filter)
                            if (filter.searchName.isEmpty() && filter.isMobilePetrolSelected) {
                                list?.let { it1 -> filterPetrolStation(it1, false) }
                            } else {
                                list?.let { it1 -> filterStationsByName(it1) }
                            }
                        } ?: list?.let { it1 -> filterStationsByName(it1) }
                    }
                } else list?.let { it1 -> putStationOnMap(it1) }
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun observeListMarineStations() {
        viewModel.resultListMarineStations.observe(this) {
            it.result?.distinct().let { list ->
                list?.let { it1 -> listAllStations.addAll(it1) }
                if (from == FROM_MAP_FILTER) {
                    lifecycleScope.launch {
                        filter?.let { filter ->
                            zoomToResult(filter)
                            if (filter.searchName.isEmpty() && filter.isMarineStationSelected) {
                                list?.let { it1 -> filterPetrolStation(it1, false) }
                            } else {
                                list?.let { it1 -> filterStationsByName(it1) }
                            }
                        } ?: list?.let { it1 -> filterStationsByName(it1) }
                    }
                } else list?.let { it1 -> putStationOnMap(it1) }
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun observeListSupermarkets() {
        viewModel.resultListSuperMarkets.observe(this) {
            it.result?.let { list ->

                listAllStations.addAll(list)
                if (from == FROM_MAP_FILTER) {
                    filter?.let { filter ->
                        zoomToResult(filter)
                        if (filter.searchName.isEmpty() && filter.isSuperMarketSelected) {
                            filterSuperMarketStation(list)
                        } else {
                            filterStationsByName(list)
                        }
                    } ?: filterStationsByName(list)
                } else putStationOnMap(list)
            }
            it.error?.apply {
                togglePopUp(this)
            }
        }
    }

    private fun observeListFahesStations() {
        viewModel.resultListFahesStation.observe(this) {
            it.result?.let { listNoDistinct ->
                val list = listNoDistinct.distinct().toMutableList()
                listAllStations.addAll(list)
                if (from == FROM_MAP_FILTER) {
                    filter?.let { filter ->
                        zoomToResult(filter)
                        if (filter.searchName.isEmpty() && filter.isFahesStationSelected) {
                            filterFahesStation(list)
                        } else {
                            filterStationsByName(list)
                        }
                    } ?: filterStationsByName(list)
                } else putStationOnMap(list)
            }
            it.error?.let { error -> togglePopUp(error) }

        }
    }

    private fun filterPetrolStation(list: List<MapStationModel>, isPetrolCategory: Boolean = true) {
        lifecycleScope.launch {
            val filterByArea = viewModel.filterByArea(list, isFahes = false)
            val listPetrolStationByDistance = viewModel.filterStationByDistance(
                filterByArea,
                currentLocation.value,
                ::showLocationError
            )
            if (isPetrolCategory) {
                val listPetrolStationByOpeningTime =
                    viewModel.filterServicesByOpeningTime(
                        listPetrolStationByDistance,
                        filter?.services
                    )
                filteredListByFilter.addAll(
                    viewModel.filterPetrolStationByServices(
                        listPetrolStationByOpeningTime
                    )
                )
            } else {
                filteredListByFilter.addAll(listPetrolStationByDistance)
            }
            putStationOnMap(filteredListByFilter.distinctBy {
                listOf(
                    it.latitude,
                    it.longitude,
                    it.title
                )
            })
        }
    }


    private fun filterSuperMarketStation(list: List<MapStationModel>) {
        lifecycleScope.launch {
            val filterByArea = viewModel.filterByArea(list, isFahes = false, isShafaf = true)
            filteredListByFilter.addAll(
                viewModel.filterStationByDistance(
                    filterByArea,
                    currentLocation.value,
                    ::showLocationError
                )
            )
            filter?.apply {
                putStationOnMap(
                    filteredListByFilter.distinct()
                )
            }
        }
    }

    private fun filterFahesStation(list: List<MapStationModel>) {
        lifecycleScope.launch {
            val filterByArea = viewModel.filterByArea(list, isFahes = true)
            filteredListByFilter.addAll(
                viewModel.filterStationByDistance(
                    filterByArea,
                    currentLocation.value,
                    ::showLocationError
                )
            )
            filter?.apply {
                putStationOnMap(filteredListByFilter.distinct())
            }
        }
    }

    /**
     * Filtering by Name
     * */
    private fun filterStationsByName(list: List<MapStationModel>) {
        lifecycleScope.launch {
            if (fromShafafRetailers) {
                val station = MapStationModel(
                    latitude = filter?.latitude ?: 0.0,
                    longitude = filter?.longitude ?: 0.0,
                    title = filter?.searchName ?: "",
                    phone = filter?.phone ?: "",
                    type = MapTypeStation.SUPERMARKET_STATION,
                    id = null,
                    icon = filter?.icon
                )
                zoomToPosition(station.latitude, station.longitude, 18f)
                putStationOnMap(listOf(station))
                setStationDetails(station)
            } else {
                viewModel.filterStationsBySearch(list)?.let {
                    filter?.latitude?.let { latitude ->
                        filter?.longitude?.let { longitude ->
                            zoomToPosition(latitude, longitude, 18f)
                            putStationOnMap(it)
                            setStationDetails(it.first())
                        }
                    } ?: putStationOnMap(it)

                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun getDeviceLocation() {
        lifecycleScope.launch {
            getCurrentDeviceLocation(activity)?.let {
                googleMap?.isMyLocationEnabled = true
                currentLocation.postValue(it)
            } ?: kotlin.run {
                currentLocation.postValue(null)
                showLocationError()
            }
        }
    }

    private fun getUserLocation() {
        if (PermissionsUtils().hasLocationPermissions(activity) &&
            PermissionsUtils().isGpsEnabled(activity)
        ) {
            getDeviceLocation()
        } else if (PermissionsUtils().hasLocationPermissions(activity) &&
            !PermissionsUtils().isGpsEnabled(activity)
        ) {
            openGPSRequestDialog()
        } else {
            PermissionsUtils().requestLocationPermission(this,activity)

        }
    }

    private fun openGPSRequestDialog() {
        showStandardDialog(
            activity,
            getString(R.string.LocationActivateGpsTitle),
            getString(R.string.LocationActivateGpsMessage),
            getString(android.R.string.yes),
            getString(android.R.string.no),
            { _, _ ->
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            },
            { dialog, _ ->
                dialog.cancel()
            }
        )
    }

    private fun zoomToPosition(lat: Double, lng: Double, zoom: Float = MAP_ZOOM) {
        googleMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat, lng), zoom))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            AppSettingsDialog.Builder(this).build().show()
        } else
            PermissionsUtils().requestLocationPermission(this,activity)
    }

    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        if (PermissionsUtils().isGpsEnabled(activity)) {
            getDeviceLocation()
        } else {
            openGPSRequestDialog()
        }
    }

    private fun putStationOnMap(list: List<MapStationModel>) {
        val listStation = mutableListOf<MapStationModel>()
        listStation.addAll(list)
        viewModel.loadStationImages(
            requireContext(),
            listStation.distinctBy { listOf(it) })
    }

    override fun onMapClick(p0: LatLng?) {
        binding.toolbarMap.containerSearchSuggestions.hide()
        with(binding.cardMapDetails) {
            if (isVisible) {
                startAnimation(animScaleDown)
                hide()
            }
        }
        with(binding.cardMapRating) {
            if (isVisible) {
                startAnimation(animScaleDown)
                hide()
            }
        }
    }

    private fun setStationDetails(station: MapStationModel) {
        if (fromRating && station.petrolStationModel?.status == PetrolStationStatus.Active)
            showStationRating(station) else
            showStationInformations(station)

    }

    private fun showStationInformations(station: MapStationModel) {
        binding.cardMapDetails.startAnimation(animScaleUp)
        binding.cardMapDetails.show()
        setPhoneNumber(station.phone)
        setBottomSheetClickListeners(station)
        binding.tvLocationStationName.text = station.title
        when (station.type) {
            MapTypeStation.FAHES_STATION -> {
                binding.groupTimingFahes.show()
                station.apply {
                    binding.tvStationAddress.text = station.fahesStationModel?.firstAddress
                    binding.tvLocationTiming.text = station.fahesStationModel?.workingDays?.trim()
                }
            }
            MapTypeStation.SUPERMARKET_STATION -> {
                station.apply {
                    binding.groupTimingFahes.hide()
                }
            }
            MapTypeStation.PETROL_STATION, MapTypeStation.SIDRA_STATION, MapTypeStation.MARINE_STATION, MapTypeStation.MOBILE_PETROL_STATION -> {
                station.apply {
                    binding.groupTimingFahes.hide()
                    binding.rvMapStation.show()
                    initRecyclerServices(station)
                }
            }
        }
    }

    private fun showStationRating(station: MapStationModel) {
        binding.ratingBarStation.rating = 3F
        binding.cardMapRating.startAnimation(animScaleUp)
        binding.cardMapRating.show()
        binding.tvLocationStationRatingName.text = station.title
        val padding = convertDPtoPixels(activity, 10)

        if (station.phone.isEmpty()) {
            binding.tvLocationStationRatingName.setPadding(
                padding,
                padding * 2,
                padding,
                padding * 2
            )
            binding.tvLocationNumberRating.hide()
            binding.imgMapsCallRating.invisible()
        } else {
            binding.tvLocationStationRatingName.setPadding(padding, padding, padding, 0)
            binding.tvLocationNumberRating.show()
            binding.imgMapsCallRating.show()
            "${getString(R.string.BulkLpgItemPhone)} ${station.phone}".also {
                binding.tvLocationNumberRating.setDoubleFontBookAndBold(activity, it)
            }
            binding.imgMapsCallRating.setOnClickListener {
                makeCall(station.phone)
            }
        }

        binding.btnSubmitRating.setOnClickListener {
            station.id?.let { id ->
                viewModel.postRatingStations(
                    hashMapOf(
                        STATION_ID to id,
                        RATING to binding.ratingBarStation.rating.toInt(),
                        DEVICE_ID to sharedPreferences.deviceId
                    )
                )
            }
        }


    }

    private fun setPhoneNumber(phone: String) {
        if (phone.isEmpty()) {
            binding.imgMapsCall.hide()
            binding.tvLocationNumber.invisible()
        } else {
            binding.imgMapsCall.show()
            binding.tvLocationNumber.show()
            "${getString(R.string.BulkLpgItemPhone)} $phone".also {
                binding.tvLocationNumber.setDoubleFontBookAndBold(activity, it)
            }
        }
    }

    private fun onCallRetailerItemClicked(phone: String) {
        val phoneList = phone.split("/")
        if (phoneList.size == 1) phone.makeCall(activity) else openPhoneNumbersDialog(phoneList)
    }

    private fun openPhoneNumbersDialog(phoneNumbers: List<String>) {
        val phoneNumbersDialog = PhoneNumbersDialog(phoneNumbers) { it.makeCall(activity) }
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        activity.supportFragmentManager.findFragmentByTag(PHONE_NUMBERS_DIALOG_TAG)
            ?.let { fragmentTransaction.remove(it) }
            .also { fragmentTransaction.addToBackStack(null) }
        with(phoneNumbersDialog) { show(fragmentTransaction, PHONE_NUMBERS_DIALOG_TAG) }
    }

    private fun setBottomSheetClickListeners(model: MapStationModel) {
        binding.imgMapsCall.setOnClickListener {
            onCallRetailerItemClicked(model.phone)
        }
        binding.imgMapsDirections.setOnClickListener {
            if (currentLocation.value == null) {
                showLocationError()
                return@setOnClickListener
            }
            currentLocation.value?.goToGoogleMapsWithDirection(
                activity,
                LatLng(model.latitude, model.longitude)
            )
        }
    }

    private fun showLocationError() {
        activity.showSnackbar(
            binding.constraintLayoutParentMaps,
            getString(R.string.LocationCouldNotGetPosition)
        )
    }

    private fun makeCall(phone: String) {
        if (phone.trim().length >= 8) phone.makeCall(activity)
    }

    override fun onClusterClick(p0: Cluster<MarkerCluster>?): Boolean {
        with(binding.cardMapDetails) {
            if (isVisible) {
                startAnimation(animScaleDown)
                hide()
            }
        }
        with(binding.cardMapRating) {
            if (isVisible) {
                startAnimation(animScaleDown)
                hide()
            }
        }
        return false
    }

    override fun onClusterItemClick(marker: MarkerCluster?): Boolean {
        val clickedPosition = marker?.position
        if (listStations.isNotEmpty()) {
            listStations.distinctBy { listOf(it.latitude, it.longitude, it.title) }.forEach {
                if (it.latitude == clickedPosition?.latitude && it.longitude == clickedPosition.longitude) {
                    setStationDetails(it)
                    return false
                }
            }
        }
        return false
    }

    private fun initRecyclerServices(selectedStation: MapStationModel) {
        if (selectedStation.petrolStationModel!!.serviceStations.isNotEmpty()) {
            binding.tvStationStatus.hide()
            binding.rvMapStation.adapter =
                ServiceLocationsAdapter(selectedStation.petrolStationModel.serviceStations)
        } else {
            binding.rvMapStation.hide()
            val text = when (selectedStation.petrolStationModel.status) {
                PetrolStationStatus.Under_Construction -> Pair(
                    getString(R.string.LocationStationUnderConstruction),
                    R.color.color_B30839
                )
                PetrolStationStatus.Active -> Pair(
                    getString(R.string.LocationStationActive),
                    R.color.color_009933
                )
                PetrolStationStatus.Opening_Soon, PetrolStationStatus.Upcoming -> Pair(
                    getString(R.string.LocationStationUpcoming),
                    R.color.color_F89828
                )
                else -> Pair(getString(R.string.LocationStationInactive), R.color.color_F89828)
            }
            binding.tvStationStatus.show()
            binding.tvStationStatus.text = text.first
            binding.tvStationStatus.textColor(text.second)
        }
    }

    private fun initSearchByText() {
        binding.toolbarMap.mapSearch.editableValue.doOnTextChanged { text, _, _, _ ->
            fromFilter = true
            if (text?.isNotBlank() == true) {
                val listTosearch: List<MapStationModel> =
                    if (filter != null) filteredListByFilter else listStations
                filteredListBySearch =
                    listTosearch.distinctBy { listOf(it.latitude, it.longitude, it.title) }
                        .filter { it.title.contains(text, true) }

                if (filteredListBySearch.isEmpty()) binding.toolbarMap.containerSearchSuggestions.hide()
                else binding.toolbarMap.containerSearchSuggestions.show()
                searchAdapter.updateList(filteredListBySearch.distinct())
                putStationOnMap(filteredListBySearch.distinct())
            } else {
                searchAdapter.updateList(listStations.distinctBy {
                    listOf(
                        it.latitude,
                        it.longitude
                    )
                })
                binding.toolbarMap.containerSearchSuggestions.hide()
                putStationOnMap(listStations.distinctBy {
                    listOf(
                        it.latitude,
                        it.longitude,
                        it.title
                    )
                })
            }
        }
    }
}