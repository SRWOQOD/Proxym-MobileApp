package com.woqod.app.presentation.locations.map_cluster

import android.content.Context
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.clustering.ClusterManager
import com.google.maps.android.clustering.view.DefaultClusterRenderer
import com.woqod.app.R
import com.woqod.app.presentation.utils.getCustomMarkerIcon

class MarkerClusterRenderer(
    private val context: Context,
    googleMap: GoogleMap?,
    clusterManager: ClusterManager<MarkerCluster>?
) : DefaultClusterRenderer<MarkerCluster>(context, googleMap, clusterManager) {

    override fun onBeforeClusterItemRendered(item: MarkerCluster, markerOptions: MarkerOptions) {
        val fallbackIcon = R.drawable.ic_map_woqod_station
        markerOptions.icon(
            BitmapDescriptorFactory.fromBitmap(
                getCustomMarkerIcon(
                    context,
                    fallbackIcon,
                    item.drawable
                )
            )
        )
    }
}