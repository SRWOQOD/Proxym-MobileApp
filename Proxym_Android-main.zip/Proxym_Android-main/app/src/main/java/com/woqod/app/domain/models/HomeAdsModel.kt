package com.woqod.app.domain.models

import com.woqod.shared.WoqodApplication

data class HomeAdsModel(
    val videoThumbnail: String?,
    val orderItem: Int,
    val fileUrl: String?,
    val fileTypeEnum: HomeBannerFileType,
    val id: Int,
    val title: String,
    val titleArabic: String,
    val creationDate: Long,
    val redirectionTypeEnum: HomeBannerRedirectionType?,
    val redirectionPath: String?,
    val redirection: Boolean,
    val appRedirection: HomeBannerAppRedirection?,
    val titleDisplayed: Boolean
) {
    constructor() : this(null ,0, null,HomeBannerFileType.IMG, 0,"","", 0L,null,"",false,null,false)

    fun getAdsBannerTitle() = if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) titleArabic else title
}