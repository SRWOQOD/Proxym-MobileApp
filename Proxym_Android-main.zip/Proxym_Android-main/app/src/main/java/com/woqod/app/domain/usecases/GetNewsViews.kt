package com.woqod.app.domain.usecases

import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetNewsViews @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCaseWithRequest<Long,WoqodResult<SharedResponse<Boolean>>> {
    override suspend fun invoke(id: Long): WoqodResult<SharedResponse<Boolean>> =
        appRepository.incrementNewsViews(id)
}