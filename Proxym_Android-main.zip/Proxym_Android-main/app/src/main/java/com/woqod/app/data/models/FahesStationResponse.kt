package com.woqod.app.data.models

import com.woqod.app.domain.models.FahesStationModel
import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.models.MapTypeStation
import com.woqod.app.domain.models.PetrolStationStatus
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper
import com.woqod.shared.commundata.models.AreaResponse

/**
 * {"workingDays":"Saturday - Thursday \n",
 * "latitude":25.191811,
 * "secondAddress":"Industrial Area",
 * "title":"Fahes -Industrial Area",
 * "arabicFirstAddress":"24,
 * Al Kasarat street",
 * "lastSynchronisationDate":[2020,7,15,4,2,8,255000000],
 * "arabicSecondAddress":"Industrial Area",
 * "titleArabic":"(فاحص (المنطقة الصناعية",
 * "areaId":22,
 * "phone":"+974-40218800",
 * "arabicWorkingDays":"السبت الى الخميس",
 * "id":null,
 * "firstAddress":"24,
 * Al Kasarat street",
 * "fahesId":6,
 * "status":"Active",
 * "longitude":51.433124}
 */
data class FahesStationResponse(
    val workingDays: String?,
    val secondAddress: String?,
    val title: String?,
    val arabicFirstAddress: String?,
    val lastSynchronisationDate: Long?,
    val arabicSecondAddress: String?,
    val titleArabic: String?,
    val area: AreaResponse?,
    val phone: String?,
    val arabicWorkingDays: String?,
    val id: Int?,
    val firstAddress: String?,
    val fahesId: Int?,
    val status: String?,
    val latitude: Double?,
    val longitude: Double?,
    val icon: String?,
    val serviceStations: List<ServiceStationResponse>?,
) : DomainMapper<MapStationModel> {
    override fun mapToDomainModel(): MapStationModel {
        val workingDaysFahesStation: String?
        val titleFahesStation: String?
        val firstAddressFahesStation: String?
        val secondAddressFahesStation: String?
        if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
            workingDaysFahesStation = arabicWorkingDays
            titleFahesStation = titleArabic
            firstAddressFahesStation = arabicFirstAddress
            secondAddressFahesStation = arabicSecondAddress
        } else {
            workingDaysFahesStation = workingDays
            titleFahesStation = title
            firstAddressFahesStation = firstAddress
            secondAddressFahesStation = secondAddress
        }
        return MapStationModel(
            MapTypeStation.FAHES_STATION,
            fahesId ?: 0,
            titleFahesStation ?: "",
            phone ?: "",
            latitude ?: 0.0,
            longitude ?: 0.0,
            lastSynchronisationDate ?: 0L,
            null,
            null,
            FahesStationModel(
                workingDaysFahesStation ?: "",
                secondAddressFahesStation ?: "",
                area?.mapToDomainModel(),
                firstAddressFahesStation ?: "",
                fahesId ?: 0,
                PetrolStationStatus.valueOf(status ?: PetrolStationStatus.Inactive.value),
                serviceStations?.map {
                    it.mapToDomainModel()
                }?: emptyList()
            ),
            icon = icon
        )
    }

}