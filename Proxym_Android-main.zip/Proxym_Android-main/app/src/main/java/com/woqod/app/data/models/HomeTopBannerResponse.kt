package com.woqod.app.data.models

import com.woqod.app.domain.models.HomeBannerRedirectionType
import com.woqod.app.domain.models.HomeTopBannerModel
import com.woqod.app.domain.models.getRedirectionAppType
import com.woqod.app.domain.models.mapToFileType
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

/**
 * {
"videoThumbnail": "https://ftp.proxym-group.net/woqod/manualUpload/video_temporary_thumbnail.png",
"fileTypeEnum": "VIDEO",
"appRedirection": null,
"orderItem": "1",
"active": true,
"redirectionTypeEnum": null,
"redirectionPath": null,
"title": "test video",
"creationDate": 1624874601087,
"titleArabic": "يوكوهاما",
"fileUrl": "https://ftp.proxym-group.net/woqod/20210628130257316.mp4",
"id": 39358,
"redirection": null
},
 
 */
data class HomeTopBannerResponse(
    val videoThumbnail: String?,
    val fileTypeEnum: String?,
    val appRedirection: String?,
    val orderItem: String?,
    val redirectionTypeEnum: String?,
    val redirectionPath: String?,
    val redirectionArPath: String?,
    val title: String?,
    val titleArabic: String?,
    val fileUrl: String?,
    val id: Long?,
    val redirection: Boolean?,
    val titleDisplayed : Boolean?
) : DomainMapper<HomeTopBannerModel> {
    override fun mapToDomainModel() = HomeTopBannerModel(
        videoThumbnail = videoThumbnail,
        fileTypeEnum = mapToFileType(fileTypeEnum),
        appRedirection = appRedirection?.let { getRedirectionAppType(it) },
        orderItem = orderItem ?: "0",
        redirectionTypeEnum = mapToRedirectionType(redirectionTypeEnum),
        redirectionPath = if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage())redirectionArPath else redirectionPath,
        title = title ?: "",
        titleArabic = titleArabic ?: "",
        fileUrl = fileUrl,
        id = id,
        redirection = redirection ?: false,
        titleDisplayed = titleDisplayed ?: false

    )

}

fun mapToRedirectionType(redirectionTypeEnum: String?): HomeBannerRedirectionType? {
    redirectionTypeEnum?.let {
        return when (it) {
            HomeBannerRedirectionType.APP.name -> HomeBannerRedirectionType.APP
            HomeBannerRedirectionType.URL.name -> HomeBannerRedirectionType.URL
            else -> null
        }
    } ?: return null
}