package com.woqod.app.data

import com.woqod.shared.commundata.BASE_API_ADAPTER_URL


const val GET_FAHES_STATIONS_URL = "$BASE_API_ADAPTER_URL/fahesStations"
const val GET_PETROL_STATIONS_URL = "$BASE_API_ADAPTER_URL/stations"
const val POST_RATING_STATIONS_URL = "$BASE_API_ADAPTER_URL/feedback/addRating"
const val GET_SUPER_MARKETS_URL = "$BASE_API_ADAPTER_URL/supermarket"
const val GET_FUEL_PRICES_URL = "$BASE_API_ADAPTER_URL/petrol/prices"
const val GET_PROMOTIONS_URL = "$BASE_API_ADAPTER_URL/promotions"
const val GET_CONTRACTORS_URL = "$BASE_API_ADAPTER_URL/contractors"

const val PUT_BIO_URL = "$BASE_API_ADAPTER_URL/updateBioPin"

const val GET_SURVEY_STATUS_URL = "$BASE_API_ADAPTER_URL/surveys/getSurveyStatus"
const val POST_SURVEY_STATUS_URL = "$BASE_API_ADAPTER_URL/surveys/changeStatus"
const val GET_WOQOD_TENDERS_URL = "$BASE_API_ADAPTER_URL/tenders/tenders"

const val GET_LIST_NOTIFICATIONS_BY_USERNAME_URL = "$BASE_API_ADAPTER_URL/notification/listByUsername"
const val GET_LIST_NOTIFICATIONS_ANONYMOUS = "$BASE_API_ADAPTER_URL/notification/anonymous"
const val PUT_UPDATE_NOTIFICATION_URL = "$BASE_API_ADAPTER_URL/notification/updateStatus"
const val PUT_UPDATE_ALL_NOTIFICATIONS_URL = "$BASE_API_ADAPTER_URL/notification/updateAll"

const val POST_SURVEY_RESPONSE_URL = "$BASE_API_ADAPTER_URL/surveys/surveysResponses"


const val GET_NEWS_LIST_URL = "$BASE_API_ADAPTER_URL/news"
const val GET_NEWS_BY_ID_URL ="$BASE_API_ADAPTER_URL/news/view/"

const val GET_HOME_TOP_BANNER_URL = "$BASE_API_ADAPTER_URL/home/topbanner"
const val GET_HOME_ADS_URL = "$BASE_API_ADAPTER_URL/home/adsbanner"
const val GET_HOME_BUSINESS_URL = "$BASE_API_ADAPTER_URL/home/businessbanner"

const val GET_APP_TIPS_URL = "$BASE_API_ADAPTER_URL/home/apptips"
const val GET_STOCK_PRICES = "$BASE_API_ADAPTER_URL/stockPrices"
const val GET_HAS_NOTIF = "$BASE_API_ADAPTER_URL/hasNotif"
const val POST_LOGOUT = "$BASE_API_ADAPTER_URL/logout"