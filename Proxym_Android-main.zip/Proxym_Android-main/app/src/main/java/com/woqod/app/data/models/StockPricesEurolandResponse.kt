package com.woqod.app.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.app.domain.models.StockPricesModel
import com.woqod.shared.commundata.DomainMapper


data class StockPricesEurolandResponse(
    @SerializedName("Qatar Fuel") var qatarFuel: QatarFuel? = QatarFuel()
) : DomainMapper<StockPricesModel> {
    override fun mapToDomainModel()  = StockPricesModel(
        id = 0,
        dateString = qatarFuel?.date,
        symbol = qatarFuel?.symbol?:"",
        change = qatarFuel?.change?:"",
        lastPrice = qatarFuel?.last?:"",
        open = qatarFuel?.open?:"",
        high = qatarFuel?.high?:"",
        low = qatarFuel?.low?:"",
        volume = qatarFuel?.volume?:"",
        previousClose = qatarFuel?.previousClose?:"",
        changePercent = qatarFuel?.changePercent?:""
    )
}

data class QatarFuel(

    @SerializedName("Currency") var currency: String? = null,
    @SerializedName("Bid") var bid: String? = null,
    @SerializedName("Ask") var ask: String? = null,
    @SerializedName("Change") var change: String? = null,
    @SerializedName("ChangePercent") var changePercent: String? = null,
    @SerializedName("Last") var last: String? = null,
    @SerializedName("High") var high: String? = null,
    @SerializedName("Low") var low: String? = null,
    @SerializedName("Volume") var volume: String? = null,
    @SerializedName("PreviousClose") var previousClose: String? = null,
    @SerializedName("Date") var date: String? = null,
    @SerializedName("ISIN") var iSIN: String? = null,
    @SerializedName("Symbol") var symbol: String? = null,
    @SerializedName("MarketName") var marketName: String? = null,
    @SerializedName("NoShares") var noShares: String? = null,
    @SerializedName("MarketCap") var marketCap: String? = null,
    @SerializedName("Open") var open: String? = null
)