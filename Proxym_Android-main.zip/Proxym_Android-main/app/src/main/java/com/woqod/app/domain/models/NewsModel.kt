package com.woqod.app.domain.models

import java.io.Serializable

data class NewsModel(
    val detailsPicture: String?,
    val link: String?,
    val listPicture: String?,
    val active: Boolean,
    val details: String,
    val detailsArabic: String,
    val id: Long,
    val title: String,
    val titleArabic: String,
    val creationDate: Long?,
    val views: Int?
) : Serializable
