package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.AppTipsModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetAppTipsUseCase @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCaseWithRequest<String,WoqodResult<SharedResponse<List<AppTipsModel>>>> {

    override suspend operator fun invoke(device : String) =
        appRepository.getAppTips(device)

}