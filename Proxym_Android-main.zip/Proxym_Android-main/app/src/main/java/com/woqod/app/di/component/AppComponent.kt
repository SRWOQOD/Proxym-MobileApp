package com.woqod.app.di.component

import com.woqod.app.di.module.RepositoriesModule
import com.woqod.app.di.module.ViewModelModule
import com.woqod.app.di.scope.AppScope
import com.woqod.app.presentation.applicationTips.ApplicationTipsFragment
import com.woqod.app.presentation.biometric.BiometricFragment
import com.woqod.app.presentation.bulk_lpg.BulkLpgFragment
import com.woqod.app.presentation.fuel_prices.FuelPricesFragment
import com.woqod.app.presentation.home.HomeFragment
import com.woqod.app.presentation.locations.LocationsFragment
import com.woqod.app.presentation.locations.map_filter.MapFilterFragment
import com.woqod.app.presentation.menu.MenuActivity
import com.woqod.app.presentation.news.NewsFragment
import com.woqod.app.presentation.news.NewsFragmentDetails
import com.woqod.app.presentation.notifications.BONotificationFragment
import com.woqod.app.presentation.notifications.NotificationsFragment
import com.woqod.app.presentation.notifications.survey.NotificationSurveyFragment
import com.woqod.app.presentation.otp.OtpFragment
import com.woqod.app.presentation.promotions.PromotionsFragment
import com.woqod.app.presentation.promotions.PromotionsFragmentDetails
import com.woqod.app.presentation.settings.SettingsFragment
import com.woqod.app.presentation.splash.SplashFragment
import com.woqod.app.presentation.static_screens.AboutWoqodFragment
import com.woqod.app.presentation.static_screens.PrivacyPolicyFragment
import com.woqod.app.presentation.static_screens.TermsOfUseFragment
import com.woqod.app.presentation.static_screens.contact_Us.ContactUsFragment
import com.woqod.app.presentation.stock_prices.StockPricesFragment
import com.woqod.app.presentation.tenders.TendersDetailsFragment
import com.woqod.app.presentation.tenders.TendersFragment
import com.woqod.shared.WoqodApplication
import com.woqod.shared.di.component.SharedComponent
import dagger.Component


@AppScope
@Component(
    modules = [ViewModelModule::class, RepositoriesModule::class],
    dependencies = [SharedComponent::class]
)
interface AppComponent {

    fun inject(splashFragment: SplashFragment)
    fun inject(menuActivity: MenuActivity)
    fun inject(fuelPricesActivity: FuelPricesFragment)
    fun inject(otpFragment: OtpFragment)
    fun inject(setBiometricFragment: BiometricFragment)
    fun inject(locationsFragment: LocationsFragment)
    fun inject(homeFragment: HomeFragment)
    fun inject(settingsFragment: SettingsFragment)
    fun inject(promotionsFragment: PromotionsFragment)
    fun inject(promotionsFragmentDetails: PromotionsFragmentDetails)
    fun inject(bulkLpgFragment: BulkLpgFragment)
    fun inject(mapFilterFragment: MapFilterFragment)
    fun inject(notificationsFragment: NotificationsFragment)
    fun inject(notificationSurveyFragment: NotificationSurveyFragment)
    fun inject(boNotificationFragment: BONotificationFragment)
    fun inject(tendersFragment: TendersFragment)
    fun inject(tendersDetailsFragment: TendersDetailsFragment)
    fun inject(newsFragment: NewsFragment)
    fun inject(newsFragment: NewsFragmentDetails)
    fun inject(privacyPolicyFragment: PrivacyPolicyFragment)
    fun inject(termsOfUseFragment: TermsOfUseFragment)
    fun inject(aboutWoqodFragment: AboutWoqodFragment)
    fun inject(contactUsFragment: ContactUsFragment)
    fun inject(stockPricesFragment: StockPricesFragment)
    fun inject(applicationTips: ApplicationTipsFragment)


    @Component.Factory
    interface AppComponentFactory {
        fun create(sharedComponent: SharedComponent): AppComponent
    }

}


object GetAppComponent {

    @Volatile
    private var INSTANCE: AppComponent? = null

    fun getInstance(): AppComponent =
        INSTANCE ?: synchronized(this) {
            INSTANCE ?: DaggerAppComponent.factory().create(WoqodApplication.sharedComponent)
                .also { INSTANCE = it }
        }
}
