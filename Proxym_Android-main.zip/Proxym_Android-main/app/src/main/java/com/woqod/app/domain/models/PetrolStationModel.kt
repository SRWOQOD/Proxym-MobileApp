package com.woqod.app.domain.models

import android.util.Log
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.utils.ServiceStationType
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by Hamdi.BOUMAIZA on 07/03/2020
 */
data class PetrolStationModel(
    val area: AreaModel?,
    val rating: Int,
    val facilityStations: List<String>,
    val serviceStations: List<ServiceStationModel>,
    val category: String,
    val stationId: Int,
    val status: PetrolStationStatus
)


data class ServiceStationModel(
    val name: String,
    val openingHour: String,
    val closingHour: String,
    val state: String,
    val status: String,
    val type: ServiceStationType,
    val id: Int
) {
    private val TAG = "ServiceStationModel"

    companion object {
        const val FORMAT_TWELVE = "hh:mm a"
        const val FORMAT_TWENTY_FOUR = "HH:mm"
    }

    fun isOpeningHourValid(): Boolean {
        return openingHour != "0"
    }

    fun convertTimeFormat(isClosing :Boolean = false): Int {
        val time = if ( isClosing) closingHour else openingHour
        val date12Format = SimpleDateFormat(FORMAT_TWELVE, Locale.US)
        val date24Format = SimpleDateFormat(FORMAT_TWENTY_FOUR, Locale.US)
        var hours = 0
        try {
            hours = date24Format.format(date12Format.parse(time.replace(".", ":"))!!).split(":")[0].toInt()
        } catch (e: ParseException) {
            Log.d(TAG, "convertTimeFormat: $time")
        }
        return if (hours == 12) {
            return 0
        } else {
            hours
        }
    }
}

enum class PetrolStationStatus(val value: String) {
    Active("Active"),
    Under_Construction("Under_Construction"),
    Inactive("Inactive"),
    Upcoming("Upcoming"),
    Opening_Soon("Opening_Soon");
}

