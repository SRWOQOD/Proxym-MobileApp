package com.woqod.app.presentation.tenders

import com.woqod.app.domain.models.TendersModel

interface TendersItemClickListener {
    fun onDetailsItemClicked(item: TendersModel)
}