package com.woqod.app.presentation.notifications.survey

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.ItemSurveyDropDownBinding
import com.woqod.app.databinding.ItemSurveyQuestionBinding
import com.woqod.app.databinding.ItemSurveyRangeQuestionBinding
import com.woqod.app.databinding.ItemSurveyTextBinding
import com.woqod.shared.commundomain.models.NotificationSurveyChoicesModel
import com.woqod.shared.commundomain.models.NotificationSurveyModel
import com.woqod.shared.commundomain.models.SurveyTypes
import java.util.*


class SurveyQuestionAdapter(
    private val listResponse: List<NotificationSurveyModel>,
    private val context: Activity
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var surveyResponsesAdapter: SurveyResponsesAdapter? = null

    override fun getItemCount() = listResponse.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        when (viewType) {
            SurveyTypes.MULTIPLE_CHOICE.ordinal, SurveyTypes.SINGLE_CHOICE.ordinal, SurveyTypes.RADIO_BUTTON.ordinal ->
                MultipleSingleChoiceSurveyHolder(
                    ItemSurveyQuestionBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                )
            SurveyTypes.RANGE.ordinal -> RangeSurveyHolder(
                ItemSurveyRangeQuestionBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )

            SurveyTypes.DROPDOWN_LIST.ordinal -> DropDownSurveyHolder(
                ItemSurveyDropDownBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
            SurveyTypes.TEXT.ordinal -> TextSurveyHolder(
                ItemSurveyTextBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )

            else -> throw IllegalStateException("Unknown viewType $viewType")
        }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) =
        when (holder) {
            is MultipleSingleChoiceSurveyHolder -> holder.bindViewHolder(listResponse[position])
            is RangeSurveyHolder -> holder.bindViewHolder(listResponse[position], position)
            is DropDownSurveyHolder -> holder.bindViewHolder(listResponse[position], position)
            is TextSurveyHolder -> holder.bindViewHolder(listResponse[position], position)
            else -> (holder as MultipleSingleChoiceSurveyHolder).bindViewHolder(listResponse[position])
        }


    override fun getItemViewType(position: Int): Int {
        return listResponse[position].typeQuestion.ordinal
    }

    inner class MultipleSingleChoiceSurveyHolder(view: ItemSurveyQuestionBinding) :
        RecyclerView.ViewHolder(view.root) {
        private val question = view.tvSurveyQuestion
        private val rvAnswers = view.rvSurveyResponses

        fun bindViewHolder(questionItem: NotificationSurveyModel) {
            question.text = questionItem.getQuestionTitle()
            surveyResponsesAdapter =
                SurveyResponsesAdapter(questionItem.options, questionItem.typeQuestion)
            rvAnswers.adapter = surveyResponsesAdapter
        }


    }

    inner class RangeSurveyHolder(view: ItemSurveyRangeQuestionBinding) :
        RecyclerView.ViewHolder(view.root) {
        private val question = view.tvSurveyQuestion
        private val rangeAnswer = view.rangeAnswer
        private val minValue = view.tvMinValue
        private val maxValue = view.tvMaxValue
        fun bindViewHolder(questionItem: NotificationSurveyModel, position: Int) {

            with(rangeAnswer) {
                setLabelFormatter {
                    String.format(
                        Locale.ENGLISH,
                        context.getString(R.string.CommonDecimal),
                        it.toInt()
                    )
                }
                addOnChangeListener { _, value, _ ->
                    listResponse[position].options.apply {
                        clear()
                        add(
                            NotificationSurveyChoicesModel(
                                value.toInt().toString(),
                                isChoiceChecked = true
                            )
                        )
                    }
                }
                valueFrom = value
                valueTo = questionItem.max.toFloat()
            }

            question.text = questionItem.getQuestionTitle()
            minValue.text = "${questionItem.min}"
            maxValue.text = "${questionItem.max}"

        }

    }

    inner class DropDownSurveyHolder(view: ItemSurveyDropDownBinding) :
        RecyclerView.ViewHolder(view.root) {
        private val question = view.tvSurveyQuestion
        private val dropDownChoices = view.spinnerChoices
        fun bindViewHolder(questionItem: NotificationSurveyModel, position: Int) {
            question.text = questionItem.getQuestionTitle()
            val response = listResponse[position].options.map { it.response }
            dropDownChoices.initSpinner(context, response) {
                listResponse[position].options[response.indexOf(it)].isChoiceChecked = true
            }
        }

    }


    inner class TextSurveyHolder(view: ItemSurveyTextBinding) : RecyclerView.ViewHolder(view.root) {
        private val question = view.tvSurveyQuestion
        private val questionResponse = view.etTextAnswer
        fun bindViewHolder(questionItem: NotificationSurveyModel, position: Int) {
            question.text = questionItem.getQuestionTitle()
            with(questionResponse) {

                setComponentMinHeight(220)
                setMaxInputLength(questionItem.textLimit)
                handleSurveyTextType {
                    listResponse[position].options.apply {
                        clear()
                        if (it.isNotBlank())
                            add(
                                NotificationSurveyChoicesModel(
                                    it,
                                    isChoiceChecked = true
                                )
                            )
                    }

                }
            }
        }

    }
}