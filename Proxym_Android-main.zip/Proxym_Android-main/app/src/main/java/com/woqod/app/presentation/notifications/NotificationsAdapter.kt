package com.woqod.app.presentation.notifications

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.ItemNotificationBinding
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.NotificationTypes
import com.woqod.shared.commundomain.models.NotificationsModel


class NotificationsAdapter(
    private var list: MutableList<NotificationsModel>,
    private val onItemClick: (NotificationsModel) -> Unit
) : RecyclerView.Adapter<NotificationsAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemNotificationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    fun addItems(newList: List<NotificationsModel>) {
        list.addAll(newList.sortedByDescending { it.sendDate })
        list = list.sortedByDescending { it.sendDate }.toMutableList()
        notifyDataSetChanged()
    }

    fun resetList() {
        this.list.clear()
        notifyDataSetChanged()
    }

    inner class ViewHolder(item: ItemNotificationBinding) : RecyclerView.ViewHolder(item.root) {
        private val container = item.constraintLayoutNotification
        private val title = item.tvNotificationTitle
        private val imageNewNotification = item.ivNotificationNew
        private val description = item.tvNotificationDescription
        private val time = item.tvNotificationDate

        fun bindTo(notification: NotificationsModel) {
            with(container) {
                if (!notification.status) {
                    title.textColor(R.color.color_009933)
                    imageNewNotification.show()
                    container.background = itemView.context.loadDrawable(R.drawable.bg_notification_new)
                } else {
                    title.textColor(R.color.color_002280)
                    imageNewNotification.hide()
                    container.background = itemView.context.loadDrawable(R.drawable.bg_notification_read)
                }
                when (notification.type) {
                    NotificationTypes.SURVEY.name -> {
                        title.text =
                            notification.surveysResource.getTitle()
                        setItemDescription(notification.surveysResource.getDescription())
                    }
                    else -> {
                        title.text = notification.getTitle().textInHtml()
                        setItemDescription(notification.getDescription())
                    }
                }
                setOnClickListener { onItemClick(notification) }
                time.text = notification.sendDate.toFormattedDateQatar(NOTIFICATION_DATE_FORMAT)
            }
        }

        private fun setItemDescription(description:String) {
             if(description.isNullOrEmpty()) {
                 this.description.hide()
             }
            this.description.text = description.textInHtml()
        }
    }

}