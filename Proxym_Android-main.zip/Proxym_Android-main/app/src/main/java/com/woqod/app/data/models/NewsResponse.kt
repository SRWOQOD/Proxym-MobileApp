package com.woqod.app.data.models

import com.woqod.app.domain.models.NewsModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class NewsResponse(
    val detailsPicture: String?,
    val link: String?,
    val linkAr: String?,
    val listPicture: String?,
    val active: Boolean?,
    val details: String?,
    val detailsArabic: String?,
    val id: Long?,
    val title: String?,
    val titleArabic: String?,
    val creationDate: Long?,
    val views: Int?
) : DomainMapper<NewsModel> {
    override fun mapToDomainModel() = NewsModel(
        detailsPicture,
        link= if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage())linkAr else link,
        listPicture,
        active ?: false,
        details ?: "",
        detailsArabic = detailsArabic ?: "",
        id?:0,
        title ?: "",
        titleArabic ?: "",
        creationDate,
        views
    )
}

