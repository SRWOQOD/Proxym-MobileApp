package com.woqod.app.presentation.tenders


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.TendersModel
import com.woqod.app.domain.usecases.GetWoqodTendersUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commun.extensions.afterOrEqual
import com.woqod.shared.commun.extensions.beforeOrEqual
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class TendersViewModel @Inject constructor(
    private val getWoqodTendersUseCase: GetWoqodTendersUseCase
) : BaseViewModel() {

    private var _currentPage = 0
    val currentPage: Int
        get() = _currentPage

    private var _pagesNumber = 1

    val isLastPage: Boolean
        get() = (_pagesNumber - 1) - _currentPage < 0

    val sizePerPage: Int
        get() = 10
    var isFetchedOnce = false


    fun resetPagingProperties() {
        _currentPage = 0
        _pagesNumber = 1
    }

    suspend fun filterByDate(startDate: Date?, endDate: Date?, tendersList: List<TendersModel>, filterIsActive: Boolean): List<TendersModel> =
    suspendCoroutine {
            sc ->
        if ( filterIsActive && (startDate != null || endDate != null) ) {
        val arrayFiltered: ArrayList<TendersModel> = ArrayList()
        tendersList.forEach {  item ->
            item.collectionDate?.let {
                when {
                    (startDate != null) && (endDate != null) && Date(item.collectionDate).after(startDate) && Date(item.collectionDate).before(endDate) -> {
                        arrayFiltered.add(item)
                        }
                    (startDate != null) && (endDate == null) && (Date(item.collectionDate).afterOrEqual(startDate)) -> {
                        arrayFiltered.add(item)
                        }
                    (endDate != null) && (startDate == null) && (Date(item.collectionDate).beforeOrEqual(endDate)) -> {
                            arrayFiltered.add(item)
                        }
                    }
                }
            }
            sc.resume(arrayFiltered)
        } else {
            sc.resume(tendersList)
        }

    }


    suspend fun filterByBond(minBond: String, maxBond: String, list: List<TendersModel>, filterIsActive: Boolean): List<TendersModel> =
        suspendCoroutine {
                sc ->
        if ( filterIsActive && (maxBond.isNotEmpty()) || (minBond.isNotEmpty())) {
            val arrayFiltered: ArrayList<TendersModel> = ArrayList()
            list.forEach { item ->
                item.bond?.toInt()?.let {
                when {
                        maxBond.isNotEmpty() && minBond.isNotEmpty() && item.bond.toInt() in minBond.toInt() .. maxBond.toInt() -> {
                            arrayFiltered.add(item)
                        }
                        minBond.isNotEmpty() && maxBond.isEmpty() && item.bond.toInt() >= minBond.toInt() -> {
                            arrayFiltered.add(item)
                        }
                        maxBond.isNotEmpty() && minBond.isEmpty() && item.bond.toInt() <= maxBond.toInt() -> {
                            arrayFiltered.add(item)
                        }
                    }
                }
            }
            sc.resume(arrayFiltered)
        } else {
            sc.resume(list)
        }
    }

    private val _resultGetTenders = SingleLiveEvent<ResultUseCase<SharedBody<List<TendersModel>>?, String?>>()
    val resultGetTenders: LiveData<ResultUseCase<SharedBody<List<TendersModel>>?, String?>> = _resultGetTenders

    fun getWoqodTenders(request: HashMap<String, Any>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            getWoqodTendersUseCase(request)
                .onSuccess {
                    showLoadingToggle(false)
                    _pagesNumber = it.body.count
                    _currentPage += 1
                    _resultGetTenders.postValue(ResultUseCase(it.body, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultGetTenders.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

}