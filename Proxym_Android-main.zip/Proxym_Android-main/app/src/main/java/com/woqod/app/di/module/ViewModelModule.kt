package com.woqod.app.di.module

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.woqod.app.presentation.applicationTips.ApplicationTipsViewModel
import com.woqod.app.presentation.biometric.BiometricViewModel
import com.woqod.app.presentation.bulk_lpg.BulkLpgViewModel
import com.woqod.app.presentation.fuel_prices.FuelPricesViewModel
import com.woqod.app.presentation.home.HomeViewModel
import com.woqod.app.presentation.locations.LocationsViewModel
import com.woqod.app.presentation.locations.map_filter.MapFilterViewModel
import com.woqod.app.presentation.menu.MainViewModel
import com.woqod.app.presentation.news.NewsViewModel
import com.woqod.app.presentation.notifications.NotificationsViewModel
import com.woqod.app.presentation.otp.OtpViewModel
import com.woqod.app.presentation.promotions.PromotionsViewModel
import com.woqod.app.presentation.settings.SettingsViewModel
import com.woqod.app.presentation.splash.SplashViewModel
import com.woqod.app.presentation.static_screens.StaticScreenViewModel
import com.woqod.app.presentation.static_screens.contact_Us.ContactUsViewModel
import com.woqod.app.presentation.stock_prices.StockPricesViewModel
import com.woqod.app.presentation.tenders.TendersViewModel
import com.woqod.shared.di.annotations.ViewModelKey
import com.woqod.shared.di.viewmodels.DaggerViewModelFactory
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap


@Module
@Suppress("UNUSED")
abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(MainViewModel::class)
    abstract fun bindMenuVM(menuViewModel: MainViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(OtpViewModel::class)
    abstract fun bindOtpVM(otpViewModel: OtpViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(BiometricViewModel::class)
    abstract fun bindBiometricVM(biometricViewModel: BiometricViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(FuelPricesViewModel::class)
    abstract fun bindFuelPricesVM(fuelPricesViewModel: FuelPricesViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(LocationsViewModel::class)
    abstract fun bindLocationVM(locationsViewModel: LocationsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(HomeViewModel::class)
    abstract fun bindHomeVM(homeViewModel: HomeViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(SettingsViewModel::class)
    abstract fun bindSettingsVM(settingsViewModel: SettingsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(PromotionsViewModel::class)
    abstract fun bindPromotionsVM(promotionsViewModel: PromotionsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(BulkLpgViewModel::class)
    abstract fun bindBulkLpgVM(bulkLpgViewModel: BulkLpgViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(MapFilterViewModel::class)
    abstract fun bindMapFilterVM(mapFilterViewModel: MapFilterViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(StaticScreenViewModel::class)
    abstract fun bindAboutWoqodVM(satiticScreenViewModel: StaticScreenViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(ContactUsViewModel::class)
    abstract fun bindContactUsVM(contactUsViewModel: ContactUsViewModel): ViewModel



    @Binds
    @IntoMap
    @ViewModelKey(NotificationsViewModel::class)
    abstract fun bindNotificationsVM(notificationsViewModel: NotificationsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(TendersViewModel::class)
    abstract fun bindTendersVM(tendersViewModel: TendersViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(NewsViewModel::class)
    abstract fun bindNewsVM(newsViewModel: NewsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(ApplicationTipsViewModel::class)
    abstract fun bindApplicationTipsVM(applicationTipsViewModel: ApplicationTipsViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(SplashViewModel::class)
    abstract fun bindSplashVM(splashViewModel: SplashViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(StockPricesViewModel::class)
    abstract fun bindStockPricesVM(stockPricesViewModel: StockPricesViewModel): ViewModel

    @Binds
    abstract fun bindViewModelFactory(factory: DaggerViewModelFactory): ViewModelProvider.Factory
}