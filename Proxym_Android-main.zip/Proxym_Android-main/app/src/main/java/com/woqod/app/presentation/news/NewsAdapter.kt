package com.woqod.app.presentation.news

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemNewsArticleBinding
import com.woqod.app.domain.models.NewsModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.extensions.BIRTH_DATE_FORMAT
import com.woqod.shared.commun.extensions.formatStringHtml
import com.woqod.shared.commun.extensions.load
import com.woqod.shared.commun.extensions.toFormattedDate
import com.woqod.shared.databinding.LayoutPagingLoadingBinding

const val VIEW_TYPE_LOADING = 1
const val VIEW_TYPE_ITEM = 0

class NewsAdapter(
    private var newsList: MutableList<NewsModel?>,
    private val action: (newsItem: NewsModel?) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    fun updateList(news: List<NewsModel>) {
        this.newsList.addAll(news)
        notifyDataSetChanged()
    }

    fun resetList() {
        this.newsList.clear()
        // notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
        NewsViewHolder(
            ItemNewsArticleBinding.inflate(
                LayoutInflater.from(
                    parent.context
                ), parent, false
            )
        )


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is NewsViewHolder -> holder.bind(newsList[position])
        }
    }

    override fun getItemCount() = newsList.size

    override fun getItemViewType(position: Int): Int =
        if (newsList[position] == null) VIEW_TYPE_LOADING else VIEW_TYPE_ITEM


    inner class LoadingViewHolder(view: LayoutPagingLoadingBinding) :
        RecyclerView.ViewHolder(view.root)

    inner class NewsViewHolder(private val view: ItemNewsArticleBinding) :
        RecyclerView.ViewHolder(view.root) {

        private val shimmer: ShimmerFrameLayout = view.shimmerItemNews
        private val tvError: TextView = view.tvNewsItemError
        private val ivPlaceHolder: ImageView = view.ivPlaceholder
        fun bind(newsItem: NewsModel?) {

            view.apply {

                root.setOnClickListener { action(newsItem) }
                newsItem?.listPicture?.let {
                    shimmer.load(
                        ivNewsItem,
                        it,
                        tvError,
                        ivPlaceHolder
                    )
                } ?: run {
                    ivNewsItem.load(
                        R.drawable.ic_placeholder
                    ) {
                        transformations(coil.transform.RoundedCornersTransformation(33F))
                    }
                }
                tvItemNewsDate.text = newsItem?.creationDate?.toFormattedDate(BIRTH_DATE_FORMAT)
                tvNewsItemTitle.text = if (WoqodApplication.sharedComponent.injectLanguageUtils()
                        .isArabicLanguage()
                ) newsItem?.titleArabic else newsItem?.title

                tvNewItemDesc.formatStringHtml(
                    if (WoqodApplication.sharedComponent.injectLanguageUtils()
                            .isArabicLanguage()
                    ) newsItem?.detailsArabic else newsItem?.details
                )
            }
        }
    }
}
