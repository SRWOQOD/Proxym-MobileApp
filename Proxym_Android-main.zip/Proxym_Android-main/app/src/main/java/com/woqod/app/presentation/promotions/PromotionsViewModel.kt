package com.woqod.app.presentation.promotions


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.PromotionsModel
import com.woqod.app.domain.usecases.GetPromotionsUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class PromotionsViewModel @Inject constructor(
    private val getPromotionsUseCase: GetPromotionsUseCase
) : BaseViewModel() {

    private val _onGetPromotions = SingleLiveEvent<ResultUseCase<List<PromotionsModel>?, String?>>()
    val onGetPromotions: LiveData<ResultUseCase<List<PromotionsModel>?, String?>> get() = _onGetPromotions

    fun getPromotions() {
        viewModelScope.launch {
            _onGetPromotions.postValue(executeUseCase(getPromotionsUseCase))
        }
    }
}