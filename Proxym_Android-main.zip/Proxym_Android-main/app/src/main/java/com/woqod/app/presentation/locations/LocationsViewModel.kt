package com.woqod.app.presentation.locations


import android.content.Context
import android.location.Location
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import coil.imageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.google.android.gms.maps.model.LatLng
import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.models.MapTypeStation
import com.woqod.app.domain.models.ServiceStationModel
import com.woqod.app.domain.usecases.GetFahesStationsUseCase
import com.woqod.app.domain.usecases.GetPetrolStationsUseCase
import com.woqod.app.domain.usecases.GetSuperMarketsUseCase
import com.woqod.app.domain.usecases.PostRatingStationsUseCase
import com.woqod.app.presentation.locations.map_cluster.MarkerCluster
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.getError
import com.woqod.shared.commundomain.models.MapFilterModel
import com.woqod.shared.commundomain.onError
import com.woqod.shared.commundomain.onSuccess
import com.woqod.shared.utils.ServiceStationType
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


class LocationsViewModel @Inject constructor(
    private val getFahesStationsUseCase: GetFahesStationsUseCase,
    private val getSuperMarketsUseCase: GetSuperMarketsUseCase,
    private val getPetrolStationsUseCase: GetPetrolStationsUseCase,
    private val postRatingStationsUseCase: PostRatingStationsUseCase,
) :
    BaseViewModel() {

    private var filter: MapFilterModel = MapFilterModel()

    private val _resultPostRatingStation =
        SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultPostRatingStation: LiveData<ResultUseCase<Boolean?, String?>> =
        _resultPostRatingStation

    private val _resultListFahesStation =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListFahesStation: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListFahesStation

    private val _resultListPetrolStations =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListPetrolStation: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListPetrolStations
    private val _resultListMobilePertolStations =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListMobilePertolStations: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListMobilePertolStations

    private val _resultListMarineStations =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListMarineStations: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListMarineStations

    private val _resultListSidraStations =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListSidraStation: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListSidraStations

    private val _resultListSuperMarkets =
        SingleLiveEvent<ResultUseCase<List<MapStationModel>?, String?>>()
    val resultListSuperMarkets: LiveData<ResultUseCase<List<MapStationModel>?, String?>> =
        _resultListSuperMarkets

    fun setMapFilter(filterMap: MapFilterModel) {
        filter = filterMap
    }

    fun getFahesStations() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getFahesStationsUseCase()
                .onSuccess {
                    _resultListFahesStation.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListFahesStation.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun postRatingStations(request: HashMap<String, Any>) {
        viewModelScope.launch {
            showLoadingToggle(true)
            postRatingStationsUseCase(request)
                .onSuccess {
                    showLoadingToggle(false)
                    _resultPostRatingStation.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultPostRatingStation.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun getPetrolStations() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getPetrolStationsUseCase()
                .onSuccess {
                    _resultListPetrolStations.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListPetrolStations.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun getSidraStandelonesStations() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getPetrolStationsUseCase()
                .onSuccess {
                    _resultListSidraStations.postValue(
                        ResultUseCase(
                            it.body.result.filter { station -> station.type == MapTypeStation.SIDRA_STATION },
                            null
                        )
                    )
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListSidraStations.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun getMobilePertolStations() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getPetrolStationsUseCase()
                .onSuccess {
                    _resultListMobilePertolStations.postValue(
                        ResultUseCase(
                            it.body.result.filter { station -> station.type == MapTypeStation.MOBILE_PETROL_STATION },
                            null
                        )
                    )
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListMobilePertolStations.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    fun getMarineStations() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getPetrolStationsUseCase()
                .onSuccess {
                    _resultListMarineStations.postValue(
                        ResultUseCase(
                            it.body.result.filter { station -> station.type == MapTypeStation.MARINE_STATION },
                            null
                        )
                    )
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListMarineStations.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }


    fun getSuperMarkets() {
        viewModelScope.launch {
            showLoadingToggle(true)
            getSuperMarketsUseCase()
                .onSuccess {
                    _resultListSuperMarkets.postValue(ResultUseCase(it.body.result, null))
                }
                .onError {
                    showLoadingToggle(false)
                    _resultListSuperMarkets.postValue(ResultUseCase(null, it.getError()))
                }
        }
    }

    suspend fun filterStationsBySearch(stations: List<MapStationModel>): List<MapStationModel>? =
        suspendCoroutine { sc ->
            val filteredStations = ArrayList<MapStationModel>()
            if (filter.searchName.isNotEmpty()) {
                stations.forEach {
                    if ((it.title.toLowerCase(Locale.ROOT)
                            .contains(filter.searchName.toLowerCase(Locale.ROOT)))
                    ) {
                        filteredStations.add(it)
                    }

                }
            }
            sc.resume(filteredStations)
        }

    /**
     * filter by given distance in MapFilterFragment
     */
    suspend fun filterStationByDistance(
        list: List<MapStationModel>,
        currentLocation: Location?,
        errorAction: () -> Unit
    ): ArrayList<MapStationModel> = suspendCoroutine { sc ->
        var filteredPetrolStation = ArrayList<MapStationModel>()
        currentLocation?.let {
            if (filter.isRangeEmpty()) {
                list.forEach {
                    val distance = getDistance(it, currentLocation)
                    if (distance < filter.range) {
                        filteredPetrolStation.add(it)
                    }
                }
            } else {
                filteredPetrolStation = ArrayList(list)
            }
            sc.resume(ArrayList(filteredPetrolStation.distinct().toMutableList()))
        } ?: kotlin.run {
            errorAction()
            sc.resume(ArrayList(list.distinct().toMutableList()))
        }
    }

    suspend fun filterServicesByOpeningTime(
        filteredPetrolStations: ArrayList<MapStationModel>,
        selectedServices: List<ServiceStationType>?,
    ): ArrayList<MapStationModel> = suspendCoroutine { sc ->
        val filteredByOpeningTime = mutableSetOf<MapStationModel>()
        if (filter.isOpeningHourSelected()) {
            filteredPetrolStations.forEach { station ->
                station.petrolStationModel?.serviceStations?.forEach { service ->
                    val selectedservicesName = ArrayList<String>()
                    selectedServices?.forEach { selectedservicesName.add(it.name) }
                    if (service.name in selectedservicesName) {
                        Log.d("time opening", service.convertTimeFormat().toString())
                        Log.d(
                            "time closing",
                            service.convertTimeFormat(isClosing = true).toString()
                        )
                        Log.d("time filter", filter.openingHour.toString())
                        validateOpeningTIme(service, filteredByOpeningTime, station)
                    }
                }
            }
        }
        if (filter.openingHour == -1) {
            sc.resume(filteredPetrolStations)
        } else
            sc.resume(ArrayList(filteredByOpeningTime))
    }

    private fun validateOpeningTIme(
        service: ServiceStationModel,
        filteredByOpeningTime: MutableSet<MapStationModel>,
        station: MapStationModel
    ) {
        when {
            service.isOpeningHourValid() && (service.convertTimeFormat() <= filter.openingHour) && (service.convertTimeFormat(
                isClosing = true
            ) >= filter.openingHour) -> {
                filteredByOpeningTime.add(station)
            }
        }
    }


    suspend fun filterPetrolStationByServices(filteredPetrolStations: ArrayList<MapStationModel>): ArrayList<MapStationModel> =
        suspendCoroutine { sc ->
            val filteredSet = mutableSetOf<MapStationModel>()
            if (filter.services.isNotEmpty()) {
                filteredPetrolStations.forEach { station ->
                    station.petrolStationModel?.serviceStations?.forEach { service ->
                        if (filterServiceByName(filter.services, service.type)) {
                            filteredSet.add(station)
                        }
                    }
                }

                sc.resume(ArrayList(filteredSet))
            } else {
                sc.resume(filteredPetrolStations)
            }
        }

    suspend fun filterByArea(
        list: List<MapStationModel>,
        isFahes: Boolean,
        isShafaf: Boolean = false
    ): ArrayList<MapStationModel> = suspendCoroutine { sc ->
        val filteredByArea = mutableSetOf<MapStationModel>()
        filter.zone?.let {
            list.forEach { station ->
                getFiltredAreaList(filteredByArea, it.idArea, station, isFahes, isShafaf)
            }


            sc.resume(ArrayList(filteredByArea.distinct()))
        } ?: run {
            sc.resume(ArrayList(list.distinct()))
        }

    }

    private fun getFiltredAreaList(
        list: MutableSet<MapStationModel>,
        areaid: String,
        station: MapStationModel,
        isFahes: Boolean,
        isShafaf: Boolean
    ) {
        if (getStationAreaId(station, isFahes, isShafaf) == areaid) {
            list.add(station)
        }
    }

    private fun getStationAreaId(
        station: MapStationModel,
        isFahes: Boolean,
        isShafaf: Boolean
    ): String? {
        return when {
            isFahes -> station.fahesStationModel?.area?.idArea
            isShafaf -> station.superMarketModel?.area?.idArea
            else -> station.petrolStationModel?.area?.idArea
        }
    }


    private fun filterServiceByName(
        list: List<ServiceStationType>,
        elem: ServiceStationType
    ): Boolean {
        return list.find { it == elem } != null
    }

    private fun getDistance(model: MapStationModel, currentLocation: Location?): Int {
        val startLocation = Location("MapFilter")
        startLocation.latitude = model.latitude
        startLocation.longitude = model.longitude
        val endlocation = Location("MapFilter")
        endlocation.latitude = currentLocation?.latitude ?: model.latitude
        endlocation.longitude = currentLocation?.longitude ?: model.longitude
        return startLocation.distanceTo(endlocation).toInt() / 1000
    }

    fun getMarkersFromStations(listStations: List<MapStationModel>): List<MarkerCluster> {
        return listStations.map {
            MarkerCluster(
                it.title,
                it.type,
                it.petrolStationModel?.status,
                it.fahesStationModel?.status,
                it.drawable,
                LatLng(it.latitude, it.longitude)
            )
        }
    }

    private val _resultLoadedStationImages = SingleLiveEvent<List<MapStationModel>>()
    val resultLoadedStationImages: LiveData<List<MapStationModel>> = _resultLoadedStationImages
    fun loadStationImages(context: Context, list: List<MapStationModel>) {
        viewModelScope.launch {
            val filteredList =
                list.filter { station -> !station.icon.isNullOrEmpty() && station.isVisible }
            if (filteredList.isNotEmpty()) {
                settingPinImage(context, filteredList)
                _resultLoadedStationImages.postValue(filteredList)
            } else {
                settingPinImage(
                    context,
                    list
                )
                _resultLoadedStationImages.postValue(list)
            }

        }
    }

    private fun settingPinImage(context: Context, list: List<MapStationModel>) {
        viewModelScope.launch {
            list.forEach { station ->
                val pinIcon = station.icon

                val request = ImageRequest.Builder(context)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .data(pinIcon?.replace("http://", "https://"))
                    .build()
                val result = context.imageLoader.execute(request)
                station.drawable = result.drawable

            }
        }

    }
}