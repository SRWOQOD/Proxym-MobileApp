package com.woqod.app.domain.models

import android.graphics.drawable.Drawable
import java.io.Serializable

/**
 * Created by Hamdi.BOUMAIZA on 09/29/2020
 */
data class MapStationModel(
    val type: MapTypeStation,
    val id: Int?,
    val title: String,
    val phone: String,
    val latitude: Double,
    val longitude: Double,
    val lastSynchronisationDate: Long? = null,
    val superMarketModel: SuperMarketModel? = null,
    val petrolStationModel: PetrolStationModel? = null,
    val fahesStationModel: FahesStationModel? = null,
    val icon: String?,
    var drawable: Drawable? = null,
    var isVisible : Boolean = false
) : Serializable


enum class MapTypeStation { FAHES_STATION, PETROL_STATION, SUPERMARKET_STATION, SIDRA_STATION, MARINE_STATION, MOBILE_PETROL_STATION }