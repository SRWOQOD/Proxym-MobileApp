package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.StockPricesModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetStockPrices @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCase<WoqodResult<SharedResponse<List<StockPricesModel>>>> {
    override suspend fun invoke(): WoqodResult<SharedResponse<List<StockPricesModel>>> =
        appRepository.getStockPrices()
}