package com.woqod.app.data.models

import com.woqod.app.domain.models.HomeAdsModel
import com.woqod.app.domain.models.getRedirectionAppType
import com.woqod.app.domain.models.mapToFileType
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

data class HomeAdsResponse(
    val videoThumbnail: String?,
    val orderItem: Int?,
    val fileUrl: String?,
    val id: Int?,
    val title : String?,
    val titleArabic : String?,
    val creationDate: Long?,
    val fileTypeEnum: String?,
    val appRedirection: String?,
    val redirectionTypeEnum: String?,
    val redirection: Boolean?,
    val redirectionPath: String?,
    val redirectionArPath: String?,
    val titleDisplayed: Boolean?
) : DomainMapper<HomeAdsModel> {
    override fun mapToDomainModel() = HomeAdsModel(
        videoThumbnail,
        orderItem ?: 0,
        fileUrl,
        mapToFileType(fileTypeEnum),
        id ?: 0,
        title?:"",
        titleArabic = titleArabic?:"",
        creationDate ?: 0L,
        redirectionTypeEnum = mapToRedirectionType(redirectionTypeEnum),
        redirectionPath=if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage())redirectionArPath else redirectionPath,
        appRedirection =  appRedirection?.let { getRedirectionAppType(it) },
        redirection = redirection?:false,
        titleDisplayed = titleDisplayed?:false
    )
}