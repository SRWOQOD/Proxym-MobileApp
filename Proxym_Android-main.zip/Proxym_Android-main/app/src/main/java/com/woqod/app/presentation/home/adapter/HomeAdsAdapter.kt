package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.size.Scale
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemHomeAdsBinding
import com.woqod.app.domain.models.HomeAdsModel
import com.woqod.app.domain.models.HomeBannerFileType
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.load
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commun.extensions.showBannerTitle


class HomeAdsAdapter(
    private var list: MutableList<HomeAdsModel>,
    private val action: (HomeAdsModel) -> Unit
) :
    RecyclerView.Adapter<HomeAdsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemHomeAdsBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    fun updateList(list: List<HomeAdsModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: ItemHomeAdsBinding) : RecyclerView.ViewHolder(view.root) {
        private val shimmer: ShimmerFrameLayout = view.shimmerAdsBanner
        private val image: ImageView = view.ivAdsBanner
        private val adTitle: TextView = view.tvAdsBannerTitle
        private val tvError: TextView = view.tvAdsError
        private val placeHolder: ImageView = view.ivPlaceholder
        private val ivPlayVideo: ImageView = view.ivAdsBannerPlay

        init {
            itemView.setOnClickListener {
                action(list[absoluteAdapterPosition])
            }
        }

            fun bindTo(item: HomeAdsModel) {
                adTitle.showBannerTitle(item.titleDisplayed,item.getAdsBannerTitle())

                if (item.fileTypeEnum == HomeBannerFileType.IMG) {
                    ivPlayVideo.hide()
                    item.fileUrl?.let { url ->
                        shimmer.load(image, url, tvError, placeHolder, true)

                    } ?: run {
                        image.load(R.drawable.ic_home_ads_placeholder) {
                            scale(Scale.FIT)
                            transformations(com.woqod.shared.commun.RoundedCornersTransformation(33F))
                        }
                        tvError.show()
                    }
                } else{
                    ivPlayVideo.show()
                    item.videoThumbnail?.let { url ->
                        shimmer.load(image, url, tvError, placeHolder)
                    } ?: run {
                        image.load(R.drawable.ic_home_ads_placeholder) {
                            scale(Scale.FIT)
                            transformations(com.woqod.shared.commun.RoundedCornersTransformation(33F))
                        }
                        tvError.show()
                    }
                }
            }
        }


}