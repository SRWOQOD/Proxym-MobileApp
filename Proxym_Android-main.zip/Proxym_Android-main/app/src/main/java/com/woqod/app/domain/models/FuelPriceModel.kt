package com.woqod.app.domain.models

import com.woqod.shared.WoqodApplication
import java.io.Serializable

data class FuelPriceModel(
    val date: Long,
    val price: Float,
    val nameEn: String,
    val nameAr: String,
    val syncdate: Long,
    val id: Int,
    val fuelType: FuelType,
    val itemOrder: Int
) : Serializable {
    fun name() = if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
        nameAr
    } else {
        nameEn
    }
}


enum class FuelType {
    GASOLINE_PREMIUM, GASOLINE_SUPER, DIESEL
}
