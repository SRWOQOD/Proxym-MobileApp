package com.woqod.app.presentation.notifications.survey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.ItemSurveyAnswerBinding
import com.woqod.shared.commundomain.models.NotificationSurveyChoicesModel
import com.woqod.shared.commundomain.models.SurveyTypes

class SurveyResponsesAdapter(
    private val listResponse: List<NotificationSurveyChoicesModel>,
    private val typeOfQuestion: SurveyTypes
) : RecyclerView.Adapter<SurveyResponsesAdapter.ViewHolder>() {

    override fun getItemCount() = listResponse.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemSurveyAnswerBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bindViewHolder(listResponse[position], position)


    private var checkedPosition = -1

    inner class ViewHolder(view: ItemSurveyAnswerBinding) : RecyclerView.ViewHolder(view.root) {
        private val answer = view.tvItemCheckboxSurvey
        private val checkbox = view.ivItemCheckboxSurvey

        private fun isSingleChoice() =
    typeOfQuestion.value == SurveyTypes.SINGLE_CHOICE.value || typeOfQuestion.value == SurveyTypes.RADIO_BUTTON.value
        init {
            itemView.setOnClickListener {
                if (isSingleChoice()) {

                    notifyItemChanged(checkedPosition) // to reset the view of the previous selected item
                    checkedPosition = absoluteAdapterPosition
                    notifyItemChanged(checkedPosition) // to update the view of the newly selected item
                    listResponse.map { it.isChoiceChecked = false }
                    listResponse[absoluteAdapterPosition].isChoiceChecked = true
                } else {
                    listResponse[absoluteAdapterPosition].isChoiceChecked =
                        !listResponse[absoluteAdapterPosition].isChoiceChecked
                    notifyItemChanged(absoluteAdapterPosition)
                }
            }
        }

        fun bindViewHolder(responseItem: NotificationSurveyChoicesModel, position: Int) {
            answer.text = responseItem.response

            if (responseItem.isChoiceChecked) {
                if (isSingleChoice()) {
                    checkbox.setImageResource(com.woqod.shared.R.drawable.ic_radiobutton_checked)
                } else {
                    checkbox.setImageResource(com.woqod.shared.R.drawable.ic_checkbox)

                }
            } else {
                if (isSingleChoice()) {
                    checkbox.setImageResource(com.woqod.shared.R.drawable.ic_radiobutton_unchecked)
                } else {
                    checkbox.setImageResource(com.woqod.shared.R.drawable.ic_checkbox_unchecked)

                }
            }

        }
    }

}