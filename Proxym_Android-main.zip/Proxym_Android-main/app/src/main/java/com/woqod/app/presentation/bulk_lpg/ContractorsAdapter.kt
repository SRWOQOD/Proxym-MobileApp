package com.woqod.app.presentation.bulk_lpg

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.ItemContractorBinding
import com.woqod.app.domain.models.ContractorsModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.baseui.BaseListAdapter
import com.woqod.shared.commun.extensions.hide


class ContractorsAdapter(
    private val onPhoneClick: (Array<String>) -> Unit,
    private val onFaxClick: (String) -> Unit,
    private val onEmailClick: (String) -> Unit
) :
    BaseListAdapter<ContractorsModel>(
        itemsSame = { old, new -> old == new },
        contentsSame = { old, new -> old == new }
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, inflater: LayoutInflater, viewType: Int) =
        ViewHolder(
            ItemContractorBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ), onPhoneClick, onFaxClick
        )


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is ViewHolder -> holder.bindTo(getItem(position))
            else -> throw IllegalStateException("Illegal ViewHolder Type")
        }
    }

    override fun submitList(list: List<ContractorsModel>?) {
        super.submitList(list?.let { ArrayList(it) })
    }

    inner class ViewHolder(
        containerView: ItemContractorBinding,
        private val onPhoneClick: (Array<String>) -> Unit,
        private val onFaxClick: (String) -> Unit
    ) : RecyclerView.ViewHolder(containerView.root) {

        private val tvContractorName = containerView.tvBulkContractorName
        private val tvAddress = containerView.tvAddressValue
        private val tvPhone = containerView.tvPhoneValue
        private val tvFax = containerView.tvFaxValue
        private val tvEmail = containerView.tvEmailValue
        private val tvAddressTitle = containerView.tvBulkAddressTitle
        private val tvPhoneTitle = containerView.tvBulkPhoneTitle
        private val tvFaxTitle = containerView.tvBulkFaxTitle
        private val tvEmailTitle = containerView.tvBulkEmailTitle

        fun bindTo(contractor: ContractorsModel) {
            fixItemsPositions()
            with(contractor) {
                title.handleEmptyValue({ tvContractorName.hide() }) {
                    tvContractorName.text = title
                }

                address.handleEmptyValue({
                    tvAddress.hide()
                    tvAddressTitle.hide()
                }) {
                    tvAddress.text = address
                }

                val phoneNumbers = phone.joinToString(",")
                phoneNumbers.handleEmptyValue({
                    tvPhone.hide()
                    tvPhoneTitle.hide()
                }) {
                    tvPhone.text = phoneNumbers
                    tvPhone.setOnClickListener {
                        with(phone) { onPhoneClick(this) }
                    }
                }

                fax.handleEmptyValue({  tvFax.hide()
                    tvFaxTitle.hide()}){
                    tvFax.setOnClickListener {
                        onFaxClick(fax)
                    }
                    tvFax.text = fax
                }

                email.handleEmptyValue({ tvEmail.hide()
                    tvEmailTitle.hide()}){
                    tvEmail.text = email
                    tvEmail.setOnClickListener { onEmailClick.invoke(email) }
                }

            }
        }


        private fun String.handleEmptyValue(empty: () -> Unit, notEmpty: () -> Unit) {
            if (isNotEmpty()) {
                notEmpty()
            } else {
                empty()
            }
        }

        @SuppressLint("RtlHardcoded")
        private fun fixItemsPositions() {
            if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
                tvContractorName.gravity = Gravity.LEFT
                tvAddress.gravity = Gravity.LEFT
                tvPhone.gravity = Gravity.LEFT
                tvFax.gravity = Gravity.LEFT
            } else {
                tvContractorName.gravity = Gravity.RIGHT
                tvAddress.gravity = Gravity.RIGHT
                tvPhone.gravity = Gravity.RIGHT
                tvFax.gravity = Gravity.RIGHT
            }
        }
    }


}