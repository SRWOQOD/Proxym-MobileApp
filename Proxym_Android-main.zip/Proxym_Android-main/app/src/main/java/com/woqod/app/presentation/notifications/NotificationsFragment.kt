package com.woqod.app.presentation.notifications

import android.app.NotificationManager
import android.graphics.Paint
import androidx.core.widget.NestedScrollView
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushIntentService
import com.ibm.mobilefirstplatform.clientsdk.android.push.internal.MFPPushConstants
import com.woqod.app.R
import com.woqod.app.databinding.FragmentNotificationsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.WoqodApplication
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.FeedbackModel
import com.woqod.shared.commundomain.models.NotificationTypes
import com.woqod.shared.commundomain.models.NotificationsModel
import com.woqod.shared.commundomain.models.PushNotificationModel
import com.woqod.shared.utils.FRAGMENT_SOURCE
import com.woqod.shared.utils.HOME_FROM_SPLASH
import com.woqod.shared.utils.NotificationsStatusPin


class NotificationsFragment :
    BaseViewModelFragment<NotificationsViewModel, FragmentNotificationsBinding>(
        FragmentNotificationsBinding::inflate
    ) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: NotificationsViewModel by injectViewModel()

    private val numberOfNotificationsPerPage = 10
    private var pageNumber = 0
    private var isLastPage = SingleLiveEvent<Boolean>()
    private val notificationList = ArrayList<NotificationsModel>()
    private val notificationsAdapter by lazy {
        NotificationsAdapter(mutableListOf()) {
            onSelectNotification(
                it
            )
        }
    }
    private lateinit var updatedNotificationModel: NotificationsModel

    override fun initViews() {
        appComponent.inject(this)
        initRecyclerView()
        getListNotifications()
        disableDefaultBackPress(true)
        binding.toolbarNotification.btnToolbar.setOnClickListener {
            viewModel.navigate(
                Navigation.MENU,
                null
            )
        }
        binding.tvNotificationAllRead.paintFlags =
            binding.tvNotificationAllRead.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        binding.tvNotificationAllRead.setOnClickListener { updateAllNotifications() }
    }

    private fun initRecyclerView() {
        binding.root.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, oldScrollY ->
            val recycler = binding.rvNotifications
            if (scrollY > (recycler.measuredHeight - v.measuredHeight) &&
                scrollY > oldScrollY && viewModel.toggleLoading.value == false
            ) {
                isLastPage.observe(activity) { lastPage ->
                    if (!lastPage && pageNumber != 0) getListNotifications()
                }
            }
        })

        binding.rvNotifications.apply {
            adapter = notificationsAdapter
        }
    }

    override fun onBackPressCustomAction() {

        viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_SPLASH))
    }

    private fun onSelectNotification(notificationModel: NotificationsModel) {
        updatedNotificationModel = notificationModel
        if (!notificationModel.status) updateNotification(notificationModel.notificationID)
        when (notificationModel.type) {
            NotificationTypes.SURVEY.name -> {
                if (!notificationModel.isAnswered)
                    viewModel.navigate(Navigation.SURVEY, notificationModel.surveysResource)
                else togglePopUp(getString(R.string.SurveyAlreadyAnswered))
            }
            NotificationTypes.FEEDBACK.name -> {
                viewModel.navigate(
                    Navigation.FEEDBACK_DETAILS,
                    FeedbackModel(notificationModel.idFeedback.toInt(), false, isFromList = true)
                )
            }
            NotificationTypes.FAHES.name -> {
                viewModel.navigate(Navigation.FAHES, null)
            }

            NotificationTypes.BO.name -> {
                viewModel.navigate(
                    Navigation.BO_NOTIF,
                    PushNotificationModel(
                        notificationModel.descriptionEn,
                        notificationModel.descriptionAr,
                        notificationModel.titleEn,
                        notificationModel.titleAr,
                        false
                    )
                )
            }
        }
    }

    private fun getListNotifications() {
        if (sharedPreferences.isUserLoggedIn()) {
            viewModel.getListNotifications(
                hashMapOf(
                    USERNAME to sharedPreferences.username,
                    SIZE to numberOfNotificationsPerPage,
                    PAGE to pageNumber,
                    DEVICE_ID to sharedPreferences.deviceId
                )
            )
        } else {
            getAnonymousListNotifications()
        }

    }

    private fun getAnonymousListNotifications() {
        viewModel.getAnonymousListNotifications(
            hashMapOf(
                SIZE to numberOfNotificationsPerPage,
                PAGE to pageNumber,
                DEVICE_ID to sharedPreferences.deviceId
            )
        )
    }

    private fun handleNotifError(error: String) {
        binding.tvNotificationAllRead.hide()
        binding.tvNotificationEmptyList.show()
        togglePopUp(error)
    }

    private fun handleNotifcationSucess(
        notifications: List<NotificationsModel>,
        page: Int,
        count: Int
    ) {
        clearNotificationBar()
        setNotificationsList(notifications, page)
        if ((count - 1) > pageNumber) {
            isLastPage.postValue(false)
            pageNumber = page + 1
        } else {
            isLastPage.postValue(true)
        }
    }

    private fun clearNotificationBar() {
        val notificationManager =
            WoqodApplication.sharedComponent.context()
                .getSystemService(MFPPushIntentService.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancelAll()
    }

    override fun initObservers() {
        viewModel.onGetNotifications.observe(viewLifecycleOwner) {
            it.result?.let { result ->

                handleNotifcationSucess(result.result, result.page, result.count)
            }
            it.error?.let { error ->
                handleNotifError(error)
            }
        }

        viewModel.onGetAnonymousNotifications.observe(viewLifecycleOwner) {
            it.result?.let { result ->
                handleNotifcationSucess(result.result, result.page, result.count)
            }
            it.error?.let { error ->
                handleNotifError(error)
            }
        }


        viewModel.onGetUpdateNotificationResponse.observe(this, {
            it.result?.let { result ->
                if (result && ::updatedNotificationModel.isInitialized) {
                    updateNotifStatus()
                    updatePinStatus()
                }
            }
            it.error?.let { error -> togglePopUp(error) }
        })

        viewModel.onGetUpdateAllNotificationsResponse.observe(this, {
            it.result?.let { result ->
                if (result) {
                    notificationList.forEachIndexed { index, notificationsModel ->
                        updateAllNotifStatus()
                        notificationsModel.status = true
                        notificationsAdapter.notifyItemChanged(index)
                    }
                    updatePinStatus()
                }
            }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun updateNotifStatus() {
        notificationList.forEachIndexed { index, notificationsModel ->
            if (notificationsModel.notificationID == updatedNotificationModel.notificationID) {
                notificationsModel.status = true
                notificationsAdapter.notifyItemChanged(index)
            }
        }
    }

    private fun updateAllNotifStatus() {
        notificationList.forEachIndexed { index, notificationsModel ->
            notificationsModel.status = true
            notificationsAdapter.notifyItemChanged(index)

        }
    }

    private fun updatePinStatus() {
        var allNotificationStatus = true

        notificationList.forEachIndexed { _, notificationsModel ->
            if (allNotificationStatus)
                allNotificationStatus = notificationsModel.status
            else return@forEachIndexed
        }

        NotificationsStatusPin.getInstance().notificationStatusPin.postValue(
            ResultUseCase<Boolean?, String?>(
                !allNotificationStatus,
                null
            )
        )

    }

    private fun setNotificationsList(list: List<NotificationsModel>, page: Int) {

        if (page == 0) {
            notificationsAdapter.resetList()
        }
        if (list.isNotEmpty()) {
            notificationList.addAll(list)
            notificationsAdapter.addItems(list)
            binding.tvNotificationEmptyList.hide()
            binding.rvNotifications.show()
            binding.tvNotificationAllRead.show()
            updatePinStatus()
        } else {
            binding.tvNotificationEmptyList.show()
            binding.rvNotifications.hide()
            binding.tvNotificationAllRead.hide()
        }
    }

    private fun updateNotification(notificationId: Int) {

        if (sharedPreferences.isUserLoggedIn()) {

                viewModel.updateNotification(
                    hashMapOf(
                        MFPPushConstants.DEVICE_ID to sharedPreferences.deviceId,
                        UNIQUE_ID to "",
                        NOTIFICATION_ID to notificationId,
                        USERNAME to sharedPreferences.username,
                    )
                )


        } else {

                viewModel.updateNotification(
                    hashMapOf(
                        MFPPushConstants.DEVICE_ID to sharedPreferences.deviceId,
                        UNIQUE_ID to "",
                        NOTIFICATION_ID to notificationId

                    )
                )

        }
    }

    private fun updateAllNotifications() {
        viewModel.updateAllNotifications(
            hashMapOf(
                USERNAME to sharedPreferences.username,
                USER_IS_CONNECTED to sharedPreferences.isUserLoggedIn(),
                USER_DEVICE_ID to sharedPreferences.deviceId
            )
        )
    }

}