package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemHomeBusinessDetailsBinding
import com.woqod.app.domain.models.HomeBusinessSectionModel
import com.woqod.app.presentation.utils.MAX_LINE_BWW
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.load
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commun.extensions.textInHtmlFormatted

class HomeBusinessDetailsAdapter(
    private var list: MutableList<HomeBusinessSectionModel>,
    private val action: (HomeBusinessSectionModel) -> Unit,
    private val clickOnReadMore: (Int) -> Unit
) :
    RecyclerView.Adapter<HomeBusinessDetailsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemHomeBusinessDetailsBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    fun updateList(list: List<HomeBusinessSectionModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }


    inner class ViewHolder(view: ItemHomeBusinessDetailsBinding) :
        RecyclerView.ViewHolder(view.root) {
        private val shimmer: ShimmerFrameLayout = view.shimmerHomeBusinessDetails
        private val image: ImageView = view.ivBusinessDetails
        private val title: TextView = view.tvBusinessDetailsTitle
        private val description: TextView = view.tvBusinessDetailsDesc
        private val tvError: TextView = view.tvHomeBusinessDetailsError
        private val readMore: TextView = view.tvBusinessReadMore
        private val placeHolder: ImageView = view.ivPlaceholder

        init {
            itemView.setOnClickListener {
                action(list[absoluteAdapterPosition])
            }

            readMore.setOnClickListener {
                readMore.hide()
                description.maxLines = Int.MAX_VALUE
                clickOnReadMore(absoluteAdapterPosition)
            }

        }

        fun bindTo(item: HomeBusinessSectionModel) {
            readMore.show()
            description.maxLines = MAX_LINE_BWW
            item.imageUrl?.let {
                shimmer.load(image, it, tvError, placeHolder, isHome = true)

            } ?: run {
                image.setImageResource(R.drawable.ic_home_ads_placeholder)
                tvError.show()
            }
            title.text = item.title()
            description.textInHtmlFormatted(item.descp(), itemView.context)
            description.post {
                var isEllipsize: Boolean =
                    description.layout.lineCount >= description.maxLines
               // for (i in 0..description.layout.lineCount) {
                isEllipsize=      description.layout.getEllipsisCount(description.layout.lineCount-1) != 0

            //    }
                if (isEllipsize) readMore.show() else readMore.hide()
            }

        }
    }

}