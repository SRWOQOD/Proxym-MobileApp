package com.woqod.app.presentation.promotions

import com.woqod.app.databinding.FragmentPromotionsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.PromotionsModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show


class PromotionsFragment :
    BaseViewModelFragment<PromotionsViewModel, FragmentPromotionsBinding>(FragmentPromotionsBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: PromotionsViewModel by injectViewModel()

    private val promotionsAdapter: PromotionsAdapter by lazy {
        PromotionsAdapter(mutableListOf(), ::onItemDetailClicked)
    }

    override fun initViews() {
        disableDefaultBackPress(true)
        appComponent.inject(this)
        initClickListeners()
        initRecyclerView()
        viewModel.getPromotions()
    }
    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)

    }
    private fun initRecyclerView() {
        binding.rcPromotionsList.adapter = promotionsAdapter
    }

    private fun onItemDetailClicked(promotionsModel: PromotionsModel) {
        viewModel.navigate(Navigation.PROMOTION_DETAILS, promotionsModel)
    }

    override fun initObservers() {
        viewModel.onGetPromotions.observe(this) {
            it.result?.let { promotionsList -> updateList(promotionsList) }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun updateList(list : List<PromotionsModel>) {
        if (list.isNullOrEmpty()) {
            binding.tvNoPromotions.show()
            binding.rcPromotionsList.hide()
        } else {
            binding.tvNoPromotions.hide()
            binding.rcPromotionsList.show()
            promotionsAdapter.updateList(list)
        }
    }

    private fun initClickListeners() {
        binding.toolbarPromotions.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

}