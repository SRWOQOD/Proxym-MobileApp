package com.woqod.app.domain.usecases

import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

class GetHasNotif @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCaseWithRequest<HashMap<String,Any>,WoqodResult<SharedResponse<Boolean>>> {

    override suspend operator fun invoke(resquest : HashMap<String,Any>) =
        appRepository.getHasNotif(resquest)

}