package com.woqod.app.data.models

import com.woqod.app.domain.models.ContractorsModel
import com.woqod.shared.commundata.DomainMapper


data class ContractorsResponse(
    val title: String?,
    val address: String?,
    val phone: Array<String>?,
    val fax: String?,
    val email: String?
) : DomainMapper<ContractorsModel> {
    override fun mapToDomainModel() = ContractorsModel(
        title = title ?: "",
        address = address ?: "",
        phone = phone ?: arrayOf(),
        fax = fax ?: "",
        email = email ?: ""
    )

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ContractorsResponse

        if (phone != null) {
            if (other.phone == null) return false
            if (!phone.contentEquals(other.phone)) return false
        } else return false

        return true
    }

    override fun hashCode() = phone?.contentHashCode() ?: 0
}