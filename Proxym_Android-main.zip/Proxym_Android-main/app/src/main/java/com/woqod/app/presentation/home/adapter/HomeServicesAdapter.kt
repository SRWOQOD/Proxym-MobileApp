package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.databinding.ItemServiceBinding
import com.woqod.app.domain.models.HomeBannerAppRedirection

class HomeServicesAdapter(
    private val list: List<ServiceModel>,
    private val action: (HomeBannerAppRedirection) -> Unit
) :
    RecyclerView.Adapter<HomeServicesAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemServiceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    inner class ViewHolder(private val view: ItemServiceBinding) :
        RecyclerView.ViewHolder(view.root) {

        init {
            itemView.setOnClickListener {
                action(list[absoluteAdapterPosition].serviceType)
            }
        }

        fun bindTo(serviceModel: ServiceModel) {
            serviceModel.apply {
                view.imgItemService.setImageResource(image)
                view.tvItemServiceTitle.text = title
            }
        }
    }
}

data class ServiceModel(val serviceType: HomeBannerAppRedirection, val image: Int, val title: String)