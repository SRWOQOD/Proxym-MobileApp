package com.woqod.app.presentation.static_screens

import android.os.Bundle
import androidx.annotation.DrawableRes
import com.woqod.app.R
import com.woqod.app.databinding.FragmentTermsOfUseBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.SideMenuItem
import com.woqod.shared.utils.FROM_REGISTRATION

class TermsOfUseFragment : BaseViewModelFragment<StaticScreenViewModel, FragmentTermsOfUseBinding>(
    FragmentTermsOfUseBinding::inflate
) {

    override val viewModel: StaticScreenViewModel by injectViewModel()
    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }
    private var isFromRegistration = false

    fun newInstance(params: HashMap<String, Boolean>) = TermsOfUseFragment().apply {
        arguments = Bundle().apply {
            putSerializable(FROM_REGISTRATION, params)
        }
    }

    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            isFromRegistration =
                (it.getSerializable(FROM_REGISTRATION) as HashMap<String, Boolean>)[FROM_REGISTRATION] == true
        }

        viewModel.getStaticText(SideMenuItem.TERMS_OF_USE.name)
    }

    override fun initObservers() {
        viewModel.resultStaticScreen.observe(this) {
            it.result?.let { staticText ->
                binding.tvTermsConditionsDesc.loadStaticWebView(
                    staticText.content,
                    isArabicLanguage = languageUtils.isArabicLanguage()
                )
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    override fun handleFragmentArgs() {
        setUpToolBar()
    }

    override fun onBackPressCustomAction() {
        when (isFromRegistration) {
            true -> viewModel.navigate(Navigation.REGISTER_STEP3, null)
            else -> viewModel.navigate(Navigation.HOME, null)
        }

    }

    private fun setUpToolBar() {
        when (isFromRegistration) {
            true -> {
                disableDefaultBackPress(false)
                initToolBarClick(R.drawable.ic_toolbar_arrow_back) {
                    activity.onBackPressed()
                }
            }
            else -> {
                disableDefaultBackPress(true)
                initToolBarClick(R.drawable.ic_toolbar_open) {
                    viewModel.navigate(Navigation.MENU, null)
                }
            }
        }
    }


    private fun initToolBarClick(@DrawableRes image: Int, action: () -> Unit) {
        binding.toolbarTermsConditions.btnToolbar.setImageResource(image)
        binding.toolbarTermsConditions.btnToolbar.setOnClickListener {
            action()
        }
    }
}