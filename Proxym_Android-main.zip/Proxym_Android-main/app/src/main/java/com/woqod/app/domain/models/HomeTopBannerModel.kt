package com.woqod.app.domain.models

import com.woqod.shared.WoqodApplication
import timber.log.Timber

/**
 * When open the home page, the list of Top banner will be shown based on the order (orderItem).

This list can contain image or video.

Get the type of item with 'fileTypeEnum' (IMG/VIDEO)

In case of video, there is no redirection.

In case of image, it may have a redirection

Get redirection type from 'redirectionTypeEnum' (APP/URL)

if redirection type = APP =>  get the feature from 'appRedirection'

if redirection type = URL => get the url from 'redirectionPath'
 */
data class HomeTopBannerModel(
    val videoThumbnail: String?,
    val fileTypeEnum: HomeBannerFileType,
    val appRedirection: HomeBannerAppRedirection?,
    val orderItem: String,
    val redirectionTypeEnum: HomeBannerRedirectionType?,
    val redirectionPath: String?,
    val title: String,
    val titleArabic: String,
    val fileUrl: String?,
    val id: Long?,
    val redirection: Boolean,
    val titleDisplayed: Boolean
) {
    constructor() : this(
        null,
        HomeBannerFileType.IMG,
        null,
        "0",
        null,
        null,
        "",
        "",
        null,
        null,
        false,
        false
    )
    fun getBannerTitle() = if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) titleArabic else title
}

enum class HomeBannerFileType {
    IMG, VIDEO
}

enum class HomeBannerAppRedirection(val value: String) {
    FAHES("Fahes"),
    WOQODE("WOQODE"),
    LOCATION("LOCATION"),
    SHAFAF("SHAFAF"),
    APP_CONTENT_STOCK_PRICES("APP_CONTENT_STOCK_PRICES"),
    APP_CONTENT_NEWS("APP_CONTENT_NEWS"),
    APP_CONTENT_TENDER("APP_CONTENT_TENDER"),
    APP_CONTENT_PROMOTIONS("APP_CONTENT_PROMOTIONS"),
    APP_CONTENT_BULK_LPG("APP_CONTENT_BULK_LPG"),
    APP_ABOUT_WOQOD("APP_ABOUT_WOQOD"),
    WOQODE_TOPUP("WOQODE_TOPUP"),
    ABOUT_WOQODE("ABOUT_WOQODE"),
    FAHES_BOOK_VEHICLE_INSPECTION("FAHES_BOOK_VEHICLE_INSPECTION"),
    FAHES_ONLINE_PAYMENT("FAHES_ONLINE_PAYMENT"),
    FAHES_CANCEL_MODIFY_BOOKING("FAHES_CANCEL_MODIFY_BOOKING"),
    FAHES_STATIONS("FAHES_STATIONS"),
    ABOUT_FAHES("ABOUT_FAHES"),
    FAHES_INSPECTION_TIPS("FAHES_INSPECTION_TIPS"),
    SHAFAF_SUPERMARKETS("SHAFAF_SUPERMARKETS"),
    SHAFAF_RETAILERS("SHAFAF_RETAILERS"),
    ABOUT_SHAFAF("ABOUT_SHAFAF"),
    REGISTRATION("REGISTRATION"),
    FEEDBACK("FEEDBACK"),
    APP_PRIVACY_POLICY("APP_PRIVACY_POLICY"),
    APP_TERMS_OF_USE("APP_TERMS_OF_USE")
}

fun mapToFileType(fileTypeEnum: String?): HomeBannerFileType {
    fileTypeEnum?.let {
        return if (it == HomeBannerFileType.VIDEO.name) HomeBannerFileType.VIDEO
        else HomeBannerFileType.IMG
    } ?: return HomeBannerFileType.IMG
}

fun getRedirectionAppType(redirectionAPPTypeEnum: String): HomeBannerAppRedirection? {
    var redirectionApp: HomeBannerAppRedirection? = null
    try {
        redirectionApp = HomeBannerAppRedirection.valueOf(redirectionAPPTypeEnum)
    } catch (e: Exception) {
        Timber.e(e)
    }
    return redirectionApp
}

enum class HomeBannerRedirectionType {
    APP, URL
}