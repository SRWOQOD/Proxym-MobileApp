package com.woqod.app.data.models

import com.woqod.app.domain.models.PromotionsModel
import com.woqod.shared.commundata.DomainMapper

data class PromotionsResponse(
    val id: Long?,
    val title: String?,
    val titleArabic: String?,
    val briefDescription: String?,
    val briefDescriptionArabic: String?,
    val image: String?,
    val imageList: String?,
    val link: String?,
    val category: String?,
    val startDate: Long?,
    val endDate: Long?,
    //val lastSynchronisationDate: Long?,
    val promotionsId: Long?
) : DomainMapper<PromotionsModel> {
    override fun mapToDomainModel() =
        PromotionsModel(
            id = id ?: 0L,
            title = title ?: "",
            titleArabic = titleArabic ?: "",
            briefDescription = briefDescription ?: "",
            briefDescriptionArabic = briefDescriptionArabic ?: "",
            image = image,
            imageList = imageList,
            link = link ?: "",
            category = category ?: "",
            startDate = startDate ?: 0L,
            endDate = endDate ?: 0L,
            lastSynchronisationDate = 0L,
            promotionsId = promotionsId ?: 0L
        )

}