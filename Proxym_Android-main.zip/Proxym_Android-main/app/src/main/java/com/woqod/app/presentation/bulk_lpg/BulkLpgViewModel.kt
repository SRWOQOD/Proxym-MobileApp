package com.woqod.app.presentation.bulk_lpg


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.ContractorsModel
import com.woqod.app.domain.usecases.GetContractorsUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.StaticScreenModel
import com.woqod.shared.commundomain.sharedusecases.GetStaticScreenTextUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class BulkLpgViewModel @Inject constructor(
    private val getContractorsUseCase: GetContractorsUseCase,
    private val getStaticScreenTextUseCase: GetStaticScreenTextUseCase
) : BaseViewModel() {

    private val _onGetContractors = SingleLiveEvent<ResultUseCase<List<ContractorsModel>?, String?>>()
    val onGetContractors: LiveData<ResultUseCase<List<ContractorsModel>?, String?>> = _onGetContractors

    fun getContractors() {
        viewModelScope.launch {
            _onGetContractors.postValue(executeUseCase(getContractorsUseCase))
        }
    }

    private val _resultStaticScreen = SingleLiveEvent<ResultUseCase<StaticScreenModel?, String?>>()
    val resultStaticScreen: LiveData<ResultUseCase<StaticScreenModel?, String?>> = _resultStaticScreen

    fun getStaticText(section : String) {
        viewModelScope.launch {
            _resultStaticScreen.postValue(executeUseCase(getStaticScreenTextUseCase,section))
        }
    }
}