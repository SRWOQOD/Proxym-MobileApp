package com.woqod.app.presentation.menu


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.usecases.GetHasNotif
import com.woqod.app.domain.usecases.LogoutUseCase
import com.woqod.app.domain.usecases.UpdateWoqodeUserUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.sharedusecases.GetBalanceInquiryUseCase
import com.woqod.shared.utils.NotificationsStatusPin
import com.woqod.woqode.domain.models.AccountInquiryModel
import kotlinx.coroutines.launch
import javax.inject.Inject

class MainViewModel @Inject constructor(
    private val getBalanceInquiryUseCase: GetBalanceInquiryUseCase,
    private val updateWoqodeUserUseCase: UpdateWoqodeUserUseCase,
    private val getHasNotif: GetHasNotif,
    private val logout : LogoutUseCase,
) : BaseViewModel(){

    private val _resultBalanceInquiry = SingleLiveEvent<ResultUseCase<AccountInquiryModel?, String?>>()
    val resultBalanceInquiry: LiveData<ResultUseCase<AccountInquiryModel?, String?>> = _resultBalanceInquiry

    private val _resultLogout = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultLogout: LiveData<ResultUseCase<Boolean?, String?>> = _resultLogout

    fun getBalanceInquiry(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _resultBalanceInquiry.postValue(executeUseCase(useCaseWithoutSharedResponse = getBalanceInquiryUseCase, query = query))
        }
    }

    fun updateWoqodeUser(query: HashMap<String, Any>) {
        viewModelScope.launch {
            updateWoqodeUserUseCase(query)
        }
    }

    fun getHasNotif(request : HashMap<String , Any >) {
        viewModelScope.launch {

            NotificationsStatusPin.getInstance().notificationStatusPin.postValue(executeUseCase(getHasNotif,request, showLoading = false))
        }
    }
    fun logout(request : HashMap<String , Any >) {
        viewModelScope.launch {
            _resultLogout.postValue(executeUseCase(logout,request))
        }
    }


}