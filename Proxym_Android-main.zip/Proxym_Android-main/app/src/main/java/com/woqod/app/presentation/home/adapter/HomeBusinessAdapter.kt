package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.request.CachePolicy
import coil.size.Precision
import coil.size.Scale
import com.woqod.app.R
import com.woqod.app.databinding.ItemHomeBusinessBinding
import com.woqod.app.domain.models.HomeBusinessSectionModel
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.loadColor
import com.woqod.shared.commun.extensions.show

class HomeBusinessAdapter(
    private var list: MutableList<HomeBusinessSectionModel>,
    private val action: (Int) -> Unit
) :
    RecyclerView.Adapter<HomeBusinessAdapter.ViewHolder>() {

    private var checkedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemHomeBusinessBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position], position)
    }

    override fun getItemCount() = list.size

    fun updateList(list: List<HomeBusinessSectionModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }

    fun selectItem(position: Int) {
        notifyItemChanged(checkedPosition) // to reset the view of the previous selected item
        checkedPosition = position
        notifyItemChanged(checkedPosition) // to update the view of the newly selected item
    }

    inner class ViewHolder(view: ItemHomeBusinessBinding) :
        RecyclerView.ViewHolder(view.root) {

        private val container: CardView = view.root
        private val icon: ImageView = view.imgItemBusiness
        private val title: TextView = view.tvItemBusinessTitle

        init {
            itemView.setOnClickListener {
                notifyItemChanged(checkedPosition) // to reset the view of the previous selected item
                checkedPosition = absoluteAdapterPosition
                notifyItemChanged(checkedPosition) // to update the view of the newly selected item
                action(absoluteAdapterPosition)
            }
        }

        fun bindTo(item: HomeBusinessSectionModel, position: Int) {
            if (item.iconTitle.isEmpty()) {
                title.hide()
            }else
            {   title.show()
                title.text = item.iconTitle()
            }

            if (checkedPosition == position) {
                item.checkedIconUrl?.let {
                    icon.load(it) {
                        crossfade(true)
                        scale(Scale.FILL)
                        precision(Precision.EXACT)
                        placeholder(R.drawable.ic_placeholder)
                        error(R.drawable.ic_placeholder)
                        memoryCachePolicy(CachePolicy.ENABLED)
                        diskCachePolicy(CachePolicy.ENABLED)
                    }
                }
                title.setTextColor(itemView.context.loadColor(R.color.colorWhite))
                container.backgroundTintList =
                    itemView.context.getColorStateList(R.color.color_66C285)
                container.scaleX = 1.0f
                container.scaleY = 1.0f
            } else {
                item.uncheckedIconUrl?.let {
                    icon.load(it) {
                        crossfade(true)
                        scale(Scale.FILL)
                        precision(Precision.EXACT)
                        placeholder(R.drawable.ic_placeholder)
                        error(R.drawable.ic_placeholder)
                        memoryCachePolicy(CachePolicy.ENABLED)
                        diskCachePolicy(CachePolicy.ENABLED)
                    }
                }
                title.setTextColor(itemView.context.loadColor(R.color.color_66C285))
                container.backgroundTintList =
                    itemView.context.getColorStateList(R.color.colorWhite)
                container.scaleX = 1.0f
                container.scaleY = 1.0f
            }

        }
    }
}