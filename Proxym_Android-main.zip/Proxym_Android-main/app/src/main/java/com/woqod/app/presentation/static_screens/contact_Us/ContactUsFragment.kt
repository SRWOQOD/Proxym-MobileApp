package com.woqod.app.presentation.static_screens.contact_Us

import com.woqod.app.databinding.FragmentContactUsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.makeCall
import com.woqod.shared.commun.extensions.openLink
import com.woqod.shared.commun.extensions.sendEmail
import com.woqod.shared.widget.phone_numbers_dialog.PhoneNumbersDialog


class ContactUsFragment :
    BaseViewModelFragment<ContactUsViewModel, FragmentContactUsBinding>(FragmentContactUsBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: ContactUsViewModel by injectViewModel()
    private val phoneNumbersList =
        listOf(CONTACT_PHONE_NUMBER, FREE_CUSTOMER_SERVICE_NUMBER)

    override fun initViews() {
        appComponent.inject(this)
        initClickListeners()
        initComponents()
        disableDefaultBackPress(true)
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)
    }

    private fun initClickListeners() {
        binding.toolbarContactUs.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

    private fun initComponents() {
        initFirstComponent()
        initSecondComponent()
        initThirdComponent()
    }

    private fun openPhoneNumbersDialog(phoneNumbers: List<String>) {
        val phoneNumbersDialog = PhoneNumbersDialog(phoneNumbers) { it.makeCall(activity) }
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        activity.supportFragmentManager.findFragmentByTag(PHONE_NUMBERS_DIALOG_TAG)
            ?.let { fragmentTransaction.remove(it) }
            .also { fragmentTransaction.addToBackStack(null) }
        with(phoneNumbersDialog) { show(fragmentTransaction, PHONE_NUMBERS_DIALOG_TAG) }
    }

    private fun initFirstComponent() {
        binding.componentContactUsFirst.initContactUsComponent(
            { openPhoneNumbersDialog(phoneNumbersList) },
            { CONTACT_EMAIL.sendEmail(activity) }
        ) { CONTACT_WEB_SITE.openLink(activity) }

    }

    private fun initSecondComponent() {
        binding.componentContactUsSecond.initContactUsComponent(
            { FACEBOOK_LINK.openLink(activity) },
            { INSTAGRAM_LINK.openLink(activity) }
        ) { TWITTER_LINK.openLink(activity) }
    }

    private fun initThirdComponent() {
        binding.componentContactUsThird.initContactUsComponent(
            { YOUTUBE_LINK.openLink(activity) },
            { LINKEDIN_LINK.openLink(activity) }
        )
    }


}