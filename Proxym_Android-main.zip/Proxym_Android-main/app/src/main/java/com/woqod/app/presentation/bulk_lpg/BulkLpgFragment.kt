package com.woqod.app.presentation.bulk_lpg

import com.woqod.app.databinding.FragmentBulkLpgBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.ContractorsModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PHONE_NUMBERS_DIALOG_TAG
import com.woqod.shared.commun.SideMenuItem
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.makeCall
import com.woqod.shared.commun.extensions.sendEmail
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.widget.phone_numbers_dialog.PhoneNumbersDialog

class BulkLpgFragment :
    BaseViewModelFragment<BulkLpgViewModel, FragmentBulkLpgBinding>(FragmentBulkLpgBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: BulkLpgViewModel by injectViewModel()

    private val contractorsAdapter: ContractorsAdapter by lazy {
        ContractorsAdapter(
            onPhoneClick = ::onPhoneCLicked,
            onFaxClick = { it.makeCall(activity) }) {
            it.sendEmail(activity)
        }
    }

    override fun initViews() {
        appComponent.inject(this)
        viewModel.getContractors()
        disableDefaultBackPress(true)
        viewModel.getStaticText(SideMenuItem.BUKLPG.name)
        binding.toolbarLpg.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)
    }

    override fun initObservers() {
        with(viewLifecycleOwner) {
            viewModel.onGetContractors.observe(this) {
                it.result?.let { list -> onGetContractors(list) }
                it.error?.let { error -> togglePopUp(error) }
            }

            viewModel.resultStaticScreen.observe(this) {
                it.result?.let { staticText ->
                    binding.bulkLpgDescription.loadStaticWebView(
                        staticText.content,
                        isArabicLanguage = languageUtils.isArabicLanguage()
                    )
                }
                it.error?.let { error ->
                    binding.bulkLpgDescription.hide()
                    binding.bulkLpgErrorDescription.show()
                    binding.bulkLpgErrorDescription.text =
                        getString(com.woqod.app.R.string.BulkLpgDescription)
                    togglePopUp(error)
                }
            }
        }
    }

    private fun onGetContractors(contractors: List<ContractorsModel>) {
        with(contractorsAdapter) {
            binding.rvContractors.adapter = this
            submitList(contractors)
        }
    }

    private fun onPhoneCLicked(phoneNumbers: Array<String>) {
        with(phoneNumbers) {
            if (isNotEmpty() && size == 1) first().makeCall(activity) else openPhoneNumbersDialog(
                toList()
            )
        }
    }

    private fun openPhoneNumbersDialog(phoneNumbers: List<String>) {
        val phoneNumbersDialog = PhoneNumbersDialog(phoneNumbers) { it.makeCall(activity) }
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        activity.supportFragmentManager.findFragmentByTag(PHONE_NUMBERS_DIALOG_TAG)
            ?.let { fragmentTransaction.remove(it) }
            .also { fragmentTransaction.addToBackStack(null) }
        with(phoneNumbersDialog) { show(fragmentTransaction, PHONE_NUMBERS_DIALOG_TAG) }
    }

}