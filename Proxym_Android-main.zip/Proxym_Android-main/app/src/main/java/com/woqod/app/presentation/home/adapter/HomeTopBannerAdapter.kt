package com.woqod.app.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.size.Scale
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemHomeTopBannerBinding
import com.woqod.app.domain.models.HomeBannerFileType
import com.woqod.app.domain.models.HomeTopBannerModel
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.load
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commun.extensions.showBannerTitle

class HomeTopBannerAdapter(
    private var list: MutableList<HomeTopBannerModel>,
    private val action: (HomeTopBannerModel) -> Unit
) :
    RecyclerView.Adapter<HomeTopBannerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemHomeTopBannerBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindTo(list[position])
    }

    override fun getItemCount() = list.size

    fun updateList(list: List<HomeTopBannerModel>) {
        this.list.clear()
        this.list = list.toMutableList()
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: ItemHomeTopBannerBinding) : RecyclerView.ViewHolder(view.root) {

        private val imageView: ImageView = view.ivTopBanner
        private val ivPlayVideo: ImageView = view.ivTopBannerPlay
        private val tvError: TextView = view.tvTopBannerErrorMsg
        private val tvTitle: TextView = view.tvTopBannerTitle
        private val shimmer: ShimmerFrameLayout = view.shimmerTopBanner
        private val placeHolder: ImageView = view.ivPlaceholder

        init {
            itemView.setOnClickListener {
                action(list[absoluteAdapterPosition])
            }
        }

        fun bindTo(item: HomeTopBannerModel) {
            if (item.fileTypeEnum == HomeBannerFileType.IMG) {
                ivPlayVideo.hide()
                item.fileUrl?.let { url ->
                    shimmer.load(imageView, url, tvError, placeHolder, true)
                } ?: run {
                    imageView.load(R.drawable.ic_home_ads_placeholder) {
                        scale(Scale.FIT)
                        transformations(com.woqod.shared.commun.RoundedCornersTransformation(33F))
                    }
                    tvError.show()

                }
            } else {
                ivPlayVideo.show()
                item.videoThumbnail?.let { url ->
                    shimmer.load(imageView, url, tvError, placeHolder)
                } ?: run {
                    imageView.load(R.drawable.ic_home_ads_placeholder) {
                        scale(Scale.FIT)
                        transformations(com.woqod.shared.commun.RoundedCornersTransformation(33F))
                    }
                    tvError.show()
                }
            }
            tvTitle.showBannerTitle(item.titleDisplayed,item.getBannerTitle())

        }


    }

}
