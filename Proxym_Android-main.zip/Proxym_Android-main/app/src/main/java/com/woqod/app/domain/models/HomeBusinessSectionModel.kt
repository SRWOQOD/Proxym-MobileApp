package com.woqod.app.domain.models

import com.woqod.shared.WoqodApplication

/**
 * When open the home page, the list of Business banner will be shown based on the order (orderItem).

Get redirection type from 'redirectionTypeEnum' (APP/URL)

if redirection type = APP =>  get the feature from 'appRedirection'

if redirection type = URL => get the url from 'redirectionPath'
 */

data class HomeBusinessSectionModel(
    val id: Long,
    val orderItem: String,
    val iconTitle: String,
    val iconTitleArabic: String,
    val uncheckedIconUrl: String?,
    val checkedIconUrl: String?,
    val imageUrl: String?,
    val title: String,
    val titleAr: String,
    val description: String,
    val descriptionAr: String,
    val redirectionTypeEnum: HomeBannerRedirectionType?,
    val redirectionPath: String?,
    val appRedirection: HomeBannerAppRedirection?
){
    fun iconTitle() = if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) iconTitleArabic else iconTitle
    fun title() = if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) titleAr else title
    fun descp() = if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) descriptionAr else description
}