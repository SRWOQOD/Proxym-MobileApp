package com.woqod.app.presentation.fuel_prices

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.LayoutFuelPricesBinding
import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.models.FuelType
import com.woqod.shared.commun.extensions.loadColor
import com.woqod.shared.commun.extensions.loadDrawable
import com.woqod.shared.commundata.context


class FuelPricesAdapter(
    private var listFuelPrices: MutableList<FuelPriceModel>
) : RecyclerView.Adapter<FuelPricesAdapter.ViewHolder>() {

    override fun getItemCount() = listFuelPrices.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutFuelPricesBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(listFuelPrices[position])
    }

    fun updateList(list: List<FuelPriceModel>) {
        listFuelPrices.clear()
        listFuelPrices = list.toMutableList()
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: LayoutFuelPricesBinding) : RecyclerView.ViewHolder(view.root) {
        private val gasType = view.tvItemFuelType
        private val gasImage = view.ivItemFuel
        private val gasPrice = view.tvItemFuelPrice
        private val itemRootLayout = view.root

        fun bindViewHolder(item: FuelPriceModel) {
            gasType.text = item.name()
            gasPrice.text = context.getString(R.string.FuelPriceFomatPrice,item.price)
            when (item.fuelType) {
                FuelType.GASOLINE_PREMIUM -> {
                    gasType.setTextColor(context.loadColor(R.color.color_21977D))
                    gasImage.background = context.loadDrawable(R.drawable.ic_fuel_green_circle_background)
                    itemRootLayout.background = itemView.context.loadDrawable(R.drawable.bg_rounded_corner_gradient_green)
                }
                FuelType.GASOLINE_SUPER -> {
                    gasType.setTextColor(context.loadColor(R.color.color_068EC0))
                    gasImage.background = context.loadDrawable(R.drawable.ic_fuel_blue_circle_background)
                    itemRootLayout.background = itemView.context.loadDrawable(R.drawable.bg_rounded_corner_gradient_light_blue)
                }
                else -> {
                    gasType.setTextColor(context.loadColor(R.color.color_FCC153))
                    gasImage.background = context.loadDrawable(R.drawable.ic_fuel_yellow_circle_background)
                    itemRootLayout.background = itemView.context.loadDrawable(R.drawable.bg_rounded_corner_gradient_blue)
                }
            }
        }
    }

}