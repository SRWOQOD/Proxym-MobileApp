package com.woqod.app.presentation.fuel_prices


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.usecases.GetFuelPricesUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class FuelPricesViewModel @Inject constructor(private val getFuelPricesUseCase: GetFuelPricesUseCase) : BaseViewModel() {

    private val _resultFuelPrices = SingleLiveEvent<ResultUseCase<List<FuelPriceModel>?, String?>>()
    val resultFuelPrices: LiveData<ResultUseCase<List<FuelPriceModel>?, String?>> = _resultFuelPrices

    fun getFuelPrices() {
        viewModelScope.launch {
            _resultFuelPrices.postValue(executeUseCase(getFuelPricesUseCase))
        }
    }

}