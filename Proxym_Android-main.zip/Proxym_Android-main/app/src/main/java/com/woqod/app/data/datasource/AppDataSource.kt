package com.woqod.app.data.datasource

import com.woqod.app.data.models.*
import com.woqod.shared.commundata.models.NotificationsResponse
import com.woqod.shared.commundata.models.PagingResult
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.woqode.data.models.AccountInquiry


interface AppDataSource {

    suspend fun getFahesStations(): WoqodResult<SharedResponse<List<FahesStationResponse>>>
    suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<PetrolStationResponse>>>
    suspend fun postRatingStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<SuperMarketsResponse>>>
    suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceResponse>>>
    suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsResponse>>>

    suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiry>
    suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsResponse>>>

    suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<TendersResponse>>>

    suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>>
    suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>>

    suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getOtp(request : HashMap<String , String>) : WoqodResult<SharedResponse<Boolean>>
    suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>

    suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>>

    suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getNewsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NewsResponse>>>
    suspend fun incrementNewsViews(id: Long): WoqodResult<SharedResponse<Boolean>>

    suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerResponse>>>
    suspend fun getHomeAds() : WoqodResult<SharedResponse<List<HomeAdsResponse>>>
    suspend fun getHomeBusinessSection() : WoqodResult<SharedResponse<List<HomeBusinessSectionResponse>>>

    suspend fun getAppTips(device : String) : WoqodResult<SharedResponse<List<AppTipsResponse>>>
    suspend fun getStockPrices():WoqodResult<SharedResponse<List<StockPricesResponse>>>
    suspend fun getStockPricesFromEuroland():WoqodResult<SharedResponse<StockPricesEurolandResponse>>
    suspend fun getHasNotif(request: HashMap<String, Any>):WoqodResult<SharedResponse<Boolean>>
    suspend fun logout(request: HashMap<String, Any>):WoqodResult<SharedResponse<Boolean>>
}