package com.woqod.app.presentation.menu

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.Animation.INFINITE
import android.view.animation.Animation.REVERSE
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.woqod.account.presentation.personalinformation.UserProfileFragment
import com.woqod.account.presentation.personalinformation.UserProfileOtpFragment
import com.woqod.app.R
import com.woqod.app.databinding.ActivityMainBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.domain.models.NewsModel
import com.woqod.app.domain.models.PromotionsModel
import com.woqod.app.domain.models.TendersModel
import com.woqod.app.presentation.biometric.BiometricFragment
import com.woqod.app.presentation.bulk_lpg.BulkLpgFragment
import com.woqod.app.presentation.fuel_prices.FuelPricesFragment
import com.woqod.app.presentation.home.HomeFragment
import com.woqod.app.presentation.locations.LocationsFragment
import com.woqod.app.presentation.locations.map_filter.MapFilterFragment
import com.woqod.app.presentation.news.NewsFragment
import com.woqod.app.presentation.news.NewsFragmentDetails
import com.woqod.app.presentation.notifications.BONotificationFragment
import com.woqod.app.presentation.notifications.NotificationsFragment
import com.woqod.app.presentation.notifications.registerDevice
import com.woqod.app.presentation.notifications.survey.NotificationSurveyFragment
import com.woqod.app.presentation.notifications.unregisterDevice
import com.woqod.app.presentation.otp.OtpFragment
import com.woqod.app.presentation.promotions.PromotionsFragment
import com.woqod.app.presentation.promotions.PromotionsFragmentDetails
import com.woqod.app.presentation.settings.SettingsFragment
import com.woqod.app.presentation.static_screens.AboutWoqodFragment
import com.woqod.app.presentation.static_screens.PrivacyPolicyFragment
import com.woqod.app.presentation.static_screens.TermsOfUseFragment
import com.woqod.app.presentation.static_screens.contact_Us.ContactUsFragment
import com.woqod.app.presentation.stock_prices.StockPricesFragment
import com.woqod.app.presentation.tenders.TendersDetailsFragment
import com.woqod.app.presentation.tenders.TendersFragment
import com.woqod.app.presentation.utils.*
import com.woqod.authentication.presentation.UserChallengeHandler
import com.woqod.authentication.presentation.forget_password.ForgetPasswordFragment
import com.woqod.authentication.presentation.login.LoginFragment
import com.woqod.authentication.presentation.register.RegisterFirstStepFragment
import com.woqod.authentication.presentation.register.RegisterSecondStepFragment
import com.woqod.authentication.presentation.register.RegisterThirdStepFragment
import com.woqod.fahes.cache.FahesCache
import com.woqod.fahes.domain.models.UserCancelReservationModel
import com.woqod.fahes.presentation.about.AboutFahesFragment
import com.woqod.fahes.presentation.booking.*
import com.woqod.fahes.presentation.inspection_payment.payment.FahesPaymentFragment
import com.woqod.fahes.presentation.inspection_payment.payment.FahesReceiptFragment
import com.woqod.fahes.presentation.inspection_payment.pre_registration.*
import com.woqod.fahes.presentation.inspection_report.details.InspectionDetailsFragment
import com.woqod.fahes.presentation.inspection_report.list_cars.FahesInspectionReportFragment
import com.woqod.fahes.presentation.inspection_tips.InspectionTipsFragment
import com.woqod.fahes.presentation.list_receipts.ListReceiptsFragment
import com.woqod.fahes.presentation.menu.FahesMenuFragment
import com.woqod.fahes.presentation.utils.FahesBookingNavigationModel
import com.woqod.fahes.presentation.utils.FahesNavigationModel
import com.woqod.fahes.presentation.utils.FahesPreRegisterNavigationModel
import com.woqod.fahes.presentation.utils.FahesReceiptNavigationModel
import com.woqod.feedback.presentation.details_feedback.DetailsFeedbackFragment
import com.woqod.feedback.presentation.form_feedback.FeedbackFormFragment
import com.woqod.feedback.presentation.list_feedback.ListFeedbackFragment
import com.woqod.feedback.presentation.menu.FeedbackFragment
import com.woqod.shafaf.presentation.about.AboutShafafFragment
import com.woqod.shafaf.presentation.menu.ShafafFragment
import com.woqod.shafaf.presentation.retailers.ShafafRetailersFragment
import com.woqod.shared.baseui.*
import com.woqod.shared.commun.*
import com.woqod.shared.commun.SideMenuItem.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundomain.models.*
import com.woqod.shared.utils.*
import com.woqod.shared.utils.LanguageUtils.Companion.ARABIC
import com.woqod.shared.utils.LanguageUtils.Companion.ENGLISH
import com.woqod.shared.widget.slidesidemenu.SlideSideMenuTransitionLayout
import com.woqod.woqode.data.models.WoqodeArgsModel
import com.woqod.woqode.data.models.WoqodeReceiptNavigationModel
import com.woqod.woqode.domain.models.AccountInquiryModel
import com.woqod.woqode.domain.models.AccountInquiryResultModel
import com.woqod.woqode.presentation.about.AboutWoqodeFragment
import com.woqod.woqode.presentation.menu.WoqodeFragment
import com.woqod.woqode.presentation.receipt.WoqodeReceiptFragment
import com.woqod.woqode.presentation.topup.WoqodeTermsOfUseFragment
import com.woqod.woqode.presentation.topup.WoqodeTopupFragment
import com.woqod.woqode.presentation.topup.WoqodeTopupGuestFragment
import com.woqod.woqode.presentation.transaction_history.TransactionHistoryFragment
import timber.log.Timber
import java.io.Serializable

const val message = "Not included in Release 1"

class MenuActivity : BaseViewModelActivity<MainViewModel, ActivityMainBinding>(),
    View.OnClickListener,
    SlideSideMenuTransitionLayout.SlideSideMenuStateListener {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: MainViewModel by injectViewModel()
    override fun getViewBinding() = ActivityMainBinding.inflate(layoutInflater)

    private val homeButtonAnimation: Animation = AlphaAnimation(
        HOME_BUTTON_ANIM_MIN_ALPHA,
        HOME_BUTTON_ANIM_MAX_ALPHA
    )

    override fun initViews() {
        appComponent.inject(this)

        binding.layoutContentMain.imgBottomBarLang.setImageResource(if (languageUtils.isArabicLanguage()) R.drawable.ic_lang else R.drawable.ic_bottom_bar_lang)
        updateSideMenu()
        setClickListeners()
        setToolbar()
        setHomeButtonAnimation()
        registerDevice(this)
        registerFragmentsCallback()
        mfpPushReceived(intent) // handle navigation from notification when app is in background or closed
    }

    private fun mfpPushReceived(intent: Intent?) {
        intent?.extras?.apply {
            when {
                containsKey(PUSH_SURVEY) -> {
                       goToFragment(NotificationSurveyFragment().newInstance(get(PUSH_SURVEY) as PushNotificationModel),true)

                }
                containsKey(PUSH_FEEDBACK) -> {
                    goToFragment(
                        DetailsFeedbackFragment().newInstance(get(PUSH_FEEDBACK) as FeedbackModel),
                        true
                    )
                }
                containsKey(PUSH_FAHES) -> {
                    viewModel.navigate(
                        Navigation.FAHES_USER_CAR_LIST,
                        FahesNavigationModel(isBooking = false)
                    )
                }
                containsKey(PUSH_BO) -> {
                    goToFragment(
                        BONotificationFragment().newInstance( get(PUSH_BO) as PushNotificationModel),
                        true
                    )


                }
                containsKey(TO_MENU_FRAGMENT) -> {
                    viewModel.logout(hashMapOf(DEVICE_ID to sharedPreferences.deviceId))
                }
            }
        }
            ?: goToFragment(HomeFragment.newInstance(hashMapOf(FRAGMENT_SOURCE to HOME_FROM_SPLASH)))
    }

    private fun setToolbar() {
        binding.root.setSideMenuStateListener(this)
    }

    private fun setHomeButtonAnimation() {
        with(homeButtonAnimation) {
            duration = HOME_BUTTON_ANIM_DURATION
            startOffset = HOME_BUTTON_ANIM_OFFSET
            repeatMode = REVERSE
            repeatCount = INFINITE
        }
        binding.layoutContentMain.imgBottomBarHome.animation = homeButtonAnimation
    }

    private fun updateSideMenu() {
        with(binding.layoutSideMenu) {

            tvMenuWelcome.text = getString(R.string.MenuWelcome)
            tvMenuLogin.text = getString(R.string.MenuLogin)
            tvMenuRegister.text = getString(R.string.MenuRegister)
            tvMenuResetPassword.text = getString(R.string.MenuResetPassword)
            recyclerMenu.adapter =
                MenuAdapter(getMenuData()) { menuItem -> onMenuItemClicked(menuItem) }
            sharedPreferences.user?.let {
                groupMenuGuest.hide()
                groupMenuLoggedIn.show()
                tvMenuUsername.text = it.fullName()
                imgMenuUser.loadUserPicture(
                    sharedPreferences.userPhoto,
                    activity = this@MenuActivity
                )
            } ?: run {
                groupMenuGuest.show()
                groupMenuLoggedIn.hide()

            }
            if (languageUtils.isArabicLanguage()) {
                clMenuProfile.layoutDirection = View.LAYOUT_DIRECTION_RTL
            } else {
                clMenuProfile.layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
        }
    }

    private fun setClickListeners() {
        with(binding.layoutContentMain) {
            imgBottomBarNotification.setOnClickListener(this@MenuActivity)
            imgBottomBarHome.setOnClickListener(this@MenuActivity)
            imgBottomBarBalance.setOnClickListener(this@MenuActivity)
            imgBottomBarFeedback.setOnClickListener(this@MenuActivity)
            imgBottomBarLang.setOnClickListener(this@MenuActivity)
        }

        with(binding.layoutSideMenu) {
            tvMenuLogin.setOnClickListener(this@MenuActivity)
            tvMenuRegister.setOnClickListener(this@MenuActivity)
            tvMenuResetPassword.setOnClickListener(this@MenuActivity)
            imgMenuClose.setOnClickListener(this@MenuActivity)
            imgMenuUser.setOnClickListener(this@MenuActivity)
            tvMenuUsername.setOnClickListener(this@MenuActivity)
        }
    }

    private fun onMenuItemClicked(item: SideMenuModel) {

        when (item.id.name) {
//            getString(R.string.MenuRentAShop) -> WOQOD_RENT_SHOP_LINK.openLink(this)
            BUKLPG.name -> goToFragment(BulkLpgFragment())
            ABOUT_US.name -> goToFragment(AboutWoqodFragment())
            PRIVACY_POLICY.name -> goToFragment(
                PrivacyPolicyFragment().newInstance(
                    hashMapOf(FROM_REGISTRATION to false)
                )
            )
            TERMS_AND_CONDITIONS.name -> goToFragment(
                TermsOfUseFragment().newInstance(
                    hashMapOf(FROM_REGISTRATION to false)
                )
            )
            CONTACT_US.name -> goToFragment(ContactUsFragment())
            SETTINGS.name -> goToFragment(SettingsFragment())
            LOGOUT.name -> viewModel.logout(hashMapOf(DEVICE_ID to sharedPreferences.deviceId))
            else -> Timber.e("position drawer ${item.id.name}")
        }
    }

    override fun finishSession() {
        FahesCache.clear()
        unregisterDevice()
        sharedPreferences.user = null
        updateSideMenu()
        try {
            UserChallengeHandler.getInstance()?.let {
                it.cancel()
            }
            UserChallengeHandler.getIsChallenged().postValue(false)
            UserChallengeHandler.errorStatusCode = SingleLiveEvent()
        } catch (e: Exception) {
            Timber.e(e.message)
        }
        goToFragment(HomeFragment.newInstance(hashMapOf(FRAGMENT_SOURCE to HOME_FROM_LOGOUT)))

    }

    override fun onClick(view: View?) {
        when (view) {
            binding.layoutSideMenu.imgMenuClose -> {
                toggleSideMenu()
            }
            binding.layoutSideMenu.imgMenuUser, binding.layoutSideMenu.tvMenuUsername -> {
                goToFragment(UserProfileFragment())
            }
            binding.layoutSideMenu.tvMenuResetPassword -> {
                toggleSideMenu()
                viewModel.navigate(Navigation.OTP, hashMapOf(OTP_SOURCE to OTP_FOR_RESET))
            }
            binding.layoutSideMenu.tvMenuLogin -> {
                toggleSideMenu()
                viewModel.navigate(destination = Navigation.LOGIN, null)
            }
            binding.layoutSideMenu.tvMenuRegister -> {
                toggleSideMenu()
                viewModel.navigate(destination = Navigation.REGISTER_STEP1, null)
            }
            binding.layoutContentMain.imgBottomBarHome -> {
                goToFragment(HomeFragment.newInstance(hashMapOf(FRAGMENT_SOURCE to HOME_FROM_BOTTOM_BAR)))
            }
            binding.layoutContentMain.imgBottomBarNotification -> {
                goToFragment(NotificationsFragment())
            }
            binding.layoutContentMain.imgBottomBarLang -> {
                languageUtils.setSelectedLocale(
                    this,
                    if (languageUtils.isArabicLanguage()) ENGLISH else ARABIC
                )
                this.relaunchFragment(binding.layoutContentMain.fragmentMenuContainer.id)
                updateMenu()
                binding.layoutContentMain.imgBottomBarLang.setImageResource(if (languageUtils.isArabicLanguage()) R.drawable.ic_lang else R.drawable.ic_bottom_bar_lang)
            }
            binding.layoutContentMain.imgBottomBarBalance -> {
                getAccountBalance()
            }
            binding.layoutContentMain.imgBottomBarFeedback -> {
                navigateToFeedback()
            }
        }
    }

    private fun navigateToFeedback() {
        if (sharedPreferences.isUserLoggedIn()) {
            goToFragment(FeedbackFragment())
        } else {
            goToFragment(FeedbackFormFragment())
        }
    }

    override fun initObservers() {
        viewModel.resultBalanceInquiry.observe(this) {
            it.result?.let { accountInquiry ->
                val isWoqode =
                    accountInquiry.envelope.body.accountInquiryResponse.accountInquiryResult.responseGeneral.responseCode == "1"
                sharedPreferences.user?.let {
                    hashMapOf<String, Any>(
                        QID to it.qid,
                        MOBILE to it.mobileNumber,
                        ISWOQODE to isWoqode
                    ).also { query -> viewModel.updateWoqodeUser(query) }
                }
                onGetBalanceSuccess(accountInquiry)
            }
            it.error?.let { _ ->
                goToFragment(AboutWoqodeFragment())
                //togglePopUp(error)
            }
        }

        NotificationsStatusPin.getInstance().notificationStatusPin.observe(this) {
            it.result?.let { hasNotif ->
                if (hasNotif)
                    binding.layoutContentMain.imgBottomBarNotification.setImageResource(R.drawable.ic_notification_badge)
                else binding.layoutContentMain.imgBottomBarNotification.setImageResource(
                    R.drawable.ic_bottom_bar_inactive_notif
                )
            }
            it.error?.let { binding.layoutContentMain.imgBottomBarNotification.setImageResource(R.drawable.ic_bottom_bar_inactive_notif) }
        }

        viewModel.resultLogout.observe(this) {
            it.result?.let { isLoggedOut -> if (isLoggedOut) logout() }
            it.error?.let { error -> togglePopUp(message = error) }
        }

    }


    private fun getAccountBalance() {
        sharedPreferences.user?.let {
            hashMapOf<String, Any>(
                QID to it.qid,
                MOBILE to it.mobileNumber
            ).also { query -> viewModel.getBalanceInquiry(query) }
        } ?: goToFragment(WoqodeTopupGuestFragment())
    }

    private fun onGetBalanceSuccess(account: AccountInquiryModel) {
        with(account.envelope.body.accountInquiryResponse.accountInquiryResult) {
            navigateToWoqodeTopUp(this)
        }
    }

    private fun navigateToWoqodeTopUp(accountInquiryResultModel: AccountInquiryResultModel) {
        when {
            sharedPreferences.isUserLoggedIn() && accountInquiryResultModel.responseGeneral.responseCode == "1" -> {
                goToFragment(
                    WoqodeTopupFragment().newInstance(
                        WoqodeArgsModel(
                            accountInquiryResultModel,
                            null
                        )
                    )
                )
            }
            sharedPreferences.guestMode -> {
                goToFragment(WoqodeTopupGuestFragment())
            }

            else -> goToFragment(AboutWoqodeFragment())

        }
    }

    /**
     * To update SideMenu and AppOrientation after languageChange instead of using recreate() which causes the loss of the backStack.
     */
    private fun updateMenu() {
        setAppOrientation()
        updateSideMenu()
    }

    private fun logout() {
        unregisterDevice()
        FahesCache.clear()
        sharedPreferences.userPhoto = ""
        sharedPreferences.user = null
        updateSideMenu()
        UserChallengeHandler.getInstance().logout()
        registerDevice(this)
        goToFragment(HomeFragment.newInstance(hashMapOf(FRAGMENT_SOURCE to HOME_FROM_LOGOUT)))
    }

    private fun goToFragment(fragment: BaseFragment<*>?,recreateFragment:Boolean = false) {
        binding.root.closeSideMenu()
        fragment?.let {
            replaceFragment(it, R.id.fragment_menu_container,recreateFragment = recreateFragment)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        mfpPushReceived(intent)
    }

    private fun getMenuData(): List<SideMenuModel> {
        val listMenu = ArrayList<SideMenuModel>()

        listMenu.add(
            SideMenuModel(
                ABOUT_US,
                getString(R.string.MenuAboutUs),
                R.drawable.ic_menu_item_about
            )
        )
        listMenu.add(
            SideMenuModel(
                PRIVACY_POLICY,
                getString(R.string.MenuPrivacyPolicy),
                R.drawable.ic_menu_item_privacypolicy
            )
        )
        if (!sharedPreferences.isUserLoggedIn()) {
            listMenu.add(
                SideMenuModel(
                    TERMS_AND_CONDITIONS,
                    getString(R.string.MenuTermsOfUse),
                    R.drawable.ic_menu_item_termofuse
                )
            )
        }
        listMenu.add(
            SideMenuModel(
                CONTACT_US,
                getString(R.string.MenuContactUs),
                R.drawable.ic_menu_item_contactus
            )
        )
        listMenu.add(
            SideMenuModel(
                BUKLPG,
                getString(R.string.MenuBulk),
                R.drawable.ic_bulk_lpg_side_menu
            )
        )

        listMenu.add(
            SideMenuModel(
                SETTINGS,
                getString(R.string.MenuSettings),
                R.drawable.ic_menu_item_settings
            )
        )
        if (sharedPreferences.isUserLoggedIn()) {
            listMenu.add(SideMenuModel(BLANK, "", 0))
            listMenu.add(
                SideMenuModel(
                    LOGOUT,
                    getString(R.string.MenuLogout),
                    R.drawable.ic_menu_item_logout
                )
            )
        }

        return listMenu
    }

    override fun onSideMenuOpened() {
        hideKeyboard()
        updateSideMenu()
    }

    override fun onSideMenuClosed() {
        hideKeyboard()
    }

    override fun onSideMenuFirstReveal() {
        hideKeyboard()
    }

    @Suppress("UNCHECKED_CAST")
    override fun handleNavigation(navigation: Navigation, entity: Serializable?) {
        updateSideMenu()
        if (navigation == Navigation.MENU) {
            toggleSideMenu()
            return
        }
        val destination = when (navigation) {
            Navigation.HOME -> entity?.let { HomeFragment.newInstance(it as HashMap<String, String>) }
            Navigation.ABOUT_US -> AboutWoqodFragment()
            Navigation.PRIVACY_POLICY -> PrivacyPolicyFragment()
            Navigation.TERMS_AND_CONDITIONS -> TermsOfUseFragment()
            Navigation.LOGIN -> entity?.let { LoginFragment().newInstance(it as HashMap<String, String>) }
            Navigation.OTP -> entity?.let { OtpFragment().newInstance(it as HashMap<String, String>) }
            Navigation.BIOMETRIC -> entity?.let { BiometricFragment().newInstance(it as BiometricNavEntity) }
            Navigation.REGISTER_STEP1 -> RegisterFirstStepFragment()
            Navigation.REGISTER_STEP2 -> RegisterSecondStepFragment()
            Navigation.REGISTER_STEP3 -> RegisterThirdStepFragment()
            Navigation.FORGET_PWD -> entity?.let { ForgetPasswordFragment().newInstance(it as HashMap<String, String>) }
            Navigation.NEWS -> NewsFragment()
            Navigation.NEWS_DETAILS -> entity?.let { NewsFragmentDetails().newInstance(it as NewsModel) }
            Navigation.PROMOTION -> PromotionsFragment()
            Navigation.PROMOTION_DETAILS -> entity?.let { PromotionsFragmentDetails().newInstance(it as PromotionsModel) }
            Navigation.FAHES -> FahesMenuFragment()
            Navigation.SETTINGS -> SettingsFragment()
            Navigation.RELAUNCH_SETTINGS -> {
                this.relaunchFragment(binding.layoutContentMain.fragmentMenuContainer.id)
                updateMenu()
                null
            }
            Navigation.MAP -> entity?.let { LocationsFragment().newInstance(it as MapNavigationModel) }
            Navigation.MAP_FILTER -> entity?.let { MapFilterFragment.newInstance(it as MapFilterNavigationModel) }
            Navigation.TERMS_OF_CONDITIONS -> entity?.let { TermsOfUseFragment().newInstance(it as HashMap<String, Boolean>) }
            Navigation.PRIVACY_AND_POLICY -> entity?.let { PrivacyPolicyFragment().newInstance(it as HashMap<String, Boolean>) }
            Navigation.FUEL -> entity?.let { FuelPricesFragment().newInstance(it as MutableList<FuelPriceModel>) }
            Navigation.FAHES_GUEST_PRE_REGISTRATION -> FahesGuestPreRegisterFragment()
            Navigation.FAHES_PRE_REGISTRATION_CONFIRMATION -> entity?.let {
                FahesPreRegisterConfirmFragment().newInstance(
                    it as FahesPreRegisterNavigationModel
                )
            }
            Navigation.FAHES_PAYMENT -> FahesPaymentFragment()
            Navigation.FAHES_USER_CAR_LIST -> entity?.let { UserVehicleListFragment().newInstance(it as FahesNavigationModel) }
            Navigation.FAHES_BOOKING_CAR_INFO -> entity?.let {
                FahesBookingCarInfoFragment().newInstance(
                    it as UserInspectionRequestModel
                )
            }
            Navigation.FAHES_OTP -> entity?.let { FahesBookingOtpFragment().newInstance(it as FahesBookingNavigationModel) }
            Navigation.FAHES_BOOKING_DATE -> entity?.let { FahesBookingDateFragment().newInstance(it as FahesBookingNavigationModel) }
            Navigation.FAHES_RECEIPT -> entity?.let { FahesReceiptFragment().newInstance(it as FahesReceiptNavigationModel) }
            Navigation.FAHES_INSPECTION_REPORT -> FahesInspectionReportFragment()
            Navigation.FAHES_INSPECTION_REPORT_DETAILS -> entity?.let {
                InspectionDetailsFragment().newInstance(
                    it as CarModel
                )
            }
            Navigation.FAHES_RECEIPT_LIST -> ListReceiptsFragment()
            Navigation.FAHES_CANCEL_BOOKING -> entity?.let {
                FahesCancelModifyBooking().newInstance(
                    it as UserCancelReservationModel
                )
            }
            Navigation.FAHES_CANCEL_BOOKING_LIST -> FahesCancelModifyBookingList()
            Navigation.FAHES_REGISTRATION_CONFIRMATION -> entity?.let {
                CarRegistrationConfirmationFragment().newInstance(
                    it as FahesNavigationModel
                )
            }
            Navigation.FAHES_REGISTRATION_CONFIRMATION_OTP -> entity?.let {
                FahesPreRegistrationOtpFragment().newInstance(
                    it as FahesNavigationModel
                )
            }
            Navigation.FAHES_CR_GUEST -> FahesCancelModifyGuest()
            Navigation.ABOUT_SHAFAF -> AboutShafafFragment()
            Navigation.SHAFAF -> ShafafFragment()
            Navigation.SHAFAF_RETAILERS -> ShafafRetailersFragment()
            Navigation.ABOUT_FAHES -> AboutFahesFragment()
            Navigation.INSPECTION_TIPS -> InspectionTipsFragment()
            Navigation.STOCK_PRICES -> StockPricesFragment()
            Navigation.WOQODE -> entity?.let { WoqodeFragment().newInstance(it as HashMap<String, Boolean>) }
            Navigation.ABOUT_WOQODE -> AboutWoqodeFragment()
            Navigation.WOQODE_TOPUP -> entity?.let { WoqodeTopupFragment().newInstance(it as WoqodeArgsModel) }
            Navigation.WOQODE_TOPUP_GUEST -> WoqodeTopupGuestFragment()
            Navigation.WOQODE_TRANSACTION_HISTORY -> TransactionHistoryFragment()
            Navigation.WOQODE_RECEIPT -> entity?.let { WoqodeReceiptFragment().newInstance(entity as WoqodeReceiptNavigationModel) }
            Navigation.WOQODE_TERMS_OF_USE -> WoqodeTermsOfUseFragment()
            Navigation.FEEDBACK_DETAILS -> entity?.let { DetailsFeedbackFragment().newInstance(it as FeedbackModel) }
            Navigation.FEEDBACK_HISTORY -> ListFeedbackFragment()
            Navigation.FEEDBACK_FORM -> FeedbackFormFragment()
            Navigation.FEEDBACK_MENU -> FeedbackFragment()
            Navigation.USER_PROFILE -> UserProfileFragment()
            Navigation.USER_PROFILE_OTP -> entity?.let { UserProfileOtpFragment().newInstance(it as HashMap<String, String>) }
            Navigation.BULK_LPG -> BulkLpgFragment()
            Navigation.SURVEY -> entity?.let { NotificationSurveyFragment().newInstance(entity as PushNotificationModel) }
            Navigation.BO_NOTIF -> entity?.let { BONotificationFragment().newInstance(entity as PushNotificationModel) }
            Navigation.NOTIFICATION -> NotificationsFragment()
            Navigation.TENDERS -> entity?.let { TendersFragment().newInstance(it as HashMap<String, Boolean>) }
            Navigation.TENDER_DETAILS -> entity?.let { TendersDetailsFragment().newInstance(entity as TendersModel)  }
            else -> throw IllegalArgumentException("navigation to $navigation is not allowed!")

        }
        destination?.let { goToFragment(it) }
    }

    private fun toggleSideMenu() {
        binding.root.toggle()
    }

    private fun registerFragmentsCallback() {
        supportFragmentManager.registerFragmentLifecycleCallbacks(object :
            FragmentManager.FragmentLifecycleCallbacks() {
            override fun onFragmentViewCreated(
                fm: FragmentManager, f: Fragment, v: View, savedInstanceState: Bundle?
            ) {
                handleFahesBackground(f)
                when {
                    f is FeedbackFormFragment && !sharedPreferences.isUserLoggedIn() -> {
                        toggleBottomBar(true)
                    }
                    f is AboutWoqodeFragment && !sharedPreferences.isFromWoqode -> {
                        toggleBottomBar(show = true)
                    }
                    f::class.java.name in noBottomBarFragmentList -> {
                        toggleBottomBar(show = false)
                    }

                    f is LocationsFragment -> {
                        toggleBottomBar(show = true)
                        binding.layoutContentMain.viewSeparator.hide()
                    }

                    else -> {
                        NotificationsStatusPin.getInstance().scrollTotOpHomeScreen.postValue(true)
                        toggleBottomBar(show = true)
                    }
                }
            }
        }, true)
    }

    fun toggleBottomBar(show: Boolean) {
        with(binding.layoutContentMain) {
            if (show) {
                groupBottomMenu.show()
                imgBottomBarHome.animation = homeButtonAnimation
            } else {
                groupBottomMenu.hide()
                imgBottomBarHome.clearAnimation()
            }
        }
    }

    private fun handleFahesBackground(fragment: Fragment) {
        if (fragment::class.java.name in FahesFragmentList) {
            binding.layoutContentMain.root.background =
                this.loadDrawable(R.drawable.fahes_background)
        } else {
            binding.layoutContentMain.root.background =
                this.loadDrawable(R.drawable.bg_activity_main)
        }
    }

}