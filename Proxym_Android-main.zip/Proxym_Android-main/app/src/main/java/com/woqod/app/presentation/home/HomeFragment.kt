package com.woqod.app.presentation.home

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.doOnLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.SCROLL_STATE_IDLE
import com.woqod.app.R
import com.woqod.app.databinding.FragmentHomeBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.*
import com.woqod.app.domain.models.HomeBannerAppRedirection.*
import com.woqod.app.presentation.home.adapter.*
import com.woqod.app.presentation.utils.FUEL_FALLBACK_VALUE
import com.woqod.fahes.presentation.utils.FahesNavigationModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commundomain.models.MapNavigationModel
import com.woqod.shared.commundomain.models.UserInspectionRequestModel
import com.woqod.shared.utils.*
import com.woqod.shared.widget.VideoComponent
import com.woqod.shared.widget.phone_numbers_dialog.PhoneNumbersDialog
import com.woqod.woqode.data.models.WoqodeArgsModel
import com.woqod.woqode.domain.models.AccountInquiryModel
import timber.log.Timber
import java.io.Serializable
import kotlin.math.abs


class HomeFragment :
    BaseViewModelFragment<HomeViewModel, FragmentHomeBinding>(FragmentHomeBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: HomeViewModel by injectViewModel()
    private val phoneNumbersList =
        listOf(CONTACT_PHONE_NUMBER, FREE_CUSTOMER_SERVICE_NUMBER)
    private val container: ViewGroup by lazy { activity.findViewById<View>(android.R.id.content) as ViewGroup }

    private val topBannerHandler: Handler = Handler(Looper.getMainLooper())
    private val adsHandler: Handler = Handler(Looper.getMainLooper())

    private var params: HashMap<String, String>? = null
    private var topBannerItems = mutableListOf(HomeTopBannerModel())
    private var adsItems = mutableListOf(HomeAdsModel())

    private lateinit var topBannerSlideRunnable: Runnable
    private lateinit var topBannerSlideBackRunnable: Runnable
    private lateinit var adsSlideRunnable: Runnable
    private lateinit var adsSlideBackRunnable: Runnable
    private var woqodeArgsModel: WoqodeArgsModel? = null

    private val homeTopBannerAdapter: HomeTopBannerAdapter by lazy {
        HomeTopBannerAdapter(topBannerItems, ::handleTopBannerClick)
    }

    private val fuelBannerAdapter: HomeFuelBannerAdapter by lazy {
        HomeFuelBannerAdapter(getFallBackFuelList()) {
            viewModel.navigate(Navigation.FUEL, it as Serializable)
        }
    }

    private val homeBusinessAdapter: HomeBusinessAdapter by lazy {
        HomeBusinessAdapter(mutableListOf()) { position ->
            onItemBusinessClicked(position)
        }
    }
    private val homeAdsAdapter: HomeAdsAdapter by lazy {
        HomeAdsAdapter(adsItems, ::handleAdsBannerClick)
    }

    private val homeBusinessDetailsAdapter: HomeBusinessDetailsAdapter by lazy {
        HomeBusinessDetailsAdapter(mutableListOf(),
            { item -> handleBusinessPagerClick(item) },
            { position -> onItemReadMoreClicked(position) }
        )
    }

    private lateinit var videoComponent: VideoComponent
    private var homeServicesAdapter: HomeServicesAdapter? =
        null // not using by lazy to be able to re-initialize list after language change

    companion object {
        private var instance: HomeFragment? = null
        private var reloadData: Boolean = false
        fun newInstance(params: HashMap<String, String>): HomeFragment {
            val args = Bundle()
            args.putSerializable(HOME_ARGS, params)
            when (instance) {
                null -> {
                    instance = HomeFragment()
                    reloadData = true
                }
                else -> {
                    reloadData = false
                }
            }
            if (instance?.arguments == null)
                instance?.arguments = args
            else {
                instance?.arguments?.putAll(args)
            }

            return instance!!
        }
    }

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            if (it.containsKey(HOME_ARGS))
                params = it.getSerializable(HOME_ARGS) as HashMap<String, String>
        }
        videoComponent = VideoComponent(requireContext()).apply {
            container.addView(this)
            hide()
        }
        setClickListeners()
        initTopBanner()
        initFuelBanner()
        initServices()
        initAdsBanner()
        initBusinessSection()
        initBusinessDetailsSection()
        initHomeData()
        binding.swipeRefresh.setOnRefreshListener {
            reloadData = true
            initHomeData()
            resetBussinessWithWoqod()
            binding.swipeRefresh.isRefreshing = false

        }
        viewModel.getHasNotif(
            hashMapOf(
                DEVICE to sharedPreferences.deviceId,
                CONNECTED to sharedPreferences.isUserLoggedIn()
            )
        )
    }

    private fun initHomeData() {
        if (reloadData) {
            viewModel.getHomeTopBannerList()
            viewModel.getFuelPrices()
            viewModel.getHomeAdsList()
            viewModel.getHomeBusinessSectionList()
        }
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
    }


    @SuppressLint("ClickableViewAccessibility")
    private fun setClickListeners() {
        binding.toolbarHome.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }

        makeShareButtonDraggable()
        with(binding) {
            woqodShareFab.setOnClickListener { openSocialMediaContainer() }

            woqodSocialMediaShareFb.setOnClickListener { FACEBOOK_LINK.openLink(activity) }
            woqodSocialMediaShareTwitter.setOnClickListener { TWITTER_LINK.openLink(activity) }
            woqodSocialMediaShareYoutube.setOnClickListener { YOUTUBE_LINK.openLink(activity) }
            woqodSocialMediaShareInstagram.setOnClickListener { INSTAGRAM_LINK.openLink(activity) }
            woqodSocialMediaShareLinkedin.setOnClickListener { LINKEDIN_LINK.openLink(activity) }
            woqodSocialMediaCallCenter.setOnClickListener { openPhoneNumbersDialog(phoneNumbersList) }
            root.setOnClickListener { with(woqodSocialMediaShareContainer) { if (isVisible) hide() } }
        }

    }

    private fun openPhoneNumbersDialog(phoneNumbers: List<String>) {
        val phoneNumbersDialog = PhoneNumbersDialog(phoneNumbers) { it.makeCall(activity) }
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        activity.supportFragmentManager.findFragmentByTag(PHONE_NUMBERS_DIALOG_TAG)
            ?.let { fragmentTransaction.remove(it) }
            .also { fragmentTransaction.addToBackStack(null) }
        with(phoneNumbersDialog) { show(fragmentTransaction, PHONE_NUMBERS_DIALOG_TAG) }
    }

    private fun initTopBanner() {
        with(binding.pagerHomeTopBanner) {
            adapter = homeTopBannerAdapter
            offscreenPageLimit = 3
            //workaround for a bug in viewpager2 that prevent reading the attributes overScrollMode inside the xml
            (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            binding.indicatorHomeTopBanner.setViewPager2(this)
            topBannerSlideBackRunnable = Runnable {
                setCurrentItem(--currentItem, true)
            }
            topBannerSlideRunnable = Runnable {
                setCurrentItem(++currentItem, true)
            }
            setPageTransformer { page, position ->
                val offset: Float = position * -(125)
                val myOffset: Float = if (languageUtils.isArabicLanguage()) -offset else offset
                when {
                    position < -1 -> {
                        page.translationX = -myOffset
                    }
                    position <= 1 -> {
                        val scaleFactor =
                            0.7f.coerceAtLeast(1.17f - abs(position - 0.14285715f))
                        page.translationX = myOffset
                        Timber.i("setViewPagerBalance: $scaleFactor")
                        page.scaleY = scaleFactor
                        page.alpha = scaleFactor
                    }
                    else -> {
                        page.alpha = 0f
                        page.translationX = myOffset
                    }
                }
            }
            var increment = true
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)
                    if (currentItem >= topBannerItems.size - 1) {
                        increment = false

                    } else if (currentItem <= 0) {
                        increment = true
                    }
                    if (increment) {
                        topBannerHandler.removeCallbacks(topBannerSlideBackRunnable)
                        registerRunnable(topBannerSlideRunnable, topBannerHandler)
                    } else {
                        topBannerHandler.removeCallbacks(topBannerSlideRunnable)
                        registerRunnable(topBannerSlideBackRunnable, topBannerHandler)
                    }

                }
            })
        }
    }

    private fun registerRunnable(runnable: Runnable, handler: Handler) {
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 5000)
    }

    private fun initFuelBanner() {
        binding.recyclerHomeFuel.adapter = fuelBannerAdapter
    }

    private fun initServices() {
        homeServicesAdapter = HomeServicesAdapter(getHomeServiceList()) {
            redirectFromWoqodeService(it)
        }
        binding.recyclerHomeServices.adapter = homeServicesAdapter
    }

    private fun initAdsBanner() {
        with(binding) {
            pagerHomeAds.adapter = homeAdsAdapter
            //workaround for a bug in viewpager2 that prevent reading the attributes overScrollMode inside the xml
            (pagerHomeAds.getChildAt(0) as RecyclerView).overScrollMode =
                RecyclerView.OVER_SCROLL_NEVER
            indicatorHomeAdsPager.setViewPager2(binding.pagerHomeAds)
            pagerHomeAds.apply {
                adsSlideBackRunnable = Runnable {
                    setCurrentItem(--currentItem, true)
                }
                adsSlideRunnable = Runnable {
                    setCurrentItem(++currentItem, true)
                }

                var increment = true
                registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                    override fun onPageSelected(position: Int) {
                        super.onPageSelected(position)
                        if (currentItem >= adsItems.size - 1) {
                            increment = false

                        } else if (currentItem <= 0) {
                            increment = true
                        }
                        if (increment) {
                            adsHandler.removeCallbacks(adsSlideBackRunnable)
                            registerRunnable(adsSlideRunnable, adsHandler)
                        } else {
                            adsHandler.removeCallbacks(adsSlideRunnable)
                            registerRunnable(adsSlideBackRunnable, adsHandler)
                        }

                    }
                })
            }
        }
    }

    private fun navigateToFeedback() {
        if (sharedPreferences.isUserLoggedIn()) {
            viewModel.navigate(Navigation.FEEDBACK_MENU, null)
        } else {
            viewModel.navigate(Navigation.FEEDBACK_FORM, null)
        }
    }

    private fun initBusinessSection() {
        binding.recyclerHomeBusiness.adapter = homeBusinessAdapter
        /**
         * Handle the visibility of arrows
         */
        binding.recyclerHomeBusiness.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                try {
                    val lastVisiblePosition =
                        (recyclerView.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                    val firstVisiblePosition =
                        (recyclerView.layoutManager as LinearLayoutManager).findFirstCompletelyVisibleItemPosition()
                    if (lastVisiblePosition + 1 == homeBusinessAdapter.itemCount) {
                        binding.ivHomeBusinessArrowEnd.hide()
                    } else {
                        binding.ivHomeBusinessArrowEnd.show()
                    }
                    if (firstVisiblePosition == 0) {
                        binding.ivHomeBusinessArrowStart.hide()
                    } else {
                        binding.ivHomeBusinessArrowStart.show()
                    }
                } catch (exception: Exception) {
                    Timber.e(exception)
                }
            }
        })
    }

    private fun initBusinessDetailsSection() {
        binding.pagerHomeBusinessDetails.adapter = homeBusinessDetailsAdapter
        //workaround for a bug in viewpager2 that prevent reading the attributes overScrollMode inside the xml
        (binding.pagerHomeBusinessDetails.getChildAt(0) as RecyclerView).overScrollMode =
            RecyclerView.OVER_SCROLL_NEVER

        registerBusinessPagerCallback()
    }

    private fun getFallBackFuelList() = mutableListOf(
        FuelPriceModel(
            0L,
            0f,
            FUEL_FALLBACK_VALUE,
            FUEL_FALLBACK_VALUE,
            0L,
            0,
            FuelType.GASOLINE_PREMIUM,
            1
        ),
        FuelPriceModel(
            0L,
            0f,
            FUEL_FALLBACK_VALUE,
            FUEL_FALLBACK_VALUE,
            0L,
            0,
            FuelType.GASOLINE_SUPER,
            2
        ),
        FuelPriceModel(0L, 0f, FUEL_FALLBACK_VALUE, FUEL_FALLBACK_VALUE, 0L, 0, FuelType.DIESEL, 3)
    )

    private fun getHomeServiceList() = mutableListOf(
        ServiceModel(
            WOQODE,
            R.drawable.ic_home_service_woqode,
            getString(R.string.HomeServiceWoqode)
        ),
        ServiceModel(
            HomeBannerAppRedirection.FAHES,
            R.drawable.ic_home_service_fahes,
            getString(R.string.HomeServiceFahes)
        ),
        ServiceModel(
            LOCATION, R.drawable.ic_home_service_location, getString(
                R.string.HomeServiceLocations
            )
        ),
        ServiceModel(
            APP_CONTENT_STOCK_PRICES,
            R.drawable.ic_home_service_stockprices,
            getString(
                R.string.HomeServiceStockPrices
            )
        ),
        ServiceModel(
            SHAFAF,
            R.drawable.ic_home_service_shafaf,
            getString(R.string.HomeServiceShafaf)
        ),
        ServiceModel(
            APP_CONTENT_NEWS,
            R.drawable.ic_home_service_news,
            getString(R.string.HomeServiceNews)
        )
    )

    private fun sortTopBanners(list: List<HomeTopBannerModel>): List<HomeTopBannerModel> {
        val sortedBannerList = arrayListOf<HomeTopBannerModel>()
        sortedBannerList.addAll(list.filter { it.orderItem.toInt() > 0 }.sortedBy { it.orderItem })
        sortedBannerList.addAll(list.filter { it.orderItem.toInt() == 0 })
        return sortedBannerList
    }


    private fun sortAdsBanners(list: List<HomeAdsModel>): List<HomeAdsModel> {
        val sortedBannerList = arrayListOf<HomeAdsModel>()
        sortedBannerList.addAll(list.filter { it.orderItem > 0 }.sortedBy { it.orderItem })
        sortedBannerList.addAll(list.filter { it.orderItem == 0 })
        return sortedBannerList
    }

    private fun scrollHomeScreenTOTOp(scrollTop: Boolean) {
        if (scrollTop) binding.nestedScrollHome.smoothScrollTo(0, binding.root.top)

    }

    private fun onGetFuelPricesSuccess(result: List<FuelPriceModel>) {
        if (result.isNotEmpty()) fuelBannerAdapter.updateList(result.sortedBy { item -> item.itemOrder })
        else fuelBannerAdapter.updateList(
            getFallBackFuelList()
        )
    }

    override fun initObservers() {

        NotificationsStatusPin.getInstance().scrollTotOpHomeScreen.observe(viewLifecycleOwner) { scrollTop ->
            scrollHomeScreenTOTOp(scrollTop)
        }
        viewModel.resultHomeTopBanner.observe(viewLifecycleOwner, {
            it.result?.let { result ->
                OnGetTopBannerSuccess(result)
            }

        })

        viewModel.resultFuelPrices.observe(viewLifecycleOwner, {
            it.result?.let { result ->
                onGetFuelPricesSuccess(result)
            }

        })

        viewModel.resultHomeAds.observe(viewLifecycleOwner, {
            it.result?.let { result ->
                onGetAdsBannerSuccess(result)
            }
        })

        viewModel.resultHomeBusiness.observe(viewLifecycleOwner, {
            it.result?.let { result ->
                onGetBusinessSectionSuccess(result)
            }
        })

        viewModel.resulBookingStatus.observe(this, {
            it.result?.let { reservationStatus ->
                handleFahesBannerRedirection(
                    source = reservationStatus.second ?: HomeBannerAppRedirection.FAHES,
                    isHidden = reservationStatus.first ?: true
                )
            }
            it.error?.let {
                handleFahesBannerRedirection(
                    source = HomeBannerAppRedirection.FAHES,
                    isHidden = true
                )
            }
        })

        viewModel.resultBalanceInquiry.observe(this) {
            it.result?.let { accountInquiry -> onGetBalanceSuccess(accountInquiry) }
            it.error?.let {
                sharedPreferences.isFromWoqode = false
                viewModel.navigate(Navigation.ABOUT_WOQODE, null) }
        }

    }

    private fun onGetBalanceSuccess(result: Pair<AccountInquiryModel?, Boolean>) {
        val isWoqodeUser =
            result.first?.let {
                it.envelope.body.accountInquiryResponse.accountInquiryResult.responseGeneral.responseCode == "1"
            } ?: false
        sharedPreferences.user = sharedPreferences.user?.copy(isWoqodeUser= true,accountInquiryModel = result.first)
        woqodeArgsModel = result.first?.let {
            WoqodeArgsModel(it.envelope.body.accountInquiryResponse.accountInquiryResult, null)
        }
        sharedPreferences.user?.let {
            hashMapOf<String, Any>(
                QID to it.qid,
                MOBILE to it.mobileNumber,
                ISWOQODE to isWoqodeUser
            ).also { query -> viewModel.updateWoqodeUser(query) }
        }
        when {
            isWoqodeUser && !result.second -> viewModel.navigate(
                Navigation.WOQODE,
                hashMapOf(FROM_HOME to true)
            )
            isWoqodeUser && result.second -> viewModel.navigate(
                Navigation.WOQODE_TOPUP,
                woqodeArgsModel
            )
            else -> {
                sharedPreferences.isFromWoqode = false
                viewModel.navigate(Navigation.ABOUT_WOQODE, null)
            }

        }
    }

    private fun handleFahesBannerRedirection(source: HomeBannerAppRedirection, isHidden: Boolean) {
        when (source) {
            FAHES_CANCEL_MODIFY_BOOKING -> {
                navigateToFahesCr(isHidden)
            }

            FAHES_ONLINE_PAYMENT -> {
                navigateToFahesPayment(isHidden)
            }

            FAHES_BOOK_VEHICLE_INSPECTION -> navigateToFahesBooking(isHidden)
            else -> viewModel.navigate(Navigation.FAHES, null)
        }

    }

    private fun onGetBusinessSectionSuccess(result: List<HomeBusinessSectionModel>) {
        if (result.isEmpty()) {
            binding.bussinessWithWoqodGruop.hide()
        } else {
            binding.bussinessWithWoqodGruop.show()
            val sortedList = result.sortedBy { item -> item.orderItem }
            homeBusinessAdapter.updateList(sortedList)
            homeBusinessDetailsAdapter.updateList(sortedList)
        }
    }

    private fun onGetAdsBannerSuccess(result: List<HomeAdsModel>) {
        if (result.isEmpty()) {
            binding.pagerHomeAds.hide()
            binding.indicatorHomeAdsPager.hide()
        } else {
            binding.pagerHomeAds.show()
            binding.indicatorHomeAdsPager.show()
            adsItems = (sortAdsBanners(result)).toMutableList()
            homeAdsAdapter.updateList(adsItems)
            binding.indicatorHomeAdsPager.setViewPager2(binding.pagerHomeAds)
        }
    }

    private fun handleTopBannerClick(item: HomeTopBannerModel) {
        if (item.fileTypeEnum == HomeBannerFileType.VIDEO) {
            item.fileUrl?.let { openVideoPopUp(it) }
        } else {
            item.redirectionTypeEnum?.let {
                if (item.redirectionTypeEnum == HomeBannerRedirectionType.URL) {
                    item.redirectionPath?.let { redirectToWebView(it) }
                } else {
                    item.appRedirection?.let { redirectToServiceFromBanners(it) }
                }
            }
        }
    }

    private fun OnGetTopBannerSuccess(result: List<HomeTopBannerModel>) {
        if (result.isEmpty()) {
            binding.pagerHomeTopBanner.hide()
            binding.indicatorHomeTopBanner.hide()
        } else {
            binding.pagerHomeTopBanner.show()
            binding.indicatorHomeTopBanner.show()
            topBannerItems = (sortTopBanners(result)).toMutableList()
            homeTopBannerAdapter.updateList(topBannerItems)
            binding.indicatorHomeTopBanner.setViewPager2(binding.pagerHomeTopBanner)
        }
    }

    private fun handleAdsBannerClick(item: HomeAdsModel) {
        if (item.fileTypeEnum == HomeBannerFileType.VIDEO) {
            item.fileUrl?.let { openVideoPopUp(it) }
        } else {
            item.redirectionTypeEnum?.let {
                if (item.redirectionTypeEnum == HomeBannerRedirectionType.URL) {
                    item.redirectionPath?.let { redirectToWebView(it) }
                } else {
                    item.appRedirection?.let { redirectToServiceFromBanners(it) }
                }
            }
        }
    }

    private fun openVideoPopUp(url: String) {
        if (isAdded) {
            videoComponent.show()
            videoComponent.initVideoComponent(activity, url) { error ->
                activity.toast(error)
            }
        }
    }

    private fun redirectToWebView(url: String) {
        try {
            val browserIntent: Intent =
                if (url.contains("http://") || url.contains("https://")) {
                    Intent(Intent.ACTION_VIEW, Uri.parse(url))
                } else {
                    Intent(Intent.ACTION_VIEW, Uri.parse("http://$url"))
                }
            startActivity(browserIntent)
        } catch (exception: ActivityNotFoundException) {
            Timber.e("Redirect to external browser: $exception")
        }
    }

    private fun handleWoqodeServiceRedirection(isFromBanner: Boolean, fromTopUp: Boolean = true) {
        when {
            (sharedPreferences.guestMode || isFromBanner && !sharedPreferences.isUserLoggedIn())&& !fromTopUp  -> {
                viewModel.navigate(Navigation.WOQODE, null)
            }
            (sharedPreferences.guestMode || isFromBanner && !sharedPreferences.isUserLoggedIn()) && fromTopUp -> {
                viewModel.navigate(Navigation.WOQODE_TOPUP_GUEST, null)
            }

            sharedPreferences.isUserLoggedIn() || (isFromBanner && sharedPreferences.isUserLoggedIn()) -> sharedPreferences.user?.let {
                hashMapOf<String, Any>(
                    QID to it.qid,
                    MOBILE to it.mobileNumber
                ).also { query -> viewModel.getBalanceInquiry(query, fromTopUp) }
            }
            else -> {
                viewModel.navigate(
                    Navigation.LOGIN, hashMapOf(
                        FRAGMENT_SOURCE to LOGIN_FROM_WOQODE
                    )
                )
            }
        }
    }

    private fun redirectFromWoqodeService(service: HomeBannerAppRedirection) {
        when (service) {
            WOQODE -> {
                handleWoqodeServiceRedirection(false, fromTopUp = false)
            }
            HomeBannerAppRedirection.FAHES -> {
                if (sharedPreferences.isUserLoggedIn() || sharedPreferences.guestMode) {
                    viewModel.navigate(Navigation.FAHES, null)
                } else {
                    viewModel.navigate(
                        Navigation.LOGIN,
                        hashMapOf(FRAGMENT_SOURCE to LOGIN_FROM_FAHES)
                    )
                }
            }
            LOCATION -> {
                viewModel.navigate(
                    Navigation.MAP,
                    MapNavigationModel(LocationRedirection.FROM_PETROL)
                )
            }
            APP_CONTENT_NEWS -> viewModel.navigate(Navigation.NEWS, null)
            SHAFAF -> viewModel.navigate(
                Navigation.SHAFAF,
                null
            )

            APP_CONTENT_STOCK_PRICES -> viewModel.navigate(
                Navigation.STOCK_PRICES,
                null
            )

        }
    }

    private fun navigateToFahesCr(isHidden: Boolean) {
        when {
            sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(Navigation.FAHES_CANCEL_BOOKING_LIST, null)
            }
            !sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(Navigation.FAHES_CR_GUEST, null)
            }
            else -> viewModel.navigate(Navigation.FAHES, null)
        }

    }

    private fun navigateToFahesBooking(isHidden: Boolean) {
        when {
            sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(
                    Navigation.FAHES_USER_CAR_LIST,
                    FahesNavigationModel(isBooking = true)
                )
            }
            !sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(
                    Navigation.FAHES_BOOKING_CAR_INFO,
                    UserInspectionRequestModel("", "", "", "", 0, "")
                )
            }
            else -> viewModel.navigate(Navigation.FAHES, null)
        }

    }

    private fun navigateToFahesPayment(isHidden: Boolean) {
        when {
            sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(
                    Navigation.FAHES_USER_CAR_LIST,
                    FahesNavigationModel(isBooking = false)
                )
            }
            !sharedPreferences.isUserLoggedIn() && !isHidden -> {
                viewModel.navigate(Navigation.FAHES_GUEST_PRE_REGISTRATION, null)
            }
            else -> viewModel.navigate(Navigation.FAHES, null)
        }

    }


    private fun redirectToServiceFromBanners(service: HomeBannerAppRedirection) {
        when (service) {
            WOQODE -> {
                handleWoqodeServiceRedirection(true, fromTopUp = false)
            }
            WOQODE_TOPUP -> {
                handleWoqodeServiceRedirection(true, fromTopUp = true)
            }

            ABOUT_WOQODE -> {
                sharedPreferences.isFromWoqode = false
                viewModel.navigate(Navigation.ABOUT_WOQODE, null)
            }

            HomeBannerAppRedirection.FAHES -> {
                viewModel.navigate(Navigation.FAHES, null)
            }

            FAHES_CANCEL_MODIFY_BOOKING -> {
                viewModel.getBookingStatus(FAHES_CANCEL_MODIFY_BOOKING)
            }

            FAHES_ONLINE_PAYMENT -> {
                viewModel.getBookingStatus(FAHES_ONLINE_PAYMENT)
            }

            FAHES_BOOK_VEHICLE_INSPECTION -> viewModel.getBookingStatus(
                FAHES_BOOK_VEHICLE_INSPECTION
            )
            FAHES_STATIONS -> viewModel.navigate(
                Navigation.MAP,
                MapNavigationModel(LocationRedirection.FROM_FAHES)
            )
            FAHES_INSPECTION_TIPS -> viewModel.navigate(Navigation.INSPECTION_TIPS, null)
            ABOUT_FAHES -> viewModel.navigate(Navigation.ABOUT_FAHES, null)
            LOCATION -> {
                viewModel.navigate(
                    Navigation.MAP,
                    MapNavigationModel(LocationRedirection.FROM_PETROL)
                )
            }
            APP_CONTENT_NEWS -> viewModel.navigate(Navigation.NEWS, null)
            SHAFAF -> viewModel.navigate(
                Navigation.SHAFAF,
                null
            )
            SHAFAF_SUPERMARKETS ->
                viewModel.navigate(
                    Navigation.MAP,
                    MapNavigationModel(LocationRedirection.FROM_SHAFAF)
                )

            SHAFAF_RETAILERS -> viewModel.navigate(
                Navigation.SHAFAF_RETAILERS,
                null
            )
            ABOUT_SHAFAF -> viewModel.navigate(
                Navigation.ABOUT_SHAFAF,
                null
            )

            APP_CONTENT_STOCK_PRICES -> viewModel.navigate(
                Navigation.STOCK_PRICES,
                null
            )
            APP_CONTENT_PROMOTIONS -> viewModel.navigate(
                Navigation.PROMOTION,
                null
            )
            FEEDBACK -> navigateToFeedback()
            APP_CONTENT_TENDER -> viewModel.navigate(Navigation.TENDERS,
                hashMapOf(FROM_HOME to true)
            )
            APP_CONTENT_BULK_LPG -> viewModel.navigate(Navigation.BULK_LPG, null)
            APP_ABOUT_WOQOD -> viewModel.navigate(Navigation.ABOUT_US, null)
            REGISTRATION -> viewModel.navigate(Navigation.REGISTER_STEP1, null)
            APP_PRIVACY_POLICY -> viewModel.navigate(Navigation.PRIVACY_POLICY, null)
            APP_TERMS_OF_USE -> viewModel.navigate(Navigation.TERMS_AND_CONDITIONS, null)
        }
    }

    private fun handleBusinessPagerClick(item: HomeBusinessSectionModel) {
        if (item.redirectionTypeEnum == HomeBannerRedirectionType.URL) {
            item.redirectionPath?.let { redirectToWebView(it) }
        } else {
            item.appRedirection?.let { redirectToServiceFromBanners(it) }
        }
    }

    private var businessDetailsPagerPosition = 0
    private var isItemSelectionEnabled = false
    private fun registerBusinessPagerCallback() {
        binding.pagerHomeBusinessDetails.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                businessDetailsPagerPosition = position
                homeBusinessAdapter.selectItem(position)
                binding.recyclerHomeBusiness.smoothScrollToPosition(position)


            }

            override fun onPageScrollStateChanged(state: Int) {
                //Wait for Pager to settle before starting to configure height
                if (state == SCROLL_STATE_IDLE) {
                    adjustHomeBusinessDetailsSize()
                }
            }
        })
    }

    private fun adjustHomeBusinessDetailsSize() {
        val view =
            (binding.pagerHomeBusinessDetails.getChildAt(0) as RecyclerView).layoutManager?.findViewByPosition(
                businessDetailsPagerPosition
            )

        // Make viewPager's height wrap content
        view?.doOnLayout { current ->
            binding.pagerHomeBusinessDetails.doOnLayoutWithHeight<ConstraintLayout.LayoutParams>(
                current
            )
        }
    }

    private val businessPagerHandler = Handler(Looper.getMainLooper())
    private val businessDetailsPagerHandler = Handler(Looper.getMainLooper())
    private fun onItemBusinessClicked(position: Int) {
        if (!binding.pagerHomeBusinessDetails.isVisible) {
            binding.pagerHomeBusinessDetails.show()

            businessPagerHandler.postDelayed({
                binding.pagerHomeBusinessDetails.currentItem = position
                binding.recyclerHomeBusiness.smoothScrollToPosition(position)
                onItemReadMoreClicked(position)
            }, 200)
        } else {
            businessPagerHandler.postDelayed({
                binding.pagerHomeBusinessDetails.currentItem = position
                binding.recyclerHomeBusiness.smoothScrollToPosition(position)
                onItemReadMoreClicked(position)

            }, 200)
        }
        homeBusinessDetailsAdapter.notifyItemChanged(position)
        smoothScrollOnReadMore()
    }

    private fun smoothScrollOnReadMore() =
        businessDetailsPagerHandler.postDelayed({
            try {
                binding.nestedScrollHome.smoothScrollTo(0, binding.tvHomeBusiness.top, 2000)
            } catch (e: Exception) {
                TODO("Animation Exception")

            }
        }, 300)

    private fun onItemReadMoreClicked(position: Int) {
        val view = (binding.pagerHomeBusinessDetails.getChildAt(0) as RecyclerView)
            .layoutManager?.findViewByPosition(position)

        view?.post {
            binding.pagerHomeBusinessDetails.doOnLayoutWithHeight<ConstraintLayout.LayoutParams>(
                view
            )
        }


    }

    private fun makeShareButtonDraggable() {
        binding.woqodShareFab.makeDraggable { view ->
            val widgetMarginY = 17
            val viewParent = view.parent as View
            val xMiddle = (viewParent.width) / 2
            if (view.x > xMiddle) {
                binding.woqodSocialMediaShareContainer.x = view.x - 240.toPixel(resources)
            } else {
                binding.woqodSocialMediaShareContainer.x = view.x + 55.toPixel(resources)
            }
            binding.woqodSocialMediaShareContainer.y = view.y + widgetMarginY
        }
    }

    private fun openSocialMediaContainer() {
        with(binding.woqodSocialMediaShareContainer) {
            if (isVisible) hide() else show()
        }
    }

    override fun onBackPressCustomAction() {
        if (videoComponent.isVisible)
            videoComponent.releasePlayer(activity)
        else {
            videoComponent.releasePlayer(activity)
            instance = null
            activity.finish()
        }
    }

    override fun onPause() {
        super.onPause()
        videoComponent.releasePlayer(activity)
        releaseHandlers()
        topBannerHandler.removeCallbacks(topBannerSlideRunnable)
        topBannerHandler.removeCallbacks(topBannerSlideBackRunnable)
        topBannerHandler.removeCallbacks(adsSlideBackRunnable)
        topBannerHandler.removeCallbacks(adsSlideRunnable)
    }

    override fun onResume() {
        super.onResume()
        resetBussinessWithWoqod()
        topBannerHandler.postDelayed(topBannerSlideRunnable, 5000)
        topBannerHandler.postDelayed(adsSlideRunnable, 5000)
    }

    private fun resetBussinessWithWoqod() {
        homeBusinessAdapter.selectItem(-1)
        try {
            binding.recyclerHomeBusiness.smoothScrollToPosition(0)
        } catch (e: Exception) {
            TODO("Animation Exception")
        }
        binding.pagerHomeBusinessDetails.hide()
        initBusinessDetailsSection()

    }

    private fun releaseHandlers() {
        businessPagerHandler.removeCallbacksAndMessages(null)
        businessDetailsPagerHandler.removeCallbacksAndMessages(null)
    }

}