package com.woqod.app.presentation.news

import android.graphics.Paint
import android.os.Bundle
import coil.load
import com.woqod.app.R
import com.woqod.app.databinding.FragmentNewsDetailsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.NewsModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.utils.NEWS_DETAILS_ARGS


class NewsFragmentDetails : BaseViewModelFragment<NewsViewModel, FragmentNewsDetailsBinding>(
    FragmentNewsDetailsBinding::inflate
) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: NewsViewModel by injectViewModel()

    private var newsDetail: NewsModel? = null

    fun newInstance(params: NewsModel) =
        NewsFragmentDetails().apply {
            arguments = Bundle().apply {
                putSerializable(NEWS_DETAILS_ARGS, params)
            }
        }

    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            newsDetail = it.getSerializable(NEWS_DETAILS_ARGS) as NewsModel
        }
        initClickListeners()
        setUpView()
    }

    override fun initObservers() {
        viewModel.resultGetNewsViews.observe(this) {
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun setUpView() {

        with(binding) {
            newsDetail?.let { newsDetail ->

                viewModel.incrementNewsViews(newsDetail.id)

                tvNewsDetailsTitle.text =
                    if (languageUtils.isArabicLanguage()) newsDetail.titleArabic else newsDetail.title
                tvNewDetailsDesc.formatStringHtml(
                    if (languageUtils.isArabicLanguage()) newsDetail.detailsArabic
                    else newsDetail.details
                )
                newsDetail.detailsPicture?.let {
                    shimmerNewsDetails.load(
                        ivNewsDetail,
                        newsDetail.detailsPicture,
                        tvNewsDetailsImgError,
                        ivPlaceholder
                    )
                } ?: kotlin.run {
                    ivNewsDetail.load(R.drawable.ic_placeholder) {
                        transformations(coil.transform.RoundedCornersTransformation(33F))
                    }
                }

                tvNewsDetailDate.text = newsDetail.creationDate?.toFormattedDate(BIRTH_DATE_FORMAT)
                newsDetail.link?.let { link ->
                    if (link.isNotEmpty()) {
                        tvNewsDetailLink.apply {
                            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
                            text = context.getString(R.string.NewsDetailsClickForMore)
                            setOnClickListener {
                                link.openLink(activity)
                            }
                        }
                    }
                }
            }
        }
    }


    private fun initClickListeners() {
        binding.toolbarNewsDetail.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }
    }


}