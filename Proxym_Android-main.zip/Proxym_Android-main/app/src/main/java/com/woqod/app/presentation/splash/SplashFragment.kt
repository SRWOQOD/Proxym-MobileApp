package com.woqod.app.presentation.splash

import android.annotation.SuppressLint
import android.content.res.Resources
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import com.woqod.app.R
import com.woqod.app.databinding.FragmentSplashBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.presentation.applicationTips.ApplicationTipsFragment
import com.woqod.app.presentation.menu.MenuActivity
import com.woqod.app.presentation.utils.RootChecker
import com.woqod.authentication.presentation.UserChallengeHandler
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.extensions.launchActivity
import com.woqod.shared.commun.extensions.replaceFragment
import com.woqod.shared.utils.LanguageUtils
import com.worklight.common.security.WLDeviceAuthManager
import java.util.*

class SplashFragment :
    BaseViewModelFragment<SplashViewModel, FragmentSplashBinding>(FragmentSplashBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }
    private val logoAnimation: Animation = AlphaAnimation(0.0f, 1.0f)
    private var handler = Handler(Looper.getMainLooper())

    override val viewModel: SplashViewModel by injectViewModel()


    override fun initViews() {
        appComponent.inject(this)
        initLogoAnimation()
        verifyUserSession()
        getDefaultLanguage()
        disableDefaultBackPress(true)
        saveDeviceId()
    }

    private fun initLogoAnimation() {
        with(logoAnimation) {
            duration = 1000
            startOffset = 20
            repeatCount = Animation.ABSOLUTE
        }
        binding.ivSplashLogo.animation = logoAnimation
    }

    private fun setAnimatedBackground() {
        with(binding.videoSplashAnimation) {
            val path = "android.resource://" + activity.packageName + "/" + R.raw.video
            setVideoURI(Uri.parse(path))
            start()
        }
       if(!RootChecker.isRooted)
        handler.postDelayed({
            if (sharedPreferences.isFirstLaunch) {
                activity.replaceFragment(ApplicationTipsFragment(),R.id.fragment_launcher_container)
            }else
            activity.launchActivity<MenuActivity>(finish = true)
        }, 2500) else  togglePopUp(getString(R.string.rooted_device_message), action = {activity.finishAndRemoveTask()})

    }

    private fun verifyUserSession() {
        UserChallengeHandler.getInstance().getAuthAccessToken().observe(this) {
            if (it == null) sharedPreferences.user = null
        }
    }

    @SuppressLint("HardwareIds")
    private fun saveDeviceId() {
        if (sharedPreferences.deviceId.isEmpty()) {
            sharedPreferences.deviceId = WLDeviceAuthManager.getInstance().getDeviceUUID(activity)
        }
    }

    override fun onResume() {
        super.onResume()
        setAnimatedBackground()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacksAndMessages(null)
    }

    private fun getDefaultLanguage() {
        if (sharedPreferences.selectedLang.isEmpty()) {
            val savedLanguage: String
            val defaultLanguage = sharedPreferences.defaultLang
            val phoneLanguage =
                Resources.getSystem().configuration.locales[0].language.toUpperCase(Locale.ROOT)
            savedLanguage = if (defaultLanguage != phoneLanguage) {
                if (phoneLanguage !in languageUtils.getLanguagesData()) {
                    LanguageUtils.ENGLISH
                } else {
                    phoneLanguage
                }
            } else {
                defaultLanguage
            }
            languageUtils.setDefaultLocale(activity, savedLanguage.toLowerCase(Locale.ROOT))
        }
    }

    override fun onBackPressCustomAction() {
            activity.finish()
    }
}