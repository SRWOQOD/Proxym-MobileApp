package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


typealias GetFahesStationsBaseUseCase = BaseUseCase<WoqodResult<SharedResponse<List<MapStationModel>>>>

open class GetFahesStationsUseCase @Inject constructor(
    private val appRepository: AppRepository
) : GetFahesStationsBaseUseCase {

    override suspend operator fun invoke() =
        appRepository.getFahesStations()
}