package com.woqod.app.presentation.biometric

import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import androidx.lifecycle.Observer
import com.woqod.app.R
import com.woqod.app.databinding.FragmentSetBiometricBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.presentation.utils.LOGIN_WITH_BIO_EMPTY_PASSWORD
import com.woqod.authentication.presentation.UserChallengeHandler
import com.woqod.authentication.presentation.login.BiometricPromptUtils
import com.woqod.authentication.presentation.login.LoginWorkFlow
import com.woqod.authentication.utils.AuthenticationType
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PASSWORD
import com.woqod.shared.commun.TYPE
import com.woqod.shared.commun.USERNAME
import com.woqod.shared.commun.extensions.invisible
import com.woqod.shared.commun.extensions.setBackgroundTint
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundata.IPADDRESS
import com.woqod.shared.utils.*
import org.json.JSONObject

/**
 * BackPressed is des-activated inside BiometricFragment
 */
class BiometricFragment : BaseViewModelFragment<BiometricViewModel, FragmentSetBiometricBinding>(FragmentSetBiometricBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: BiometricViewModel by injectViewModel()

    private var params: BiometricNavEntity? = null

    fun newInstance(params: BiometricNavEntity): BiometricFragment {
        val args = Bundle()
        args.putSerializable(BIOMETRIC_ARGS, params)
        val fragment = BiometricFragment()
        fragment.arguments = args
        return fragment
    }

    private var cancelText: SpannableString? = null
    private var goToLoginText: SpannableString? = null

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            if (it.containsKey(BIOMETRIC_ARGS))
                params = it.getSerializable(BIOMETRIC_ARGS) as BiometricNavEntity
        }

        binding.toolbarBiometric.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU,null)
        }
        cancelText = SpannableString(getString(R.string.BiometricCancel))
        goToLoginText = SpannableString(getString(R.string.BiometricGoToLogin))
        cancelText?.setSpan(UnderlineSpan(), 0, cancelText?.length ?: 0, 0)
        goToLoginText?.setSpan(UnderlineSpan(), 0, goToLoginText?.length ?: 0, 0)

    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
        params?.let {
            if (it.isSuccess) {
                initSuccessViews()
            } else {
                initFailureViews()
            }
        } ?: initFailureViews()
    }

    private fun initSuccessViews() {
        with(binding) {
            tvBiometricDesc.text = getString(R.string.BiometricSuccessful)
            ivBiometric.setImageResource(R.drawable.ic_biometric_success)
            btnBiometricCancel.invisible()
            btnBiometricProceed.setBackgroundTint(activity, R.color.color_009933)
            btnBiometricProceed.text = getString(R.string.BiometricContinue)
            btnBiometricProceed.setOnClickListener {
                when (params?.source) {
                    BIOMETRIC_SOURCE_LOGIN -> {
                        loginUser()
                    }
                    BIOMETRIC_SOURCE_SETUP -> {
                        sharedPreferences.customPasswordForBiometric = sharedPreferences.user?.customIdentification ?: ""
                        params?.let{
                        if (it.isFromSettings) {
                            viewModel.navigate(Navigation.OTP, hashMapOf(OTP_SOURCE to OTP_FOR_BIOMETRIC))
                        } else {
                            viewModel.navigate(Navigation.OTP, hashMapOf(OTP_SOURCE to OTP_FOR_LOGIN_BIOMETRIC))
                        }}
                  /*      viewModel.updateBiometricStatus(
                            hashMapOf(
                                USERNAME to sharedPreferences.customPasswordForBiometric,
                                DEVICE_ID to sharedPreferences.deviceId
                            )
                        )*/
                    }
                    else -> {
                        viewModel.navigate(Navigation.SETTINGS, null)
                    }
                }
            }
        }
    }

    private fun initFailureViews(error: String = getString(R.string.BiometricFail)) {
        with(binding) {
            tvBiometricDesc.text = error
            btnBiometricProceed.setBackgroundTint(activity, R.color.color_B30839)
            btnBiometricProceed.text = getString(R.string.BiometricTryAgain)
            ivBiometric.setImageResource(R.drawable.ic_biometric_fail)

            if (params?.source == BIOMETRIC_SOURCE_LOGIN) {
                btnBiometricCancel.text = goToLoginText
                btnBiometricCancel.setOnClickListener {
                    viewModel.navigate(Navigation.LOGIN, null)
                }
            } else {
                btnBiometricCancel.text = cancelText
                btnBiometricCancel.setOnClickListener {
                    biometricCancelBtnAction()
                }
            }
            btnBiometricCancel.show()
            btnBiometricProceed.setOnClickListener {
                openBiometricNativeDialog()
            }
        }
    }

    private fun biometricCancelBtnAction(){
        params?.let {
            if(it.isFromSettings)  viewModel.navigate(Navigation.SETTINGS, null)
            else getProfilePhoto()
        }
    }

    /**
     * Re-open Biometric Dialog when click on Try Again
     */
    private fun openBiometricNativeDialog() {
        val biometricPrompt = BiometricPromptUtils.createBiometricPrompt(activity,
            processSuccess =
            {
                sharedPreferences.isBiometricActivated = true
                sharedPreferences.user = sharedPreferences.user?.copy(isBiometricActivated = sharedPreferences.isBiometricActivated)
                initSuccessViews()
            },
            processFailure = { error ->
                initFailureViews(error)
            }
        )
        val promptInfo = BiometricPromptUtils.createPromptInfo(activity)
        biometricPrompt.authenticate(promptInfo)
    }

    private fun getProfilePhoto() {
        sharedPreferences.user?.let {
            viewModel.getProfilePhoto(hashMapOf(USERNAME to it.userName))
        }
    }

    override fun initObservers() {


        viewModel.onGetProfilePhoto.observe(this, {
            it.result?.let { photo ->
                sharedPreferences.userPhoto = photo
                redirectionAfterProfilePhoto()
            } ?: redirectionAfterProfilePhoto()
            it.error?.let {
                redirectionAfterProfilePhoto()
            }
        })
    }

    private fun redirectionAfterProfilePhoto() {
        when (params?.source) {
            BIOMETRIC_SOURCE_LOGIN -> {
                if (!LoginWorkFlow.isRedirect) {
                    viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_BIOMETRIC))
                } else if (LoginWorkFlow.isFahes) {
                    viewModel.navigate(Navigation.FAHES, null)
                } else {
                    viewModel.navigate(Navigation.WOQODE, null)
                }
            }

            BIOMETRIC_SOURCE_SETUP ->  viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_BIOMETRIC))
        }
    }

    private fun loginUser() {
        toggleLoading(true)
        UserChallengeHandler.getInstance().login(getFingerPrintLoginCredentials()).observe(this, Observer(::manageLoginResult))
    }

    private fun getFingerPrintLoginCredentials(): JSONObject {
        val credentials = JSONObject()
        credentials.put(USERNAME, sharedPreferences.customPasswordForBiometric)
        credentials.put(PASSWORD, LOGIN_WITH_BIO_EMPTY_PASSWORD)
        credentials.put(TYPE, AuthenticationType.BIO_AUTH)
        credentials.put(DEVICE_ID, sharedPreferences.deviceId)
        credentials.put(IPADDRESS, getIpAddress())
        return credentials
    }

    private fun manageLoginResult(isLoginSuccessful: Boolean) {
        if (isLoginSuccessful) {
            getProfilePhoto()
        } else {
            toggleLoading(false)
            togglePopUp(getString(com.woqod.authentication.R.string.AuthenticationLoginLoginFail))
        }
    }

}