package com.woqod.app.presentation.static_screens

import android.os.Bundle
import androidx.annotation.DrawableRes
import com.woqod.app.R
import com.woqod.app.databinding.FragmentPrivacyPolicyBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.SideMenuItem.PRIVACY_POLICY
import com.woqod.shared.utils.FROM_REGISTRATION

class PrivacyPolicyFragment :
    BaseViewModelFragment<StaticScreenViewModel, FragmentPrivacyPolicyBinding>(
        FragmentPrivacyPolicyBinding::inflate
    ) {

    override val viewModel: StaticScreenViewModel by injectViewModel()
    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }
    private var isFromRegistration = false

    fun newInstance(params: HashMap<String, Boolean>) = PrivacyPolicyFragment().apply {
        arguments = Bundle().apply {
            putSerializable(FROM_REGISTRATION, params)
        }
    }

    override fun initViews() {
        appComponent.inject(this)
        disableDefaultBackPress(true)
        arguments?.let {
            isFromRegistration =
                (it.getSerializable(FROM_REGISTRATION) as HashMap<String, Boolean>)[FROM_REGISTRATION] == true
        }
        viewModel.getStaticText(PRIVACY_POLICY.name)
    }

    override fun handleFragmentArgs() {
        setUpToolBar()
    }


    override fun onBackPressCustomAction() {
        when (isFromRegistration) {
            true -> viewModel.navigate(Navigation.REGISTER_STEP3, null)
            else -> viewModel.navigate(Navigation.HOME, null)
        }

    }

    private fun setUpToolBar() {
        when (isFromRegistration) {
            true -> {
                initToolBarClick(R.drawable.ic_toolbar_arrow_back) {
                    activity.onBackPressed()
                }
            }
            else -> {
                initToolBarClick(R.drawable.ic_toolbar_open) {
                    viewModel.navigate(Navigation.MENU, null)
                }
            }
        }
    }


    private fun initToolBarClick(@DrawableRes image: Int, action: () -> Unit) {
        binding.toolbarPrivacyPolicy.btnToolbar.setImageResource(image)
        binding.toolbarPrivacyPolicy.btnToolbar.setOnClickListener {
            action()
        }
    }

    override fun initObservers() {
        viewModel.resultStaticScreen.observe(this) {
            it.result?.let { staticText ->
                binding.tvPrivacyPolicyDesc.loadStaticWebView(
                    staticText.content,
                    isArabicLanguage = languageUtils.isArabicLanguage()
                )
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }


}