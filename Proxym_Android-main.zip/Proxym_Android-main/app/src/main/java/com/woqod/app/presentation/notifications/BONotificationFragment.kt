package com.woqod.app.presentation.notifications

import android.os.Bundle
import com.ibm.mobilefirstplatform.clientsdk.android.push.internal.MFPPushConstants.DEVICE_ID
import com.woqod.app.databinding.FragmentBONotificationBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.NOTIFICATION_ID
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.UNIQUE_ID
import com.woqod.shared.commun.USERNAME
import com.woqod.shared.commun.extensions.textInHtml
import com.woqod.shared.commundomain.models.PushNotificationModel
import com.woqod.shared.utils.BO_ARGS
import com.woqod.shared.utils.FRAGMENT_SOURCE
import com.woqod.shared.utils.HOME_FROM_SPLASH

class BONotificationFragment :
    BaseViewModelFragment<NotificationsViewModel, FragmentBONotificationBinding>(
        FragmentBONotificationBinding::inflate
    ) {

    private var notificationBO: PushNotificationModel? = null
    override val viewModel: NotificationsViewModel by injectViewModel()
    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    fun newInstance(params: PushNotificationModel): BONotificationFragment {
        val args = Bundle()
        args.putSerializable(BO_ARGS, params)
        val fragment = BONotificationFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        appComponent.inject(this)
        toggleLoading(false)
        disableDefaultBackPress(true)
        arguments?.let {
            notificationBO = it.getSerializable(BO_ARGS) as PushNotificationModel
        }
        initClickListeners()
        initValues()
        notificationBO?.let { if (it.isFromNotification) updateNotification(it.uniqueId) }

    }

    private fun updateNotification(notificationUniqueId: String?) {
        if (sharedPreferences.isUserLoggedIn()) {
            notificationUniqueId?.let {
                viewModel.updateNotification(
                    hashMapOf(
                        DEVICE_ID to sharedPreferences.deviceId,
                        UNIQUE_ID to it,
                        NOTIFICATION_ID to it,
                        USERNAME to sharedPreferences.username,
                    )
                )
            }

        } else {
            notificationUniqueId?.let {
                viewModel.updateNotification(
                    hashMapOf(
                        DEVICE_ID to sharedPreferences.deviceId,
                        UNIQUE_ID to it,
                        NOTIFICATION_ID to it

                    )
                )
            }
        }

    }


    override fun onBackPressCustomAction() {
        backPressedBehavior()
    }

    private fun initValues() {
        notificationBO?.let {
            binding.tvBOTitle.text = it.getTitle().textInHtml()
            binding.tvBONotifDescp.text = it.getDescription().textInHtml()
        }
    }

    private fun backPressedBehavior() {

        notificationBO?.let {
            if (it.isFromNotification) {
                viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_SPLASH))
            } else viewModel.navigate(Navigation.NOTIFICATION, null)
        } ?: activity.onBackPressed()
    }

    private fun initClickListeners() {
        binding.toolbarBONotif.btnToolbar.setOnClickListener {
            backPressedBehavior()
        }

        binding.tvSubmit.setOnClickListener {
            backPressedBehavior()
        }
    }

}