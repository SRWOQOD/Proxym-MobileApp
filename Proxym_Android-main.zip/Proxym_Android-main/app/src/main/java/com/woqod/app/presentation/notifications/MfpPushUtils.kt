package com.woqod.app.presentation.notifications

import android.content.Context
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPush
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushException
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushResponseListener
import org.json.JSONObject
import timber.log.Timber


/**
 * Created by Hamdi.BOUMAIZA on 09/30/2020
 */

/**
 * register device for push notifications
 */
fun registerDevice(context : Context) {
    MFPPush.getInstance().initialize(context)
    MFPPush.getInstance().registerDevice(null, object : MFPPushResponseListener<String?> {
        override fun onSuccess(s: String?) {
            Timber.e("success $s")
            getTags()
        }

        override fun onSuccess(p0: JSONObject?) {
            Timber.e("Registered Successfully $p0")
            getTags()
        }

        override fun onFailure(e: MFPPushException) {
            Timber.e("Registered failed $e")
        }
    })
}
/**
 * unregister device for push notifications
 */
fun unregisterDevice() {
    MFPPush.getInstance().unregisterDevice( object : MFPPushResponseListener<String?> {
        override fun onSuccess(s: String?) {
            Timber.e("success $s")
            getTags()
        }

        override fun onSuccess(p0: JSONObject?) {
            Timber.e("UnRegistered Successfully $p0")
        }

        override fun onFailure(e: MFPPushException) {
            Timber.e("UnRegistered failed $e")
        }
    })
}

/**
 * get all tags from mfp
 */
fun getTags() {
    MFPPush.getInstance().getTags(object : MFPPushResponseListener<List<String?>?> {
        override fun onSuccess(strings: List<String?>?) {
            // Successfully retrieved tags as list of strings
            Timber.e("tags success $strings")
            strings?.let {
                subscribeToTags(strings.map { it.toString() }.toTypedArray())
            }
        }

        override fun onSuccess(p0: JSONObject?) {
            Timber.e("tags success $p0")
        }

        override fun onFailure(e: MFPPushException) {
            Timber.e("tags failed $e")
        }
    })
}

/**
 *subscribe to tags on mfp
 */
fun subscribeToTags(listTags: Array<String>) {
    MFPPush.getInstance().subscribe(listTags, object : MFPPushResponseListener<Array<String?>?> {
        override fun onSuccess(strings: Array<String?>?) {
            Timber.e("Subscribe success $strings")
        }

        override fun onSuccess(p0: JSONObject?) {
            Timber.e("Subscribed successfully $p0")
        }

        override fun onFailure(e: MFPPushException) {
            Timber.e("Subscribed failed $e")
        }
    })
}