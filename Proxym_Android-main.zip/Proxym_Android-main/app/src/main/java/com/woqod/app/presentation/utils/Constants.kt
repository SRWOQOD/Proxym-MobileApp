package com.woqod.app.presentation.utils

import com.google.android.gms.maps.model.LatLng

//Min and Max alpha for the home Button animation
const val HOME_BUTTON_ANIM_MIN_ALPHA = 0.33f
const val HOME_BUTTON_ANIM_MAX_ALPHA = 0.8f
const val HOME_BUTTON_ANIM_DURATION = 2500L
const val HOME_BUTTON_ANIM_OFFSET = 20L
const val MAX_LINE_BWW =3
//this const plays the role of password when trying to invoke mfp login after biometric authentication
const val LOGIN_WITH_BIO_EMPTY_PASSWORD = "LOGIN_WITH_BIO_EMPTY_PASSWORD"

const val INITIAL_HOME_BANNER_IMG_URL = "EMPTY"
const val FUEL_FALLBACK_VALUE = "--"
const val SIDRA_CATEGORY="Sidra"
const val MOBILE_PETROL_CATEGORY="WOQOD Mobile PS"
const val MARINE_CATEGORY="Marine"
const val Petrol_CATEGORY="WOQOD PS"

val QATAR_LOCATION = LatLng(25.3548, 51.1839)
const val MAP_ZOOM = 9f
const val MAP_ZOOM_FILTER = 9f
const val MAP_ICON_WIDTH_DP = 25
const val MAP_ICON_HEIGHT_DP = 32