package com.woqod.app.data.models

import com.woqod.app.domain.models.HomeBusinessSectionModel
import com.woqod.app.domain.models.getRedirectionAppType
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commundata.DomainMapper

/**
{
"iconTitle": "Test2",
"descriptionArabic": "<p>​عرض خاص لخدمات مختارة من 15 يوليو- 15 اكتوبر 2018</p><p>&#160;في محطة جنوب مسيمير فقط&#160;.</p><p>حماية السيارة_عازل حراري_التفاصيل الخارجية_التفاصيل الداخلية</p>",
"fileTypeEnum": null,
"iconTitleArabic": "وقودي",
"appRedirection": WOQODE,
"orderItem": "1",
"description": "As part of WOQOD's",
"active": true,
"redirectionTypeEnum": "URL",
"creationDate": 1624533343721,
"redirectionPath": "www.woqod.com",
"title": "test 2",
"uncheckedIconUrl": "https://ftp.proxym-group.net/woqod/20210624141542755icon2.PNG",
"titleArabic": "يوكوهاما",
"imageUrl": "https://ftp.proxym-group.net/woqod/20210624141542755.PNG",
"id": 31742,
"checkedIconUrl": "https://ftp.proxym-group.net/woqod/20210624141542755icon1.PNG",
"redirection": true
},
 */

data class HomeBusinessSectionResponse(
    val id: Long?,
    val orderItem: String?,
    val iconTitle: String?,
    val iconTitleArabic: String?,
    val uncheckedIconUrl: String?,
    val checkedIconUrl: String?,
    val imageUrl: String?,
    val title: String?,
    val titleArabic: String?,
    val description: String?,
    val descriptionArabic: String?,
    val redirectionTypeEnum: String?,
    val redirectionPath: String?,
    val redirectionArPath : String?,
    val appRedirection: String?
) : DomainMapper<HomeBusinessSectionModel> {
    override fun mapToDomainModel(): HomeBusinessSectionModel =
        HomeBusinessSectionModel(
            id = id ?: 0L,
            orderItem = orderItem ?: "0",
            iconTitle = iconTitle?:"",
            iconTitleArabic = iconTitleArabic?:"",
            uncheckedIconUrl = uncheckedIconUrl,
            checkedIconUrl = checkedIconUrl,
            imageUrl = imageUrl,
            title =  title ?: "",
            titleAr = titleArabic ?: "",
            description = description?: "",
            descriptionAr = descriptionArabic?: "",
            redirectionTypeEnum = mapToRedirectionType(redirectionTypeEnum),
            redirectionPath = if(WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage())redirectionArPath else redirectionPath,
            appRedirection = appRedirection?.let { getRedirectionAppType(it) }
        )
}
