package com.woqod.app.presentation.locations.map_filter


import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.children
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.woqod.app.R
import com.woqod.app.databinding.FragmentMapFilterBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.presentation.utils.getStationServicesList
import com.woqod.shared.WoqodApplication
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.LocationRedirection
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.models.MapFilterModel
import com.woqod.shared.commundomain.models.MapFilterNavigationModel
import com.woqod.shared.commundomain.models.MapNavigationModel
import com.woqod.shared.utils.MAPS_FILTER_ARGS
import com.woqod.shared.utils.ServiceStationType
import com.woqod.shared.widget.PopUpType
import timber.log.Timber

class MapFilterFragment :
    BaseViewModelFragment<MapFilterViewModel, FragmentMapFilterBinding>(FragmentMapFilterBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: MapFilterViewModel by injectViewModel()


    private var params: MapFilterNavigationModel? = null
    private var fromOrigin: String? = null
    private var listTitles: List<String> = listOf()

    private lateinit var listAreas: List<AreaModel>
    private var selectedZones: AreaModel? = null
    private var selectedServices: List<ServiceStationType>? = null
    private var serviceAdapter: MapFilterServicesAdapter? = null
    private fun initMapFilterServices() =
        MapFilterServicesAdapter(getStationServicesList(WoqodApplication.sharedComponent.context())) {
            // mapFilterModel?.services = it.map { item -> item.type }
            selectedServices = it.map { item -> item.type }
        }

    override fun initViews() {
        appComponent.inject(this)
            activity.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        if (params == null)
            handleFragmentArgs()
        if (newFilter) {
            binding.petrolStationChip.isChecked = true
            mapFilterModel?.isPetrolStationSelected = true
        }
        disableDefaultBackPress(true)
        viewModel.requestAreas()
            setClickListeners()

        handlePetrolStationFilter()
        initSliders()
        serviceAdapter = initMapFilterServices()
        initServicesRecyclerView()
        resetStatusVisivilityServices()
        resetPreviousFilterStatus()
    }

    override fun onBackPressCustomAction() {
        /*    serviceAdapter?.getCurrentServicesList()?.map { item -> item.type }
                ?.let { mapFilterModel?.services = it }*/
        goToLocationFragment()
    }

    private fun resetStatusVisivilityServices() {
        if (servicesAreVisible == true) binding.groupSearchByService.visibility =
            View.VISIBLE else binding.groupSearchByService.visibility = View.GONE
    }


    override fun handleFragmentArgs() {
        arguments?.let {
            params = it.getSerializable(MAPS_FILTER_ARGS) as MapFilterNavigationModel
        }
        fromOrigin = params?.fromOrigin
        listTitles = params?.listTitles ?: listOf()
    }

    private fun setClickListeners() {
        with(binding) {
            searchByServicesBtn.setOnClickListener {
                if (servicesAreVisible == false) {
                    setServicesVisibility(View.VISIBLE)
                } else {
                    setServicesVisibility(View.GONE)
                }
            }

       /*     searchByZonesBtn.setOnClickListener {
                if (zonesAreVisible == false) {
                    setZonesViewVisibility(View.VISIBLE)
                } else {
                    setZonesViewVisibility(View.GONE)
                }
            }*/


            searchBtn.setOnClickListener {
                binding.spinnerZone.hideSpinnerDropDown()
                startFilter()
            }

            toolbarMapFilter.btnToolbar.setOnClickListener {
                /*        serviceAdapter?.getCurrentServicesList()?.map { item -> item.type }
                            ?.let { mapFilterModel?.services = it }*/
                goToLocationFragment()
            }

            fahesStationChip.setOnClickListener {
                setStationClick()
            }
            sidraStationChip.setOnClickListener {
                setStationClick()
            }

            shafafSupermarketChip.setOnClickListener {
                setStationClick()
            }

            petrolStationChip.setOnClickListener {
                setStationClick()
            }
        }

    }

    private fun setStationClick() {
        with(binding) {
            if (!petrolStationChip.isChecked) {
                serviceAdapter?.setServicesStations(getStationServicesList(WoqodApplication.sharedComponent.context()))
                hideServicesBtn()
            } else {
                showServicesBtn()
            }

        }
    }

    private fun resetPreviousFilterStatus() {
        if (mapFilterModel?.isPetrolStationSelected != true) {
            serviceAdapter = initMapFilterServices()
            serviceAdapter?.notifyDataSetChanged()
            initServicesRecyclerView()
            hideServicesBtn()
        } else {
            showServicesBtn()

        }


    }


    private fun initSliders() {
        binding.tvMaxValueDistance.text = getString(R.string.MapFilterSliderMaxValueDistance)
        binding.tvMinValueDistance.text = getString(R.string.MapFilterSliderMinValueDistance)
        binding.sliderDistance.setLabelFormatter {
            "${it.toInt()} ${getString(R.string.CommonKM)}"
        }
        binding.sliderDistance.addOnChangeListener { _, _, _ ->
            //mapFilterModel?.range = value.toInt()
        }

        binding.sliderOpeningTime.addOnChangeListener { _, _, _ ->

        }

        binding.tvMaxValueOpeningTime.text = getString(R.string.MapFilterSliderMaxOpeningTimeValue)
        binding.tvMinValueOpeningTime.text = getString(R.string.MapFilterSliderMinOpeningTimeValue)
        binding.sliderOpeningTime.setLabelFormatter {
            when {
                it < 12 -> {
                    "${it.toInt()} ${getString(com.woqod.shared.R.string.CommonAm)}"
                }
                it.toInt() == 12 -> {
                    "${it.toInt()} ${getString(com.woqod.shared.R.string.CommonPm)}"
                }
                else -> {
                    "${it.toInt() - 12} ${getString(com.woqod.shared.R.string.CommonPm)}"
                }
            }
        }
    }

    private fun initServicesRecyclerView() {
        binding.rvMapFilterServices.adapter = serviceAdapter


        /**
         * Handle the visibility of arrows
         */
        binding.rvMapFilterServices.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                try {
                    val lastVisiblePosition =
                        (recyclerView.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                    val firstVisiblePosition =
                        (recyclerView.layoutManager as LinearLayoutManager).findFirstCompletelyVisibleItemPosition()
                    if (lastVisiblePosition + 1 == serviceAdapter?.itemCount) {
                        binding.ivMapFilterServiceArrowEnd.hide()
                    } else {
                        binding.ivMapFilterServiceArrowEnd.show()
                    }
                    if (firstVisiblePosition == 0) {
                        binding.ivMapFilterServiceArrowStart.hide()
                    } else {
                        binding.ivMapFilterServiceArrowStart.show()
                    }
                } catch (exception: Exception) {
                    Timber.e(exception)
                }
            }
        })
        mapFilterModel?.services?.let {
            val listStations = getStationServicesList(WoqodApplication.sharedComponent.context())
            it.forEach { station ->
                listStations.find { sationService -> sationService.type == station }?.isSelected =
                    true
            }
            serviceAdapter?.setServicesStations(listStations)

        }
    }

    private fun startFilter() {
        if (filteredChips(binding.constraintChipGroupStations).isEmpty())
            togglePopUp(
                getString(R.string.MapFilterErrorTextCheckPetrol),
                popUpType = PopUpType.POP_ERROR
            )
        else {
            putCheckedStations()
            serviceAdapter?.getCurrentServicesList()?.map { item -> item.type }
                ?.let { mapFilterModel?.services = it }
            goToLocationFragment()
        }
    }

    //setting checked chips to mapFilter Model
    private fun putCheckedStations() {
        binding.petrolStationChip.setOnCheckedChangeListener { _, _ ->
            hideServicesSection()
        }
        mapFilterModel?.isPetrolStationSelected = binding.petrolStationChip.isChecked
        mapFilterModel?.isSidraMarketSelected = binding.sidraStationChip.isChecked
        mapFilterModel?.isFahesStationSelected = binding.fahesStationChip.isChecked
        mapFilterModel?.isSuperMarketSelected = binding.shafafSupermarketChip.isChecked
        mapFilterModel?.isMobilePetrolSelected = binding.mobilePertolStation.isChecked
        mapFilterModel?.isMarineStationSelected = binding.marineStation.isChecked
        mapFilterModel?.range = binding.sliderDistance.value.toInt()
        if (binding.sliderOpeningTime.value.toInt() == 0)
            mapFilterModel?.openingHour = -1
        else
            mapFilterModel?.openingHour = binding.sliderOpeningTime.value.toInt()
        mapFilterModel?.zone = selectedZones
        selectedServices?.let { mapFilterModel?.services = it }

    }

    override fun onResume() {
        super.onResume()
        setOldFilter()
    }

    override fun initObservers() {
        viewModel.onRequestAreas.observe(this) {
            it.result?.let { result ->
                listAreas = result
                val initalListAreas = mutableListOf<String>()
                initalListAreas.add(getString(R.string.LocationAllZones))
                initalListAreas.addAll(result.map { area -> area.areaName() })
                initSpinner(initalListAreas)
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }



    //changing the visibility of services section
    private fun setServicesVisibility(visibility: Int) {
        binding.groupSearchByService.visibility = visibility
        servicesAreVisible = !(servicesAreVisible ?: false)
    }

    //navigation to location Fragment
    private fun goToLocationFragment() {
        servicesAreVisible= binding.groupSearchByService.isVisible
        viewModel.navigate(
            Navigation.MAP,
            MapNavigationModel(
                LocationRedirection.FROM_MAP_FILTER,
                fromOrigin,
                //  oldMapFilterModel,
                mapFilterModel,
                isBackFromFilter = true,
                isFromRating = params?.isFromRating?: false
            )
        )
    }

    //returns a list of checked chips
    private fun filteredChips(constraintLayout: ConstraintLayout): MutableList<String> {
        val checkedIds = ArrayList<Chip>()
        constraintLayout.children.forEach { chip ->
            if (chip is Chip && chip.isChecked) {
                checkedIds.add(chip)
            }
        }
        val titles = mutableListOf<String>()
        checkedIds.forEach { chip ->
            titles.add(chip.text.toString())
        }
        return titles
    }

    //hiding the section of services if it's visible and petrol station is unchecked
    private fun hideServicesSection() {
        if (!binding.petrolStationChip.isChecked && binding.groupSearchByService.isVisible) {
            setServicesVisibility(View.GONE)
        }
    }

    //hide chips in case the user came from fahes or shafaf menu
    private fun handlePetrolStationFilter() {
         // it is better to use strategy here
        when (fromOrigin) {
            LocationRedirection.FROM_FAHES -> {
                binding.chipGroupStations.hide()

                hideServicesBtn()
                // if we use strategy we will not need that
                initChipGroupToFahes()
                initMapFilterTofahes()
            }
            LocationRedirection.FROM_SHAFAF -> {
                binding.chipGroupStations.hide()
                hideServicesBtn()
                // if we use strategy we will not need that
                initChipGroupToShafaf()
                initMapFilterToShafaf()

            }

        }
    }

    private fun initChipGroupToShafaf() {
        binding.petrolStationChip.isChecked = false
        binding.fahesStationChip.isChecked = false
        binding.sidraStationChip.isChecked = false
        binding.mobilePertolStation.isChecked = false
        binding.marineStation.isChecked = false
        binding.shafafSupermarketChip.isChecked = true
    }

    private fun initChipGroupToFahes() {
        binding.petrolStationChip.isChecked = false
        binding.fahesStationChip.isChecked = true
        binding.sidraStationChip.isChecked = false
        binding.shafafSupermarketChip.isChecked = false
        binding.mobilePertolStation.isChecked = false
        binding.marineStation.isChecked = false
    }

    private fun initMapFilterToShafaf() {
        mapFilterModel?.isFahesStationSelected = false
        mapFilterModel?.isPetrolStationSelected = false
        mapFilterModel?.isSidraMarketSelected = false
        mapFilterModel?.isSuperMarketSelected = true
        mapFilterModel?.isMobilePetrolSelected = false
        mapFilterModel?.isMarineStationSelected = false
    }

    private fun initMapFilterTofahes() {
        mapFilterModel?.isFahesStationSelected = true
        mapFilterModel?.isPetrolStationSelected = false
        mapFilterModel?.isSidraMarketSelected = false
        mapFilterModel?.isSuperMarketSelected = false
        mapFilterModel?.isMobilePetrolSelected = false
        mapFilterModel?.isMarineStationSelected = false
    }

    private fun setOldFilter() {
        mapFilterModel?.isPetrolStationSelected?.let {
            binding.petrolStationChip.isChecked = it
        }
        mapFilterModel?.isFahesStationSelected?.let {
            binding.fahesStationChip.isChecked = it
        }
        mapFilterModel?.isSidraMarketSelected?.let {
            binding.sidraStationChip.isChecked = it
        }
        mapFilterModel?.isMobilePetrolSelected?.let {
            binding.mobilePertolStation.isChecked = it
        }
        mapFilterModel?.isMarineStationSelected?.let {
            binding.marineStation.isChecked = it
        }
        mapFilterModel?.isSuperMarketSelected?.let {
            binding.shafafSupermarketChip.isChecked = it
        }
        mapFilterModel?.range?.toFloat()?.let { binding.sliderDistance.value = it }
        mapFilterModel?.openingHour?.let {
            if (it == -1) binding.sliderOpeningTime.value = 0f else binding.sliderOpeningTime.value = it.toFloat()
        }

    }


    private fun hideServicesBtn() {
        binding.searchByServicesBtn.hide()
        setServicesVisibility(View.GONE)

    }

    private fun showServicesBtn() {
        binding.searchByServicesBtn.show()
    }

    //zone spinner initialisation
    private fun initSpinner(zones: List<String> = emptyList()) {
        binding.spinnerZone.initSpinner(activity,zones,isFilterable = true) {
          //  if (it == "All Areas" || it == "جميع المناطق")
            if (it == getString(R.string.LocationAllZones))
                selectedZones = null
            else
                for (item in listAreas) {
                    if (item.areaName() == it) {
                        selectedZones = item
                    }
                }
        }
        if (mapFilterModel?.zone == null)
            binding.spinnerZone.setSelection(getString(R.string.LocationAllZones), 0)
        else
            mapFilterModel?.zone?.areaName()
                ?.let { binding.spinnerZone.setSelection(it, zones.indexOf(it)) }
        binding.spinnerZone.filterSpinnerList()

    }

    companion object {
        private var instance: MapFilterFragment? = null
        private var newFilter: Boolean = true
        private var mapFilterModel: MapFilterModel? = null
        private var servicesAreVisible: Boolean? = null
        fun newInstance(params: MapFilterNavigationModel): MapFilterFragment {
            val args = Bundle()
            args.putSerializable(MAPS_FILTER_ARGS, params)
            when (instance) {
                null -> {
                    instance = MapFilterFragment()
                    mapFilterModel = MapFilterModel()
                    newFilter = true
                    servicesAreVisible = false
                }
                else -> {
                    newFilter = false
                }
            }
            if (instance?.arguments == null)
                instance?.arguments = args
            else {
                instance?.arguments?.putAll(args)
            }

            return instance!!
        }

        fun clearInstance() {
            instance = null
            mapFilterModel = MapFilterModel()
            newFilter = true
            servicesAreVisible = false

        }

        fun updateInstance(params: MapFilterNavigationModel) {
            val args = Bundle()
            args.putSerializable(MAPS_FILTER_ARGS, params)
            instance?.arguments?.putAll(args)
            newFilter = false

        }


    }

    override fun keyBoardState(isOpened: Boolean, keyboardHeight: Double) {
          if(isOpened) {
              binding.root.scrollBy(0,binding.root.height - keyboardHeight.toInt())
          }
    }
}

