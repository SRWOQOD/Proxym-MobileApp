package com.woqod.app.domain.models

import com.woqod.shared.commundomain.models.AreaModel

data class FahesStationModel(
    val workingDays: String,
    val secondAddress: String,
    val area: AreaModel?,
    val firstAddress: String,
    val fahesId: Int,
    val status: PetrolStationStatus,
    val serviceStations: List<ServiceStationModel>,
)