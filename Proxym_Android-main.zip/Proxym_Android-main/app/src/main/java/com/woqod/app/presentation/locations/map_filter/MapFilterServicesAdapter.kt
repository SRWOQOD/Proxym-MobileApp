package com.woqod.app.presentation.locations.map_filter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.ItemStationServiceBinding
import com.woqod.app.presentation.utils.getServiceNameByType
import com.woqod.shared.commun.extensions.invisible
import com.woqod.shared.commun.extensions.loadDrawable
import com.woqod.shared.commun.extensions.textColor
import com.woqod.shared.utils.ServiceStationType

class MapFilterServicesAdapter(
    private var serviceStations: List<MapFilterServiceModel>,
    private val action: (List<MapFilterServiceModel>) -> Unit
) : RecyclerView.Adapter<MapFilterServicesAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(
            ItemStationServiceBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(serviceStations[position])
    }

    override fun getItemCount() = serviceStations.size
    fun setServicesStations(list: List<MapFilterServiceModel>) {
        this.serviceStations = list
        notifyDataSetChanged()
    }

    fun getCurrentServicesList(): List<MapFilterServiceModel> {
        return serviceStations.filter { it.isSelected }
    }

    inner class ViewHolder(view: ItemStationServiceBinding) : RecyclerView.ViewHolder(view.root) {
        private val root = view.root
        private var serviceImage = view.ivStationService
        private var serviceName = view.tvNameStationService
        private var serviceTiming = view.tvTimingStationService

        init {
            itemView.setOnClickListener {
                val item = serviceStations[absoluteAdapterPosition]
                item.isSelected = !item.isSelected
                notifyItemChanged(absoluteAdapterPosition)
                action(serviceStations)
            }
        }


        fun bindViewHolder(service: MapFilterServiceModel) {
            serviceName.text = getServiceNameByType(service.type, itemView.context)
            /*      when(service.type) {
                      ServiceStationType.AUTO_WASH -> serviceName.text =  itemView.context.getString(R.string.MapFilterAutoWashService)
                      ServiceStationType.SIDRA -> serviceName.text =  itemView.context.getString(R.string.MapFilterSidraService)
                      ServiceStationType.MANUAL_WASH -> serviceName.text =  itemView.context.getString(R.string.MapFilterManualWashService)
                      ServiceStationType.VACCUM -> serviceName.text =  itemView.context.getString(R.string.MapFilterVacuumBayService)
                      ServiceStationType.LUBE -> serviceName.text =  itemView.context.getString(R.string.MapFilterLubeBayService)
                      ServiceStationType.REPAIR -> serviceName.text =  itemView.context.getString(R.string.MapFilterCarRepairService)
                      ServiceStationType.TIRE -> serviceName.text =  itemView.context.getString(R.string.MapFilterTireBayService)
                  }
      */
            serviceTiming.invisible()

            if (service.isSelected) {
                val serviceIcon = when (service.type) {
                    ServiceStationType.AUTO_WASH -> R.drawable.ic_automatic_wash_white
                    ServiceStationType.MANUAL_WASH -> R.drawable.ic_car_wash_service_white
                    ServiceStationType.LUBE -> R.drawable.ic_lube_bay_white
                    ServiceStationType.VACCUM -> R.drawable.ic_vaccum_service_white
                    ServiceStationType.TIRE -> R.drawable.ic_tire_service_white
                    ServiceStationType.REPAIR -> R.drawable.ic_car_repair_service_white
                    ServiceStationType.SIDRA -> R.drawable.ic_sidra_service_white
                }
                serviceImage.setImageResource(serviceIcon)
                serviceName.textColor(R.color.colorWhite)
                root.background =
                    itemView.context.loadDrawable(R.drawable.bg_green_stroke_radius_11)
            } else {
                val serviceIcon = when (service.type) {
                    ServiceStationType.AUTO_WASH -> R.drawable.ic_automatic_wash
                    ServiceStationType.MANUAL_WASH -> R.drawable.ic_car_wash_service
                    ServiceStationType.LUBE -> R.drawable.ic_lube_bay
                    ServiceStationType.VACCUM -> R.drawable.ic_vaccum_service
                    ServiceStationType.TIRE -> R.drawable.ic_tire_service
                    ServiceStationType.REPAIR -> R.drawable.ic_car_repair_service
                    ServiceStationType.SIDRA -> R.drawable.ic_sidra_service
                }
                serviceImage.setImageResource(serviceIcon)
                serviceName.textColor(R.color.color_04267E)
                root.background = itemView.context.loadDrawable(R.drawable.bg_stroke_radius_11)
            }
        }
    }
}

data class MapFilterServiceModel(
    val id: Int,
    val name: String,
    val type: ServiceStationType,
    var isSelected: Boolean = false
)
