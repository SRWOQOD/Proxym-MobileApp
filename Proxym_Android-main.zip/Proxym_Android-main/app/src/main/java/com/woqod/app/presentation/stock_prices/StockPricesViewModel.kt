package com.woqod.app.presentation.stock_prices

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.app.domain.models.StockPricesModel
import com.woqod.app.domain.usecases.GetStockPrices
import com.woqod.app.domain.usecases.GetStockPricesEuroland
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class StockPricesViewModel @Inject constructor(
    private val getStockPrices: GetStockPrices,
    private val getStockPricesEuroland: GetStockPricesEuroland

) : BaseViewModel() {

    private val _resultGetStockPrices = SingleLiveEvent<ResultUseCase<List<StockPricesModel>?, String?>>()
    val resultGetStockPrices: LiveData<ResultUseCase<List<StockPricesModel>?, String?>> = _resultGetStockPrices

    private val _resultGetStockPricesEuroland = SingleLiveEvent<ResultUseCase<StockPricesModel?, String?>>()
    val resultGetStockPricesEuroland : LiveData<ResultUseCase<StockPricesModel?, String?>> = _resultGetStockPricesEuroland

    fun getStockPrices() {
        viewModelScope.launch {
            _resultGetStockPrices.postValue(executeUseCase(getStockPrices))
        }
    }
    fun getEurolanStockPrices(){
        viewModelScope.launch {
            _resultGetStockPricesEuroland.postValue(executeUseCase(getStockPricesEuroland))

        }
    }

}