package com.woqod.app.domain.models


data class ContractorsModel(
    val title: String,
    val address: String,
    val phone: Array<String>,
    val fax: String,
    val email: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ContractorsModel

        if (!phone.contentEquals(other.phone)) return false

        return true
    }

    override fun hashCode() = phone.contentHashCode()
}