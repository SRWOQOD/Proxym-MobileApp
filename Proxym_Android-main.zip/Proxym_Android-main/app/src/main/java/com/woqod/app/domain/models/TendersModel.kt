package com.woqod.app.domain.models

import com.woqod.shared.commun.extensions.toFormattedDate
import java.io.Serializable

data class TendersModel(
    val tenderNumber: String?,
    val srNo: String?,
    val fee: String?,
    val description: String?,
    val details: String?,
    val id: Int?,
    val category: String?,
    val closingDate: Long?,
    val collectionDate: Long?,
    val bond: String?,
    val tenderFee: Boolean?
) : Serializable {
    fun getFormattedCollectionDate() = collectionDate?.toFormattedDate()
    fun getFormattedClosingDate() = closingDate?.toFormattedDate()

}