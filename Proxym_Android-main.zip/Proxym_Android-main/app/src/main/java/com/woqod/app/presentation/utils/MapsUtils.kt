package com.woqod.app.presentation.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.location.Location
import android.net.Uri
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.woqod.shared.baseui.BaseActivity
import com.woqod.shared.commun.extensions.loadDrawable
import com.woqod.shared.commun.extensions.toPixel
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


/**
 * Created by Hamdi.BOUMAIZA on 06/30/2020
 */


/**
 * move map to a specific location
 * @param googleMap
 * @param latLng
 */
fun moveCameraPosition(googleMap: GoogleMap, latLng: LatLng) {
    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 9f))
}

/**
 * create a custom marker icon
 * @param context
 * @param fallbackDrawable
 * @param drawable
 */
fun getCustomMarkerIcon(context: Context, fallbackDrawable: Int, drawable: Drawable?): Bitmap {
    val bitmapDrawable = drawable as BitmapDrawable?

    return bitmapDrawable?.let {
        Bitmap.createScaledBitmap(
            it.bitmap,
            MAP_ICON_WIDTH_DP.toPixel(context.resources),
            MAP_ICON_HEIGHT_DP.toPixel(context.resources),
            false
        ) as Bitmap
    } ?: Bitmap.createScaledBitmap(
        (context.loadDrawable(fallbackDrawable) as BitmapDrawable).bitmap,
        MAP_ICON_WIDTH_DP.toPixel(context.resources),
        MAP_ICON_HEIGHT_DP.toPixel(context.resources),
        false
    ) as Bitmap
}

/**
 * open google maps with direction to the destination
 */
fun Location.goToGoogleMapsWithDirection(activity: BaseActivity<*>, destination: LatLng) {
    activity.startActivity(
        Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://maps.google.com/maps?saddr=${latitude},${longitude}&daddr=${destination.latitude},${destination.longitude}")
        )
    )
}

/**
 * suspend fun that return the current location of the device
 * @param activity
 * @return current location
 */
@SuppressLint("MissingPermission")
suspend fun getCurrentDeviceLocation(activity: BaseActivity<*>): Location? = suspendCoroutine {
    val mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(activity)
    val location = mFusedLocationProviderClient.lastLocation
    location.addOnCompleteListener { task ->
        it.resume(task.result)
    }
}