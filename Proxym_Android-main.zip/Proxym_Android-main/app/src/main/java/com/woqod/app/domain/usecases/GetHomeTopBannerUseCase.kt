package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.HomeTopBannerModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject

open class GetHomeTopBannerUseCase @Inject constructor(
    private val appRepository: AppRepository
) : BaseUseCase<WoqodResult<SharedResponse<List<HomeTopBannerModel>>>> {

    override suspend operator fun invoke() = appRepository.getHomeTopBanner()
}