package com.woqod.app.data.repository


import com.woqod.app.data.datasource.AppDataSource
import com.woqod.app.domain.models.*
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.WoqodResult.Error
import com.woqod.shared.commundomain.WoqodResult.Success
import com.woqod.shared.commundomain.models.NotificationsModel
import com.woqod.woqode.domain.models.AccountInquiryModel

class AppRepositoryImpl(private val appDataSource: AppDataSource) : AppRepository {

    override suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceModel>>> {
        return when (val result = appDataSource.getFuelPrices()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { fuel ->
                            fuel.mapToDomainModel()
                        })
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.updateBiopin(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getFahesStations(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        return when (val result = appDataSource.getFahesStations()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { fs ->
                                fs.mapToDomainModel()
                            }
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        return when (val result = appDataSource.getPetrolStations()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { ps ->
                                ps.mapToDomainModel()
                            }
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        return when (val result = appDataSource.getListOfSuperMarkets()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { sm ->
                                sm.mapToDomainModel()
                            }
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsModel>>> =
        when (val result = appDataSource.getPromotions()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { it.mapToDomainModel() }
                        )
                    )
                )
            }
            is Error -> Error(result.exception)

        }

    override suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiryModel> {
        return when (val result = appDataSource.getBalanceInquiry(query)) {
            is Success -> {
                Success(result.data.mapToDomainModel())
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsModel>>> =
        when (val result = appDataSource.getContractors()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { it.mapToDomainModel() }
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.getSurveyStatus(query)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.postSurveyStatus(query)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TendersModel>>> {
        return when (val result = appDataSource.getWoqodTenders(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.result.map { tenders -> tenders.mapToDomainModel() },
                            data.body.result.size,
                            data.body.result.page,
                            data.body.result.count
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>> {
        return when (val result = appDataSource.getListNotifications(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.result.map { notification -> notification.mapToDomainModel() },
                            data.body.result.size,
                            data.body.result.page,
                            data.body.result.count
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>> {
        return when (val result = appDataSource.getAnonymousNotificationsList(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.result.map { notification -> notification.mapToDomainModel() },
                            data.body.result.size,
                            data.body.result.page,
                            data.body.result.count
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.postSurveyResponse(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.updateNotificationStatus(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.updateAllNotificationsStatus(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.getOtp(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.sendOtp(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = appDataSource.updateBiometricStatus(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>> {
        return when (val result = appDataSource.getProfilePhoto(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.putResendActivationCode(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.postAccountActivation(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }


    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.postRecoveryCode(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.getCheckRecoverCode(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerModel>>> =
        when (val result = appDataSource.getHomeTopBanner()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { item -> item.mapToDomainModel() })
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }

    override suspend fun getHomeAds(): WoqodResult<SharedResponse<List<HomeAdsModel>>> =
        when (val result = appDataSource.getHomeAds()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { item -> item.mapToDomainModel() })
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }


    override suspend fun getHomeBusinessSection(): WoqodResult<SharedResponse<List<HomeBusinessSectionModel>>> =
        when (val result = appDataSource.getHomeBusinessSection()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { item -> item.mapToDomainModel() })
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }

    override suspend fun getAppTips(device: String): WoqodResult<SharedResponse<List<AppTipsModel>>> =
        when (val result = appDataSource.getAppTips(device)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { appTip -> appTip.mapToDomainModel() })
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }

    override suspend fun getNewsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NewsModel>>> =
        when (val result = appDataSource.getNewsList(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful, data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.result.map { newsResponse -> newsResponse.mapToDomainModel() },
                            data.body.result.size,
                            data.body.result.page,
                            data.body.result.count
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun incrementNewsViews(id: Long): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.incrementNewsViews(id)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getStockPrices(): WoqodResult<SharedResponse<List<StockPricesModel>>> =
        when (val result = appDataSource.getStockPrices()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { stockPrice -> stockPrice.mapToDomainModel() }
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getStockPricesEuroland(): WoqodResult<SharedResponse<StockPricesModel>> =
        when (val result = appDataSource.getStockPricesFromEuroland()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type, data.body.result.mapToDomainModel()
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun getHasNotif(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.getHasNotif(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun postRatingStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.postRatingStations(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun logout(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = appDataSource.logout(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is Error -> Error(result.exception)
        }
}