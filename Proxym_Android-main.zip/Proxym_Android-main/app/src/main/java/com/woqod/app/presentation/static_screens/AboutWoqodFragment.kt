package com.woqod.app.presentation.static_screens

import com.woqod.app.databinding.FragmentAboutWoqodBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.SideMenuItem.ABOUT_US

class AboutWoqodFragment : BaseViewModelFragment<StaticScreenViewModel, FragmentAboutWoqodBinding>(FragmentAboutWoqodBinding::inflate) {

    override val viewModel: StaticScreenViewModel by injectViewModel()
    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override fun initViews() {
        appComponent.inject(this)
        initClickListeners()
        viewModel.getStaticText(ABOUT_US.name)
        disableDefaultBackPress(true)
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME,null)
    }

    override fun initObservers() {
        viewModel.resultStaticScreen.observe(this) {
            it.result?.let { staticText ->
                binding.tvAboutUsDesc.loadStaticWebView(
                    staticText.content,
                    isArabicLanguage = languageUtils.isArabicLanguage()
                )
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }



    private fun initClickListeners() {
        binding.toolbarAboutUs.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

}