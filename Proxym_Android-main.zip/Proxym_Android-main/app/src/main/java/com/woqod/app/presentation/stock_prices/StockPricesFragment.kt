package com.woqod.app.presentation.stock_prices

import android.widget.TextView
import com.woqod.app.R
import com.woqod.app.databinding.FragmentStockPricesBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.StockPricesModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.extensions.*
import java.util.*

class StockPricesFragment : BaseViewModelFragment<StockPricesViewModel, FragmentStockPricesBinding>(
    FragmentStockPricesBinding::inflate
) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: StockPricesViewModel by injectViewModel()

    override fun initViews() {
        disableDefaultBackPress(true)
        appComponent.inject(this)
        binding.toolbarStockPrices.btnToolbar.setOnClickListener {
            viewModel.navigate(
                Navigation.MENU,
                null
            )
        }
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.getEurolanStockPrices()
            binding.swipeRefresh.isRefreshing = false
        }
        viewModel.getEurolanStockPrices()
    }

    override fun onBackPressCustomAction() {
        viewModel.navigate(Navigation.HOME, null)

    }

    override fun initObservers() {
        viewModel.resultGetStockPrices.observe(this) {
            it.result?.let { stockPrice ->
                initValues(stockPrice.sortedBy { stockPrice -> stockPrice.date }.last())
            }
            it.error?.let { error ->
                togglePopUp(error)
            }

        }
        viewModel.resultGetStockPricesEuroland.observe(this) {
            it.result?.let { stockPrice ->
                initValues(stockPrice, isEuroland = true)
            }
            it.error?.let { error ->
                viewModel.getStockPrices()

            }

        }
    }

    private fun initValues(stockPrice: StockPricesModel, isEuroland: Boolean = false) {
        with(binding) {
            tvStockPricesQfls.text = stockPrice.symbol
            tvStockPricesDate.text = if (isEuroland) stockPrice.dateString?.toFormattedDateString() else stockPrice.date.toFormattedDateQatar(BIRTH_DATE_FORMAT)
            tvStockPricesLastPriceValue.text =
                formatValue(getString(R.string.FuelPriceFomatPrice), stockPrice.lastPrice.toFloat())
            tvStockPricesOpenValue.text =
                formatValue(getString(R.string.FuelPriceFomatPrice), stockPrice.open.toFloat())
            tvStockPricesHighValue.text =
                formatValue(getString(R.string.FuelPriceFomatPrice), stockPrice.high.toFloat())
            tvStockPricesLowValue.text =
                formatValue(getString(R.string.FuelPriceFomatPrice), stockPrice.low.toFloat())
            tvStockPricesVolumeValue.text = stockPrice.volume.numberCommaFormat()
            tvStockPricesPreviousCloseValue.text =
                formatValue(
                    getString(R.string.FuelPriceFomatPrice),
                    stockPrice.previousClose.toFloat()
                )
            tvStockPricesChangeValue.formatChange(stockPrice.change, stockPrice.changePercent)
        }


    }

    private fun formatValue(formattedString: String, change: Float, changePercent: Float = 0F) =
        String.format(Locale.ENGLISH, formattedString, change, changePercent)


    private fun TextView.formatChange(change: String, changePercent: String) {
        if (change.toFloat() >= 0) {
            text = formatValue(
                getString(
                    R.string.FuelPriceFomatPostiveChnge
                ), change.toFloat(), changePercent.toFloat()
            )
            textColor(R.color.color_009933)
        } else {
            text = formatValue(
                getString(
                    R.string.FuelPriceFomaNegativehnge
                ), change.replace("-", "").toFloat(), changePercent.replace("-", "").toFloat()
            )

            textColor(R.color.color_d32f2f)
        }

    }
}