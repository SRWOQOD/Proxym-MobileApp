package com.woqod.app.presentation.fuel_prices

import android.os.Bundle
import com.woqod.app.databinding.FragmentFuelPricesBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.FuelPriceModel
import com.woqod.app.presentation.utils.FUEL_FALLBACK_VALUE
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.utils.FUEL_ARGS
import java.io.Serializable

class FuelPricesFragment : BaseViewModelFragment<FuelPricesViewModel, FragmentFuelPricesBinding>(FragmentFuelPricesBinding::inflate) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: FuelPricesViewModel by injectViewModel()

    private var params: MutableList<FuelPriceModel>? = null

    private val fuelPriceAdapter: FuelPricesAdapter by lazy {
        FuelPricesAdapter(mutableListOf())
    }

    fun newInstance(params: MutableList<FuelPriceModel>?): FuelPricesFragment {
        val args = Bundle()
        args.putSerializable(FUEL_ARGS, params as Serializable)
        val fragment = FuelPricesFragment()
        fragment.arguments = args
        return fragment
    }

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            if (it.containsKey(FUEL_ARGS))
                params = it.getSerializable(FUEL_ARGS) as MutableList<FuelPriceModel>?
        }
        initClickListeners()
        initRecyclerFuelPrices()
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(false)
        params?.let {
            if (it.size == 3 && it.first().name() != FUEL_FALLBACK_VALUE) fuelPriceAdapter.updateList(it)
            else viewModel.getFuelPrices()
        }
    }

    override fun initObservers() {
        viewModel.resultFuelPrices.observe(this, {
            it.result?.let { list -> fuelPriceAdapter.updateList(list.sortedBy { item -> item.itemOrder }) }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun initRecyclerFuelPrices() {
        binding.rvFuelPrices.adapter = fuelPriceAdapter
    }

    private fun initClickListeners() {
        binding.toolbarFuelPrices.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

}