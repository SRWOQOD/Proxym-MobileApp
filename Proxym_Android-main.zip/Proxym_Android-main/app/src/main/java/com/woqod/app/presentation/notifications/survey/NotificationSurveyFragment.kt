package com.woqod.app.presentation.notifications.survey

import android.os.Bundle
import com.google.gson.Gson
import com.woqod.app.R
import com.woqod.app.data.models.SurveyResponseRequest
import com.woqod.app.databinding.FragmentSurveyNotificationBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.presentation.notifications.NotificationsViewModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.SURVEY_ID
import com.woqod.shared.commun.SURVEY_RESPONSES
import com.woqod.shared.commun.extensions.hide
import com.woqod.shared.commun.extensions.show
import com.woqod.shared.commundata.DEVICE_ID
import com.woqod.shared.commundomain.models.NotificationSurveyChoicesModel
import com.woqod.shared.commundomain.models.NotificationSurveyModel
import com.woqod.shared.commundomain.models.PushNotificationModel
import com.woqod.shared.utils.FRAGMENT_SOURCE
import com.woqod.shared.utils.HOME_FROM_SPLASH
import com.woqod.shared.utils.SURVEY_ARGS
import com.woqod.shared.widget.PopUpType
import timber.log.Timber

class NotificationSurveyFragment :
    BaseViewModelFragment<NotificationsViewModel, FragmentSurveyNotificationBinding>(
        FragmentSurveyNotificationBinding::inflate
    ) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: NotificationsViewModel by injectViewModel()

    private var surveyQuestionAdapter: SurveyQuestionAdapter? = null
    private var survey: List<NotificationSurveyModel>? = null
    private var notificationSurvey: PushNotificationModel? = null
    private val answeredSurveyList = mutableListOf<SurveyResponseRequest>()

    fun newInstance(params: PushNotificationModel): NotificationSurveyFragment {
        val args = Bundle()
        args.putSerializable(SURVEY_ARGS, params)
        val fragment = NotificationSurveyFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            notificationSurvey = it.getSerializable(SURVEY_ARGS) as PushNotificationModel
        }
        disableDefaultBackPress(true)
        initClickListeners()
        survey = notificationSurvey?.surveyQuestionResources
        setUpNotificationTitle(notificationSurvey?.getTitle())
        setUpNotificationDescrp(notificationSurvey?.getDescription())
        surveyQuestionAdapter = SurveyQuestionAdapter(survey ?: listOf(), activity)
        binding.rvSurveyQuestion.adapter = surveyQuestionAdapter
    }

    private fun setUpNotificationTitle(title: String?) {
        if (title.isNullOrEmpty()) binding.tvSurveyTitle.text = getString(R.string.SettingsSurvey)
        else binding.tvSurveyTitle.text = title
    }

    private fun setUpNotificationDescrp(description: String?) {
        if (!description.isNullOrEmpty()) {
            binding.tvSurveyNotifDescp.text =
                notificationSurvey?.getDescription()
            binding.tvSurveyNotifDescp.show()
        } else binding.tvSurveyNotifDescp.hide()

    }

    override fun onBackPressCustomAction() {
        customBackPressedBehavior()
    }

    private fun customBackPressedBehavior() {
        notificationSurvey?.let {
            if (it.isFromNotification) {
                viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_SPLASH))
            } else viewModel.navigate(Navigation.NOTIFICATION, null)
        } ?: activity.onBackPressed()
    }

    override fun initObservers() {
        viewModel.onGetSurveyResponse.observe(this, {
            it.result?.let { result ->
                if (result) togglePopUp(
                    getString(R.string.NotificationsSurveyResponseSent),
                    popUpType = PopUpType.POPUP_SUCCESS,
                    action = {
                        activity.onBackPressed()
                    })
            }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun initClickListeners() {
        binding.toolbarSurvey.btnToolbar.setOnClickListener {
            customBackPressedBehavior()
        }
        binding.tvSubmit.setOnClickListener {
            survey?.forEach {
                if (!getSelectedOptions(it)) {
                    return@forEach
                }
            }
            checkUserAnswer()
        }
    }

    private fun checkUserAnswer() {
        if (verifyAnsweredQuestion()) {
            sendSurveyResponse(answeredSurveyList, sharedPreferences.deviceId)
        } else {
            answeredSurveyList.clear()
            togglePopUp(getString(R.string.NotificationMustAnswerAll))
        }
    }

    private fun getSelectedOptions(question: NotificationSurveyModel): Boolean {
        return surveyQuestionAdapter?.let {
            val listCheckedChoices = getListOfCheckedChoices(question.options)
            if (listCheckedChoices.isEmpty()) {
                Timber.e("Please select at least one answer")
                false
            } else {
                Timber.e(listCheckedChoices.toString())
                answeredSurveyList.add(
                    SurveyResponseRequest(
                        questionId = question.questionId,
                        responses = listCheckedChoices
                    )
                )
                true
            }
        } ?: false
    }

    private fun getListOfCheckedChoices(answers: List<NotificationSurveyChoicesModel>): ArrayList<String> {
        val listCheckedChoices = ArrayList<String>()
        for (choice in answers) {
            if (choice.isChoiceChecked) listCheckedChoices.add(choice.response)
        }
        return listCheckedChoices
    }

    private fun verifyAnsweredQuestion(): Boolean {
        return survey?.let {
            it.size == answeredSurveyList.size
        } ?: false
    }

    private fun sendSurveyResponse(
        surveyList: MutableList<SurveyResponseRequest>,
        deviceId: String
    ) {
        survey?.let {
            viewModel.postSurveyResponse(
                hashMapOf(
                    SURVEY_ID to notificationSurvey?.id!!,
                    SURVEY_RESPONSES to Gson().toJson(surveyList),
                    DEVICE_ID to deviceId
                )
            )
        }
    }

}
