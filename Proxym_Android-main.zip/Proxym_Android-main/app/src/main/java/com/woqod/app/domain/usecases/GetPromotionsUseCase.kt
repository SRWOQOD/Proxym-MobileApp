package com.woqod.app.domain.usecases

import com.woqod.app.domain.models.PromotionsModel
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


typealias GetPromotionsBaseUseCase = BaseUseCase<WoqodResult<SharedResponse<List<PromotionsModel>>>>

class GetPromotionsUseCase @Inject constructor(
    private val appRepository: AppRepository
) : GetPromotionsBaseUseCase {

    override suspend operator fun invoke() = appRepository.getPromotions()
}