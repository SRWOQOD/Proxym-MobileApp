package com.woqod.app.presentation.promotions

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.facebook.shimmer.ShimmerFrameLayout
import com.woqod.app.R
import com.woqod.app.databinding.ItemPromotionsArticleBinding
import com.woqod.app.domain.models.PromotionsModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.extensions.BIRTH_DATE_FORMAT
import com.woqod.shared.commun.extensions.formatStringHtml
import com.woqod.shared.commun.extensions.load
import com.woqod.shared.commun.extensions.toFormattedDate


class PromotionsAdapter(
    private var promotionsList: MutableList<PromotionsModel>,
    private val action: (promotionsItem: PromotionsModel) -> Unit
) : RecyclerView.Adapter<PromotionsAdapter.PromotionsViewHolder>() {

    fun updateList(promotions: List<PromotionsModel>) {
        this.promotionsList.clear()
        this.promotionsList = promotions.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        PromotionsViewHolder(
            ItemPromotionsArticleBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: PromotionsViewHolder, position: Int) {
        holder.bind(promotionsList[position])
    }

    override fun getItemCount() = promotionsList.size

    inner class PromotionsViewHolder(private val view: ItemPromotionsArticleBinding) :
        RecyclerView.ViewHolder(view.root) {

        private val shimmer: ShimmerFrameLayout = view.shimmerItemPromotions
        private val tvError: TextView = view.tvPromotionsItemError
        private val ivPlaceHolder: ImageView = view.ivPlaceholder

        fun bind(promotionsItem: PromotionsModel) {

            view.apply {
                promotionsItem.imageList?.let { image ->
                    shimmer.load(ivPromotionsItem, image, tvError, ivPlaceHolder)
                } ?: run { ivPromotionsItem.load(R.drawable.ic_placeholder) {
                    transformations(coil.transform.RoundedCornersTransformation(33F))
                } }
                ivPromotionsItemRedirection.setOnClickListener {
                    action(promotionsItem)
                }
                ivPromotionsItem.setOnClickListener {
                    action(promotionsItem)
                }
                tvItemPromotionsStartDate.text =
                    promotionsItem.endDate.toFormattedDate(BIRTH_DATE_FORMAT)
                tvPromotionsItemTitle.text =
                    if (WoqodApplication.sharedComponent.injectLanguageUtils()
                            .isArabicLanguage()
                    ) promotionsItem.titleArabic else promotionsItem.title
                tvPromotionsItemDesc.formatStringHtml(

                    if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) promotionsItem.briefDescriptionArabic
                    else promotionsItem.briefDescription
                )
            }
        }
    }
}