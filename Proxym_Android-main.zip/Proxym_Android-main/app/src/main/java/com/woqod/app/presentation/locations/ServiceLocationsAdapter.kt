package com.woqod.app.presentation.locations

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.woqod.app.R
import com.woqod.app.databinding.ItemStationServiceBinding
import com.woqod.app.domain.models.ServiceStationModel
import com.woqod.app.presentation.utils.getServiceNameByType
import com.woqod.shared.commun.extensions.textColor
import com.woqod.shared.utils.ServiceStationType

class ServiceLocationsAdapter(
    private var serviceStations: List<ServiceStationModel>
) : RecyclerView.Adapter<ServiceLocationsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemStationServiceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViewHolder(serviceStations[position])
    }

    override fun getItemCount() = serviceStations.size

    inner class ViewHolder(view: ItemStationServiceBinding) : RecyclerView.ViewHolder(view.root) {
        private var serviceImage = view.ivStationService
        private var serviceName = view.tvNameStationService
        private var serviceTiming = view.tvTimingStationService


        fun bindViewHolder(service: ServiceStationModel) {
            service.apply {
                when (type) {
                    ServiceStationType.AUTO_WASH -> serviceImage.setImageResource(R.drawable.ic_automatic_wash)
                    ServiceStationType.MANUAL_WASH -> serviceImage.setImageResource(R.drawable.ic_car_wash_service)
                    ServiceStationType.LUBE -> serviceImage.setImageResource(R.drawable.ic_lube_bay)
                    ServiceStationType.VACCUM -> serviceImage.setImageResource(R.drawable.ic_vaccum_service)
                    ServiceStationType.TIRE -> serviceImage.setImageResource(R.drawable.ic_tire_service)
                    ServiceStationType.REPAIR -> serviceImage.setImageResource(R.drawable.ic_car_repair_service)
                    ServiceStationType.SIDRA -> serviceImage.setImageResource(R.drawable.ic_sidra_service)
                }
                serviceName.text = getServiceNameByType(type,context = itemView.context)
                serviceName.textColor(R.color.color_04267E)
                serviceTiming.text = "$openingHour - $closingHour"

            }
        }
    }
}
