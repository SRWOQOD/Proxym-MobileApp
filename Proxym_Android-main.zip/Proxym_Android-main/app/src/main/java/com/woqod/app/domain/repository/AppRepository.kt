package com.woqod.app.domain.repository

import com.woqod.app.domain.models.*
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.NotificationsModel
import com.woqod.woqode.domain.models.AccountInquiryModel


interface AppRepository {
    suspend fun getFahesStations(): WoqodResult<SharedResponse<List<MapStationModel>>>
    suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<MapStationModel>>>
    suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<MapStationModel>>>
    suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceModel>>>
    suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsModel>>>
    suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiryModel>
    suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsModel>>>

    suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TendersModel>>>

    suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>>
    suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>>

    suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>

    suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>>

    suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun getNewsList(request: HashMap<String, Any>) : WoqodResult<SharedResponse<List<NewsModel>>>
    suspend fun incrementNewsViews(id:Long) : WoqodResult<SharedResponse<Boolean>>

    suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerModel>>>
    suspend fun getHomeAds() : WoqodResult<SharedResponse<List<HomeAdsModel>>>
    suspend fun getHomeBusinessSection() : WoqodResult<SharedResponse<List<HomeBusinessSectionModel>>>

    suspend fun getAppTips(device : String) : WoqodResult<SharedResponse<List<AppTipsModel>>>

    suspend fun getStockPrices():WoqodResult<SharedResponse<List<StockPricesModel>>>
    suspend fun getStockPricesEuroland():WoqodResult<SharedResponse<StockPricesModel>>
    suspend fun getHasNotif(request: HashMap<String, Any>):WoqodResult<SharedResponse<Boolean>>

    suspend fun postRatingStations(request: HashMap<String, Any>):WoqodResult<SharedResponse<Boolean>>

    suspend fun logout(request: HashMap<String, Any>):WoqodResult<SharedResponse<Boolean>>

}