package com.woqod.app.data.models

import com.google.gson.annotations.SerializedName
import com.woqod.app.domain.models.MapStationModel
import com.woqod.app.domain.models.MapTypeStation
import com.woqod.app.domain.models.SuperMarketModel
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.extensions.convertLocationToDouble
import com.woqod.shared.commundata.DomainMapper
import com.woqod.shared.commundata.models.AreaResponse

/**
 * {"lastSynchronisationDate":[2020,7,15,4,15,15,97000000],
 * "arabicTitle":"سوبر ماركت الصفوة",
 * "imageCaption":"مشيرب",
 * "latitude":"25.2843025",
 * "xPortalAdress":"Mshereb",
 * "contactPerson":"Ali",
 * "id":573,
 * "title":"Safwa supermarket",
 * "xPortalPhone":"44310224",
 * "marketId":1485,
 * "longitude":"51.5192651"}
 */
data class SuperMarketsResponse(
    val lastSynchronisationDate: Long?,
    val arabicTitle: String?,
    val imageCaption: String?,
    val xPortalAdress: String?,
    val contactPerson: String?,
    val id: Int?,
    val title: String?,
    val xportalPhone: String?,
    val marketId: Int?,
    val latitude: String?,
    val longitude: String?,
    val icon: String?,
    @SerializedName("areaResource")
    val area: AreaResponse?,

    ) : DomainMapper<MapStationModel> {
    override fun mapToDomainModel(): MapStationModel {
        val titleSupermarket: String?
        val addressSupermarket: String?
        if (WoqodApplication.sharedComponent.injectLanguageUtils().isArabicLanguage()) {
            titleSupermarket = arabicTitle
            addressSupermarket = imageCaption
        } else {
            titleSupermarket = title
            addressSupermarket = xPortalAdress
        }

        return MapStationModel(
            MapTypeStation.SUPERMARKET_STATION,
            id ?: 0,
            titleSupermarket ?: "",
            xportalPhone ?: "",
            latitude?.convertLocationToDouble() ?: 0.0,
            longitude?.convertLocationToDouble() ?: 0.0,
            lastSynchronisationDate ?: 0L,
            SuperMarketModel(
                xportalPhone ?: "",
                contactPerson ?: "",
                marketId ?: 0,
                area?.mapToDomainModel()
            ),
            null,
            null,
            icon = icon
        )
    }

}