package com.woqod.app.presentation.promotions

import android.graphics.Paint
import android.os.Bundle
import coil.load
import com.woqod.app.R
import com.woqod.app.databinding.FragmentPromotionsDetailsBinding
import com.woqod.app.di.component.AppComponent
import com.woqod.app.di.component.GetAppComponent
import com.woqod.app.domain.models.PromotionsModel
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.utils.PROMOTIONS_DETAILS_ARGS

class PromotionsFragmentDetails :
    BaseViewModelFragment<PromotionsViewModel, FragmentPromotionsDetailsBinding>(
        FragmentPromotionsDetailsBinding::inflate
    ) {

    private val appComponent: AppComponent by lazy {
        GetAppComponent.getInstance()
    }

    override val viewModel: PromotionsViewModel by injectViewModel()

    private var promotionsDetail: PromotionsModel? = null

    fun newInstance(params: PromotionsModel) =
        PromotionsFragmentDetails().apply {
            arguments = Bundle().apply {
                putSerializable(PROMOTIONS_DETAILS_ARGS, params)
            }
        }

    override fun initViews() {
        appComponent.inject(this)
        arguments?.let {
            promotionsDetail = it.getSerializable(PROMOTIONS_DETAILS_ARGS) as PromotionsModel
        }
        initClickListeners()
        setUpView()
    }

    private fun setUpView() {
        with(binding) {
            promotionsDetail?.let { promotionsDetail ->

                tvPromotionsDetailsTitle.text =
                    if (languageUtils.isArabicLanguage()) promotionsDetail.titleArabic else promotionsDetail.title

                tvPromotionsDetailsDesc.formatStringHtml(
                    if (languageUtils.isArabicLanguage()) promotionsDetail.briefDescriptionArabic
                    else promotionsDetail.briefDescription
                )
                promotionsDetail.image?.let { image ->
                    shimmerPromotionsDetails.load(
                        ivPromotionsDetail,
                        image,
                        tvPromotionsDetailsImgError,
                        ivPlaceholder
                    )
                } ?: run {
                    ivPromotionsDetail.load(R.drawable.ic_placeholder) {
                        transformations(coil.transform.RoundedCornersTransformation(33F))
                    }
                }
                tvPromotionsDetailsEndDate.text =
                    promotionsDetail.endDate.toFormattedDate(BIRTH_DATE_FORMAT)
                tvPromotionsDetailLink.apply {
                    paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
                    text = context.getString(R.string.NewsDetailsClickForMore)
                    setOnClickListener {
                        promotionsDetail.link.openLink(activity)
                    }
                }
            }
        }
    }

    private fun initClickListeners() {
        binding.toolbarPromotionsDetail.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }
    }


}