package com.woqod.app.repository

import com.woqod.app.datasource.AppDataSourceImplTest
import com.woqod.app.domain.models.*
import com.woqod.app.domain.repository.AppRepository
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.NotificationsModel
import com.woqod.woqode.domain.models.AccountInquiryModel

class AppRepositoryImplTest(private val appDataSource: AppDataSourceImplTest) : AppRepository {

    override suspend fun getFahesStations(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        return when (val result = appDataSource.getFahesStations()) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.result.map { fp ->
                            fp.mapToDomainModel()
                        })
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<MapStationModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceModel>>> {
        return when (val result = appDataSource.getFuelPrices()) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.result.map { fs ->
                                fs.mapToDomainModel()
                            })
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiryModel> {
        TODO("Not yet implemented")
    }

    override suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<TendersModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NotificationsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>> {
        TODO("Not yet implemented")
    }

    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getNewsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<List<NewsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun incrementNewsViews(id: Long): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeAds(): WoqodResult<SharedResponse<List<HomeAdsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeBusinessSection(): WoqodResult<SharedResponse<List<HomeBusinessSectionModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getAppTips(device: String): WoqodResult<SharedResponse<List<AppTipsModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getStockPrices(): WoqodResult<SharedResponse<List<StockPricesModel>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getStockPricesEuroland(): WoqodResult<SharedResponse<StockPricesModel>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHasNotif(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postRatingStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun logout(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

}