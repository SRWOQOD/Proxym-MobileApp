package com.woqod.app.datasource

import com.google.gson.Gson
import com.woqod.app.data.datasource.AppDataSource
import com.woqod.app.data.models.*
import com.woqod.app.helpers.getJson
import com.woqod.shared.commundata.fromJsonToObjectType
import com.woqod.shared.commundata.models.NotificationsResponse
import com.woqod.shared.commundata.models.PagingResult
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundata.verifySuccessCode
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.woqode.data.models.AccountInquiry

class AppDataSourceImplTest : AppDataSource {

    override suspend fun getFahesStations(): WoqodResult<SharedResponse<List<FahesStationResponse>>> {
        return verifySuccessCode(Gson().fromJsonToObjectType(getJson("fahes_stations.json")))
    }

    override suspend fun getPetrolStations(): WoqodResult<SharedResponse<List<PetrolStationResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun postRatingStations(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getListOfSuperMarkets(): WoqodResult<SharedResponse<List<SuperMarketsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getFuelPrices(): WoqodResult<SharedResponse<List<FuelPriceResponse>>> {
        return verifySuccessCode(Gson().fromJsonToObjectType(getJson("fuel_prices.json")))
    }

    override suspend fun updateBiopin(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getPromotions(): WoqodResult<SharedResponse<List<PromotionsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getBalanceInquiry(query: HashMap<String, Any>): WoqodResult<AccountInquiry> {
        TODO("Not yet implemented")
    }

    override suspend fun getContractors(): WoqodResult<SharedResponse<List<ContractorsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postSurveyStatus(query: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getWoqodTenders(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<TendersResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getListNotifications(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getAnonymousNotificationsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NotificationsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun postSurveyResponse(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateNotificationStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateAllNotificationsStatus(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun sendOtp(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateBiometricStatus(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getProfilePhoto(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>> {
        TODO("Not yet implemented")
    }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getCheckRecoverCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getNewsList(request: HashMap<String, Any>): WoqodResult<SharedResponse<PagingResult<NewsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun incrementNewsViews(id: Long): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeTopBanner(): WoqodResult<SharedResponse<List<HomeTopBannerResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeAds(): WoqodResult<SharedResponse<List<HomeAdsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHomeBusinessSection(): WoqodResult<SharedResponse<List<HomeBusinessSectionResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getAppTips(device: String): WoqodResult<SharedResponse<List<AppTipsResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getStockPrices(): WoqodResult<SharedResponse<List<StockPricesResponse>>> {
        TODO("Not yet implemented")
    }

    override suspend fun getStockPricesFromEuroland(): WoqodResult<SharedResponse<StockPricesEurolandResponse>> {
        TODO("Not yet implemented")
    }

    override suspend fun getHasNotif(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

    override suspend fun logout(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> {
        TODO("Not yet implemented")
    }

}