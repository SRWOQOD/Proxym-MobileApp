package com.woqod.app.usecase

import com.woqod.app.domain.repository.AppRepository
import com.woqod.app.domain.usecases.GetFuelPricesUseCase

class GetFuelPricesUseCaseTest(private val appRepository: AppRepository) :
    GetFuelPricesUseCase(appRepository) {
    override suspend fun invoke() =
        appRepository.getFuelPrices()
}