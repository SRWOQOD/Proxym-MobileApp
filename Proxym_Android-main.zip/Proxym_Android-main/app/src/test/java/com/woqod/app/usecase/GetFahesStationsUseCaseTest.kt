package com.woqod.app.usecase

import com.woqod.app.domain.repository.AppRepository
import com.woqod.app.domain.usecases.GetFahesStationsUseCase

class GetFahesStationsUseCaseTest(private val appRepository: AppRepository) :
    GetFahesStationsUseCase(appRepository) {
    override suspend fun invoke() =
        appRepository.getFahesStations()
}