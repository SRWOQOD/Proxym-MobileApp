package com.woqod.app


import androidx.test.espresso.intent.rule.IntentsTestRule
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import com.schibsted.spain.barista.assertion.BaristaImageViewAssertions.assertHasDrawable
import com.schibsted.spain.barista.interaction.BaristaDrawerInteractions.openDrawer
import com.schibsted.spain.barista.interaction.BaristaListInteractions.clickListItem
import com.woqod.app.presentation.menu.MenuActivity
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4ClassRunner::class)
class MainActivityIntegrationTest {

    @get:Rule
    var activityRule: ActivityTestRule<MenuActivity> =
        ActivityTestRule(MenuActivity::class.java, false, false)

    @get:Rule
    val intentsTestRule = IntentsTestRule(MenuActivity::class.java)


    @Test
    fun useAppContext() {
        // Context of the app under test.
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.woqod.app", appContext.packageName)
    }

    @Test
    fun verifyViews() {
        openDrawer()
        assertHasDrawable(R.id.img_toolbar, R.drawable.ic_logo_header)
        clickListItem(R.id.recycler_menu, 0)
    }
}