package com.woqod.app


import androidx.fragment.app.Fragment
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import com.schibsted.spain.barista.interaction.BaristaListInteractions.clickListItem
import com.schibsted.spain.barista.interaction.BaristaSleepInteractions.sleep
import com.woqod.app.presentation.fuel_prices.FuelPricesFragment
import com.woqod.app.presentation.menu.MenuActivity
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith


/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4ClassRunner::class)
class FuelPricesFragmentIntegrationTest {

    @get:Rule
    var activityRule: ActivityTestRule<MenuActivity> = ActivityTestRule(MenuActivity::class.java)

    @Before
    fun setUp() {
        startFragment(FuelPricesFragment())
    }

    @Test
    fun testEventFragment() {
        sleep(3000) // wait to get data from ws
        clickListItem(R.id.rv_fuel_prices, 0)
    }

    private fun startFragment(fragment: Fragment) {
        activityRule.activity
            .supportFragmentManager
            .beginTransaction()
            .add(R.id.fragment_menu_container, fragment, fragment.javaClass.name)
            .commit()
    }
}