package com.woqod.account.data.datasource

import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundata.models.UserDetailsResponse
import com.woqod.shared.commundomain.WoqodResult


interface AccountDataSource {
    suspend fun getUserDetails(): WoqodResult<SharedResponse<UserDetailsResponse>>
    suspend fun postSendRecoveryCode(request: HashMap<String, String>): WoqodResult<SharedResponse<UserDetailsResponse>>
    suspend fun updateUser(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsResponse>>
    suspend fun updateUserPhoto(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsResponse>>
    suspend fun updateUserPhoneNumber(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun updateUserEmail(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendEmailPinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendPhonePinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>

}