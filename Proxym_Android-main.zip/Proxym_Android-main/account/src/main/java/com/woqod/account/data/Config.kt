package com.woqod.account.data

import com.woqod.shared.commundata.BASE_API_ADAPTER_URL


const val GET_USER_DETAILS_URL = "$BASE_API_ADAPTER_URL/users/details"
const val PUT_USER_URL = "$BASE_API_ADAPTER_URL/users"
const val PUT_UPDATE_PROFILE_PHOTO = "$BASE_API_ADAPTER_URL/users/updatePhoto"
const val PUT_UPDATE_PROFILE_PHONE_NUMBER = "$BASE_API_ADAPTER_URL/users/updatePhoneNumber"
const val PUT_UPDATE_PROFILE_EMAIL = "$BASE_API_ADAPTER_URL/users/updateEmail"
const val POST_UPDATE_PROFILE_EMAIL = "$BASE_API_ADAPTER_URL/pincode/sendPinCodeToUpdateUserEMail"
const val POST_UPDATE_PROFILE_PHONE = "$BASE_API_ADAPTER_URL/pincode/sendPinCodeToUpdateUserPhone"
