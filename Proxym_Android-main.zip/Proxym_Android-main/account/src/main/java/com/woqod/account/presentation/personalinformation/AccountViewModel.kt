package com.woqod.account.presentation.personalinformation


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.account.domain.usecases.*
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commundata.IPADDRESS
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.models.UserDetailsModel
import com.woqod.shared.commundomain.sharedusecases.CheckMobileValidityUseCase
import com.woqod.shared.commundomain.sharedusecases.GetListAreasUseCase
import com.woqod.shared.commundomain.sharedusecases.ValidatePinCodeUseCase
import com.woqod.shared.utils.LanguageUtils
import com.woqod.shared.utils.getIpAddress
import kotlinx.coroutines.launch
import javax.inject.Inject

class AccountViewModel @Inject constructor(
    private val languageUtils: LanguageUtils,
    private val updateUserUseCase: UpdateUserUseCase,
    private val updateUserPhotoUseCase: UpdateUserPhotoUseCase,
    private val getListAreasUseCase: GetListAreasUseCase,
    private val updateUserPhoneNumberUseCase: UpdateUserPhoneNumberUseCase,
    private val updateUserEmailUseCase: UpdateUserEmailUseCase,
    private val sendEmailPincode: SendEmailPincode,
    private val validatePinCodeUseCase: ValidatePinCodeUseCase,
    private val sendPhonePincode: SendPhonePincode,
    private val checkQidValidityUseCase: CheckMobileValidityUseCase
) : BaseViewModel() {

    private val _onSuccessUserUpdate = SingleLiveEvent<ResultUseCase<UserDetailsModel?, String?>>()
    val onSuccessUserUpdate: LiveData<ResultUseCase<UserDetailsModel?, String?>> get() = _onSuccessUserUpdate

    private val _onSendPhonePincode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSendPhonePincode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSendPhonePincode

    private val _onSendEmailPincode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSendEmailPincode: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSendEmailPincode

    private val _onSuccessUserPhotoUpdate =
        SingleLiveEvent<ResultUseCase<UserDetailsModel?, String?>>()
    val onSuccessUserPhotoUpdate: LiveData<ResultUseCase<UserDetailsModel?, String?>> get() = _onSuccessUserPhotoUpdate

    private val _onRequestAreas = SingleLiveEvent<ResultUseCase<List<AreaModel>?, String?>>()
    val onRequestAreas: LiveData<ResultUseCase<List<AreaModel>?, String?>> get() = _onRequestAreas

    private val _onSuccessUserMobileUpdate =
        SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSuccessUserMobileUpdate: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSuccessUserMobileUpdate

    private val _onSuccessUserEmailUpdate =
        SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSuccessUserEmailUpdate: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSuccessUserEmailUpdate

    private val _onCheckQidValidity = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckQidValidity: LiveData<ResultUseCase<Boolean?, String?>> get() = _onCheckQidValidity

    fun requestAreas() {
        viewModelScope.launch {
            _onRequestAreas.postValue(executeUseCase(getListAreasUseCase))
        }
    }

    fun onSubmitUpdate(userInfo: UserDetailsModel) {
        hashMapOf<String, Any?>(
            FIRST_NAME to userInfo.firstName,
            LAST_NAME to userInfo.lastName,
            MOBILE_NUMBER to userInfo.mobileNumber,
            EMAIL to userInfo.email,
            ADDRESS to userInfo.addressLabel,
            BIRTH_DATE to userInfo.birthDate,
            AREA_ID to userInfo.area.idArea,
            INCOME to userInfo.income,
            FLEET_NAME to userInfo.fleetName,
            UNLOCK_ACCOUNT to userInfo.unlockAccount,
            TYPE to INDIVIDUAL_CUSTOMER,
            USERNAME to userInfo.userName,
            QID to userInfo.qid,
            CREATED_AT to userInfo.createdAt,
            ID to userInfo.id,
            STATUS to userInfo.status,
            PHOTO to userInfo.photo,
            PO_BOX to userInfo.poBox,
            IPADDRESS to getIpAddress()
        ).also {
            updateUser(it)
        }
    }

    private fun updateUser(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            _onSuccessUserUpdate.postValue(executeUseCase(updateUserUseCase, query))
        }
    }

    fun updateUserPhoto(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            _onSuccessUserPhotoUpdate.postValue(executeUseCase(updateUserPhotoUseCase, query))
        }
    }


    fun updatePhoneNumber(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            _onSuccessUserMobileUpdate.postValue(
                executeUseCase(updateUserPhoneNumberUseCase, query)
            )
        }
    }

    fun updateEmail(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            _onSuccessUserEmailUpdate.postValue(
                executeUseCase(updateUserEmailUseCase, query)
            )
        }
    }

    fun sendEmailPinCode(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            query[LANGUAGE] = languageUtils.getAppLanguage()
            _onSendEmailPincode.postValue(executeUseCase(sendEmailPincode, query))
        }

    }

    fun sendPhonePinCode(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            query[LANGUAGE] = languageUtils.getAppLanguage()
            _onSendPhonePincode.postValue(executeUseCase(sendPhonePincode, query))
        }

    }

    private val _onCheckPinCode = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckPinCode: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckPinCode

    fun checkSecurityCodeValidity(username: String, securityCode: String) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(PIN_CODE to securityCode, USERNAME to username)
            _onCheckPinCode.postValue(executeUseCase(validatePinCodeUseCase, query))
        }
    }

    fun checkQidValidity(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onCheckQidValidity.postValue(executeUseCase(checkQidValidityUseCase,query))
        }
    }
}