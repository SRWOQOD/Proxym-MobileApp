package com.woqod.account.domain.usecases

import com.woqod.account.domain.repository.AccountRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


open class SendEmailPincode @Inject constructor(
    private val accountRepository: AccountRepository
) : BaseUseCaseWithRequest<HashMap<String, Any?>, WoqodResult<SharedResponse<Boolean>>> {

    override suspend operator fun invoke(request: HashMap<String, Any?>) =
        accountRepository.sendEmailPinCode(request)
}