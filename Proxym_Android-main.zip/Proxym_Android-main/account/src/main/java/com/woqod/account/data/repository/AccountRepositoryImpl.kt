package com.woqod.account.data.repository


import com.woqod.account.data.datasource.AccountDataSource
import com.woqod.account.domain.repository.AccountRepository
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.WoqodResult.Error
import com.woqod.shared.commundomain.WoqodResult.Success
import com.woqod.shared.commundomain.models.UserDetailsModel

class AccountRepositoryImpl(private val accountDataSource: AccountDataSource) : AccountRepository {

    override suspend fun getUserDetails(): WoqodResult<SharedResponse<UserDetailsModel>> {
        return when (val result = accountDataSource.getUserDetails()) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.mapToDomainModel()
                        )
                    )
                )
            }
            is Error -> {
                Error(result.exception)
            }
        }
    }

    override suspend fun postSendRecoveryCode(request: HashMap<String, String>): WoqodResult<SharedResponse<UserDetailsModel>> {
        TODO("Not yet implemented")
    }


    override suspend fun updateUser(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsModel>> =
        when (val result = accountDataSource.updateUser(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.mapToDomainModel()
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserPhoto(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsModel>> =
        when (val result = accountDataSource.updateUserPhoto(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result.mapToDomainModel()
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserPhoneNumber(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = accountDataSource.updateUserPhoneNumber(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserEmail(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = accountDataSource.updateUserEmail(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun sendEmailPinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = accountDataSource.sendEmailPinCode(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

    override suspend fun sendPhonePinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = accountDataSource.sendPhonePinCode(request)) {
            is Success -> {
                val data = result.data
                Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is Error -> Error(result.exception)
        }

}