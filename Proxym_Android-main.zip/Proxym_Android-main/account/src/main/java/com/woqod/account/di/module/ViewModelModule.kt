package com.woqod.account.di.module

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.woqod.account.presentation.personalinformation.AccountViewModel
import com.woqod.shared.di.annotations.ViewModelKey
import com.woqod.shared.di.viewmodels.DaggerViewModelFactory
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap


@Module
@Suppress("UNUSED")
abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(AccountViewModel::class)
    abstract fun bindAccountVM(accountViewModel: AccountViewModel): ViewModel

    @Binds
    abstract fun bindViewModelFactory(factory: DaggerViewModelFactory): ViewModelProvider.Factory

}