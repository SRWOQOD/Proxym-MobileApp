package com.woqod.account.di.component

import com.woqod.account.di.module.RepositoriesModule
import com.woqod.account.di.module.ViewModelModule
import com.woqod.account.di.scope.AccountScope
import com.woqod.account.presentation.personalinformation.UserProfileFragment
import com.woqod.account.presentation.personalinformation.UserProfileOtpFragment
import com.woqod.shared.WoqodApplication
import com.woqod.shared.di.component.SharedComponent
import dagger.Component


@AccountScope
@Component(
    modules = [ViewModelModule::class, RepositoriesModule::class],
    dependencies = [SharedComponent::class]
)
interface AccountComponent {

    fun inject(userProfileFragment: UserProfileFragment)
    fun inject(userProfileOtpFragment: UserProfileOtpFragment)


    @Component.Factory
    interface AccountComponentFactory {
        fun create(sharedComponent: SharedComponent): AccountComponent
    }

}


object GetAccountComponent {

    @Volatile
    private var INSTANCE: AccountComponent? = null

    fun getInstance(): AccountComponent =
        INSTANCE ?: synchronized(this) {
            INSTANCE ?: DaggerAccountComponent.factory().create(WoqodApplication.sharedComponent)
                .also { INSTANCE = it }
        }
}