package com.woqod.account.di.module

import com.woqod.account.data.datasource.AccountDataSourceImpl
import com.woqod.account.data.repository.AccountRepositoryImpl
import com.woqod.account.di.scope.AccountScope
import com.woqod.account.domain.repository.AccountRepository
import dagger.Module
import dagger.Provides

@Module
object RepositoriesModule {

    @Provides
    @AccountScope
    fun provideAccountRepository(): AccountRepository {
        return AccountRepositoryImpl(AccountDataSourceImpl())
    }

}