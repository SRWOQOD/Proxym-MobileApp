package com.woqod.account.presentation.personalinformation

import android.os.Bundle
import com.woqod.account.R
import com.woqod.account.databinding.UserProfileOtpFragmentBinding
import com.woqod.account.di.component.AccountComponent
import com.woqod.account.di.component.GetAccountComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.EMAIL
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.PHONE
import com.woqod.shared.commun.USERNAME
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.commundata.IPADDRESS
import com.woqod.shared.commundomain.models.UserDetailsModel
import com.woqod.shared.utils.*
import com.woqod.shared.widget.PopUpType


class UserProfileOtpFragment :
    BaseViewModelFragment<AccountViewModel, UserProfileOtpFragmentBinding>(
        UserProfileOtpFragmentBinding::inflate
    ) {

    private val accountComponent: AccountComponent by lazy {
        GetAccountComponent.getInstance()
    }
    private var username = ""
    private var email = ""
    private var mobile = ""
    private var currentUser: UserDetailsModel? = null
    private var params: HashMap<String, String>? = null
    override val viewModel: AccountViewModel by injectViewModel()

    fun newInstance(params: HashMap<String, String>): UserProfileOtpFragment {
        val args = Bundle()
        args.putSerializable(OTP_ARGS, params)
        val fragment = UserProfileOtpFragment()
        fragment.arguments = args
        return fragment
    }

    override fun initViews() {
        accountComponent.inject(this)
        arguments?.let { params = it.getSerializable(OTP_ARGS) as HashMap<String, String> }
        if (params?.get(OTP_FOR_USER_PROFILE) == EMAIL_UPDATE) {
            binding.pinCodeComponent.updateWordingString(
                getString(R.string.AccountUserVerifyEmail),
                getString(R.string.AccountUserOTPDescEmail)
            )
            binding.pinCodeComponent.updateComponentIcon(R.drawable.ic_otp_mail)
        } else if (params?.get(OTP_FOR_USER_PROFILE) == PHONE_UPDATE) {
            binding.pinCodeComponent.updateWordingString(
                getString(R.string.AccountUserVerifyPhone),
                getString(R.string.AccountUserOTPDescPhone)
            )
            binding.pinCodeComponent.updateComponentIcon(R.drawable.ic_envelop)
        }

        binding.toolbarUserOtp.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }
        binding.pinCodeComponent.initPinCodeObservers(this,
            doOnResend = { resendActivateCode() },
            doOnConfirm = { verifyOtp() },
            doOnHideKeyBoard = { hideKeyboard() })
        disableDefaultBackPress(true)
    }

    override fun onBackPressCustomAction() {
        super.onBackPressCustomAction()
        val fragmentManager = activity.supportFragmentManager
        fragmentManager.beginTransaction()
            .remove(this) // "this" refers to current instance of Fragment2
            .commit()
        fragmentManager.popBackStack()
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
        sharedPreferences.user?.let { currentUser = it }
        sendOtp()
    }


    private fun verifyOtp() {
        viewModel.checkSecurityCodeValidity(username, binding.pinCodeComponent.pinCode())
    }

    private fun resendActivateCode() {
        sendOtp()
    }

    override fun initObservers() {
        viewModel.onSendEmailPincode.observe(this) {
            it.error?.let { error ->
                togglePopUp(error)
            }
        }
        viewModel.onCheckPinCode.observe(this) {
            it.result?.let { isValid ->
                if (isValid) {
                    proceed()
                } else {
                    binding.pinCodeComponent.showError(getString(R.string.wrong_pincode))
                    binding.pinCodeComponent.resetValues()
                }
            }

            it.error?.let { error -> togglePopUp(error) }
        }

        viewModel.onSuccessUserEmailUpdate.observe(this) { it ->
            it.result?.let { isEmailUpdated ->
                if (isEmailUpdated) {
                    togglePopUp(
                        message = getString(R.string.AccountUserUpdateEmailSuccessMsg),
                        action = {
                            sharedPreferences.user = currentUser?.copy(email = email)
                            goToUserProfile()
                        }, popUpType = PopUpType.POPUP_SUCCESS
                    )

                }
            }
            it.error?.let { error ->
                togglePopUp(error)
            }
        }

        viewModel.onSuccessUserMobileUpdate.observe(this) {
            it.result?.let { isPhoneUpdated ->
                if (isPhoneUpdated) {
                    togglePopUp(
                        message = getString(R.string.AccountUserUpdatePhoneSuccessMsg),
                        action = {
                            sharedPreferences.user = currentUser?.copy(mobileNumber = mobile)
                            goToUserProfile()
                        }, popUpType = PopUpType.POPUP_SUCCESS
                    )

                }
            }
        }

        viewModel.onSendPhonePincode.observe(viewLifecycleOwner, {
            it.error?.let {

            }
        })
    }


    private fun goToUserProfile() = viewModel.navigate(Navigation.USER_PROFILE, null)

    private fun proceed() {
        params?.let {
            when (it[OTP_FOR_USER_PROFILE]) {
                EMAIL_UPDATE -> {
                    viewModel.updateEmail(
                        hashMapOf(
                            USERNAME to username,
                            EMAIL to it[NEW_VALUE],
                            IPADDRESS to getIpAddress()
                        )
                    )
                }
                PHONE_UPDATE -> {
                    viewModel.updatePhoneNumber(
                        hashMapOf(
                            USERNAME to username,
                            PHONE to it[NEW_VALUE],
                            IPADDRESS to getIpAddress()
                        )
                    )
                }
            }
        }
    }

    private fun sendOtp() {
        params?.let {
            username = it[USERNAME].toString()
            when (it[OTP_FOR_USER_PROFILE]) {
                EMAIL_UPDATE -> {
                    email = it[NEW_VALUE].toString()
                    viewModel.sendEmailPinCode(
                        hashMapOf(
                            USERNAME to it[USERNAME],
                            EMAIL to email
                        )
                    )
                }
                PHONE_UPDATE -> {
                    mobile = it[NEW_VALUE].toString()
                    viewModel.sendPhonePinCode(
                        hashMapOf(
                            USERNAME to it[USERNAME],
                            PHONE to mobile
                        )
                    )
                }
            }
        }
    }

}