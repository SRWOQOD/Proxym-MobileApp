package com.woqod.account.presentation.personalinformation


import android.app.DatePickerDialog
import android.content.Intent
import androidx.core.view.forEach
import coil.load
import coil.transform.CircleCropTransformation
import com.woqod.account.R
import com.woqod.account.databinding.FragmentUserProfileBinding
import com.woqod.account.di.component.AccountComponent
import com.woqod.account.di.component.GetAccountComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.commun.imagepickermanager.FragmentImagePickerManager
import com.woqod.shared.commun.imagepickermanager.IMAGE_CAPTURE_CODE
import com.woqod.shared.commun.imagepickermanager.IMAGE_GALLERY_CODE
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.models.UserDetailsModel
import com.woqod.shared.utils.EMAIL_UPDATE
import com.woqod.shared.utils.NEW_VALUE
import com.woqod.shared.utils.OTP_FOR_USER_PROFILE
import com.woqod.shared.utils.PHONE_UPDATE
import com.woqod.shared.widget.EditableComponent
import com.woqod.shared.widget.ImagePickerDialog
import com.woqod.shared.widget.PopUpType
import timber.log.Timber
import java.io.File
import java.util.*

class UserProfileFragment :
    BaseViewModelFragment<AccountViewModel, FragmentUserProfileBinding>(FragmentUserProfileBinding::inflate) {

    private val accountComponent: AccountComponent by lazy {
        GetAccountComponent.getInstance()
    }

    override val viewModel: AccountViewModel by injectViewModel()

    private val imageManager: FragmentImagePickerManager by lazy {
        FragmentImagePickerManager(this, activity)
    }

    private val datePickerListener =
        DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            binding.tvBirthDayUserProfile.setValue(
                getString(
                    R.string.CommonDateOfBirthForm, dayOfMonth.formatDayAndMonthDate(),
                    (month + 1).formatDayAndMonthDate(), year.toString()
                )
            )
        }

    private lateinit var currentUser: UserDetailsModel
    private lateinit var listAreas: List<AreaModel>
    private lateinit var selectedArea: AreaModel
    private var profilePic: File? = null
    private val datePicker: DatePickerDialog by lazy { initDatePicker() }
    private var isInputsEnabled = false
    private var fragmentAttached = false

    override fun onStart() {
        super.onStart()
        if (!fragmentAttached) {
            initValues()
            fragmentAttached = true
        } else {
            onEditBtnClicked()
        }
    }

    private fun onEditBtnClicked() {
        binding.root.scrollTo(0, 0)
        onEditButtonClicked()
    }


    override fun initViews() {
        accountComponent.inject(this)
        binding.ivEditImageProfile.hide()
        initInputs()
        initClickListeners()
        disableDefaultBackPress(true)
        binding.tvAddressUserProfile.setComponentMinHeight(220)

    }


    private fun initClickListeners() {
        binding.toolbarProfile.btnToolbar.setOnClickListener {
            onBackPressCustomAction()
        }

        binding.apply {
            ivEditImageProfile.setOnClickListener {
                openImagePickerDialog()
            }
            tvEditUserProfile.setOnClickListener {
                onEditBtnClicked()
            }


            tvSaveUserProfile.setOnClickListener {
                onSaveButtonClicked()
            }
            tvSaveUserEmail.setOnClickListener {
                if (currentUser.email != binding.tvEmailUserProfile.getValue())
                    onSaveUserEmailClicked()
                else togglePopUp(
                    getString(R.string.AccountUserUpdateConfirmation),
                    buttonTitle = getString(R.string.BoNotificationok),
                    popUpType = PopUpType.POP_WARNING
                )
            }

            tvSaveUserMobile.setOnClickListener {
                if (currentUser.mobileNumber != binding.tvMobileNumberUserProfile.getValue()) {
                    onSaveMobileNumberClicked()
                } else togglePopUp(
                    getString(R.string.AccountUserUpdateConfirmation),
                    buttonTitle = getString(R.string.BoNotificationok),

                    popUpType = PopUpType.POP_WARNING
                )
            }
        }

    }

    private fun onSaveMobileNumberClicked() {
        val mobile = binding.tvMobileNumberUserProfile.getValue()
        if (validateUserMobile(mobile)) {
            checkQidValidity(mobile)
        }
    }

    private fun onEditButtonClicked() {
        binding.apply {
            tvEditUserProfile.hide()
            tvSaveUserProfile.show()
            tvSaveUserEmail.show()
            tvSaveUserMobile.show()
            ivEditImageProfile.show()
            spinnerEditProfileAreaOfResidence.show()
            tvResidenceUserProfile.hide()
        }
        initInputs(true)
        viewModel.requestAreas()
        binding.tvBirthDayUserProfile.apply {
            setDrawableEnd(R.drawable.ic_calendar)
            setEditableClickListener {
                showDatePicker()
                this.getValue().toTimeStamp()?.let {
                    val calendar = Calendar.getInstance()
                    calendar.time = Date(it)
                    datePicker.datePicker.updateDate(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH))
                }
            }
        }
    }

    private fun isNameChanged(name: String) =
        name != currentUser.firstName

    private fun isLastNameChanged(lastname: String) =
        lastname != currentUser.lastName


    private fun isAddressChanged(address: String) =
        address != currentUser.addressLabel

    private fun isPoBoxChanged(poBox: String) =
        poBox != currentUser.poBox

    private fun isBirthDateChanged(birthDate: String) =
        birthDate != currentUser.birthDay()

    private fun isResidenceChanged(area: String) =
        area != currentUser.area.areaName()

    private fun onSaveUserEmailClicked() {
        val email = binding.tvEmailUserProfile.getValue()
        if (validateUserEmail(email)) {
            viewModel.navigate(
                Navigation.USER_PROFILE_OTP, hashMapOf(
                    OTP_FOR_USER_PROFILE to EMAIL_UPDATE,
                    NEW_VALUE to email,
                    USERNAME to currentUser.userName
                )
            )
        }
    }

    private fun onSaveButtonClicked() {
        val user = getUpdatedUserModel()
        if (isInputChanged(user))
            updateUser(user)
        else
            togglePopUp(
                getString(R.string.AccountUserUpdateConfirmation),
                buttonTitle = getString(R.string.BoNotificationok),
                popUpType = PopUpType.POP_WARNING
            )
    }

    private fun updateUser(user: UserDetailsModel) {
        if (validateInputs(user)) {
            initInputs()
            binding.apply {
                ivEditImageProfile.hide()
                tvSaveUserProfile.hide()
                tvSaveUserMobile.hide()
                tvSaveUserEmail.hide()
                tvEditUserProfile.show()
                spinnerEditProfileAreaOfResidence.invisible()
                tvResidenceUserProfile.show()
                binding.tvBirthDayUserProfile.isClickable = false
                tvBirthDayUserProfile.setDrawableEnd()
                spinnerEditProfileAreaOfResidence.hideSpinnerDropDown()
            }

            user.also { viewModel.onSubmitUpdate(it) }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        imageManager.onSuccessResult(requestCode, resultCode,
            onCamera = { profilePic = it },
            onGallery = { data?.let { profilePic = data.data!!.fileFromURI(activity) } }
        )
        profilePic?.let { pic ->
            pic.compress(activity)?.also {
                sharedPreferences.userPhoto = it.toBase64()
                binding.ivUserProfile.load(it) { transformations(CircleCropTransformation()) }
                viewModel.updateUserPhoto(
                    hashMapOf(
                        USERNAME to currentUser.userName,
                        PHOTO to sharedPreferences.userPhoto
                    )
                )
            }
        }
    }

    private fun showDatePicker() {
        with(datePicker) {
            datePicker.maxDate = java.lang.System.currentTimeMillis()
            show()
        }
    }

    private fun initDatePicker(): DatePickerDialog {
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH) + 1
        val month = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        return DatePickerDialog(
            activity,
            R.style.DatePickerTheme,
            datePickerListener,
            year,
            month,
            day
        )
    }

    private fun initValues() {
        if (this::currentUser.isInitialized) {
            currentUser.apply {
                initValues()
            }
        } else {
            sharedPreferences.user
                ?.apply {
                    currentUser = this
                    initValues()
                }
        }

    }

    private fun UserDetailsModel.initValues() {
        binding.apply {
            tvNameUserProfile.setValue(firstName)
            tvFamilyNameUserProfile.setValue(lastName)
            try {
                tvMobileNumberUserProfile.setValue(mobileNumber)
            }catch (e  : Exception) {
                Timber.e(e)
            }
            tvEmailUserProfile.setValue(email)
            tvBirthDayUserProfile.setValue(
                birthDay() ?: getString(R.string.CommonUndefinedProfileValue)
            )
            tvAddressUserProfile.setValue(if (addressLabel.isEmpty()) getString(R.string.CommonUndefinedProfileValue) else addressLabel)
            tvPoBoxUserProfile.setValue(if (poBox.isEmpty()) getString(R.string.CommonUndefinedProfileValue) else poBox)
            tvResidenceUserProfile.setValue(
                if (area.areaName.isNotEmpty()) area.areaName() else getString(
                    R.string.CommonUndefinedProfileValue
                )
            )
            ivUserProfile.loadUserPicture(sharedPreferences.userPhoto)
            selectedArea = area
        }

    }

    private fun isInputChanged(userInfo: UserDetailsModel): Boolean {
        val resultList = listOf(
            isNameChanged(userInfo.firstName),
            isLastNameChanged(userInfo.lastName),
            isAddressChanged(getAddressValue()),
            isPoBoxChanged(getPoBoxValue()),
            isBirthDateChanged(binding.tvBirthDayUserProfile.getValue()),
            isResidenceChanged(userInfo.area.areaName)
        )
        return resultList.any { it }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        imageManager.onRequestPermissionsResult(requestCode, grantResults)
    }

    private fun openImagePickerDialog() {
        val imagePickerDialog = ImagePickerDialog(
            onCamera = { imageManager.takePhoto(IMAGE_CAPTURE_CODE) },
            onGallery = { imageManager.takePhoto(IMAGE_GALLERY_CODE) })
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        activity.supportFragmentManager.findFragmentByTag(IMAGE_PICKER_DIALOG_TAG)
            ?.let { fragmentTransaction.remove(it) }
            .also { fragmentTransaction.addToBackStack(null) }
        with(imagePickerDialog) {
            show(fragmentTransaction, IMAGE_PICKER_DIALOG_TAG)
        }
    }

    private fun initInputs(isEnabled: Boolean = false) {
        isInputsEnabled = isEnabled
        binding.layoutForm.forEach {
            if (it is EditableComponent) {
                it.isEnabled(isEnabled)
                it.setFilledBackground(!isEnabled)
                changeEmailTitle(it,isEnabled)
                changePhoneTitle(it,isEnabled)
                checkIfInputIsMandatory(it,isEnabled)
            }
        }
    }


    private fun changeEmailTitle(input: EditableComponent ,isEnabled: Boolean) {
        if (input.id == R.id.tv_email_user_profile) {
            if (isEnabled) input.addMandatoryIndication(getString(R.string.EditProfileEditEmailTitle)) else input.setEditableTitle(
                getString(R.string.CommonEmail)
            )
        }
    }

    private fun changePhoneTitle(input: EditableComponent,isEnabled: Boolean) {
        if (input.id == R.id.tv_mobileNumber_user_profile) {
            if (isEnabled) input.addMandatoryIndication(getString(R.string.EditProfileEditMobileNumberTitle)) else input.setEditableTitle(
                getString(R.string.CommonMobileNumber)
            )
        }
    }


    private fun checkIfInputIsMandatory(input: EditableComponent,isEnabled: Boolean) {
        if ((input.id != R.id.tv_address_user_profile) && (input.id != R.id.tv_poBox_user_profile))
            input.inputIsMandatory = !isEnabled
    }

    private fun validateUserAddress() = with(binding.tvAddressUserProfile) {
        getValue().isNotEmpty() && getValue() != getString(R.string.CommonUndefinedProfileValue)

    }

    private fun validateUserPOBox() = with(binding.tvPoBoxUserProfile) {
        getValue().isNotEmpty() && getValue() != getString(R.string.CommonUndefinedProfileValue)

    }


    private fun validateInputs(userInfo: UserDetailsModel): Boolean {
        var validate = true
        with(binding) {
            val nameError = ValidationsUtils.isNameValid(userInfo.firstName)
            val familyNameError = ValidationsUtils.isFamilyValid(userInfo.lastName)
            val poBoxError = ValidationsUtils.isPoBoxValid(userInfo.poBox)
            val addressError = ValidationsUtils.isAddressValid(userInfo.addressLabel)



            if (nameError != 0) {
                validate = false
                tvNameUserProfile.showError(getString(nameError))
            }
            if (familyNameError != 0) {
                validate = false
                tvFamilyNameUserProfile.showError(getString(familyNameError))
            }
            if (poBoxError != 0 && validateUserPOBox()) {
                validate = false
                tvPoBoxUserProfile.showError(getString(poBoxError))
            }
            if (addressError != 0 && validateUserAddress()) {
                validate = false
                tvAddressUserProfile.showError(getString(addressError))
            }


        }
        return validate
    }


    private fun validateUserEmail(email: String): Boolean {
        var validate = true
        val emailError = ValidationsUtils.isEmailValid(email)
        if (emailError != 0) {
            validate = false
            binding.tvEmailUserProfile.showError(getString(emailError))
        }
        return validate
    }

    private fun validateUserMobile(phoneNumber: String): Boolean {
        var validate = true
        val phoneError = ValidationsUtils.isMobileValid(phoneNumber)
        if (phoneError != 0) {
            validate = false
            binding.tvMobileNumberUserProfile.showError(getString(phoneError))
        }
        return validate
    }

    private fun getUpdatedUserModel() = UserDetailsModel(
        firstName = binding.tvNameUserProfile.getValue(),
        lastName = binding.tvFamilyNameUserProfile.getValue(),
        mobileNumber = currentUser.mobileNumber,
        email = currentUser.email,
        addressLabel = getAddressValue(),
        birthDate = binding.tvBirthDayUserProfile.getValue().toServerTimeStamp(),
        income = currentUser.income,
        fleetName = currentUser.fleetName,
        unlockAccount = currentUser.unlockAccount,
        type = currentUser.type,
        userName = currentUser.userName,
        preferredLanguage = languageUtils.getAppLanguage(),
        qid = currentUser.qid,
        createdAt = currentUser.createdAt,
        id = currentUser.id,
        status = currentUser.status,
        poBox = getPoBoxValue(),
        area = selectedArea
    )


    private fun getPoBoxValue() =
        if (binding.tvPoBoxUserProfile.getValue() == getString(R.string.CommonUndefinedProfileValue)) "" else binding.tvPoBoxUserProfile.getValue()

    private fun getAddressValue() =
        if (binding.tvAddressUserProfile.getValue() == getString(R.string.CommonUndefinedProfileValue)) "" else binding.tvAddressUserProfile.getValue()


    private fun initSpinner(areas: List<String>) {
        binding.spinnerEditProfileAreaOfResidence.initSpinner(activity, areas) {
            for (item in listAreas) {
                if (item.areaName == it) {
                    selectedArea = item
                }
            }
        }
        binding.spinnerEditProfileAreaOfResidence.setFilledBackground(setFilled = false)
        binding.spinnerEditProfileAreaOfResidence.setValue(currentUser.area.areaName())
    }

    override fun initObservers() {
        viewModel.onRequestAreas.observe(this, {
            it.result?.let { result ->
                listAreas = result
                initSpinner(result.map { area -> area.areaName() })
            }
            it.error?.let { error -> togglePopUp(error) }
        })

        viewModel.onSuccessUserUpdate.observe(this, {
            it.result?.let { result -> onSuccessUpdate(result) }
            it.error?.let { error -> togglePopUp(error) }
        })

        viewModel.onSuccessUserPhotoUpdate.observe(this, {
            it.result?.let {
                togglePopUp(
                    getString(R.string.AccountUserUpdateProfilePicMsg),
                    popUpType = PopUpType.POPUP_SUCCESS
                )


            }
            it.error?.let { error -> togglePopUp(error) }
        })
        viewModel.onCheckQidValidity.observe(this) {
            it.result?.let { result ->
                if (result) viewModel.navigate(
                    Navigation.USER_PROFILE_OTP, hashMapOf(
                        OTP_FOR_USER_PROFILE to PHONE_UPDATE,
                        NEW_VALUE to binding.tvMobileNumberUserProfile.getValue(),
                        USERNAME to currentUser.userName
                    )
                )
            }

            it.error?.let { error -> togglePopUp(error) }

        }
    }

    private fun onSuccessUpdate(user: UserDetailsModel) {
        currentUser = user
        sharedPreferences.user = currentUser.also {
            initValues()
            togglePopUp(
                getString(R.string.AccountUserUpdateSuccessMsg),
                popUpType = PopUpType.POPUP_SUCCESS
            )
        }
    }


    private fun checkQidValidity(mobile: String) {
        hashMapOf<String, Any>(
            QID to currentUser.qid,
            NUMBER to mobile
        ).also { viewModel.checkQidValidity(it) }
    }


    override fun onBackPressCustomAction() {
        if (isInputsEnabled) {
            binding.apply {
                ivEditImageProfile.hide()
                tvSaveUserProfile.hide()
                tvSaveUserMobile.hide()
                tvSaveUserEmail.hide()
                tvEditUserProfile.show()
                spinnerEditProfileAreaOfResidence.invisible()
                tvResidenceUserProfile.show()
                binding.tvBirthDayUserProfile.isClickable = false
                tvBirthDayUserProfile.setDrawableEnd()

            }
            initValues()
            initInputs()
        } else {
            viewModel.navigate(Navigation.HOME, null)
        }
    }

}
