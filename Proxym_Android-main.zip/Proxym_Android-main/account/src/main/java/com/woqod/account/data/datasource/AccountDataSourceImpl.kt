package com.woqod.account.data.datasource

import com.google.gson.Gson
import com.woqod.account.data.*
import com.woqod.shared.commundata.fromJsonToObjectType
import com.woqod.shared.commundata.getRequest
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundata.models.UserDetailsResponse
import com.woqod.shared.commundata.postRequest
import com.woqod.shared.commundata.verifySuccessCode
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.WoqodResult.Error
import com.woqod.shared.commundomain.WoqodResult.Success
import com.worklight.wlclient.api.WLResourceRequest

class AccountDataSourceImpl : AccountDataSource {

    override suspend fun getUserDetails(): WoqodResult<SharedResponse<UserDetailsResponse>> {
        return when (val result = getRequest(GET_USER_DETAILS_URL)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }
    }

    override suspend fun postSendRecoveryCode(request: HashMap<String, String>): WoqodResult<SharedResponse<UserDetailsResponse>> {
        TODO("Not yet implemented")
    }

    override suspend fun updateUser(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsResponse>> =
        when (val result = postRequest(PUT_USER_URL, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserPhoto(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsResponse>> =
        when (val result = postRequest(PUT_UPDATE_PROFILE_PHOTO, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserPhoneNumber(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_UPDATE_PROFILE_PHONE_NUMBER, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }

    override suspend fun updateUserEmail(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_UPDATE_PROFILE_EMAIL, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }

    override suspend fun sendEmailPinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_UPDATE_PROFILE_EMAIL, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }

    override suspend fun sendPhonePinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_UPDATE_PROFILE_PHONE, request)) {
            is Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is Error -> Error(result.exception)
        }



}

