package com.woqod.account.domain.usecases

import com.woqod.account.domain.repository.AccountRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCase
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.UserDetailsModel
import javax.inject.Inject


open class GetUsersDetailsUseCase @Inject constructor(
    private val accountRepository: AccountRepository
) : BaseUseCase<WoqodResult<SharedResponse<UserDetailsModel>>> {

    override suspend operator fun invoke() =
        accountRepository.getUserDetails()
}