package com.woqod.account.domain.repository

import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult
import com.woqod.shared.commundomain.models.UserDetailsModel


interface AccountRepository {

    suspend fun getUserDetails(): WoqodResult<SharedResponse<UserDetailsModel>>
    suspend fun postSendRecoveryCode(request: HashMap<String, String>): WoqodResult<SharedResponse<UserDetailsModel>>
    suspend fun updateUser(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsModel>>
    suspend fun updateUserPhoto(request: HashMap<String, Any?>): WoqodResult<SharedResponse<UserDetailsModel>>
    suspend fun updateUserPhoneNumber(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun updateUserEmail(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendEmailPinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun sendPhonePinCode(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>


}