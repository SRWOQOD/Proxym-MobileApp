package com.woqod.authentication.presentation.register


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.authentication.domain.usecases.PostRegisterUseCase
import com.woqod.authentication.utils.REGISTER_FIRST_STEP
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commundomain.ResultUseCase
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.models.UserInfo
import com.woqod.shared.commundomain.sharedusecases.GetCheckQidValidityUseCase
import com.woqod.shared.commundomain.sharedusecases.GetCheckUserUseCase
import com.woqod.shared.commundomain.sharedusecases.GetListAreasUseCase
import com.woqod.shared.utils.LanguageUtils
import kotlinx.coroutines.launch
import javax.inject.Inject

class RegisterViewModel @Inject constructor(
    private val languageUtils: LanguageUtils,
    private val getCheckQidValidityUseCase: GetCheckQidValidityUseCase,
    private val postRegisterUseCase: PostRegisterUseCase,
    private val getCheckUserUseCase: GetCheckUserUseCase,
    private val getListAreasUseCase: GetListAreasUseCase
) : BaseViewModel() {


    private val _onRequestAreas = SingleLiveEvent<ResultUseCase<List<AreaModel>?, String?>>()
    val onRequestAreas: LiveData<ResultUseCase<List<AreaModel>?, String?>> get() = _onRequestAreas

    private val _onCheckQidValidity = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckQidValidity: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckQidValidity

    private val _resultRegistration = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val resultRegistration: LiveData<ResultUseCase<Boolean?, String?>> = _resultRegistration

    private val _onCheckUserFistStep = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckUserFistStep: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckUserFistStep

    private val _onCheckUserSecondStep = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onCheckUserSecondStep: LiveData<ResultUseCase<Boolean?, String?>> = _onCheckUserSecondStep

    fun requestAreas() {
        viewModelScope.launch {
            _onRequestAreas.postValue(executeUseCase(getListAreasUseCase))
        }
    }

    /**
     * check if the mobile number is associated to the qid via MOTC API
     */
    fun checkQidValidity(query: HashMap<String, Any>) {
        viewModelScope.launch {
            _onCheckQidValidity.postValue(executeUseCase(getCheckQidValidityUseCase, query))
        }
    }

    fun register(query: HashMap<String, Any?>) {
        viewModelScope.launch {
            _resultRegistration.postValue(executeUseCase(postRegisterUseCase, query))
        }
    }


    fun onSubmitRegistration(userInfo: UserInfo) {
        hashMapOf<String, Any?>(
            FIRST_NAME to userInfo.firstName,
            LAST_NAME to userInfo.lastName,
            MOBILE_NUMBER to userInfo.mobileNumber,
            EMAIL to userInfo.email,
            ADDRESS to userInfo.addressLabel,
            PO_BOX to userInfo.poBox,
            AREA_ID to userInfo.areaId,
            BIRTH_DATE to userInfo.birthDate.toString(),
            QID to userInfo.qid,
            USERNAME to userInfo.username,
            TYPE to INDIVIDUAL_CUSTOMER,
            CONTACT_TYPE to CONTACT_TYPE_MAIL,
            PASSWORD to userInfo.password,
            LANGUAGE to languageUtils.getAppLanguage(),
            GENDER to userInfo.gender
        ).also {
            register(it)
        }
    }

    /**
     * Check if user exist
     */
    fun checkUser(source: Int, query: HashMap<String, Any>) {
        viewModelScope.launch {
            if (source == REGISTER_FIRST_STEP) {
                _onCheckUserFistStep.postValue(executeUseCase(getCheckUserUseCase, query))
            } else {
                _onCheckUserSecondStep.postValue(executeUseCase(getCheckUserUseCase, query))
            }
        }
    }

}