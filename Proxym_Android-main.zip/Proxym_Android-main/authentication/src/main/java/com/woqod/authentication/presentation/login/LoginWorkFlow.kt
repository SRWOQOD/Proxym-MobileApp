package com.woqod.authentication.presentation.login

import com.woqod.authentication.utils.AuthenticationType

object LoginWorkFlow {
    var username: String = ""
    var temporaryCachedCode: String = ""
    var connectionType: String = AuthenticationType.USERNAME_AUTH
    var isRememberMe: Boolean = false
    var isRedirect = false
    var isFahes = false

    fun clearLoginCache() {
        username = ""
        temporaryCachedCode = ""
        connectionType = ""
        isRememberMe = false
        isRedirect = false
        isFahes = false
    }
}