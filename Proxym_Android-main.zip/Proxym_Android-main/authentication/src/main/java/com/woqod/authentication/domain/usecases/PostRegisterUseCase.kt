package com.woqod.authentication.domain.usecases

import com.woqod.authentication.domain.repository.AuthenticationRepository
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.BaseUseCaseWithRequest
import com.woqod.shared.commundomain.WoqodResult
import javax.inject.Inject


class PostRegisterUseCase @Inject constructor(
    private val authenticationRepository: AuthenticationRepository
) : BaseUseCaseWithRequest<HashMap<String, Any?>, WoqodResult<SharedResponse<Boolean>>> {

    override suspend operator fun invoke(request: HashMap<String, Any?>) =
        authenticationRepository.register(request)
}