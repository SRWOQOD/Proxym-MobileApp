package com.woqod.authentication.data

import com.woqod.shared.commundata.BASE_API_ADAPTER_URL

const val POST_CHECK_FINGERPRINT_URL = "$BASE_API_ADAPTER_URL/checkFingerPrint"
const val POST_BIO_URL = "$BASE_API_ADAPTER_URL/addBioPin"
const val GET_CUSTOM_PASSWORD_URL = "$BASE_API_ADAPTER_URL/generateCustomPwd"
const val GET_OTP_CODE = "$BASE_API_ADAPTER_URL/pincode/login/send"
const val VALIDATE_OTP_CODE ="$BASE_API_ADAPTER_URL/pincode/login/validatePinCode"
const val VERIFY_CREDENTIALS ="$BASE_API_ADAPTER_URL/login/verifyCredentials"

const val PUT_UPDATE_BIOMETRIC_STATUS ="$BASE_API_ADAPTER_URL/bio/updateStatus"

const val POST_REGISTER = "$BASE_API_ADAPTER_URL/register/register"
const val POST_ACCOUNT_ACTIVATION = "$BASE_API_ADAPTER_URL/register/activate"

const val GET_PROFILE_PHOTO_URL = "$BASE_API_ADAPTER_URL/users/getProfilePhoto"
const val POST_RECOVER_PASSWORD = "$BASE_API_ADAPTER_URL/register/recover"
const val PUT_RESEND_ACTIVATION_CODE = "$BASE_API_ADAPTER_URL/register/sendpincode"
const val PUT_RESET_BIOPIN = "$BASE_API_ADAPTER_URL/resetBioPin"
const val PUT_RESET_PASSWORD = "$BASE_API_ADAPTER_URL/users/password"