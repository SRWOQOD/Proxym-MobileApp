package com.woqod.authentication.presentation.login


import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.authentication.domain.usecases.VerifyCredentialsUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject

class LoginViewModel @Inject constructor(
    private val verifyCredentialsUseCase: VerifyCredentialsUseCase
) : BaseViewModel() {

    private val _onVerifyCredentialsSuccess = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onVerifyCredentialsSuccess: LiveData<ResultUseCase<Boolean?, String?>> get() = _onVerifyCredentialsSuccess

    fun verifyCredentials(query: HashMap<String, String>) {
        viewModelScope.launch {
            _onVerifyCredentialsSuccess.postValue(executeUseCase(verifyCredentialsUseCase, query))
        }
    }
}