package com.woqod.authentication.data.repository

import com.woqod.authentication.data.datasource.AuthenticationDataSource
import com.woqod.authentication.domain.repository.AuthenticationRepository
import com.woqod.shared.commundata.models.SharedBody
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult


class AuthenticationRepositoryImpl(private val authenticationDataSource: AuthenticationDataSource) :
    AuthenticationRepository {

    override suspend fun verifyFingerprintActivation(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = authenticationDataSource.verifyFingerprintActivation(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun postBiometrics(request: HashMap<String, String>): WoqodResult<SharedResponse<String>> {
        return when (val result = authenticationDataSource.postBiometrics(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun verifyCredentials(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = authenticationDataSource.verifyCredentials(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> {
                WoqodResult.Error(result.exception)
            }
        }
    }

    override suspend fun register(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.postRegister(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.postAccountActivation(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.postRecoveryCode(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postRecoverPassword(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.postRecoverPassword(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }



    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.putResendActivationCode(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun putResetBiopin(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.putResetBiopin(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(data.body.type, data.body.result)
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postResetPassword(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = authenticationDataSource.postResetPassword(request)) {
            is WoqodResult.Success -> {
                val data = result.data
                WoqodResult.Success(
                    SharedResponse(
                        data.isSuccessful,
                        data.header,
                        SharedBody(
                            data.body.type,
                            data.body.result
                        )
                    )
                )
            }
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

}
