package com.woqod.authentication.presentation.register

import android.view.WindowManager
import com.woqod.authentication.R
import com.woqod.authentication.databinding.FragmentRegisterThirdStepBinding
import com.woqod.authentication.di.component.AuthenticationComponent
import com.woqod.authentication.di.component.GetAuthenticationComponent
import com.woqod.authentication.presentation.register.RegistrationWorkFlow.areaName
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.CONTACT_TYPE_MAIL
import com.woqod.shared.commun.INDIVIDUAL_CUSTOMER
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.Navigation.PRIVACY_AND_POLICY
import com.woqod.shared.commun.Navigation.TERMS_OF_CONDITIONS
import com.woqod.shared.commun.ValidationsUtils
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.commun.extensions.setBackgroundTint
import com.woqod.shared.commundomain.models.AreaModel
import com.woqod.shared.commundomain.models.UserInfo
import com.woqod.shared.utils.FROM_REGISTRATION
import com.woqod.shared.utils.OTP_FOR_REGISTER
import com.woqod.shared.utils.OTP_SOURCE

class RegisterThirdStepFragment :
    BaseViewModelFragment<RegisterViewModel, FragmentRegisterThirdStepBinding>(
        FragmentRegisterThirdStepBinding::inflate
    ) {

    private val authenticationComponent: AuthenticationComponent by lazy {
        GetAuthenticationComponent.getInstance()
    }

    override val viewModel: RegisterViewModel by injectViewModel()

    private lateinit var listAreas: List<AreaModel>
    private var selectedAreaId = ""

    override fun onStart() {
        super.onStart()
        initValues()
    }

    override fun initViews() {
        authenticationComponent.inject(this)
        activity.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        initIndicator()
        binding.etRegistrationAddress
            .setComponentMinHeight(220)
        binding.spRegistrationArea.setFilledBackground(setFilled = false)
        binding.etRegistrationAddress.setComponentHeight(250)
        viewModel.requestAreas()
        initClickListeners()
    }

    private fun initValues() {
        with(binding) {
            spRegistrationArea.setValue(areaName)
            etRegistrationAddress.setValue(RegistrationWorkFlow.address1Label)
            etRegistrationPoBox.setValue(RegistrationWorkFlow.poBox)
            selectedAreaId = RegistrationWorkFlow.areaId
            etRegistrationPassword.setValue(RegistrationWorkFlow.temporaryCachedCode)
            checkboxRegisterPrivacy.isChecked = RegistrationWorkFlow.privacyPolicy
            checkboxRegisterTermsOfUse.isChecked = RegistrationWorkFlow.termOfUse
        }
    }

    private fun initIndicator() {
        with(binding.indicatorRegister) {
            indicatorRegistrationFirst.setBackgroundTint(activity, R.color.color_98A5CC_63)
            indicatorRegistrationSecond.setBackgroundTint(activity, R.color.color_98A5CC_63)
            indicatorRegistrationThird.setBackgroundTint(activity, R.color.color_002280)
        }
    }

    private fun initClickListeners() {
        binding.toolbarRegister.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }

        with(binding) {
            etRegistrationAddress.imeKeyBoardAction { etRegistrationPoBox.requestFocus() }
            etRegistrationPoBox.imeKeyBoardAction { etRegistrationPassword.requestFocus() }
            etRegistrationPassword.imeKeyBoardAction { etRegistrationConfirmPassword.requestFocus() }
            etRegistrationConfirmPassword.imeKeyBoardAction { submitForm() }
            tvRegisterNextStep3.setOnClickListener { submitForm() }
            clRegisterThird.setOnClickListener {
                hideKeyboard()
                binding.spRegistrationArea.hideSpinnerDropDown()
            }
            checkboxRegisterTermsOfUse.setOnCheckedChangeListener { _, isChecked ->
                RegistrationWorkFlow.termOfUse = isChecked
            }
            checkboxRegisterPrivacy.setOnCheckedChangeListener { _, isChecked ->
                RegistrationWorkFlow.privacyPolicy = isChecked
            }

            tvRegisterTermsOfUse.setOnClickListener {
                viewModel.navigate(
                    TERMS_OF_CONDITIONS,
                    hashMapOf(FROM_REGISTRATION to true)
                )
            }
            tvRegisterPrivacy.setOnClickListener {
                viewModel.navigate(
                    PRIVACY_AND_POLICY,
                    hashMapOf(FROM_REGISTRATION to true)
                )
            }
        }
    }

    private fun submitForm() {
        hideKeyboard()
        binding.spRegistrationArea.hideSpinnerDropDown()
        if (validateInputs()) {
            saveRegistrationFlow()
            onSubmitRegistration()
        }
    }

    private fun saveRegistrationFlow() {
        with(RegistrationWorkFlow) {
            areaId = selectedAreaId
            address1Label = binding.etRegistrationAddress.getValue()
            poBox = binding.etRegistrationPoBox.getValue()
            temporaryCachedCode = binding.etRegistrationPassword.getValue()
            temporaryCachedConfirmCode = binding.etRegistrationConfirmPassword.getValue()
        }
    }

    private fun handleAreaList(list: List<AreaModel>) {
        if (list.isNotEmpty()) {
            listAreas = list
            selectedAreaId = list.first().idArea
            areaName = list.first().areaName
            initSpinner(list.map { area -> area.areaName() })
        }
    }

    override fun initObservers() {
        viewModel.onRequestAreas.observe(this, {
            it.result?.let { result ->
                handleAreaList(result)
            }
            it.error?.let { error -> togglePopUp(error) }
        })

        viewModel.resultRegistration.observe(this, {
            it.result?.let { result -> onRegistrationResponse(result) }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun initSpinner(areas: List<String>) {
        binding.spRegistrationArea.initSpinner(activity, areas) {
            for (item in listAreas) {
                if (item.areaName == it) {
                    selectedAreaId = item.idArea
                    areaName = item.areaName
                }
            }
        }
        //binding.spRegistrationArea.setValue(areas.first())
    }

    private fun validateInputs(): Boolean {
        var validate = true
        val addressError = ValidationsUtils.isAddressValid(binding.etRegistrationAddress.getValue())
        val poBoxError = ValidationsUtils.isPoBoxValid(binding.etRegistrationPoBox.getValue())
        val passwordError =
            ValidationsUtils.isPasswordValid(binding.etRegistrationPassword.getValue())
        val confirmationPasswordError = ValidationsUtils.isPasswordConfirmationValid(
            binding.etRegistrationPassword.getValue(),
            binding.etRegistrationConfirmPassword.getValue()
        )

        if (addressError != 0 && binding.etRegistrationAddress.getValue().isNotEmpty()) {
            validate = false
            binding.etRegistrationAddress.showError(getString(addressError))
        }
        if (poBoxError != 0 && binding.etRegistrationPoBox.getValue().isNotEmpty()) {
            validate = false
            binding.etRegistrationPoBox.showError(getString(poBoxError))
        }
        if (passwordError != 0) {
            validate = false
            binding.etRegistrationPassword.showError(getString(passwordError))
        }
        if (confirmationPasswordError != 0) {
            validate = false
            binding.etRegistrationConfirmPassword.showError(getString(confirmationPasswordError))
        }
        if (selectedAreaId.isEmpty()) {
            validate = false
            binding.spRegistrationArea.setError(getString(R.string.FahesBookingCarPlateTypeError))
        }

        if (!validate) return false
        if (!binding.checkboxRegisterPrivacy.isChecked && !binding.checkboxRegisterTermsOfUse.isChecked) {
            validate = false
            togglePopUp(getString(R.string.AuthenticationRegistrationAcceptTermsAndPrivacyErrorMsg))
        } else if (!binding.checkboxRegisterPrivacy.isChecked) {
            validate = false
            togglePopUp(getString(R.string.AuthenticationRegistrationAcceptPrivacyErrorMsg))
        } else if (!binding.checkboxRegisterTermsOfUse.isChecked) {
            validate = false
            togglePopUp(getString(R.string.AuthenticationRegistrationAcceptTermsErrorMsg))
        } else {
            // both are checked
        }
        return validate
    }

    private fun onSubmitRegistration() {
        UserInfo(
            RegistrationWorkFlow.firstName,
            RegistrationWorkFlow.lastName,
            RegistrationWorkFlow.mobileNumber,
            RegistrationWorkFlow.email,
            RegistrationWorkFlow.address1Label,
            RegistrationWorkFlow.poBox,
            RegistrationWorkFlow.areaId,
            RegistrationWorkFlow.birthDate,
            RegistrationWorkFlow.qid,
            RegistrationWorkFlow.userName,
            INDIVIDUAL_CUSTOMER,
            CONTACT_TYPE_MAIL,
            RegistrationWorkFlow.temporaryCachedCode,
            RegistrationWorkFlow.gender
        ).also {
            viewModel.onSubmitRegistration(it)
        }
    }

    private fun onRegistrationResponse(isRegisterSuccessful: Boolean) {
        if (isRegisterSuccessful) {
            viewModel.navigate(Navigation.OTP, hashMapOf(OTP_SOURCE to OTP_FOR_REGISTER))
        } else {
            togglePopUp(getString(R.string.AuthenticationRegistrationRegistrationFailed))
        }
    }


    override fun onStop() {
        super.onStop()
        saveRegistrationFlow()
    }

}