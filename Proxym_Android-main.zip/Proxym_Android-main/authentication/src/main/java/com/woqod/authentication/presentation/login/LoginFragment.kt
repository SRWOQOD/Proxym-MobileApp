package com.woqod.authentication.presentation.login

import android.os.Bundle
import com.woqod.authentication.R
import com.woqod.authentication.databinding.FragmentLoginBinding
import com.woqod.authentication.di.component.AuthenticationComponent
import com.woqod.authentication.di.component.GetAuthenticationComponent
import com.woqod.authentication.presentation.UserChallengeHandler
import com.woqod.authentication.presentation.register.RegistrationWorkFlow
import com.woqod.authentication.utils.AuthenticationType
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.ValidationsUtils.isEmailValid
import com.woqod.shared.commun.ValidationsUtils.isUserNameValid
import com.woqod.shared.commun.extensions.*
import com.woqod.shared.utils.*
import com.woqod.shared.widget.PopUpType
import java.util.*


/**
 * onBackPress is de-activated inside LoginFragment
 */
class LoginFragment :
    BaseViewModelFragment<LoginViewModel, FragmentLoginBinding>(FragmentLoginBinding::inflate) {

    private val authenticationComponent: AuthenticationComponent by lazy {
        GetAuthenticationComponent.getInstance()
    }

    override val viewModel: LoginViewModel by injectViewModel()

    private var selectedType = AuthenticationType.USERNAME_AUTH
    private var params: HashMap<String, String>? = null

    private lateinit var username: String
    private lateinit var password: String

    override fun onStart() {
        super.onStart()
        isRememberMe(sharedPreferences.isRememberMe)
    }


    private fun isRememberMe(isRememberMe: Boolean) {
        binding.tvLoginRememberMe.isChecked = isRememberMe
        if (isRememberMe) {
            binding.tvLoginUsername.setValue(sharedPreferences.rememberusername)

        } else {
            binding.tvLoginUsername.setValue(LoginWorkFlow.username)
        }
    }

    fun newInstance(params: HashMap<String, String>): LoginFragment {
        val args = Bundle()
        args.putSerializable(LOGIN_ARGS, params)
        val fragment = LoginFragment()
        fragment.arguments = args
        return fragment
    }

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        authenticationComponent.inject(this)
        arguments?.let {
            if (it.containsKey(LOGIN_ARGS))
                params = it.getSerializable(LOGIN_ARGS) as HashMap<String, String>
        }
        RegistrationWorkFlow.clearRegistrationCache()
        UserChallengeHandler.createAndRegister()
        setClickListeners()
        verifyFingerPrintActivation()
    }

    override fun handleFragmentArgs() {
        params?.let {
            disableDefaultBackPress(true)
            LoginWorkFlow.isRedirect = false
            when (it[FRAGMENT_SOURCE]) {
                LOGIN_FROM_FAHES -> {
                    LoginWorkFlow.isRedirect = true
                    LoginWorkFlow.isFahes = true
                }
                LOGIN_FROM_WOQODE -> {
                    LoginWorkFlow.isRedirect = true
                    LoginWorkFlow.isFahes = false
                }
                NULL_ENTITY -> {
                    disableDefaultBackPress(true)
                }
            }
        } ?: disableDefaultBackPress(true)
    }

    private fun verifyFingerPrintActivation() {
        if (biometricsExistOnDevice(activity) && sharedPreferences.isBiometricActivated && !sharedPreferences.customPasswordForBiometric.isNullOrEmpty()) {
            binding.groupLoginBiometric.show()
            binding.groupLoginBiometric.addOnClickListener {
                handleFingerPrintAuthentication()
            }
        } else {
            binding.groupLoginBiometric.hide()
        }
    }

    private fun setClickListeners() {
        binding.tvLoginForgotPassword.setOnClickListener {
            username = binding.tvLoginUsername.getValue().toLowerCase(Locale.ROOT)

            if (username.isNotEmpty() && validateUserNameLogin(username) == 0) {
                showSendOtpCustomPopUp()

            } else {
                togglePopUp(
                    getString(R.string.ForgotPwdErrorMessage),
                    popUpType = PopUpType.POP_WARNING
                )
            }
        }
        binding.tvLoginGo.setOnClickListener { attemptToLogin() }
        binding.tvLoginSignUp.setOnClickListener {
            viewModel.navigate(Navigation.REGISTER_STEP1, null)
        }
        binding.tvLoginContinueGuest.setOnClickListener {
            sharedPreferences.guestMode = true
            redirect()
        }
        binding.toolbarLogin.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
    }

    private fun navigateToForgetPwdOtp() {
        val params = hashMapOf(
            OTP_SOURCE to OTP_FOR_FORGET_PWD
        )
        LoginWorkFlow.username = username
        LoginWorkFlow.connectionType = selectedType

        viewModel.navigate(Navigation.OTP, params)
    }

    private fun showSendOtpCustomPopUp() {
        togglePopUpChoice(
            getString(R.string.recoveryPassword),
            getString(R.string.recoveryPasswordDesc),
            firstOption = {},
            secondOption = {
                navigateToForgetPwdOtp()
            },
            getString(R.string.CommonCancel),
            getString(R.string.BoNotificationok),
            R.drawable.ic_popup_lock
        )
    }

    /**
     * Username and password will be checked via ws call.
     * If success we navigate to OTP screen where the actual login will take place
     */
    private fun verifyCredentials() {
        if (validateInputs()) {
            username = binding.tvLoginUsername.getValue().toLowerCase(Locale.ROOT)
            password = binding.tvLoginPassword.getValue()
            sharedPreferences.isRememberMe = binding.tvLoginRememberMe.isChecked
            viewModel.verifyCredentials(
                hashMapOf(
                    USERNAME to username.encode64(),
                    TYPE to selectedType,
                    PASSWORD to password.encode64()
                )
            )
        }
    }

    /**
     * Check validity of Login and password
     */
    private fun validateInputs(): Boolean {
        val username = binding.tvLoginUsername.getValue().toLowerCase(Locale.ROOT)
        val userNameError = validateUserNameLogin(username)
        val passwordError =
            ValidationsUtils.isPasswordValid(binding.tvLoginPassword.getValue(), fromLogin = true)

        if (userNameError != 0 && passwordError != 0) {
            binding.tvLoginUsername.showError(getString(userNameError))
            binding.tvLoginPassword.showError(getString(passwordError))
            return false
        } else if (userNameError != 0) {
            binding.tvLoginUsername.showError(getString(userNameError))
            binding.tvLoginPassword.hideError()
            return false
        } else if (passwordError != 0) {
            binding.tvLoginPassword.showError(getString(passwordError))
            binding.tvLoginUsername.hideError()
            return false
        } else {
            binding.tvLoginUsername.hideError()
            binding.tvLoginPassword.hideError()
        }

        return true
    }

    /**
     * check the format of login input : Email / MobileNumber / QID / else it's Username
     */
    private fun validateUserNameLogin(userName: String): Int {
        var checkPassed = 0
        if (userName.isBlank()) {
            return R.string.CommonLoginIdEmpty
        } else {
            val isMobileOrQID = validateInputWhenNumber(userName)
            if (!isMobileOrQID.first) {
                selectedType = if (isEmailValid(userName) != 0) {
                    checkPassed = isUserNameValid(userName)
                    AuthenticationType.USERNAME_AUTH
                } else {
                    AuthenticationType.EMAIL_AUTH
                }
            } else if (isMobileOrQID.second != 0) {
                return isMobileOrQID.second
            } else {
                // no action to be done
            }
        }
        return checkPassed
    }


    /**
     * Check if input matches Mobile number or QID format
     *
     * @return Pair<Boolean, Int>
     *     Boolean : true if input is composed of Numbers only.
     *     Int : String resources for error when input is all numbers but different from QID and Mobile size.
     */
    private fun validateInputWhenNumber(userName: String): Pair<Boolean, Int> {
        return if (userName.isNumber()) {
            when (userName.length) {
                8 -> {
                    selectedType = AuthenticationType.MOBILE_NUMBER_AUTH
                    Pair(true, 0)
                }
                11 -> {
                    selectedType = AuthenticationType.QID_AUTH
                    Pair(true, 0)
                }
                else -> {
                    Pair(true, R.string.AuthenticationLoginUsernameError)
                }
            }
        } else {
            Pair(false, 0)
        }
    }

    private fun observeOnCredentialsVerification() {
        viewModel.onVerifyCredentialsSuccess.observe(this) {
            it.result?.let { isLoginSuccess ->
                if (isLoginSuccess) {
                    LoginWorkFlow.username = username
                    LoginWorkFlow.temporaryCachedCode = password
                    LoginWorkFlow.connectionType = selectedType
                    LoginWorkFlow.isRememberMe = binding.tvLoginRememberMe.isChecked
                    val params = hashMapOf(
                        OTP_SOURCE to OTP_FOR_LOGIN
                    )

                    viewModel.navigate(Navigation.OTP, params)
                }
            }
            it.error?.let { error ->
                togglePopUp(error)
            }
        }
    }

    private fun handleFingerPrintAuthentication() {
        val biometricPrompt = BiometricPromptUtils.createBiometricPrompt(activity,
            processSuccess =
            {
                viewModel.navigate(
                    Navigation.BIOMETRIC,
                    BiometricNavEntity(
                        BIOMETRIC_SOURCE_LOGIN,
                        isSuccess = true,
                        isFromSettings = false
                    )
                )
            },
            processFailure = {
                if (it != CANCELE)
                    viewModel.navigate(
                        Navigation.BIOMETRIC,
                        BiometricNavEntity(
                            BIOMETRIC_SOURCE_LOGIN,
                            isSuccess = false,
                            isFromSettings = false
                        )
                    )
            }
        )
        val promptInfo = BiometricPromptUtils.createPromptInfo(activity)
        biometricPrompt.authenticate(promptInfo)
    }

    override fun initObservers() {
        observeOnCredentialsVerification()
    }

    private fun showCounterPopup(time: Long) {
        togglePopUp(getString(R.string.LoginAccountBlocked, time.asMinAndSec()))
        startCountDownTimer(time)
    }


    private fun attemptToLogin() {
        hideKeyboard()
        val timeElapsed = Date().time - sharedPreferences.blockedAccountTime
        if (timeElapsed > ACCOUNT_BLOCKED_TIMER) {
            verifyCredentials()
        } else {
            val timeLeft = ACCOUNT_BLOCKED_TIMER - timeElapsed
            showCounterPopup(timeLeft)
        }
    }

    private fun redirect() {
        if (!LoginWorkFlow.isRedirect) {
            viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_LOGIN_GUEST))
        } else if (LoginWorkFlow.isFahes) {
            viewModel.navigate(Navigation.FAHES, null)
        } else {
            viewModel.navigate(Navigation.WOQODE, null)
        }
        LoginWorkFlow.clearLoginCache()
    }


}