package com.woqod.authentication.domain.repository

import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundomain.WoqodResult


interface AuthenticationRepository {
    suspend fun verifyFingerprintActivation(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postBiometrics(request: HashMap<String, String>): WoqodResult<SharedResponse<String>>
    suspend fun verifyCredentials(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>

    suspend fun register(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun postRecoverPassword(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>


    suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>
    suspend fun putResetBiopin(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>>

    suspend fun postResetPassword(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>>
}