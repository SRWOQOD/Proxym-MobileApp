package com.woqod.authentication.utils

import android.app.Activity
import com.woqod.authentication.R

/**
 * Created by Hamdi.BOUMAIZA on 11/27/2020
 */
object GenderUtils {
    fun getListOfGender(activity: Activity) = listOf(
        activity.getString(R.string.AuthenticationGenderMale),
        activity.getString(R.string.AuthenticationGenderFemale)
    )

    fun getGender(gender: String, activity: Activity): String {
        return if (gender == activity.getString(R.string.AuthenticationGenderMale)) {
            EnumGender.Male.name
        } else {
            EnumGender.Female.name
        }
    }

    fun Activity.getGender(gender: String): String {
        return when (gender ) {
            EnumGender.Male.name  -> getString(R.string.AuthenticationGenderMale)
            EnumGender.Female.name ->   getString(R.string.AuthenticationGenderFemale)
            else -> ""

        }
    }
}

enum class EnumGender { Male, Female }


