package com.woqod.authentication.presentation.forget_password

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.woqod.authentication.domain.usecases.PostRecoverPasswordUseCase
import com.woqod.authentication.domain.usecases.ResetPasswordUseCase
import com.woqod.shared.baseui.BaseViewModel
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.encode64
import com.woqod.shared.commundomain.ResultUseCase
import kotlinx.coroutines.launch
import javax.inject.Inject


class ForgetPasswordViewModel @Inject constructor(
    private val postRecoverPasswordUseCase: PostRecoverPasswordUseCase,
    private val postResetPasswordUseCase: ResetPasswordUseCase
) : BaseViewModel() {


    private val _onSuccessRecoveryPwd = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSuccessRecoveryPwd: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSuccessRecoveryPwd

    private val _onSuccessResetPwd = SingleLiveEvent<ResultUseCase<Boolean?, String?>>()
    val onSuccessResetPwd: LiveData<ResultUseCase<Boolean?, String?>> get() = _onSuccessResetPwd

    fun recoverPassword(username: String?, connectionType: String?, password: String) {
        viewModelScope.launch {
            val query: HashMap<String, Any> =
                hashMapOf(
                    USERNAME to (encryptUsernameQid(username,connectionType) ?: ""),
                    TYPE to (connectionType ?: ""),
                    NEW_PASSWORD to password
                )
            _onSuccessRecoveryPwd.postValue(executeUseCase(postRecoverPasswordUseCase, query))
        }
    }

    private fun encryptUsernameQid(userName: String?, type: String?) : String? {
        if (type == "Qid_Auth") {
            return userName?.encode64()
        }
        return userName
    }

    fun resetPassword(username: String, password: String) {
        viewModelScope.launch {
            val query = hashMapOf(USERNAME to username, PASSWORD to password)
            _onSuccessResetPwd.postValue(executeUseCase(postResetPasswordUseCase, query))
        }
    }
}