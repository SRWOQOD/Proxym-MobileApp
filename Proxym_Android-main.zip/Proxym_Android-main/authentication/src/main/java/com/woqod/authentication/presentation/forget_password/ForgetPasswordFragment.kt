package com.woqod.authentication.presentation.forget_password

import android.os.Bundle
import com.woqod.authentication.R
import com.woqod.authentication.databinding.FragmentForgetPasswordBinding
import com.woqod.authentication.di.component.AuthenticationComponent
import com.woqod.authentication.di.component.GetAuthenticationComponent
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.utils.FRAGMENT_SOURCE
import com.woqod.shared.utils.HOME_FROM_PASSWORD_MANAGEMENT
import com.woqod.shared.utils.OTP_FOR_FORGET_PWD
import com.woqod.shared.utils.OTP_FOR_RESET
import com.woqod.shared.widget.PopUpType

class ForgetPasswordFragment : BaseViewModelFragment<ForgetPasswordViewModel, FragmentForgetPasswordBinding>(FragmentForgetPasswordBinding::inflate) {

    private val authenticationComponent: AuthenticationComponent by lazy {
        GetAuthenticationComponent.getInstance()
    }

    override val viewModel: ForgetPasswordViewModel by injectViewModel()

    private var params: HashMap<String, String>? = null

    fun newInstance(params: HashMap<String, String>) =
        ForgetPasswordFragment().apply {
            arguments = Bundle().apply {
                putSerializable(FORGET_PASSWORD_ARGS, params)
            }
        }

    @Suppress("UNCHECKED_CAST")
    override fun initViews() {
        authenticationComponent.inject(this)
        arguments?.let {
            params = it.getSerializable(FORGET_PASSWORD_ARGS) as HashMap<String, String>
        }
        initClickListeners()
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
        params?.let {
            when (it[FRAGMENT_SOURCE]) {
                OTP_FOR_RESET -> {
                 binding.resetPasswordTitle.text=getString(R.string.forget_password)
                }
                OTP_FOR_FORGET_PWD -> {
                    binding.resetPasswordTitle.text=getString(R.string.recoveryPassword)
                }
            }
        }
    }

    override fun initObservers() {
        viewModel.onSuccessRecoveryPwd.observe(this, {
            it.result?.let {
                togglePopUp(
                    message = getString(R.string.PasswordRecoverySuccess),
                    action = {
                        viewModel.navigate(Navigation.LOGIN, null)
                    },
                    popUpType = PopUpType.POPUP_SUCCESS
                )
            }
            it.error?.let { error -> togglePopUp(error) }
        })

        viewModel.onSuccessResetPwd.observe(this) {
            it.result?.let { isSuccess ->
                if (isSuccess) {
                    handleRestPwdSuccess()
                }
            }
            it.error?.let { error -> togglePopUp(error) }
        }
    }

    private fun handleRestPwdSuccess() {
        togglePopUp(
            getString(R.string.PasswordRecoverySuccess),
            action = {
                viewModel.navigate(Navigation.HOME, hashMapOf(FRAGMENT_SOURCE to HOME_FROM_PASSWORD_MANAGEMENT))
            },
            popUpType = PopUpType.POPUP_SUCCESS
        )
    }

    private fun setSubmitBtnClick() {
        params?.let {
            when (it[FRAGMENT_SOURCE]) {
                OTP_FOR_RESET -> {
                    viewModel.resetPassword(sharedPreferences.username, binding.etForgetPwdNewPwd.getValue())
                }
                OTP_FOR_FORGET_PWD -> {
                    viewModel.recoverPassword(it[USERNAME], it[TYPE], binding.etForgetPwdNewPwd.getValue())
                }
            }
        }
    }

    private fun initClickListeners() {
        binding.toolbarTop.btnToolbar.setOnClickListener {
            handleBackPressed()
        }
        binding.etForgetPwdNewPwd.imeKeyBoardAction { binding.etForgetPwdConfirmPassword.requestFocus() }
        binding.etForgetPwdConfirmPassword.imeKeyBoardAction { onSubmitResetPassword() }
        binding.btnForgetPwdSubmit.setOnClickListener { onSubmitResetPassword() }
    }

    override fun onBackPressCustomAction() {
        handleBackPressed()
    }

    private fun onSubmitResetPassword() {
        hideKeyboard()
        if (validateInputs()) setSubmitBtnClick()
    }

    private fun validateInputs(): Boolean {
        var validate = true
        val passwordError = ValidationsUtils.isPasswordValid(binding.etForgetPwdNewPwd.getValue())
        val confirmationPasswordError =
            ValidationsUtils.isPasswordConfirmationValid(
                binding.etForgetPwdNewPwd.getValue(),
                binding.etForgetPwdConfirmPassword.getValue()
            )

        if (passwordError != 0) {
            validate = false
            binding.etForgetPwdNewPwd.showError(getString(passwordError))
        }
        if (confirmationPasswordError != 0) {
            validate = false
            binding.etForgetPwdConfirmPassword.showError(getString(confirmationPasswordError))
        }
        return validate
    }

    private fun handleBackPressed(){
        params?.let {
            when (it[FRAGMENT_SOURCE]) {
                // backPress behavior can be changed based on client demand
                OTP_FOR_FORGET_PWD -> {
                   viewModel.navigate(Navigation.LOGIN,null)
                }
                OTP_FOR_RESET -> {
                    viewModel.navigate(Navigation.HOME,null)
                }
            }
        }
    }


}