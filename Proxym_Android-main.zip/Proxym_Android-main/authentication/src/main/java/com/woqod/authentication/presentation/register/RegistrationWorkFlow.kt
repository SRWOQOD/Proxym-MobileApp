package com.woqod.authentication.presentation.register

object RegistrationWorkFlow {
    var firstName: String = ""
    var lastName: String = ""
    var mobileNumber: String = ""
    var email: String = ""
    var address1Label: String = ""
    var poBox: String = ""
    var areaId: String = ""
    var areaName: String = ""
    var birthDate: Long? = 0L
    var birthDateValue: String = ""
    var qid: String = ""
    var userName: String = ""
    var type: String = ""
    var contactType: String = ""
    var temporaryCachedCode: String = ""
    var temporaryCachedConfirmCode: String = ""
    var gender: String = ""
    var termOfUse: Boolean = false
    var privacyPolicy: Boolean = false

    fun clearRegistrationCache() {
        firstName = ""
        lastName = ""
        mobileNumber = ""
        email = ""
        address1Label = ""
        poBox = ""
        areaId = ""
        areaName = ""
        birthDate = 0L
        birthDateValue = ""
        qid = ""
        userName = ""
        type = ""
        contactType = ""
        temporaryCachedCode = ""
        temporaryCachedConfirmCode = ""
        gender = ""
        termOfUse = false
        privacyPolicy = false
    }
}