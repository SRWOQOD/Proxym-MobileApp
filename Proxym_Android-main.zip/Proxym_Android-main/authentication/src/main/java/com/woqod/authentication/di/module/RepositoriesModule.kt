package com.woqod.authentication.di.module

import com.woqod.authentication.data.datasource.AuthenticationDataSourceImpl
import com.woqod.authentication.data.repository.AuthenticationRepositoryImpl
import com.woqod.authentication.di.scope.AuthenticationScope
import com.woqod.authentication.domain.repository.AuthenticationRepository
import dagger.Module
import dagger.Provides

@Module
object RepositoriesModule {

    @Provides
    @AuthenticationScope
    fun provideAuthenticationRepository(): AuthenticationRepository {
        val authenticationDataSourceImpl = AuthenticationDataSourceImpl()
        return AuthenticationRepositoryImpl(authenticationDataSourceImpl)
    }

}