package com.woqod.authentication.di.component

import com.woqod.authentication.di.module.RepositoriesModule
import com.woqod.authentication.di.module.ViewModelModule
import com.woqod.authentication.di.scope.AuthenticationScope
import com.woqod.authentication.presentation.forget_password.ForgetPasswordFragment
import com.woqod.authentication.presentation.login.LoginFragment
import com.woqod.authentication.presentation.register.RegisterFirstStepFragment
import com.woqod.authentication.presentation.register.RegisterSecondStepFragment
import com.woqod.authentication.presentation.register.RegisterThirdStepFragment
import com.woqod.shared.WoqodApplication
import com.woqod.shared.di.component.SharedComponent
import dagger.Component


@AuthenticationScope
@Component(
    modules = [ViewModelModule::class, RepositoriesModule::class],
    dependencies = [SharedComponent::class]
)
interface AuthenticationComponent {

    fun inject(loginFragment: LoginFragment)
    fun inject(registerFirstStepFragment: RegisterFirstStepFragment)
    fun inject(registerSecondStepFragment: RegisterSecondStepFragment)
    fun inject(registerThirdStepFragment: RegisterThirdStepFragment)
    fun inject(forgetPasswordFragment: ForgetPasswordFragment)

    @Component.Factory
    interface AuthenticationComponentFactory {
        fun create(sharedComponent: SharedComponent): AuthenticationComponent
    }

}


object GetAuthenticationComponent {

    @Volatile
    private var INSTANCE: AuthenticationComponent? = null

    fun getInstance(): AuthenticationComponent =
        INSTANCE ?: synchronized(this) {
            INSTANCE ?: DaggerAuthenticationComponent.factory().create(WoqodApplication.sharedComponent)
                .also { INSTANCE = it }
        }
}
