package com.woqod.authentication.utils

const val REGISTER_FIRST_STEP = 0
const val REGISTER_SECOND_STEP = 1
const val REGISTER_THIRD_STEP = 2
