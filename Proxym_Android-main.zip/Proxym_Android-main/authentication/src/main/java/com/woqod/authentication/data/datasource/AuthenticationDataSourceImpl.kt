package com.woqod.authentication.data.datasource

import com.google.gson.Gson
import com.woqod.authentication.data.*
import com.woqod.shared.commundata.POST_RECOVERY_CODE
import com.woqod.shared.commundata.fromJsonToObjectType
import com.woqod.shared.commundata.models.SharedResponse
import com.woqod.shared.commundata.postRequest
import com.woqod.shared.commundata.verifySuccessCode
import com.woqod.shared.commundomain.WoqodResult
import com.worklight.wlclient.api.WLResourceRequest

class AuthenticationDataSourceImpl : AuthenticationDataSource {
    override suspend fun verifyFingerprintActivation(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = postRequest(POST_CHECK_FINGERPRINT_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
    }

    override suspend fun postBiometrics(request: HashMap<String, String>): WoqodResult<SharedResponse<String>> {
        return when (val result = postRequest(POST_BIO_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
    }


    override suspend fun getCustomPassword(request: HashMap<String, Any>): WoqodResult<SharedResponse<String>> {
        return when (val result = postRequest(GET_CUSTOM_PASSWORD_URL, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
    }

    override suspend fun verifyCredentials(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> {
        return when (val result = postRequest(VERIFY_CREDENTIALS, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }
    }

    override suspend fun postRegister(request: HashMap<String, Any?>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_REGISTER, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postAccountActivation(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_ACCOUNT_ACTIVATION, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postRecoveryCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_RECOVERY_CODE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun postRecoverPassword(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(POST_RECOVER_PASSWORD, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


    override suspend fun putResendActivationCode(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_RESEND_ACTIVATION_CODE, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun putResetBiopin(request: HashMap<String, Any>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_RESET_BIOPIN, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }

    override suspend fun postResetPassword(request: HashMap<String, String>): WoqodResult<SharedResponse<Boolean>> =
        when (val result = postRequest(PUT_RESET_PASSWORD, request)) {
            is WoqodResult.Success -> verifySuccessCode(Gson().fromJsonToObjectType(result.data.toString()))
            is WoqodResult.Error -> WoqodResult.Error(result.exception)
        }


}

