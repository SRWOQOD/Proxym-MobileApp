package com.woqod.authentication.presentation.register

import android.view.WindowManager
import com.woqod.authentication.R
import com.woqod.authentication.databinding.FragmentRegisterFirstStepBinding
import com.woqod.authentication.di.component.AuthenticationComponent
import com.woqod.authentication.di.component.GetAuthenticationComponent
import com.woqod.authentication.utils.REGISTER_FIRST_STEP
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.*
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.commun.extensions.setBackgroundTint

/**
 * onBackPress is des-activated inside RegisterFirstStepFragment
 */
class RegisterFirstStepFragment :
    BaseViewModelFragment<RegisterViewModel, FragmentRegisterFirstStepBinding>(FragmentRegisterFirstStepBinding::inflate) {

    private val authenticationComponent: AuthenticationComponent by lazy {
        GetAuthenticationComponent.getInstance()
    }

    override val viewModel: RegisterViewModel by injectViewModel()

    override fun onStart() {
        super.onStart()
        initValues()
    }

    override fun initViews() {
        authenticationComponent.inject(this)
        activity.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        initIndicator()
        initClickListeners()
    }


    override fun handleFragmentArgs() {
        disableDefaultBackPress(true)
    }

    private fun initIndicator() {
        with(binding.indicatorRegister) {
            indicatorRegistrationFirst.setBackgroundTint(activity, R.color.color_002280)
            indicatorRegistrationSecond.setBackgroundTint(activity, R.color.color_98A5CC_63)
            indicatorRegistrationThird.setBackgroundTint(activity, R.color.color_98A5CC_63)
        }
    }

    private fun initValues() {
        binding.etRegistrationQid.setValue(RegistrationWorkFlow.qid)
        binding.etRegistrationMobile.setValue(RegistrationWorkFlow.mobileNumber)
    }

    private fun initClickListeners() {
        binding.toolbarRegister.btnToolbar.setOnClickListener {
            viewModel.navigate(Navigation.MENU, null)
        }
        with(binding) {
            etRegistrationQid.imeKeyBoardAction { binding.etRegistrationMobile.requestFocus() }
            etRegistrationMobile.imeKeyBoardAction { submitForm() }
            tvRegisterNextStep1.setOnClickListener { submitForm() }
            clRegister.setOnClickListener { hideKeyboard() }

        }
    }

    private fun submitForm() {
        hideKeyboard()
        val qatariId = binding.etRegistrationQid.getValue()
        val mobile = binding.etRegistrationMobile.getValue()
        if (validateInputs(qatariId, mobile)) {

            saveRegistrationFlow()
                checkUser(RegistrationWorkFlow.qid, RegistrationWorkFlow.mobileNumber)

        }
    }

    private fun saveRegistrationFlow() {
        with(RegistrationWorkFlow) {
            type = INDIVIDUAL_CUSTOMER
            contactType = CONTACT_TYPE_MAIL
            qid = binding.etRegistrationQid.getValue()
            mobileNumber = binding.etRegistrationMobile.getValue()
        }
    }


    private fun checkQidValidity(qid: String, mobile: String) {
        viewModel.checkQidValidity(hashMapOf(QID to qid, NUMBER to mobile))
    }

    private fun checkUser(qid: String, mobile: String) {
        viewModel.checkUser(REGISTER_FIRST_STEP, hashMapOf(QID to qid, MOBILE_NUMBER to mobile))
    }

    override fun initObservers() {
        viewModel.onCheckQidValidity.observe(viewLifecycleOwner, {
            it.result?.let { result ->
                if (result) {
                    goToNextScreen()
                } else {
                    togglePopUp(getString(R.string.AuthenticationRegistrationVerifyYourCredentials))
                }
            }
            it.error?.let { error -> togglePopUp(error) }
        })
        viewModel.onCheckUserFistStep.observe(viewLifecycleOwner, {
            it.result?.let { onUserChecked() }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun onUserChecked() {
        with(RegistrationWorkFlow) { checkQidValidity(qid, mobileNumber) }
    }

    private fun validateInputs(qid: String, mobile: String): Boolean {
        var validate = true
        val qidError = ValidationsUtils.isQidValid(qid)
        val mobileError = ValidationsUtils.isMobileValid(mobile)
        if (qidError != 0) {
            validate = false
            binding.etRegistrationQid.showError(getString(qidError))
        }
        if (mobileError != 0) {
            validate = false
            binding.etRegistrationMobile.showError(getString(mobileError))
        }
        return validate
    }

    private fun goToNextScreen() {
        viewModel.navigate(Navigation.REGISTER_STEP2, null)
    }

    override fun onPause() {
        super.onPause()
        saveRegistrationFlow()
    }


}