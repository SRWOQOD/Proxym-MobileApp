package com.woqod.authentication.presentation.register

import android.app.DatePickerDialog
import android.view.WindowManager
import com.woqod.authentication.R
import com.woqod.authentication.databinding.FragmentRegisterSecondStepBinding
import com.woqod.authentication.di.component.AuthenticationComponent
import com.woqod.authentication.di.component.GetAuthenticationComponent
import com.woqod.authentication.presentation.register.RegistrationWorkFlow.email
import com.woqod.authentication.presentation.register.RegistrationWorkFlow.userName
import com.woqod.authentication.utils.GenderUtils
import com.woqod.authentication.utils.GenderUtils.getGender
import com.woqod.authentication.utils.REGISTER_SECOND_STEP
import com.woqod.shared.baseui.BaseViewModelFragment
import com.woqod.shared.commun.EMAIL
import com.woqod.shared.commun.Navigation
import com.woqod.shared.commun.USERNAME
import com.woqod.shared.commun.ValidationsUtils
import com.woqod.shared.commun.extensions.formatDayAndMonthDate
import com.woqod.shared.commun.extensions.hideKeyboard
import com.woqod.shared.commun.extensions.setBackgroundTint
import com.woqod.shared.commun.extensions.toTimeStamp
import java.util.*

class RegisterSecondStepFragment :
    BaseViewModelFragment<RegisterViewModel, FragmentRegisterSecondStepBinding>(
        FragmentRegisterSecondStepBinding::inflate
    ) {

    private val authenticationComponent: AuthenticationComponent by lazy {
        GetAuthenticationComponent.getInstance()
    }

    override val viewModel: RegisterViewModel by injectViewModel()

    private val datePicker: DatePickerDialog by lazy { initDatePicker() }
    private var selectedGender = ""


    override fun onStart() {
        super.onStart()
        initValues()
    }

    override fun initViews() {
        authenticationComponent.inject(this)
        activity.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        initIndicator()
        initClickListeners()
        initGenderSpinner()
    }

    override fun handleFragmentArgs() {
        disableDefaultBackPress(false)
    }

    private fun initValues() {
        with(binding) {
            etRegistrationName.setValue(RegistrationWorkFlow.firstName)
            etRegistrationFamily.setValue(RegistrationWorkFlow.lastName)
            etRegistrationUserName.setValue(userName)
            etRegistrationBirthday.setValue(RegistrationWorkFlow.birthDateValue)
            etRegistrationEmail.setValue(email)
           selectedGender =  activity.getGender(RegistrationWorkFlow.gender)
            spRegistrationGender.setValue(selectedGender)
        }
    }

    private fun initIndicator() {
        with(binding.indicatorRegister) {
            indicatorRegistrationFirst.setBackgroundTint(activity, R.color.color_98A5CC_63)
            indicatorRegistrationSecond.setBackgroundTint(activity, R.color.color_002280)
            indicatorRegistrationThird.setBackgroundTint(activity, R.color.color_98A5CC_63)
        }
    }

    private fun initClickListeners() {
        binding.toolbarRegister.btnToolbar.setOnClickListener {
            activity.onBackPressed()
        }
        with(binding) {
            etRegistrationName.imeKeyBoardAction { etRegistrationFamily.requestFocus() }
            etRegistrationFamily.imeKeyBoardAction { etRegistrationUserName.requestFocus() }
            etRegistrationUserName.imeKeyBoardAction { showDatePicker() }
            etRegistrationBirthday.setEditableClickListener { showDatePicker() }
            etRegistrationEmail.imeKeyBoardAction {
                hideKeyboard()
                spRegistrationGender.performClick()
            }
            tvRegisterNextStep2.setOnClickListener { submitForm() }
            clRegisterSecond.setOnClickListener {
                hideKeyboard()
                spRegistrationGender.hideSpinnerDropDown()
            }
        }
    }

    private fun initGenderSpinner() {
        binding.spRegistrationGender.initSpinner(activity, GenderUtils.getListOfGender(activity)) {
            selectedGender = it
        }
        binding.spRegistrationGender.setFilledBackground(setFilled = false)
    }

    override fun initObservers() {
        viewModel.onCheckUserSecondStep.observe(this, {
            it.result?.let { result ->
                if (result) {
                    goToNextScreen()
                } else {
                    togglePopUp(getString(R.string.AuthenticationRegistrationVerifyYourCredentials))
                }
            }
            it.error?.let { error -> togglePopUp(error) }
        })
    }

    private fun submitForm() {
        hideKeyboard()
        if (validateInputs()) {
            saveRegistrationFlow()
            checkUser(userName, email)
        }
    }

    private fun saveRegistrationFlow() {
        with(RegistrationWorkFlow) {
            firstName = binding.etRegistrationName.getValue()
            lastName = binding.etRegistrationFamily.getValue()
            userName = binding.etRegistrationUserName.getValue().toLowerCase(Locale.ROOT)
            email = binding.etRegistrationEmail.getValue()
            birthDate = binding.etRegistrationBirthday.getValue().toTimeStamp()
            gender = getGender(selectedGender, activity)
        }
    }

    private fun checkUser(username: String, email: String) {
        viewModel.checkUser(REGISTER_SECOND_STEP, hashMapOf(USERNAME to username, EMAIL to email))
    }

    private fun initDatePicker(): DatePickerDialog {
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        return DatePickerDialog(
            activity,
            R.style.DatePickerTheme,
            datePickerListener,
            year,
            month,
            day
        )
    }

    private val datePickerListener =
        DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            val dateValue = getString(
                R.string.CommonDateOfBirthForm, dayOfMonth.formatDayAndMonthDate(),
                (month + 1).formatDayAndMonthDate(),
                year.toString()
            )
            RegistrationWorkFlow.birthDateValue = dateValue
            binding.etRegistrationBirthday.setValue(dateValue)
        }

    private fun showDatePicker() {
        with(datePicker) {
            datePicker.maxDate = System.currentTimeMillis()
            show()
        }
    }

    private fun validateInputs(): Boolean {
        var validate = true
        val firstNameError = ValidationsUtils.isNameValid(binding.etRegistrationName.getValue())
        val familyNameError =
            ValidationsUtils.isFamilyValid(binding.etRegistrationFamily.getValue())
        val userNameError =
            ValidationsUtils.isUserNameValid(binding.etRegistrationUserName.getValueWithSpace())
        val emailError = ValidationsUtils.isEmailValid(binding.etRegistrationEmail.getValue())
        val birthDateError = ValidationsUtils.isBirthDateValid(
            binding.etRegistrationBirthday.getValue().toTimeStamp()
        )

        if (firstNameError != 0) {
            validate = false
            binding.etRegistrationName.showError(getString(firstNameError))
        }
        if (familyNameError != 0) {
            validate = false
            binding.etRegistrationFamily.showError(getString(familyNameError))
        }
        if (userNameError != 0) {
            validate = false
            binding.etRegistrationUserName.showError(getString(userNameError))
        }
        if (emailError != 0) {
            validate = false
            binding.etRegistrationEmail.showError(getString(emailError))
        }
        if (birthDateError != 0) {
            validate = false
            binding.etRegistrationBirthday.showError(getString(birthDateError))
        }
        if (selectedGender.isEmpty()) {
            validate = false
             binding.spRegistrationGender.setError(getString(R.string.FahesBookingCarPlateTypeError))
        }
        return validate
    }

    private fun goToNextScreen() {
        viewModel.navigate(Navigation.REGISTER_STEP3, null)
    }

    override fun onPause() {
        super.onPause()
        saveRegistrationFlow()
    }


}