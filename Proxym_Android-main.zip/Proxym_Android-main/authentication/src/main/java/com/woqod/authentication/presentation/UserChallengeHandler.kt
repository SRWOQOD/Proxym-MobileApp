package com.woqod.authentication.presentation

import android.content.Context
import com.woqod.authentication.R
import com.woqod.authentication.presentation.login.LoginWorkFlow
import com.woqod.shared.WoqodApplication
import com.woqod.shared.commun.Event
import com.woqod.shared.commun.SingleLiveEvent
import com.woqod.shared.commundata.fromJsonToObject
import com.woqod.shared.commundata.models.UserDetailsResponse
import com.worklight.wlclient.api.*
import com.worklight.wlclient.api.challengehandler.SecurityCheckChallengeHandler
import com.worklight.wlclient.auth.AccessToken
import org.json.JSONException
import org.json.JSONObject
import timber.log.Timber


/**
 * Copyright 2016 IBM Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class UserChallengeHandler : SecurityCheckChallengeHandler(SECURITY_CHECK_NAME) {
    private val context: Context = WLClient.getInstance().context

    companion object {
        private const val SECURITY_CHECK_NAME = "UserLogin"
        private const val USER = "user"
        private const val ATTRIBUTES = "attributes"

        var isChallenged = SingleLiveEvent<Boolean>()
        var errorStatusCode = SingleLiveEvent<Event<String, *>>()

         var challengeHandler = UserChallengeHandler()
        fun getInstance() = challengeHandler
        fun getIsChallenged() =isChallenged
        fun createAndRegister() {
            WLClient.getInstance().registerChallengeHandler(challengeHandler)
        }
    }

    override fun handleChallenge(jsonObject: JSONObject) {
        //{"header":{"titleEN":"Bad LDAP credentials","titleAR":"اسم المستخدم أو كلمة المرور خاطئة","statusCode":"125"},"remainingAttempts":2}
        Timber.e("handleChallenge ::  $jsonObject")
        val remainingAttempts = jsonObject.get("remainingAttempts").toString()
        errorStatusCode.postValue(
            Event(
                getErrorMessage(
                    remainingAttempts,
                    getErrorMessage(jsonObject)
                ), null
            )
        )
        isChallenged.postValue(true)
    }

    private fun getErrorMessage(jsonObject: JSONObject): String {
        val titleEn = jsonObject.getJSONObject("header").get("titleEN").toString()
        val titleAr = jsonObject.getJSONObject("header").get("titleAR").toString()
        return if (WoqodApplication.sharedComponent.injectLanguageUtils()
                .isArabicLanguage()
        ) titleAr else titleEn
    }

    private fun getErrorMessage(remainingAttempts: String, errorMessage: String): String {
        return if (errorMessage.isNotEmpty()) {
            val remaining = context.getString(
                R.string.AuthenticationLoginLoginRemainingAttempts,
                remainingAttempts
            )
            "$errorMessage \n$remaining"
        } else {
            context.getString(R.string.CommonErrorUnexpectedMessage)
        }
    }

    override fun handleFailure(error: JSONObject) {
        super.handleFailure(error)
        //handleFailure :: {"failure":"Account blocked"}
        Timber.e("handleFailure :: $error")
        errorStatusCode.postValue(Event(error.get("failure").toString(), null))
        isChallenged.postValue(false)
    }

    override fun handleSuccess(identity: JSONObject) {
        super.handleSuccess(identity)
        /**
         *  {"user":{"id":"2","displayName":"ikk Username_Auth","authenticatedAt":1598966358373,"authenticatedBy":"UserLogin",
         *  "attributes":{"income":null,"fleetName":"147258369","lastName":"Username_Auth","vehBrand":null,
         *  "birthdate":1598562000000,"gender":"Female","adress2Label":null,"mobileNumber":"25252525",
         *  "contactType":"Mail","adress2":null,"username":"meriam02","type":"Individual_Customer",
         *  "preferedLanguage":null,"adress1":null,"qid":"147258369","firstName":"ikk",
         *  "createdAt":1598821200000,"vehModel":null,"id":2,"email":"hh","adress1Label":null,"status":"Active"}}}
         */
        Timber.e("handleSuccess :: $identity")
        isChallenged.postValue(false)
        saveUserToSharedPrefs(identity)
    }

    private fun saveUserToSharedPrefs(identity: JSONObject) {
        try {
            val userJson = identity.getJSONObject(USER).getJSONObject(ATTRIBUTES).toString()
            Timber.e("userJson :: $userJson")
            userJson.fromJsonToObject(UserDetailsResponse::class.java)?.mapToDomainModel()?.let {
                WoqodApplication.sharedComponent.appSharedPref().apply {
                    user = it
                    username = it.userName
                    rememberusername = LoginWorkFlow.username
                    guestMode = false
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    fun login(credentials: JSONObject?): SingleLiveEvent<Boolean> {
        val result = SingleLiveEvent<Boolean>()
        if (isChallenged.value == true) {
            submitChallengeAnswer(credentials)
        } else {
            WLAuthorizationManager.getInstance().login(
                SECURITY_CHECK_NAME,
                credentials,
                object : WLLoginResponseListener {
                    override fun onSuccess() {
                        Timber.e("login successful")
                        return result.postValue(true)
                    }

                    override fun onFailure(wlFailResponse: WLFailResponse) {
                        Timber.e("login fail ${wlFailResponse.errorMsg}")
                        return result.postValue(false)
                    }
                })
        }
        return result
    }

    fun logout(): SingleLiveEvent<Boolean> {
        val result = SingleLiveEvent<Boolean>()
        WLAuthorizationManager.getInstance().logout(
            SECURITY_CHECK_NAME,
            object : WLLogoutResponseListener {
                override fun onSuccess() {
                    Timber.e("logout successful")
                    return result.postValue(true)
                }

                override fun onFailure(wlFailResponse: WLFailResponse) {
                    Timber.e("logout fail ${wlFailResponse.errorMsg}")
                    return result.postValue(false)
                }
            })
        return result
    }

    fun getAuthAccessToken(): SingleLiveEvent<String> {
        val token = SingleLiveEvent<String>()
        WLAuthorizationManager.getInstance()
            .obtainAccessToken(SECURITY_CHECK_NAME, object : WLAccessTokenListener {
                override fun onSuccess(accessToken: AccessToken?) {
                    Timber.e("token ${accessToken?.value}")
                    return token.postValue(accessToken?.value)
                }

                override fun onFailure(wlFailResponse: WLFailResponse?) {
                    Timber.e("token fail ${wlFailResponse.toString()}")
                    return token.postValue(null)
                }
            })
        return token
    }
}