package com.woqod.authentication.utils

class AuthenticationType {
    companion object {
        const val USERNAME_AUTH = "Username_Auth"
        const val QID_AUTH = "Qid_Auth"
        const val MOBILE_NUMBER_AUTH = "Mobile_number_Auth"
        const val EMAIL_AUTH = "Email_Auth"
        const val BIO_AUTH = "Bio_Auth"
    }
}