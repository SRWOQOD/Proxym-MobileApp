package com.woqod.adapters.SoapClasses;



public class AccountInquiryResponse {
  public AccountInquiryResult AccountInquiryResult;
 /* public String xmlns;
  public String text;*/
}
