package com.woqod.adapters.utils;

import java.util.Date;

/*
public class Timestamp {
  public Date Created;
  public Date Expires;
  public String Id;
  public String text;
}

public class Security {
  public Timestamp Timestamp;
}

public class Header {
  public String Action;
  public String MessageID;
  public String RelatesTo;
  public String To;
  public Security Security;
}
*/











