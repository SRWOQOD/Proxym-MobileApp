package com.woqod.adapters.SoapClasses;

public class AccountInquiryResult {
  public int FleetID;
  public String Balance;
  public String CivilName;
  public String IsTopUpAllowed;
  public ResponseGeneral ResponseGeneral;
}
