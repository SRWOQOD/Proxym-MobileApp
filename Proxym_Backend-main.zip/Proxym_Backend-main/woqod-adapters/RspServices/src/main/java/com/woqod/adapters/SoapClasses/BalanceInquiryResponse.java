package com.woqod.adapters.SoapClasses;

public class BalanceInquiryResponse {
  public BalanceInquiryResult BalanceInquiryResult;
}
