package com.woqod.adapters.SoapClasses;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Body {
  public AccountInquiryResponse AccountInquiryResponse;
  public BalanceInquiryResponse BalanceInquiryResponse;
}
