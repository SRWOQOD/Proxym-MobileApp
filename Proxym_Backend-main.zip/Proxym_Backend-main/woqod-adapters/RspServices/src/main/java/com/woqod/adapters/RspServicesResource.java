/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.SoapClasses.Envelope;
import com.woqod.adapters.utils.CommonUtils;
import io.swagger.annotations.*;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.logging.Logger;

@Api(value = "Sample Adapter Resource")
@Path("/")
public class RspServicesResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(RspServicesResource.class.getName());
    String AuthName = "WOQODUSERHDR";
    String AuthPass = "#W13O$#O2#%Q4D";
    String Origin = "WOQ-MOBILE";
    String ChannelID = "WOQ-MOBILE";

    String wsseUsername = "WSSECWOQOD";
    String wssePassword = "3O4D##W1#O2$%Q";

    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    @Context
    AdapterSecurityContext securityContext;

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource"
     */

    @ApiOperation(value = "Returns 'Hello from resource'", notes = "A basic example of a resource returning a constant string.")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Hello message returned")})
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getResourceData() {
        // log message to server log
        logger.info("Logging info message...");

        return "Hello from resource";
    }

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource/greet?name={name}"
     */

    @ApiOperation(value = "Query Parameter Example", notes = "Example of passing query parameters to a resource. Returns a greeting containing the name that was passed in the query parameter.")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Greeting message returned")})
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/greet")
    public String helloUser(
            @ApiParam(value = "Name of the person to greet", required = true) @QueryParam("name") String name) {
        return "Hello " + name + "!";
    }

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource/{path}/"
     */

    @ApiOperation(value = "Multiple Parameter Types Example", notes = "Example of passing parameters using 3 different methods: path parameters, headers, and form parameters. A JSON object containing all the received parameters is returned.")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "A JSON object containing all the received parameters returned.")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{path}")
    public Map<String, String> enterInfo(
            @ApiParam(value = "The value to be passed as a path parameter", required = true) @PathParam("path") String path,
            @ApiParam(value = "The value to be passed as a header", required = true) @HeaderParam("Header") String header,
            @ApiParam(value = "The value to be passed as a form parameter", required = true) @FormParam("form") String form) {
        Map<String, String> result = new HashMap<String, String>();

        result.put("path", path);
        result.put("header", header);
        result.put("form", form);

        return result;
    }

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource/prop"
     */

    @ApiOperation(value = "Configuration Example", notes = "Example usage of the configuration API. A property name is read from the query parameter, and the value corresponding to that property name is returned.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Property value returned."),
            @ApiResponse(code = 404, message = "Property value not found.")})
    @GET
    @Path("/prop")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getPropertyValue(
            @ApiParam(value = "The name of the property to lookup", required = true) @QueryParam("propertyName") String propertyName) {
        // Get the value of the property:
        String value = configApi.getPropertyValue(propertyName);
        if (value != null) {
            // return the value:
            return Response
                    .ok("The value of " + propertyName + " is: " + value)
                    .build();
        } else {
            return Response.status(Status.NOT_FOUND)
                    .entity("No value for " + propertyName + ".").build();
        }

    }

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource/unprotected"
     */

    @ApiOperation(value = "Unprotected Resource", notes = "Example of an unprotected resource, this resource is accessible without a valid token.")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "A constant string is returned")})
    @GET
    @Path("/unprotected")
    @Produces(MediaType.TEXT_PLAIN)
    @OAuthSecurity(enabled = false)
    public String unprotected() {
        return "Hello from unprotected resource!";
    }

    /*
     * Path for method:
     * "<server address>/mfp/api/adapters/RspServices/resource/protected"
     */

    @ApiOperation(value = "Custom Scope Protection", notes = "Example of a resource that is protected by a custom scope. To access this resource a valid token for the scope 'myCustomScope' must be acquired.")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "A constant string is returned")})
    @GET
    @Path("/protected")
    @Produces(MediaType.TEXT_PLAIN)
    @OAuthSecurity(scope = "myCustomScope")
    public String customScopeProtected() {
        return "Hello from a resource protected by a custom scope!";
    }

    public AuthenticatedUser getCurrentUser() {
        AuthenticatedUser user = securityContext.getAuthenticatedUser();
        return user;
    }

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Property value returned."),
            @ApiResponse(code = 404, message = "Property value not found.")})
    @POST
    @Path("/BalanceInquiry")
    @OAuthSecurity(enabled = false)
    @Produces(MediaType.APPLICATION_JSON)
    public JSONObject BalanceInquiry(@ApiParam(value = "qid") @FormParam("qid") String qid,
                                     @ApiParam(value = "mobile") @FormParam("mobile") String mobile) {

        byte[] decodedBytes = java.util.Base64.getDecoder().decode(qid);
        String decodedQid = new String(decodedBytes);

        System.out.println("qid:" + decodedQid + "- mobile: " + mobile);

        String CivilID = decodedQid;
        String CivilMobileNumber = mobile;

        try {

            String nonce = "q4j9LP3gI9QiDEL5HqHEew==";
            String created = Instant.now().toString();
            if (created.indexOf('.') != -1) {
                created = created.substring(0, created.indexOf('.')) + "Z";
            }
            String expired = Instant.now().plus(5, ChronoUnit.MINUTES).toString();
            if (expired.indexOf('.') != -1) {
                expired = expired.substring(0, expired.indexOf('.')) + "Z";
            }
            String AuthName64 = Base64.getEncoder().encodeToString(AuthName.getBytes("utf-8"));
            String AuthPass64 = Base64.getEncoder().encodeToString(AuthPass.getBytes("utf-8"));
            String wsseUsername64 = Base64.getEncoder().encodeToString(wsseUsername.getBytes("utf-8"));
            String rpsServiceURL = configApi.getPropertyValue("rpsServiceURL");
            String WS_RPS_PATH = "RPSIntegrationService.asmx";
            String PasswordDigest = CommonUtils.generatepassword(nonce, created, wssePassword);

            String AccountInqueryrequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<soap:Envelope\n" +
                    "                xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" +
                    "                xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                    "                xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                    "                xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\"\n" +
                    "                xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"\n" +
                    "                xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
                    "                <soap:Header>\n" +
                    "                   <AuthInfo xmlns=\"http://tempuri.org/\">" +
                    "                      <AuthName>" + AuthName64 + "</AuthName>\n" +
                    "                      <AuthPass>" + AuthPass64 + "</AuthPass>\n" +
                    "                                </AuthInfo>\n" +
                    "                                <wsa:Action>http://tempuri.org/AccountInquiry</wsa:Action>\n" +
                    "                                <wsa:MessageID>urn:uuid:" + UUID.randomUUID() + "</wsa:MessageID>\n" +
                    "                                <wsa:ReplyTo>\n" +
                    "                                    <wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address>\n" +
                    "                                </wsa:ReplyTo>\n" +
                    "                                <wsa:To>" + rpsServiceURL + WS_RPS_PATH + "</wsa:To>\n" +
                    "                                <wsse:Security soap:mustUnderstand=\"1\">\n" +
                    "                                   <wsu:Timestamp wsu:Id=\"Timestamp-" + UUID.randomUUID() + "\">\n" +
                    "                                              <wsu:Created>" + created + "</wsu:Created>\n" +
                    "                                              <wsu:Expires>" + expired + "</wsu:Expires>\n" +
                    "                                  </wsu:Timestamp>\n" +
                    "                                  <wsse:UsernameToken xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"SecurityToken-" + UUID.randomUUID() + "\">\n" +
                    "                                        <wsse:Username>" + wsseUsername64 + "</wsse:Username>\n" +
                    "                                        <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">" + PasswordDigest + "</wsse:Password>\n" +
                    "                                        <wsse:Nonce>" + nonce + "</wsse:Nonce>\n" +
                    "                                        <wsu:Created>" + created + "</wsu:Created>\n" +
                    "                                  </wsse:UsernameToken>\n" +
                    "                                </wsse:Security>\n" +
                    "</soap:Header>" +
                    "<soap:Body>" +
                    "<AccountInquiry xmlns=\"http://tempuri.org/\">\n" +
                    //<Origin>WOQ-WEB</Origin><ChannelID>WPS</ChannelID>
                    "<CivilID>" + CivilID + "</CivilID>" +
                    "<CivilMobileNumber>" + CivilMobileNumber + "</CivilMobileNumber>" +
                    "<Origin>" + Origin + "</Origin>" +
                    "<ChannelID>" + ChannelID + "</ChannelID>" +
                    "</AccountInquiry>" +
                    "</soap:Body>" +
                    "</soap:Envelope>";

            System.out.println("AccountInquery " + AccountInqueryrequest);
            //JSONObject header=RequestGenerator.generateHeader();
            // header.put("SOAPAction",http://tempuri.org/UpdateBalance)
            String AccountInqueryResponse = null;

            System.out.println("AccountInquirySendRequestTime :::::::::: " + new Date());
            AccountInqueryResponse = CommonUtils.postWithHeader(rpsServiceURL + WS_RPS_PATH, AccountInqueryrequest, "http://tempuri.org/AccountInquiry");
            System.out.println("AccountInquirySendResponseTime :::::::::: " + new Date());
            XmlMapper xmlMapper = new XmlMapper();
            Envelope envelope = xmlMapper.readValue(AccountInqueryResponse, Envelope.class);
            envelope.Body.AccountInquiryResponse.AccountInquiryResult.ResponseGeneral.ResponseMessage = "" + envelope.Body.AccountInquiryResponse.AccountInquiryResult.FleetID;
            System.out.println("AccountInquiryResponse " + AccountInqueryResponse);

            ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            String json = mapper.writeValueAsString(envelope);
            System.out.println("BalanceInquiryResponse json" + json);
            JSONObject result = new JSONObject();
            JSONObject envelopjson = new JSONObject();
            envelopjson.put("Envelope", JSONObject.parse(json));
            result.put("AccountInquiry", envelopjson);

            String BalanceInqueryRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<soap:Envelope\n" +
                    "                xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" +
                    "                xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                    "                xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                    "                xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\"\n" +
                    "                xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"\n" +
                    "                xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
                    "                <soap:Header>\n" +
                    "                   <AuthInfo xmlns=\"http://tempuri.org/\">" +
                    "                      <AuthName>" + AuthName64 + "</AuthName>\n" +
                    "                      <AuthPass>" + AuthPass64 + "</AuthPass>\n" +
                    "                                </AuthInfo>\n" +
                    "                                <wsa:Action>http://tempuri.org/BalanceInquiry</wsa:Action>\n" +
                    "                                <wsa:MessageID>urn:uuid:" + UUID.randomUUID() + "</wsa:MessageID>\n" +
                    "                                <wsa:ReplyTo>\n" +
                    "                                    <wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address>\n" +
                    "                                </wsa:ReplyTo>\n" +
                    "                                <wsa:To>" + rpsServiceURL + WS_RPS_PATH + "</wsa:To>\n" +
                    "                                <wsse:Security soap:mustUnderstand=\"1\">\n" +
                    "                                   <wsu:Timestamp wsu:Id=\"Timestamp-" + UUID.randomUUID() + "\">\n" +
                    "                                              <wsu:Created>" + created + "</wsu:Created>\n" +
                    "                                              <wsu:Expires>" + expired + "</wsu:Expires>\n" +
                    "                                  </wsu:Timestamp>\n" +
                    "                                  <wsse:UsernameToken xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"SecurityToken-" + UUID.randomUUID() + "\">\n" +
                    "                                        <wsse:Username>" + wsseUsername64 + "</wsse:Username>\n" +
                    "                                        <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">" + PasswordDigest + "</wsse:Password>\n" +
                    "                                        <wsse:Nonce>" + nonce + "</wsse:Nonce>\n" +
                    "                                        <wsu:Created>" + created + "</wsu:Created>\n" +
                    "                                  </wsse:UsernameToken>\n" +
                    "                                </wsse:Security>\n" +
                    "</soap:Header>" +
                    "<soap:Body>" +
                    "<BalanceInquiry xmlns=\"http://tempuri.org/\">\n" +
                    //<Origin>WOQ-WEB</Origin><ChannelID>WPS</ChannelID>
                    "<CivilID>" + CivilID + "</CivilID>" +
                    "<CivilMobileNumber>" + CivilMobileNumber + "</CivilMobileNumber>" +
                    "<Origin>" + Origin + "</Origin>" +
                    "<ChannelID>" + ChannelID + "</ChannelID>" +
                    "</BalanceInquiry>" +
                    "</soap:Body>" +
                    "</soap:Envelope>";

            String balanceInqueryResponse = null;

            balanceInqueryResponse = CommonUtils.postWithHeader(rpsServiceURL + WS_RPS_PATH, BalanceInqueryRequest, "http://tempuri.org/BalanceInquiry");
            System.out.println("BalanceInquiryResponse :" + balanceInqueryResponse);
            XmlMapper xmlMapper1 = new XmlMapper();
            Envelope envelope1 = xmlMapper1.readValue(balanceInqueryResponse, Envelope.class);
            System.out.println("AccountInquiryResponse " + balanceInqueryResponse);
            ObjectMapper mapper1 = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            envelope1.Body.BalanceInquiryResponse.BalanceInquiryResult.ResponseGeneral.ResponseMessage = "" + envelope1.Body.BalanceInquiryResponse.BalanceInquiryResult.FleetID;
            String json1 = mapper1.writeValueAsString(envelope1);
            //System.out.println("AccountInquiryResponse json :" + json1);
            System.out.println("AccountInquiryResult json :" + json1);
            //  System.out.println("AccountInquiryResponse json" + json1);

            JSONObject envelopjson1 = new JSONObject();
            envelopjson1.put("Envelope", JSONObject.parse(json1));

            result.put("BalanceInquiry", envelopjson1);
            result.put("isSuccessful", true);
            JSONObject fullResult = new JSONObject();

            fullResult.put("responseJSON", result);

            // System.out.println(result.toString());
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
