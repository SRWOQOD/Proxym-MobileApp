package com.woqod.adapters.SoapClasses;



public class Envelope {
  public Header Header;
  public Body Body;
 /* public String soap;
  public String xsi;
  public String xsd;
  public String wsa;
  public String wsse;
  public String wsu;
  public String text;*/
}
