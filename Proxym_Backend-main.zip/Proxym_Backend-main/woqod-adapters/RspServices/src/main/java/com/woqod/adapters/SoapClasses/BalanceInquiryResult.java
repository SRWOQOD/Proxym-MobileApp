package com.woqod.adapters.SoapClasses;

public class BalanceInquiryResult {
  public int IsTopUpAllowed;
  public int FleetID;
  public String Balance;
  public String CivilName;
  public ResponseGeneral ResponseGeneral;
  public String TotalAddedBankBalance;
}
