/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.codec.digest.DigestUtils;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.logging.Logger;

@Path("/")
public class FahesPaymentResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    static Logger logger = Logger.getLogger(FahesPaymentResource.class.getName());

    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    public static final String QPAY_FAHES_SECRET_KEY = "N2YzMjVkZDVkMWQ2NTU0NDFiNGI4NTNj";

    @POST
    @Path("/qpay/success")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject successQpayPayment(@ApiParam(value = "Response.Amount", required = false) @FormParam("Response.Amount") String amount,
                                         @ApiParam(value = "Response.CurrencyCode", required = false) @FormParam("Response.CurrencyCode") String currencyCode,
                                         @ApiParam(value = "Response.PUN", required = false) @FormParam("Response.PUN") String pun,
                                         @ApiParam(value = "Response.EZConnectResponseDate", required = false) @FormParam("Response.EZConnectResponseDate") String ezConnectResponseDate,
                                         @ApiParam(value = "Response.ConfirmationID", required = false) @FormParam("Response.ConfirmationID") String confirmationId,
                                         @ApiParam(value = "Response.MerchantModuleSessionID", required = false) @FormParam("Response.MerchantModuleSessionID") String merchantModuleSessionId,
                                         @ApiParam(value = "Response.Status", required = false) @FormParam("Response.Status") String status,
                                         @ApiParam(value = "Response.StatusMessage", required = false) @FormParam("Response.StatusMessage") String statusMessage,
                                         @ApiParam(value = "Response.MerchantID", required = false) @FormParam("Response.MerchantID") String merchantId,
                                         @ApiParam(value = "Response.BankID", required = false) @FormParam("Response.BankID") String bankId,
                                         @ApiParam(value = "Response.Lang", required = false) @FormParam("Response.Lang") String lang,
                                         @ApiParam(value = "Response.AcquirerID", required = false) @FormParam("Response.AcquirerID") String acquirerId,
                                         @ApiParam(value = "Response.ItemID", required = false) @FormParam("Response.ItemID") String itemId,
                                         @ApiParam(value = "Response.CardNumber", required = false) @FormParam("Response.CardNumber") String cardNumber,
                                         @ApiParam(value = "Response.CardExpiryDate", required = false) @FormParam("Response.CardExpiryDate") String cardExpiryDate,
                                         @ApiParam(value = "Response.CardHolderName", required = false) @FormParam("Response.CardHolderName") String cardHolderName,
                                         @ApiParam(value = "Response.AgentID", required = false) @FormParam("Response.AgentID") String agentId,
                                         @ApiParam(value = "Response.SecureHash", required = false) @FormParam("Response.SecureHash") String secureHash) throws UnsupportedEncodingException {

        logger.info("/******************************** QPAY FAHES CALLBACK ******************************/");
        logger.info("Amount= " + amount + "**CurrencyCode= " + currencyCode + "**PUN= " + pun + "**EZConnectResponseDate= " + ezConnectResponseDate
                + "**ConfirmationID= " + confirmationId + "**MerchantModuleSessionID= " + merchantModuleSessionId + "**Status= " + status + "**StatusMessage= " + statusMessage + "**MerchantID= " + merchantId + "**BankID= " + bankId
                + "**Lang= " + lang + "**AcquirerID= " + acquirerId + "**ItemID= " + itemId + "**CardNumber= " + cardNumber + "**CardExpiryDate= " + cardExpiryDate + "**CardHolderName= " + cardHolderName + "**AgentID= " + agentId + "**SecureHash= " + secureHash);

        //Retrieve QPay payment sekcret key
       Operation getQpayPaymentSecretKey = ApiConfig.operations.get("/getQpayPaymentSecretKey");        JSONObject getQpayPaymentSecretKeyQueryParams = new JSONObject();
        getQpayPaymentSecretKeyQueryParams.put("name", "Fahes");

        JSONObject fahesQpayPaymentSecretKey = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, getQpayPaymentSecretKey.url,
                getQpayPaymentSecretKey.method, RequestGenerator.generateHeader(), null, getQpayPaymentSecretKeyQueryParams, null);

       JSONObject requestBody, requestResult;
        requestBody = (JSONObject) fahesQpayPaymentSecretKey.get("body");
        requestResult = (JSONObject) requestBody.get("result");

        JSONObject queryParams = new JSONObject();

        Operation operation = ApiConfig.operations.get("/qpay/success");

        // Now that we have the map, order it to generate secure hash and compare it with the received one
        StringBuilder responseOrderedString = new StringBuilder();
        String encodedStatusMessage = URLEncoder.encode(statusMessage, "utf-8");
        responseOrderedString.append(requestResult.get("secretKey").toString()).append((acquirerId == null) ? "" : acquirerId).append((amount == null) ? "" : amount).append((bankId == null) ? "" : bankId).append((cardExpiryDate == null) ? "" : cardExpiryDate).append((cardHolderName == null) ? "" : cardHolderName).append((cardNumber == null) ? "" : cardNumber)
                .append((confirmationId == null) ? "" : confirmationId).append((currencyCode == null) ? "" : currencyCode).append((ezConnectResponseDate == null) ? "" : ezConnectResponseDate).append((lang == null) ? "" : lang).append((merchantId == null) ? "" : merchantId).append((merchantModuleSessionId == null) ? "" : merchantModuleSessionId).append((pun == null) ? "" : pun).append((status == null) ? "" : status).append((lang.equals("ar")) ? encodedStatusMessage : statusMessage.replace(' ', '+'));

        logger.info("Ordered Response : " + responseOrderedString.toString());

        // Generate SecureHash with SHA256
        // Using DigestUtils from appache.commons.codes.jar Library
        String generatedSecureHash = new
                String(DigestUtils.sha256Hex(responseOrderedString.toString()).getBytes());

        if (secureHash!= null && !secureHash.equals(generatedSecureHash)) {
            // IF they are not equal then the response will not be accepted
            status = "-3";
            statusMessage = "TAMPERED";
            logger.info("Received Secure Hash does not Equal generated Secure hash");

        } else {
            if (pun != null) {
                Operation getTransaction = ApiConfig.operations.get("/qpay/getTransaction");

                JSONObject getTransactionQueryParams = new JSONObject();

                getTransactionQueryParams.put("pun", pun);

                JSONObject transactionn = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, getTransaction.url,
                        getTransaction.method, RequestGenerator.generateHeader(), null, getTransactionQueryParams, null);

                if (transactionn.get("isSuccessful").toString().equalsIgnoreCase("true")) {
                    logger.info("getTransaction ::::: ");

                    JSONObject body;
                    JSONObject obj;
                    body = (JSONObject) transactionn.get("body");
                    obj = (JSONObject) body.get("result");
                    amount = obj.get("amount").toString().replace(".0", "");
                }
            }
        }

        queryParams.put("statusCode", status);
        queryParams.put("statusMessage", lang.equals("ar") ? new String(statusMessage.getBytes(), StandardCharsets.UTF_8) : statusMessage);
        queryParams.put("pun", pun == null ? "" : pun);
        queryParams.put("transaction_id", pun == null ? "" : pun);
        queryParams.put("amount", amount);

        JSONObject responseBE = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

        logger.info("Response === {}" + responseBE);
        return responseBE;
    }

    @ApiOperation(value = "Retrieve transaction", notes = "Retrieve transaction")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Send operation OK")})
    @Path("/prtransactionlog/retrieveTransaction")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject retrieveTransaction
            (@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {
        logger.info("fahes retrieveTransaction!!!!!!!!!!!");
        Operation operation = ApiConfig.operations.get("/prtransactionlog/retrieveTransaction");

        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        logger.info("queryParams::::::::::" + queryParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    @POST
    @Path("/qpay/inquiryTransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject inquiryQpayTransaction
            (@ApiParam(value = "OriginalPUN", required = true) @FormParam("OriginalPUN") String original_pun) {

        logger.info("/******************************** BEGIN INQUIRY QPAY TRANSACTION ******************************/");
        logger.info("**OriginalPUN= " + original_pun);

        JSONObject queryParams = new JSONObject();

        Operation operation = ApiConfig.operations.get("/qpay/inquiryTransaction");

        JSONObject responseBE = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

        logger.info("Response === " + responseBE);
        return responseBE;
    }

    @ApiOperation(value = "Update PR transaction ", notes = "Update PR transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " update transaction  OK")})
    @POST
    @Path("/qpay/cancelTransactionPost")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject cancelTransactionPost(@ApiParam(value = "pun", required = true) @FormParam("pun") String pun,
                                        @ApiParam(value = "statusCode", required = false) @FormParam("statusCode") String statusCode,
                                        @ApiParam(value = "statusMessage", required = false) @FormParam("statusMessage") String statusMessage) {

        Operation operation = ApiConfig.operations.get("/qpay/cancelTransaction");

        JSONObject queryParams = new JSONObject();
        queryParams.put("pun", pun);
        queryParams.put("statusCode", statusCode);
        queryParams.put("statusMessage", statusMessage);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
    @ApiOperation(value = "Update PR transaction ", notes = "Update PR transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " update transaction  OK")})
    @PUT
    @Path("/qpay/cancelTransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject cancelTransaction(@ApiParam(value = "pun", required = true) @FormParam("pun") String pun,
                                        @ApiParam(value = "statusCode", required = false) @FormParam("statusCode") String statusCode,
                                        @ApiParam(value = "statusMessage", required = false) @FormParam("statusMessage") String statusMessage) {

        Operation operation = ApiConfig.operations.get("/qpay/cancelTransaction");

        JSONObject queryParams = new JSONObject();
        queryParams.put("pun", pun);
        queryParams.put("statusCode", statusCode);
        queryParams.put("statusMessage", statusMessage);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
}
