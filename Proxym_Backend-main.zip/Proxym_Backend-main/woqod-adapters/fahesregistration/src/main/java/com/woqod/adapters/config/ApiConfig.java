package com.woqod.adapters.config;

import java.util.HashMap;

public class ApiConfig {

    public static String defaultProtocol = "http";
    public static String defaultHost = "10.97.14.35:8080/BE";

    public static String protocol = "http";
    public static String host = "10.97.14.35:8080/BE";

    public static HashMap<String, Operation> operations = createOperations();


    public static String protocolWSDL = "http";
    public static String hostWSDL = "10.99.104.191:82";

    private static HashMap<String, Operation> createOperations() {

        HashMap<String, Operation> operations = new HashMap<String, Operation>();

        //Payment
        operations.put("/payement/getTransaction", new Operation("GET", "/payement/getTransaction"));
        operations.put("/payement/updateTransactionUUID", new Operation("PUT", "/payement/updateTransactionUUID"));


        operations.put("/RPSIntegrationService.asmx", new Operation("POST", "/RPSIntegrationService.asmx"));

        operations.put("/transactions/authReversal", new Operation("POST", "/transactions/authReversal"));

        //Fahes Qpay Payment
        operations.put("/qpay/success", new Operation("POST", "/qpay/prtransaction/success"));
        operations.put("/qpay/inquiryTransaction", new Operation("POST", "/qpay/prtransaction/inquiryTransaction"));
        operations.put("/qpay/cancelTransaction", new Operation("PUT", "/qpay/prtransaction/updatePun"));
        operations.put("/qpay/getTransaction", new Operation("GET", "/qpay/prtransaction/getTransaction"));


        //JobCard Payment
        operations.put("/jctransactionlog/success", new Operation("POST", "/jctransactionlog/success"));

        //Topup confirm transaction
        operations.put("/payement/retrieveTransaction", new Operation("POST", "/payement/retrieveTransaction"));

        //JobCard confirm transaction
        operations.put("/jctransactionlog/retrieveTransaction", new Operation("POST", "/jctransactionlog/retrieveTransaction"));

        //Fahes confirm transaction
        operations.put("/prtransactionlog/retrieveTransaction", new Operation("POST", "/prtransactionlog/retrieveTransaction"));

        //get Qpay Payment secret key
        operations.put("/getQpayPaymentSecretKey", new Operation("GET", "/fahes/getQpayPaymentSecretKey"));

        return operations;
    }
}
