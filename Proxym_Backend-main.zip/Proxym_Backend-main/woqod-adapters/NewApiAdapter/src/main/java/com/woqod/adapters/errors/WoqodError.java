package com.woqod.adapters.errors;


import java.text.MessageFormat;

/**
 * Created by bfitouri on 18/11/16.
 */
public enum WoqodError {

    HEADER_NOT_FOUND(100, "Header not found"),
    ;


    private final int code;
    private final String title;

    WoqodError(int code, String title) {
        this.code = code;
        this.title = title;
    }

    public String getTitle(Object... args) {
        return MessageFormat.format(title, args);
    }

    public String getCode() {
        return String.valueOf(this.code);
    }

}