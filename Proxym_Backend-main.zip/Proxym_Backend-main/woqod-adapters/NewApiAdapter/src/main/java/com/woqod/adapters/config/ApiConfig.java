package com.woqod.adapters.config;

import java.util.HashMap;

public class ApiConfig {

    public static String defaultProtocol = "http";
    public static String defaultHost = "10.97.111.12:8080/BE2020";
    public static String secret_key = "Pr0xym";

    public static String protocol = "";
    public static String host = "";

    public static  HashMap<String, Operation> operations = createOperations();

    private static HashMap<String, Operation> createOperations() {

        HashMap<String, Operation> operations = new HashMap<String, Operation>();

        // Generic API
        operations.put("/petrol/prices", new Operation("GET", "/petrol/prices"));
        operations.put("/image/findImg", new Operation("GET", "/image/findImg"));
        operations.put("/logout", new Operation("GET", "/logoutt"));
        operations.put("/updateWoqodeUser", new Operation("POST", "/updateWoqodeUser"));


        operations.put("/stations", new Operation("GET", "/stations"));
        operations.put("/supermarket", new Operation("GET", "/SuperMarket"));
        operations.put("/retailers", new Operation("GET", "/retailers"));
        operations.put("/fahesStations", new Operation("GET", "/fahes/station"));
        operations.put("/promotions", new Operation("GET", "/promotions"));
        operations.put("/contractors", new Operation("GET", "/Contractor"));
        operations.put("/news", new Operation("GET", "/news"));
        operations.put("/appointments", new Operation("GET", "/appointments"));
        operations.put("/events", new Operation("GET", "/events"));
        operations.put("/agenda", new Operation("GET", "/agenda"));

        operations.put("/createTransactionUUID", new Operation("POST", "/payement/createTransactionUUID"));
        operations.put("/qpay/createTransaction", new Operation("POST", "/payement/qpay/createTransaction"));
        operations.put("/updateTransactionUUID", new Operation("PUT", "/payement/updateTransactionUUID"));
        operations.put("/getMaxMin", new Operation("GET", "/amount/getMaxMin"));
        operations.put("/area", new Operation("GET", "/area"));
        operations.put("/stockPrices", new Operation("GET", "/stockPrices"));
        operations.put("/stockPrices/getLastStockPrices", new Operation("GET", "/stockPrices/getLastStockPrices"));

        // Register API
        operations.put("/checkqidvalidity", new Operation("GET", "/checkqidvalidity"));
        operations.put("/checkQidAndMobileValidity", new Operation("GET", "/checkQidAndMobileValidity"));
        operations.put("/register", new Operation("POST", "/register"));
        operations.put("/activate", new Operation("POST", "/activate"));
        operations.put("/recover", new Operation("POST", "/recover"));
        operations.put("/sendrecoverycode", new Operation("POST", "/sendrecoverycode"));
        operations.put("/checkrecoverycode", new Operation("POST", "/checkrecoverycode"));
        operations.put("/sendpincode", new Operation("PUT", "/sendpincode"));
        operations.put("/updateWoqodeUser", new Operation("POST", "/updateWoqodeUser"));


        // Login API
        operations.put("/login", new Operation("POST", "/login"));
        operations.put("/login/verifyCredentials", new Operation("POST", "/verifyCredentials"));

        // User API
        operations.put("/users", new Operation("PUT", "/users"));
        operations.put("/users/updatePhoto", new Operation("PUT", "/users/updateProfilePhoto"));
        operations.put("/users/password", new Operation("PUT", "/users/password"));
        operations.put("/users/{username}", new Operation("GET", "/users/{username}"));
        operations.put("/users/transactions", new Operation("GET", "/transactions"));
        operations.put("/users/cars", new Operation("GET", "/cars"));
        operations.put("/users/cars/deleteCar", new Operation("DELETE", "/car"));
        operations.put("/users/cars/add", new Operation("POST", "/cars"));
        operations.put("/users/getProfilePhoto", new Operation("GET", "/users/getProfilePhoto"));
        operations.put("/users/checkUser", new Operation("POST", "/users/checkUser"));
        operations.put("/users/updatePhoneNumber", new Operation("PUT", "/users/updatePhoneNumber"));
        operations.put("/users/updateEmail", new Operation("PUT", "/users/updateEmail"));
        operations.put("/users/sendMail", new Operation("POST", "/users/sendMail"));
        operations.put("/users/deleteUser", new Operation("DELETE", "/users/delete"));

        // Feedback API
        operations.put("/feedbacks/all", new Operation("GET", "/feedbacks/all"));
        operations.put("/feedbacks", new Operation("GET", "/feedbacks"));
        operations.put("/lazyFeedbackHistory", new Operation("GET", "/feedbacks/lazyFeedbackHistory"));
        operations.put("/feedbacks/new", new Operation("POST", "/feedbacks"));
        operations.put("/feedbacks/edit", new Operation("POST", "/feedbacks"));
        operations.put("/feedbacks/getFeedbackById", new Operation("GET", "/feedbacks/getFeedbackById"));
        operations.put("/ratings", new Operation("POST", "/ratings"));
        operations.put("/permissions", new Operation("GET", "/permissions"));
        operations.put("/dummy", new Operation("GET", "/permissions"));

        // Survey API
        operations.put("/surveys/all", new Operation("GET", "/surveys/all"));
        operations.put("/surveys/{id}", new Operation("GET", "/surveys/{id}"));
        operations.put("/surveys/getSurveyStatus", new Operation("GET", "/devices/getSurveyStatus"));
        operations.put("/surveys/changeStatus", new Operation("POST", "/devices/changeStatus"));
        operations.put("/surveys", new Operation("POST", "/surveys"));
        operations.put("/surveysResponses", new Operation("POST", "/surveysResponses"));

        // Fahes API
        operations.put("/fahes/listCars", new Operation("GET", "/car/getCarsByQid"));
        operations.put("/getSignatureParam", new Operation("GET", "/fahes/getSingParam"));
        operations.put("/fahes/platetypes", new Operation("GET", "/plate"));
        operations.put("/fahes/checkCar", new Operation("GET", "/car/checkCar"));
        operations.put("/fahes/isOwner", new Operation("GET", "/car/isOwner"));
        operations.put("/fahes/isOwnerAddCar", new Operation("GET", "/car/isOwnerAddCar"));
        operations.put("/getQpaySignatureParam", new Operation("GET", "/fahes/getQpaySignParam"));

//    operations.put("/fahes/prtransactionlog/creditcard/save", new Operation("POST","/prtransactionlog/creditcard/save"));
//    operations.put("/fahes/prtransactionlog/anonym/creditcard/save", new Operation("POST","/prtransactionlog/anonym/creditcard/save"));
        operations.put("/fahes/sendPin", new Operation("POST", "/pincode/send"));
        operations.put("/fahes/addCar", new Operation("POST", "/car/register"));
        operations.put("/fahes/updateCar", new Operation("POST", "/car/updateCar"));
        operations.put("/fahes/updateStatusCar", new Operation("PUT", "/car/changeStatus"));
        operations.put("/fahes/inspection/historyInspectionsByPlate", new Operation("GET", "/inspection/listDetailsByPlate"));
        operations.put("/fahes/inspection/detailInspection", new Operation("GET", "/inspection/details"));
        operations.put("/fahes/inspection/fee", new Operation("GET", "/inspection/fee"));
        operations.put("/fahes/preRegistration/sendMail", new Operation("POST", "/preregistration/sendMail"));
        operations.put("/fahes/preRegistration/findByQid", new Operation("GET", "/preregistration/findByQid"));
        operations.put("/fahes/preRegistration/anonym/sendMail", new Operation("POST", "/preregistration/anonym/sendMail"));
        operations.put("/fahes/prtransactionlog/updateTransactionUUID", new Operation("PUT", "/prtransactionlog/updateTransactionUUID"));
//    operations.put("/fahes/prtransactionlog/woqode/save", new Operation("POST", "/prtransactionlog/woqode/save"));
        operations.put("/fahes/prtransactionlog/free/save", new Operation("POST"
                , "/prtransactionlog/free/save"));
        operations.put("/fahes/discount/byType", new Operation("GET", "/discount/byTypeAndAmount"));
        operations.put("/fahes/preregistration/generatePDF", new Operation("GET", "/preregistration/generatePDF"));
        operations.put("/fahes/prtransactionlog/creditcard/save", new Operation("POST", "/prtransactionlog/creditcard/save"));
        //    operations.put("/fahes/prtransactionlog/anonym/free/save", new Operation("POST", "/prtransactionlog/anonym/free/save"));

        //  QPAY TRANSACTIONS API
        operations.put("/fahes/qpaytransaction/debitcard/save", new Operation("POST", "/qpay/prtransaction/debitcard/save"));
        operations.put("/fahes/qpaytransaction/free/save", new Operation("POST", "/qpay/prtransaction/free/save"));

        //  JobCard API
        operations.put("/jobcard/all", new Operation("GET", "/jobcard/all"));
        operations.put("/jobcard/allByDate", new Operation("GET", "/jobcard/listByDate"));
        operations.put("/jobcard/jctransactionlog/creditcard/save", new Operation("POST", "/jctransactionlog/creditcard/save"));
        operations.put("/jobcard/jctransactionlog/updateTransactionUUID", new Operation("PUT", "/jctransactionlog/updateTransactionUUID"));
        operations.put("/jobcard/jctransactionlog/woqode/save", new Operation("POST", "/jctransactionlog/woqode/save"));
        operations.put("/jobcard/voucher/getByReference", new Operation("GET", "/voucher/getByReference"));
        operations.put("/jobcard/jctransactionlog/findByJobCard", new Operation("GET", "/jctransactionlog/findByJobCard"));
        operations.put("/jobcard/generatePDF", new Operation("GET", "/jobcard/generatePDF"));
        operations.put("/jobcard/sendMail", new Operation("POST", "/jobcard/sendMail"));
        operations.put("/jobcard/image", new Operation("GET", "/jobcard/image"));

        //Tag API
        operations.put("/tag/register", new Operation("POST", "/tag/register"));
        operations.put("/tagTransaction/register", new Operation("POST", "/tagTransaction/register"));
        operations.put("/tagTransaction/update", new Operation("POST", "/tagTransaction/update"));

        //Bio Api
        operations.put("/bio", new Operation("POST", "/bio"));
        operations.put("/bio/validate", new Operation("POST", "/bio/validate"));
        operations.put("/bio/custompwd", new Operation("GET", "/bio/custompwd"));
        operations.put("/bio/getUser", new Operation("POST", "/bio/getUser"));
        operations.put("/bio/checkFingerPrint", new Operation("POST", "/bio/checkFingerPrint"));
        operations.put("/bio/updateBioPin", new Operation("PUT", "/bio"));
        operations.put("/bio/updateStatus", new Operation("PUT", "/bio/status"));
        operations.put("/bio/resetBioPin", new Operation("PUT", "/bio/resetBioPin"));

        //Pin Code
        operations.put("/pincode/validatePinCode", new Operation("POST", "/pincode/validatePinCode"));
        operations.put("/pincode/send", new Operation("POST", "/pincode/send"));
        operations.put("/pincode/login/validatePinCode", new Operation("POST", "/pincode/login/validatePinCode"));
        operations.put("/pincode/login/send", new Operation("POST", "/pincode/login/send"));
        operations.put("/pincode/sendPinCodeToUpdateUserEMail", new Operation("POST", "/pincode/sendPinCodeToUpdateUserEMail"));
        operations.put("/pincode/sendPinCodeToUpdateUserPhone", new Operation("POST", "/pincode/sendPinCodeToUpdateUserPhone"));

        // Car Api
        operations.put("/car/updateFuelStatus", new Operation("PUT", "/car/update"));
        operations.put("/car/updateCarFuelLimit", new Operation("PUT", "/car/updateCarFuelLimit"));

        // Tenders Api
        operations.put("/tenders", new Operation("GET", "/tenders"));
        operations.put("/tenders/tenders", new Operation("GET", "/tenders/tenders"));


        // notif api
        operations.put("/notification/listByDevice", new Operation("GET", "/notification/listByDevice"));
        operations.put("/notification/listByUsername", new Operation("GET", "/notification/listByUsername"));
        operations.put("/notification/updateAll", new Operation("PUT", "/notification/updateAll"));
        operations.put("/notification/anonymous", new Operation("GET", "/notification/anonymous"));
        operations.put("/notification/updateStatus", new Operation("POST", "/notification/updateStatus"));

        // Home api
        operations.put("/home/adsbanner", new Operation("GET", "/adsbanner/activebanner"));
        operations.put("/hasNotif", new Operation("GET", "/adsbanner/hasNotif"));
        operations.put("/home/topbanner", new Operation("GET", "/topbanner/active"));
        operations.put("/home/businessbanner", new Operation("GET", "/businessbanner/activebanner"));
        operations.put("/news/active", new Operation("GET", "/news/active"));
        operations.put("/news/views/{id}", new Operation("GET", "/news/views/{id}"));
        operations.put("/getTextByType", new Operation("GET", "/text/getTextByType"));

        //Logging api
        operations.put("/saveLog", new Operation("POST", "/auditBackEnd/save"));

        //Reservation api
        operations.put("reservation/getPlateTypeWithShape", new Operation("GET", "/reservation/getPlateTypeWithShape"));
        operations.put("reservation/getAvailableStations", new Operation("GET", "/reservation/getAvailableStations"));
        operations.put("reservation/getPreReservationReference", new Operation("POST", "/reservation/getPreReservationReference"));
        operations.put("reservation/otpValidation", new Operation("POST", "/reservation/otpValidation"));
        operations.put("reservation/resendOtp", new Operation("PUT", "/reservation/resendOtp"));
        operations.put("reservation/getSlots",new Operation("GET","/reservation/getSlots"));
        operations.put("reservation/getDetails",new Operation("POST","/reservation/getDetails"));
        operations.put("reservation/reservation",new Operation("POST","/reservation/reservation"));
        operations.put("reservation/cancellation", new Operation("POST", "/reservation/cancellation"));
        operations.put("reservation/availableByCustomer", new Operation("GET", "/reservation/availableByCustomer"));
        operations.put("reservation/getAppointmentDates", new Operation("GET", "/reservation/getAppointmentDates"));
        operations.put("reservation/reservationId", new Operation("GET", "/reservation/reservationId"));
        operations.put("reservation/getDetailsByCustomer", new Operation("POST", "/reservation/getDetailsByCustomer"));
        operations.put("reservation/rescheduling", new Operation("GET", "/reservation/rescheduling"));
        operations.put("reservation/canPayOnline",new Operation("POST","/reservation/canPayOnline"));
        operations.put("reservation/vehiculeDetails",new Operation("POST","/reservation/vehiculeDetails"));
        operations.put("reservation/vehiculeRegistrationValidity",new Operation("POST","/reservation/vehiculeRegistrationValidity"));

        //AppTips api
        operations.put("/apptips/active", new Operation("GET", "/apptips"));

        //AppRedirection api
        operations.put("/appRedirection", new Operation("GET", "/appRedirection"));

        //Reservation Config api
        operations.put("reservation/isReservationHidden", new Operation("GET", "/reservation-config"));

        //TransactionLog api
        operations.put("/transactionLog/receipt", new Operation("GET", "/transactionLog/receipt"));
        operations.put("/transactionLog/sendMail", new Operation("POST", "/transactionLog/sendMail"));
        operations.put("/devices/register", new Operation("POST", "/users/registerDevice"));

        // Debit Card Payment config
        operations.put("/isDebitCardPaymentHidden", new Operation("GET", "/debit-card-payment-config"));

        return operations;
    }
}
