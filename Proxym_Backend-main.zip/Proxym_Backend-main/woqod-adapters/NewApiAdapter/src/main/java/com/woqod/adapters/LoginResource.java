/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.Base64;
import java.util.logging.Logger;

@Api(value = "Login API")
@Path("/login")
public class LoginResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(LoginResource.class.getName());

    @Context
    HttpServletRequest servletRequest;

    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @ApiOperation(value = "Login", notes = "Login")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Login")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject activate(@ApiParam(value = "username", required = true) @FormParam("username") String userName,
                               @ApiParam(value = "password", required = true) @FormParam("password") String password) {


        Operation operation = ApiConfig.operations.get("/login");
        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
        String encodedUsername = Base64.getEncoder().encodeToString(userName.toLowerCase().getBytes());
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", encodedUsername);
        bodyParams.put("password", encodedPassword);
        bodyParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/verifyCredentials")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject verifyCredentials(
            @ApiParam(value = "username", required = true) @FormParam("username") String username,
            @ApiParam(value = "type", required = true) @FormParam("type") String type,
            @ApiParam(value = "password", required = true) @FormParam("password") String password) {

        Operation operation = ApiConfig.operations.get("/login/verifyCredentials");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("type", type);
        queryParams.put("password", password);
        queryParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getCustomerInfo")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getCustomerInfo(
            @ApiParam(value = "username", required = true) @FormParam("username") String username,
            @ApiParam(value = "type", required = true) @FormParam("type") String type,
            @ApiParam(value = "password", required = true) @FormParam("password") String password,
        @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
        @ApiParam(value = "deviceType", required = true) @FormParam("deviceType") String deviceType
    ) {

        Operation operation = ApiConfig.operations.get("/login");

        JSONObject queryParams = new JSONObject();
        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
        String encodedUsername = Base64.getEncoder().encodeToString(username.getBytes());
        queryParams.put("username", encodedUsername);
        queryParams.put("type", type);
        queryParams.put("password", encodedPassword);
        queryParams.put("deviceId", deviceId);
        queryParams.put("deviceType", deviceType);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);

    }
}
