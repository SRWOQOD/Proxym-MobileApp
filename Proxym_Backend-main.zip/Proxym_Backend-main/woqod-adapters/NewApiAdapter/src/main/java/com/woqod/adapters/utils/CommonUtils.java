package com.woqod.adapters.utils;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.woqod.adapters.commands.ResponseCommand;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.enums.Errors;
import com.woqod.adapters.enums.ResponseTypes;
import com.woqod.adapters.exceptions.ApplicationException;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContexts;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLContext;
import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.DigestException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by Kais Elouragini on 26/04/2016.
 */
public class CommonUtils {

    // maybe DEV/////
    public static final String HMAC_SHA256 = "HmacSHA256";
    public static final String SECRET_KEY_TOPUP2 = "e631050519f34f8096746b963ca8ab78c8a7d660fd954b91aaebebd186a3bf6e6067dd4f65a04a2b8909d3681654d49daf9eda21fc534802bfb210bd1043d78eccce3695593c47d19aa49b018fd0410a3f7ab6a8ad1e4421ace6cd6489670ece9b8e826db11d4daeb75213d9412f7cfc3f18e8ee3d0c4ae9b0777424b4216369";
    public static final String SECRET_KEY_TOPUP = "e631050519f34f8096746b963ca8ab78c8a7d660fd954b91aaebebd186a3bf6e6067dd4f65a04a2b8909d3681654d49daf9eda21fc534802bfb210bd1043d78eccce3695593c47d19aa49b018fd0410a3f7ab6a8ad1e4421ace6cd6489670ece9b8e826db11d4daeb75213d9412f7cfc3f18e8ee3d0c4ae9b0777424b4216369";
    public static final String SECRET_KEY_FAHES = "3e620097ddfd410f823cdb27e2236e94c63e9585d0044db594e76b8f327bed69ad816c5ab1a349d79841d3d58a47cea582e063c7caa949a5abc8812011afdbc9b81df949d5c84d159a9b0139e6c46fe5f1828d44b8fb4c908128bad38f2a1301a6e5366eddae4f10852172509ad3b7f09dcda8c16cfc4af38d5525e630fb6eb1";
    public static final String SECRET_KEY_JOBCARD = "b3faae4fe0ac46058c89cd907dddfbe1b6d913527b3342ceb96248b4f20807663528fbc524de46cd90cbcd0b65a921ec1fda17db0b8e4dc89d1c37800ff41e80b1411beb092840e6b184b2aa2282629cb14dfe2d95b24ce3b626a68070d82df92b22be9a2148421bbb4b55939cf705d8732f974dbc6b419aaa1b384abf4ac91c";
    static String GET = "GET";

    //    public static JSONObject callWS(String protocol, String host, String path, String method, JSONObject headers,AuditResource auditResource) {
//        return callWS(protocol, host, path, method, headers, null, null, null,CommonUtils.generateAuditResource(servletRequest));
//    }
    static String POST = "POST";
    static String PUT = "PUT";
    static String DELETE = "DELETE";

    public static void buildHeaders(HttpRequestBase httpRequest, JSONObject headers) {
        // Adding Request Headers
        try {
            if (null != headers) {
                for (Object key : headers.keySet()) {
                    httpRequest.setHeader(String.valueOf(key), String.valueOf(headers.get(key)));
                    System.out.println("key: "+String.valueOf(key) +" value: "+String.valueOf(headers.get(key)));
                }
            }
        } catch (Exception e) {
            //System.out.println("Parsing Headers Exception : " + e.getMessage());
        }
    }

    public static String buildUri(String protocol, String host, String path, String method, JSONObject headers, JSONObject queryParams) {
        try {

            URIBuilder uriBuilder = new URIBuilder()
                    .setScheme(protocol)
                    .setHost(host)
                    .setPath(path);


            // Adding Query Params
            try {
                if (null != queryParams) {
                    for (Object key : queryParams.keySet()) {
                        //System.out.println("Key : " + key + " Query params : " + queryParams);
                        uriBuilder.setParameter(String.valueOf(key), String.valueOf(queryParams.get(key)));
                    }
                }
            } catch (Exception e) {
                //System.out.println("Parsing Headers Exception : " + e.getMessage());
            }

            String encodedURL = uriBuilder.build().toString();
            System.out.println(encodedURL);
            if (null != queryParams) {
                System.out.println(queryParams);
                return encodedURL;
            }else{
                return URIUtil.encodeQuery(encodedURL, "UTF-8");
            }


        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Common WS caller
     *
     * @param protocol
     * @param host
     * @param path
     * @param method
     * @param headers
     * @param urlParams
     * @param queryParams
     * @return
     */
    public static JSONObject callWS(String protocol, String host, String path, String method, JSONObject headers, JSONObject urlParams, JSONObject queryParams, JSONObject bodyParams) {
        try {

            String url = buildUri(protocol, host, RequestGenerator.prepareUrlParams(path, urlParams), method, headers, queryParams);
            if (null != url) {

                HttpRequestBase httpRequestBase;
                if (GET.equals(method)) {
                    httpRequestBase = new HttpGet(url);
                } else if (POST.equals(method)) {

                    HttpPost httpPost = new HttpPost(url);
                    if (null != bodyParams) {
                        StringEntity postingString = new StringEntity(bodyParams.serialize());
                        httpPost.setEntity(postingString);
                    }
                    httpRequestBase = httpPost;

                } else if (PUT.equals(method)) {
                    HttpPut httpPut = new HttpPut(url);
                    if (null != bodyParams) {
                        StringEntity postingString = new StringEntity(bodyParams.serialize());
                        httpPut.setEntity(postingString);
                    }
                    httpRequestBase = httpPut;
                } else if (DELETE.equals(method)) {
                    httpRequestBase = new HttpDelete(url);
                } else {
                    method = GET;
                    httpRequestBase = new HttpGet(url);
                    //System.out.println("Unsupported Method, using GET as default !");
                }

                buildHeaders(httpRequestBase, headers);
                HttpClient client = HttpClientBuilder.create().setSSLContext(SSLContexts.custom().setProtocol("TLSv1.2").build()).build();
                HttpResponse response = null;
                try {
                    response = client.execute(httpRequestBase);

                    StringBuilder sb = new StringBuilder();
                    try {
                        BufferedReader reader =
                                new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                        String line = null;

                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.out.println("IOException *************");
                    }
                    JSONObject jsonResponse = JSONObject.parse(sb.toString());
                    if (null != jsonResponse.get("header") && String.valueOf(JSONObject.parse(String.valueOf(jsonResponse.get("header"))).get("statusCode")).equals("000")) {
                      //  System.out.println("jsonResponse ::::::::::: ");
                    //    System.out.println(jsonResponse);
//                        return CommonUtils.replySuccess(jsonResponse.toString());

                        return CommonUtils.replyToJson(jsonResponse);
                    } else {
                        return CommonUtils.errorHandler(jsonResponse);
                    }
                } catch (Exception ee) {
                    System.out.println("An error occurred when trying to execute url :" + url+" *** "+ee.getMessage());
                    ee.printStackTrace();
                    return CommonUtils.errorHandler(ee);
                }
            } else {
                return CommonUtils.errorHandler("An error occurred when trying build URI");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception *************" + e.getMessage());
            return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
        }
    }

    /**
     * Hash a string SHA-1 + SALT
     *
     * @param passwordToHash
     * @param salt
     * @return
     */
    public static String sha1WithSalt(String passwordToHash, String salt) {
        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            passwordToHash += salt;
            byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatedPassword;
    }

    /**
     * Hash a string SHA-256 + SALT
     *
     * @param passwordToHash
     * @param salt
     * @return
     */
    public static String sha256WithSalt(String passwordToHash, String salt) {
        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            passwordToHash += salt;
            byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatedPassword;
    }

    /**
     * Get StackTrace as a String from Exception
     *
     * @param e
     * @return
     */
    public static String getStackTrace(Exception e) {
        try {

            // PRINT TO LOG - FOR DEVELOPEMENT
            e.printStackTrace();

            // THE FOLLOWING CODE IS FOR DEVELOMEPENT
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);

            return sw.toString();

            // TO BE ENABLED FOR PRODUCTION
            //return e.getMessage();
        } catch (Exception ex) {
            // WL Logger
            ex.printStackTrace();
            return "";
        }
    }

    /**
     * Get Current DateTime as String
     *
     * @return String
     */
    public static String getCurrentDateTimeStamp() {

        return new SimpleDateFormat("YYYYMMddHHmmssSSS").format(new Date());
    }

    public static JSONObject getCurrentDateFormats() {
        JSONObject result = new JSONObject();
        JSONObject finalResult = new JSONObject();
        Date  currentDate= new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String UTCDate= sdf.format(currentDate);
        result.put("CurrentDateTimeStamp",""+ java.lang.System.nanoTime());
        result.put("UTCDateTime", UTCDate);
        result.put("DebitCardDateFormat", new SimpleDateFormat("ddMMyyyyHHmmss").format(currentDate));
        finalResult.put("result", result);
        return finalResult;
    }
    /**
     * Global Error Handler
     *
     * @param message
     * @return JSONObject
     */
    public static JSONObject errorHandler(String message) {
        JSONObject invocationResult = new JSONObject();
        try {
            invocationResult.put("errors", message);
            invocationResult.put("isSuccessful", false);
            //System.out.println("An error has occurred and this the response : ");
            //System.out.println(invocationResult.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return invocationResult;
    }

    public static JSONObject errorHandler(Object response) {
        try {
            JSONObject invocationResult = CommonUtils.objectToJson(response);
            //System.out.println("An error has occurred and this the response : ");
            //System.out.println(invocationResult.toString());
            invocationResult.put("isSuccessful", false);
            return invocationResult;
        } catch (Exception e) {
            return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
        }
    }
    //public static final String
    // SECRET_KEY = "794ee4d32c2e4860a5aada7e7d000556d9322d6abca346409556b310045612ae3941c4b62a8a47ec8691ba80ec677ecd40bd61d214054335811b20db2442a1c80f0bd8fa8a644c6b82251ebbf97f887b1f07a0cf34e144c2901202bb92ecc9f0d6e0deff9cfa4abfb0fc4ecf9bb3f35668d84011f6474772831a9a9c43697c63";
    //UAT////

    /**
     * Convert Object to JSON
     *
     * @param source
     * @return com.ibm.json.java.JSONObject
     */
    @SuppressWarnings("unchecked")
    public static JSONObject objectToJson(Object source) {
        JSONObject result = new JSONObject();
        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            String json = ow.writeValueAsString(source);
            result = JSONObject.parse(json);
            return result;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }


    }

    /**
     * Rely To Json
     *
     * @param response
     * @return JSONObject
     */
    public static JSONObject replyToJson(Object response) {

        try {
            JSONObject invocationResult = CommonUtils.objectToJson(response);
            invocationResult.put("isSuccessful", true);
            return invocationResult;
        } catch (Exception e) {
            return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
        }
    }

    /**
     * Convert String as "YYYY-MM-DD" to XMLGregorianCalendar
     *
     * @param s
     * @return XMLGregorianCalendar
     */
    public static XMLGregorianCalendar stringToXMLGregorianCalendar(String s) {
        try {
            Date dob = null;
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            dob = df.parse(s + " 00:00:00");
            GregorianCalendar cal = new GregorianCalendar();

            cal.setTime(dob);
            XMLGregorianCalendar xmlDate2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), dob.getHours(), dob.getMinutes(), dob.getSeconds(), DatatypeConstants.FIELD_UNDEFINED, cal.getTimeZone().LONG).normalize();
            //XMLGregorianCalendar xmlDate3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH),dob.getHours(),dob.getMinutes(),dob.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
            return xmlDate2;
        } catch (Exception e) {
            CommonUtils.getStackTrace(e);
            return null;
        }
    }

    /**
     * Get StackTrace as a String from Exception
     *
     * @param e
     * @return
     */
    public static String getStackTrace(Error e) {
        try {

            // PRINT TO LOG - FOR DEVELOPEMENT
            e.printStackTrace();

            // THE FOLLOWING CODE IS FOR DEVELOMEPENT
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);

            return sw.toString();

            // TO BE ENABLED FOR PRODUCTION
            //return e.getMessage();
        } catch (Exception ex) {
            // WL Logger
            ex.printStackTrace();
            return "";
        }
    }

    public static String sign(String params, String SECRET_KEY) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {

//        secretKeyTypes secretKeyType = secretKeyTypes.valueOf(sourceType);
//        String SECRET_KEY = SECRET_KEY_TOPUP;
//        switch (secretKeyType) {
//            case TOPUP:
//                SECRET_KEY = SECRET_KEY_TOPUP;
//                break;
//            case FAHES:
//                SECRET_KEY = SECRET_KEY_FAHES;
//                break;
//            case JOBCARD:
//                SECRET_KEY = SECRET_KEY_JOBCARD;
//                break;
//            case TOPUP2:
//                SECRET_KEY = SECRET_KEY_TOPUP2;
//                break;
//        }
        System.out.println(params);
        System.out.println(SECRET_KEY);
        return sign2(params, SECRET_KEY);
    }

    public static String signn(String params, String sourceType) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {

        secretKeyTypes secretKeyType = secretKeyTypes.valueOf(sourceType);
        String SECRET_KEY = SECRET_KEY_TOPUP;
        switch (secretKeyType) {
            case TOPUP:
                SECRET_KEY = SECRET_KEY_TOPUP;
                break;
            case FAHES:
                SECRET_KEY = SECRET_KEY_FAHES;
                break;
            case JOBCARD:
                SECRET_KEY = SECRET_KEY_JOBCARD;
                break;
            case TOPUP2:
                SECRET_KEY = SECRET_KEY_TOPUP2;
                break;
        }
        System.out.println(params);
        System.out.println(SECRET_KEY);
        return sign2(params, SECRET_KEY);
    }

    //PROD////
//    public static final String SECRET_KEY_TOPUP2 = "1bb851c5cb8640619f4046843b963d8f0f829f4a7b154c60a288dbb0ddda9d87841269ca0afe4b329744b7f7829dd9984c915aa4289841e9b399f4c7053f9a25785529db334f46fdb3a476723238701fe70439dc0d7b453fb1b1b2ed6027c3b4e02e5883a11f40698395759822826e048e77869215f74c85b3b5e14ee57c2ea2";
//    public static final String SECRET_KEY_TOPUP = "8f8474ac98b948a493d1a9ef79b36b733cd1ffb261eb484ca182658df62779d23eaa7db35f4b409ebddb0dece677b7802b5820df194444eead68706ab8fc23a6c26ff694b94247df91ab364d3248f015a91a4c9aaee8420e9edf79eeec2a82395bd414894ada4f239fc61bf62c1627efc484f888d77740a59ae921a8919d2088";
//    public static final String SECRET_KEY_FAHES = "dce4e2c025b74a32b2305a2e65d7d93666e0d5be2fa346eebf176f5805c5141a923b32c37b5e4a898ba2cf64b6147365b1a4f1edb6c1404492479c9d36d3984931de821608c044059b91c2e48a48604ca4a10279105d4e8fa442fe2f7b4ed87693eb5c3512d54d67a26f90a34cef844049f4a5d55ea2476e96b0cf9828057b22";
//    public static final String SECRET_KEY_JOBCARD = "8f8474ac98b948a493d1a9ef79b36b733cd1ffb261eb484ca182658df62779d23eaa7db35f4b409ebddb0dece677b7802b5820df194444eead68706ab8fc23a6c26ff694b94247df91ab364d3248f015a91a4c9aaee8420e9edf79eeec2a82395bd414894ada4f239fc61bf62c1627efc484f888d77740a59ae921a8919d2088";

    public static String sign2(String data, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), HMAC_SHA256);
        Mac mac = Mac.getInstance(HMAC_SHA256);
        mac.init(secretKeySpec);
        byte[] rawHmac = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return DatatypeConverter.printBase64Binary(rawHmac).replace("\n", "");
    }

    public static String buildDataToSign(HashMap params) {
        String[] signedFieldNames = String.valueOf(params.get("signed_field_names")).split(",");
        ArrayList<String> dataToSign = new ArrayList<String>();
        for (String signedFieldName : signedFieldNames) {
            dataToSign.add(signedFieldName + "=" + String.valueOf(params.get(signedFieldName)));
        }
        return commaSeparate(dataToSign);
    }

    public static String commaSeparate(ArrayList<String> dataToSign) {
        StringBuilder csv = new StringBuilder();
        for (Iterator<String> it = dataToSign.iterator(); it.hasNext(); ) {
            csv.append(it.next());
            if (it.hasNext()) {
                csv.append(",");
            }
        }
        return csv.toString();
    }

    public static String getUTCDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }


    public static String decrypte(String input) {

        try {
            byte[] cipherData = Base64.getDecoder().decode(input);
            byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);

            MessageDigest md5 = MessageDigest.getInstance("MD5");
            final byte[][] keyAndIV = GenerateKeyAndIV(32, 16, 1, saltData, ApiConfig.secret_key.getBytes(StandardCharsets.UTF_8), md5);
            SecretKeySpec key = new SecretKeySpec(keyAndIV[0], "AES");
            IvParameterSpec iv = new IvParameterSpec(keyAndIV[1]);

            byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
            Cipher aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
            aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
            byte[] decryptedData = aesCBC.doFinal(encrypted);
            String decryptedText = new String(decryptedData, StandardCharsets.UTF_8);

            return decryptedText;
        } catch (Exception e) {
            e.printStackTrace();
            return "DECRYPT ERROR !!!!!";
        }

    }

    private static byte[][] GenerateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password, MessageDigest md) {

        int digestLength = md.getDigestLength();
        int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
        byte[] generatedData = new byte[requiredLength];
        int generatedLength = 0;

        try {
            md.reset();

            // Repeat process until sufficient data has been generated
            while (generatedLength < keyLength + ivLength) {

                // Digest data (last digest if available, password data, salt if available)
                if (generatedLength > 0)
                    md.update(generatedData, generatedLength - digestLength, digestLength);
                md.update(password);
                if (salt != null)
                    md.update(salt, 0, 8);
                md.digest(generatedData, generatedLength, digestLength);

                // additional rounds
                for (int i = 1; i < iterations; i++) {
                    md.update(generatedData, generatedLength, digestLength);
                    md.digest(generatedData, generatedLength, digestLength);
                }

                generatedLength += digestLength;
            }

            // Copy key and IV into separate byte arrays
            byte[][] result = new byte[2][];
            result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
            if (ivLength > 0)
                result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);

            return result;

        } catch (DigestException e) {
            throw new RuntimeException(e);

        } finally {
            // Clean out temporary data
            Arrays.fill(generatedData, (byte) 0);
        }

    }

    public static JSONObject replySuccess(String responseString) {

        ObjectMapper mapper = new ObjectMapper();
        JSONObject invocationResult = new JSONObject();

        boolean isSuccessful = false;

        try {
            ResponseCommand responseCommand = mapper.readValue(responseString, ResponseCommand.class);

//            if(statusCode.equalsIgnoreCase("000")){
            if (responseCommand.getBody() != null) {

                isSuccessful = responseCommand.getHeader().getStatusCode().equalsIgnoreCase("000");
                Object result = responseCommand.getBody().getResult();
                String responseType = responseCommand.getBody().getType();

                if (responseType.equalsIgnoreCase(ResponseTypes.LIST_RESPONSE.toString())) {
                    invocationResult.put("result", objectToJsonArray(result));
                } else if (result == null || result instanceof String || result instanceof Boolean || result instanceof Integer ||
                        result instanceof Float || result instanceof Double || result instanceof Short || result instanceof Long ||
                        result instanceof Character || result instanceof Byte || result instanceof BigInteger || result instanceof Date) {
                    invocationResult.put("result", responseCommand.getBody().getResult());
                } else if (responseType.equalsIgnoreCase(ResponseTypes.OBJECT_RESPONSE.toString())) {
                    invocationResult.put("result", objectToJson(responseCommand.getBody().getResult()));
                } else {
                    invocationResult.put("result", responseCommand.getBody().getResult());
                }
            }


            invocationResult.put("isSuccessfull", isSuccessful);
            invocationResult.put("statusCode", responseCommand.getHeader().getStatusCode());
            invocationResult.put("messageAr", responseCommand.getHeader().getTitleAR());
            invocationResult.put("messageEn", responseCommand.getHeader().getTitleEN());
            invocationResult.put("providerCode", responseCommand.getHeader().getProviderCode());
            invocationResult.put("messageType", responseCommand.getHeader().getMessageType());
        } catch (JsonMappingException e) {
            e.printStackTrace();
            ApplicationException ex = new ApplicationException(Errors.JSON_MAPPING_EXCEPTION);
            invocationResult = replyFailure(ex);
        } catch (Exception e) {
            e.printStackTrace();
            ApplicationException ex = new ApplicationException(Errors.PARSE_EXCEPTION);
            invocationResult = replyFailure(ex);
        }
        return invocationResult;
    }

    public static JSONObject replyFailure(ApplicationException ex) {

        JSONObject invocationResult = new JSONObject();
        invocationResult.put("isSuccessfull", false);
        invocationResult.put("statusCode", ex.getCode());
        invocationResult.put("messageAr", ex.getDescriptionAR());
        invocationResult.put("messageEn", ex.getDescriptionEN());
        invocationResult.put("providerCode", ex.getProviderCode());
        invocationResult.put("messageType", ex.getMessageType());

        return invocationResult;
    }

    public static JSONArray objectToJsonArray(Object source) throws ApplicationException {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String json = mapper.writeValueAsString(source);
            return com.ibm.json.java.JSONArray.parse(json);
        } catch (Exception e) {
            e.printStackTrace();
            ApplicationException ex = new ApplicationException(Errors.PARSE_EXCEPTION);
            throw ex;
        }
    }

    private enum secretKeyTypes {
        TOPUP, TOPUP2, FAHES, JOBCARD;
    }

}
