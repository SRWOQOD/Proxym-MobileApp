/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.ConvertUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Surveys API")
@Path("/surveys")
public class SurveyRessource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(SurveyRessource.class.getName());

    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @ApiOperation(value = "Get survey details by Id", notes = "Get survey details by Id")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Survey details OK")})
    @POST
    @Path("/surveys/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject getSurveyByID(@ApiParam(value = "id") @FormParam("id") String id) {

        Operation operation = ApiConfig.operations.get("/surveys/{id}");

        JSONObject urlParams = new JSONObject();
        urlParams.put("id", id);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), urlParams, null, null);
    }

    @ApiOperation(value = "Get all surveys ", notes = "Get all surveys")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "All Surveys OK")})
    @GET
    @Path("/surveys/all")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject allSurveys() {
        Operation operation = ApiConfig.operations.get("/surveys/all");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }


    @ApiOperation(value = "Respond to survey", notes = "Respond to survey")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Add operation OK")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/surveysResponses")
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject respondToSurvey(
            @ApiParam(value = "surveyId", required = true) @FormParam("surveyId") Long surveyId,
            @ApiParam(value = "questionResponseResources", required = false) @FormParam("questionResponseResources") String questionResponseResources,
            @ApiParam(value = "deviceId", required = false) @FormParam("deviceId") String deviceId) {


        Operation operation = ApiConfig.operations.get("/surveysResponses");
        JSONArray jsonArray = ConvertUtils.stringToJsonArray(questionResponseResources);

        System.out.println(jsonArray);
//    JSONObject questionResponseResources = new JSONObject();
//    questionResponseResources.put("questionId",questionId);
//    questionResponseResources.put("responses",responses);

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("surveyId", surveyId);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("questionResponseResources", jsonArray);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/getSurveyStatus")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject getSurveyStatus(@ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {
        Operation operation = ApiConfig.operations.get("/surveys/getSurveyStatus");
        JSONObject urlParams = new JSONObject();
        urlParams.put("deviceId", deviceId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, urlParams, null);
    }

    @POST
    @Path("/changeStatus")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject changeStatus(@ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {
        Operation operation = ApiConfig.operations.get("/surveys/changeStatus");
        JSONObject urlParams = new JSONObject();
        urlParams.put("deviceId", deviceId);
        System.out.println("operation" + operation.url + operation.method);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, urlParams, null);
    }
}
