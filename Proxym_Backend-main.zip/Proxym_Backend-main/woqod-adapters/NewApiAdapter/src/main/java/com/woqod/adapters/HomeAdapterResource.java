package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(value = "Home API")
@Path("/home")
public class HomeAdapterResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("adsbanner")
    @OAuthSecurity(enabled = false)
    public JSONObject adsbanner() {

        Operation operation = ApiConfig.operations.get("/home/adsbanner");


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("topbanner")
    @OAuthSecurity(enabled = false)
    public JSONObject topbanner() {

        Operation operation = ApiConfig.operations.get("/home/topbanner");


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("businessbanner")
    @OAuthSecurity(enabled = false)
    public JSONObject businessbanner() {
        Operation operation = ApiConfig.operations.get("/home/businessbanner");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("apptips")
    @OAuthSecurity(enabled = false)
    public JSONObject appTips(@ApiParam(value = "device") @FormParam(value = "device") String device) {

        Operation operation = ApiConfig.operations.get("/apptips/active");
        JSONObject queryParams = new JSONObject();
        queryParams.put("device", device);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("appRedirection")
    @OAuthSecurity(enabled = false)
    public JSONObject appRedirection() {
        Operation operation = ApiConfig.operations.get("/appRedirection");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }
}
