/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Api(value = "JobCard API")
@Path("/jobcard")
public class JobCardResource {

    // Define logger (Standard java.util.Logger)
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    //List of all services car

    @ApiOperation(value = "Get List of services car", notes = "Get all services ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of services  OK")})
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject JobCardCarServices(@QueryParam(value = "plate_number") String plate_number) {

            Operation operation = ApiConfig.operations.get("/jobcard/all");

            JSONObject queryParams = new JSONObject();
            queryParams.put("plate_number", plate_number);

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //List of services Car filtered By Date

    @ApiOperation(value = "Get List of services By Date ", notes = "Get all services By date ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of services By Date  OK")})
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/allByDate")
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject JobCardCarServicesByDate(@QueryParam(value = "plate_number") String plate_number,
                                               @QueryParam(value = "from") String from,
                                               @QueryParam(value = "to") String to) {

            Operation operation = ApiConfig.operations.get("/jobcard/allByDate");

            JSONObject queryParams = new JSONObject();
            queryParams.put("plate_number", plate_number);
            queryParams.put("from", from);
            queryParams.put("to", to);

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }


    //JobCard transaction  creditCard

    @ApiOperation(value = "Add JobCard transaction ", notes = "Add JobCard transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Add operation  OK")})
    @POST
    @Path("/jctransactionlog/creditcard/save")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    // @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject saveCreditCardJCtransaction(@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
                                                  @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                                  @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                                  @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
                                                  @ApiParam(value = "voucher_reference", required = true) @FormParam("voucher_reference") String voucher_reference,
                                                  @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                                  @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                                  @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                                  @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String referenceNumber,
                                                  @ApiParam(value = "jobCard_organisation_id", required = true) @FormParam("jobCard_organisation_id") String jobCard_organisation_id,
                                                  @ApiParam(value = "jobCard_asset_number", required = true) @FormParam("jobCard_asset_number") String jobCard_asset_number,
                                                  @ApiParam(value = "jobcard_asset_description", required = true) @FormParam("jobcard_asset_description") String jobcard_asset_description,
                                                  @ApiParam(value = "jobCard_wip_entity_id", required = true) @FormParam("jobCard_wip_entity_id") String jobCard_wip_entity_id,
                                                  @ApiParam(value = "jobCard_wono", required = false) @FormParam("jobCard_wono") String jobCard_wono,
                                                  @ApiParam(value = "jobCard_wono_desc", required = false) @FormParam("jobCard_wono_desc") String jobCard_wono_desc,
                                                  @ApiParam(value = "jobCard_status", required = false) @FormParam("jobCard_status") String jobCard_status,
                                                  @ApiParam(value = "jobCard_dept", required = false) @FormParam("jobCard_dept") String jobCard_dept,
                                                  @ApiParam(value = "jobCard_activity", required = false) @FormParam("jobCard_activity") String jobCard_activity,
                                                  @ApiParam(value = "jobCard_activity_desc", required = false) @FormParam("jobCard_activity_desc") String jobCard_activity_desc,
                                                  @ApiParam(value = "jobCard_creation_date", required = false) @FormParam("jobCard_creation_date") String jobCard_creation_date,
                                                  @ApiParam(value = "jobCard_date_released", required = false) @FormParam("jobCard_date_released") String jobCard_date_released,
                                                  @ApiParam(value = "jobCard_date_completed", required = false) @FormParam("jobCard_date_completed") String jobCard_date_completed,
                                                  @ApiParam(value = "jobCard_date_closed", required = false) @FormParam("jobCard_date_closed") String jobCard_date_closed,
                                                  @ApiParam(value = "jobCard_actual_start_date", required = false) @FormParam("jobCard_actual_start_date") String jobCard_actual_start_date,
                                                  @ApiParam(value = "jobCard_scheduled_start_date", required = false) @FormParam("jobCard_scheduled_start_date") String jobCard_scheduled_start_date,
                                                  @ApiParam(value = "jobCard_scheduled_completion_date", required = false) @FormParam("jobCard_scheduled_completion_date") String jobCard_scheduled_completion_date,
                                                  @ApiParam(value = "jobCard_created_by", required = false) @FormParam("jobCard_created_by") String jobCard_created_by,
                                                  @ApiParam(value = "jobCard_meter_reading", required = true) @FormParam("jobCard_meter_reading") String jobCard_meter_reading,
                                                  @ApiParam(value = "jobCard_actual_end_date", required = true) @FormParam("jobCard_actual_end_date") String jobCard_actual_end_date,
                                                  @ApiParam(value = "jobCard_wip_class", required = true) @FormParam("jobCard_wip_class") String jobCard_wip_class,
                                                  @ApiParam(value = "jobCard_next_service", required = true) @FormParam("jobCard_next_service") String jobCard_next_service,
                                                  @ApiParam(value = "jobCard_station_name", required = true) @FormParam("jobCard_station_name") String jobCard_station_name,
                                                  @ApiParam(value = "jobCard_total_amount", required = true) @FormParam("jobCard_total_amount") String jobCard_total_amount,
                                                  @ApiParam(value = "jobCard_status_payment", required = true) @FormParam("jobCard_status_payment") String jobCard_status_payment,
                                                  @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                                  @ApiParam(value = "initial_amount", required = true) @FormParam("initial_amount") String initial_amount) {


        Operation operation = ApiConfig.operations.get("/jobcard/jctransactionlog/creditcard/save");

        JSONObject jobCard = new JSONObject();
        jobCard.put("ORGANIZATION_ID", jobCard_organisation_id);
        jobCard.put("ASSET_NUMBER", jobCard_asset_number);
        jobCard.put("ASSET_DESCRIPTION", jobcard_asset_description);
        jobCard.put("WIP_ENTITY_ID", jobCard_wip_entity_id);
        jobCard.put("WONO", jobCard_wono);
        jobCard.put("WO_DESC", jobCard_wono_desc);
        jobCard.put("STATUS", jobCard_status);
        jobCard.put("DEPT", jobCard_dept);
        jobCard.put("ACTIVITY", jobCard_activity);
        jobCard.put("ACTIVITY_DESC", jobCard_activity_desc);
        jobCard.put("CREATION_DATE", jobCard_creation_date);
        jobCard.put("DATE_RELEASED", jobCard_date_released);
        jobCard.put("DATE_COMPLETED", jobCard_date_completed);
        jobCard.put("DATE_CLOSED", jobCard_date_closed);
        jobCard.put("ACTUAL_START_DATE", jobCard_actual_start_date);
        jobCard.put("SCHEDULED_START_DATE", jobCard_scheduled_start_date);
        jobCard.put("SCHEDULED_COMPLETION_DATE", jobCard_scheduled_completion_date);
        jobCard.put("CREATED_BY", jobCard_created_by);
        jobCard.put("METER_READING", jobCard_meter_reading);
        jobCard.put("ACTUAL_END_DATE", jobCard_actual_end_date);
        jobCard.put("WIP_CLASS", jobCard_wip_class);
        jobCard.put("NEXT_SERVICE", jobCard_next_service);
        jobCard.put("STATION_NAME", jobCard_station_name);
        jobCard.put("TOTAL_AMOUNT", jobCard_total_amount);
        jobCard.put("PAYMENT_STATUS", jobCard_status_payment);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("jobCard", jobCard);
        bodyParams.put("initial_amount", initial_amount);

        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("voucher_reference", voucher_reference);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }


    //  update transaction jobcard  (if cancel)
    @ApiOperation(value = "Update jc transaction ", notes = "Update jc transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " update transaction  OK")})
    @POST
    @Path("/jctransactionlog/updateTransactionUUID")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject UpdateJCTransaction(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
                                          @ApiParam(value = "status", required = true) @FormParam("status") String status) {

        Operation operation = ApiConfig.operations.get("/jobcard/jctransactionlog/updateTransactionUUID");

        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        queryParams.put("status", status);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


//  transaction jobcard woqode

    @ApiOperation(value = "save jc transaction woqode", notes = "transaction jc woqode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " save transaction jc woqode OK")})
    @POST
    @Path("/jctransactionlog/woqode/save")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject TransactionJCWoqode(@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
                                          @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                          @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                          @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
                                          @ApiParam(value = "voucher_reference", required = true) @FormParam("voucher_reference") String voucher_reference,
                                          @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String referenceNumber,
                                          @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                          @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                          @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                          @ApiParam(value = "jobCard_organisation_id", required = true) @FormParam("jobCard_organisation_id") String jobCard_organisation_id,
                                          @ApiParam(value = "jobCard_asset_number", required = true) @FormParam("jobCard_asset_number") String jobCard_asset_number,
                                          @ApiParam(value = "jobcard_asset_description", required = true) @FormParam("jobcard_asset_description") String jobcard_asset_description,
                                          @ApiParam(value = "jobCard_wip_entity_id", required = true) @FormParam("jobCard_wip_entity_id") String jobCard_wip_entity_id,
                                          @ApiParam(value = "jobCard_wono", required = false) @FormParam("jobCard_wono") String jobCard_wono,
                                          @ApiParam(value = "jobCard_wono_desc", required = false) @FormParam("jobCard_wono_desc") String jobCard_wono_desc,
                                          @ApiParam(value = "jobCard_status", required = false) @FormParam("jobCard_status") String jobCard_status,
                                          @ApiParam(value = "jobCard_dept", required = false) @FormParam("jobCard_dept") String jobCard_dept,
                                          @ApiParam(value = "jobCard_activity", required = false) @FormParam("jobCard_activity") String jobCard_activity,
                                          @ApiParam(value = "jobCard_activity_desc", required = false) @FormParam("jobCard_activity_desc") String jobCard_activity_desc,
                                          @ApiParam(value = "jobCard_creation_date", required = false) @FormParam("jobCard_creation_date") String jobCard_creation_date,
                                          @ApiParam(value = "jobCard_date_released", required = false) @FormParam("jobCard_date_released") String jobCard_date_released,
                                          @ApiParam(value = "jobCard_date_completed", required = false) @FormParam("jobCard_date_completed") String jobCard_date_completed,
                                          @ApiParam(value = "jobCard_date_closed", required = false) @FormParam("jobCard_date_closed") String jobCard_date_closed,
                                          @ApiParam(value = "jobCard_actual_start_date", required = false) @FormParam("jobCard_actual_start_date") String jobCard_actual_start_date,
                                          @ApiParam(value = "jobCard_scheduled_start_date", required = false) @FormParam("jobCard_scheduled_start_date") String jobCard_scheduled_start_date,
                                          @ApiParam(value = "jobCard_scheduled_completion_date", required = false) @FormParam("jobCard_scheduled_completion_date") String jobCard_scheduled_completion_date,
                                          @ApiParam(value = "jobCard_created_by", required = false) @FormParam("jobCard_created_by") String jobCard_created_by,
                                          @ApiParam(value = "jobCard_meter_reading", required = true) @FormParam("jobCard_meter_reading") String jobCard_meter_reading,
                                          @ApiParam(value = "jobCard_actual_end_date", required = true) @FormParam("jobCard_actual_end_date") String jobCard_actual_end_date,
                                          @ApiParam(value = "jobCard_wip_class", required = true) @FormParam("jobCard_wip_class") String jobCard_wip_class,
                                          @ApiParam(value = "jobCard_next_service", required = true) @FormParam("jobCard_next_service") String jobCard_next_service,
                                          @ApiParam(value = "jobCard_station_name", required = true) @FormParam("jobCard_station_name") String jobCard_station_name,
                                          @ApiParam(value = "jobCard_total_amount", required = true) @FormParam("jobCard_total_amount") String jobCard_total_amount,
                                          @ApiParam(value = "jobCard_status_payment", required = true) @FormParam("jobCard_status_payment") String jobCard_status_payment,
                                          @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                          @ApiParam(value = "initial_amount", required = true) @FormParam("initial_amount") String initial_amount) {

        Operation operation = ApiConfig.operations.get("/jobcard/jctransactionlog/woqode/save");

        JSONObject jobCard = new JSONObject();
        jobCard.put("ORGANIZATION_ID", jobCard_organisation_id);
        jobCard.put("ASSET_NUMBER", jobCard_asset_number);
        jobCard.put("ASSET_DESCRIPTION", jobcard_asset_description);
        jobCard.put("WIP_ENTITY_ID", jobCard_wip_entity_id);
        jobCard.put("WONO", jobCard_wono);
        jobCard.put("WO_DESC", jobCard_wono_desc);
        jobCard.put("STATUS", jobCard_status);
        jobCard.put("DEPT", jobCard_dept);
        jobCard.put("ACTIVITY", jobCard_activity);
        jobCard.put("ACTIVITY_DESC", jobCard_activity_desc);
        jobCard.put("CREATION_DATE", jobCard_creation_date);
        jobCard.put("DATE_RELEASED", jobCard_date_released);
        jobCard.put("DATE_COMPLETED", jobCard_date_completed);
        jobCard.put("DATE_CLOSED", jobCard_date_closed);
        jobCard.put("ACTUAL_START_DATE", jobCard_actual_start_date);
        jobCard.put("SCHEDULED_START_DATE", jobCard_scheduled_start_date);
        jobCard.put("SCHEDULED_COMPLETION_DATE", jobCard_scheduled_completion_date);
        jobCard.put("CREATED_BY", jobCard_created_by);
        jobCard.put("METER_READING", jobCard_meter_reading);
        jobCard.put("ACTUAL_END_DATE", jobCard_actual_end_date);
        jobCard.put("WIP_CLASS", jobCard_wip_class);
        jobCard.put("NEXT_SERVICE", jobCard_next_service);
        jobCard.put("STATION_NAME", jobCard_station_name);
        jobCard.put("TOTAL_AMOUNT", jobCard_total_amount);
        jobCard.put("PAYMENT_STATUS", jobCard_status_payment);

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("amount", amount);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("jobCard", jobCard);
        bodyParams.put("initial_amount", initial_amount);

        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("voucher_reference", voucher_reference);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);

    }

    //DiscountVoucher

    @ApiOperation(value = "Get voucher discount", notes = "Get voucher discount ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " voucher descount  OK")})
    @GET
    @Path("/voucher/getByReference")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject VoucherDiscount(@ApiParam(value = "voucherReference", required = true) @FormParam("voucherReference") String voucherReference) {

        Operation operation = ApiConfig.operations.get("/jobcard/voucher/getByReference");

        JSONObject queryParams = new JSONObject();
        queryParams.put("voucherReference", voucherReference);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //  Get Reference Number
    @ApiOperation(value = "Get ReferenceNumber", notes = "Get ReferenceNumber ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Get ReferenceNumber OK")})
    @GET
    @Path("/jctransactionlog/findByJobCard")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject GetReferenceNumber(@ApiParam(value = "job_card_identity", required = true) @FormParam("job_card_identity") String ASSET_NUMBER) {

        Operation operation = ApiConfig.operations.get("/jobcard/jctransactionlog/findByJobCard");

        JSONObject queryParams = new JSONObject();
        queryParams.put("job_card_identity", ASSET_NUMBER);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }

    // generate job card pdf
    @ApiOperation(value = "Generate  E-Receipt", notes = "Generate  E-Receipt")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Generate  E-Receipt  OK")})
    @GET
    @Path("/generatePDF")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(enabled = false)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject GeneratePdf(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {

        System.out.println("jobCard GeneratePdf...");
        Operation operation = ApiConfig.operations.get("/jobcard/generatePDF");
        //  System.out.println("jobCard GeneratePdf url :::" + operation.url);
        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        System.out.println("jobCard queryParams:::" + queryParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    // JobCard SendMail
    @ApiOperation(value = "JobCard Send Mail", notes = "JobCard Send Mail")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Send operation OK")})
    @POST
    @Path("/sendMail")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(enabled = false)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject SendMail(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {

        Operation operation = ApiConfig.operations.get("/jobcard/sendMail");

        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }

    // JobCard get receipt image
    @ApiOperation(value = "Generate Receipt Image", notes = "Generate  Receipt Image")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Generate  E-Receipt  OK")})
    @GET
    @Path("/image")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(enabled = false)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject getImage(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transaction) {
//    transactionUUID = "8d8ecddf-24c5-e694-117c-649c49b47fae";

        System.out.println("param transactionUUID:::" + transaction);
        Operation operation = ApiConfig.operations.get("/jobcard/image");
        System.out.println("jobCard GetReceiptImage url :::" + operation.url);
        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transaction);
        System.out.println("jobCard GetReceiptImage queryParams:::" + queryParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
}


