/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.Base64;
import java.util.logging.Logger;

@Api(value = "User API")
@Path("/users")
public class UserResource {
    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(UserResource.class.getName());
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @GET
    @Path("/details")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getUserDetails() {

        Operation operation = ApiConfig.operations.get("/users/{username}");

        JSONObject urlParams = new JSONObject();
        urlParams.put("username", RequestGenerator.getUserName(securityContext));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), urlParams, null, null);
    }

    @POST
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject update(@ApiParam(value = "id") @FormParam("id") String id,
                             @ApiParam(value = "username") @FormParam("username") String username,
                             @ApiParam(value = "firstName") @FormParam("firstName") String firstName,
                             @ApiParam(value = "lastName") @FormParam("lastName") String lastName,
                             @ApiParam(value = "birthdate") @FormParam("birthdate") String birthdate,
                             @ApiParam(value = "adress1Label") @FormParam("adress1Label") String adress1Label,
                             @ApiParam(value = "idArea") @FormParam("idArea") String idArea,
                             @ApiParam(value = "poBox") @FormParam("poBox") String poBox,
                             @ApiParam(value = "ipAddress", required = true) @FormParam(value = "ipAddress") String ipAddress) {
        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userName = String.valueOf(currentUser.getAttributes().get("username"));

        if (userName.equalsIgnoreCase(username)) {

            Operation operation = ApiConfig.operations.get("/users");

            JSONObject bodyParams = new JSONObject();
            bodyParams.put("id", id);
            bodyParams.put("firstName", firstName);
            bodyParams.put("lastName", lastName);
            bodyParams.put("birthdate", birthdate);
            bodyParams.put("adress1Label", adress1Label);
            bodyParams.put("poBox", poBox);
            bodyParams.put("idArea", idArea);
            bodyParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }

    @POST
    @Path("/password")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject resetPassword(@ApiParam(value = "password") @FormParam("password") String password) {

        Operation operation = ApiConfig.operations.get("/users/password");

        JSONObject bodyParams = new JSONObject();
        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
        bodyParams.put("username", RequestGenerator.getUserName(securityContext));
        bodyParams.put("password", encodedPassword);

        //System.out.println(bodyParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/updatePhoto")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject updatePhoto(@ApiParam(value = "photo") @FormParam("photo") String photo) {

        Operation operation = ApiConfig.operations.get("/users/updatePhoto");

        JSONObject bodyParams = new JSONObject();

        bodyParams.put("username", RequestGenerator.getUserName(securityContext));
        bodyParams.put("photo", photo);
//    bodyParams.put("type", "Individual_Customer");

        //System.out.println(bodyParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/updatePhoneNumber")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject updatePhoneNumber(@ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
                                        @ApiParam(value = "phone", required = true) @FormParam(value = "phone") String phone,
                                        @ApiParam(value = "ipAddress", required = true) @FormParam(value = "ipAddress") String ipAddress) {

        Operation operation = ApiConfig.operations.get("/users/updatePhoneNumber");
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("phone", phone);
        bodyParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/updateEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject updateEmail(@ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
                                  @ApiParam(value = "email", required = true) @FormParam(value = "email") String email,
                                  @ApiParam(value = "ipAddress", required = true) @FormParam(value = "ipAddress") String ipAddress) {

        Operation operation = ApiConfig.operations.get("/users/updateEmail");
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("email", email);
        bodyParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @GET
    @Path("/transactions")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject transactions() {

        Operation operation = ApiConfig.operations.get("/users/transactions");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", RequestGenerator.getUserName(securityContext));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/cars/deleteCar")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject deleteCar(@ApiParam(value = "qid") @FormParam("qid") String qid,
                                @ApiParam(value = "id") @FormParam("id") long id) {

        Operation operation = ApiConfig.operations.get("/users/cars/deleteCar");
        JSONObject queryParams = new JSONObject();
        queryParams.put("qid", qid);
        queryParams.put("id", id);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/cars")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject cars() {

        Operation operation = ApiConfig.operations.get("/users/cars");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", RequestGenerator.getUserName(securityContext));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/getProfilePhoto")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject getProfilePhoto() {
        JSONObject jsonObject = new JSONObject();

        Operation operation = ApiConfig.operations.get("/users/getProfilePhoto");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", RequestGenerator.getUserName(securityContext));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/cars/add")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject addCar(@ApiParam(value = "vehiclePlate", required = true) @FormParam("vehiclePlate") String vehiclePlate,
                             @ApiParam(value = "vehicleModel", required = true) @FormParam("vehicleModel") String vehicleModel,
                             @ApiParam(value = "dueDate", required = true) @FormParam("dueDate") String dueDate) {

        Operation operation = ApiConfig.operations.get("/users/cars/add");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", RequestGenerator.getUserName(securityContext));
        bodyParams.put("vehiclePlate", vehiclePlate);
        bodyParams.put("vehicleModel", vehicleModel);
        bodyParams.put("dueDate", dueDate);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @ApiOperation(value = "get Current authenticated user", notes = "get Current authenticated user")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "get Current authenticated user")})
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getCurrentUser")
    @OAuthSecurity(scope = "UserLogin")
    public String getCurrentUser() {
        AuthenticatedUser user = securityContext.getAuthenticatedUser();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "hassen");
        return "{'hassen':'hassen'}";
    }


    @POST
    @Path("/checkUser")
    @Produces(MediaType.APPLICATION_JSON)
//  @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject checkUser(@ApiParam(value = "username", required = false) @FormParam("username") String username,
                                @ApiParam(value = "qid", required = false) @FormParam("qid") String qid,
                                @ApiParam(value = "mobileNumber", required = false) @FormParam("mobileNumber") String phone,
                                @ApiParam(value = "email", required = false) @FormParam("email") String email) {

        Operation operation = ApiConfig.operations.get("/users/checkUser");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("qid", qid);
        queryParams.put("email", email);
        queryParams.put("phone", phone);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

    @POST
    @Path("/sendMail")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject sendMail(@ApiParam(value = "email", required = true) @FormParam("email") String email,
                               @ApiParam(value = "username", required = true) @FormParam("username") String username) {
        Operation operation = ApiConfig.operations.get("/users/sendMail");
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("email", email);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/registerDevice")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject register(@ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {
        Operation operation = ApiConfig.operations.get("/surveys/register");
        JSONObject urlParams = new JSONObject();
        urlParams.put("deviceId", deviceId);
        System.out.println("operation" + operation.url + operation.method);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, urlParams, null);
}


    @POST
    @Path("/deleteUser")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject deleteUser() {

        Operation operation = ApiConfig.operations.get("/users/deleteUser");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", RequestGenerator.getUserName(securityContext));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
}
