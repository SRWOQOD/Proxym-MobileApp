/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.logging.Logger;


@Api(value = "Register API")
@Path("/register")
public class RegisterResource {
    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(RegisterResource.class.getName());
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;


    @ApiOperation(value = "Check QID Validity", notes = "Check QID Validity")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Check QID Validity")})
    @POST
    @Path("/checkQidValidity")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject checkQidValidity(@ApiParam(value = "number", required = true) @FormParam("number") String number,
                                       @ApiParam(value = "qid", required = true) @FormParam("qid") String qid) {

        Operation operation = ApiConfig.operations.get("/checkqidvalidity");

        JSONObject queryParams = new JSONObject();
        queryParams.put("number", number);
        queryParams.put("qid", qid);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @ApiOperation(value = "Check QID And Mobile Number Validity", notes = "Check QID And Mobile Number Validity")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Check QID And Mobile Number Validity")})
    @POST
    @Path("/checkQidAndMobileValidity")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject checkQidAndMobileValidity(@ApiParam(value = "number", required = true) @FormParam("number") String number,
                                                @ApiParam(value = "qid", required = true) @FormParam("qid") String qid) {

        Operation operation = ApiConfig.operations.get("/checkQidAndMobileValidity");

        JSONObject queryParams = new JSONObject();
        queryParams.put("number", number);
        queryParams.put("qid", qid);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @ApiOperation(value = "Register and GenerateActivationCode", notes = "Register and GenerateActivationCode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Register and GenerateActivationCode")})
    @POST
    @Path("/register")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject register(@ApiParam(value = "type", required = true) @FormParam("type") String type,
                               @ApiParam(value = "customerId", required = true) @FormParam("customerId") String customerId,
                               @ApiParam(value = "poBox", required = true) @FormParam("poBox") String poBox,
                               @ApiParam(value = "language", required = true) @FormParam("language") String language,
                               @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                               @ApiParam(value = "username", required = true) @FormParam("username") String userName,
                               @ApiParam(value = "password", required = true) @FormParam("password") String password,
                               @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                               @ApiParam(value = "email", required = true) @FormParam("email") String email,
                               @ApiParam(value = "firstName", required = true) @FormParam("firstName") String firstName,
                               @ApiParam(value = "lastName", required = true) @FormParam("lastName") String lastName,
                               @ApiParam(value = "birthdate", required = true) @FormParam("birthdate") String birthdate,
                               @ApiParam(value = "gender", required = true) @FormParam("gender") String gender,
                               @ApiParam(value = "contactType", required = true) @FormParam("contactType") String contactType,
                               @ApiParam(value = "adress1", required = true) @FormParam("adress1") String adress1,
                               @ApiParam(value = "adress2") @FormParam("adress2") String adress2,
                               @ApiParam(value = "adress1Label", required = true) @FormParam("adress1Label") String adress1Label,
                               @ApiParam(value = "adress2Label") @FormParam("adress2Label") String adress2Label,
                               @ApiParam(value = "income") @FormParam("income") String income,
                               @ApiParam(value = "vehBrand") @FormParam("vehBrand") String vehBrand,
                               @ApiParam(value = "idArea") @FormParam("idArea") String idArea,
                               @ApiParam(value = "vehModel") @FormParam("vehModel") String vehModel,
                               @ApiParam(value = "preferedLanguage", required = true) @FormParam("preferedLanguage") String preferedLanguage,
                               @ApiParam(value = "photo") @FormParam("photo") String photo) {

        Operation operation = ApiConfig.operations.get("/register");


        JSONObject bodyParams = new JSONObject();
        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
        bodyParams.put("type", type);
        bodyParams.put("customerId", customerId);
        bodyParams.put("qid", qid);
        bodyParams.put("username", userName);
        bodyParams.put("password", encodedPassword);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("email", email);
        bodyParams.put("firstName", firstName);
        bodyParams.put("lastName", lastName);
        bodyParams.put("birthdate", birthdate);
        bodyParams.put("gender", gender);
        bodyParams.put("contactType", contactType);
        bodyParams.put("adress1", adress1);
        bodyParams.put("adress2", adress2);
        bodyParams.put("adress1Label", adress1Label);
        bodyParams.put("adress2Label", adress2Label);
        bodyParams.put("income", income);
        bodyParams.put("vehBrand", vehBrand);
        bodyParams.put("vehModel", vehModel);
        bodyParams.put("preferedLanguage", preferedLanguage);
        bodyParams.put("photo", photo);
        bodyParams.put("poBox", poBox);
        bodyParams.put("idArea", idArea);

        JSONObject queryParams = new JSONObject();
        queryParams.put("language", language.trim().toLowerCase());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }


    @ApiOperation(value = "Register and GenerateActivationCode", notes = "Register and GenerateActivationCode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Register and GenerateActivationCode")})
    @POST
    @Path("/registerup")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject registerup(@ApiParam(value = "encryptedData") @FormParam("encryptedData") String encryptedData) {

        System.out.println("encrypted Credentials: " + encryptedData);
        JSONObject credentials = null;

        try {

            byte[] input = Base64.getDecoder().decode(encryptedData);
            System.out.println("input: " + Arrays.toString(input));

            SecretKey keySpec = new SecretKeySpec(Base64.getDecoder().decode("u/Gu5posvwDsXUnV5Zaq4g=="), "AES");
            System.out.println("key: " + keySpec);

            AlgorithmParameterSpec ivSpec = new IvParameterSpec(Base64.getDecoder().decode("5D9r9ZVzEYYgha93/aUK2w=="));
            System.out.println("ivSpec: " + ivSpec);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            String bytes = new String(cipher.doFinal(input), "UTF-8");
            System.out.println("bytes :" + bytes);

            //JSONParser parser = new JSONParser();
            credentials = (JSONObject) JSONObject.parse(bytes);
            System.out.println("credentials :" + credentials);

        } catch (Exception ex) {
            System.out.println(ex.toString());
        }

        Operation operation = ApiConfig.operations.get("/register");

        String type = credentials.get("type").toString();
        String customerId = credentials.get("customerId").toString();
        String qid = credentials.get("qid").toString();
        String userName = credentials.get("username").toString().trim().toLowerCase();
        String password = credentials.get("password").toString();
        String mobileNumber = credentials.get("mobileNumber").toString();
        String email = credentials.get("email").toString();
        String firstName = credentials.get("firstName").toString();
        String lastName = credentials.get("lastName").toString();
        String birthdate = credentials.get("birthdate").toString();
        String gender = credentials.get("gender").toString();
        String contactType = credentials.get("contactType").toString();
        String adress1 = credentials.get("adress1").toString();
        String adress2 = (credentials.containsKey("adress2")) ? credentials.get("adress2").toString() : null;
        String adress1Label = credentials.get("adress1Label").toString();
        String adress2Label = (credentials.containsKey("adress2Label")) ? credentials.get("adress2Label").toString() : null;
        String income = (credentials.containsKey("income")) ? credentials.get("income").toString() : null;
        String vehBrand = (credentials.containsKey("vehBrand")) ? credentials.get("vehBrand").toString() : null;
        String vehModel = (credentials.containsKey("vehModel")) ? credentials.get("vehModel").toString() : null;
        String preferedLanguage = credentials.get("preferedLanguage").toString();
        String photo = (credentials.containsKey("photo")) ? credentials.get("photo").toString() : null;

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("type", type);
        bodyParams.put("customerId", customerId);
        bodyParams.put("qid", qid);
        bodyParams.put("username", userName.trim().toLowerCase());
        bodyParams.put("password", password);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("email", email);
        bodyParams.put("firstName", firstName);
        bodyParams.put("lastName", lastName);
        bodyParams.put("birthdate", birthdate);
        bodyParams.put("gender", gender);
        bodyParams.put("contactType", contactType);
        bodyParams.put("adress1", adress1);
        bodyParams.put("adress2", adress2);
        bodyParams.put("adress1Label", adress1Label);
        bodyParams.put("adress2Label", adress2Label);
        bodyParams.put("income", income);
        bodyParams.put("vehBrand", vehBrand);
        bodyParams.put("vehModel", vehModel);
        bodyParams.put("preferedLanguage", preferedLanguage);
        bodyParams.put("photo", photo);

        String language = credentials.get("language").toString().trim().toLowerCase();
        JSONObject queryParams = new JSONObject();
        queryParams.put("language", language);
        //queryParams.put("language", language.trim().toLowerCase());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);

    }


    @ApiOperation(value = "ActivateAccount", notes = "ActivateAccount")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "ActivateAccount")})
    @POST
    @Path("/activate")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject activate(@ApiParam(value = "username", required = true) @FormParam("username") String userName,
                               @ApiParam(value = "pinCode", required = true) @FormParam("pinCode") String pinCode,
                               @ApiParam(value = "deviceSerial", required = true) @FormParam("deviceSerial") String deviceSerial,
                               @ApiParam(value = "deviceType", required = true) @FormParam("deviceType") String deviceType) {

        Operation operation = ApiConfig.operations.get("/activate");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", userName);
        bodyParams.put("pinCode", pinCode);
        bodyParams.put("deviceSerial", deviceSerial);
        bodyParams.put("deviceType", deviceType);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @ApiOperation(value = "SendRecoveryCode", notes = "SendRecoveryCode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "SendRecoveryCode")})
    @POST
    @Path("/sendrecoverycode")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject sendRecoveryCode(@ApiParam(value = "username", required = true) @FormParam("username") String userName,
                                       @ApiParam(value = "type", required = true) @FormParam("type") String type,
                                       @ApiParam(value = "language", required = true) @FormParam("language") String language) {

        Operation operation = ApiConfig.operations.get("/sendrecoverycode");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", userName);
        queryParams.put("language", language.trim().toLowerCase());
        queryParams.put("type", type);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

    @POST
    @Path("/checkrecoverycode")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject checkrecoverycode(@ApiParam(value = "username", required = true) @FormParam("username") String userName,
                                        @ApiParam(value = "type", required = true) @FormParam("type") String type,
                                        @ApiParam(value = "pincode", required = true) @FormParam("pincode") String pincode) {

        Operation operation = ApiConfig.operations.get("/checkrecoverycode");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", userName);
        queryParams.put("pincode", pincode);
        queryParams.put("type", type);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

    @ApiOperation(value = "SendNewPinCode", notes = "SendNewPinCode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "SendNewPinCode")})
    @POST
    @Path("/sendpincode")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject sendPinCode(@ApiParam(value = "username") @FormParam("username") String userName,
                                  @ApiParam(value = "language") @FormParam("language") String language) {

        Operation operation = ApiConfig.operations.get("/sendpincode");


        JSONObject queryParams = new JSONObject();
        queryParams.put("username", userName);
        queryParams.put("language", language.trim().toLowerCase());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }

    @ApiOperation(value = "RecoverPassword", notes = "RecoverPassword")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "RecoverPassword")})
    @POST
    @Path("/recover")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject recover(@ApiParam(value = "username", required = true) @FormParam("username") String userName,
                              @ApiParam(value = "type", required = true) @FormParam("type") String type,
                              @ApiParam(value = "newpassword", required = true) @FormParam("newpassword") String newpassword) {

        Operation operation = ApiConfig.operations.get("/recover");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", userName);
        bodyParams.put("type", type);
        String encodedPassword = Base64.getEncoder().encodeToString(newpassword.getBytes());
        bodyParams.put("newpassword", encodedPassword);

        System.out.println("jsonResponse ::::::::::: " + bodyParams.toString());
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

}
