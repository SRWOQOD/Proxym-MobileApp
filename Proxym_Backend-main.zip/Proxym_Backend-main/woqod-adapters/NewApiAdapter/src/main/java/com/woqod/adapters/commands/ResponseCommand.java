package com.woqod.adapters.commands;

import java.io.Serializable;

public class ResponseCommand implements Serializable {

    private static final long serialVersionUID = 3352115329524238195L;

    private HeaderCommand header;
    private BodyCommand body;

    public ResponseCommand() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseCommand(HeaderCommand header, BodyCommand body) {
        super();
        this.header = header;
        this.body = body;
    }

    public HeaderCommand getHeader() {
        return header;
    }

    public void setHeader(HeaderCommand header) {
        this.header = header;
    }

    public BodyCommand getBody() {
        return body;
    }

    public void setBody(BodyCommand body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "ResponseCommand [header=" + header + ", body=" + body + "]";
    }
}
