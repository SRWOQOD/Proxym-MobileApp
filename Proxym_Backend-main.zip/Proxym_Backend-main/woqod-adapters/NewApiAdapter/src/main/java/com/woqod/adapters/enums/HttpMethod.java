package com.woqod.adapters.enums;

public enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE;
}
