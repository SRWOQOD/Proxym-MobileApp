package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Api(value = "Bio API")
@Path("/")
public class BioResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("addBioPin")
    @OAuthSecurity(enabled = false)
    public JSONObject addBioPin(
            @ApiParam(value = "bioPin", required = true) @FormParam("bioPin") String bioPin,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("bioPin", bioPin);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("validate")
    @OAuthSecurity(enabled = false)
    public JSONObject validate(
            @ApiParam(value = "pinCode", required = true) @FormParam("pinCode") String pinCode,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio/validate");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("pinCode", pinCode);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("generateCustomPwd")
    @OAuthSecurity(enabled = false)
    public JSONObject generateCustomPwd(
            @ApiParam(value = "username", required = true) @FormParam("username") String username,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {

        Operation operation = ApiConfig.operations.get("/bio/custompwd");


        JSONObject queryParams = new JSONObject();

        queryParams.put("deviceId", deviceId);
        queryParams.put("username", username);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("bio/getUser")
    @OAuthSecurity(enabled = false)
    public JSONObject getUser(
            @ApiParam(value = "username", required = true) @FormParam("username") String username,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {

        Operation operation = ApiConfig.operations.get("/bio/getUser");


        JSONObject queryParams = new JSONObject();

        queryParams.put("deviceId", deviceId);
        queryParams.put("username", username);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("checkFingerPrint")
    @OAuthSecurity(enabled = false)
    public JSONObject checkFingerPrint(
            @ApiParam(value = "customPwd", required = true) @FormParam("customPwd") String customPwd,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio/checkFingerPrint");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("customPwd", customPwd);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("updateBioPin")
    @OAuthSecurity(enabled = false)
    public JSONObject updateBioPin(
            @ApiParam(value = "oldBioPin", required = true) @FormParam("oldBioPin") String oldBioPin,
            @ApiParam(value = "newBioPin", required = true) @FormParam("newBioPin") String bioPin,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio/updateBioPin");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("newBioPin", bioPin);
        bodyParams.put("oldBioPin", oldBioPin);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("bio/updateStatus")
    @OAuthSecurity(enabled = false)
    public JSONObject updatestatus(
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio/updateStatus");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("deviceId", deviceId);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("resetBioPin")
    @OAuthSecurity(enabled = false)
    public JSONObject resetBioPin(
            @ApiParam(value = "bioPin", required = true) @FormParam("bioPin") String bioPin,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "username", required = true) @FormParam("username") String username) {

        Operation operation = ApiConfig.operations.get("/bio/resetBioPin");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("newBioPin", bioPin);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }
}
