package com.woqod.adapters.enums;

public enum Errors {

    KEY_PAIR_EXCEPTION("02", "001", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),//Technical error, failed to get public key.
    ENCRYPT_EXCEPTION("02", "002", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, failed to encrypt an object.
    DECRYPT_EXCEPTION("02", "003", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, failed to decrypt an object.
    PARSE_EXCEPTION("02", "004", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, failed to parse an object.
    TECHNICAL_EXCEPTION("02", "005", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, failed to connect to the backend from mobile first server.
    UNKNOWN_EXCEPTION("02", "006", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Unknown error, An error has occurred when trying to connect to the backend from mobile first server.
    JSON_MAPPING_EXCEPTION("02", "007", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Json mapping error - No content to map due to end-of-input.
    ENCODING_EXCEPTION("02", "017", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Encoding exception.
    GENERATE_GET_PARAMS_EXCEPTION("02", "008", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, failed to generate get parameters.

    NOT_FOUND_EXCEPTION("02", "009", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Could not establish connection to the backend server,(404) not found.
    MALFORMED_URL_EXCEPTION("02", "010", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, malformed url error
    UNKNOWN_HOST_EXCEPTION("02", "011", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, unknown host error
    UNSUPPORTED_ENCODING_EXCEPTION("02", "012", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"), // Technical error, unsupported encoding error
    PROTOCOL_EXCEPTION("02", "013", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Technical error, protocol error
    AUTHENTICATION_ERROR("02", "015", "Failed to authenticate user.", "Failed to authenticate user.", "WARNING"),// Technical error, failed to authenticate user.
    IO_EXCEPTION("02", "014", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Could not establish connection to the backend server, Request time out.
    UNEXPECTED_ERROR("02", "015", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "WARNING"),// Unexpected Server Error
    SSO_SAML_ERROR("02", "016", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "ERROR"),// Error while getting connected user
    FILE_EXCEPTION("02", "017", "Technical error occurred, please try again later.", "Technical error occurred, please try again later.", "ERROR");// Error while saving file

    private final String code;
    private final String messageAR;
    private final String messageEN;
    private final String providerCode;
    private final String messageType;

    Errors(String _providerCode, String _code, String _messageEN, String _messageAR, String _messageType) {
        this.code = _code;
        this.messageAR = _messageAR;
        this.messageEN = _messageEN;
        this.providerCode = _providerCode;
        this.messageType = _messageType;
    }

    public String getMessageAR() {
        return messageAR;
    }

    public String getMessageEN() {
        return messageEN;
    }

    public String getCode() {
        return this.code;
    }

    public String getProviderCode() {
        return this.providerCode;
    }

    public String getMessageType() {
        return messageType;
    }

} 
 