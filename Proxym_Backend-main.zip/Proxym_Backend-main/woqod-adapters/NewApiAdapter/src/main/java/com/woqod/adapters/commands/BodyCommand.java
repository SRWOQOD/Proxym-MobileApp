package com.woqod.adapters.commands;

import java.io.Serializable;

public class BodyCommand implements Serializable {

    private static final long serialVersionUID = -3276533702127612355L;

    private String type;
    private Object result;

    public BodyCommand() {
        super();
        // TODO Auto-generated constructor stub
    }

    public BodyCommand(String type, Object result) {
        super();
        this.type = type;
        this.result = result;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "BodyCommand [type=" + type + ", result=" + result + "]";
    }
}
