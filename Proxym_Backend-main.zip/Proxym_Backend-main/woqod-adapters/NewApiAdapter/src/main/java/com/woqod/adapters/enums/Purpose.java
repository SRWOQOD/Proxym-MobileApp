package com.woqod.adapters.enums;

public enum Purpose {
    ACTIVE_REQUEST,
    NEW_SUBSCRIBE,
    FORGOTTEN_PWD
}
