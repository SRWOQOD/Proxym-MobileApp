package com.woqod.adapters.exceptions;


import com.woqod.adapters.enums.Errors;

public class ApplicationException extends RuntimeException {

    private static final long serialVersionUID = 8205877130108144548L;

    private String code;
    private String descriptionAR;
    private String descriptionEN;
    private String providerCode;
    private String messageType;

    public ApplicationException(String code, String descriptionAR, String descriptionEN, String providerCode, String messageType) {
        super();
        this.code = code;
        this.descriptionAR = descriptionAR;
        this.descriptionEN = descriptionEN;
        this.providerCode = providerCode;
        this.messageType = messageType;
    }

    public ApplicationException(Errors error) {
        super();
        this.code = error.getCode();
        this.descriptionAR = error.getMessageAR();
        this.descriptionEN = error.getMessageEN();
        this.providerCode = error.getProviderCode();
        this.messageType = error.getMessageType();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescriptionAR() {
        return descriptionAR;
    }

    public void setDescriptionAR(String descriptionAR) {
        this.descriptionAR = descriptionAR;
    }

    public String getDescriptionEN() {
        return descriptionEN;
    }

    public void setDescriptionEN(String descriptionEN) {
        this.descriptionEN = descriptionEN;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }


}
