package com.woqod.adapters.exceptions;


import com.woqod.adapters.errors.WoqodError;

/**
 * Created by bfitouri on 18/11/16.
 */
public class HeaderException extends WoqodException {

    public HeaderException(String entry) {
        super(WoqodError.HEADER_NOT_FOUND, entry);
    }
}
