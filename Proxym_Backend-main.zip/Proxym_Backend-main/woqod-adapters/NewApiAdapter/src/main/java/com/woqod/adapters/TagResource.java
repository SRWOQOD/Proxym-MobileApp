package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Tag API")
@Path("/tag")
public class TagResource {

    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */


    // Define logger (Standard java.util.Logger)
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @ApiOperation(value = "Add new pre registration  transaction ", notes = "Add new pre registration transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Add operation  OK")})
    @POST
    @Path("/prtransactionlog/creditcard/save")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject createTagTransaction(
            @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
            @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
            @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
            @ApiParam(value = "payment_method", required = true) @FormParam("payment_method") String paymentMethod,
            @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
            @ApiParam(value = "email", required = true) @FormParam("email") String email,
            @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
            @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
            @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type) {
        Operation operation = ApiConfig.operations.get("/tagTransaction/register");


        JSONObject feeResource = new JSONObject();


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("paymentMethod", paymentMethod);
        bodyParams.put("email", email);
        bodyParams.put("plateType", "1");
        bodyParams.put("plateNumber", plate_number);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);

    }
}
