package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Api(value = "Logging API")
@Path("/")
public class LoggingAdapterResource {


    @GET
    @Path("/saveLog")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject saveLog() {

        Operation operation = ApiConfig.operations.get("/saveLog");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("qid", "qid");
        bodyParams.put("ip", "ip");
        bodyParams.put("service", "service");
        bodyParams.put("request", "request");
        bodyParams.put("response", "response");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }
}
