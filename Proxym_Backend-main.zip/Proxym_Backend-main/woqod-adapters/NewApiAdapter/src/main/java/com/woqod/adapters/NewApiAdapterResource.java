/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Api(value = "Generic API")
@Path("/")
public class NewApiAdapterResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @GET
    @Path("/petrol/prices")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getPetrolPrices() {

        Operation operation = ApiConfig.operations.get("/petrol/prices");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method,
                RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Path("/logout")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject logout(@ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {

        Operation operation = ApiConfig.operations.get("/logout");
        //    System.out.println("xxxxxxxxxxx:" + operation.url);
        JSONObject queryParams = new JSONObject();
        queryParams.put("deviceId", deviceId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method,
                RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/updateWoqodeUser")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject updateWoqodeUser(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                       @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                       @ApiParam(value = "isWoqode", required = true) @FormParam("isWoqode") Boolean isWoqode) {

        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        if (qid.equals(userQid)) {
            Operation operation = ApiConfig.operations.get("/updateWoqodeUser");
            JSONObject queryParams = new JSONObject();
            queryParams.put("qid", qid);
            queryParams.put("mobile", mobile);
            queryParams.put("isWoqode", isWoqode);
            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method,
                    RequestGenerator.generateHeader(), null, queryParams, null);
        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }

    @GET
    @Path("/getStaticText")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getTextByType(@ApiParam(value = "type", required = true) @QueryParam("type") String type) {

        Operation operation = ApiConfig.operations.get("/getTextByType");
        JSONObject queryParams = new JSONObject();
        queryParams.put("type", type);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
//
//    @POST
//    @Path("/logout")
//    @Produces(MediaType.APPLICATION_JSON)
//    //@OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
//    public JSONObject logout(@ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId) {
//
//        Operation operation = ApiConfig.operations.get("logout");
//        JSONObject queryParams = new JSONObject();
//        System.out.println("xxxxxxxxxxx :" + operation.url);
//        queryParams.put("deviceId", deviceId);
//
//        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
//    }

    @POST
    @Path("/stations")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getStationsByCategory(@ApiParam(value = "category", required = false) @FormParam("category") String category) {

        Operation operation = ApiConfig.operations.get("/stations");

        JSONObject queryParams = new JSONObject();
        if (category != null && !category.equals("")) {
            queryParams.put("category", category);
        }

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    @POST
    @Path("/news")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject news(@ApiParam(value = "size") @FormParam("size") String size,
                           @ApiParam(value = "page") @FormParam("page") String page) {
        Operation operation = ApiConfig.operations.get("/news");
        JSONObject queryParams = new JSONObject();
        queryParams.put("size", size);
        queryParams.put("page", page);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    @POST
    @Path("/transactionLog/receipt")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject transactionLogReceipt(@ApiParam(value = "reference_number") @FormParam("reference_number") String reference_number) {
        Operation operation = ApiConfig.operations.get("/transactionLog/receipt");
        JSONObject queryParams = new JSONObject();
        queryParams.put("reference_number", reference_number);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/transactionLog/sendMail")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject sendMail(@ApiParam(value = "reference_number") @FormParam("reference_number") String referencenumber,
                               @ApiParam(value = "connected") @FormParam("connected") boolean connected,
                               @ApiParam(value = "email") @FormParam("email") String email) {
        Operation operation = ApiConfig.operations.get("/transactionLog/sendMail");
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("referencenumber", referencenumber);
        bodyParams.put("connected", connected);
        bodyParams.put("email", email);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/news/view")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject view(@ApiParam(value = "id") @FormParam("id") String id) {

        Operation operation = ApiConfig.operations.get("/news/views/{id}");
        JSONObject urlParams = new JSONObject();
        urlParams.put("id", id);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), urlParams, null, null);
    }


    @GET
    @Path("/supermarket")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getSuperMarket() {

        Operation operation = ApiConfig.operations.get("/supermarket");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/retailers")
    @Produces(MediaType.APPLICATION_JSON + "; charset=UTF-8")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject retailers() {

        Operation operation = ApiConfig.operations.get("/retailers");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/fahesStations")
    @Produces(MediaType.APPLICATION_JSON + "; charset=UTF-8")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject fahesStation() {

        Operation operation = ApiConfig.operations.get("/fahesStations");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/fahes")
    @Produces(MediaType.APPLICATION_JSON + "; charset=UTF-8")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject fahes() {

        Operation operation = ApiConfig.operations.get("/fahesStations");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/promotions")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject promotions() {

        Operation operation = ApiConfig.operations.get("/promotions");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }


    @GET
    @Path("/contractors")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject contractors() {

        Operation operation = ApiConfig.operations.get("/contractors");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/appointments")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject appointments() {

        Operation operation = ApiConfig.operations.get("/appointments");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/events")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject events() {

        Operation operation = ApiConfig.operations.get("/events");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/agenda")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject agenda() {

        Operation operation = ApiConfig.operations.get("/agenda");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }


    @POST
    @Path("/signature")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject signature(@ApiParam(value = "params", required = true) @FormParam("params") String params, @ApiParam(value = "sourceType") @FormParam("sourceType") String sourceType) throws InvalidKeyException, NoSuchAlgorithmException, NullPointerException, IOException {

        //   System.out.println("tessssssssssssssssst param " + params);

        JSONObject result = new JSONObject();
        if (sourceType == null || sourceType == "")
            sourceType = "TOPUP";
        String sign = CommonUtils.signn(params, sourceType);

        result.put("signature", sign);

        result.put("isSuccessful", true);

        //    System.out.println("signature isSuccessful");
        return result;

    }

    @POST
    @Path("/signature2")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject signature2(@ApiParam(value = "params", required = true) @FormParam("params") String params,
                                 @ApiParam(value = "secretKey", required = true) @FormParam("secretKey") String SECRET_KEY) throws InvalidKeyException, NoSuchAlgorithmException, NullPointerException, IOException {
        JSONObject result = new JSONObject();

        String sign = CommonUtils.sign(params, SECRET_KEY);

        result.put("signature", sign);

        result.put("isSuccessful", true);

        System.out.println("signature isSuccessful");
        return result;

    }

    @GET
    @Path("/date")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject date() {
        JSONObject result = new JSONObject();
        JSONObject header = new JSONObject();
        header.put("statusCode", "000");

        result.put("header", header);
        result.put("body", CommonUtils.getCurrentDateFormats());
        result.put("isSuccessful", true);

        return result;
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/createTransactionUUID")
    @OAuthSecurity(enabled = false)
    public JSONObject createTransactionUUID(
            @ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
            @ApiParam(value = "qid", required = false) @FormParam("qid") String qid,
            @ApiParam(value = "mobile", required = false) @FormParam("mobile") String mobile,
            @ApiParam(value = "transactionUUID", required = false) @FormParam("transactionUUID") String transactionUUID,
            @ApiParam(value = "reference_number", required = true) @FormParam("reference_number") String referenceNumber,
            @ApiParam(value = "amount", required = false) @FormParam("amount") String amount,
            @ApiParam(value = "currency", required = false) @FormParam("currency") String currency,
            @ApiParam(value = "email", required = false) @FormParam("email") String email,
            @ApiParam(value = "transactionStatus", required = false) @FormParam("transactionStatus") String transactionStatus) {

        Operation operation = ApiConfig.operations.get("/createTransactionUUID");


         if(qid != null && !qid.isEmpty() && mobile != null && !mobile.isEmpty()){
             JSONObject bodyParams = new JSONObject();
             bodyParams.put("userID", userID);
             bodyParams.put("qid", qid);
             bodyParams.put("mobile", mobile);
             bodyParams.put("transactionUUID", transactionUUID);
             bodyParams.put("referenceNumber", referenceNumber);
             bodyParams.put("amount", Double.parseDouble(amount));
             bodyParams.put("currency", currency);
             bodyParams.put("email", email);
             bodyParams.put("transactionStatus", transactionStatus);

             System.out.println("createTransactionUUID ::::::::::: ");
             System.out.println(transactionUUID);
             System.out.println(referenceNumber);
             System.out.println(qid);
             System.out.println(mobile);
             System.out.println(userID);
             System.out.println(amount);

             return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);


         }else{

             JSONObject result = new JSONObject();
             JSONObject header = new JSONObject();
             header.put("statusCode", "100");
             header.put("providerCode", "2");
             header.put("titleEN", "QID or mobile number is not correct please try again");
             header.put("titleAR", "الرقم الشخصي أو رقم الهاتف المحمول غير صحيح ، يرجى المحاولة مرة أخرى");
             header.put("providerDescription", "Woqod API");

             result.put("header", header);
             result.put("body", null);
              result.put("isSuccessful", false);


             return result;

         }
        }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/qpay/createTransaction")
    @OAuthSecurity(enabled = false)
    public JSONObject createWoqodeQpayTransaction(
            @ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
            @ApiParam(value = "qid", required = false) @FormParam("qid") String qid,
            @ApiParam(value = "mobile", required = false) @FormParam("mobile") String mobile,
            @ApiParam(value = "pun", required = false) @FormParam("pun") String pun,
            @ApiParam(value = "reference_number", required = true) @FormParam("reference_number") String referenceNumber,
            @ApiParam(value = "amount", required = false) @FormParam("amount") String amount,
            @ApiParam(value = "currency", required = false) @FormParam("currency") String currency,
            @ApiParam(value = "email", required = false) @FormParam("email") String email,
            @ApiParam(value = "transactionStatus", required = false) @FormParam("transactionStatus") String transactionStatus) {

        Operation operation = ApiConfig.operations.get("/qpay/createTransaction");


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("pun", pun);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("amount", Double.parseDouble(amount));
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("transactionStatus", transactionStatus);

        System.out.println("create Woqode Qpay Transaction ::::::::::: ");
        System.out.println(pun);
        System.out.println(referenceNumber);
        System.out.println(userID);
        System.out.println(amount);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getMaxMin")
    @OAuthSecurity(enabled = false)
    public JSONObject getMaxMin() {

        Operation operation = ApiConfig.operations.get("/getMaxMin");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/updateTransactionUUID")
    @OAuthSecurity(enabled = false)
    public JSONObject updateTransactionUUID(
            @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
            @ApiParam(value = "statusEnum", required = false) @FormParam("statusEnum") String statusEnum) {

        Operation operation = ApiConfig.operations.get("/updateTransactionUUID");


        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        queryParams.put("statusEnum", statusEnum);
        queryParams.put("transactionID", "");
        queryParams.put("authReversal", "");
        queryParams.put("RPSStatus", "");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @GET
    @Path("/stockPrices")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject stockPrices() {

        Operation operation = ApiConfig.operations.get("/stockPrices");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/stockPrices/getLastStockPrices")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getLastStockPrices() {

        Operation operation = ApiConfig.operations.get("/stockPrices/getLastStockPrices");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Path("/hasNotif")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject hasNotif(@ApiParam(value = "device") @FormParam(value = "device") String device,
                               @ApiParam(value = "connected") @FormParam(value = "connected") Boolean connected) {

        Operation operation = ApiConfig.operations.get("/hasNotif");
        JSONObject queryParams = new JSONObject();
        queryParams.put("deviceid", device);
        queryParams.put("connected", connected);

        System.out.println(device);
        System.out.println(connected);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    @GET
    @Path("/area")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getAreas() {

        Operation operation = ApiConfig.operations.get("/area");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Path("/getSignatureParam")
    @Produces(MediaType.APPLICATION_JSON)
//    @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject getSignatureParam(@ApiParam(value = "name") @FormParam(value = "name") String name) {
        Operation operation = ApiConfig.operations.get("/getSignatureParam");
        JSONObject queryParams = new JSONObject();
        queryParams.put("name", name);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/getQpaySignatureParam")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject getQpaySignatureParam(@ApiParam(value = "name") @FormParam(value = "name") String name,
                                            @ApiParam(value = "action", required = true) @FormParam("action") String Action,
                                            @ApiParam(value = "amount", required = true) @FormParam("amount") String Amount,
                                            @ApiParam(value = "lang", required = false) @FormParam("lang") String Lang,
                                            @ApiParam(value = "merchantModuleSessionID", required = true) @FormParam("merchantModuleSessionID") String MerchantModuleSessionID,
                                            @ApiParam(value = "pun", required = true) @FormParam("pun") String PUN,
                                            @ApiParam(value = "quantity", required = true) @FormParam("quantity") String Quantity,
                                            @ApiParam(value = "transactionRequestDate", required = true) @FormParam("transactionRequestDate") String TransactionRequestDate) {
        Operation operation = ApiConfig.operations.get("/getQpaySignatureParam");
        JSONObject queryParams = new JSONObject();
        queryParams.put("name", name);
        queryParams.put("action", Action);
        queryParams.put("amount", Amount);
        queryParams.put("lang", Lang);
        queryParams.put("merchantModuleSessionID", MerchantModuleSessionID);
        queryParams.put("pun", PUN);
        queryParams.put("quantity", Quantity);
        queryParams.put("transactionRequestDate", TransactionRequestDate);
        System.out.println("getQpaySignatureParam"+queryParams);
        JSONObject result= CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
        System.out.println("getQpaySignatureParam result"+result);
        return result;
    }

    /**
     * @return Boolean to show or hide QPay(Debit card) Payment feature in mobile app side
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("isDebitCardPaymentHidden")
    @OAuthSecurity(enabled = false)
    public JSONObject isReservationHidden() {
        Operation operation = ApiConfig.operations.get("/isDebitCardPaymentHidden");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }
}




