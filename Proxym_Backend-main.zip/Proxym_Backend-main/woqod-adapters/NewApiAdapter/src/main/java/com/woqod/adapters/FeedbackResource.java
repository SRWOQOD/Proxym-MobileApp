/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Feedback API")
@Path("/feedback")
public class FeedbackResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(FeedbackResource.class.getName());
    @Context
    HttpServletRequest servletRequest;

    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    @Context
    AdapterSecurityContext securityContext;

    @ApiOperation(value = "Get all feedbacks", notes = "Get all feedbacks")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of feedbacks OK")})
    @GET
    @Path("/allFeedbacks")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject allFeedbacks() {
        Operation operation = ApiConfig.operations.get("/feedbacks/all");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @ApiOperation(value = "Get filtred feedbacks", notes = "Get all feedbacks")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of feedbacks OK")})
    @POST
    @Path("/feedbacks")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject filtredFeedbacks(@ApiParam(value = "username") @FormParam("username") String username) {

        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userName = String.valueOf(currentUser.getAttributes().get("username"));

        if (userName.equalsIgnoreCase(username)) {
            System.out.println("username: " + username);
            Operation operation = ApiConfig.operations.get("/feedbacks");

            JSONObject queryParams = new JSONObject();
            queryParams.put("username", username);
            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }

    @ApiOperation(value = "Get lazy loaded feedbacks by username", notes = "Get all feedbacks without images ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of feedbacks without images OK")})
    @POST
    @Path("/lazyFeedbackHistory")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject lazyFeedbackHistory(@ApiParam(value = "username") @FormParam("username") String username) {

        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userName = String.valueOf(currentUser.getAttributes().get("username"));

        if (userName.equalsIgnoreCase(username)) {
            System.out.println("username: " + username);
            Operation operation = ApiConfig.operations.get("/lazyFeedbackHistory");

            JSONObject queryParams = new JSONObject();
            queryParams.put("username", username);
            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }

    @ApiOperation(value = "Add new feedback", notes = "Add new feedback")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Add operation OK")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/newFeedback")
    @OAuthSecurity(enabled = false)
    public JSONObject newFeedback(
            @ApiParam(value = "connected", required = true) @FormParam("connected") String connected,
            @ApiParam(value = "contactNumber", required = false) @FormParam("contactNumber") String contactNumber,
            @ApiParam(value = "name", required = false) @FormParam("name") String name,
            @ApiParam(value = "email", required = false) @FormParam("email") String email,
            @ApiParam(value = "username", required = false) @FormParam("username") String userName,
            @ApiParam(value = "category", required = true) @FormParam("category") String category,
            @ApiParam(value = "sector", required = true) @FormParam("sector") String sector,
            @ApiParam(value = "language", required = true) @FormParam("language") String language,
            @ApiParam(value = "creationDate", required = true) @FormParam("creationDate") String creationDate,
            @ApiParam(value = "content", required = true) @FormParam("content") String content,
            @ApiParam(value = "file", required = false) @FormParam("file") String file) {

        Operation operation = ApiConfig.operations.get("/feedbacks/new");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("connected", connected);
        bodyParams.put("contactNumber", contactNumber);
        bodyParams.put("name", name);
        bodyParams.put("email", email);
        bodyParams.put("userName", userName);
        bodyParams.put("category", category);
        bodyParams.put("sector", sector);
        bodyParams.put("content", content);
        bodyParams.put("file", file);
        bodyParams.put("creationDate", creationDate);
        bodyParams.put("language", language);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @ApiOperation(value = "Edit feedback", notes = "Edit feedback")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Edit operation OK")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/editFeedback")
    @OAuthSecurity(enabled = false)
    public JSONObject editFeedback(
            @ApiParam(value = "id", required = true) @FormParam("id") String id,
            @ApiParam(value = "connected", required = true) @FormParam("connected") String connected,
            @ApiParam(value = "contactNumber", required = false) @FormParam("contactNumber") String contactNumber,
            @ApiParam(value = "name", required = false) @FormParam("name") String name,
            @ApiParam(value = "userName", required = false) @FormParam("userName") String userName,
            @ApiParam(value = "category", required = true) @FormParam("category") String category,
            @ApiParam(value = "sector", required = true) @FormParam("sector") String sector,
            @ApiParam(value = "content", required = true) @FormParam("content") String content,
            @ApiParam(value = "file", required = false) @FormParam("file") String file) {

        Operation operation = ApiConfig.operations.get("/feedbacks/edit");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("id", id);
        bodyParams.put("connected", connected);
        bodyParams.put("contactNumber", contactNumber);
        bodyParams.put("name", name);
        bodyParams.put("userName", userName);
        bodyParams.put("category", category);
        bodyParams.put("sector", sector);
        bodyParams.put("content", content);
        bodyParams.put("file", file);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }


    @ApiOperation(value = "Add Rating", notes = "Add Rating")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Rate submitted")})
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/addRating")
    @OAuthSecurity(enabled = false)
    public JSONObject addRating(
            @ApiParam(value = "stationId", required = true) @FormParam("stationId") String stationId,
            @ApiParam(value = "deviceId", required = true) @FormParam("deviceId") String deviceId,
            @ApiParam(value = "rating", required = true) @FormParam("rating") String rating) {
        Operation operation = ApiConfig.operations.get("/ratings");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("stationId", stationId);
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("rating", rating);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }

    @POST
    @Path("/getFeedbackById")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject getFeedbackbyid(@ApiParam(value = "id") @FormParam("id") String id) {
        Operation operation = ApiConfig.operations.get("/feedbacks/getFeedbackById");

        JSONObject queryParams = new JSONObject();
        queryParams.put("id", id);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }
}
