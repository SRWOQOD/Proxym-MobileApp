package com.woqod.adapters.enums;

public enum Platform {
    MOB,
    WEB;
}
