package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Car API")
@Path("/")
public class CarResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(NewApiAdapterResource.class.getName());
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("updateFuelStatus")
    //@OAuthSecurity(enabled = false)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject updateFuelStatus(
            @ApiParam(value = "id", required = true) @FormParam("id") String id,
            @ApiParam(value = "status", required = true) @FormParam("status") String status) {

        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        Operation operation = ApiConfig.operations.get("/car/updateFuelStatus");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("id", id);
        bodyParams.put("qid", userQid);
        bodyParams.put("status", status);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, bodyParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("updateCarFuelLimit")
    //@OAuthSecurity(enabled = false)
    @OAuthSecurity(scope = "UserLogin")
    public JSONObject updateCarFuelLimit(
            @ApiParam(value = "id", required = true) @FormParam("id") String id,
            @ApiParam(value = "fuel", required = true) @FormParam("fuel") String fuel) {

        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        Operation operation = ApiConfig.operations.get("/car/updateCarFuelLimit");

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("id", id);
        bodyParams.put("qid", userQid);
        bodyParams.put("fuel", fuel);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, bodyParams, null);
    }
}
