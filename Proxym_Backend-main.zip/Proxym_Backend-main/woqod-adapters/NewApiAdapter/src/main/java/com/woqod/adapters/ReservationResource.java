package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Api(value = "Reservation API")
@Path("/reservation")
public class ReservationResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getPlateTypeWithShape")
    @OAuthSecurity(enabled = false)
    public JSONObject getPlateTypeWithShape() {
        Operation operation = ApiConfig.operations.get("reservation/getPlateTypeWithShape");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getPreReservationReference")
    @OAuthSecurity(enabled = false)
    public JSONObject getPreReservationReference(@ApiParam(value = "mobileNumber") @FormParam("mobileNumber") String mobileNumber,
                                                 @ApiParam(value = "plateNumber") @FormParam("plateNumber") String plateNumber,
                                                 @ApiParam(value = "plateTypeId") @FormParam("plateTypeId") String plateTypeId,
                                                 @ApiParam(value = "vehicleShapeId") @FormParam("vehicleShapeId") String vehicleShapeId,
                                                 @ApiParam(value = "customerId") @FormParam("customerId") String customerId,
                                                 @ApiParam(value = "otpRetriesLeftCount") @FormParam("otpRetriesLeftCount") String otpRetriesLeftCount,
                                                 @ApiParam(value = "preReservationReferenceId") @FormParam("preReservationReferenceId") Long preReservationReferenceId) {
        Operation operation = ApiConfig.operations.get("reservation/getPreReservationReference");

        JSONObject bodyParam = new JSONObject();
        bodyParam.put("mobileNumber", mobileNumber);
        bodyParam.put("plateNumber", plateNumber);
        bodyParam.put("plateTypeId", plateTypeId);
        bodyParam.put("vehicleShapeId", vehicleShapeId);
        bodyParam.put("customerId", customerId);
        bodyParam.put("otpRetriesLeftCount", otpRetriesLeftCount);
        bodyParam.put("preReservationReferenceId", preReservationReferenceId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, null, bodyParam);

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("otpValidation")
    @OAuthSecurity(enabled = false)
    public JSONObject otpValidation(@ApiParam(value = "preReservationReferenceId", required = true) @FormParam("preReservationReferenceId") String preReservationReferenceId,
                                    @ApiParam(value = "otp", required = true) @FormParam("otp") String otp) {
        Operation operation = ApiConfig.operations.get("reservation/otpValidation");
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        queryParams.put("otp", otp);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("resendOtp")
    @OAuthSecurity(enabled = false)
    public JSONObject resendOtp(@ApiParam(value = "preReservationReferenceId", required = true) @FormParam("preReservationReferenceId") String preReservationReferenceId) {
        Operation operation = ApiConfig.operations.get("reservation/resendOtp");
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getAvailableStations")
    @OAuthSecurity(enabled = false)
    public JSONObject getAvailableStations(@ApiParam(value = "preReservationReferenceId") @FormParam("preReservationReferenceId") String preReservationReferenceId) {
        Operation operation = ApiConfig.operations.get("reservation/getAvailableStations");

        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getDetails")
    @OAuthSecurity(enabled = false)
    public JSONObject getDetails(@ApiParam(value = "mobileNumber") @FormParam("mobileNumber") String mobileNumber,
                                 @ApiParam(value = "plateNumber") @FormParam("plateNumber") String plateNumber,
                                 @ApiParam(value = "plateTypeId") @FormParam("plateTypeId") String plateTypeId,
                                 @ApiParam(value = "vehicleShapeId") @FormParam("vehicleShapeId") String vehicleShapeId,
                                 @ApiParam(value = "customerId") @FormParam("customerId") String customerId,
                                 @ApiParam(value = "otpRetriesLeftCount") @FormParam("otpRetriesLeftCount") String otpRetriesLeftCount,
                                 @ApiParam(value = "preReservationReferenceId") @FormParam("preReservationReferenceId") Long preReservationReferenceId) {
        Operation operation = ApiConfig.operations.get("reservation/getDetails");
        System.out.println(mobileNumber);
        JSONObject bodyParam = new JSONObject();
        bodyParam.put("mobileNumber", mobileNumber);
        bodyParam.put("plateNumber", plateNumber);
        bodyParam.put("plateTypeId", plateTypeId);
        bodyParam.put("vehicleShapeId", vehicleShapeId);
        bodyParam.put("customerId", customerId);
        bodyParam.put("otpRetriesLeftCount", otpRetriesLeftCount);
        bodyParam.put("preReservationReferenceId", preReservationReferenceId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, null, bodyParam);

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("reservation")
    @OAuthSecurity(enabled = false)
    public JSONObject reservation(@ApiParam(value = "preReservationReferenceId", required = true) @FormParam("preReservationReferenceId") String preReservationReferenceId,
                                  @ApiParam(value = "slotId", required = true) @FormParam("slotId") String slotId,
                                  @ApiParam(value = "userType", required = true) @FormParam("userType") String userType,
                                  @ApiParam(value = "vehiculeShapeName", required = true) @FormParam("vehiculeShapeName") String vehiculeShapeName) {
        Operation operation = ApiConfig.operations.get("reservation/reservation");
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        queryParams.put("slotId", slotId);
        queryParams.put("userType", userType);
        queryParams.put("vehiculeShapeName", vehiculeShapeName);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("cancellation")
    @OAuthSecurity(enabled = false)
    public JSONObject cancellation(@ApiParam(value = "reservationId", required = true) @FormParam("reservationId") String reservationId) {
        Operation operation = ApiConfig.operations.get("reservation/cancellation");
        JSONObject queryParams = new JSONObject();
        queryParams.put("reservationId", reservationId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getAppointmentDates")
    @OAuthSecurity(enabled = false)
    public JSONObject getAppointmentDates(@ApiParam(value = "preReservationReferenceId") @FormParam(value = "preReservationReferenceId") String preReservationReferenceId,
                                          @ApiParam(value = "stationId") @FormParam(value = "stationId") String stationId) {
        Operation operation = ApiConfig.operations.get("reservation/getAppointmentDates");
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        queryParams.put("stationId", stationId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getSlots")
    @OAuthSecurity(enabled = false)
    public JSONObject getSlots(@ApiParam(value = "preReservationReferenceId") @FormParam(value = "preReservationReferenceId") String preReservationReferenceId,
                               @ApiParam(value = "stationId") @FormParam(value = "stationId") String stationId,
                               @ApiParam(value = "date") @FormParam(value = "date") String date) {
        Operation operation = ApiConfig.operations.get("reservation/getSlots");
        System.out.println(preReservationReferenceId + date + stationId + operation.url);
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        queryParams.put("stationId", stationId);
        queryParams.put("date", date);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);

    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("isReservationHidden")
    @OAuthSecurity(enabled = false)
    public JSONObject isReservationHidden() {
        Operation operation = ApiConfig.operations.get("reservation/isReservationHidden");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("availableByCustomer")
    @OAuthSecurity(enabled = false)
    public JSONObject isReservationAvailable(@ApiParam(value = "customerId") @FormParam(value = "customerId") String customerId) {
        Operation operation = ApiConfig.operations.get("reservation/availableByCustomer");
        JSONObject queryParams = new JSONObject();
        queryParams.put("customerId", customerId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("detailsByCustomer")
    @OAuthSecurity(enabled = false)
    public JSONObject detailsByCustomer(@ApiParam(value = "customerId") @FormParam(value = "customerId") String customerId) {
        Operation operation = ApiConfig.operations.get("reservation/getDetailsByCustomer");
        JSONObject queryParams = new JSONObject();
        queryParams.put("customerId", customerId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("rescheduling")
    @OAuthSecurity(enabled = false)
    public JSONObject rescheduling(@ApiParam(value = "reservationId") @FormParam(value = "reservationId") String reservationId) {
        Operation operation = ApiConfig.operations.get("reservation/rescheduling");
        JSONObject queryParams = new JSONObject();
        queryParams.put("reservationId", reservationId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("canPayOnline")
    @OAuthSecurity(enabled = false)
    public JSONObject canPayOnline(@ApiParam(value = "preReservationReferenceId") @FormParam(value = "preReservationReferenceId") String preReservationReferenceId,
                                   @ApiParam(value = "slotId") @FormParam(value = "slotId") String slotId) {
        Operation operation = ApiConfig.operations.get("reservation/canPayOnline");
        JSONObject queryParams = new JSONObject();
        queryParams.put("preReservationReferenceId", preReservationReferenceId);
        queryParams.put("slotId", slotId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("vehiculeDetails")
    @OAuthSecurity(enabled = false)
    public JSONObject vehiculeDetails(@ApiParam(value = "customerId") @FormParam("customerId") String customerId,
                                      @ApiParam(value = "plateNumber") @FormParam("plateNumber") String plateNumber,
                                      @ApiParam(value = "plateTypeId") @FormParam("plateTypeId") String plateTypeId) {
        Operation operation = ApiConfig.operations.get("reservation/vehiculeDetails");
        JSONObject queryParams = new JSONObject();
        queryParams.put("customerId", customerId);
        queryParams.put("plateNumber", plateNumber);
        queryParams.put("plateTypeId", plateTypeId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("vehiculeRegistrationValidity")
    @OAuthSecurity(enabled = false)
    public JSONObject vehiculeRegistrationValidity(@ApiParam(value = "customerId") @FormParam("customerId") String customerId,
                                      @ApiParam(value = "plateNumber") @FormParam("plateNumber") String plateNumber,
                                      @ApiParam(value = "plateTypeId") @FormParam("plateTypeId") String plateTypeId) {
        Operation operation = ApiConfig.operations.get("reservation/vehiculeRegistrationValidity");
        JSONObject queryParams = new JSONObject();
        queryParams.put("customerId", customerId);
        queryParams.put("plateNumber", plateNumber);
        queryParams.put("plateTypeId", plateTypeId);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(),
                null, queryParams, null);
    }
}
