/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Fahes API")
@Path("/fahes")
public class FahesResource {

    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */


    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(FahesResource.class.getName());

    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    @Context
    AdapterSecurityContext securityContext;


    @GET
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON + "; charset=UTF-8")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject fahes() {

        Operation operation = ApiConfig.operations.get("/fahesStations");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    // List Of cars

    @ApiOperation(value = "Get List of cars ", notes = "Get all cars")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of cars  OK")})
    @POST
    @Path("/listCars")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject newInspection() {
        AuthenticatedUser currentUser = getCurrentUser();

        Operation operation = ApiConfig.operations.get("/fahes/listCars");

        JSONObject queryParams = new JSONObject();
        queryParams.put("qid", currentUser.getAttributes().get("qid"));

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @ApiOperation(value = "Get List of pre registration by qid ", notes = "Get List")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Get List  OK")})
    @POST
    @Path("/preRegistration/findByQid")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
   // @OAuthSecurity(enabled = false)
    public JSONObject listofPreRegistrationByQid(@ApiParam(value = "qid") @FormParam(value = "qid") String qid) {
        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        if (qid.equals(userQid)) {
            Operation operation = ApiConfig.operations.get("/fahes/preRegistration/findByQid");

            JSONObject queryParams = new JSONObject();
            queryParams.put("qid", qid);

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }


    // List of Platetypes

    @ApiOperation(value = "Get List of platetypes ", notes = "Get all platetypes")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of platetypes  OK")})
    @GET
    @Path("/platetypes")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject PlateTypes() {
        Operation operation = ApiConfig.operations.get("/fahes/platetypes");
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }


    // Find Car bY plateNumber and type

    @ApiOperation(value = "Get Details Car Inspection  ", notes = "Get Details Car Inspection")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Details Car Inspection  OK")})
    @POST
    @Path("/checkCar")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier4
    public JSONObject checkCar(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                               @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plateNumber,
                               @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plateType) {

        Operation operation = ApiConfig.operations.get("/fahes/checkCar");

        JSONObject queryParams = new JSONObject();

        queryParams.put("qid", qid);
        queryParams.put("plate_number", plateNumber);
        queryParams.put("plate_type_id", plateType);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
    // Find Car bY plateNumber and type if owner

    @ApiOperation(value = "Get Details Car Inspection Owner ", notes = "Get Details Car Inspection Owner")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Details Car Inspection Owner OK")})
    @POST
    @Path("/isOwner")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier4
    public JSONObject CarInspectionIsOwner(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                           @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plateNumber,
                                           @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plateType) {

        Operation operation = ApiConfig.operations.get("/fahes/isOwner");

        JSONObject queryParams = new JSONObject();

        queryParams.put("qid", qid);
        queryParams.put("plate_number", plateNumber);
        queryParams.put("plate_type_id", plateType);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @ApiOperation(value = "Get Details Car Inspection Owner ", notes = "Get Details Car Inspection Owner")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Details Car Inspection Owner OK")})
    @POST
    @Path("/isOwnerAddCar")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject isOwnerAddCar(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                    @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plateNumber,
                                    @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plateType) {


        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();

        if (currentUser.getAttributes().get("qid").equals(qid)) {
            Operation operation = ApiConfig.operations.get("/fahes/isOwnerAddCar");

            JSONObject queryParams = new JSONObject();

            queryParams.put("qid", qid);
            queryParams.put("plate_number", plateNumber);
            queryParams.put("plate_type_id", plateType);

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
        } else {
            JSONObject jsonObject = new JSONObject();
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);
            return jsonObject;

        }
    }


    // OTP Before register Car

    @ApiOperation(value = "Send pin SMS ", notes = "Send pin SMS")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Send PIN  OK")})
    @POST
    @Path("/sendPin")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier4
    public JSONObject SendPin(@ApiParam(value = "username", required = true) @FormParam("username") String
                                      username,
                              @ApiParam(value = "language", required = true) @FormParam("language") String language) {

        Operation operation = ApiConfig.operations.get("/fahes/sendPin");

        JSONObject queryParams = new JSONObject();

        queryParams.put("username", username);
        queryParams.put("language", language);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    // register Car

    @ApiOperation(value = "add Car ", notes = "Add Car ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " register car OK")})
    @POST
    @Path("/addCar")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject addCar(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                             @ApiParam(value = "pincode", required = true) @FormParam("pincode") String pincode,
                             @ApiParam(value = "vin", required = true) @FormParam("vin") String vin,
                             @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                             @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plate_type_id,
                             @ApiParam(value = "plate_type_name_en", required = true) @FormParam("plate_type_name_en") String
                                     plate_type_name_en,
                             @ApiParam(value = "plate_type_name_ar", required = true) @FormParam("plate_type_name_ar") String
                                     plate_type_name_ar,
                             @ApiParam(value = "manufacture_id", required = true) @FormParam("manufacture_id") String manufacture_id,
                             @ApiParam(value = "manufacture_name_en", required = true) @FormParam("manufacture_name_en") String
                                     manufacture_name_en,
                             @ApiParam(value = "manufacture_name_ar", required = true) @FormParam("manufacture_name_ar") String
                                     manufacture_name_ar,
                             @ApiParam(value = "model_id", required = true) @FormParam("model_id") String model_id,
                             @ApiParam(value = "model_name_en", required = true) @FormParam("model_name_en") String model_name_en,
                             @ApiParam(value = "model_name_ar", required = true) @FormParam("model_name_ar") String model_name_ar,
                             @ApiParam(value = "colour_id", required = true) @FormParam("colour_id") String colour_id,
                             @ApiParam(value = "colour_name_en", required = true) @FormParam("colour_name_en") String colour_name_en,
                             @ApiParam(value = "colour_name_ar", required = true) @FormParam("colour_name_ar") String colour_name_ar,
                             @ApiParam(value = "registration_expires_on", required = true) @FormParam("registration_expires_on") String
                                     registration_expires_on,
                             @ApiParam(value = "year", required = true) @FormParam("year") String year
    ) {

        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        if (qid.equals(userQid)) {
            Operation operation = ApiConfig.operations.get("/fahes/addCar");

            JSONObject plate_type = new JSONObject();
            plate_type.put("id", plate_type_id);
            plate_type.put("name_en", plate_type_name_en);
            plate_type.put("name_ar", plate_type_name_ar);

            JSONObject manufacturer = new JSONObject();
            manufacturer.put("id", manufacture_id);
            manufacturer.put("name_en", manufacture_name_en);
            manufacturer.put("name_ar", manufacture_name_ar);

            JSONObject model = new JSONObject();
            model.put("id", model_id);
            model.put("name_en", model_name_en);
            model.put("name_ar", model_name_ar);

            JSONObject colour = new JSONObject();
            colour.put("id", colour_id);
            colour.put("name_en", colour_name_en);
            colour.put("name_ar", colour_name_ar);

            JSONObject bodyParams = new JSONObject();

            bodyParams.put("vin", vin);
            bodyParams.put("plate_number", plate_number);
            bodyParams.put("plate_type", plate_type);
            bodyParams.put("manufacturer", manufacturer);
            bodyParams.put("model", model);
            bodyParams.put("colour", colour);
            bodyParams.put("registration_expires_on", registration_expires_on);
            bodyParams.put("year", year);
            bodyParams.put("active", true);

            JSONObject queryParams = new JSONObject();
            queryParams.put("qid", qid);
            queryParams.put("pincode", pincode);

            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }


// transaction inspection credit Card

    @ApiOperation(value = "Add new pre registration  transaction ", notes = "Add new pre registration transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Add operation  OK")})
    @POST
    @Path("/prtransactionlog/creditcard/save")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject savePreRegistrationByCC
            (@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
             @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
             @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
             @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String
                     transactionUUID,
             @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String
                     referenceNumber,
             @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
             @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
             @ApiParam(value = "email", required = true) @FormParam("email") String email,
             @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String
                     inspection_type,
             @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
             @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
             @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String
                     category_name_en,
             @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String
                     category_name_ar,
             @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
             @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
             @ApiParam(value = "service_category", required = true) @FormParam("service_category") String
                     service_category,
             @ApiParam(value = "anonym", required = true) @FormParam("anonym") String anonym,
             @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type

            ) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/creditcard/save");


        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);
        bodyParams.put("plateType", plate_type);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);
        queryParams.put("anonym", anonym);

        System.out.println(queryParams);
        System.out.println(bodyParams);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

    //detail inspection

    @ApiOperation(value = "Get Detail inspection  ", notes = "Get Detail Inspection")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Detail Inspection  OK")})
    @POST
    @Path("/inspection/detailInspection")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject GetDetailInspection
            (@ApiParam(value = "inspection_id") @FormParam(value = "inspection_id") String inspection_id) {

        Operation operation = ApiConfig.operations.get("/fahes/inspection/detailInspection");

        JSONObject queryParams = new JSONObject();
        queryParams.put("inspection_id", inspection_id);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //preRegistration fee
    @ApiOperation(value = "Get fee inspection  ", notes = "Get fee Inspection")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " fee Inspection  OK")})
    @POST
    @Path("/inspection/fee")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject GetFee(@ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String
                                     plate_number,
                             @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plate_type_id,
                             @ApiParam(value = "qid", required = true) @FormParam("qid") String qid) {

        Operation operation = ApiConfig.operations.get("/fahes/inspection/fee");

        JSONObject queryParams = new JSONObject();

        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type_id", plate_type_id);
        queryParams.put("qid", qid);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }


    //listDetailsHistoryByPlate_number

    @ApiOperation(value = "Get list history inspection by plate  ", notes = "Get list history Inspection by plate")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " list history Inspection  OK")})
    @POST
    @Path("/inspection/historyInspectionsByPlate")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject historyInspectionsByPlate
            (@ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
             @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plate_type_id,
             @ApiParam(value = "owner_id", required = true) @FormParam("owner_id") String owner_id) {

        Operation operation = ApiConfig.operations.get("/fahes/inspection/historyInspectionsByPlate");

        JSONObject queryParams = new JSONObject();

        queryParams.put("plate_number", plate_number);
        queryParams.put("owner_id", owner_id);
        queryParams.put("plate_type_id", plate_type_id);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //update status Car

    @ApiOperation(value = "Update status Car", notes = "Update status Car")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Update operation OK")})
    @POST
    @Path("/updateStatusCar")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
    //@OAuthSecurity(enabled = false)
    public JSONObject UpdateStatusCar
            (@ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number) {

        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String userQid = String.valueOf(currentUser.getAttributes().get("qid"));

        Operation operation = ApiConfig.operations.get("/fahes/updateStatusCar");

        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("qid", userQid);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

//SendMail

    @ApiOperation(value = "Send Mail", notes = "Send Mail")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Send operation OK")})
    // Todo get or post ?
    @POST
    @Path("/preRegistration/sendMail")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject SendMail
            (@ApiParam(value = "reference_number", required = true) @FormParam("reference_number") String reference_number,
             @ApiParam(value = "email", required = true) @FormParam("email") String email,
             @ApiParam(value = "connected", required = true) @FormParam("connected") String connected) {

        Operation operation = ApiConfig.operations.get("/fahes/preRegistration/sendMail");

        System.out.println(email);
        JSONObject queryParams = new JSONObject();
        queryParams.put("referencenumber", reference_number);
        queryParams.put("connected", connected);
        queryParams.put("email", email);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

//  update transaction fahes  (if cancel)

    @ApiOperation(value = "Update PR transaction ", notes = "Update PR transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " update transaction  OK")})
    @POST
    @Path("/prtransactionlog/updateTransactionUUID")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject UpdatePRTransaction
            (@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID,
             @ApiParam(value = "status", required = true) @FormParam("status") String status) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/updateTransactionUUID");

        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        queryParams.put("status", status);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

//  transaction fahes inspection woqode

    @ApiOperation(value = "transaction pr woqode", notes = "transaction pr woqode")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "transaction pr woqode  OK")})
    @POST
    @Path("/prtransactionlog/woqode/save")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject TransactionPRWoqode(@ApiParam(value = "userID", required = true) @FormParam("userID") String
                                                  userID,
                                          @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                          @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                          @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String
                                                  transactionUUID,
                                          @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                          @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                          @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                          @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String
                                                  inspection_type,
                                          @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                          @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
                                          @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String
                                                  category_name_en,
                                          @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String
                                                  category_name_ar,
                                          @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
                                          @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                                          @ApiParam(value = "service_category", required = true) @FormParam("service_category") String
                                                  service_category,
                                          @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String
                                                  referenceNumber,
                                          @ApiParam(value = "plate_type", required = false) @FormParam("plate_type") String plate_type
    ) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/woqode/save");

        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("plateType", plate_type);

        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }


    //  PreRegistration with amount fee null

    @ApiOperation(value = "transaction free", notes = "transaction free")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "transaction free OK")})
    @POST
    @Path("/prtransactionlog/free/save")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject TransactionFree(@ApiParam(value = "userID", required = true) @FormParam("userID") String
                                              userID,
                                      @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                      @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                      @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String
                                              transactionUUID,
                                      @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                      @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                      @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                      @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String
                                              inspection_type,
                                      @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                      @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
                                      @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String
                                              category_name_en,
                                      @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String
                                              category_name_ar,
                                      @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
                                      @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                                      @ApiParam(value = "service_category", required = true) @FormParam("service_category") String
                                              service_category,
                                      @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type,
                                      @ApiParam(value = "anonym", required = true) @FormParam("anonym") String anonym
    ) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/free/save");

        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);
        bodyParams.put("plateType", plate_type);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);
        queryParams.put("anonym", anonym);

        System.out.println("prtransactionlog/free/save queryParams:::" + queryParams);
        System.out.println("prtransactionlog/free/save bodyParams:::" + bodyParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

//discount preRegistration

    @ApiOperation(value = "Discount preRegistration", notes = "Discount preRegistration")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Discount preRegistration  OK")})
    @GET
    @Path("discount/byType")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject DiscountPreRegistration(@QueryParam(value = "fahes_service") String fahes_service,
                                              @QueryParam(value = "payment_method") String payment_method,
                                              @QueryParam(value = "amount") String amount) {
        System.out.println("amount" + amount);
        Operation operation = ApiConfig.operations.get("/fahes/discount/byType");

        JSONObject queryParams = new JSONObject();
        queryParams.put("fahes_service", fahes_service);
        queryParams.put("payment_method", payment_method);
        queryParams.put("amount", amount);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

//  Generate pdfBase64

    @ApiOperation(value = "Generate  E-Receipt", notes = "Generate  E-Receipt")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Generate  E-Receipt  OK")})
    @POST
    @Path("preregistration/generatePDF")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject GeneratePdf
            (@ApiParam(value = "reference_number") @FormParam(value = "reference_number") String reference_number) {

        Operation operation = ApiConfig.operations.get("/fahes/preregistration/generatePDF");

        System.out.println(reference_number);
        JSONObject queryParams = new JSONObject();
        queryParams.put("reference_number", reference_number);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //update Car if we want to deactivate it


    @ApiOperation(value = "update Car ", notes = "update Car ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " update car OK")})
    @POST
    @Path("/updateCar")
    @Produces(MediaType.APPLICATION_JSON)
//    @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject addCar(@ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                             @ApiParam(value = "vin", required = true) @FormParam("vin") String vin,
                             @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                             @ApiParam(value = "plate_type_id", required = true) @FormParam("plate_type_id") String plate_type_id,
                             @ApiParam(value = "plate_type_name_en", required = true) @FormParam("plate_type_name_en") String
                                     plate_type_name_en,
                             @ApiParam(value = "plate_type_name_ar", required = true) @FormParam("plate_type_name_ar") String
                                     plate_type_name_ar,
                             @ApiParam(value = "manufacture_id", required = true) @FormParam("manufacture_id") String manufacture_id,
                             @ApiParam(value = "manufacture_name_en", required = true) @FormParam("manufacture_name_en") String
                                     manufacture_name_en,
                             @ApiParam(value = "manufacture_name_ar", required = true) @FormParam("manufacture_name_ar") String
                                     manufacture_name_ar,
                             @ApiParam(value = "model_id", required = true) @FormParam("model_id") String model_id,
                             @ApiParam(value = "model_name_en", required = true) @FormParam("model_name_en") String model_name_en,
                             @ApiParam(value = "model_name_ar", required = true) @FormParam("model_name_ar") String model_name_ar,
                             @ApiParam(value = "colour_id", required = true) @FormParam("colour_id") String colour_id,
                             @ApiParam(value = "colour_name_en", required = true) @FormParam("colour_name_en") String colour_name_en,
                             @ApiParam(value = "colour_name_ar", required = true) @FormParam("colour_name_ar") String colour_name_ar,
                             @ApiParam(value = "registration_expires_on", required = true) @FormParam("registration_expires_on") String
                                     registration_expires_on,
                             @ApiParam(value = "year", required = true) @FormParam("year") String year
    ) {

        Operation operation = ApiConfig.operations.get("/fahes/updateCar");

        JSONObject plate_type = new JSONObject();
        plate_type.put("id", plate_type_id);
        plate_type.put("name_en", plate_type_name_en);
        plate_type.put("name_ar", plate_type_name_ar);

        JSONObject manufacturer = new JSONObject();
        manufacturer.put("id", manufacture_id);
        manufacturer.put("name_en", manufacture_name_en);
        manufacturer.put("name_ar", manufacture_name_ar);

        JSONObject model = new JSONObject();
        model.put("id", model_id);
        model.put("name_en", model_name_en);
        model.put("name_ar", model_name_ar);

        JSONObject colour = new JSONObject();
        colour.put("id", colour_id);
        colour.put("name_en", colour_name_en);
        colour.put("name_ar", colour_name_ar);

        JSONObject bodyParams = new JSONObject();
        bodyParams.put("vin", vin);
        bodyParams.put("plate_number", plate_number);
        bodyParams.put("plate_type", plate_type);
        bodyParams.put("manufacturer", manufacturer);
        bodyParams.put("model", model);
        bodyParams.put("colour", colour);
        bodyParams.put("registration_expires_on", registration_expires_on);
        bodyParams.put("year", year);

        JSONObject queryParams = new JSONObject();
        queryParams.put("qid", qid);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

// transaction inspection credit Card for Anonymous

    @ApiOperation(value = "Add new pre registration  transaction Anonymous", notes = "Add new pre registration transaction Anonymous")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Add operation  OK")})
    @POST
    @Path("/prtransactionlog/anonym/creditcard/save")
    @Produces(MediaType.APPLICATION_JSON)
    // @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    // les types à verifier
    public JSONObject savePreRegistration(@ApiParam(value = "userID", required = true) @FormParam("userID") String
                                                  userID,
                                          @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                          @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                          @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String
                                                  transactionUUID,
                                          @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String
                                                  referenceNumber,
                                          @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                          @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                          @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                          @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String
                                                  inspection_type,
                                          @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                          @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
                                          @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String
                                                  category_name_en,
                                          @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String
                                                  category_name_ar,
                                          @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
                                          @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                                          @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type,
                                          @ApiParam(value = "service_category", required = true) @FormParam("service_category") String
                                                  service_category

    ) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/anonym/creditcard/save");


        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);

        System.out.println("queryParams" + queryParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

//SendMail Anonymous

    @ApiOperation(value = "Send Mail Anonymous", notes = "Send Mail Anonymous")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Send operation OK")})
    // Todo get or post ?
    @POST
    @Path("/preRegistration/anonym/sendMail")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject SendMail
            (@ApiParam(value = "reference_number", required = true) @FormParam("reference_number") String reference_number,
             @ApiParam(value = "email", required = true) @FormParam("email") String email
            ) {

        Operation operation = ApiConfig.operations.get("/fahes/preRegistration/anonym/sendMail");

        JSONObject queryParams = new JSONObject();
        queryParams.put("reference_number", reference_number);
        queryParams.put("email", email);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    //  Anonym PreRegistration with amount fee null

    @ApiOperation(value = "transaction free", notes = "transaction free")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "transaction free OK")})
    @POST
    @Path("/prtransactionlog/anonym/free/save")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject AnonymTransactionFree
            (@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
             @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
             @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
             @ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String
                     transactionUUID,
             @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
             @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
             @ApiParam(value = "email", required = true) @FormParam("email") String email,
             @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String
                     inspection_type,
             @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
             @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
             @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String
                     category_name_en,
             @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String
                     category_name_ar,
             @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
             @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
             @ApiParam(value = "service_category", required = true) @FormParam("service_category") String
                     service_category,
             @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type
            ) {

        Operation operation = ApiConfig.operations.get("/fahes/prtransactionlog/anonym/free/save");

        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("transactionUUID", transactionUUID);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);
        System.out.println("/prtransactionlog/anonym/free/save queryParams:::" + queryParams);
        System.out.println("/prtransactionlog/anonym/free/save bodyParams:::" + bodyParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

    // To get the current User
    public AuthenticatedUser getCurrentUser() {
        AuthenticatedUser user = securityContext.getAuthenticatedUser();

        return user;
    }



    @ApiOperation(value = "Add new pre registration  transaction ", notes = "Add new pre registration transaction ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = " Add operation  OK")})
    @POST
    @Path("/qpaytransaction/debitcard/save")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject savePreRegistrationByDC(@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
                                              @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                              @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                              @ApiParam(value = "pun", required = true) @FormParam("pun") String pun,
                                              @ApiParam(value = "referenceNumber", required = true) @FormParam("referenceNumber") String referenceNumber,
                                              @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                              @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                              @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                              @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String inspection_type,
                                              @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                              @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
                                              @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String category_name_en,
                                              @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String category_name_ar,
                                              @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
                                              @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                                              @ApiParam(value = "service_category", required = true) @FormParam("service_category") String service_category,
                                              @ApiParam(value = "anonym", required = true) @FormParam("anonym") String anonym,
                                              @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type

    ) {

        Operation operation = ApiConfig.operations.get("/fahes/qpaytransaction/debitcard/save");

        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("pun", pun);
        bodyParams.put("referenceNumber", referenceNumber);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);
        bodyParams.put("plateType", plate_type);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);
        queryParams.put("anonym", anonym);

        System.out.println(queryParams);
        System.out.println(bodyParams);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }

    //  PreRegistration with amount fee null
    @ApiOperation(value = "transaction free", notes = "transaction free")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "transaction free OK")})
    @POST
    @Path("/qpaytransaction/free/save")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject qpayTransactionFree(@ApiParam(value = "userID", required = true) @FormParam("userID") String userID,
                                      @ApiParam(value = "qid", required = true) @FormParam("qid") String qid,
                                      @ApiParam(value = "mobile", required = true) @FormParam("mobile") String mobile,
                                      @ApiParam(value = "pun", required = true) @FormParam("pun") String pun,
                                      @ApiParam(value = "amount", required = true) @FormParam("amount") String amount,
                                      @ApiParam(value = "currency", required = true) @FormParam("currency") String currency,
                                      @ApiParam(value = "email", required = true) @FormParam("email") String email,
                                      @ApiParam(value = "inspection_type", required = true) @FormParam("inspection_type") String inspection_type,
                                      @ApiParam(value = "plate_number", required = true) @FormParam("plate_number") String plate_number,
                                      @ApiParam(value = "category_id", required = true) @FormParam("category_id") String category_id,
                                      @ApiParam(value = "category_name_en", required = true) @FormParam("category_name_en") String category_name_en,
                                      @ApiParam(value = "category_name_ar", required = true) @FormParam("category_name_ar") String category_name_ar,
                                      @ApiParam(value = "category_fee", required = true) @FormParam("category_fee") String category_fee,
                                      @ApiParam(value = "mobileNumber", required = true) @FormParam("mobileNumber") String mobileNumber,
                                      @ApiParam(value = "service_category", required = true) @FormParam("service_category") String service_category,
                                      @ApiParam(value = "plate_type", required = true) @FormParam("plate_type") String plate_type,
                                      @ApiParam(value = "anonym", required = true) @FormParam("anonym") String anonym
    ) {

        Operation operation = ApiConfig.operations.get("/fahes/qpaytransaction/free/save");

        JSONObject category = new JSONObject();
        category.put("id", category_id);
        category.put("name_en", category_name_en);
        category.put("name_ar", category_name_ar);
        category.put("fee", category_fee);

        JSONObject feeResource = new JSONObject();
        feeResource.put("category", category);
        feeResource.put("inspection_type", inspection_type);
        feeResource.put("service_category", service_category);


        JSONObject bodyParams = new JSONObject();
        bodyParams.put("userID", userID);
        bodyParams.put("qid", qid);
        bodyParams.put("mobile", mobile);
        bodyParams.put("pun", pun);
        bodyParams.put("mobileNumber", mobileNumber);
        bodyParams.put("amount", amount);
        bodyParams.put("currency", currency);
        bodyParams.put("email", email);
        bodyParams.put("feeResource", feeResource);
        bodyParams.put("plateType", plate_type);


        JSONObject queryParams = new JSONObject();
        queryParams.put("plate_number", plate_number);
        queryParams.put("plate_type", plate_type);
        queryParams.put("anonym", anonym);

        System.out.println("prtransactionlog/free/save queryParams:::" + queryParams);
        System.out.println("prtransactionlog/free/save bodyParams:::" + bodyParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, bodyParams);
    }
}


