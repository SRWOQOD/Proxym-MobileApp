package com.woqod.adapters.commands;

import java.io.Serializable;

public class HeaderCommand implements Serializable {

    private static final long serialVersionUID = -4085527061488789809L;

    private String statusCode;
    private String titleEN;
    private String titleAR;
    private String key;
    private String description;
    private String providerCode;
    private String providerDescription;
    private String errors;
    private String messageType;

    public HeaderCommand() {
        super();
        // TODO Auto-generated constructor stub
    }


    public HeaderCommand(String statusCode, String titleEN, String titleAR, String key, String description,
                         String providerCode, String providerDescription, String errors) {
        super();
        this.statusCode = statusCode;
        this.titleEN = titleEN;
        this.titleAR = titleAR;
        this.key = key;
        this.description = description;
        this.providerCode = providerCode;
        this.providerDescription = providerDescription;
        this.errors = errors;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getTitleEN() {
        return titleEN;
    }

    public void setTitleEN(String titleEN) {
        this.titleEN = titleEN;
    }

    public String getTitleAR() {
        return titleAR;
    }

    public void setTitleAR(String titleAR) {
        this.titleAR = titleAR;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderDescription() {
        return providerDescription;
    }

    public void setProviderDescription(String providerDescription) {
        this.providerDescription = providerDescription;
    }

    public String getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors = errors;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    @Override
    public String toString() {
        return "HeaderCommand [statusCode=" + statusCode + ", titleEN=" + titleEN + ", titleAR=" + titleAR + ", key="
                + key + ", description=" + description + ", providerCode=" + providerCode + ", providerDescription="
                + providerDescription + ", errors=" + errors + ", messageType=" + messageType + "]";
    }
}
