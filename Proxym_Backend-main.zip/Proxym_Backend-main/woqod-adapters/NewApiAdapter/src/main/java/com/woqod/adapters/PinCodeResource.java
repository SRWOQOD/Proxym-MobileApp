package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Pin Code API")
@Path("/pincode")
public class PinCodeResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(NewApiAdapterResource.class.getName());
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/send")
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject send(
            @ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
            @ApiParam(value = "biostatus", required = false) @FormParam(value = "biostatus") String biostatus,
            @ApiParam(value = "language", required = true) @FormParam(value = "language") String language) {

        Operation operation = ApiConfig.operations.get("/pincode/send");

        logger.info(language);
        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("language", language);
        queryParams.put("biostatus", biostatus);

        System.out.println(queryParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/validatePinCode")
    @OAuthSecurity(enabled = false)
    //@OAuthSecurity(scope = "UserLogin")
    public JSONObject validatePinCode(
            @ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
            @ApiParam(value = "biostatus", required = false) @FormParam(value = "biostatus") String biostatus,
            @ApiParam(value = "pincode", required = true) @FormParam(value = "pincode") String pinCode) {

        Operation operation = ApiConfig.operations.get("/pincode/validatePinCode");


        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("pincode", pinCode);
        queryParams.put("biostatus", biostatus);

        System.out.println(queryParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login/send")
    @OAuthSecurity(enabled = false)
    //@OAuthSecurity(scope = "UserLogin")
    public JSONObject sendLogin(
            @ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
            @ApiParam(value = "type", required = true) @FormParam(value = "type") String type,
            @ApiParam(value = "language", required = true) @FormParam(value = "language") String language) {


        /*JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String currentUsername = String.valueOf(currentUser.getAttributes().get("username"));

        if (currentUsername.equalsIgnoreCase(username)) {*/
        Operation operation = ApiConfig.operations.get("/pincode/login/send");

        logger.info(language);
        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("language", language);
        queryParams.put("type", type);

        System.out.println(queryParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    }/* else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }*/


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login/validatePinCode")
    @OAuthSecurity(enabled = false)
    //@OAuthSecurity(scope = "UserLogin")
    public JSONObject validatePinCodeLogin(
            @ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
            @ApiParam(value = "type", required = true) @FormParam(value = "type") String type,
            @ApiParam(value = "pincode", required = true) @FormParam(value = "pincode") String pinCode) {

        /*JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String currentUsername = String.valueOf(currentUser.getAttributes().get("username"));

        if (currentUsername.equalsIgnoreCase(username)) {*/
        Operation operation = ApiConfig.operations.get("/pincode/login/validatePinCode");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("pincode", pinCode);
        queryParams.put("type", type);
        queryParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));

        System.out.println(queryParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);
    } /*else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }*/

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/sendPinCodeToUpdateUserEMail")
    @OAuthSecurity(enabled = false)
    //@OAuthSecurity(scope = "UserLogin")
    public JSONObject sendPinCodeToUpdateUserEMail(@ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
                                                   @ApiParam(value = "language", required = true) @FormParam(value = "language") String language,
                                                   @ApiParam(value = "email", required = true) @FormParam(value = "email") String email) {


        /*JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String currentUsername = String.valueOf(currentUser.getAttributes().get("username"));

        if (currentUsername.equalsIgnoreCase(username)) {*/

        Operation operation = ApiConfig.operations.get("/pincode/sendPinCodeToUpdateUserEMail");
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("language", language);
        bodyParams.put("email", email);

        System.out.println(bodyParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }/* else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }*/

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/sendPinCodeToUpdateUserPhone")
    @OAuthSecurity(enabled = false)
    //@OAuthSecurity(scope = "UserLogin")
    public JSONObject sendPinCodeToUpdateUserPhone(@ApiParam(value = "username", required = true) @FormParam(value = "username") String username,
                                                   @ApiParam(value = "language", required = true) @FormParam(value = "language") String language,
                                                   @ApiParam(value = "phone", required = true) @FormParam(value = "phone") String phone) {

       /* JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String currentUsername = String.valueOf(currentUser.getAttributes().get("username"));

        if (currentUsername.equalsIgnoreCase(username)) {
*/
        Operation operation = ApiConfig.operations.get("/pincode/sendPinCodeToUpdateUserPhone");
        logger.info(language);
        JSONObject bodyParams = new JSONObject();
        bodyParams.put("username", username);
        bodyParams.put("language", language);
        bodyParams.put("phone", phone);

        System.out.println(bodyParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);
    }


}
