package com.woqod.adapters.modals;

import com.ibm.json.java.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class User {
    private Long id;
    private String customerId;
    private String type;
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private String contactType;
    private String adress1;
    private String adress2;
    private String qid;
    private String gender;
    private String adress2Label;
    private String mobileNumber;
    //private String photo;
    private String preferedLanguage;
    private String adress1Label;
    private String status;
    private Double income;
    private String vehBrand;
    private String vehModel;
    private String fleetName;
    private Long birthdate;
    private Long createdAt;
    private String poBox;
    private String customIdentification;
    private Boolean isBiometricActivated;
    private Map<String, Object> area;

    private Long[] defaultDate = new Long[]{2011L, 5L, 5L};


    public User() {
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", customerId='" + customerId + '\'' +
                ", type='" + type + '\'' +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", contactType='" + contactType + '\'' +
                ", adress1='" + adress1 + '\'' +
                ", adress2='" + adress2 + '\'' +
                ", qid='" + qid + '\'' +
                ", gender='" + gender + '\'' +
                ", adress2Label='" + adress2Label + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                //", photo='" + photo + '\'' +
                ", preferedLanguage='" + preferedLanguage + '\'' +
                ", adress1Label='" + adress1Label + '\'' +
                ", status='" + status + '\'' +
                ", income='" + income + '\'' +
                ", vehBrand='" + vehBrand + '\'' +
                ", vehModel='" + vehModel + '\'' +
                ", fleetName='" + fleetName + '\'' +
                ", birthdate=" + (birthdate) +
                ", createdAt=" + (createdAt) +
                ", poBox=" + (poBox) +
                ", custom Identification=" + (customIdentification) +
                ", is Biometric Activated=" + (isBiometricActivated) +
                ", area=" + (area) +
                '}';
    }

    public Map<String, Object> toMapObject() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", id);
        map.put("qid", qid);
        map.put("username", username);
        map.put("email", email);
        map.put("type", type);
        map.put("status", status);
        map.put("firstName", firstName);
        map.put("lastName", lastName);
        map.put("contactType", contactType);
        map.put("mobileNumber", mobileNumber);
        //map.put("photo", photo);
        map.put("gender", gender);
        map.put("preferedLanguage", preferedLanguage);
        map.put("adress1", adress1);
        map.put("adress2", adress2);
        map.put("adress1Label", adress1Label);
        map.put("adress2Label", adress2Label);
        map.put("birthdate", birthdate);
        map.put("createdAt", createdAt);
        map.put("income", income);
        map.put("vehBrand", vehBrand);
        map.put("vehModel", vehModel);
        map.put("fleetName", fleetName);
        map.put("poBox", poBox);
        map.put("area", area);
        map.put("isBiometricActivated", isBiometricActivated);
        map.put("customIdentification", customIdentification);
        return map;
    }

    public void setFromJsonObject(JSONObject userData) {
        this.setId((Long) userData.get("id"));
        this.setQid((String) userData.get("qid"));
        this.setCustomerId((String) userData.get("customerId"));
        this.setType((String) userData.get("type"));
        this.setUsername((String) userData.get("username"));
        this.setEmail((String) userData.get("email"));
        this.setFirstName((String) userData.get("firstName"));
        this.setLastName((String) userData.get("lastName"));
        //this.setPhoto((String) userData.get("photo"));
        this.setContactType((String) userData.get("contactType"));
        this.setMobileNumber((String) userData.get("mobileNumber"));
        this.setStatus((String) userData.get("status"));
        this.setAdress1((String) userData.get("adress1"));
        this.setAdress2((String) userData.get("adress2"));
        this.setAdress1Label((String) userData.get("adress1Label"));
        this.setAdress2Label((String) userData.get("adress2Label"));
        this.setGender((String) userData.get("gender"));
        this.setPreferedLanguage((String) userData.get("preferedLanguage"));
        this.setIncome((Double) userData.get("income"));
        this.setVehBrand((String) userData.get("vehBrand"));
        this.setVehModel((String) userData.get("vehModel"));
        this.setFleetName((String) userData.get("fleetName"));
        this.setPoBox((String) userData.get("poBox"));
        this.setCustomIdentification((String) userData.get("customIdentification"));
        this.setBiometricActivated((Boolean) userData.get("isBiometricActivated"));
        if (userData.get("birthdate") == null)
            this.setBirthdate(null);
        else
            this.setBirthdate((Long) userData.get("birthdate"));
        if (userData.get("createdAt") == null)
            this.setCreatedAt(null);
        else
            this.setCreatedAt((Long) userData.get("createdAt"));
        Map<String, Object> area = (Map<String, Object>) userData.get("area");
        this.setArea(area);

    }

    public void setFromMap(Map<String, Object> userData) {
        this.setId(new Long(String.valueOf(userData.get("id"))));
        this.setQid((String) userData.get("qid"));
        this.setCustomerId((String) userData.get("customerId"));
        this.setType((String) userData.get("type"));
        this.setUsername((String) userData.get("username"));
        this.setEmail((String) userData.get("email"));
        this.setFirstName((String) userData.get("firstName"));
        this.setLastName((String) userData.get("lastName"));
        this.setContactType((String) userData.get("contactType"));
        this.setMobileNumber((String) userData.get("mobileNumber"));
        this.setStatus((String) userData.get("status"));
        this.setAdress1((String) userData.get("adress1"));
        this.setAdress2((String) userData.get("adress2"));
        this.setAdress1Label((String) userData.get("adress1Label"));
        this.setAdress2Label((String) userData.get("adress2Label"));
        this.setGender((String) userData.get("gender"));
        this.setPreferedLanguage((String) userData.get("preferedLanguage"));
        this.setIncome(new Double(String.valueOf(userData.get("income"))));
        this.setVehBrand((String) userData.get("vehBrand"));
        this.setVehModel((String) userData.get("vehModel"));
        this.setFleetName((String) userData.get("fleetName"));
        this.setPoBox((String) userData.get("poBox"));
        this.setBirthdate((Long) userData.get("birthdate"));
        this.setCreatedAt((Long) userData.get("createdAt"));
        this.setCustomIdentification((String) userData.get("customIdentification"));
        this.setBiometricActivated((Boolean) userData.get("isBiometricActivated"));
        Map<String, Object> area = (Map<String, Object>) userData.get("area");
        this.setArea(area);
    }


    public Map<String, Object> getArea() {
        return area;
    }

    public void setArea(Map<String, Object> area) {
        this.area = area;
    }

    public Long[] getDefaultDate() {
        return defaultDate;
    }

    public void setDefaultDate(Long[] defaultDate) {
        this.defaultDate = defaultDate;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getVehBrand() {
        return vehBrand;
    }

    public void setVehBrand(String vehBrand) {
        this.vehBrand = vehBrand;
    }

    public String getVehModel() {
        return vehModel;
    }

    public void setVehModel(String vehModel) {
        this.vehModel = vehModel;
    }

    public Double getIncome() {
        return income;
    }

    public void setIncome(Double income) {
        this.income = income;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAdress2Label() {
        return adress2Label;
    }

    public void setAdress2Label(String adress2Label) {
        this.adress2Label = adress2Label;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getCustomIdentification() {
        return customIdentification;
    }

    public void setCustomIdentification(String customIdentification) {
        this.customIdentification = customIdentification;
    }

    public Boolean getBiometricActivated() {
        return isBiometricActivated;
    }

    public void setBiometricActivated(Boolean biometricActivated) {
        isBiometricActivated = biometricActivated;
    }
/*public String getPhoto() {
    return photo;
  }

  public void setPhoto(String photo) {
    this.photo = photo;
  }*/

    public String getPreferedLanguage() {
        return preferedLanguage;
    }

    public void setPreferedLanguage(String preferedLanguage) {
        this.preferedLanguage = preferedLanguage;
    }

    public String getAdress1Label() {
        return adress1Label;
    }

    public void setAdress1Label(String adress1Label) {
        this.adress1Label = adress1Label;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Long birthdate) {
        if (birthdate == null)
            this.birthdate = 0L;
        else
            this.birthdate = birthdate;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        if (createdAt == null)
            this.createdAt = 0L;
        else
            this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getAdress1() {
        return adress1;
    }

    public void setAdress1(String adress1) {
        this.adress1 = adress1;
    }

    public String getAdress2() {
        return adress2;
    }

    public void setAdress2(String adress2) {
        this.adress2 = adress2;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getFleetName() {
        return fleetName;
    }

    public void setFleetName(String fleetName) {
        this.fleetName = fleetName;
    }

    public String getPoBox() {
        return poBox;
    }

    public void setPoBox(String poBox) {
        this.poBox = poBox;
    }
}
