package com.woqod.adapters;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.*;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Api(value = "notification API")
@Path("/notification")
public class NotificationResource {

    @Context
    AdapterSecurityContext securityContext;

    @ApiOperation(value = "Get List of notification by device ", notes = "List of notification by device")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of notification by device")})
    @GET
    @Path("/listByDevice")
    @Produces(MediaType.APPLICATION_JSON)
//    @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject listByDevice(@QueryParam(value = "device") String device) {

        Operation operation = ApiConfig.operations.get("/notification/listByDevice");

        JSONObject queryParams = new JSONObject();
        queryParams.put("device", device);


        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }

    @ApiOperation(value = "Get List of notification by device ", notes = "List of notification by device")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "List of notification by device")})
    @POST
    @Path("/listByUsername")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(scope = "UserLogin")
//    @OAuthSecurity(enabled = false)
    public JSONObject listByUsername(@ApiParam(value = "username") @FormParam(value = "username") String username,
                                     @ApiParam(value = "size") @FormParam("size") String size,
                                     @ApiParam(value = "page") @FormParam("page") String page
            , @ApiParam(value = "deviceId") @FormParam("deviceId") String deviceId) {
        JSONObject jsonObject = new JSONObject();
        AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();
        String currentUsername = String.valueOf(currentUser.getAttributes().get("username"));

        if (currentUsername.equalsIgnoreCase(username)) {
            Operation operation = ApiConfig.operations.get("/notification/listByUsername");

            JSONObject queryParams = new JSONObject();
            queryParams.put("parameters", username);
            queryParams.put("size", size);
            queryParams.put("page", page);
            queryParams.put("deviceId", deviceId);
            System.out.println("username" + username);
            System.out.println("deviceId" + deviceId);
            System.out.println("page" + page);
            System.out.println("size" + size);
            return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
        } else {
            JSONArray arr = new JSONArray();
            arr.add("unauthorized");
            jsonObject.put("isSuccessful", true);
            jsonObject.put("data", null);
            jsonObject.put("errors", arr);
            jsonObject.put("statusCode", 401);

            return jsonObject;
        }
    }

    @ApiOperation(value = "find All For Anonymous User ", notes = "find All For Anonymous User")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "find All For Anonymous User")})
    @POST
    @Path("/anonymous")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject findAllForAnonymousUser(@ApiParam(value = "size") @FormParam("size") String size,
                                              @ApiParam(value = "page") @FormParam("page") String page
            , @ApiParam(value = "deviceId") @FormParam(value = "deviceId") String deviceId) {

        Operation operation = ApiConfig.operations.get("/notification/anonymous");

        JSONObject queryParams = new JSONObject();
        queryParams.put("size", size);
        queryParams.put("page", page);
        queryParams.put("deviceId", deviceId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }

    @POST
    @Path("/updateStatus")
    @Produces(MediaType.APPLICATION_JSON)
//    @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject updateStatus(@ApiParam(value = "username", required = false) @FormParam("username") String username,
                                   @ApiParam(value = "deviceId", required = false) @FormParam("deviceId") String deviceId,
                                   @ApiParam(value = "uniqueId", required = false) @FormParam("uniqueId") String uniqueId,
                                   @ApiParam(value = "idnotif", required = false) @FormParam("idnotif") String idnotif) {

        Operation operation = ApiConfig.operations.get("/notification/updateStatus");

        JSONObject queryParams = new JSONObject();
        queryParams.put("username", username);
        queryParams.put("idnotif", idnotif);
        queryParams.put("uniqueId", uniqueId);
        queryParams.put("deviceId", deviceId);


        System.out.println("idnotif " + idnotif);
        System.out.println("username " + username);
        System.out.println("uniqueId " + uniqueId);
        System.out.println("deviceId " + deviceId);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, queryParams);

    }

    @POST
    @Path("/updateAll")
    @Produces(MediaType.APPLICATION_JSON)
//    @OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject updateAll(@ApiParam(value = "connected", required = true) @FormParam("connected") Boolean connected,
                                @ApiParam(value = "deviceid", required = true) @FormParam("deviceid") String deviceid) {

        Operation operation = ApiConfig.operations.get("/notification/updateAll");

        JSONObject queryParams = new JSONObject();
        queryParams.put("connected", connected);
        queryParams.put("deviceid", deviceid);

        System.out.println(deviceid);
        System.out.println(connected);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    }
}
