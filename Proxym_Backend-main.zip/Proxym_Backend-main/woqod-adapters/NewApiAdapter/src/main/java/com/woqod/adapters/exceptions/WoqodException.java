package com.woqod.adapters.exceptions;


import com.woqod.adapters.errors.WoqodError;

/**
 * a runtime exception that will be thrown to handle application errors
 *
 * @author Radhouene
 */
public abstract class WoqodException extends RuntimeException {
    private static final long serialVersionUID = 8205877130108144548L;
    protected String key;
    private WoqodError error;
    private String[] tokens;
    private String originalMessage;
    private Throwable exception;

    public WoqodException(WoqodError error, Throwable exception, String... tokens) {
        super(exception);
        this.originalMessage = exception.getMessage();
        this.error = error;
        this.exception = exception;
        this.tokens = tokens;
    }

    public WoqodException(WoqodError error, String... tokens) {
        super();
        this.error = error;
        this.tokens = tokens;
    }

    public WoqodError getError() {
        return error;
    }

    public String getOriginalMessage() {
        return originalMessage;
    }

    public String getKey() {
        return key;
    }

    public Throwable getException() {
        return exception;
    }

    public String getCode() {
        return error.getCode();
    }

    public String getErrorTitle() {
        return error.getTitle(tokens);
    }

    @Override
    public String toString() {
        return this.getCode() + " - " + this.getErrorTitle();
    }

}
