package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.logging.Logger;

@Api(value = "Tenders API")
@Path("/tenders")
public class TendersResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    // Define logger (Standard java.util.Logger)
    static Logger logger = Logger.getLogger(NewApiAdapterResource.class.getName());
    @Context
    HttpServletRequest servletRequest;
    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;
    @Context
    AdapterSecurityContext securityContext;

    @GET
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    //@OAuthSecurity(scope = "UserLogin")
    @OAuthSecurity(enabled = false)
    public JSONObject tenders() {

        Operation operation = ApiConfig.operations.get("/tenders");

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

    @GET
    @Path("/tenders")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject getAlltenders(@ApiParam(value = "size") @FormParam("size") String size,
                                    @ApiParam(value = "page") @FormParam("page") String page) {

        Operation operation = ApiConfig.operations.get("/tenders/tenders");
        JSONObject queryParams = new JSONObject();
        queryParams.put("size", size);
        queryParams.put("page", page);
        queryParams.put("parameters", null);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, null);
    }

}
