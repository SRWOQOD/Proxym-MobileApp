package com.woqod.adapters.enums;

public enum ResponseTypes {
    LIST_RESPONSE,
    OBJECT_RESPONSE
}
