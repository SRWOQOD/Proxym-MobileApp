/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.security.checks.base.UserAuthenticationSecurityCheck;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.checks.AuthorizationResponse;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.modals.User;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.ConvertUtils;
import com.woqod.adapters.utils.RequestGenerator;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.io.IOException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.*;
import java.util.logging.Logger;

public class UserLoginSecurityCheck extends UserAuthenticationSecurityCheck {

    static Logger logger = Logger.getLogger(NewApiAdapterResource.class.getName());
    @Context
    HttpServletRequest servletRequest;

    private String titleEN, statusCode, titleAR;
    private boolean rememberMe = false;
    private User authenticatedUser;

    @Override
    protected AuthenticatedUser createUser() {
        System.out.println("UserLoginSecurityCheck @Override createUser()");
        return new AuthenticatedUser(String.valueOf(authenticatedUser.getId()),
                authenticatedUser.getFullName(),
                this.getName(),
                authenticatedUser.toMapObject());
    }

    // CREATE USER WITH NEW USER DATA
    private AuthenticatedUser createUser(Map<String, Object> attributes) {
        System.out.println("UserLoginSecurityCheck createUser() ");
        authenticatedUser = new User();
        authenticatedUser.setFromMap(attributes);

        return new AuthenticatedUser(String.valueOf(authenticatedUser.getId()),
                authenticatedUser.getFullName(),
                this.getName(),
                authenticatedUser.toMapObject());
    }

    @Override
    protected boolean validateCredentials(Map<String, Object> encryptedCredentials) {

        Map<String, Object> credentials = null;
        try {
            if (encryptedCredentials.containsKey("encryptedData")) {
                //String encryptedData = encryptedCredentials.get("encryptedData").toString();
                byte[] input = Base64.getDecoder().decode(encryptedCredentials.get("encryptedData").toString());


                SecretKey keySpec = new SecretKeySpec(Base64.getDecoder().decode("u/Gu5posvwDsXUnV5Zaq4g=="), "AES");


                AlgorithmParameterSpec ivSpec = new IvParameterSpec(Base64.getDecoder().decode("5D9r9ZVzEYYgha93/aUK2w=="));


                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
                String bytes = new String(cipher.doFinal(input), "UTF-8");

                //JSONParser parser = new JSONParser();
                credentials = (JSONObject) JSONObject.parse(bytes);


            } else {
                credentials = encryptedCredentials;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println("exception" + e.getMessage());
        } catch (Exception ex) {

            ex.printStackTrace();
            System.out.println("exception" + ex.getMessage());
        }

        if (credentials != null && credentials.containsKey("username") && credentials.containsKey("password")) {

            try {
                JSONObject responseObject = this.checkUserCredentials(credentials);

                JSONObject headerObject = (JSONObject) responseObject.get("header");
                System.out.println("headerObject" + headerObject.toString());


                this.statusCode = (String) headerObject.get("statusCode");
                this.titleEN = (String) headerObject.get("titleEN");
                this.titleAR = (String) headerObject.get("titleAR");

                 // Block access for inactive users
                if (this.statusCode.equals("159")) {
                    return false;
                }

                boolean requestIsSuccessful = responseObject.get("isSuccessful").toString().equals("true");
                if (requestIsSuccessful) {
                    JSONObject userData = (JSONObject) ((JSONObject) responseObject.get("body")).get("result");
                    this.authenticatedUser = new User();
                    this.authenticatedUser.setFromJsonObject(userData);
                    // Only Active User can access
                    if (this.authenticatedUser.getStatus().equals("Pending")) {
                        //System.out.println("User is not Active");
                        this.titleEN = "User '" + this.authenticatedUser.getFullName() +
                                "' not able to connect for a reason his status is '" + this.authenticatedUser.getStatus() + "'.";
                        this.statusCode = "155";
                        return false;
                    }

                    //System.out.println("User Authenticated !");
                    //System.out.println("Id: " + authenticatedUser.getId() + " UserName: " + authenticatedUser.getUserName());
                    return true;
                }

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println(e.getMessage());
            }

        } else {
            //System.out.println("Credentials not set properly !");
            this.titleEN = "Credentials not set properly";
            this.titleAR = "Credentials not set properly";
            this.statusCode = "101";
        }
        return false;
    }

    private JSONObject checkUserCredentials(Map<String, Object> credentials) {
        System.out.println(credentials.toString());

        String username = credentials.get("username").toString().trim().toLowerCase();
        String password = credentials.get("password").toString();
        String deviceId = credentials.get("deviceId").toString();
        String type = credentials.get("type").toString();

        String deviceType = "";
        try {
            deviceType = credentials.get("deviceType").toString();
        } catch (Exception e) {
            //
        }


        //Optional RememberMe
        this.rememberMe = (credentials.containsKey("rememberMe") && credentials.get("rememberMe").toString().equals("true"));

        Operation operation = ApiConfig.operations.get("/login");

        JSONObject bodyParams = new JSONObject();

        String encodedUsername = Base64.getEncoder().encodeToString(username.getBytes());
        bodyParams.put("username", encodedUsername);
        if (type.equals("Bio_Auth")) {
            bodyParams.put("bioPin", "00000");
        } else {
            String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
            bodyParams.put("password", encodedPassword);
        }

        logger.info("Client IP :::::::::::::::" + RequestGenerator.getClientIp(servletRequest));


        //logger.info("BodyParams :::::::::::::::" + bodyParams.toString());
        bodyParams.put("deviceId", deviceId);
        bodyParams.put("deviceType", deviceType);
        bodyParams.put("type", type);
        bodyParams.put("ipAddress", RequestGenerator.getClientIp(servletRequest));
        logger.info("BodyParams :::::::::::::::" + bodyParams.toString());

        JSONObject header = new JSONObject();

        header.put("deviceId", deviceId);

        //   System.out.println("headeers" + header);
        //  System.out.println("bodyParams" + bodyParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams);

    }
  /*
  protected boolean checkUserCredentials(Map<String, Object> credentials) {
    String username = credentials.get("username").toString().toLowerCase();
    String password = credentials.get("password").toString();
    if (!username.isEmpty() && !password.isEmpty() && username.equals(password)) {
      return true;
    }
    return false;
  }*/

    @Override
    protected Map<String, Object> createChallenge() {
        Map<String, Object> challenge = new HashMap<String, Object>();
        Map<String, Object> error = new HashMap<String, Object>();
        error.put("statusCode", statusCode);
        error.put("titleEN", titleEN);
        error.put("titleAR", titleAR);
        challenge.put("header", error);
        challenge.put("remainingAttempts", getRemainingAttempts());
        return challenge;
    }


    @Override
    protected boolean rememberCreatedUser() {
        return rememberMe;
    }

    @Override
    public void authorize(Set<String> scope, Map<String, Object> credentials, HttpServletRequest request,
                          AuthorizationResponse response) {

        Enumeration<String> parameterNames = request.getParameterNames();

        while (parameterNames.hasMoreElements()) {

            String paramName = parameterNames.nextElement();
            logger.info(paramName);

            String[] paramValues = request.getParameterValues(paramName);
            for (int i = 0; i < paramValues.length; i++) {
                String paramValue = paramValues[i];
                logger.info("t" + paramValue);
            }
        }

        logger.info("Remote IP :::::::::::::::" + RequestGenerator.getClientIp(servletRequest));

        logger.info(request.getAttributeNames().nextElement());

        if (credentials != null && credentials.get("updateUser") != null) {
            // UPDATE SESSION / BACKEND USER DATA
            //System.out.println("UserLoginSecurityCheck .authorize() -- update session");

            Map<String, Object> attributes = new HashMap<String, Object>();//super.user.getAttributes();
            for (Map.Entry<String, Object> entry : super.user.getAttributes().entrySet()) {
                attributes.put(entry.getKey(), entry.getValue());
            }

            try {

                Map<String, Object> updatedUserData = ConvertUtils.mergeMaps(attributes, credentials);

                // UPDATE USER IN BE
                JSONObject responseObject = this.updateUserInBE(updatedUserData);

                JSONObject headerObject = (JSONObject) responseObject.get("header");
                boolean requestIsSuccessful = responseObject.get("isSuccessful").toString().equals("true");

                this.statusCode = (String) headerObject.get("statusCode");
                this.titleEN = (String) headerObject.get("titleEN");
                this.titleAR = (String) headerObject.get("titleAR");

                if (requestIsSuccessful) {
                    super.user = createUser(updatedUserData);
                    super.authorizationContext.setActiveUser(super.user);
                    registrationContext.setRegisteredUser(super.user);
                    response.addSuccess(scope, super.getExpiresAt(), super.getName(), "user", super.user);

                } else {
                    Map<String, Object> failureData = new HashMap<String, Object>();

                    failureData.put("statusCode", this.statusCode);
                    failureData.put("titleEN", this.titleEN);
                    failureData.put("titleAR", this.titleAR);
                    response.addFailure("UserLogin", failureData);
                }


            } catch (Exception e) {
                e.printStackTrace();
                Map<String, Object> failureData = new HashMap<String, Object>();

                failureData.put("statusCode", "105");
                failureData.put("errorMsg", e.getMessage());

                response.addFailure("UserLogin", failureData);
            }

        } else {
            // KEEP DEFAULT INVOKE
            //System.out.println("UserLoginSecurityCheck .authorize() -- Simple Login");
            super.authorize(scope, credentials, request, response);
        }
    }


    private JSONObject updateUserInBE(Map<String, Object> userData) {
        //  System.out.println("UserLoginSecurityCheck .updateUserInBE() --" + userData.size());

        Operation operation = ApiConfig.operations.get("/users");
        JSONObject bodyParams = new JSONObject();

        bodyParams.putAll(userData);

        bodyParams.put("birthdate", ConvertUtils.parseWoqodDate(userData.get("birthdate")));
        bodyParams.put("createdAt", ConvertUtils.parseWoqodDate(userData.get("createdAt")));
        bodyParams.put("password", "****");


        if (userData.get("income") == null) {
            bodyParams.put("income", 0);
        }

        //System.out.println("updateUserInBE");
        //System.out.println(userData.get("income"));
        //System.out.println(bodyParams.toString());

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, null, bodyParams
        );
    }

}
