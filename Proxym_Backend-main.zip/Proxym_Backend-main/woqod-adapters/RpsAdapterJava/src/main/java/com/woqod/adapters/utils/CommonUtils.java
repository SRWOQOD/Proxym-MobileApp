package com.woqod.adapters.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.ibm.json.java.JSONObject;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by Kais Elouragini on 26/04/2016.
 */
public class CommonUtils {

  static String GET = "GET";
  static String POST = "POST";
  static String PUT = "PUT";
  static String DELETE = "DELETE";

  public static void buildHeaders(HttpRequestBase httpRequest, JSONObject headers) {
    // Adding Request Headers
    try {
      if (null != headers) {
        for (Object key : headers.keySet()) {
          httpRequest.setHeader(String.valueOf(key), String.valueOf(headers.get(key)));
        }
      }
    } catch (Exception e) {
      //System.out.println("Parsing Headers Exception : " + e.getMessage());
    }
  }



  public static String getUTCDateTime() {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
      sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
      return sdf.format(new Date());
  }


  public static String post(String url, String content) throws Exception{
      HttpClient client = new DefaultHttpClient();
      HttpPost post = new HttpPost(url);
      String xml = content;
      HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
      post.setEntity(entity);
      post.setHeader("Content-Type", "text/xml; charset=utf-8");
      HttpResponse response = client.execute(post);
      String result = EntityUtils.toString(response.getEntity());

      return result;
  }

  public static JSONObject objectToJson(Object source) {
    JSONObject result = new JSONObject();
    try {
      ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
      String json = ow.writeValueAsString(source);
      result = JSONObject.parse(json);
      return result;

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public static String postWithHeader(String url, String content) throws Exception{
    HttpClient client = new DefaultHttpClient();
    HttpPost post = new HttpPost(url);
    String xml = content;
    HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
    post.setEntity(entity);
    post.setHeader("Content-Type", "text/xml; charset=utf-8");
    HttpResponse response = client.execute(post);

    String result = EntityUtils.toString(response.getEntity());

    return result;
  }

  public static String generatepassword(String nonce, String created,
                                        String pwd) {
    try {
      byte[] nonceBytes = Base64.getDecoder().decode(nonce);
      byte[] createdBytes = created.getBytes("UTF-8");
      byte[] passwordBytes = pwd.getBytes("UTF-8");
      ByteArrayOutputStream outputStream =
        new ByteArrayOutputStream( );
      outputStream.write(nonceBytes);
      outputStream.write(createdBytes);
      outputStream.write(passwordBytes);
      byte[] concatenatedBytes = outputStream.toByteArray();
      MessageDigest digest = MessageDigest.getInstance( "SHA-1" );
      digest.update(concatenatedBytes, 0, concatenatedBytes.length);
      byte[] digestBytes = digest.digest();
      String digestString = Base64.getEncoder().encodeToString(digestBytes);


      System.out.println("Provided password digest is: "+digestString);
      System.out.println("   Nonce: "+nonce);
      System.out.println("   Timestamp: "+created);
      System.out.println("   Password: "+pwd);
      System.out.println("   Computed digest: "+digestString);

      return digestString;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }


}
