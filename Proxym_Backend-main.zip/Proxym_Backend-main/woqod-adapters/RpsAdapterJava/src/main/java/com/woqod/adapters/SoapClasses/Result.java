package com.woqod.adapters.SoapClasses;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Result {
    @JsonProperty("Envelope")
    private Object envelope ;

    public Object getEnvelope() {
        return envelope;
    }

    public void setEnvelope(Object envelope) {
        this.envelope = envelope;
    }
}
