package com.woqod.adapters.SoapClasses;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TCustomer {

    @JsonProperty("GroupName")
    private String groupName ;
    @JsonProperty("CustomerCode")
    private String customerCode ;
    @JsonProperty("VehicleID")
    private String vehicleID ;
    @JsonProperty("LicensePlateNr")
    private String licensePlateNr ;
    @JsonProperty("GroupCode")
    private String groupCode ;
    @JsonProperty("CustomerID")
    private String customerID ;
    @JsonProperty("rowOrder")
    private String fowOrder ;
    @JsonProperty("GroupID")
    private String froupID ;
    @JsonProperty("FleetORACLE_ID")
    private String fleetORACLE_ID ;
    @JsonProperty("FleetName")
    private String fleetName ;
    @JsonProperty("CustomerORACLE_ID")
    private String customerORACLE_ID ;
    @JsonProperty("FleetID")
    private String fleetID ;
    @JsonProperty("id")
    private String id ;
    @JsonProperty("CustomerName")
    private String vustomerName ;
    @JsonProperty("FleetCode")
    private String fleetCode ;


}
