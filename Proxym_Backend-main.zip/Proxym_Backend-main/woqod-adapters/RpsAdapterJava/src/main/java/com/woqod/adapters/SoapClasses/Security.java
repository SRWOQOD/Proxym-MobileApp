package com.woqod.adapters.SoapClasses;

public class Security {
  public Timestamp Timestamp;
}
