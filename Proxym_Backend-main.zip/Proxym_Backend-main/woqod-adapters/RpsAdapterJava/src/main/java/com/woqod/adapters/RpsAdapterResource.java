/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.SoapClasses.Envelope;
import com.woqod.adapters.SoapClasses.EnvelopeCustomer;
import com.woqod.adapters.SoapClasses.TsalesTransactions;
import com.woqod.adapters.utils.CommonUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Api(value = "Sample Adapter Resource")
@Path("/")
public class RpsAdapterResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */


    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    @POST
    @Path("/getCustomerByFleetName")
    @OAuthSecurity(enabled = false)
    @Produces(MediaType.APPLICATION_JSON)
    public JSONObject getCustomerByFleetName(@ApiParam(value = "qid") @FormParam("qid") String qid
    ) throws Exception {
        String WS_RPS_PATH = "wsmobileapp/rps/woqode.asmx";
        String rpsAdapterURL = configApi.getPropertyValue("rpsAdapterURL");
        System.out.println("qid" + qid);

        byte[] decodedBytes = java.util.Base64.getDecoder().decode(qid);
        String decodedQid = new String(decodedBytes);

        String req =
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:woqv=\"http://woqv-web-services/\">" +
                        " <soapenv:Header/> <soapenv:Body>  <woqv:Get_Customer_ByFleetName> " +
                        " <!--Optional:--> <woqv:sFleetName>" + decodedQid + "</woqv:sFleetName>" +
                        " </woqv:Get_Customer_ByFleetName>  </soapenv:Body> " +
                        "</soapenv:Envelope>";

        System.out.println("Get_Customer_ByFleetName " + req);
        String resp = null;
        resp = CommonUtils.postWithHeader(rpsAdapterURL + WS_RPS_PATH, req);
        System.out.println("resp" + resp);
        JacksonXmlModule module = new JacksonXmlModule();
        module.setDefaultUseWrapper(false);
        XmlMapper xmlMapper = new XmlMapper(module);
        EnvelopeCustomer res = xmlMapper.readValue(resp, EnvelopeCustomer.class);
        //    System.out.println("resp" + res);
        JSONObject fullResult = new JSONObject();
        if (res.getBody() != null &&
                res.getBody().getCustomerbyFleetNameResponse() != null &&
                res.getBody().getCustomerbyFleetNameResponse().getCustomer_byFleetNameResult() != null &&
                res.getBody().getCustomerbyFleetNameResponse().getCustomer_byFleetNameResult().getDiffgram() != null &&
                res.getBody().getCustomerbyFleetNameResponse().getCustomer_byFleetNameResult().getDiffgram().getNewDataSetCus() != null) {

            Gson gson = new Gson();
            String json = gson.toJson(res.getBody().getCustomerbyFleetNameResponse().getCustomer_byFleetNameResult()
                    .getDiffgram().getNewDataSetCus().getTCustomer());

            JSONObject result = new JSONObject();
            result.put("result", JSONArray.parse(json)
            );


            JSONObject header = new JSONObject();
            header.put("statusCode", "000");

            fullResult.put("isSuccessful", true);
            fullResult.put("header", header);

            fullResult.put("body", result);

        } else {
            fullResult.put("isSuccessful", true);
            JSONObject result = new JSONObject();
            result.put("result", new JSONArray());
            fullResult.put("body", result);


        }

        return fullResult;

    }

    @POST
    @Path("/getSaleTransactions")
    @OAuthSecurity(enabled = false)
    @Produces(MediaType.APPLICATION_JSON)
    public JSONObject getSaleTransactions(@ApiParam(value = "plateNumber") @FormParam("plateNumber") String plateNumber
    ) {
        String WS_RPS_PATH = "wsmobileapp/rps/woqode.asmx";
        String rpsAdapterURL = configApi.getPropertyValue("rpsAdapterURL");
        System.out.println("plateNumber" + plateNumber);
        String CivilID = plateNumber;
        System.out.println("CivilID" + CivilID);
        try {


            String req =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:woqv=\"http://woqv-web-services/\">" +
                            " <soapenv:Header/> <soapenv:Body>  <woqv:Get_SalesTransactions> " +
                            " <!--Optional:--> <woqv:sPlateNumber>" + plateNumber + "</woqv:sPlateNumber>" +
                            " </woqv:Get_SalesTransactions>  </soapenv:Body> " +
                            "</soapenv:Envelope>";

            System.out.println("getSaleTransactions " + req);
            String resp = null;

            resp = CommonUtils.postWithHeader(rpsAdapterURL + WS_RPS_PATH, req);
            System.out.println("resp" + resp);

            //mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPJSONObject.java:241ERTIES);
            JacksonXmlModule module = new JacksonXmlModule();
            module.setDefaultUseWrapper(false);
            XmlMapper xmlMapper = new XmlMapper(module);
            Envelope res = xmlMapper.readValue(resp, Envelope.class);
            //      System.out.println("resp" + res);
            JSONObject fullResult = new JSONObject();
            if (res.getBody() != null &&
                    res.getBody().getSalesTransactionsResponse() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult().getDiffgram() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult().getDiffgram().getNewDataSet() != null) {

                Gson gson = new Gson();
                String json = gson.toJson(res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult()
                        .getDiffgram().getNewDataSet().getTsalesTransactions());

                JSONObject result = new JSONObject();
                result.put("result", JSONArray.parse(json)
                );


                JSONObject header = new JSONObject();
                header.put("statusCode", "000");

                fullResult.put("isSuccessful", true);
                fullResult.put("header", header);

                fullResult.put("body", result);

            } else {
                fullResult.put("isSuccessful", true);
                JSONObject header = new JSONObject();
                header.put("statusCode", "000");
                JSONObject result = new JSONObject();
                result.put("result", new JSONArray());
                fullResult.put("header", header);
                fullResult.put("body", result);


            }

            return fullResult;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @POST
    @Path("/getAllSalesTransactions")
    @OAuthSecurity(enabled = false)
    @Produces(MediaType.APPLICATION_JSON)
    public JSONObject getAllSalesTransactions(@ApiParam(value = "plateNumbersStr") @FormParam("plateNumbersStr") String plateNumbersStr,
                                              @ApiParam(value = "fleetName") @FormParam("fleetName") String fleetName
    ) throws IOException {
        JSONArray transactions = new JSONArray();

        String[] plateNumbers = plateNumbersStr.split("-");
        int length = (plateNumbers.length);
        if (length > 3) length = 3;
        for (int i = 0; i < length; i++) {
            JSONObject jsonObject = getSalesTransactions(plateNumbers[i]);
            System.out.println(plateNumbers[i]);
            System.out.println(jsonObject.get("isSuccessful"));
            if (jsonObject.get("isSuccessful").equals(true)) {
                JSONObject json = (JSONObject) jsonObject.get("body");
                System.out.println(json.get("result"));
                JSONArray jArray = (JSONArray) json.get("result");
                transactions.addAll(jArray);

            }

        }
        JSONObject result = new JSONObject();
        result.put("result", transactions
        );


        JSONObject header = new JSONObject();
        header.put("statusCode", "000");

        JSONObject fullResult = new JSONObject();
        fullResult.put("isSuccessful", true);
        fullResult.put("header", header);

        fullResult.put("body", result);
        return fullResult;
    }

    public JSONObject getSalesTransactions(String plate) {
        String WS_RPS_PATH = "wsmobileapp/rps/woqode.asmx";
        String rpsServiceURL = configApi.getPropertyValue("rpsAdapterURL");
        System.out.println("plate" + plate);
        try {


            String req =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:woqv=\"http://woqv-web-services/\">" +
                            " <soapenv:Header/> <soapenv:Body>  <woqv:Get_SalesTransactions> " +
                            " <!--Optional:--> <woqv:sPlateNumber>" + plate + "</woqv:sPlateNumber>" +
                            " </woqv:Get_SalesTransactions>  </soapenv:Body> " +
                            "</soapenv:Envelope>";

            System.out.println("getSaleTransactions " + req);
            String resp = null;

            resp = CommonUtils.postWithHeader(rpsServiceURL + WS_RPS_PATH, req);
            System.out.println("resp" + resp);
            //mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPJSONObject.java:241ERTIES);
            JacksonXmlModule module = new JacksonXmlModule();
            module.setDefaultUseWrapper(false);
            XmlMapper xmlMapper = new XmlMapper(module);
            Envelope res = xmlMapper.readValue(resp, Envelope.class);
            System.out.println("resp" + res);
            JSONObject fullResult = new JSONObject();
            if (res.getBody() != null &&
                    res.getBody().getSalesTransactionsResponse() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult().getDiffgram() != null &&
                    res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult().getDiffgram().getNewDataSet() != null) {
                Gson gson = new Gson();
                String json = gson.toJson(res.getBody().getSalesTransactionsResponse().getSalesTransactionsResult()
                        .getDiffgram().getNewDataSet().getTsalesTransactions());

                JSONObject result = new JSONObject();
                result.put("result", JSONArray.parse(json)
                );


                JSONObject header = new JSONObject();
                header.put("statusCode", "000");

                fullResult.put("isSuccessful", true);
                fullResult.put("header", header);

                fullResult.put("body", result);

            } else {
                fullResult.put("isSuccessful", false);

            }
            return fullResult;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


}
