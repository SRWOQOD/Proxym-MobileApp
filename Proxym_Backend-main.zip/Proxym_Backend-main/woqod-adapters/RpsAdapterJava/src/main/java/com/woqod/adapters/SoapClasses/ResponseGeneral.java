package com.woqod.adapters.SoapClasses;

public class ResponseGeneral {
  public String ResponseCode;
  public String ResponseMessage;
}
