package com.woqod.adapters.SoapClasses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TsalesTransactions {

    @JsonProperty("RecID")
    private String recID;
    @JsonProperty("StationCode")
    private String stationCode;
    @JsonProperty("StationName")
    private String stationName;
    @JsonProperty("CustomerORACLE_ID")
    private String customerORACLE_ID;
    @JsonProperty("CustomerCode")
    private String customerCode;
    @JsonProperty("CustomerName")
    private String customerName;
    @JsonProperty("FleetCode")
    private String fleetCode;
    @JsonProperty("FleetName")
    private String fleetName;
    @JsonProperty("SaleEnd")
    private String saleEnd;
    @JsonProperty("LicensePlateNr")
    private String licensePlateNr;
    @JsonProperty("Total")
    private String total;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("RowOrder")
    private String rowOrder;

}
