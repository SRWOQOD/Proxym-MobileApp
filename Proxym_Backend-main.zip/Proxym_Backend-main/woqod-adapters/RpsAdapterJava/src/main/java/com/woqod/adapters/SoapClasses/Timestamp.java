package com.woqod.adapters.SoapClasses;

import java.time.Instant;
import java.util.Date;

public class Timestamp {
  public Instant Created;
  public Instant Expires;
  public String Id;
  public String text;
}
