package com.woqod.adapters.SoapClasses;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Envelope {
  public Header Header;
  @JsonProperty("Body")
  public Body body;
 /* public String soap;
  public String xsi;
  public String xsd;
  public String wsa;
  public String wsse;
  public String wsu;
  public String text;*/

}
