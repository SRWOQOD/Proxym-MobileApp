package com.woqod.adapters.SoapClasses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Header {
  public String Action;
  public String MessageID;
  public String RelatesTo;
  public String To;
 // public Security Security;
}
