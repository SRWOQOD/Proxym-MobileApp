package com.woqod.adapters.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.ibm.json.java.JSONObject;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by Kais Elouragini on 26/04/2016.
 */
public class CommonUtils {

  static String GET = "GET";
  static String POST = "POST";
  static String PUT = "PUT";
  static String DELETE = "DELETE";

  public static void buildHeaders(HttpRequestBase httpRequest, JSONObject headers) {
    // Adding Request Headers
    try {
      if (null != headers) {
        for (Object key : headers.keySet()) {
          httpRequest.setHeader(String.valueOf(key), String.valueOf(headers.get(key)));
        }
      }
    } catch (Exception e) {
      //System.out.println("Parsing Headers Exception : " + e.getMessage());
    }
  }

  public static String buildUri(String protocol, String host, String path, String method, JSONObject headers, JSONObject queryParams) {
    try {

      URIBuilder uriBuilder = new URIBuilder()
        .setScheme(protocol)
        .setHost(host)
        .setPath(path);


      // Adding Query Params
      try {
        if (null != queryParams) {
          for (Object key : queryParams.keySet()) {
            uriBuilder.setParameter(String.valueOf(key), String.valueOf(queryParams.get(key)));
          }
        }
      } catch (Exception e) {
        //System.out.println("Parsing Headers Exception : " + e.getMessage());
      }

      String encodedURL = uriBuilder.build().toString();
      //System.out.println("encodedURL=" + encodedURL);
      return URIUtil.encodeQuery(encodedURL, "UTF-8");

    } catch (Exception e) {
      return null;
    }
  }

  public static JSONObject callWS(String protocol, String host, String path, String method, JSONObject headers) {
    return callWS(protocol, host, path, method, headers, null, null, null);
  }

  /**
   * Common WS caller
   *
   * @param protocol
   * @param host
   * @param path
   * @param method
   * @param headers
   * @param urlParams
   * @param queryParams
   * @return
   */
  public static JSONObject callWS(String protocol, String host, String path, String method, JSONObject headers, JSONObject urlParams, JSONObject queryParams, JSONObject bodyParams) {
    try {
      String url = buildUri(protocol, host, RequestGenerator.prepareUrlParams(path, urlParams), method, headers, queryParams);

      System.out.println(url);

      if (null != url) {

        HttpRequestBase httpRequestBase;
        if (GET.equals(method)) {
          httpRequestBase = new HttpGet(url);
        } else if (POST.equals(method)) {

          HttpPost httpPost = new HttpPost(url);
          if (null != bodyParams) {
            StringEntity postingString = new StringEntity(bodyParams.serialize());
            httpPost.setEntity(postingString);
          }
          httpRequestBase = httpPost;

        } else if (PUT.equals(method)) {
          HttpPut httpPut = new HttpPut(url);
          if (null != bodyParams) {
            StringEntity postingString = new StringEntity(bodyParams.serialize());
            httpPut.setEntity(postingString);
          }
          httpRequestBase = httpPut;
        } else if (DELETE.equals(method)) {
          httpRequestBase = new HttpDelete(url);
        } else {
          method = GET;
          httpRequestBase = new HttpGet(url);
          //System.out.println("Unsupported Method, using GET as default !");
        }

        buildHeaders(httpRequestBase, headers);
        HttpClient client = HttpClientBuilder.create().setSSLContext(SSLContexts.custom().setProtocol("TLSv1.2").build()).build();
        HttpResponse response = null;
        try {
          response = client.execute(httpRequestBase);

          StringBuilder sb = new StringBuilder();
          try {
            BufferedReader reader =
              new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = null;

            while ((line = reader.readLine()) != null) {
              sb.append(line);
            }
          } catch (IOException e) {
            e.printStackTrace();
          }
          JSONObject jsonResponse = JSONObject.parse(sb.toString());

//          System.out.println("jsonResponse ::::::::::: ");
//          System.out.println(jsonResponse);

          if (null != jsonResponse.get("header") && String.valueOf(JSONObject.parse(String.valueOf(jsonResponse.get("header"))).get("statusCode")).equals("000")) {
            return CommonUtils.replyToJson(jsonResponse);
          } else {
            return CommonUtils.errorHandler(jsonResponse);
          }
        } catch (Exception ee) {
          System.out.println("An error occurred when trying to execute url :"+url+" ***" + ee.getMessage());
          return CommonUtils.errorHandler(ee);
        }
      } else {
        return CommonUtils.errorHandler("An error occurred when trying build URI");
      }
    } catch (Exception e) {
      e.printStackTrace();
      return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
    }
  }

  /**
   * Hash a string SHA-1 + SALT
   *
   * @param passwordToHash
   * @param salt
   * @return
   */
  public static String sha1WithSalt(String passwordToHash, String salt) {
    String generatedPassword = null;
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-1");
      //md.update(salt.getBytes());
      passwordToHash += salt;
      byte[] bytes = md.digest(passwordToHash.getBytes());
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < bytes.length; i++) {
        sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
      }
      generatedPassword = sb.toString();
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return generatedPassword;
  }

  /**
   * Hash a string SHA-256 + SALT
   *
   * @param passwordToHash
   * @param salt
   * @return
   */
  public static String sha256WithSalt(String passwordToHash, String salt) {
    String generatedPassword = null;
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      //md.update(salt.getBytes());
      passwordToHash += salt;
      byte[] bytes = md.digest(passwordToHash.getBytes());
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < bytes.length; i++) {
        sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
      }
      generatedPassword = sb.toString();
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return generatedPassword;
  }

  /**
   * Get StackTrace as a String from Exception
   *
   * @param e
   * @return
   */
  public static String getStackTrace(Exception e) {
    try {

      // PRINT TO LOG - FOR DEVELOPEMENT
      e.printStackTrace();

      // THE FOLLOWING CODE IS FOR DEVELOMEPENT
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      e.printStackTrace(pw);

      return sw.toString();

      // TO BE ENABLED FOR PRODUCTION
      //return e.getMessage();
    } catch (Exception ex) {
      // WL Logger
      ex.printStackTrace();
      return "";
    }
  }

  /**
   * Get Current DateTime as String
   *
   * @return String
   */
  public static String getCurrentDateTimeStamp() {
    return new SimpleDateFormat("YYYYMMddHHmmssSSS").format(new Date());
  }

  /**
   * Global Error Handler
   *
   * @param message
   * @return JSONObject
   */
  public static JSONObject errorHandler(String message) {
    JSONObject invocationResult = new JSONObject();
    try {
      invocationResult.put("errors", message);
      invocationResult.put("isSuccessful", false);
      //System.out.println("An error has occurred and this the response : ");
      //System.out.println(invocationResult.toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    return invocationResult;
  }


  public static JSONObject errorHandler(Object response) {
    try {
      JSONObject invocationResult = CommonUtils.objectToJson(response);
      //System.out.println("An error has occurred and this the response : ");
      //System.out.println(invocationResult.toString());
      invocationResult.put("isSuccessful", false);
      return invocationResult;
    } catch (Exception e) {
      return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
    }
  }

  /**
   * Convert Object to JSON
   *
   * @param source
   * @return com.ibm.json.java.JSONObject
   */
  @SuppressWarnings("unchecked")
  public static JSONObject objectToJson(Object source) {
    JSONObject result = new JSONObject();
    try {
      ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
      String json = ow.writeValueAsString(source);
      result = JSONObject.parse(json);
      return result;

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }


  }

  /**
   * Rely To Json
   *
   * @param response
   * @return JSONObject
   */
  public static JSONObject replyToJson(Object response) {

    try {
      JSONObject invocationResult = CommonUtils.objectToJson(response);
      invocationResult.put("isSuccessful", true);
      return invocationResult;
    } catch (Exception e) {
      return CommonUtils.errorHandler(CommonUtils.getStackTrace(e));
    }
  }

  /**
   * Convert String as "YYYY-MM-DD" to XMLGregorianCalendar
   *
   * @param s
   * @return XMLGregorianCalendar
   */
  public static XMLGregorianCalendar stringToXMLGregorianCalendar(String s) {
    try {
      Date dob = null;
      DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
      dob = df.parse(s + " 00:00:00");
      GregorianCalendar cal = new GregorianCalendar();

      cal.setTime(dob);
      XMLGregorianCalendar xmlDate2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), dob.getHours(), dob.getMinutes(), dob.getSeconds(), DatatypeConstants.FIELD_UNDEFINED, cal.getTimeZone().LONG).normalize();
      //XMLGregorianCalendar xmlDate3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH),dob.getHours(),dob.getMinutes(),dob.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
      return xmlDate2;
    } catch (Exception e) {
      CommonUtils.getStackTrace(e);
      return null;
    }
  }


  /**
   * Get StackTrace as a String from Exception
   *
   * @param e
   * @return
   */
  public static String getStackTrace(Error e) {
    try {

      // PRINT TO LOG - FOR DEVELOPEMENT
      e.printStackTrace();

      // THE FOLLOWING CODE IS FOR DEVELOMEPENT
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      e.printStackTrace(pw);

      return sw.toString();

      // TO BE ENABLED FOR PRODUCTION
      //return e.getMessage();
    } catch (Exception ex) {
      // WL Logger
      ex.printStackTrace();
      return "";
    }
  }



  public static final String HMAC_SHA256 = "HmacSHA256";
  //public static final String SECRET_KEY = "794ee4d32c2e4860a5aada7e7d000556d9322d6abca346409556b310045612ae3941c4b62a8a47ec8691ba80ec677ecd40bd61d214054335811b20db2442a1c80f0bd8fa8a644c6b82251ebbf97f887b1f07a0cf34e144c2901202bb92ecc9f0d6e0deff9cfa4abfb0fc4ecf9bb3f35668d84011f6474772831a9a9c43697c63";
//  public static final String SECRET_KEY = "d226311ac0d14ac38cf1b22f8b672d92660fb15ed4de4296a7fed0cca9f88b7b075963b1b4a54ba4b752dfb6a4360ecbd6d8d179643742a9b9ba96da67e78e669cf0904d21b24df18fc3362f21dcb734eef4ebc079934fbbaa2b1dd59cc6b5925e43fc0326424b759936188320eccc7309024ec45202419a9541a920097677c5";
 // public static final String SECRET_KEY = "8f8474ac98b948a493d1a9ef79b36b733cd1ffb261eb484ca182658df62779d23eaa7db35f4b409ebddb0dece677b7802b5820df194444eead68706ab8fc23a6c26ff694b94247df91ab364d3248f015a91a4c9aaee8420e9edf79eeec2a82395bd414894ada4f239fc61bf62c1627efc484f888d77740a59ae921a8919d2088";
  public static final String SECRET_KEY = "e631050519f34f8096746b963ca8ab78c8a7d660fd954b91aaebebd186a3bf6e6067dd4f65a04a2b8909d3681654d49daf9eda21fc534802bfb210bd1043d78eccce3695593c47d19aa49b018fd0410a3f7ab6a8ad1e4421ace6cd6489670ece9b8e826db11d4daeb75213d9412f7cfc3f18e8ee3d0c4ae9b0777424b4216369";

  public static String sign(String params) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
      return sign(params, SECRET_KEY);
  }

  public static String sign(String data, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
      SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), HMAC_SHA256);
      Mac mac = Mac.getInstance(HMAC_SHA256);
      mac.init(secretKeySpec);
      byte[] rawHmac = mac.doFinal(data.getBytes("UTF-8"));
      return DatatypeConverter.printBase64Binary(rawHmac).replace("\n", "");
  }

  public static String buildDataToSign(HashMap params) {
      String[] signedFieldNames = String.valueOf(params.get("signed_field_names")).split(",");
      ArrayList<String> dataToSign = new ArrayList<String>();
      for (String signedFieldName : signedFieldNames) {
          dataToSign.add(signedFieldName + "=" + String.valueOf(params.get(signedFieldName)));
      }
      return commaSeparate(dataToSign);
  }

  public static String commaSeparate(ArrayList<String> dataToSign) {
      StringBuilder csv = new StringBuilder();
      for (Iterator<String> it = dataToSign.iterator(); it.hasNext(); ) {
          csv.append(it.next());
          if (it.hasNext()) {
              csv.append(",");
          }
      }
      return csv.toString();
  }

  public static String getUTCDateTime() {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
      sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
      return sdf.format(new Date());
  }


  public static String post(String url, String content) throws Exception{
      HttpClient client = new DefaultHttpClient();
      HttpPost post = new HttpPost(url);
      String xml = content;
      HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
      post.setEntity(entity);
      post.setHeader("Content-Type", "text/xml; charset=utf-8");
      HttpResponse response = client.execute(post);
      String result = EntityUtils.toString(response.getEntity());

      return result;
  }

  public static String postWithHeader(String url, String content) throws Exception{
    HttpClient client = new DefaultHttpClient();
    HttpPost post = new HttpPost(url);
    String xml = content;
    HttpEntity entity = new ByteArrayEntity(xml.getBytes("UTF-8"));
    post.setEntity(entity);
    post.setHeader("Content-Type", "text/xml; charset=utf-8");
    post.setHeader("SOAPAction", "http://tempuri.org/BalanceUpdate");
    HttpResponse response = client.execute(post);
    String result = EntityUtils.toString(response.getEntity());

    return result;
  }

  public static String generatepassword(String nonce, String created,
                                        String pwd) {
    try {
      byte[] nonceBytes = Base64.getDecoder().decode(nonce);
      byte[] createdBytes = created.getBytes("UTF-8");
      byte[] passwordBytes = pwd.getBytes("UTF-8");
      ByteArrayOutputStream outputStream =
        new ByteArrayOutputStream( );
      outputStream.write(nonceBytes);
      outputStream.write(createdBytes);
      outputStream.write(passwordBytes);
      byte[] concatenatedBytes = outputStream.toByteArray();
      MessageDigest digest = MessageDigest.getInstance( "SHA-1" );
      digest.update(concatenatedBytes, 0, concatenatedBytes.length);
      byte[] digestBytes = digest.digest();
      String digestString = Base64.getEncoder().encodeToString(digestBytes);


      System.out.println("Provided password digest is: "+digestString);
      System.out.println("   Nonce: "+nonce);
      System.out.println("   Timestamp: "+created);
      System.out.println("   Password: "+pwd);
      System.out.println("   Computed digest: "+digestString);

      return digestString;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }


}
