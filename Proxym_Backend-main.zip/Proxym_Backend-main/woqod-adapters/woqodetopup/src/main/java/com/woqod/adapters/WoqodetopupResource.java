/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.codec.digest.DigestUtils;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;
import java.util.logging.Logger;

@Path("/")
public class WoqodetopupResource {
    /*
     * For more info on JAX-RS see
     * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
     */

    static Logger logger = Logger.getLogger(WoqodetopupResource.class.getName());

    // Inject the MFP configuration API:
    @Context
    ConfigurationAPI configApi;

    public static final String QPAY_WOQODE_SECRET_KEY = "YWZhZjNhMjM5OTE5MzVlZGU3YWNhZmZh";
    private static final String[] QPAY_FAILED_STATUS_CODES_ARRAY = {"2799", "2992", "2993", "3000", "4003", "4004", "4100", "5019", "7000", "7001", "7002", "7003", "7004", "7005", "7006", "8000", "8005", "8006", "8007",
            "8008", "8009", "8010", "8011", "8012", "8100", "8101", "8102", "8103", "8104", "8105", "8107", "8108", "8109", "8200", "8201", "8203", "8204", "9001"};


    @POST
    @Path("/success")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject success(@ApiParam(value = "decision", required = false) @FormParam("decision") String decision,
                              @ApiParam(value = "req_transaction_uuid", required = false) @FormParam("req_transaction_uuid") String req_transaction_uuid,
                              @ApiParam(value = "auth_response", required = false) @FormParam("auth_response") String auth_response,
                              @ApiParam(value = "req_reference_number", required = false) @FormParam("req_reference_number") String req_reference_number,
                              @ApiParam(value = "req_amount", required = false) @FormParam("req_amount") String req_amount,
                              @ApiParam(value = "transaction_id", required = false) @FormParam("transaction_id") String transaction_id,
                              @ApiParam(value = "reason_code", required = false) @FormParam("reason_code") String reason_code,
                              @ApiParam(value = "auth_trans_ref_no", required = false) @FormParam("auth_trans_ref_no") String auth_trans_ref_no,
                              @ApiParam(value = "req_card_expiry_date", required = false) @FormParam("req_card_expiry_date") String req_card_expiry_date,
                              @ApiParam(value = "auth_amount", required = false) @FormParam("auth_amount") String auth_amount,
                              @ApiParam(value = "bill_trans_ref_no", required = false) @FormParam("bill_trans_ref_no") String bill_trans_ref_no,
                              @ApiParam(value = "req_card_type", required = false) @FormParam("req_card_type") String req_card_type,
                              @ApiParam(value = "payer_authentication_pares_status", required = false) @FormParam("payer_authentication_pares_status") String payer_authentication_pares_status,
                              @ApiParam(value = "req_profile_id", required = false) @FormParam("req_profile_id") String req_profile_id,
                              @ApiParam(value = "signed_date_time", required = false) @FormParam("signed_date_time") String signed_date_time,
                              @ApiParam(value = "req_bill_to_address_line1", required = false) @FormParam("req_bill_to_address_line1") String req_bill_to_address_line1,
                              @ApiParam(value = "req_bill_to_address_city", required = false) @FormParam("req_bill_to_address_city") String req_bill_to_address_city,
                              @ApiParam(value = "payer_authentication_xid", required = false) @FormParam("payer_authentication_xid") String payer_authentication_xid,
                              @ApiParam(value = "req_customer_ip_address", required = false) @FormParam("req_customer_ip_address") String req_customer_ip_address,
                              @ApiParam(value = "payer_authentication_validate_result", required = false) @FormParam("payer_authentication_validate_result") String payer_authentication_validate_result,
                              @ApiParam(value = "req_bill_to_address_country", required = false) @FormParam("req_bill_to_address_country") String req_bill_to_address_country,
                              @ApiParam(value = "req_bill_to_address_postal_code", required = false) @FormParam("req_bill_to_address_postal_code") String req_bill_to_address_postal_code,
                              @ApiParam(value = "req_payment_method", required = false) @FormParam("req_payment_method") String req_payment_method) {

        JSONObject response = new JSONObject();

        String AuthName = "WOQODUSERHDR";
        String AuthPass = "#W13O$#O2#%Q4D";
        String Origin = "WOQ-MOBILE";
        String ChannelID = "WOQ-MOBILE";

        String wsseUsername = "WSSECWOQOD";
        String wssePassword = "3O4D##W1#O2$%Q";

        logger.info("********** TOPUP BEGIN TRANSACTION **********");
        logger.info("Decision= " + decision + "**req_transaction_uuid= " + req_transaction_uuid + "**transaction_id= " + transaction_id + "**reason_code= " + reason_code + "**req_reference_number= " + req_reference_number + "**req_amount" + req_amount);

        Operation updateTransactionUUID = ApiConfig.operations.get("/payement/updateTransactionUUID");

        JSONObject updateTransactionUUIDQueryParams = new JSONObject();

        JSONObject res = new JSONObject();

        if (decision.equals("ACCEPT")) {

            Operation getTransaction = ApiConfig.operations.get("/payement/getTransaction");

            JSONObject getTransactionQueryParams = new JSONObject();

            getTransactionQueryParams.put("transactionID", req_transaction_uuid);

            JSONObject Transaction = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, getTransaction.url,
                    getTransaction.method, RequestGenerator.generateHeader(), null, getTransactionQueryParams, null);
            if (Transaction.get("isSuccessful").toString().equalsIgnoreCase("true")) {
                try {

                    JSONObject body, obj;
                    body = (JSONObject) Transaction.get("body");
                    obj = (JSONObject) body.get("result");

                    byte[] decodedBytes = java.util.Base64.getDecoder().decode(obj.get("qid").toString());
                    String decodedQid = new String(decodedBytes);

                    logger.info("update RPSIntegrationService begin :::::::: ");
                    String TransactionID, CivilMobileNumber, CivilID, BalanceIncreaseValue, transactionStatus;

                    TransactionID = req_transaction_uuid;
                    CivilMobileNumber = (String) obj.get("mobile");
                    CivilID = decodedQid ;
                    transactionStatus = obj.get("transactionStatus").toString();
                    logger.info("Transaction.transactionStatus=== " + obj.get("transactionStatus").toString());
                    if (!transactionStatus.equalsIgnoreCase("PAID") && !transactionStatus.equalsIgnoreCase("PAIED")) {

                        if (req_amount != null) {
                            BalanceIncreaseValue = req_amount;
                        } else {
                            BalanceIncreaseValue = obj.get("amount").toString().replace(".0", "");
                        }

                        res.put("TransactionID", TransactionID);
                        res.put("CivilMobileNumber", CivilMobileNumber);
                        res.put("CivilID", CivilID);
                        res.put("BalanceIncreaseValue", BalanceIncreaseValue);


                        String nonce = "q4j9LP3gI9QiDEL5HqHEew==";
                        String created = Instant.now().toString();
                        if (created.indexOf('.') != -1) {
                            created = created.substring(0, created.indexOf('.')) + "Z";
                        }
                        String expired = Instant.now().plus(5, ChronoUnit.MINUTES).toString();
                        if (expired.indexOf('.') != -1) {
                            expired = expired.substring(0, expired.indexOf('.')) + "Z";
                        }
                        String AuthName64 = Base64.getEncoder().encodeToString(AuthName.getBytes("utf-8"));
                        String AuthPass64 = Base64.getEncoder().encodeToString(AuthPass.getBytes("utf-8"));
                        String wsseUsername64 = Base64.getEncoder().encodeToString(wsseUsername.getBytes("utf-8"));
                        String rpsServiceURL = configApi.getPropertyValue("rpsServiceURL");
                        String WS_RPS_PATH = "RPSIntegrationService.asmx";
                        String PasswordDigest = CommonUtils.generatepassword(nonce, created, wssePassword);

                        String request = buildUpdateTopupSoapString(Origin, ChannelID, TransactionID, CivilMobileNumber, CivilID, BalanceIncreaseValue, nonce, created, expired, AuthName64, AuthPass64, wsseUsername64, rpsServiceURL, WS_RPS_PATH, PasswordDigest);

                        logger.info("updateBalanceRequest " + request);

                        String updateBalanceResponse = CommonUtils.postWithHeader(rpsServiceURL + WS_RPS_PATH, request);
                        logger.info("updateBalanceResponse " + updateBalanceResponse);
                        if (updateBalanceResponse.contains("<ResponseCode>1</ResponseCode>")) {
                            logger.info("update status to PAID :::::::: ");
                            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
                            updateTransactionUUIDQueryParams.put("statusEnum", "PAID");
                            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
                            updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
                            updateTransactionUUIDQueryParams.put("RPSStatus", "SUCCESS");
                            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);

                        } else if (updateBalanceResponse.indexOf("Timeout expired") != -1) {
                            logger.info("update status to INPROGRESS :::::::: ");
                            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
                            updateTransactionUUIDQueryParams.put("statusEnum", "ERROR");
                            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
                            updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
                            updateTransactionUUIDQueryParams.put("RPSStatus", "FAILED-Timeout expired");
                            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);
                            decision = "INPROGRESS";
                        } else {
                            /**
                             * Update status
                             **/
                            String errorCode = updateBalanceResponse.indexOf("<ResponseCode>") != -1 ? updateBalanceResponse.substring(updateBalanceResponse.indexOf("<ResponseCode>") + 14, updateBalanceResponse.indexOf("</ResponseCode>")) : "";
                            String errormessage = updateBalanceResponse.indexOf("<ResponseMessage>") != -1 ? updateBalanceResponse.substring(updateBalanceResponse.indexOf("<ResponseMessage>") + 17, updateBalanceResponse.indexOf("</ResponseMessage>")) : "";
                            if (errorCode.equalsIgnoreCase("BU2") || errormessage.equalsIgnoreCase("Duplicate Transaction")) {
                                logger.info("error Occured ->update status to DUPLICATED :::::::: ");
                                updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
                                updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
                                updateTransactionUUIDQueryParams.put("statusEnum", "PAID");
                                updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
                                updateTransactionUUIDQueryParams.put("RPSStatus", "FAILED-" + errorCode + "-" + errormessage);
                                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);
                            } else {

                                logger.info("error Occured ->update status to ERROR :::::::: ");
                                updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
                                updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
                                updateTransactionUUIDQueryParams.put("statusEnum", "ERROR");
                                updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
                                updateTransactionUUIDQueryParams.put("RPSStatus", "FAILED-" + errorCode + "-" + errormessage);
                                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);

                            }
                            decision = "INPROGRESS";
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.info("catch error Occured ->update status to ERROR :::::::: ");
                    updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
                    updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
                    updateTransactionUUIDQueryParams.put("statusEnum", "ERROR");
                    updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
                    updateTransactionUUIDQueryParams.put("RPSStatus", "FAILED-" + e.getMessage());
                    CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);
                    decision = "INPROGRESS";
                }
            } else {
                decision = "INPROGRESS";
            }
        } else if (decision.equals("DECLINE") && reason_code.equals("481")) {
            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
            updateTransactionUUIDQueryParams.put("statusEnum", "FAILED");
            updateTransactionUUIDQueryParams.put("authReversal", "DECLINE 481");
            updateTransactionUUIDQueryParams.put("RPSStatus", null);
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);


          /*  JSONObject authreversalQueryParams = new JSONObject();
            authreversalQueryParams.put("transactionId", req_transaction_uuid);
            Operation authreversal = ApiConfig.operations.get("/transactions/authReversal");
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, authreversal.url, authreversal.method, RequestGenerator.generateHeader(), null, authreversalQueryParams, null);
            logger.info("AuthReversal :::::::: fromDecline + error 481" + transaction_id);*/

        } else if (decision.equals("ERROR") && reason_code.equals("151")) {
            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
            updateTransactionUUIDQueryParams.put("statusEnum", "FAILED");
            updateTransactionUUIDQueryParams.put("authReversal", "ERROR 151");
            updateTransactionUUIDQueryParams.put("RPSStatus", null);
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);


          /*  JSONObject authreversalQueryParams = new JSONObject();
            authreversalQueryParams.put("transactionId", req_transaction_uuid);
            Operation authreversal = ApiConfig.operations.get("/transactions/authReversal");
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, authreversal.url, authreversal.method, RequestGenerator.generateHeader(), null, authreversalQueryParams, null);
            logger.info("AuthReversal :::::::: fromError + error 151" + transaction_id);*/

        } else if (decision.equals("REVIEW")) {
            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
            updateTransactionUUIDQueryParams.put("statusEnum", "FAILED");
            updateTransactionUUIDQueryParams.put("authReversal", "REVIEW");
            updateTransactionUUIDQueryParams.put("RPSStatus", null);
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);

           /* JSONObject authreversalQueryParams = new JSONObject();
            authreversalQueryParams.put("transactionId", req_transaction_uuid);
            Operation authreversal = ApiConfig.operations.get("/transactions/authReversal");
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, authreversal.url, authreversal.method, RequestGenerator.generateHeader(), null, authreversalQueryParams, null);
            logger.info("AuthReversal from Review :::::::: " + transaction_id);*/

        } else {
            logger.info("update status to FAILED :::::::: ");
            updateTransactionUUIDQueryParams.put("transactionUUID", req_transaction_uuid);
            updateTransactionUUIDQueryParams.put("transactionID", transaction_id);
            updateTransactionUUIDQueryParams.put("statusEnum", "FAILED");
            updateTransactionUUIDQueryParams.put("authReversal", "FALSE");
            updateTransactionUUIDQueryParams.put("RPSStatus", null);
            CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updateTransactionUUID.url, updateTransactionUUID.method, RequestGenerator.generateHeader(), null, updateTransactionUUIDQueryParams, null);
        }

        res.put("decision", decision);
        res.put("reference", req_reference_number);

        JSONObject body1 = new JSONObject();
        body1.put("result", res);

        response.put("header", null);
        response.put("body", body1);
        response.put("isSuccessful", true);
        logger.info("********** TOPUP END TRANSACTION **********");
        return response;

    }

    @ApiOperation(value = "Retrieve transaction", notes = "Retrieve transaction")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Send operation OK")})
    @POST
    @Path("/payement/retrieveTransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject retrieveTransaction(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {
        logger.info("TopUp retrieveTransaction!!!!!!!!!!!");
        Operation operation = ApiConfig.operations.get("/payement/retrieveTransaction");

        JSONObject queryParams = new JSONObject();
        queryParams.put("transactionUUID", transactionUUID);
        logger.info("queryParams::::::::::" + queryParams);
        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }

    @POST
    @Path("/qpay/success")
    @Produces(MediaType.APPLICATION_JSON)
    @OAuthSecurity(enabled = false)
    public JSONObject successQpayPayment(@ApiParam(value = "Response.Amount", required = true) @FormParam("Response.Amount") String amount,
                                         @ApiParam(value = "Response.CurrencyCode", required = true) @FormParam("Response.CurrencyCode") String currencyCode,
                                         @ApiParam(value = "Response.PUN", required = true) @FormParam("Response.PUN") String pun,
                                         @ApiParam(value = "Response.EZConnectResponseDate", required = true) @FormParam("Response.EZConnectResponseDate") String ezConnectResponseDate,
                                         @ApiParam(value = "Response.ConfirmationID", required = true) @FormParam("Response.ConfirmationID") String confirmationId,
                                         @ApiParam(value = "Response.MerchantModuleSessionID", required = true) @FormParam("Response.MerchantModuleSessionID") String merchantModuleSessionId,
                                         @ApiParam(value = "Response.Status", required = true) @FormParam("Response.Status") String status,
                                         @ApiParam(value = "Response.StatusMessage", required = true) @FormParam("Response.StatusMessage") String statusMessage,
                                         @ApiParam(value = "Response.MerchantID", required = true) @FormParam("Response.MerchantID") String merchantId,
                                         @ApiParam(value = "Response.BankID", required = true) @FormParam("Response.BankID") String bankId,
                                         @ApiParam(value = "Response.Lang", required = true) @FormParam("Response.Lang") String lang,
                                         @ApiParam(value = "Response.AcquirerID", required = true) @FormParam("Response.AcquirerID") String acquirerId,
                                         @ApiParam(value = "Response.ItemID", required = false) @FormParam("Response.ItemID") String itemId,
                                         @ApiParam(value = "Response.CardNumber", required = true) @FormParam("Response.CardNumber") String cardNumber,
                                         @ApiParam(value = "Response.CardExpiryDate", required = true) @FormParam("Response.CardExpiryDate") String cardExpiryDate,
                                         @ApiParam(value = "Response.CardHolderName", required = true) @FormParam("Response.CardHolderName") String cardHolderName,
                                         @ApiParam(value = "Response.AgentID", required = false) @FormParam("Response.AgentID") String agentId,
                                         @ApiParam(value = "Response.SecureHash", required = true) @FormParam("Response.SecureHash") String secureHash) throws UnsupportedEncodingException {

        logger.info("/******************************** BEGIN QPAY WOQODe TOPUP TRANSACTION ******************************/");

        logger.info("Amount= " + amount + "**CurrencyCode= " + currencyCode + "**PUN= " + pun + "**EZConnectResponseDate= " + ezConnectResponseDate
                + "**ConfirmationID= " + confirmationId + "**MerchantModuleSessionID= " + merchantModuleSessionId + "**Status= " + status + "**StatusMessage= " + statusMessage + "**MerchantID= " + merchantId + "**BankID= " + bankId
                + "**Lang= " + lang + "**AcquirerID= " + acquirerId + "**ItemID= " + itemId + "**CardNumber= " + cardNumber + "**CardExpiryDate= " + cardExpiryDate + "**CardHolderName= " + cardHolderName + "**AgentID= " + agentId + "**SecureHash= " + secureHash);

        String generatedSecureHash = "";
        String decision = "";
        String creationDate = "";
        JSONObject responses = new JSONObject();
        JSONObject res = new JSONObject();

        //Generate secure hash after receiving payment callback
        generatedSecureHash = secureHashGeneration(amount, currencyCode, pun, ezConnectResponseDate, confirmationId, merchantModuleSessionId, status, statusMessage, merchantId, bankId, lang, acquirerId, cardNumber, cardExpiryDate, cardHolderName, statusMessage);


        //Compare generated secure hash with received secure hash
        if (secureHash != null && !secureHash.equals(generatedSecureHash)) {
            status = "-3"; // transaction status code for tempered(secure hash not matching) qpay transaction
            statusMessage = "TAMPERED";  // transaction status message for tempered(secure hash not matching) qpay transaction
            decision = "INPROGRESS";
            logger.info("Received Secure Hash does not Equal generated Secure hash");
        } else {

            String AuthName = "WOQODUSERHDR";
            String AuthPass = "#W13O$#O2#%Q4D";
            String Origin = "WOQ-MOBILE";
            String ChannelID = "WOQ-MOBILE";

            String wsseUsername = "WSSECWOQOD";
            String wssePassword = "3O4D##W1#O2$%Q";

            logger.info("/*********************** WOQODE TOPUP QPAY CALLBACK  **********************/");

            Operation updatePUN = ApiConfig.operations.get("/payement/qpay/updateTopupQpayTransaction");

            JSONObject updateTransactionPUNQueryParams = new JSONObject();

            if (status != null && status.equals("0000")) {  // if transaction status is PAID

                // Retrieve transaction details from database 0
                Operation getTransaction = ApiConfig.operations.get("/payement/qpay/getTransaction");
                JSONObject getTransactionQueryParams = new JSONObject();
                getTransactionQueryParams.put("pun", pun);

                // call getTransaction WS
                JSONObject retrievedTransaction = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, getTransaction.url,
                        getTransaction.method, RequestGenerator.generateHeader(), null, getTransactionQueryParams, null);

                if (retrievedTransaction.get("isSuccessful").toString().equalsIgnoreCase("true")) {
                    logger.info("getTransaction : ");
                    try {

                        JSONObject body, obj;
                        body = (JSONObject) retrievedTransaction.get("body");
                        obj = (JSONObject) body.get("result");
                        logger.info("update RPSIntegrationService begin :::::::: ");
                        String TransactionID, CivilMobileNumber, CivilID, BalanceIncreaseValue, transactionStatus;
                        byte[] decodedBytes = java.util.Base64.getDecoder().decode(obj.get("qid").toString());
                        String decodedQid = new String(decodedBytes);
                        TransactionID = pun;
                        CivilMobileNumber = (String) obj.get("mobile");
                        CivilID = decodedQid;
                        transactionStatus = obj.get("transactionStatus").toString();
                        creationDate = obj.get("createdDate").toString();
                        logger.info("Transaction.transactionStatus=== " + obj.get("transactionStatus").toString());
                        logger.info("Transaction.creationDate=== " + obj.get("createdDate").toString());

                        // if transaction status is not PAID
                        if (!transactionStatus.equalsIgnoreCase("PAID") && !transactionStatus.equalsIgnoreCase("PAIED")) {

                            if (amount != null && !amount.contains(".0")) {
                                Double dividedValue = Double.valueOf(amount) / 100;
                                BalanceIncreaseValue = dividedValue.toString();
                            } else {
                                BalanceIncreaseValue = obj.get("amount").toString().replace(".0", "");
                            }

                            res.put("TransactionID", TransactionID);
                            res.put("CivilMobileNumber", CivilMobileNumber);
                            res.put("CivilID", CivilID);
                            res.put("BalanceIncreaseValue", BalanceIncreaseValue);


                            String nonce = "q4j9LP3gI9QiDEL5HqHEew==";
                            String created = Instant.now().toString();
                            if (created.indexOf('.') != -1) {
                                created = created.substring(0, created.indexOf('.')) + "Z";
                            }
                            String expired = Instant.now().plus(5, ChronoUnit.MINUTES).toString();
                            if (expired.indexOf('.') != -1) {
                                expired = expired.substring(0, expired.indexOf('.')) + "Z";
                            }
                            String AuthName64 = Base64.getEncoder().encodeToString(AuthName.getBytes("utf-8"));
                            String AuthPass64 = Base64.getEncoder().encodeToString(AuthPass.getBytes("utf-8"));
                            String wsseUsername64 = Base64.getEncoder().encodeToString(wsseUsername.getBytes("utf-8"));
                            String rpsServiceURL = configApi.getPropertyValue("rpsServiceURL");
                            String WS_RPS_PATH = "RPSIntegrationService.asmx";
                            String PasswordDigest = CommonUtils.generatepassword(nonce, created, wssePassword);

                            String request = buildUpdateTopupSoapString(Origin, ChannelID, TransactionID, CivilMobileNumber, CivilID, BalanceIncreaseValue, nonce, created, expired, AuthName64, AuthPass64, wsseUsername64, rpsServiceURL, WS_RPS_PATH, PasswordDigest);

                            logger.info("updateBalanceRequest :::" + request);
                            String updateBalanceResponse = CommonUtils.postWithHeader(rpsServiceURL + WS_RPS_PATH, request);
                            logger.info("updateBalanceResponse :::" + updateBalanceResponse);

                            if (updateBalanceResponse.contains("<ResponseCode>1</ResponseCode>")) {
                                logger.info("update status to PAID :::::::: ");
                                updateTransactionPUNQueryParams.put("pun", pun);
                                updateTransactionPUNQueryParams.put("statusEnum", "PAID");
                                updateTransactionPUNQueryParams.put("transactionID", pun);
                                updateTransactionPUNQueryParams.put("RPSStatus", "SUCCESS");
                                updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                                updateTransactionPUNQueryParams.put("statusCode", status);
                                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                                decision = "ACCEPT";
                            } else if (updateBalanceResponse.contains("Timeout expired")) {
                                logger.info("update status to INPROGRESS :::::::: ");
                                updateTransactionPUNQueryParams.put("pun", pun);
                                updateTransactionPUNQueryParams.put("statusEnum", "ERROR");
                                updateTransactionPUNQueryParams.put("transactionID", pun);
                                updateTransactionPUNQueryParams.put("RPSStatus", "FAILED-Timeout expired");
                                updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                                updateTransactionPUNQueryParams.put("statusCode", status);
                                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                                decision = "INPROGRESS";
                            } else {
                                /**
                                 * Update status
                                 **/
                                String errorCode = updateBalanceResponse.contains("<ResponseCode>") ? updateBalanceResponse.substring(updateBalanceResponse.indexOf("<ResponseCode>") + 14, updateBalanceResponse.indexOf("</ResponseCode>")) : "";
                                String errormessage = updateBalanceResponse.contains("<ResponseMessage>") ? updateBalanceResponse.substring(updateBalanceResponse.indexOf("<ResponseMessage>") + 17, updateBalanceResponse.indexOf("</ResponseMessage>")) : "";
                                if (errorCode.equalsIgnoreCase("BU2") || errormessage.equalsIgnoreCase("Duplicate Transaction")) {
                                    logger.info("error Occured ->update status to DUPLICATED :::::::: ");
                                    updateTransactionPUNQueryParams.put("pun", pun);
                                    updateTransactionPUNQueryParams.put("transactionID", pun);
                                    updateTransactionPUNQueryParams.put("statusEnum", "PAID");
                                    updateTransactionPUNQueryParams.put("RPSStatus", "FAILED-" + errorCode + "-" + errormessage);
                                    updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                                    updateTransactionPUNQueryParams.put("statusCode", status);
                                    CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                                } else {

                                    logger.info("error Occured ->update status to ERROR :::::::: ");
                                    updateTransactionPUNQueryParams.put("pun", pun);
                                    updateTransactionPUNQueryParams.put("transactionID", pun);
                                    updateTransactionPUNQueryParams.put("statusEnum", "ERROR");
                                    updateTransactionPUNQueryParams.put("RPSStatus", "FAILED-" + errorCode + "-" + errormessage);
                                    updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                                    updateTransactionPUNQueryParams.put("statusCode", status);
                                    CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                                }
                                decision = "INPROGRESS";
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.info("catch error Occured ->update status to ERROR :::::::: ");
                        updateTransactionPUNQueryParams.put("pun", pun);
                        updateTransactionPUNQueryParams.put("transactionID", pun);
                        updateTransactionPUNQueryParams.put("statusEnum", "ERROR");
                        updateTransactionPUNQueryParams.put("RPSStatus", "FAILED-" + e.getMessage());
                        updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                        updateTransactionPUNQueryParams.put("statusCode", status);
                        CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                        decision = "INPROGRESS";
                    }
                } else {
                    decision = "INPROGRESS";
                }
            } else if (status != null && Arrays.asList(QPAY_FAILED_STATUS_CODES_ARRAY).contains(status)) {
                updateTransactionPUNQueryParams.put("pun", pun);
                updateTransactionPUNQueryParams.put("transactionID", pun);
                updateTransactionPUNQueryParams.put("statusEnum", "FAILED");
                updateTransactionPUNQueryParams.put("RPSStatus", null);
                updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                updateTransactionPUNQueryParams.put("statusCode", status);
                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                decision = "FAILED";

            } else if (status != null && (status.equals("2994") || status.equals("2996") || status.equals("2997"))) {
                updateTransactionPUNQueryParams.put("pun", pun);
                updateTransactionPUNQueryParams.put("transactionID", pun);
                updateTransactionPUNQueryParams.put("statusEnum", "CANCELED");
                updateTransactionPUNQueryParams.put("RPSStatus", "CANCELED");
                updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                updateTransactionPUNQueryParams.put("statusCode", status);
                decision = "CANCEL";
                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
            } else {
                logger.info("update status to FAILED :::::::: ");
                updateTransactionPUNQueryParams.put("pun", pun);
                updateTransactionPUNQueryParams.put("transactionID", pun);
                updateTransactionPUNQueryParams.put("statusEnum", "FAILED");
                updateTransactionPUNQueryParams.put("RPSStatus", null);
                updateTransactionPUNQueryParams.put("statusCode", status);
                updateTransactionPUNQueryParams.put("statusMessage", new String(statusMessage.getBytes(), StandardCharsets.UTF_8));
                CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, updatePUN.url, updatePUN.method, RequestGenerator.generateHeader(), null, updateTransactionPUNQueryParams, null);
                decision = "FAILED";
            }
        }

        res.put("decision", decision);
        res.put("pun", pun);
        res.put("statusMessage", statusMessage);
        res.put("statusCode", status);
        res.put("responseDate", creationDate);
        res.put("amount", amount);

        JSONObject body1 = new JSONObject();
        body1.put("result", res);

        responses.put("header", null);
        responses.put("body", body1);
        responses.put("isSuccessful", true);
        return responses;
    }

    private String secureHashGeneration(@FormParam("Response.Amount") @ApiParam(value = "Response.Amount", required = true) String amount, @FormParam("Response.CurrencyCode") @ApiParam(value = "Response.CurrencyCode", required = true) String currencyCode, @FormParam("Response.PUN") @ApiParam(value = "Response.PUN", required = true) String pun, @FormParam("Response.EZConnectResponseDate") @ApiParam(value = "Response.EZConnectResponseDate", required = true) String ezConnectResponseDate, @FormParam("Response.ConfirmationID") @ApiParam(value = "Response.ConfirmationID", required = true) String confirmationId, @FormParam("Response.MerchantModuleSessionID") @ApiParam(value = "Response.MerchantModuleSessionID", required = true) String merchantModuleSessionId, @FormParam("Response.Status") @ApiParam(value = "Response.Status", required = true) String status, @FormParam("Response.StatusMessage") @ApiParam(value = "Response.StatusMessage", required = true) String statusMessage, @FormParam("Response.MerchantID") @ApiParam(value = "Response.MerchantID", required = true) String merchantId, @FormParam("Response.BankID") @ApiParam(value = "Response.BankID", required = true) String bankId, @FormParam("Response.Lang") @ApiParam(value = "Response.Lang", required = true) String lang, @FormParam("Response.AcquirerID") @ApiParam(value = "Response.AcquirerID", required = true) String acquirerId, @FormParam("Response.CardNumber") @ApiParam(value = "Response.CardNumber", required = true) String cardNumber, @FormParam("Response.CardExpiryDate") @ApiParam(value = "Response.CardExpiryDate", required = true) String cardExpiryDate, @FormParam("Response.CardHolderName") @ApiParam(value = "Response.CardHolderName", required = true) String cardHolderName, String encodedStatusMessage) throws UnsupportedEncodingException {
        JSONObject body, obj;

        // Now that we have the map, order it to generate secure hash and compare it with the received one
        StringBuilder responseOrderdString = new StringBuilder();

        //Retrieve QPay payment secret key
        Operation getQpayPaymentSecretKey = ApiConfig.operations.get("/getQpayPaymentSecretKey");

        JSONObject getQpayPaymentSecretKeyQueryParams = new JSONObject();
        getQpayPaymentSecretKeyQueryParams.put("name", "Woqode");

        //Call getQpayPaymentSecretKey WS
        JSONObject woqodeQpayPaymentSecretKey = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, getQpayPaymentSecretKey.url,
                getQpayPaymentSecretKey.method, RequestGenerator.generateHeader(), null, getQpayPaymentSecretKeyQueryParams, null);

        body = (JSONObject) woqodeQpayPaymentSecretKey.get("body");
        obj = (JSONObject) body.get("result");
        responseOrderdString.append((obj.get("secretKey").toString())).append((acquirerId == null) ? "" : acquirerId).append((amount == null) ? "" : amount).append((bankId == null) ? "" : bankId).append((cardExpiryDate == null) ? "" : cardExpiryDate).append((cardHolderName == null) ? "" : cardHolderName).append((cardNumber == null) ? "" : cardNumber)
                .append((confirmationId == null) ? "" : confirmationId).append((currencyCode == null) ? "" : currencyCode).append((ezConnectResponseDate == null) ? "" : ezConnectResponseDate).append((lang == null) ? "" : lang).append((merchantId == null) ? "" : merchantId).append((merchantModuleSessionId == null) ? "" : merchantModuleSessionId).append((pun == null) ? "" : pun).append((status == null) ? "" : status).append((lang != null && lang.equals("ar")) ? URLEncoder.encode(statusMessage, "UTF-8") : statusMessage.replace(' ', '+'));
        logger.info("Ordered Response :" + responseOrderdString);

        // Generate SecureHash with SHA256
        // Using DigestUtils from apache.commons.codes.jar Library
        return new
                String(DigestUtils.sha256Hex(responseOrderdString.toString()).getBytes());
    }

    private String buildUpdateTopupSoapString(String origin, String channelID, String transactionID, String civilMobileNumber, String civilID, String balanceIncreaseValue, String nonce, String created, String expired, String authName64, String authPass64, String wsseUsername64, String rpsServiceURL, String WS_RPS_PATH, String passwordDigest) {

        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<soap:Envelope\n" +
                "                xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" +
                "                xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                "                xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                "                xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\"\n" +
                "                xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"\n" +
                "                xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
                "                <soap:Header>\n" +
                "                   <AuthInfo xmlns=\"http://tempuri.org/\">" +
                "                      <AuthName>" + authName64 + "</AuthName>\n" +
                "                      <AuthPass>" + authPass64 + "</AuthPass>\n" +
                "                                </AuthInfo>\n" +
                "                                <wsa:Action>http://tempuri.org/BalanceUpdate\"</wsa:Action>\n" +
                "                                <wsa:MessageID>urn:uuid:" + UUID.randomUUID() + "</wsa:MessageID>\n" +
                "                                <wsa:ReplyTo>\n" +
                "                                    <wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address>\n" +
                "                                </wsa:ReplyTo>\n" +
                "                                <wsa:To>" + rpsServiceURL + WS_RPS_PATH + "</wsa:To>\n" +
                "                                <wsse:Security soap:mustUnderstand=\"1\">\n" +
                "                                   <wsu:Timestamp wsu:Id=\"Timestamp-" + UUID.randomUUID() + "\">\n" +
                "                                              <wsu:Created>" + created + "</wsu:Created>\n" +
                "                                              <wsu:Expires>" + expired + "</wsu:Expires>\n" +
                "                                  </wsu:Timestamp>\n" +
                "                                  <wsse:UsernameToken xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" wsu:Id=\"SecurityToken-" + UUID.randomUUID() + "\">\n" +
                "                                        <wsse:Username>" + wsseUsername64 + "</wsse:Username>\n" +
                "                                        <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">" + passwordDigest + "</wsse:Password>\n" +
                "                                        <wsse:Nonce>" + nonce + "</wsse:Nonce>\n" +
                "                                        <wsu:Created>" + created + "</wsu:Created>\n" +
                "                                  </wsse:UsernameToken>\n" +
                "                                </wsse:Security>\n" +
                "</soap:Header>" +
                "<soap:Body>" +
                "<BalanceUpdate xmlns=\"http://tempuri.org/\">\n" +
                //<Origin>WOQ-WEB</Origin><ChannelID>WPS</ChannelID>
                "<CivilID>" + civilID + "</CivilID>" +
                "<CivilMobileNumber>" + civilMobileNumber + "</CivilMobileNumber>" +
                "<BalanceIncreaseValue>" + balanceIncreaseValue + "</BalanceIncreaseValue>" +
                "<TransactionID>" + transactionID + "</TransactionID>" +
                "<Origin>" + origin + "</Origin>" +
                "<ChannelID>" + channelID + "</ChannelID>" +
                "</BalanceUpdate>" +
                "</soap:Body>" +
                "</soap:Envelope>";
    }


    /**
     * @param pun
     * @param statusCode
     * @param statusMessage
     * @param statusEnum
     * @return
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/updatePun")
    @OAuthSecurity(enabled = false)
    public JSONObject updatePun(
            @ApiParam(value = "pun", required = true) @FormParam("pun") String pun,
            @ApiParam(value = "statusCode", required = true) @FormParam("statusCode") String statusCode,
            @ApiParam(value = "statusMessage", required = true) @FormParam("statusMessage") String statusMessage,
            @ApiParam(value = "statusEnum", required = true) @FormParam("statusEnum") String statusEnum) {

        Operation operation = ApiConfig.operations.get("/updatePun");

        JSONObject queryParams = new JSONObject();
        queryParams.put("pun", pun);
        queryParams.put("statusEnum", statusEnum);
        queryParams.put("statusCode", statusCode);
        queryParams.put("statusMessage", statusMessage);
        queryParams.put("transactionID", pun);
        queryParams.put("RPSStatus", statusEnum);

        return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
    }
}
