/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/")
public class JobCardPaymentResource {
  /*
   * For more info on JAX-RS see
   * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
   */

  // Inject the MFP configuration API:
  @Context
  ConfigurationAPI configApi;

  @POST
  @Path("/jctransactionlog/success")
  @Produces(MediaType.APPLICATION_JSON)
  @OAuthSecurity(enabled = false)
  public JSONObject successFJobCardPayment(@ApiParam(value = "decision", required = false) @FormParam("decision") String decision,
                                           @ApiParam(value = "req_transaction_uuid", required = false) @FormParam("req_transaction_uuid") String req_transaction_uuid,
                                           @ApiParam(value = "auth_response", required = false) @FormParam("auth_response") String auth_response,
                                           @ApiParam(value = "req_reference_number", required = false) @FormParam("req_reference_number") String req_reference_number,
                                           @ApiParam(value = "req_amount", required = false) @FormParam("req_amount") String req_amount,
                                           @ApiParam(value = "transaction_id", required = false) @FormParam("transaction_id") String transaction_id,
                                           @ApiParam(value = "reason_code", required = false) @FormParam("reason_code") String reason_code) {
    System.out.println("********** BEGIN JobCard TRANSACTION **********");

    System.out.println("Decision= "+ decision+"**req_transaction_uuid= "+req_transaction_uuid+"**transaction_id= "+transaction_id+"**reason_code= "+reason_code+"**req_reference_number= "+req_reference_number+"**req_amount"+req_amount);


    Operation operation = ApiConfig.operations.get("/jctransactionlog/success");

    JSONObject queryParams = new JSONObject();

    queryParams.put("decision", decision);
    queryParams.put("transactionUUID", req_transaction_uuid);
    queryParams.put("transaction_id", transaction_id);
    queryParams.put("reason_code", reason_code);

    JSONObject responseBE = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    JSONObject body, object = new JSONObject();
    body = (JSONObject) responseBE.get("body");
    object = (JSONObject) body.get("object");

    JSONObject response = new JSONObject();
    response.put("decision", decision);
    response.put("transactionUUID", req_transaction_uuid);
    response.put("success", true);
    response.put("status", 200);
    System.out.println("********** END JobCard TRANSACTION **********");
    return response;

  }

  @ApiOperation(value = "Retrieve transaction", notes = "Retrieve transaction")
  @ApiResponses(value = {@ApiResponse(code = 200, message = "Send operation OK")})
  @POST
  @Path("/jctransactionlog/retrieveTransaction")
  @Produces(MediaType.APPLICATION_JSON)
  @OAuthSecurity(enabled = false)
  public JSONObject retrieveTransaction(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {
    System.out.println("Jobcard retrieveTransaction!!!!!!!!!!!");
    Operation operation = ApiConfig.operations.get("/jctransactionlog/retrieveTransaction");

    JSONObject queryParams = new JSONObject();
    queryParams.put("transactionUUID", transactionUUID);
    System.out.println("queryParams::::::::::" + queryParams);
    return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
  }
}
