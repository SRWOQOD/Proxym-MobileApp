/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package com.woqod.adapters;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.adapter.api.ConfigurationAPI;
import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.woqod.adapters.config.ApiConfig;
import com.woqod.adapters.config.Operation;
import com.woqod.adapters.utils.CommonUtils;
import com.woqod.adapters.utils.RequestGenerator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/")
public class FahesPaymentResource {
  /*
   * For more info on JAX-RS see
   * https://jax-rs-spec.java.net/nonav/2.0-rev-a/apidocs/index.html
   */

  // Inject the MFP configuration API:
  @Context
  ConfigurationAPI configApi;

  @POST
  @Path("/prtransactionlog/success")
  @Produces(MediaType.APPLICATION_JSON)
  @OAuthSecurity(enabled = false)
  public JSONObject successFahesPayment(@ApiParam(value = "decision", required = false) @FormParam("decision") String decision,
                                        @ApiParam(value = "req_transaction_uuid", required = false) @FormParam("req_transaction_uuid") String req_transaction_uuid,
                                        @ApiParam(value = "auth_response", required = false) @FormParam("auth_response") String auth_response,
                                        @ApiParam(value = "req_reference_number", required = false) @FormParam("req_reference_number") String req_reference_number,
                                        @ApiParam(value = "req_amount", required = false) @FormParam("req_amount") String req_amount,
                                        @ApiParam(value = "transaction_id", required = false) @FormParam("transaction_id") String transaction_id,
                                        @ApiParam(value = "reason_code", required = false) @FormParam("reason_code") String reason_code,
                                        @ApiParam(value = "auth_trans_ref_no", required = false) @FormParam("auth_trans_ref_no") String auth_trans_ref_no,
                                        @ApiParam(value = "req_card_expiry_date", required = false) @FormParam("req_card_expiry_date") String req_card_expiry_date,
                                        @ApiParam(value = "auth_amount", required = false) @FormParam("auth_amount") String auth_amount,
                                        @ApiParam(value = "bill_trans_ref_no", required = false) @FormParam("bill_trans_ref_no") String bill_trans_ref_no,
                                        @ApiParam(value = "req_card_type", required = false) @FormParam("req_card_type") String req_card_type,
                                        @ApiParam(value = "payer_authentication_pares_status", required = false) @FormParam("payer_authentication_pares_status") String payer_authentication_pares_status,
                                        @ApiParam(value = "req_profile_id", required = false) @FormParam("req_profile_id") String req_profile_id,
                                        @ApiParam(value = "signed_date_time", required = false) @FormParam("signed_date_time") String signed_date_time,
                                        @ApiParam(value = "req_bill_to_address_line1", required = false) @FormParam("req_bill_to_address_line1") String req_bill_to_address_line1,
                                        @ApiParam(value = "req_bill_to_address_city", required = false) @FormParam("req_bill_to_address_city") String req_bill_to_address_city,
                                        @ApiParam(value = "payer_authentication_xid", required = false) @FormParam("payer_authentication_xid") String payer_authentication_xid,
                                        @ApiParam(value = "req_customer_ip_address", required = false) @FormParam("req_customer_ip_address") String req_customer_ip_address,
                                        @ApiParam(value = "payer_authentication_validate_result", required = false) @FormParam("payer_authentication_validate_result") String payer_authentication_validate_result,
                                        @ApiParam(value = "req_bill_to_address_country", required = false) @FormParam("req_bill_to_address_country") String req_bill_to_address_country,
                                        @ApiParam(value = "req_bill_to_address_postal_code", required = false) @FormParam("req_bill_to_address_postal_code") String req_bill_to_address_postal_code) {

    System.out.println("********** BEGIN FAHES TRANSACTION **********");
    System.out.println("Decision= " + decision + "**req_transaction_uuid= " + req_transaction_uuid + "**transaction_id= " + transaction_id + "**reason_code= " + reason_code + "**req_reference_number= " + req_reference_number + "**req_amount" + req_amount);

    Operation operation = ApiConfig.operations.get("/prtransactionlog/success");

    JSONObject queryParams = new JSONObject();
    queryParams.put("decision", decision);
    queryParams.put("transactionUUID", req_transaction_uuid);
    queryParams.put("reason_code", reason_code);
    queryParams.put("transaction_id", transaction_id);


    JSONObject responseBE = CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);

    System.out.println("response === " + responseBE);
//    JSONObject body, object = new JSONObject();
//    body = (JSONObject) responseBE.get("body");
//    object = (JSONObject) body.get("object");
//    String reference = (String) object.get("reference");
//    String receipt = (String) object.get("receipt");
//
//
//    JSONObject response = new JSONObject();
//    response.put("decision", decision);
//    response.put("transactionUUID", req_transaction_uuid);
//    response.put("success", true);
//    response.put("status", 200);
//    response.put("reference", reference);
//    response.put("receipt", receipt);

    System.out.println("********** END FAHES TRANSACTION **********");
    return responseBE;

  }


  @ApiOperation(value = "Retrieve transaction", notes = "Retrieve transaction")
  @ApiResponses(value = {@ApiResponse(code = 200, message = "Send operation OK")})
  @Path("/prtransactionlog/retrieveTransaction")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @OAuthSecurity(enabled = false)
  public JSONObject retrieveTransaction(@ApiParam(value = "transactionUUID", required = true) @FormParam("transactionUUID") String transactionUUID) {
    System.out.println("fahes retrieveTransaction!!!!!!!!!!!");
    Operation operation = ApiConfig.operations.get("/prtransactionlog/retrieveTransaction");

    JSONObject queryParams = new JSONObject();
    queryParams.put("transactionUUID", transactionUUID);
    System.out.println("queryParams::::::::::" + queryParams);
    return CommonUtils.callWS(ApiConfig.protocol, ApiConfig.host, operation.url, operation.method, RequestGenerator.generateHeader(), null, queryParams, null);
  }
}
