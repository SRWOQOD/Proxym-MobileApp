package com.woqod.adapters.utils;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ConvertUtils {


  // Convert an object array to integer array.
  public static Integer[] objectArrayToIntegerArray(Object[] objectArray) {
    Integer[] intArray = new Integer[objectArray.length];

    for (int i = 0; i < objectArray.length; i++) {
      intArray[i] = (Integer) objectArray[i];
    }

    return intArray;
  }

  // Convert an object array to long array.
  public static Long[] objectArrayToLongArray(Object[] objectArray) {
    Long[] longArray = new Long[objectArray.length];

    for (int i = 0; i < objectArray.length; i++) {
      longArray[i] = new Long(String.valueOf(objectArray[i]));
    }

    return longArray;
  }

  // Convert an object array to long array.
  public static Long[] jsonArrayToLongArray(JSONArray jsonArray) {
    Long[] longArray = new Long[jsonArray.size()];

    for (int i = 0; i < jsonArray.size(); i++) {
      longArray[i] = new Long(String.valueOf(jsonArray.get(i)));
    }

    return longArray;
  }

  public static Object replaceNull(Object input) {
    return input == null ? "" : input;
  }

  // merging two maps
  public static Map<String, Object> mergeMaps(Map<String, Object>... maps) {
    Map<String, Object> map = new HashMap<String, Object>();

    for (Map<String, Object> objectMap : maps) {
      map.putAll(objectMap);
    }

    return map;
  }

  // convert string to json array: '11-12-2017' => [11,12,2017]
  public static JSONArray parseWoqodDate(Object source) {
    JSONArray jsonArray = new JSONArray();

    try {
    	//System.out.println("Try ::::: parseWoqodDate");
    	//System.out.println(source.toString());
    	if(source instanceof String) {
    		String string = (String) source;
        	//System.out.println(string);
        	if (string.contains("-")) {
        	      String[] parts = string.split("-");

        	      for (String part : parts) {
        	        jsonArray.add(Long.valueOf(part));
        	      } 
        	    }
    	}else {
    		jsonArray = getJsonObjectOrJsonArray(source);
    	}
     }catch(Exception ex) {
    	//System.out.println("Catch ::::: parseWoqodDate");
    } 

    return jsonArray;
  }
  
  public static JSONArray getJsonObjectOrJsonArray(Object object){
	    JSONArray jsonArray = new JSONArray();
	    if (object instanceof Map){
	        JSONObject jsonObject = new JSONObject();
	        jsonObject.putAll((Map)object);
	        jsonArray.add(jsonObject);
	    }
	    else if (object instanceof List){
	        jsonArray.addAll((List)object);
	    }
	    return jsonArray;
	}

  // convert string to long array: '11-12-2017' => [11,12,2017]
  public static Long[] parseWoqodDate2(Object source) {
    Long[] longs = new Long[3];
    
    //System.out.println("parseWoqodDate2");
    //System.out.println(source);
    
    JSONArray jsonArray = new JSONArray();	
    
    try {
    	//System.out.println("Try ::::: parseWoqodDate2");
	    	if(source instanceof String) {
	    		String string = (String) source;
		        if (string.contains("-")) {
		          String[] parts = string.split("-");
		          for (int i = 0; i < parts.length; i++) {
		            longs[i] = new Long(parts[i]);
		          }
		        }
	    	}else {
	    		jsonArray = getJsonObjectOrJsonArray(source);
	    		for (int i = 0; i < jsonArray.size(); i++) {
	    			longs[i] = new Long((Long) jsonArray.get(i));
	    		}
	    	}
	    }catch(Exception ex) {
	    	//System.out.println("Catch ::::: parseWoqodDate2");
	    }
    return longs;
  }

  // serialize string and convert to json array
  public static JSONArray stringToJsonArray(String string) {

    JSONArray jsonArray = new JSONArray();
    try {
      jsonArray = (JSONArray) JSONArray.parse(string);

    } catch (IOException e) {
      e.printStackTrace();
    }

    return jsonArray;
  }

}
