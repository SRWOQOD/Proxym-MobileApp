package com.woqod.adapters.config;


public class Operation {

  public String method;
  public String url;

  Operation(String method, String url) {
    this.method = method;
    this.url = url;
  }
}
