/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015, 2016. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/

package com.woqod.adapters;

import java.util.logging.Logger;

import com.ibm.mfp.adapter.api.MFPJAXRSApplication;
import com.woqod.adapters.config.ApiConfig;
import com.ibm.mfp.adapter.api.ConfigurationAPI;

import javax.ws.rs.core.Context;

public class WoqodetopupApplication extends MFPJAXRSApplication{

	static Logger logger = Logger.getLogger(WoqodetopupApplication.class.getName());
  // Inject the MFP configuration API:
  @Context
  ConfigurationAPI configurationAPI;  // Inject the MFP configuration API:


	protected void init() throws Exception {
		logger.info("Adapter initialized!");
    String host = configurationAPI.getPropertyValue("baseUrlHostName");
    String protocol = configurationAPI.getPropertyValue("baseUrlProtocol");

    ApiConfig.host = host != null ? host : ApiConfig.defaultHost;
    ApiConfig.protocol = protocol != null ? protocol : ApiConfig.defaultProtocol;
	}


	protected void destroy() throws Exception {
		logger.info("Adapter destroyed!");
	}


	protected String getPackageToScan() {
		//The package of this class will be scanned (recursively) to find JAX-RS resources.
		//It is also possible to override "getPackagesToScan" method in order to return more than one package for scanning
		return getClass().getPackage().getName();
	}
}
