package com.woqod.adapters.config;

import java.util.HashMap;

public class ApiConfig {

  public static String defaultProtocol = "http";
  public static String defaultHost = "10.97.14.35:8080/BE";

  public static String protocol = "http";
  public static String host = "10.97.14.35:8080/BE";

  public static HashMap<String, Operation> operations = createOperations();


  public static String protocolWSDL = "http";
  public static String hostWSDL = "10.99.104.191:82";

  private static HashMap<String, Operation> createOperations() {

    HashMap<String, Operation> operations = new HashMap<>();

    //Payment
    operations.put("/payement/getTransaction", new Operation("GET", "/payement/getTransaction"));
    operations.put("/payement/updateTransactionUUID", new Operation("PUT", "/payement/updateTransactionUUID"));

    operations.put("/RPSIntegrationService.asmx", new Operation("POST", "/RPSIntegrationService.asmx"));

    operations.put("/transactions/authReversal", new Operation("POST", "/transactions/authReversal"));

    // Topup Payment
    operations.put("/payement/success", new Operation("POST", "/payement/success"));

    //Fahes Payment
    operations.put("/prtransactionlog/success", new Operation("POST", "/prtransactionlog/success"));

    //JobCard Payment
    operations.put("/jctransactionlog/success", new Operation("POST", "/jctransactionlog/success"));

    //Topup confirm transaction
    operations.put("/payement/retrieveTransaction", new Operation("POST", "/payement/retrieveTransaction"));

    //JobCard confirm transaction
    operations.put("/jctransactionlog/retrieveTransaction", new Operation("POST", "/jctransactionlog/retrieveTransaction"));

    //Fahes confirm transaction
    operations.put("/prtransactionlog/retrieveTransaction", new Operation("POST", "/prtransactionlog/retrieveTransaction"));

    //WOOQODE
    operations.put("/transactionLog/receipt",new Operation("GET","/transactionLog/receipt"));
    operations.put("/transactionLog/sendMail",new Operation("POST","/transactionLog/sendMail"));

    // Qpay Payment
    operations.put("/payement/qpay/success", new Operation("POST", "/payement/qpay/success"));
    operations.put("/payement/qpay/getTransaction", new Operation("GET", "/payement/qpay/getTransaction"));
    operations.put("/payement/qpay/updateTopupQpayTransaction", new Operation("PUT", "/payement/qpay/updateTopupQpayTransaction"));
    operations.put("/updatePun", new Operation("PUT", "/payement/qpay/updateTopupQpayTransaction"));

    //get Qpay Payment secret key
    operations.put("/getQpayPaymentSecretKey", new Operation("GET", "/fahes/getQpayPaymentSecretKey"));

    return operations;
  }
}
