package com.woqod.adapters.utils;

import com.ibm.json.java.JSONObject;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;

import java.util.Map;

public class RequestGenerator {

  static String prepareUrlParams(String rawUrl, JSONObject urlParams) {
    String prepareUrl = rawUrl;
    if (null != urlParams) {
      for (Object key : urlParams.keySet()) {
        prepareUrl = prepareUrl.replace("{" + key + "}", String.valueOf(urlParams.get(key)));
      }
    }
    return prepareUrl;
  }

  public static String getUserId(AdapterSecurityContext securityContext) {

    AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();

    if (null != currentUser && null != currentUser.getAttributes().get("id")) {
      return String.valueOf(currentUser.getAttributes().get("id"));
    }

    return null;
  }


  public static String getUserName(AdapterSecurityContext securityContext) {

    AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();

    if (null != currentUser && null != currentUser.getAttributes().get("userName")) {
      return String.valueOf(currentUser.getAttributes().get("userName"));
    }

    return null;
  }

  public static Map<String, Object> getUserAttributes(AdapterSecurityContext securityContext) {

    AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();

    if (null != currentUser && null != currentUser.getAttributes()) {
      return currentUser.getAttributes();
    }

    return null;
  }


  public static Object getUserAttributeByKey(AdapterSecurityContext securityContext, String key) {

    AuthenticatedUser currentUser = securityContext.getAuthenticatedUser();

    if (null != currentUser && null != currentUser.getAttributes().get(key)) {
      return String.valueOf(currentUser.getAttributes().get(key));
    }

    return null;
  }

  private static JSONObject generateHeader(AdapterSecurityContext securityContext) {
    JSONObject headers = new JSONObject();
    headers.put("authorization", "Basic d29xb2Q6d29xb2Q=");
    headers.put("Content-Type", "application/json; charset=UTF-8");
    return headers;
  }

  public static JSONObject generateHeader() {

    return generateHeader(null);
  }

}
