package wq.woqod.dao.constants;

public class FilterConstants {
    public static final String TITLE="title";
    public static final String CREATION_DATE="creationDate";
    public static final String START_DATE="startDate";
    public static final String END_DATE="endDate";
    public static final String TYPE="type";

    public static final String PLATENUMBER = "plateNumber";
    public static final String ACTIVE = "active";
    public static final String PLATE_TYPE = "plateType";
    public static final String DATEFORMAT ="yyyy/MM/dd" ;
    public static final String USERNAME = "userName";
    public static final String USERNAME1 = "username";
    public static final String MANUFACTUER = "manufacturer";
    public static final String MODEL = "model";
    public static final String OWNER = "owner";
    public static final String DUE_DATE = "dueDate";
    public static final String VIN = "vin";
    public static final String YEAR = "year";
    public static final String ISWOQODEUSER = "isWoqodeUser";

    public static final String FEEDBACK = "feedback";
    public static final String CATEGORY = "category";
    public static final String SECTOR = "sector";
    public static final String CONNECTED = "connected";
    public static final String STATUS = "status";
    public static final String QID = "Qid";

    public static final String TRANSACTION_LOG_SRING = "TransactionLog";
    public static final String TRANSACTION_UUID_OP_SRING = "transactionUUIDOP";
    public static final String MOBILE_TRANSACTION_OP_SRING = "mobileTransactionOP";
    public static final String USER_IDOP_STRING = "userIDOP";
    public static final String QID_TRANSATION_OP_STRING = "qidTransactionOP";
    public static final String TRANSACTION_STATUS_OP_STRING = "transactionStatusOP";
    public static final String REFERENCE_NUMBER_OP_STRING = "referenceNumberOP";
    public static final String REFERENCE_NUMBER_STRING = "referenceNumber";
    public static final String CREATED_DATE_STRING = "createdDate";
    public static final String EQUAL_STRING = "equal";
    public static final String CONTAINS_STRING = "contains";
    public static final String TRANSACTION_UUID_STRING = "transactionUUID";
    public static final String QID_TRANSACTION_STRING = "qidTransaction";
    public static final String QID_TRANSACTION_LOG = "qid";
    public static final String TRANSACTION_STATUS = "transactionStatus";
    public static final String MOBILE_TRANSACTION_STRING = "mobileTransaction";
    public static final String USER_ID_STRING = "userID";
    public static final String CREATED_DATE_OP_STRING = "createdDateOP";

    public static final String DESCRIPTION="description";
    public static final String SEND_DATE_TO="sendDateTo";
    public static final String SEND_DATE_FROM="sendDateFrom";

    public static final String CONTENT="content";
    public static final String NOTIFICATION_TEMPLATE="NotificationTemplate";

    public static final String AMOUNT = "amount";
    public static final String CONRRENCY = "currency";
    public static final String PAYMENT_METHOD = "paymentMethod";
    public static final String MOBILE = "mobile";
    public static final String API_STATUS = "apiStatus";
    public static final String USER_ID = "userID";
    public static final String TRANSACTION_UUID = "transactionUUID";
    public static final String REFERENCE_NUMBER = "referenceNumber";
    public static final String TRANSACTION_ID = "transactionID";
    public static final String AUTH_RESERVAL = "authReversal";
    public static final String AUTH_RESERVAL_STATUS = "authReversalStatus";
    public static final String RPS_STATUS = "rpsStatus";
    public static final String SUCCESS = "SUCCESS";
    public static final String CREATED_DATE="createdDate";
    public static final String PUN = "pun";

    public static final String QID_PRG ="createdDate";
    public static final String DATE_CREATION="createdDate";
    public static final String PLATE_NUMBER="plateNumber";

    public static final String PROMOTIONS_ID="promotionsId";

    public static final String CATEGORY_ENUM="categoryEnum";
    public static final String BOND="bond";
    public static final String COLLECTON_DATE ="collectionDate";
    public static final String COLLECTON_DATE_FROM ="collectionDateFrom";
    public static final String COLLECTON_DATE_TO ="collectionDateTo";
    public static final String CLOSING_DATE_FROM ="closingDateFrom";
    public static final String CLOSING_DATE_TO ="closingDateTo";


    public static final String DATE = "date";
    public static final String EMAIL = "email";

}
