package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Account;

import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 11/17/2016.
 */
public interface AccountRepository extends JpaRepository<Account, Long> {

    Optional<Account> findOneByUsername(String userName);

}
