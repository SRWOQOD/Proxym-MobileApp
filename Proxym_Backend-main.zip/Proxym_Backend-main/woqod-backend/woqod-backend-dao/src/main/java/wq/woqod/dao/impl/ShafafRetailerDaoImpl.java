package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wq.woqod.dao.ShafafRetailerDao;
import wq.woqod.dao.entity.ShafafRetailer;
import wq.woqod.dao.repository.ShafafRetailerRepository;

import java.util.List;

/**
 * Created by med-taher.ben-torkia on 12/30/2016.
 */
@Component
public class ShafafRetailerDaoImpl implements ShafafRetailerDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(ShafafRetailerDaoImpl.class);

    private final ShafafRetailerRepository shafafRetailerRepository;

    @Autowired
    public ShafafRetailerDaoImpl(final ShafafRetailerRepository shafafRetailerRepository) {
        this.shafafRetailerRepository = shafafRetailerRepository;
    }

    @Override
    public List<ShafafRetailer> getAllShafafRetailers() {
        LOGGER.info("Find All Shafaf Retailers");
        return shafafRetailerRepository.findAll();
    }
}
