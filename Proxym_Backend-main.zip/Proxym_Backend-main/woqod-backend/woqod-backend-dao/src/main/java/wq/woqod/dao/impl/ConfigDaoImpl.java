package wq.woqod.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.ConfigDao;
import wq.woqod.dao.entity.Config;
import wq.woqod.dao.repository.ConfigRepository;

import javax.annotation.PostConstruct;

@Repository

public class ConfigDaoImpl implements ConfigDao {
    private final ConfigRepository configRepository;

    @Autowired
    public ConfigDaoImpl(ConfigRepository configRepository) {
        this.configRepository = configRepository;
    }

    @Override
    public void save(Config config) {
        try {
            configRepository.save(config);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("ConfigDaoImpl", ex);
        }
    }

    @Override
    public Config getConfigByProprety(String proprety) {

        return configRepository.getConfigByProprety(proprety);
    }

    @Override
    public void updateConfig(Config config) {
        configRepository.saveAndFlush(config);
    }


    @PostConstruct
    public void init() {
        if (configRepository.getConfigByProprety("hideResrvation") == null) {
            Config config = new Config();
            config.setProprety("hideResrvation");
            config.setValue(true);
            configRepository.save(config);
        }

        if (configRepository.getConfigByProprety("hideWoqodeTopupQpayRefund") == null) {
            Config config = new Config();
            config.setProprety("hideWoqodeTopupQpayRefund");
            config.setValue(true);
            configRepository.save(config);
        }

        if (configRepository.getConfigByProprety("hideFahesQpayPaymentRefund") == null) {
            Config config = new Config();
            config.setProprety("hideFahesQpayPaymentRefund");
            config.setValue(true);
            configRepository.save(config);
        }

    }
}