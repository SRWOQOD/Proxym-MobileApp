package wq.woqod.dao;

import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.AppTips;

import java.util.List;

public interface AppTipsDao {
    void save(AppTips adsBanner);

    List<AppTips> filter(MultiValueMap<String, String> parameters);

    AppTips getById(Long valueOf);

    void update(List<AppTips> list);

    void update(AppTips appTips);

    List<AppTips> getAppTips();

    Long count();

    void delete(Long id);
}
