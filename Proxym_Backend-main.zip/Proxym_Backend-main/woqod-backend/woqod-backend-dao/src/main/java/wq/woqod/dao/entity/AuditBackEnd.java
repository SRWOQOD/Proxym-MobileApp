package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = Constants.TABLE_AUDITBACKEND)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditBackEnd {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "encrypted_qid")
    private String qid;

    private Date creationDate;

    private String ip;

    private String service;

    private String userMessage;

    private String responseDescription;

    @Lob
    private String request;

    @Lob
    private String response;

}
