package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import wq.woqod.dao.entity.NewsHome;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface NewsDao {

    void save(NewsHome newsHome);

    void saveAndFlush(NewsHome newsHome);

    Page<NewsHome> filter(Pageable pageable, Map<String, String> parameters) throws ParseException;

    NewsHome getById(Long valueOf);

    void update(List<NewsHome> list);

    List<NewsHome> getNews();

    Page<NewsHome> getActiveNews(Pageable pageable);

    Long count();


    void delete(Long id);
}
