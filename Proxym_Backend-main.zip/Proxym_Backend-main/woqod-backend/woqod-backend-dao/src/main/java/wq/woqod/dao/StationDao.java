package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.FacilityStation;
import wq.woqod.dao.entity.ServiceStation;
import wq.woqod.dao.entity.Station;
import wq.woqod.resources.enumerations.StationCategoryEnum;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Created by med-taher.ben-torkia on 12/13/2016.
 */
public interface StationDao {

    Station getStationById(Long id);

    Station getStationByStationId(Long stationId);

    Optional<Station> getOptionalStationByStationId(Long stationId);

    List<Station> getAllstations();

    List<Station> getStationByCategory(StationCategoryEnum category);

    void createStations(List<Station> stations);

    Set<ServiceStation> getServicesByStation(Station station);

    Set<FacilityStation> getFacilitiesByStation(Station station);

    void updateServiceStations(Set<ServiceStation> serviceStations);

    Page<Station> getFilteredList(Pageable pageable, Predicate predicate, MultiValueMap<String, String> parameters);

    Optional<ServiceStation> getServiceStationById(Long id);

    Map<Integer, Double> findStationRatingByStation_Id(Long id);

}
