package wq.woqod.dao.impl;


import com.querydsl.core.types.Predicate;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.AreaAlreadyExistException;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.AreaDao;
import wq.woqod.dao.entity.Area;
import wq.woqod.dao.entity.QArea;
import wq.woqod.dao.repository.AreaRepository;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;


@Component
public class AreaDaoImpl implements AreaDao {

    private final AreaRepository areaRepository;

    public AreaDaoImpl(AreaRepository areaRepository) {
        this.areaRepository = areaRepository;
    }


    @Override
    public void saveAll(List<Area> list) {
        try {
            areaRepository.saveAll(list);
        } catch (Exception e) {
            throw new PersistingDataException("Area", e);
        }
    }

    @Override
    public void save(Area area) {
        try {
            if ((areaRepository.findByTitle(area.getTitle()) != null) || (areaRepository.findByArabicTitle(area.getArabicTitle()) != null))
            {
                throw new AreaAlreadyExistException(area.getTitle() + " " + area.getArabicTitle());
            }
            areaRepository.save(area);
        } catch (Exception e) {
            throw new PersistingDataException("Area", e);
        }
    }

    @Override
    public void saveBO(Area area) {
        Long lastId = areaRepository.getId();
        if ((areaRepository.findByTitle(area.getTitle()) != null) || (areaRepository.findByArabicTitle(area.getArabicTitle()) != null))
        {
            throw new AreaAlreadyExistException(area.getTitle() + " " + area.getArabicTitle());
        }
        area.setId(lastId != null ? lastId + 1 : 1);
        area.setIdArea(lastId != null ? Long.toString(lastId + 1) : "1");
        areaRepository.save(area);

    }

    @Override
    public void update(Area area) {
        Optional<Area> area1 = areaRepository.findById(area.getId());
        if (!area1.isPresent()) {
            throw new DataNotFoundException("Area", area.getTitle(), "Area");
        }
        try {
            areaRepository.save(area);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("Area", ex);
        }

    }

    @Override
    public List<Area> getAreas(String arabicTitle, String title) {
        Predicate title1 = null;
        Predicate arabicTitle1 = null;


        QArea qArea = QArea.area;

        if (title != null && !title.isEmpty()) {
            title1 = qArea.title.containsIgnoreCase(title);
        }

        if (arabicTitle != null && !arabicTitle.isEmpty()) {
            arabicTitle1 = qArea.arabicTitle.containsIgnoreCase(arabicTitle);
        }

        Predicate predicateArea = qArea.isNotNull()
                .and(title1)
                .and(arabicTitle1);
        return (List<Area>) areaRepository.findAll(predicateArea);
    }

    @Override
    public Area findbyId(String id) {
        return areaRepository.findAreaByIdArea(id);
    }

    @Override
    public Area findAreaById(Long id) {
        Optional<Area> area = areaRepository.findById(id);
        if (!area.isPresent()) {
            throw new DataNotFoundException("Area", "Null", "Area");
        }
        return area.get();
    }

    @Override
    public void checkArea(String areaNameAr, String areaNameEn) {
        if (areaNameAr != null && (areaRepository.findByArabicTitle(areaNameAr.trim()) != null) ) {
                throw new AreaAlreadyExistException(areaNameAr);
        }
        if (areaNameEn != null && (areaRepository.findByTitle(areaNameEn.trim()) != null)) {
                throw new AreaAlreadyExistException(areaNameEn);
        }
    }


    @Override
    public Page<Area> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate title = null;
        Predicate arabicTitle = null;


        QArea qArea = QArea.area;

        if (params.get("title") != null) {
            title = qArea.title.containsIgnoreCase(params.getFirst("title"));
        }

        if (params.get("arabicTitle") != null) {
            arabicTitle = qArea.arabicTitle.containsIgnoreCase(params.getFirst("arabicTitle"));
        }

        Predicate predicateArea = qArea.isNotNull()
                .and(title)
                .and(arabicTitle);
        return areaRepository.findAll(predicateArea, pageable);
    }

    @Override
    public Long count() {
        return areaRepository.count();
    }
}
