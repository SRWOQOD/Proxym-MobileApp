package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.User;
import wq.woqod.resources.enumerations.StatusEnum;
import wq.woqod.resources.enumerations.UserTypeEnum;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

/**
 * Created by bfitouri on 14/11/16.
 */
@Transactional
public interface UserDao {

    Page<User> all(Pageable pageable);

    User save(User user);

    List<User> save(List<User> employees);

    void update(User user);

    User getByQid(String qid);

    Optional<User> getUserByQid(String qid);

    Optional<User> getUserByQidAndMobileAndActive(String qid, String mobile);

    User getByUserNameAndUserType(String userName, UserTypeEnum userType);

    User getByUserNameAndStatusNot(String userName);

    User updateDeviceIdByUsername(String userName, String deviceId, String deviceType);

    User getByUserId(Long id);

    boolean checkExistanceByQidAndUserType(String qid, UserTypeEnum userType);

    boolean checkExistanceByEmailAndUserType(String email, UserTypeEnum userType);

    boolean checkExistanceByMobileAndUserType(String mobile, UserTypeEnum userType);

    boolean checkExistanceByUsernameAndUserType(String qid, UserTypeEnum userType);

    boolean exist(String userName);

    Page<User> getFiltredUsers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters);

    void deleteUserById(Long id, UserTypeEnum type);

    void deleteUser(Long id, UserTypeEnum type);

    void updateUserStatusById(Long id, StatusEnum status, UserTypeEnum type, String qid);

    User getByQidAndStatus(String qid, StatusEnum status);

    User getUserByEmail(String email);

    User getUserByPhoneNumber(String phone);

    User getByUsername(String username);

    User getUserDetailsByUsername(String username);

    BigInteger countUsers(String qid, String from, String to, boolean b);

    List<String> getAllDeviceUUIDByUserId(Long id);

    List<User> getusers(MultiValueMap<String, String> parameters);

    List<String > getDevicesForWoqodeUsers();

    Long getWoqodeUsers(String from, String to);

    List<String> getWoqodeUsersId();

    Long count();
}
