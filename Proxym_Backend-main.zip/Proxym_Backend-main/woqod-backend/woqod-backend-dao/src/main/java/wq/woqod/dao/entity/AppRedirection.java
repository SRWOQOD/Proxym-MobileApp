package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = Constants.TABLE_HOME_REDIRECTION)
@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
public class AppRedirection {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    @OneToMany(mappedBy = "appRedirection")
    private List<TopBanner> topBanner;
    @OneToMany(mappedBy = "appRedirection")
    private List<BusinessBanner> businessBanners;

    public AppRedirection(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
