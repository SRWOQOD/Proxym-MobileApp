package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

/**
 * Created by Meriam Mejri
 */
@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = Constants.TABLE_QIDCARD)
public class QidCard {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String side1;

    private String side2;


}
