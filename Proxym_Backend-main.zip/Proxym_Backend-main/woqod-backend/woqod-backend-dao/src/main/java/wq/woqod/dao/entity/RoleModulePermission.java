package wq.woqod.dao.entity;


import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by bfitouri on 14/11/16.
 */
@Entity
@Table(name = Constants.TABLE_ROLES_MODULE_PERMISSION)
public class RoleModulePermission implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id")
    private Role role;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "module_id")
    private Module module;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "feature_id")
    private Feature feature;

    @Column(name = "has_access")
    private boolean access;

    public RoleModulePermission() {
    }

    public RoleModulePermission(Feature feature, Module module, Role role) {
        this.feature = feature;
        this.module = module;
        this.role = role;
    }

    public RoleModulePermission(Feature feature, Module module, boolean access) {
        this.feature = feature;
        this.module = module;
        this.access = access;
    }

    public RoleModulePermission(Role role, Module module, Feature feature, boolean access) {
        this.role = role;
        this.module = module;
        this.feature = feature;
        this.access = access;
    }

    public RoleModulePermission(Long id, Role role, Module module, Feature feature, boolean access) {
        this.id = id;
        this.access = access;
        this.role = role;
        this.module = module;
        this.feature = feature;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Module getModule() {
        return module;
    }

    public Feature getFeature() {
        return feature;
    }

    public boolean isAccess() {
        return access;
    }

    public void setAccess(boolean access) {
        this.access = access;
    }
}
