package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.dao.entity.FeedbackProjection;
import wq.woqod.dao.entity.User;

import java.util.List;


/**
 * Created by med-taher.ben-torkia on 11/30/2016.
 */
public interface FeedbackDao {

    void save(Feedback feedback);

    Feedback findById(Long id);

    Feedback findByIdAndActiveStatus(Long id);

    Page<Feedback> getFiltredFeedbacks(Pageable pageable, MultiValueMap<String, String> parameters, User owner);

    void update(Feedback feedback);

    void deleteFeedback(Long id);

    Feedback getFeedbackByTicketNumber(String ticket);

    List<Feedback> findAllFeedbacks(MultiValueMap<String, String> parameters);

    Long count();
}
