package wq.woqod.dao.repository;


import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.dao.entity.Notification;
import wq.woqod.dao.entity.NotificationProjection;

import java.util.List;
import java.util.Optional;

public interface NotificationRepository extends JpaRepository<Notification, Long>,
        QuerydslPredicateExecutor<Notification> {

    Page<Notification> findAllByUser_UserNameOrderBySendDateDesc(String device, Pageable pageable);

    List<Notification> findAllByUser_UserNameOrderBySendDateDesc(String device);

    List<Notification> findAllByUniqueIdAndUser_UserName(String id,String name);

    List<Notification> findAllByStatusAndUser_UserName(Boolean status, String device);

    List<Notification> findAllByDeviceId(String device);

    List<Notification> findAllByDeviceIdAndSurvey_Id(String device, Long surveyId);

    List<Notification> findAllByFeedback(Feedback feedback);

    List<Notification> findAllBySurvey_IdAndUser_Id(Long surveyId, Long userid);

    @Query(value = "select n from Notification n GROUP BY n.uniqueId having n.user.id = ?1")
    List<Long> findAllForConnectedUser(Long userName);

    Optional<Notification> findByUniqueIdAndDeviceId(String unique, String device);

    @Query(value = "select n.ID, n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN  " +
            "from Notifications n " +
            "where n.TITLE_EN like  %:titleEn% and n.DESCRIPTION_EN like %:descriptionEn% " +
            "group by n.ID, n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN ",
            countQuery = "SELECT count(*) from (select n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN " +
                    "from Notifications n " +
                    "where n.TITLE_EN like  %:titleEn% and n.DESCRIPTION_EN like %:descriptionEn% " +
                    "group by n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN )",
            nativeQuery = true)
    Page<NotificationProjection> getNotifications(@Param("titleEn") String titleEn, @Param("descriptionEn") String descriptionEn, Pageable pageable);


    @Query(value = "select n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN  " +
            "from Notifications n " +
            "where n.TITLE_EN like  %:titleEn% and n.DESCRIPTION_EN like %:descriptionEn% " +
            "group by n.TITLE_EN, n.CREATED_DATE, n.DESCRIPTION_EN ", nativeQuery = true)
    List<NotificationProjection> getAllNotifications(@Param("titleEn") String titleEn, @Param("descriptionEn") String description);


}

