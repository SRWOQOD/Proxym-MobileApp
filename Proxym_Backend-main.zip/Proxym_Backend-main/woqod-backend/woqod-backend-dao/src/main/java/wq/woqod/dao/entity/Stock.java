package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.sql.Timestamp;

@Getter
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = Constants.TABLE_STOCK_PRICES)
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(name = "currency")
    private String currency;
    @Column(name = "bid")
    private String bid;
    @Column(name = "ask")
    private String ask;
    @Column(name = "change")
    private String change;
    @Column(name = "changePercent")
    private String changePercent;
    @Column(name = "last")
    private String last;
    @Column(name = "high")
    private String high;
    @Column(name = "low")
    private String low;
    @Column(name = "volume")
    private String volume;
    @Column(name = "previousClose")
    private String previousClose;
    @Column(name = "iSIN")
    private String iSIN;
    @Column(name = "symbol")
    private String symbol;
    @Column(name = "marketName")
    private String marketName;
    @Column(name = "noShares")
    private String noShares;
    @Column(name = "marketCap")
    private String marketCap;
    @Column(name = "open")
    private String open;
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Timestamp dateStock;


    private Stock(Stock.Builder builder) {
        this.id = builder.id;
        this.currency = builder.currency;
        this.bid = builder.bid;
        this.ask = builder.ask;
        this.change = builder.change;
        this.changePercent = builder.changePercent;
        this.last = builder.last;
        this.high = builder.high;
        this.low = builder.low;
        this.volume = builder.volume;
        this.previousClose = builder.previousClose;
        this.iSIN = builder.iSIN;
        this.symbol = builder.symbol;
        this.marketName = builder.marketName;
        this.noShares = builder.noShares;
        this.marketCap = builder.marketCap;
        this.open = builder.open;
        this.dateStock = builder.dateStock;
    }

    public static Stock.Builder newBuilder() {
        return new Stock.Builder();
    }

    public static class Builder {

        private Long id;
        private String currency;
        private String bid;
        private String ask;
        private String change;
        private String changePercent;
        private String last;
        private String high;
        private String low;
        private String volume;
        private String previousClose;
        private String iSIN;
        private String symbol;
        private String marketName;
        private String noShares;
        private String marketCap;
        private String open;
        private Timestamp dateStock;

        public Stock.Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Stock.Builder currency(String currency) {
            this.currency = currency;
            return this;
        }

        public Stock.Builder bid(String bid) {
            this.bid = bid;
            return this;
        }

        public Stock.Builder ask(String ask) {
            this.ask = ask;
            return this;
        }

        public Stock.Builder change(String change) {
            this.change = change;
            return this;
        }

        public Stock.Builder changePercent(String changePercent) {
            this.changePercent = changePercent;
            return this;
        }

        public Stock.Builder low(String low) {
            this.low = low;
            return this;
        }

        public Stock.Builder high(String high) {
            this.high = high;
            return this;
        }

        public Stock.Builder last(String last) {
            this.last = last;
            return this;
        }

        public Stock.Builder volume(String volume) {
            this.volume = volume;
            return this;
        }

        public Stock.Builder previousClose(String previousClose) {
            this.previousClose = previousClose;
            return this;
        }

        public Stock.Builder iSIN(String iSIN) {
            this.iSIN = iSIN;
            return this;
        }

        public Stock.Builder symbol(String symbol) {
            this.symbol = symbol;
            return this;
        }

        public Stock.Builder marketName(String marketName) {
            this.marketName = marketName;
            return this;
        }

        public Stock.Builder noShares(String noShares) {
            this.noShares = noShares;
            return this;
        }

        public Stock.Builder marketCap(String marketCap) {
            this.marketCap = marketCap;
            return this;
        }

        public Stock.Builder open(String open) {
            this.open = open;
            return this;
        }

        public Stock.Builder dateStock(Timestamp dateStock) {
            this.dateStock = dateStock;
            return this;
        }

        public Stock build() {
            return new Stock(this);
        }

    }
}