package wq.woqod.dao.repository;

import com.querydsl.core.types.dsl.StringPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import wq.woqod.dao.entity.Promotion;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/11/16.
 */
public interface PromotionRepository extends JpaRepository<Promotion, Long>, QueryByExampleExecutor<Promotion>, QuerydslPredicateExecutor<Promotion> {


    Optional<Promotion> findPromotionByPromotionId(Long promotionId);

    List<Promotion> findAll();

    @Override
    void deleteAll();


}