package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.FeedbackTemplate;


/**
 * The interface {@code FeedbackTemplateRepository} eases the management
 * of feedback template database operations
 *
 * @author Meriam.Mejri
 */
public interface FeedbackTemplateRepository extends JpaRepository<FeedbackTemplate, Long>, QuerydslPredicateExecutor<FeedbackTemplate> {

    FeedbackTemplate findByTitle(String title);
}
