package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.AdsBanner;
import wq.woqod.dao.entity.AppTips;

import java.util.List;
import java.util.Optional;

@Repository
public interface AppTipsRepository extends JpaRepository<AppTips, Long>, QuerydslPredicateExecutor<AppTips> {
    List<AppTips> findAllByActive(Boolean active);
    Optional<AppTips> findTopByOrderByOrderItemDesc();

}
