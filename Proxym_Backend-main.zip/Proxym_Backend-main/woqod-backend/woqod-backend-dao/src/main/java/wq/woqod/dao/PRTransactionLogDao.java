package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.PRTransactionLog;
import wq.woqod.dao.entity.Reservations;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

public interface PRTransactionLogDao {

    void createTransactionLog(PRTransactionLog transactionLog, String plateNumber);

    PRTransactionLog findByTransactionUUID(String transactionUUID);

    void updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus);

    PRTransactionLog update(PRTransactionLog transactionLog);

    List<PRTransactionLog> findAll(MultiValueMap<String, String> parameters);

    Page<PRTransactionLog> all(Pageable pageable);

    Page<PRTransactionLog> getFiltredTransactions(Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    BigDecimal getSum(String qid, String from, String to) throws ParseException;

    BigDecimal getSumCC(String qid, String from, String to) throws ParseException;

    BigDecimal getSumDC(String qid, String from, String to) throws ParseException;

    /**
     * find transaction before 10min
     **/
    public List<PRTransactionLog> findAllByCreatedDateBetween();

    SFResource getSFTrans(String qid, String from, String to) throws ParseException;
    /**
     * find transaction between now and given date
     **/
    public  List<PRTransactionLog> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException;

    List<PRTransactionLog> saveAll(List<PRTransactionLog> prTransactionLogs);

    Long count();
}
