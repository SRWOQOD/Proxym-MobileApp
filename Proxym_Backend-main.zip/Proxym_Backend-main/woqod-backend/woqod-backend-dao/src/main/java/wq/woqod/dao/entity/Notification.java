package wq.woqod.dao.entity;


import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.LangTagName;
import wq.woqod.resources.enumerations.PushNotifEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = Constants.TABLE_NOTIFICATION)
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Notification extends Auditable implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "title_ar")
    private String titleAr;
    @Column(name = "title_en")
    private String titleEn;
    @Column(name = "description_ar")
    private String descriptionAr;

    private String uniqueId;

    @Column(name = "description_en")
    private String descriptionEn;
    @Column(name = "send_date")
    private Date sendDate;
    @Column(name = "lang_tag_name", nullable = false)
    @Enumerated(EnumType.STRING)
    private LangTagName langTagName;

    private String deviceId;

    private String forwho;

    private Boolean isanswered;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User user;
    private Boolean status;
    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private PushNotifEnum type;

    @OneToOne
    @JoinColumn(name = "survey_id")
    private Survey survey;

    @OneToOne
    @JoinColumn(name = "feedback_id")
    private Feedback feedback;

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinTable(name = "notifications_device",
            joinColumns = @JoinColumn(name = "notifications_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "device_id", referencedColumnName = "id"))
    private List<Device> devices;

}
