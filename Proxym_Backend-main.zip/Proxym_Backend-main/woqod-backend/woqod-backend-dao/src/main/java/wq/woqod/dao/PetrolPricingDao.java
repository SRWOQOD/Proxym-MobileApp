package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Petrol;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/11/16.
 */
public interface PetrolPricingDao {

    List<Petrol> getAllPetrolPricing();

    Optional<Petrol> getPetrolByPetrolId(Long petrolId);

    void createPetrolPrices(List<Petrol> petrols);

    List<Petrol> getFilteredPrices(MultiValueMap<String, String> parameters);

}
