package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_APPTIPS)
public class AppTips {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String title ;

    private String titleArabic ;

    private String fileUrl ;

    private Boolean active ;

    private Long orderItem;

    private LocalDateTime creationDate;
}
