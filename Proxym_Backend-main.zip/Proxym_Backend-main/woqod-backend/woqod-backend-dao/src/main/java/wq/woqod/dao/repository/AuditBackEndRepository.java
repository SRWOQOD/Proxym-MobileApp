package wq.woqod.dao.repository;

import com.querydsl.core.types.dsl.StringPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import wq.woqod.dao.entity.AuditBackEnd;


public interface AuditBackEndRepository extends JpaRepository<AuditBackEnd, Long>, QuerydslPredicateExecutor<AuditBackEnd> {

}
