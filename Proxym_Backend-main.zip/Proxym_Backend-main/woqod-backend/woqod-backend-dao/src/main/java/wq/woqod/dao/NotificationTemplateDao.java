package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.NotificationTemplate;

import java.util.List;


public interface NotificationTemplateDao {
    Page<NotificationTemplate> findAll(Pageable pageable, MultiValueMap<String, String> parameters);

    void save(NotificationTemplate notificationTemplate);

    void update(NotificationTemplate notificationTemplate);

    void delete(Long id);

    NotificationTemplate findById(Long id);

    List<NotificationTemplate> getAllNotificationTemplates(MultiValueMap<String, String> parameters);

    Long count();
}
