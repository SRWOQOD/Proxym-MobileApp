package wq.woqod.dao;

import wq.woqod.dao.entity.FeedbackResponse;

import java.util.List;

public interface FeedbackResponseDao {

    void save(FeedbackResponse feedbackResponse);

    List<FeedbackResponse> getAllFeedBackResponse(String id);
}
