package wq.woqod.dao.entity;

import wq.woqod.commons.enumerations.TransactionStatusEnum;

import javax.persistence.*;

@Entity
@Table
public class TransactionLog extends Auditable {

    @Column(length = 1024)
    public String transactionSearchDescription;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    @Column(name = "encrypted_qid")
    private String qid;
    private String mobile;
    //private Date createdDate;
    @Column(unique = true)
    private String transactionUUID;
    private String transactionID;
    private String referenceNumber;
    private Double amount;
    private String currency;
    private String email;
    private String RPSStatus;
    private String authReversal;
    private String authReversalStatus;
    private String description;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum transactionStatus;

    public String getTransactionSearchDescription() {
        return transactionSearchDescription;
    }

    public void setTransactionSearchDescription(String transactionSearchDescription) {
        this.transactionSearchDescription = transactionSearchDescription;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public TransactionStatusEnum getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatusEnum transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }


    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getTransactionUUID() {
        return transactionUUID;
    }

    public void setTransactionUUID(String transactionUUID) {
        this.transactionUUID = transactionUUID;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getRPSStatus() {
        return RPSStatus;
    }

    public void setRPSStatus(String RPSStatus) {
        this.RPSStatus = RPSStatus;
    }

    public String getAuthReversal() {
        return authReversal;
    }

    public void setAuthReversal(String authReversal) {
        this.authReversal = authReversal;
    }

    public String getAuthReversalStatus() {
        return authReversalStatus;
    }

    public void setAuthReversalStatus(String authReversalStatus) {
        this.authReversalStatus = authReversalStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
