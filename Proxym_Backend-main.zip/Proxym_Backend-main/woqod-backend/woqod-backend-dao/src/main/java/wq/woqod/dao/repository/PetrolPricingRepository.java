package wq.woqod.dao.repository;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import wq.woqod.dao.entity.Petrol;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/11/16.
 */
public interface PetrolPricingRepository extends JpaRepository<Petrol, Long>, QuerydslPredicateExecutor<Petrol> {

    Optional<Petrol> findPetrolByPetrolId(Long petrolId);

    @Query("SELECT DISTINCT name FROM Petrol where name is not null")
    List<String> findDistinctName();

    List<Petrol> findAll(Predicate predicate);

    @Override
    void deleteAll();
}

