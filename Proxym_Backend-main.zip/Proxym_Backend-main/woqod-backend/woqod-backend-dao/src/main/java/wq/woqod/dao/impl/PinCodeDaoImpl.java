package wq.woqod.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wq.woqod.dao.PinCodeDao;
import wq.woqod.dao.entity.PinCode;
import wq.woqod.dao.repository.PinCodeRepository;

/**
 * Created by Hassen.Ellouze on 06/02/2019.
 */
@Component
public class PinCodeDaoImpl implements PinCodeDao {

    @Autowired
    public PinCodeRepository pinCodeRepository;

    @Override
    public PinCode getPinCodeByUsername(String username) {
        try {
            return pinCodeRepository.findPinCodeByUsername(username);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return null;
        }
    }

    @Override
    public void saveOrUpdatePinCode(PinCode pinCode) {
        pinCodeRepository.save(pinCode);
    }


}
