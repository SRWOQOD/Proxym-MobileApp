package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.Fahes;

import java.util.Optional;

/**
 * Created by ameni on 26/03/18.
 */
public interface FahesRepository extends JpaRepository<Fahes, Long>, QuerydslPredicateExecutor<Fahes> {

    Optional<Fahes> findFahesByFahesId(Long fahesId);
}