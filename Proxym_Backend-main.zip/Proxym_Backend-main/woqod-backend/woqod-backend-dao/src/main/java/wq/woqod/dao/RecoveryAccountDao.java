package wq.woqod.dao;

import wq.woqod.dao.entity.RecoveryAccount;

/**
 * Created by med-taher.ben-torkia on 12/23/2016.
 */
public interface RecoveryAccountDao {

    void save(RecoveryAccount recoveryAccount);

    boolean exist(String userName);

    RecoveryAccount getRecoveryAccountByUserName(String userName);
}
