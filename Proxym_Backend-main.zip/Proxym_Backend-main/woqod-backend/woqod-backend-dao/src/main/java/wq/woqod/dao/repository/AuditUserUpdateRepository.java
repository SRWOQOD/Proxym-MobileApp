package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.AuditBackEnd;
import wq.woqod.dao.entity.AuditTrailUpdateUser;


public interface AuditUserUpdateRepository extends JpaRepository<AuditTrailUpdateUser, Long>, QuerydslPredicateExecutor<AuditTrailUpdateUser> {

}
