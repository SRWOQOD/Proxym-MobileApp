package wq.woqod.dao.entity;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.sql.Blob;
import java.util.Date;

/**
 * Created by Hassen.Ellouze on 08/02/2019.
 */

@Entity
@Table(name = Constants.TABLE_PREREGISTRATION)
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PreRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private CarCategory carCategory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_id")
    private Car car;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "creation_date")
    private Date creationDate;

    @Column(name = "final_amount")
    private Double finalAmount;

    @Column(name = "initial_amount")
    private Double initialAmount;

    @Column(name = "inspection_type")
    private String inspectionType;

    @Column(name = "barcode")
    private Blob barcode;

    @Column(name = "reference_number")
    private String referenceNumber;

    @Column(name = "barcode_reference")
    private String barcodeReference;

    @Column(name = "transactionUUID")
    private String transactionUUID;

    @Column(name = "mobileNumber")
    private String mobileNumber;

    //@Column(name = "qid")
    @Column(name = "encrypted_qid")
    private String qid;

    @Column(name = "pay_status")
    private String payStatus;

    @Column(name = "discount_info")
    private String discountInfo;

    @Column(name = "ws_status")
    private String wsStatus;

    @Column(name = "service_category")
    private String serviceCategory;

    @Column(name = "username_en")
    private String userNameEn;

    @Column(name = "username_ar")
    private String userNameAr;

    @Column(name = "receipturl")
    private String receipturl;

}