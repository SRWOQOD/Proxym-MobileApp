package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.DeviceDao;
import wq.woqod.dao.entity.Device;
import wq.woqod.dao.entity.QDevice;
import wq.woqod.dao.entity.User;
import wq.woqod.dao.repository.DeviceRepository;
import wq.woqod.resources.enumerations.DeviceStatusEnum;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 12/27/2016.
 */
@Component
public class DeviceDaoImpl implements DeviceDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceDaoImpl.class);
    private static final String DEVICESTRING = "device";

    private final DeviceRepository deviceRepository;

    @Autowired
    public DeviceDaoImpl(final DeviceRepository deviceRepository) {
        this.deviceRepository = deviceRepository;
    }

    @Override
    public Device getById(Long id) {
        LOGGER.info("DAO: find Devices By id {}", id);
        Optional<Device> device = deviceRepository.findById(id);
        return device.orElseThrow(() -> new DataNotFoundException(DEVICESTRING, String.valueOf(id), "Device"));
    }

    //FIXME: Dead code not used for the moment
    @Override
    public Optional<Device> getBySerial(String serial) {
        LOGGER.info("DAO: find Devices By serial {}", serial);
        return Optional.empty();
    }

    @Override
    public Optional<Device> getActiveByDeviceId(String serial, User user) {
        LOGGER.info("DAO: find Devices By serial and userId: {} , {}", serial, user.getId());
        Device device1 = deviceRepository.findByDeviceIdAndStatus(serial, DeviceStatusEnum.Active);
        if (Objects.isNull(device1)) {
            return Optional.empty();
        }
        return Optional.of(device1);
    }

    @Override
    public List<Device> getDevicesByOwner(User owner) {
        LOGGER.info("DAO: find Devices By Owner");
        return deviceRepository.findByOwner(owner);
    }

    @Override
    public Device save(Device device) {
        try {
            LOGGER.info("DAO: save device with serial");
//            deviceRepository.saveAndFlushDevice(device.getId(), device.getDeviceId(), device.getDeviceType(), device.getLastConnection(),
//                    device.getCreationDate(), device.getOwner().getId());
            deviceRepository.save(device);
            return device;
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting device entity..", ex);
            throw new PersistingDataException(DEVICESTRING, ex);
        }
    }
    @Override
    public Device update(Device device) {
        try {
            LOGGER.info("DAO: save device with serial");
            deviceRepository.saveAndFlushDevice(device.getId(), device.getDeviceId(), device.getDeviceType(), device.getLastConnection(),
                    device.getCreationDate(), device.getOwner().getId());
//                    deviceRepository.saveAndFlush(device);
            return device;
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting device entity..", ex);
            throw new PersistingDataException(DEVICESTRING, ex);
        }
    }

    @Override
    public void updateDevice(Device device) {
        LOGGER.info("DAO: update device {}", device);

        if (!exist(device.getDeviceId())) {
            throw new DataNotFoundException(DEVICESTRING, String.valueOf(device.getId()), "Device");
        }
        try {
            deviceRepository.updateStatus(device.getStatus(), device.getDeviceId());
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting device entity..", ex);
            throw new UpdatingDataException(DEVICESTRING, ex);
        }
    }

    @Override
    public boolean checkFingerPrint(String deviceId, String userName) {
        LOGGER.debug("DAO: checkFingerPrint : deviceId {}, Username {}", deviceId, userName);
        List<Device> devices = deviceRepository.findDeviceByDeviceIdAndOwnerUserNameNotAndCustomPwdNotNull(deviceId, userName);
        if (devices != null && !devices.isEmpty()) {
            LOGGER.error("finger print already exist for this device");
            return false;
        }
        return true;
    }

    @Override
    public Page<Device> getDevicesEnabledForFinger(Pageable pageable, Predicate predicate, MultiValueMap<String, String> parameters, String customerNumber) {
        LOGGER.debug("DAO: getDevicesEnabledForFinger :Start");

        QDevice device = QDevice.device;
        Predicate devicePredicate = device.isNotNull().and(predicate);
        devicePredicate = device.customPwd.isNotNull().and(devicePredicate);
        if ((customerNumber != null) && !(customerNumber.isEmpty())) {
            devicePredicate = ((BooleanExpression) devicePredicate).and((device.owner.userName.eq(customerNumber)));
        }
        Page<Device> page = deviceRepository.findAll(devicePredicate, pageable);
        LOGGER.debug("[LoggingExceptionDaoImpl] getFiltredLoggingException: End");
        return page;
    }


    @Override
    public boolean disableFinger(String deviceId) {
        deviceRepository.disableFinger(deviceId);
        return true;
    }

    public boolean exist(String deviceId) {
        return deviceRepository.findByDeviceIdAndStatus(deviceId, DeviceStatusEnum.Active) != null;
    }

    @Override
    public void updateDeviceBioPin(String bioPin, String customPwd, String deviceId, Long userId) {
        LOGGER.debug("DAO: updateDevice :  device id {}, user Id {}", deviceId, userId);
        try {
            deviceRepository.updateBioPin(bioPin, customPwd, deviceId, userId);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating device loyalty..", ex);
            throw new UpdatingDataException(DEVICESTRING, ex);
        }

    }

    @Override
    public Device findByDeviceUUID(String deviceUIID) {
        LOGGER.debug("DAO: findByDeviceUUID{}", deviceUIID);
        Device device = deviceRepository.findByDeviceIdAndStatus(deviceUIID, DeviceStatusEnum.Active);
        if (device == null) {
            throw new DataNotFoundException(DEVICESTRING, deviceUIID, "Device");
        } else {
            return device;
        }
    }

    @Override
    public List<Device> getAll() {
        LOGGER.debug("[DeviceDaoImpl] find all");
        Optional<List<Device>> deviceList = this.deviceRepository.findAllByStatus(DeviceStatusEnum.Active);
        if (deviceList.isPresent() && !deviceList.get().isEmpty()) {
            return deviceList.get();
        }
        return new ArrayList<>();
    }

    @Override
    public Device findDeviceByDeviceUUID(String deviceUUID) {
        return deviceRepository.findFirstByDeviceId(deviceUUID);
    }

    @Override
    public void addSurveyToDevice(String deviceId, Long surveyId) {
//        Device device = deviceRepository.findDeviceByDeviceId(deviceId);
//        if(!device.getSurveyList().contains(surveyId)) device.getSurveyList().add(surveyId);
//        deviceRepository.saveAndFlush(device);
    }
}
