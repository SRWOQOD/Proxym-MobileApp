package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.SuperMarket;

import java.util.List;
import java.util.Optional;

public interface SuperMarketDao {

    List<SuperMarket> getAllSuperMarkets();

    Optional<SuperMarket> getSuperMarketByMarketId(Long marketId);

    void create(List<SuperMarket> superMarkets);

    Page<SuperMarket> getFilteredSupermarkets(Pageable pageable, MultiValueMap<String, String> parameters);
}
