package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.AuditBackEnd;

import java.text.ParseException;


public interface AuditBackEndDao {
    AuditBackEnd save(AuditBackEnd auditBackEnd);

    Page<AuditBackEnd> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException;

    Long count();
}
