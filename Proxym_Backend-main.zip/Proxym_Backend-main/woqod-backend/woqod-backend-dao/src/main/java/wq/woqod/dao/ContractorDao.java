package wq.woqod.dao;

import wq.woqod.dao.entity.Contractor;

import java.util.List;

public interface ContractorDao {

    List<Contractor> getAllContractors();


}
