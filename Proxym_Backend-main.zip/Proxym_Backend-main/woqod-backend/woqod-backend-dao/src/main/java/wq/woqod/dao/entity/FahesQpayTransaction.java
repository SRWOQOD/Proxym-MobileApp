package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.commons.enumerations.RefundStatusEnum;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.PaymentMethodEnum;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = Constants.TABLE_FAHES_QPAY_TRANSACTION)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FahesQpayTransaction extends Auditable {

    @Column(length = 1024)
    public String transactionSearchDescription;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    @Column(name = "encrypted_qid")
    private String qid;
    private String mobile;
    @Column(unique = true)
    private String pun;
    private String referenceNumber;
    private Double amount;
    private String currency;
    private String email;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum transactionStatus;
    private String transactionStatusCode;
    private String transactionStatusMessage;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum apiStatus;
    @Column(length = 1024)
    private String description;
    private boolean valid;
    @Enumerated(EnumType.STRING)
    private PaymentMethodEnum paymentMethod;
    private Double initialAmount;
    private String discountInfo;
    private String transactionID;
    private String rpsStatus;
    private String authReversalStatus;
    private String plateType;
    private String purchasePun;
    private String approvalCode;
    private RefundStatusEnum refundStatus;
    private String refundStatusCode;
    private String refundStatusMessage;
}
