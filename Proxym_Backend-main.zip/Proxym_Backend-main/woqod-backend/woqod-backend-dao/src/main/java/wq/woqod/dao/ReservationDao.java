package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Reservations;
import wq.woqod.dao.entity.User;

import java.util.List;
import java.util.Map;

public interface ReservationDao {

    Reservations save(Reservations reservations);

    Reservations findByReservationId(String reservationId);

    Page<Reservations> filter(Pageable pageable, Map<String, String> parameters);

    List<Reservations> getReservations(MultiValueMap<String, String> params);

    Page<Reservations> all(Pageable pageable);

    List<Reservations> saveAll(List<Reservations> reservations);

    Long count();
}
