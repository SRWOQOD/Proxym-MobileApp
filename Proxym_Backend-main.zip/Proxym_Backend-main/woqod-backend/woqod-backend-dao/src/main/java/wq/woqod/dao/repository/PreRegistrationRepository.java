package wq.woqod.dao.repository;


import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.PreRegistration;

import java.util.List;
import java.util.Optional;

/**
 * The interface {@code PreRegistrationRepository} eases the management
 * of pre registration database operations
 *
 * @author Meriam.Mejri
 */
public interface PreRegistrationRepository extends JpaRepository<PreRegistration, Long>, QuerydslPredicateExecutor<PreRegistration> {

    Optional<PreRegistration> findByReferenceNumber(String referenceNumber);

    Optional<PreRegistration> findByCar_PlateNumber(String plateNumber);
   List<PreRegistration>  findAllByCar_PlateNumber(String plateNumber);

    Optional<PreRegistration> findPreRegistrationByTransactionUUID(String transactionUUID);

    Optional<PreRegistration> findByTransactionUUID(String TransactionUUID);

    List<PreRegistration> findAllByCar(Car car);

    List<PreRegistration> findByQid(String qid);

    List<PreRegistration> findAllByReferenceNumber(String referenceNumber);

    Optional<PreRegistration> findPreRegistrationByReferenceNumberAndTransactionUUID(String referenceNumber, String transactionUUID);

}
