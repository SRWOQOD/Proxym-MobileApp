package wq.woqod.dao;


import wq.woqod.dao.entity.QuestionResponse;
import wq.woqod.dao.entity.SurveyQuestion;

import java.util.List;

public interface QuestionResponseDao {
    List<QuestionResponse> getAll();
    List<QuestionResponse>   getBySurveyQuestionId(Long id);
}
