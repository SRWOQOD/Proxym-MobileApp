package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.ReservationEnum;
import wq.woqod.resources.enumerations.ResponseStatusEnum;
import wq.woqod.resources.enumerations.UserTypeEnum;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = Constants.RESERVATIONS)
public class Reservations {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "user_type")
    @Enumerated(EnumType.STRING)
    private UserTypeEnum userType;
    private String reservationId;
    private String stationNameEn;
    private String stationNameAr;
    private String slotTimeEn;
    private String slotTimeAr;
    private String appointmentDate;
    private String hourFrom;
    private String hourTo;
    private String vin;
    private String licencePlate;
    private String licencePlateTypeId;
    private String licencePlateTypeName;
    private String vehicleShapeId;
    private String vehicleShapeName;
    @Column(name = "encrypted_pid")
    private String pid;

    @Column(name = "encrypted_qid")
    private String qid;
    private String mobileNumber;
    private String canPayOnline;
    private Date creationDate;
    private Date cancellationDate;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private ReservationEnum status;

    private ResponseStatusEnum apiStatus;

}