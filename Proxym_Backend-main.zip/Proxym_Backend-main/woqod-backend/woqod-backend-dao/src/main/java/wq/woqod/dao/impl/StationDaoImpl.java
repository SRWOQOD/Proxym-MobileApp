package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.StationDao;
import wq.woqod.dao.entity.FacilityStation;
import wq.woqod.dao.entity.QStation;
import wq.woqod.dao.entity.ServiceStation;
import wq.woqod.dao.entity.Station;
import wq.woqod.dao.repository.FacilityStationRepository;
import wq.woqod.dao.repository.ServiceStationRepository;
import wq.woqod.dao.repository.StationRepository;
import wq.woqod.resources.enumerations.StationCategoryEnum;
import wq.woqod.resources.enumerations.StationStatusEnum;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Created by med-taher.ben-torkia on 12/13/2016.
 */
@Component
public class StationDaoImpl implements StationDao {

    @PersistenceContext
    EntityManager entityManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(StationDaoImpl.class);

    private final StationRepository stationRepository;
    private final ServiceStationRepository serviceStationRepository;
    private final FacilityStationRepository facilityStationRepository;


    @Autowired
    public StationDaoImpl(final StationRepository stationRepository, final ServiceStationRepository serviceStationRepository, final FacilityStationRepository facilityStationRepository) {
        this.stationRepository = stationRepository;
        this.serviceStationRepository = serviceStationRepository;
        this.facilityStationRepository = facilityStationRepository;
    }

    @Override
    public Station getStationById(Long id) {
        Optional<Station> station = stationRepository.findById(id);
        return station.orElseThrow(() -> new DataNotFoundException("station", String.valueOf(id), "Station"));
    }

    @Override
    public Station getStationByStationId(Long stationId) {
        Optional<Station> station = this.getOptionalStationByStationId(stationId);
        return station.orElseThrow(() -> new DataNotFoundException("station", String.valueOf(stationId), "Station"));
    }

    @Override
    public Optional<Station> getOptionalStationByStationId(Long stationId) {
        return stationRepository.findByStationId(stationId);
    }

    @Override
    public Map<Integer, Double> findStationRatingByStation_Id(Long stationId){
        return stationRepository.getStationRatingByStationId(stationId);
    }


    @Override
    public List<Station> getAllstations() {
        return stationRepository.findAll();
    }

    @Override
    public List<Station> getStationByCategory(StationCategoryEnum category) {
        return stationRepository.findStationByCategory(category);
    }

    @Override
    public void updateServiceStations(Set<ServiceStation> serviceStations) {
        try {
            serviceStationRepository.saveAll(serviceStations);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating ServiceStation entity..", ex);
            throw new UpdatingDataException("ServiceStation", ex);
        }
    }

    @Override
    public Page<Station> getFilteredList(Pageable pageable, Predicate predicate, MultiValueMap<String, String> params) {

        Predicate category = null;
        Predicate title = null;
        Predicate arabicName = null;
        Predicate phone = null;
        Predicate status = null;
        Predicate categoryp = null;
        Predicate area = null;

        QStation qStation = QStation.station;
        if (params.get("category") != null) {
            category = qStation.category.eq(StationCategoryEnum.valueOf(params.getFirst("category")));
        }

        if (params.get("areaId") != null) {
            area = qStation.area.idArea.eq((params.getFirst("areaId")));
        }
        if (params.get("categoryp") != null) {
            categoryp = qStation.petrolCategory.containsIgnoreCase((params.getFirst("categoryp")));
        }

        if (params.get("status") != null) {
            status = qStation.status.eq(StationStatusEnum.valueOf(params.getFirst("status")));
        }
        if (params.get("title") != null) {
            title = qStation.title.containsIgnoreCase((params.getFirst("title")));
        }

        if (params.get("arabicName") != null) {
            arabicName = qStation.arabicName.containsIgnoreCase((params.getFirst("arabicName")));
        }

        if (params.get("phone") != null) {
            phone = qStation.phone.containsIgnoreCase((params.getFirst("phone")));
        }

        Predicate predicateTransaction = qStation.isNotNull()
                .and(phone)
                .and(arabicName)
                .and(title)
                .and(status)
                .and(categoryp)
                .and(area)
                .and(category);
        return stationRepository.findAll(predicateTransaction, pageable);
    }

    @Override
    public Set<ServiceStation> getServicesByStation(Station station) {
        return serviceStationRepository.findByStation(station);
    }

    @Override
    public Set<FacilityStation> getFacilitiesByStation(Station station) {
        return facilityStationRepository.findByStation(station);
    }

    @Override
    public void createStations(List<Station> stations) {
        stationRepository.saveAll(stations);
    }

    @Override
    public Optional<ServiceStation> getServiceStationById(Long id) {
        return serviceStationRepository.findById(id).isPresent() ?
                Optional.of(serviceStationRepository.findById(id).get()) : null;
    }

}
