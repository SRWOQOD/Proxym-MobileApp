package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.FacilityNameEnum;
import wq.woqod.resources.enumerations.FacilityStatusEnum;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 12/13/2016.
 */
@Entity
@Table(name = Constants.TABLE_FACILITY_STATION)
public class FacilityStation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Enumerated(EnumType.STRING)
    private FacilityNameEnum name;

    @Enumerated(EnumType.STRING)
    private FacilityStatusEnum status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "station_id")
    private Station station;

    public FacilityStation() {
    }

    private FacilityStation(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.status = builder.status;
        this.station = builder.station;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FacilityNameEnum getName() {
        return name;
    }

    public void setName(FacilityNameEnum name) {
        this.name = name;
    }

    public FacilityStatusEnum getStatus() {
        return status;
    }

    public void setStatus(FacilityStatusEnum status) {
        this.status = status;
    }

    public Station getStation() {
        return station;
    }

    public void setStation(Station station) {
        this.station = station;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        FacilityStation other = (FacilityStation) obj;
        return Objects.equal(this.id, other.id) && Objects.equal(this.name, other.name)
                && Objects.equal(this.status, other.status) && Objects.equal(this.station, other.station);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), id, name, status, station);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("id", id).add("name", name).add("status", status)
                .add("station", station).toString();
    }

    public static class Builder {

        private Long id;
        private FacilityNameEnum name;
        private FacilityStatusEnum status;
        private Station station;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(FacilityNameEnum name) {
            this.name = name;
            return this;
        }

        public Builder status(FacilityStatusEnum status) {
            this.status = status;
            return this;
        }

        public Builder station(Station station) {
            this.station = station;
            return this;
        }

        public FacilityStation build() {
            return new FacilityStation(this);
        }
    }
}
