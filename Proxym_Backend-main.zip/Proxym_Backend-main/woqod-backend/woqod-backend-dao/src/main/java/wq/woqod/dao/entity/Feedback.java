package wq.woqod.dao.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.FeedbackCategoryEnum;
import wq.woqod.resources.enumerations.FeedbackSectorEnum;
import wq.woqod.resources.enumerations.LanguageEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by med-taher.ben-torkia on 11/30/2016.
 */
@Entity
@Table(name = Constants.TABLE_FEEDBACK)
public class Feedback implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "ticket_number", unique = true)
    private String ticketNumber;

    @Column
    private String feedbackNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "feedback_id")
    private User owner;

    private String name;

    @Column(name = "contact_number")
    private String contactNumber;

    @Column(name = "email")
    private String email;

    @Column(nullable = false)
    private String content;

    private Boolean status;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private FeedbackCategoryEnum category;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private FeedbackSectorEnum sector;

    public LanguageEnum getLanguage() {
        return language;
    }

    public void setLanguage(LanguageEnum language) {
        this.language = language;
    }

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_date")
    private Date creationDate;

    @Column(nullable = false)
    private boolean connected;

    @Lob
    @Column(name = "document_new")
    private String document;

    @OneToMany(mappedBy = "feedback", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("creationDate ASC")
    private List<FeedbackResponse> feedbackResponseList;

    public Feedback() {
    }

    public Feedback(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.contactNumber = builder.contactNumber;
        this.ticketNumber = builder.ticketNumber;
        this.content = builder.content;
        this.status = builder.status;
        this.category = builder.category;
        this.sector = builder.sector;
        this.creationDate = builder.creationDate;
        this.connected = builder.connected;
        this.owner = builder.owner;
        this.feedbackNumber = builder.feedbackNumber;
        this.document = builder.document;
        this.language = builder.language;
        this.email = builder.email;
        this.feedbackResponseList = builder.feedbackResponseList;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Boolean isStatus() {
        return status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public FeedbackCategoryEnum getCategory() {
        return category;
    }

    public void setCategory(FeedbackCategoryEnum category) {
        this.category = category;
    }

    public FeedbackSectorEnum getSector() {
        return sector;
    }

    public void setSector(FeedbackSectorEnum sector) {
        this.sector = sector;
    }

    public Date getCreationDate() {
        return creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public String getFeedbackNumber() {
        return feedbackNumber;
    }

    public void setFeedbackNumber(String feedbackNumber) {
        this.feedbackNumber = feedbackNumber;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public List<FeedbackResponse> getFeedbackResponseList() {
        return feedbackResponseList;
    }

    public void setFeedbackResponseList(List<FeedbackResponse> feedbackResponseList) {
        this.feedbackResponseList = feedbackResponseList;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", content='" + content + '\'' +
                ", status=" + status +
                ", category=" + category +
                ", sector=" + sector +
                ", creationDate=" + creationDate +
                '}';
    }

    public static class Builder {
        private String ticketNumber;
        private Long id;
        private String name;
        private String contactNumber;
        private String content;
        private Boolean status;
        private String email;
        private String feedbackNumber;
        private FeedbackCategoryEnum category;
        private FeedbackSectorEnum sector;
        private Date creationDate;
        private boolean connected;
        private User owner;
        private LanguageEnum language;
        private String document;
        private List<FeedbackResponse> feedbackResponseList;

        public Builder feedbackResponseList(List<FeedbackResponse> feedbackResponseList) {
            this.feedbackResponseList = feedbackResponseList;
            return this;
        }

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder feedbackNumber(String feedbackNumber) {
            this.feedbackNumber = feedbackNumber;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder contactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder status(Boolean status) {
            this.status = status;
            return this;
        }

        public Builder category(FeedbackCategoryEnum category) {
            this.category = category;
            return this;
        }

        public Builder sector(FeedbackSectorEnum sector) {
            this.sector = sector;
            return this;
        }

        public Builder language(LanguageEnum language) {
            this.language = language;
            return this;
        }

        public Builder creationDate(Date creationDate) {
            this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
            return this;
        }

        public Builder connected(boolean connected) {
            this.connected = connected;
            return this;
        }

        public Builder owner(User owner) {
            this.owner = owner;
            return this;
        }

        public Builder document(String document) {
            this.document = document;
            return this;
        }

        public Feedback build() {
            return new Feedback(this);
        }

        public Builder ticketNumber(String ticketNumber) {
            this.ticketNumber = ticketNumber;
            return this;
        }
    }
}
