package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.PaymentMethodEnum;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = Constants.TABLE_PR_TRANSACTION_LOG)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PRTransactionLog extends Auditable {

    @Column(length = 1024)
    public String transactionSearchDescription;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    @Column(name = "encrypted_qid")
    private String qid;
    private String mobile;
    @Column(unique = true)
    private String transactionUUID;
    private String referenceNumber;
    private Double amount;
    private String currency;
    private String email;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum transactionStatus;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum apiStatus;
    @Column(length = 1024)
    private String description;
    private boolean valid;
    @Enumerated(EnumType.STRING)
    private PaymentMethodEnum paymentMethod;
    private Double initialAmount;
    private String discountInfo;
    private String transactionID;
    private String rpsStatus;
    private String authReversal;
    private String AuthReversalStatus;
    private String plateType;

}
