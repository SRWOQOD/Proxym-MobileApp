package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.SurveyResponseDao;
import wq.woqod.dao.entity.Survey;
import wq.woqod.dao.entity.SurveyResponse;
import wq.woqod.dao.repository.SurveyResponseRepository;

import java.util.List;

@Component
@Transactional
public class SurveyResponseDaoImpl implements SurveyResponseDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyResponseDaoImpl.class);
    private final SurveyResponseRepository surveyResponseRepository;

    @Autowired
    public SurveyResponseDaoImpl(SurveyResponseRepository surveyResponseRepository) {
        this.surveyResponseRepository = surveyResponseRepository;
    }

    @Override
    public List<SurveyResponse> getAllSurveysResponses() {
        return surveyResponseRepository.findAll();
    }

    @Override
    public SurveyResponse getSurveyResponseById(Long id) {
        return surveyResponseRepository.findSurveyResponseById(id);
    }

    public List<SurveyResponse> getResponseBySurvey(Survey survey) {
        return surveyResponseRepository.findSurveyResponseBySurvey(survey);
    }

    @Override
    public void save(List<SurveyResponse> surveyResponse) {
        surveyResponseRepository.saveAll(surveyResponse);
    }

    @Override
    public void deleteSurveysResponses(Long id) {
        SurveyResponse surveyResponse = surveyResponseRepository.getOne(id);
        surveyResponseRepository.delete(surveyResponse);
    }
    @Override
    public List<SurveyResponse> findAllByDeviceId(String deviceId) {
      return   surveyResponseRepository.findByDeviceId(deviceId);
    }

}