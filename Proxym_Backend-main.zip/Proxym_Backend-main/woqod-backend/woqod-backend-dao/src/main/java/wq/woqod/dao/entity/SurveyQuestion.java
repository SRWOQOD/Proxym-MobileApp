package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.QuestionTypeEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = Constants.TABLE_SURVEY_QUESTION)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class SurveyQuestion implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "title_question", nullable = false)
    private String title;

    @Column(name = "arabic_title_question", nullable = false)
    private String arabicTitle;

    @Column(name = "type_question", nullable = false)
    private QuestionTypeEnum typeQuestion;

    //    @Fetch(FetchMode.SELECT)
    @ElementCollection
    @CollectionTable(
            name="SURVEY_OPTION",
            joinColumns=@JoinColumn(name="SURVEY_QUESTION_ID")
    )
    private List<Option> options;

    @Column(name = "min")
    private Double min;

    @Column(name = "max")
    private Double max;

    @Column(name = "text_limit")
    private Long textLimit;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "survey_id")
    private Survey survey;
}
