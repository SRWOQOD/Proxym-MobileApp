package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.Expressions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.RejectedVoucherDao;
import wq.woqod.dao.entity.QRejectedVoucher;
import wq.woqod.dao.entity.RejectedVoucher;
import wq.woqod.dao.repository.RejectedVoucherRepository;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * The class {@code RejectedVoucherDaoImpl} define the operations
 * of methods needed for rejected voucher database
 *
 * @author Meriam.Mejri
 */
@Component
public class RejectedVoucherDaoImpl implements RejectedVoucherDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(RejectedVoucherDaoImpl.class);

    private final RejectedVoucherRepository voucherRepository;

    public RejectedVoucherDaoImpl(RejectedVoucherRepository voucherRepository) {
        this.voucherRepository = voucherRepository;
    }


    /**
     * The method {@code save} allows to add a new voucher
     *
     * @param voucher
     */
    @Override
    public void save(RejectedVoucher voucher) {
        try {
            voucherRepository.save(voucher);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("voucher", ex);
        }
    }

    /**
     * The method {@code getAllVoucher} Used to get All voucher
     *
     * @return list
     */
    @Override
    public List<RejectedVoucher> getAllVoucher() {

        return voucherRepository.findAll();
    }


    /**
     * Used to Delete a voucher
     *
     * @param voucher
     */
    @Override
    public void delete(RejectedVoucher voucher) {
        voucherRepository.delete(voucher);
    }


    /**
     * Used to find voucher by Reference
     *
     * @param reference
     */
    @Override
    public RejectedVoucher findByReference(String reference) {
        if (voucherRepository.findByVoucherReference(reference).isPresent()) {
            return voucherRepository.findByVoucherReference(reference).get();
        } else {
            throw new DataNotFoundException("voucher", String.valueOf(reference), "Voucher");
        }
    }

    /**
     * The method {@code save} allows to add a list
     * of voucher
     *
     * @param vouchers
     */
    @Override
    public void saveList(List<RejectedVoucher> vouchers) {
        for (RejectedVoucher voucher : vouchers
        ) {
            voucherRepository.save(voucher);
        }
    }

    /**
     * Used to filter  voucher list
     *
     * @param predicate
     * @param pageable
     * @param parameters
     * @return Page
     */
    @Override
    public Page<RejectedVoucher> getFiltredVouchers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException {

        QRejectedVoucher voucher = QRejectedVoucher.rejectedVoucher;

        Predicate predicateWithEquals;
        BooleanExpression voucherReference = null;
        BooleanExpression beginDate = null;
        BooleanExpression finishDate = null;

        if (parameters.containsKey("voucherReferenceOP") || parameters.containsKey("type") || parameters.containsKey("beginDateOP") || parameters.containsKey("finishDateOP")) {


            if (parameters.containsKey("voucherReference") && (parameters.containsKey("voucherReferenceOP"))) {
                if (!Objects.isNull(voucher.voucherReference) && (!Objects.isNull(parameters.get("voucherReferenceOP")))) {
                    if (parameters.get("voucherReferenceOP").contains("equal")) {
                        voucherReference = voucher.voucherReference.eq((parameters.get("voucherReference")).toString().substring(1, (parameters.get("voucherReference")).toString().length() - 1));
                    }
                    if (parameters.get("voucherReferenceOP").contains("contains")) {
                        voucherReference = voucher.voucherReference.contains((parameters.get("voucherReference")).toString().substring(1, (parameters.get("voucherReference")).toString().length() - 1));
                    }
                }
            }

            if (parameters.containsKey("beginDate") && (parameters.containsKey("beginDateOP"))) {
                if (!Objects.isNull(voucher.beginDate) && (!Objects.isNull(parameters.get("beginDateOP")))) {
                    String dateString = "";
                    dateString = parameters.get("beginDate").get(0);
                    LocalDate localDate = null;
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    localDate = LocalDate.parse(dateString, formatter);


                    if (parameters.get("beginDateOP").contains("equal")) {
                        beginDate = voucher.beginDate.eq(localDate.plusDays(1));
                    }
                    if (parameters.get("beginDateOP").contains("less")) {
                        beginDate = voucher.beginDate.before(localDate.plusDays(1));
                    }
                    if (parameters.get("beginDateOP").contains("greater")) {
                        beginDate = voucher.beginDate.after(localDate.plusDays(1));
                    }
                }
            }
            if (parameters.containsKey("finishDate") && (parameters.containsKey("finishDateOP"))) {
                if (!Objects.isNull(voucher.finishDate) && (!Objects.isNull(parameters.get("finishDateOP")))) {
                    String dateString = "";
                    dateString = parameters.get("finishDate").get(0);
                    LocalDate localDate = null;
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);

                    localDate = LocalDate.parse(dateString, formatter);


                    if (parameters.get("finishDateOP").contains("equal")) {
                        finishDate = voucher.finishDate.eq(localDate.plusDays(1));
                    }
                    if (parameters.get("finishDateOP").contains("less")) {
                        finishDate = voucher.finishDate.before(localDate.plusDays(1));
                    }
                    if (parameters.get("finishDateOP").contains("greater")) {
                        finishDate = voucher.finishDate.after(localDate.plusDays(1));
                    }
                }
            }
        }


        if (null == voucherReference) {
            voucherReference = Expressions.asBoolean(true).isTrue();
        }
        if (null == beginDate) {
            beginDate = Expressions.asBoolean(true).isTrue();
        }
        if (null == finishDate) {
            finishDate = Expressions.asBoolean(true).isTrue();
        }


        predicateWithEquals = voucherReference.and(beginDate).and(finishDate);


        Page<RejectedVoucher> page = voucherRepository.findAll(predicateWithEquals, pageable);
        return page;
    }

}
