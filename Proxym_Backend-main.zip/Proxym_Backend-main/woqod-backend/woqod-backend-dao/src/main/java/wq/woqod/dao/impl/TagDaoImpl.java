package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.TagDao;
import wq.woqod.dao.entity.QTag;
import wq.woqod.dao.entity.Tag;
import wq.woqod.dao.repository.TagRepository;
import wq.woqod.resources.enumerations.CarTagStatusEnum;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;


@Slf4j
@Component
public class TagDaoImpl implements TagDao {

    private final TagRepository tagRepository;

    public TagDaoImpl(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @Override
    public Tag save(Tag tag) {
        try {
            return tagRepository.save(tag);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting tag entity..", ex);
            throw new PersistingDataException("tag", ex);
        }

    }

    @Override
    public Page<Tag> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate date = null;
        Predicate qid = null;
        Predicate plateNumber = null;
        Predicate mobile = null;
        Predicate status = null;


        QTag qTagLog = QTag.tag;

        if (params.get("qid") != null) {
            qid = qTagLog.car.owner.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get("plateNumber") != null) {
            plateNumber = qTagLog.car.plateNumber.containsIgnoreCase(params.getFirst("plateNumber"));
        }


        if (params.get("mobile") != null) {
            mobile = qTagLog.car.owner.phone.containsIgnoreCase(params.getFirst("mobile"));
        }

        if (params.get("date") != null) {
            date = qTagLog.registrationDate.after(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(params.getFirst("date")));
        }

        if (params.get("status") != null) {
            status = qTagLog.carTagStatusEnum.eq(CarTagStatusEnum.PENDING);
        }


        Predicate predicateTag = qTagLog.isNotNull()
                .and(qid)
                .and(mobile)
                .and(status)
                .and(plateNumber)
                .and(date);
        return tagRepository.findAll(predicateTag, pageable);
    }

    @Override
    public List<Tag> findAllTags(MultiValueMap<String, String> params) throws ParseException {
        if (params == null) {
            return tagRepository.findAll();
        }

        Predicate date = null;
        Predicate qid = null;
        Predicate plateNumber = null;
        Predicate mobile = null;
        Predicate status = null;

        QTag qTagLog = QTag.tag;


        if (params.get("qid") != null) {
            qid = qTagLog.car.owner.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get("plateNumber") != null) {
            plateNumber = qTagLog.car.plateNumber.containsIgnoreCase(params.getFirst("plateNumber"));
        }


        if (params.get("mobile") != null) {
            mobile = qTagLog.car.owner.phone.containsIgnoreCase(params.getFirst("mobile"));
        }

        if (params.get("date") != null) {
            date = qTagLog.registrationDate.after(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(params.getFirst("date")));
        }

        if (params.get("status") != null) {
            status = qTagLog.carTagStatusEnum.eq(CarTagStatusEnum.PENDING);
        }


        Predicate predicateTag = qTagLog.isNotNull()
                .and(qid)
                .and(mobile)
                .and(status)
                .and(plateNumber)
                .and(date);
        return (List<Tag>) tagRepository.findAll(predicateTag);
    }

    @Override
    public Long count() {
        return tagRepository.count();
    }

}
