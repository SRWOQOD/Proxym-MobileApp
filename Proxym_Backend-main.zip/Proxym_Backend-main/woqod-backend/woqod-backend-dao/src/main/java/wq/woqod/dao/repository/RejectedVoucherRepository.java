package wq.woqod.dao.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.RejectedVoucher;

import java.util.Optional;

/**
 * The interface {@code RejectedVoucherRepository} eases the management
 * of rejected voucher database operations
 *
 * @author Meriam.Mejri
 */
public interface RejectedVoucherRepository extends JpaRepository<RejectedVoucher, Long>, QuerydslPredicateExecutor<RejectedVoucher> {

    Optional<RejectedVoucher> findByVoucherReference(String reference);

}
