package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.CarCategory;

import java.util.List;

public interface CarCategoryDao {

    CarCategory save(CarCategory carCategory);

    CarCategory findByCategoryId(String categoryId);

    CarCategory findByFee(Double fee);

    CarCategory findByNameEn(String nameEn);

    List<CarCategory> findAll();

    Page<CarCategory> getFiltredCarCategory(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters);

    void delete(Long id);
}
