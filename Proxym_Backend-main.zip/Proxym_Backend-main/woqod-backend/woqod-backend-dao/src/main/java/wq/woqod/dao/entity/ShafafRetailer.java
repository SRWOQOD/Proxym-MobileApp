package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

/**
 * Created by med-taher.ben-torkia on 12/30/2016.
 */
@Entity
@Table(name = Constants.TABLE_SHAFAF_RETAILER)
public class ShafafRetailer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String arabicName;
    private String contactNumber;
    private String location;

    public ShafafRetailer() {
    }

    private ShafafRetailer(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.arabicName = builder.arabicName;
        this.contactNumber = builder.contactNumber;
        this.location = builder.location;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getArabicName() {
        return arabicName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getLocation() {
        return location;
    }

    public static class Builder {

        private Long id;
        private String name;
        private String arabicName;
        private String contactNumber;
        private String location;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder arabicName(String arabicName) {
            this.arabicName = arabicName;
            return this;
        }

        public Builder contactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
            return this;
        }

        public Builder location(String location) {
            this.location = location;
            return this;
        }

        public ShafafRetailer build() {
            return new ShafafRetailer(this);
        }
    }
}
