package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.PRTransactionLog;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface PRTransactionRepository extends JpaRepository<PRTransactionLog, Long>, QuerydslPredicateExecutor<PRTransactionLog> {
    Optional<PRTransactionLog> findByTransactionUUID(String TransactionUUID);

    @Modifying
    @Transactional
    @Query("update PRTransactionLog u set u.transactionStatus = ?2  where u.transactionUUID= ?1")
    void updateStatus(String TransactionUUID, TransactionStatusEnum statusEnum);
    @Query("select f from PRTransactionLog f where  f.createdDate between ?1 and ?2 and (f.transactionStatus=?3 or f.transactionStatus =?4)")
    List<PRTransactionLog> findAllByCreatedDateBetweenAndTransactionStatusOrTransactionStatus(Date dateNow, Date fin, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);
    List<PRTransactionLog> findAllByCreatedDateBetweenAndTransactionStatusAndApiStatus(Date dateNow, Date fin, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);
    @Query("select f from PRTransactionLog f where f.rpsStatus=?1 and f.createdDate between ?2 and ?3 and (f.transactionStatus=?4 or f.transactionStatus =?5)")
    List<PRTransactionLog> findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus(String desc,Date dateNow, Date fin, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);
    List<PRTransactionLog>  findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusAndApiStatus(String desc,Date dateNow, Date fin, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);

    @Query("select count(f) from PRTransactionLog f where (f.transactionStatus = 'PAID' or f.transactionStatus = 'PAIED') and f.qid=?1 and f.createdDate between ?2 and ?3 ")
    Long getSuccesscount(String qid, Date fro, Date to);

    @Query("select count(t) from PRTransactionLog t where t.transactionStatus = 'ERROR' or t.transactionStatus = 'FAILED'")
    Long getFailedcount();

    @Query("select sum(t.amount) from PRTransactionLog t")
    Long getSum();

    @Query("select sum(t.amount) from PRTransactionLog t " + "where (t.transactionStatus = 'PAID' or t.transactionStatus = 'PAIED') and t.createdDate between :creDatFrom and :creDatTo")
    Optional<Long> calculateTotalFahesAmount(@Param("creDatFrom") Date creDatFrom, @Param("creDatTo") Date creDatTo);
}
