package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.Config;

@Repository
public interface ConfigRepository extends JpaRepository<Config, Long> {
    Config getConfigByProprety(String proprety);
}
