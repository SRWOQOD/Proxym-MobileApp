package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.*;
import wq.woqod.dao.NotificationTemplateDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.NotificationTemplate;
import wq.woqod.dao.entity.QNotificationTemplate;
import wq.woqod.dao.repository.NotificationTemplateRepository;

import java.util.List;
import java.util.Optional;

@Repository
@Slf4j
public class NotificationTemplateDaoImpl implements NotificationTemplateDao {
    private final NotificationTemplateRepository notificationTemplateRepository;

    public NotificationTemplateDaoImpl(NotificationTemplateRepository notificationTemplateRepository) {
        this.notificationTemplateRepository = notificationTemplateRepository;
    }


    @Override
    public Page<NotificationTemplate> findAll(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qcontent = null;
        Predicate qtitle = null;

        QNotificationTemplate qTemplate = QNotificationTemplate.notificationTemplate;

        if (parameters.get(FilterConstants.CONTENT) != null) {
            qcontent = qTemplate.content.containsIgnoreCase(parameters.getFirst(FilterConstants.CONTENT));
        }

        if (parameters.get(FilterConstants.TITLE) != null) {
            qtitle = qTemplate.title.containsIgnoreCase(parameters.getFirst(FilterConstants.TITLE));
        }


        Predicate predicateTransaction = qTemplate.isNotNull()
                .and(qcontent)
                .and(qtitle);
        return notificationTemplateRepository.findAll(predicateTransaction, pageable);

    }

    @Override
    public void save(NotificationTemplate notificationTemplate) {
        try {
            check(notificationTemplate);
            notificationTemplateRepository.saveAndFlush(notificationTemplate);
        } catch (DataIntegrityViolationException e) {
            throw new TemplateAlreadyExistException(notificationTemplate.getTitle());
        }
    }

    @Override
    public void update(NotificationTemplate notificationTemplate) {
        try {
            check(notificationTemplate);
            notificationTemplateRepository.saveAndFlush(notificationTemplate);
        } catch (DataIntegrityViolationException e) {
            throw new TemplateAlreadyExistException(notificationTemplate.getTitle());
        } catch (Exception ex) {
            log.error("Problem when persisting NotificationTemplate entity..", ex);
            throw new PersistingDataException(FilterConstants.NOTIFICATION_TEMPLATE, ex);
        }
    }

    @Override
    public void delete(Long id) {
        try {
            Optional<NotificationTemplate> notificationTemplate = notificationTemplateRepository.findById(id);
            notificationTemplate.ifPresent(notificationTemplateRepository::delete);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when Deleting NotificationTemplate entity..", ex);
            throw new UpdatingDataException(FilterConstants.NOTIFICATION_TEMPLATE, ex);
        }
    }

    @Override
    public NotificationTemplate findById(Long id) {
        Optional<NotificationTemplate> notificationTemplate = notificationTemplateRepository.findById(id);
        return notificationTemplate.orElseThrow(() -> new DataNotFoundException(FilterConstants.NOTIFICATION_TEMPLATE, String.valueOf(id), FilterConstants.NOTIFICATION_TEMPLATE));

    }

    @Override
    public List<NotificationTemplate> getAllNotificationTemplates(MultiValueMap<String, String> parameters) {

        Predicate qcontent = null;
        Predicate qtitle = null;

        QNotificationTemplate qTemplate = QNotificationTemplate.notificationTemplate;

        if (parameters.get(FilterConstants.CONTENT) != null) {
            qcontent = qTemplate.content.containsIgnoreCase(parameters.getFirst(FilterConstants.CONTENT));
        }

        if (parameters.get(FilterConstants.TITLE) != null) {
            qtitle = qTemplate.title.containsIgnoreCase(parameters.getFirst(FilterConstants.TITLE));
        }


        Predicate predicateTransaction = qTemplate.isNotNull()
                .and(qcontent)
                .and(qtitle);
        return (List<NotificationTemplate>) notificationTemplateRepository.findAll(predicateTransaction);
    }

    private void check(NotificationTemplate notificationTemplate) {
        if (notificationTemplate.getTitle() == null || notificationTemplate.getTitle().isEmpty()) {
            throw new InputDataMissingException(FilterConstants.TITLE);
        }
        if (notificationTemplate.getContent() == null || notificationTemplate.getContent().isEmpty()) {
            throw new InputDataMissingException(FilterConstants.CONTENT);
        }
    }

    @Override
    public Long count() {
        return notificationTemplateRepository.count();
    }
}
