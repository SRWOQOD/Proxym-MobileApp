package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.TagTransactionDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QTagTransaction;
import wq.woqod.dao.entity.TagTransaction;
import wq.woqod.dao.repository.TagTransactionRepository;
import wq.woqod.resources.resources.inputs.InputUpdateTransaction;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;


@Slf4j
@Component
public class TransactionTagDaoImpl implements TagTransactionDao {

    private final TagTransactionRepository tagTransactionRepository;

    public TransactionTagDaoImpl(TagTransactionRepository tagTransactionRepository) {
        this.tagTransactionRepository = tagTransactionRepository;
    }

    @Override
    public TagTransaction save(TagTransaction tagTransaction) {
        try {
            return tagTransactionRepository.save(tagTransaction);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting tag entity..", ex);
            throw new PersistingDataException("tag", ex);
        }

    }

    @Override
    public TagTransaction findByTransactionUUid(String transactionUUID) {
        try {
            return tagTransactionRepository.findByTransactionUUID(transactionUUID);
        } catch (DataIntegrityViolationException ex) {
            log.error("couldn't find transaction with id : " + transactionUUID, ex);
            throw new PersistingDataException("tag", ex);
        }
    }

    @Override
    public TagTransaction update(InputUpdateTransaction inputUpdateTransaction) {
        try {

            Optional<TagTransaction> transaction = tagTransactionRepository.findById(inputUpdateTransaction.getLocalId());
            if (transaction.isPresent()) {
                transaction.get().setTransactionStatus(inputUpdateTransaction.getTransactionStatusEnum());
                transaction.get().setTransactionId(inputUpdateTransaction.getId());
                return tagTransactionRepository.save(transaction.get());
            }
            log.error("Couldn't get transaction with id : " + inputUpdateTransaction.getLocalId());
            throw new DataNotFoundException("TagTransaction", inputUpdateTransaction.getLocalId().toString(), "TagTransaction");
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting tag entity..", ex);
            throw new PersistingDataException("tag", ex);
        }

    }

    @Override
    public List<TagTransaction> getAll(MultiValueMap<String, String> params) throws ParseException {
        if (params == null) {
            return tagTransactionRepository.findAll();
        }
        Predicate createdDate = null;
        Predicate qid = null;
        Predicate transactionUUID = null;
        Predicate plateNumber = null;
        Predicate mobile = null;
        Predicate transactionStatus = null;

        QTagTransaction qTransactionLog = QTagTransaction.tagTransaction;


        if (params.get(FilterConstants.QID_TRANSACTION_LOG) != null) {
            qid = qTransactionLog.qid.containsIgnoreCase(params.getFirst(FilterConstants.QID_TRANSACTION_LOG));
        }

        if (params.get(FilterConstants.TRANSACTION_UUID) != null) {
            transactionUUID = qTransactionLog.transactionUUID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_UUID));
        }

        if (params.get(FilterConstants.PLATENUMBER) != null) {
            plateNumber = qTransactionLog.plateNumber.containsIgnoreCase(params.getFirst(FilterConstants.PLATENUMBER));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.DATE) != null) {
            createdDate = qTransactionLog.createdDate.after(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(params.getFirst(FilterConstants.DATE)));
        }


        Predicate predicateTransaction = qTransactionLog.isNotNull()
                .and(qid)
                .and(transactionUUID)
                .and(mobile)
                .and(plateNumber)
                .and(transactionStatus)
                .and(createdDate);
        return (List<TagTransaction>) tagTransactionRepository.findAll(predicateTransaction);
    }


    @Override
    public Page<TagTransaction> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate createdDate = null;
        Predicate qid = null;
        Predicate transactionUUID = null;
        Predicate plateNumber = null;
        Predicate mobile = null;
        Predicate transactionStatus = null;

        QTagTransaction qTransactionLog = QTagTransaction.tagTransaction;


        if (params.get(FilterConstants.QID_TRANSACTION_LOG) != null) {
            qid = qTransactionLog.qid.containsIgnoreCase(params.getFirst(FilterConstants.QID_TRANSACTION_LOG));
        }

        if (params.get(FilterConstants.TRANSACTION_UUID) != null) {
            transactionUUID = qTransactionLog.transactionUUID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_UUID));
        }

        if (params.get(FilterConstants.PLATENUMBER) != null) {
            plateNumber = qTransactionLog.plateNumber.containsIgnoreCase(params.getFirst(FilterConstants.PLATENUMBER));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.DATE) != null) {
            createdDate = qTransactionLog.createdDate.after(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(params.getFirst(FilterConstants.DATE)));
        }


        Predicate predicateTransaction = qTransactionLog.isNotNull()
                .and(qid)
                .and(transactionUUID)
                .and(mobile)
                .and(plateNumber)
                .and(transactionStatus)
                .and(createdDate);
        return tagTransactionRepository.findAll(predicateTransaction, pageable);
    }

    @Override
    public Long count() {
        return tagTransactionRepository.count();
    }

}
