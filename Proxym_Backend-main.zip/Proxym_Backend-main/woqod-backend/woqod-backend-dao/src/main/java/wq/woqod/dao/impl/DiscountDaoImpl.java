package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.dao.DiscountDao;
import wq.woqod.dao.entity.Discount;
import wq.woqod.dao.entity.QDiscount;
import wq.woqod.dao.repository.DiscountRepository;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.enumerations.PaymentTypeEnum;

import java.util.List;
import java.util.Optional;

/**
 * Created by Hassen.Ellouze on 15/11/2018.
 */
@Component
@Slf4j
public class DiscountDaoImpl implements DiscountDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscountDaoImpl.class);

    private final DiscountRepository discountRepository;

    @Autowired
    public DiscountDaoImpl(final DiscountRepository discountRepository) {
        this.discountRepository = discountRepository;
    }


    @Override
    public List<Discount> getAllDiscount() {
        return discountRepository.findAll();
    }

    @Override
    public void updateDiscount(Discount discount) {

        try {
            discountRepository.save(discount);
        } catch (Exception e) {
            log.error("Exception when updating discount");
        }
    }

    @Override
    public void save(Discount discount) {
        try {
            discountRepository.save(discount);
        } catch (Exception e) {
            log.error("Exception when persisiting new discount");

        }
    }

    @Override
    public Discount getDiscountByServiceAndPaymentMethode(String fahesService, String paymentMethod) {
        FahesServiceEnum fahesServiceEnum = FahesServiceEnum.valueOf(fahesService);
        PaymentMethodEnum paymentMethodEnum = PaymentMethodEnum.valueOf(paymentMethod);
        return discountRepository.getDiscountByFahesServiceEnumAndPaymentMethodEnum(fahesServiceEnum, paymentMethodEnum);
    }


    @Override
    public Discount getDiscountByServiceAndPaymentMethodeAndAmount(String fahesService, String paymentMethod, Double amount) {
        try {
            FahesServiceEnum fahesServiceEnum = FahesServiceEnum.valueOf(fahesService);
            PaymentMethodEnum paymentMethodEnum = PaymentMethodEnum.valueOf(paymentMethod);
            return discountRepository.getDiscountByFahesServiceEnumAndPaymentMethodEnumAndAmount(fahesServiceEnum.name(), paymentMethodEnum.name(), amount);

        } catch (Exception e) {
            log.error("Discount Exeption : {} ", e.getMessage());
            return null;
        }
    }


    @Override
    public Discount getDiscountByAmount(Double amount) {
        return discountRepository.getDiscountByAmount(amount);
    }

    @Override
    public Boolean checkInterval(Double min, Double max, String method, String type, String service, String status) {
        List<Discount> list = discountRepository.findAll();
        boolean test;
        if (status.equals("true")) {
            test = true;
        } else {
            test = false;
        }

        for (Discount discount : list
        ) {
            if (((min >= discount.getMin()) && (min < discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name())) && (test == (discount.isStatus()))) || ((max > discount.getMin()) && (max <= discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name())) && (test == (discount.isStatus()))) || ((min <= discount.getMin()) && (max >= discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name())) && (test == (discount.isStatus())))) {
                return false;
            }
        }

        return true;
    }

    @Override
    public Boolean checkIntervalForUpdate(Long id, Double min, Double max, String method, String type, String service, String status) {
        List<Discount> list = discountRepository.findAll();

        boolean test;
        if (status.equals("true")) {
            test = true;
        } else {
            test = false;
        }

        list.remove(discountRepository.findById(id));
        for (Discount discount : list
        ) {

            if (((min >= discount.getMin()) && (min < discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name()))) || ((max > discount.getMin()) && (max <= discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name()))) || ((min <= discount.getMin()) && (max >= discount.getMax()) && (service.equals(discount.getFahesServiceEnum().name())) && (method.equals(discount.getPaymentMethodEnum().name())))) {

                if (test == discount.isStatus() && test) {
                    return false;
                } else if (test == discount.isStatus() && !test) {
                    return true;
                }


            }

        }


        return true;
    }

    @Override
    public Page<Discount> getFiltredDiscounts(Pageable pageable, MultiValueMap<String, String> params) {

        Predicate service = null;
        Predicate paymentType = null;
        Predicate paymentMethod = null;
        Predicate status = null;

        QDiscount qDiscount = QDiscount.discount;

        if (params.get("fahesServiceEnum") != null) {
            service = qDiscount.fahesServiceEnum.eq(FahesServiceEnum.valueOf(params.getFirst("fahesServiceEnum")));
        }


        if (params.get("paymentMethodEnum") != null) {
            paymentMethod = qDiscount.paymentMethodEnum.eq(PaymentMethodEnum.valueOf(params.getFirst("paymentMethodEnum")));
        }

        if (params.get("paymentTypeEnum") != null) {
            paymentType = qDiscount.paymentTypeEnum.eq(PaymentTypeEnum.valueOf(params.getFirst("paymentTypeEnum")));
        }

        if (params.get("status") != null) {
            status = qDiscount.status.eq(Boolean.valueOf(params.getFirst("status")));
        }


        Predicate predicateTransaction = qDiscount.isNotNull()
                .and(service)
                .and(paymentType)
                .and(status)
                .and(paymentMethod);
        return discountRepository.findAll(predicateTransaction, pageable);

    }

    @Override
    public void delete(Long id) {
        Optional<Discount> discount = discountRepository.findById(id);
        discount.ifPresent(discountRepository::delete);
    }

    @Override
    public Discount getById(Long id) {
        if (discountRepository.findById(id).isPresent()) {
            return discountRepository.findById(id).get();
        } else {
            throw new DataNotFoundException("discount", String.valueOf(id), "discount");
        }
    }
}
