package wq.woqod.dao.impl;


import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.Expressions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.DeviceDao;
import wq.woqod.dao.NotificationDao;
import wq.woqod.dao.UserDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.*;
import wq.woqod.dao.repository.NotificationRepository;
import wq.woqod.resources.enumerations.PushNotifEnum;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;


@Repository
@Slf4j
public class NotificationDaoImpl implements NotificationDao {
    private final NotificationRepository notificationRepository;
    private final DeviceDao deviceDao;

    @Autowired
    public NotificationDaoImpl(NotificationRepository notificationRepository, DeviceDao deviceDao) {
        this.notificationRepository = notificationRepository;
        this.deviceDao = deviceDao;
    }


    @Override
    @Async
    public void save(Notification notification) {
        try {
            this.notificationRepository.saveAndFlush(notification);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("NotificationDaoImpl", ex);
        }

    }

    @Override
    public List<NotificationProjection> getAll(MultiValueMap<String, String> parameters) {

        String titleEn = parameters.getFirst("title");
        String descriptionEn = parameters.getFirst("description");

        if(titleEn == null) {
            titleEn = "";
        }

        if(descriptionEn == null) {
            descriptionEn = "";
        }


        return  notificationRepository.getAllNotifications(titleEn, descriptionEn);
    }

    @Override
    public void delete(Long id) {
        Optional<Notification> notification = notificationRepository.findById(id);
        Notification d = notification.orElseThrow(() -> new DataNotFoundException("NotificationDaoImp", "", "Device"));
        notificationRepository.delete(d);
    }

    @Override
    public List<Notification> getAllByDevice() {
        return Collections.emptyList();
    }

    /**
     * The method {@code update} used to get filtres notifications
     *
     * @param pageable
     * @param predicate
     * @param parameters
     */
    @Override
    public Page<Notification> getFilteredNotifications(Pageable pageable, Predicate predicate, MultiValueMap<String, String> parameters) throws ParseException {
        Predicate predicateWithEquals;
        Predicate titleEn = null;
        Predicate descriptionEn = null;

        QNotification notification = QNotification.notification;
        BooleanExpression sendDate = null;

        if (parameters.get(FilterConstants.TITLE) != null) {
            titleEn = notification.titleEn.containsIgnoreCase(parameters.getFirst(FilterConstants.TITLE));
        }

        if (parameters.get(FilterConstants.DESCRIPTION) != null) {
            descriptionEn = notification.descriptionEn.containsIgnoreCase(parameters.getFirst(FilterConstants.DESCRIPTION));
        }

        if (parameters.containsKey(FilterConstants.SEND_DATE_FROM) && parameters.containsKey(FilterConstants.SEND_DATE_TO)) {
            if (!Objects.isNull(notification.sendDate) && (!Objects.isNull(parameters.get(FilterConstants.SEND_DATE_FROM))) && (!Objects.isNull(parameters.get(FilterConstants.SEND_DATE_TO)))) {
                String dateString = "";
                String dateString1 = "";
                Date date1 = null;
                Date date2 = null;
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                dateString = parameters.get(FilterConstants.SEND_DATE_FROM).get(0);
                dateString1 = parameters.get(FilterConstants.SEND_DATE_TO).get(0);


                try {

                    date1 = format.parse(dateString);

                    date2 = format.parse(dateString1);

                } catch (ParseException e) {
                    log.error(e.getMessage());
                }

                sendDate = notification.sendDate.between(date1, date2);
            }


        }

        if (null == sendDate) {
            sendDate = Expressions.asBoolean(true).isTrue();
        }
        predicateWithEquals = notification.isNotNull().andAnyOf(sendDate, titleEn, descriptionEn);
        return notificationRepository.findAll(predicateWithEquals, pageable);


    }


    @Override
    public Page<NotificationProjection> getFilteredNotifications(Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException {

        String titleEn = parameters.getFirst("title");
        String descriptionEn = parameters.getFirst("description");

        if(titleEn == null) {
            titleEn = "";
        }

        if(descriptionEn == null) {
            descriptionEn = "";
        }

        return notificationRepository.getNotifications(titleEn, descriptionEn, pageable);
    }


    /**
     * The method {@code findAllByDevice}  used to get list of  notifications
     * by Device UIID
     *
     * @param deviceID
     */
    @Override
    public List<Notification> findAllByDevice(String deviceID) {
        return new ArrayList<>();
    }

    @Override
    public List<Notification> findAllByUsername(String deviceId) {

        Optional<User> user = Optional.ofNullable(deviceDao.findByDeviceUUID(deviceId).getOwner());
        if (user.isPresent()) {
            List<Notification> list = notificationRepository.findAllByUser_UserNameOrderBySendDateDesc(user.get().getUserName());
            list = list.stream().filter(n -> n.getIsanswered().equals(Boolean.FALSE)).filter(distinctByKey(Notification::getUniqueId)).collect(toList());
            return list;
        } else {
            throw new DataNotFoundException("Device id not related to any user ", "", "User");
        }

    }

    public static <T> java.util.function.Predicate<T> distinctByKey(
            Function<? super T, ?> keyExtractor) {

        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    @Override
    public Page<Notification> findAllForAnonymousUser(Pageable pageable) {
        QNotification qNotification = QNotification.notification;
        Predicate predicate = qNotification.type.notIn(PushNotifEnum.FEEDBACK);
        return notificationRepository.findAll(predicate, pageable);
    }

    @Override
    public List<Notification> findAllForAnonymousUserList(String deviceId) {
        QNotification qNotification = QNotification.notification;
        Predicate predicate1 = null;
        Predicate predicate = qNotification.type.notIn(PushNotifEnum.FEEDBACK);
        Predicate predicateDevice = qNotification.deviceId.eq(deviceId);
        Predicate predicateAnswered = qNotification.isanswered.eq(Boolean.FALSE);
        Predicate all = qNotification.forwho.eq("ALL");
        predicate1 = qNotification.isNotNull().
                and(predicateDevice).and(predicate).and(all).and(predicateAnswered);

        return (List<Notification>) notificationRepository.findAll(predicate1, Sort.by(Sort.Direction.DESC, "sendDate"));
    }

    @Override
    public void updateStatus(Long valueOf, String username, String uniqueId, String deviceId) {
        if (uniqueId != null && !uniqueId.isEmpty()) {
            if (username != null && !username.isEmpty()) {
                List<Notification> notifications = notificationRepository.findAllByUniqueIdAndUser_UserName(uniqueId, username);
                for (Notification n : notifications
                ) {
                    n.setStatus(true);
                }
                notificationRepository.saveAll(notifications);
            } else {
                Optional<Notification> notification = notificationRepository.findByUniqueIdAndDeviceId(uniqueId,
                        deviceId);
                notification.ifPresent(value -> value.setStatus(true));
                notificationRepository.save(notification.get());
            }

        } else {
            Optional<Notification> notification = notificationRepository.findById(valueOf);
            if (username != null && !username.isEmpty()) {
                List<Notification> notifications = notificationRepository.findAllByUniqueIdAndUser_UserName(notification.get().getUniqueId()
                        , username);
                for (Notification n : notifications
                ) {
                    n.setStatus(true);
                }
                notificationRepository.saveAll(notifications);

            } else {
                notification.ifPresent(value -> value.setStatus(true));
                notificationRepository.save(notification.get());
            }
        }

    }

    @Override
    public void updateAll(Boolean connected, String deviceid) {
        List<Notification> notifications;
        if (Boolean.TRUE.equals(connected)) {
//            Device device = deviceDao.findByDeviceUUID(deviceid);
            notifications = findNotReadByUsername(deviceid);
        } else {
            notifications = findAllForAnonymousUserList(deviceid);
        }

        for (Notification n : notifications
        ) {
            n.setStatus(true);
        }
        notifications.forEach(n-> updateStatus(n.getId(), n.getUser() != null ? n.getUser().getUserName() : "", n.getUniqueId(), n.getDeviceId()));
    }

    @Override
    public void updateStatusAnswered(Long survey, String deviceId) {
        Device device = deviceDao.findByDeviceUUID(deviceId);
        if (device.getOwner() != null) {
            List<Notification> notification = notificationRepository.findAllBySurvey_IdAndUser_Id(survey, device.getOwner().getId());
            if (!notification.isEmpty()) {
                for (Notification no : notification
                ) {
                    no.setIsanswered(true);
                }
            }
            notificationRepository.saveAll(notification);

        } else {
            List<Notification> notification = notificationRepository.findAllByDeviceIdAndSurvey_Id(deviceId, survey);
            if (!notification.isEmpty()) {
                for (Notification no : notification
                ) {
                    no.setIsanswered(true);
                }
                notificationRepository.saveAll(notification);

            }
        }

    }

    @Override
    public Boolean hasNotif(String deviceid, Boolean connected) {
        if (Boolean.FALSE.equals(connected) && !findNotReadForAnonymousUserList(deviceid).isEmpty()) {
            return true;
        }
        if (Boolean.TRUE.equals(connected) && !findNotReadByUsername(deviceid).isEmpty()) {
            return true;
        }
        return false;
    }

    public List<Notification> findNotReadForAnonymousUserList(String deviceId) {
        QNotification qNotification = QNotification.notification;
        Predicate predicate1 = null;
        Predicate status = qNotification.status.eq(false);
        Predicate predicate = qNotification.type.notIn(PushNotifEnum.FEEDBACK);
        Predicate predicateDevice = qNotification.deviceId.eq(deviceId);
        Predicate all = qNotification.forwho.eq("ALL");

        predicate1 = qNotification.isNotNull().
                and(predicateDevice).and(predicate).and(all).and(status);

        return (List<Notification>) notificationRepository.findAll(predicate1);
    }

    public List<Notification> findNotReadByUsername(String deviceid) {
        Optional<User> user = Optional.ofNullable(deviceDao.findByDeviceUUID(deviceid).getOwner());
        if (user.isPresent()) {
            List<Notification> list = notificationRepository.findAllByStatusAndUser_UserName(false, user.get().getUserName());
            list = list.stream().filter(distinctByKey(Notification::getUniqueId)).collect(toList());
            return list;
        } else {
            throw new DataNotFoundException("Device id not related to any user ", "", "User");
        }
    }

    @Override
    public Long count() {
        return notificationRepository.count();
    }
}
