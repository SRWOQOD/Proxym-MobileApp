package wq.woqod.dao.entity;

import javax.persistence.Entity;
import java.io.Serializable;

@Entity
public class IndividualUser extends User implements Serializable {

    public IndividualUser() {
    }

    public IndividualUser(Builder builder) {
        super(builder);
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder extends User.Builder<Builder> {

        public Builder getThis() {
            return this;
        }

        public IndividualUser build() {
            return new IndividualUser(this);
        }

    }
}
