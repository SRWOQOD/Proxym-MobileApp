package wq.woqod.dao;

import wq.woqod.dao.entity.ShafafRetailer;

import java.util.List;

/**
 * Created by med-taher.ben-torkia on 12/30/2016.
 */
public interface ShafafRetailerDao {

    List<ShafafRetailer> getAllShafafRetailers();
}
