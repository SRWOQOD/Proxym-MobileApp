package wq.woqod.dao;

import wq.woqod.dao.entity.Company;

import java.util.List;

/**
 * Created by ameni on 24/11/16.
 */
public interface CompanyDao {

    void save(Company company);

    Company getCompanyById(String id);

    List<Company> getAllCompanies();

    boolean exist(String compId);
}
