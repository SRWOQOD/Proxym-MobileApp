package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Survey;
import wq.woqod.resources.enumerations.SurveyTypeEnum;

import java.util.List;

public interface SurveyDao {

    Survey getSurveyById(Long id);

    Survey getSurveyByTitle(String title);

    List<Survey> getSurveyByType(SurveyTypeEnum type);

    List<Survey> getAllSurveys(MultiValueMap<String, String> parameters);

    void createSurveys(Survey surveys);

    void deleteSurveys(Long id);

    void update(Survey survey);

    Page<Survey> getFilteredSurveys(Pageable pageable, MultiValueMap<String, String> parameters);

    Long count() ;
}
