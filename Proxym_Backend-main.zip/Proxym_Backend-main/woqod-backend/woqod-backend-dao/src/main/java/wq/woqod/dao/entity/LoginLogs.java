package wq.woqod.dao.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.LoginStatusEnum;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by med-amine.dahmen on 03/11/2020.
 */
@Entity
@Table(name = Constants.TABLE_LOGIN_LOGS)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginLogs {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Date creationDate;

    @Enumerated(EnumType.STRING)
    private LoginStatusEnum loginStatusEnum;

    private String userName;

    private String ip;

}
