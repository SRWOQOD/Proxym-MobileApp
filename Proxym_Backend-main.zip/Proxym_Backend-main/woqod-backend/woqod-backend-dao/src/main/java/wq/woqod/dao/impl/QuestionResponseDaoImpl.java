package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.QuestionResponseDao;
import wq.woqod.dao.entity.QuestionResponse;
import wq.woqod.dao.repository.QuestionResponseRepository;

import java.util.List;

@Repository
public class QuestionResponseDaoImpl implements QuestionResponseDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(QuestionResponseDaoImpl.class);

    private final QuestionResponseRepository questionResponseRepository;

    public QuestionResponseDaoImpl(QuestionResponseRepository questionResponseRepository) {
        this.questionResponseRepository = questionResponseRepository;
    }
    @Override
    public List<QuestionResponse> getAll() {
        return questionResponseRepository.findAll();
    }

    @Override
    public List<QuestionResponse> getBySurveyQuestionId(Long id) {
        return questionResponseRepository.getBySurveyQuestionId(id);
    }
}
