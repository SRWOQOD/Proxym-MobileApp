package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Fahes;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/03/18.
 */
public interface FahesDao {

    List<Fahes> getAllFahesStations();

    void createFahesList(List<Fahes> fahesList);

    Optional<Fahes> getFahesByFahesId(Long promotionId);

    Page<Fahes> getFilteredFahes(Pageable pageable, MultiValueMap<String, String> parameters);

}
