package wq.woqod.dao;

import wq.woqod.dao.entity.SurveyQuestion;


public interface SurveyQuestionDao {

    SurveyQuestion getQuestionById(Long id);
}
