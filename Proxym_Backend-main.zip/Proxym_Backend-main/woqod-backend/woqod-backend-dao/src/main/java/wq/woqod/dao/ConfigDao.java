package wq.woqod.dao;

import wq.woqod.dao.entity.Config;

public interface ConfigDao {
    void save(Config config);

    Config getConfigByProprety(String proprety);

    void updateConfig(Config config);
}
