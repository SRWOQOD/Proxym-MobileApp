package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.AuditUserUpdateDao;
import wq.woqod.dao.UserDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.AuditTrailUpdateUser;
import wq.woqod.dao.entity.QAuditTrailUpdateUser;
import wq.woqod.dao.repository.AuditUserUpdateRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


@Slf4j
@Component
public class AuditUserUpdateDaoImpl implements AuditUserUpdateDao {

    private final AuditUserUpdateRepository auditUserUpdateRepository;
    private final UserDao userDao;

    public AuditUserUpdateDaoImpl(AuditUserUpdateRepository auditUserUpdateRepository, UserDao userDao) {
        this.auditUserUpdateRepository = auditUserUpdateRepository;
        this.userDao = userDao;
    }

    @Override
    public AuditTrailUpdateUser save(AuditTrailUpdateUser auditTrailUpdateUser) {
        try {
            return auditUserUpdateRepository.save(auditTrailUpdateUser);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("auditBackEnd", ex);
        }

    }

    @Override
    public Page<AuditTrailUpdateUser> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate creationDate = null;
        Predicate qid = null;
        Predicate username = null;
        Predicate service = null;

        QAuditTrailUpdateUser qAuditTrailUpdateUser = QAuditTrailUpdateUser.auditTrailUpdateUser;
        Date date;

        if (params.get("qid") != null) {
            qid = qAuditTrailUpdateUser.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get("username") != null) {
            username = qAuditTrailUpdateUser.username.containsIgnoreCase(params.getFirst("username"));
        }

        if (params.get("service") != null) {
            service = qAuditTrailUpdateUser.service.containsIgnoreCase(params.getFirst("service"));
        }

        if (params.get("creationDate") != null) {
            try {
                Calendar cal1 = Calendar.getInstance();
                Calendar cal2 = Calendar.getInstance();
                date = new SimpleDateFormat("yyyy-MM-dd").parse(params.getFirst(FilterConstants.CREATION_DATE));
                cal1.setTime(date);
                cal1.set(Calendar.HOUR_OF_DAY, 0);
                cal1.set(Calendar.MINUTE, 0);
                cal1.set(Calendar.SECOND, 0);
                cal1.set(Calendar.MILLISECOND, 0);

                cal2.setTime(date);
                cal2.set(Calendar.HOUR_OF_DAY, 23);
                cal2.set(Calendar.MINUTE, 59);
                cal2.set(Calendar.SECOND, 59);
                cal2.set(Calendar.MILLISECOND, 0);
                creationDate = qAuditTrailUpdateUser.creationDate.between(cal1.getTime(), cal2.getTime());

            } catch (ParseException e) {
                log.error(e.getMessage());
            }
        } /*else {
            Date today = DateFormatter.StringToDate(LocalDate.now().toString());
            creationDate = qAuditTrailUpdateUser.creationDate.after(today);
        }*/

        Predicate predicateAuditBE = qAuditTrailUpdateUser.isNotNull()
                .and(qid)
                .and(username)
                .and(service)
                .and(creationDate);
        return auditUserUpdateRepository.findAll(predicateAuditBE, pageable);
    }

    @Override
    public Long count() {
        return auditUserUpdateRepository.count();
    }
}
