package wq.woqod.dao.entity;


import lombok.Setter;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by bfitouri on 14/11/16.
 */
@Setter
@Entity
@Table(name = Constants.TABLE_ACCOUNT)
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String pincode;

    @Column(name = "username", unique = true)
    private String username;

    private LocalDateTime creationDate;

    private int wrongAttempt;

    public Account() {
    }

    public Account(Builder builder) {
        this.id = builder.id;
        this.username = builder.userName;
        this.pincode = builder.pincode;
        this.creationDate = builder.creationDate;
        this.wrongAttempt = builder.wrongAttempt;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public String getPincode() {
        return pincode;
    }

    public String getUsername() {
        return username;
    }

    public int getWrongAttempt() {
        return wrongAttempt;
    }

    public static class Builder {

        private Long id;
        private String pincode;
        private String userName;
        private LocalDateTime creationDate;
        private int wrongAttempt;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder pincode(String pincode) {
            this.pincode = pincode;
            return this;
        }

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Builder creationDate(LocalDateTime creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder wrongAttempt(int wrongAttempt) {
            this.wrongAttempt = wrongAttempt;
            return this;
        }

        public Account build() {
            return new Account(this);
        }
    }
}
