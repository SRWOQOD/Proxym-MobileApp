package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_NEWS)
public class NewsHome {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Boolean active;

    private Date creationDate;

    @Lob
    private String details;

    @Lob
    @Column(name = "details_arabic")
    private String detailsArabic;

    private String link;

    private String linkAr;

    private String picture;

    private String secondPicture;

    private Integer views;

    private String title;

    @Column(name = "title_arabic")
    private String titleArabic;
}
