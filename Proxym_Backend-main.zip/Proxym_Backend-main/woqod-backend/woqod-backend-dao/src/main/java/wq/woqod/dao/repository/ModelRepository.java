package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.Model;

import java.util.List;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Repository
public interface ModelRepository extends JpaRepository<Model, Long> {

    Model getByModelId(String modelId);

    List<Model> getAllByNameEn(String nameEn);
}
