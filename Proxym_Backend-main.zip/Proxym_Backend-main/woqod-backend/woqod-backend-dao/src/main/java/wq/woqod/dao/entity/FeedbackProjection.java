
package wq.woqod.dao.entity;

import java.util.Date;

public interface FeedbackProjection {

    Long getID();

    String getNAME();

    String getCONTENT();

    String getCATEGORY();

    String getSECTOR();

    Date getCREATION_DATE();
}

