package wq.woqod.dao;


import wq.woqod.dao.entity.Amount;

public interface AmountDao {
    public void update(Amount amount);

    public Amount findByName(String s);
}
