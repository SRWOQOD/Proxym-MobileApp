package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.AppRedirection;

public interface AppRedirectionRepository extends JpaRepository<AppRedirection, Long> {
    AppRedirection getHomeRedirectionByName(String name);
}
