package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.dao.entity.SurveyQuestion;
import wq.woqod.dao.repository.SurveyQuestionRepository;

import java.util.Optional;

@Component
@Transactional
public class SurveyQuestionDaoImpl implements wq.woqod.dao.SurveyQuestionDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyQuestionDaoImpl.class);
    private final SurveyQuestionRepository surveyQuestionRepository;

    @Autowired
    public SurveyQuestionDaoImpl(SurveyQuestionRepository surveyQuestionRepository) {
        this.surveyQuestionRepository = surveyQuestionRepository;
    }

    @Override
    public SurveyQuestion getQuestionById(Long id) {
        LOGGER.info("[DAO] GET Survey Question by Id {}", id);
        Optional<SurveyQuestion> surveyQuestion = Optional.ofNullable(surveyQuestionRepository.findSurveyQuestionById(id));
        return surveyQuestion.orElseThrow(() -> new DataNotFoundException("survey", String.valueOf(id), "Survey Question"));
    }

}