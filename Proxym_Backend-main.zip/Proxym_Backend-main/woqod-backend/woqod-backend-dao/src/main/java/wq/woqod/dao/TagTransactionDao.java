package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.TagTransaction;
import wq.woqod.resources.resources.inputs.InputUpdateTransaction;

import java.text.ParseException;
import java.util.List;

/**
 * Created bymed-amine.dahmen
 */
public interface TagTransactionDao {

    TagTransaction save(TagTransaction tagTransaction);

    TagTransaction findByTransactionUUid(String tagTransactionResource);

    Page<TagTransaction> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException;

    TagTransaction update(InputUpdateTransaction inputUpdateTransaction);

    List<TagTransaction> getAll(MultiValueMap<String, String> params) throws ParseException;

    Long count();
}
