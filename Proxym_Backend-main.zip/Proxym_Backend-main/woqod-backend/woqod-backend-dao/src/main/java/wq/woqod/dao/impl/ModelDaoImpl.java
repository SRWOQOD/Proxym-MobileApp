package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.ModelDao;
import wq.woqod.dao.entity.Model;
import wq.woqod.dao.repository.ModelRepository;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Slf4j
@Component
public class ModelDaoImpl implements ModelDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(ModelDaoImpl.class);

    @Autowired
    public ModelRepository modelRepository;

    @Override
    public Model getModelByGivenId(String modelId) {
        return modelRepository.getByModelId(modelId);
    }

    @Override
    public Model save(Model model) {
        try {
            return modelRepository.save(model);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting model entity..", ex);
            throw new PersistingDataException("model", ex);
        }
    }
}
