package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.CompanyDao;
import wq.woqod.dao.entity.Company;
import wq.woqod.dao.repository.CompanyRepository;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 24/11/16.
 */
@Slf4j
@Component
public class CompanyDaoImpl implements CompanyDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyDaoImpl.class);

    private final CompanyRepository companyRepository;

    @Autowired
    public CompanyDaoImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public void save(Company company) {
        try {
            companyRepository.saveAndFlush(company);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting company entity..", ex);
            throw new PersistingDataException("company", ex);
        }
    }

    @Override
    public Company getCompanyById(String id) {
        LOGGER.debug("getCompanyById : {}", id);
        Optional<Company> company = companyRepository.findOneByCompanyId(id);
        return company.orElseThrow(() -> new DataNotFoundException("company", id, "Company"));
    }

    @Override
    public List<Company> getAllCompanies() {
        LOGGER.debug("[DAO] GET All Companies");
        return companyRepository.findAll();
    }

    @Override
    public boolean exist(String compId) {
        Company company = Company.newBuilder().companyId(compId).build();
        return companyRepository.exists(Example.of(company));
    }
}
