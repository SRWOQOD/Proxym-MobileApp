package wq.woqod.dao.entity;

import org.hibernate.annotations.NaturalId;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Created by ameni on 26/11/16.
 */
@Entity
@Table(name = Constants.TABLE_PETROL)
public class Petrol implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NaturalId
    @Column(unique = true)
    private Long petrolId;

    private String name;

    private String arabicName;

    private Double price;

    @Column(name = "last_synchronisation_date")
    private LocalDateTime date;

    @Column(name = "lastsyncdate")
    private LocalDateTime syncdate;

    public Petrol() {
    }

    private Petrol(Builder builder) {
        this.id = builder.id;
        this.petrolId = builder.petrolId;
        this.name = builder.name;
        this.arabicName = builder.arabicName;
        this.price = builder.price;
        this.date = builder.date;
        this.syncdate = builder.syncdate;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getArabicName() {
        return arabicName;
    }

    public Double getPrice() {
        return price;
    }

    public Long getPetrolId() {
        return petrolId;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public LocalDateTime getSyncdate() {
        return syncdate;
    }

    public static class Builder {

        private Long id;
        private String name;
        private String arabicName;
        private Double price;
        private Long petrolId;
        private LocalDateTime date;
        private LocalDateTime syncdate;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder arabicName(String arabicName) {
            this.arabicName = arabicName;
            return this;
        }

        public Builder price(Double price) {
            this.price = price;
            return this;
        }

        public Builder petrolId(Long petrolId) {
            this.petrolId = petrolId;
            return this;
        }

        public Builder date(LocalDateTime date) {
            this.date = date;
            return this;
        }

        public Builder syncdate(LocalDateTime syncdate) {
            this.syncdate = syncdate;
            return this;
        }

        public Petrol build() {
            return new Petrol(this);
        }

    }
}
