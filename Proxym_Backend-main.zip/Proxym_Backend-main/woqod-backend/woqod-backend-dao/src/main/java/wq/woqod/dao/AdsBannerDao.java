package wq.woqod.dao;

import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.AdsBanner;

import java.util.List;

public interface AdsBannerDao {
    void save(AdsBanner adsBanner);

    List<AdsBanner> getAdsbanner();

    List<AdsBanner> filter(MultiValueMap<String, String> parameters);

    AdsBanner getById(Long valueOf);

    void update(List<AdsBanner> list);

    void update(AdsBanner adsBanner);

    List<AdsBanner> getActiveAdsBanner();

    Long count();

    void delete(Long id);
}
