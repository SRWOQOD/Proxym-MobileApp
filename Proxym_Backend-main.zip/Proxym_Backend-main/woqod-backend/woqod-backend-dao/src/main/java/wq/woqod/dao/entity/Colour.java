package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 28/11/2018.
 */
@Entity
@Table(name = Constants.TABLE_COLOUR)
public class Colour {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "colour_id")
    private String colourId;

    @Column(name = "colour_name_en")
    private String nameEn;

    @Column(name = "colour_name_ar")
    private String nameAr;

    //@OneToMany(mappedBy = "colour", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    //private List<Car> carList;


    public Colour() {
    }

    public Colour(Builder builder) {
        this.id = builder.id;
        this.colourId = builder.colourId;
        this.nameEn = builder.nameEn;
        this.nameAr = builder.nameAr;
 //       this.carList = builder.carList;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getColourId() {
        return colourId;
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

//    public List<Car> getCarList() {
//        return carList;
 //   }

    public static class Builder {

        private Long id;
        private String colourId;
        private String nameEn;
        private String nameAr;
    //    private List<Car> carList;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder colourId(String colourId) {
            this.colourId = colourId;
            return this;
        }

        public Builder nameEn(String nameEn) {
            this.nameEn = nameEn;
            return this;
        }

        public Builder nameAr(String nameAr) {
            this.nameAr = nameAr;
            return this;
        }

      //  public Builder carList(List<Car> carList) {
        //    this.carList = carList;
          //  return this;
       // }

        public Colour build() {
            return new Colour(this);
        }
    }
}
