package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import net.minidev.json.annotate.JsonIgnore;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.ContactMethodEnum;
import wq.woqod.resources.enumerations.GenderTypeEnum;
import wq.woqod.resources.enumerations.StatusEnum;
import wq.woqod.resources.enumerations.UserTypeEnum;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity(name = Constants.TABLE_USER)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@AllArgsConstructor
public abstract class User implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "user_name", unique = true, nullable = false)
    private String userName;

    @Column(name = "user_type")
    @Enumerated(EnumType.STRING)
    private UserTypeEnum userType;

    @Column(name = "contact_type")
    @Enumerated(EnumType.STRING)
    private ContactMethodEnum contactType;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "encrypted_qid")
    private String qid;

    private LocalDate birthDate;

    @Enumerated(EnumType.STRING)
    private GenderTypeEnum gender;

    private String phone;

    private String email;

    private String jobTitle;

    private String adress1;

    @Column(name = "adress_1_label")
    private String adress1Label;

    private String adress2;

    @Column(name = "adress_2_label")
    private String adress2Label;

    @Enumerated(EnumType.STRING)
    private StatusEnum status;

    @Column(name = "employee_id")
    private String employeeId;

    private String functionality;

    @Column(name = "site_id")
    private String siteId;

    @Column(name = "fleet_name")
    private String fleetName;


    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserRole> userRoles;

    @OneToOne
    @JoinColumn(name = "surveyresponse_id")
    private SurveyResponse surveyResponse;

    @OneToMany(mappedBy = "owner", fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true)
    private List<Device> devices;


    @OneToMany(mappedBy = "owner", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Feedback> feedbacks;

    @OneToMany(mappedBy = "owner", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Car> cars;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id")
    private Company company;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "customer_id")
    private String customerId;

    @Column(name = "vehicule_brand")
    private String vehiculeBrand;

    @Column(name = "unlock_Account")
    private String unlockAccount;

    @Column(name = "vehicule_Model")
    private String vehiculeModel;

    @OneToOne
    @JoinColumn(name = "account_id")
    private Account account;

    private Double income;

    private String preferedLanguage;

    private String poBox;

    @Lob
    @Column(name = "photo_new")
    private String photo;

    private LocalDate createdAt;

    private String customIdentification;

    private Boolean isBiometricActivated;

    @Column(name = "is_woqode_user")
    private Boolean isWoqodeUser;

    protected User() {
    }

    public User(Builder builder) {
        this.id = builder.id;
        this.userType = builder.userType;
        this.contactType = builder.contactType;
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.qid = builder.qid;
        this.userName = builder.userName;
        this.feedbacks = (builder.feedbacks != null) ? builder.feedbacks : new ArrayList<>();
        this.birthDate = builder.birthDate;
        this.gender = builder.gender;
        this.phone = builder.phone;
        this.email = builder.email;
        this.adress1 = builder.adress1;
        this.adress1Label = builder.adress1Label;
        this.adress2 = builder.adress2;
        this.adress2Label = builder.adress2Label;
        this.status = builder.status;
        this.employeeId = builder.employeeId;
        this.functionality = builder.functionality;
        this.siteId = builder.siteId;
        this.userRoles = (builder.userRoles != null) ? builder.userRoles : new ArrayList<>();
        this.surveyResponse = builder.surveyResponse;
        this.devices = (builder.devices != null) ? builder.devices : new ArrayList<>();
        this.cars = (builder.cars != null) ? builder.cars : new ArrayList<>();
        this.company = builder.company;
        this.createdBy = builder.createdBy;
        this.customerId = builder.customerId;
        this.fleetName = builder.fleetName;
        this.account = builder.account;
        this.jobTitle = builder.jobTitle;
        this.income = builder.income;
        this.preferedLanguage = builder.preferedLanguage;
        this.photo = builder.photo;
        this.createdAt = builder.createdAt;
        this.vehiculeBrand = builder.vehiculeBrand;
        this.vehiculeModel = builder.vehiculeModel;
        this.unlockAccount = builder.unlockAccount;
        this.area = builder.area;
        this.poBox = builder.poBox;
        this.isBiometricActivated = builder.isBiometricActivated;
        this.customIdentification = builder.customIdentification;

    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserTypeEnum getUserType() {
        return this.userType;
    }

    public void setUserType(UserTypeEnum userType) {
        this.userType = userType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Feedback> getFeedbacks() {
        return feedbacks;
    }

    public String getAdress1() {
        return adress1;
    }

    public void setAdress1(String adress1) {
        this.adress1 = adress1;
    }

    public String getAdress1Label() {
        return adress1Label;
    }

    public void setAdress1Label(String adress1Label) {
        this.adress1Label = adress1Label;
    }

    public String getAdress2() {
        return adress2;
    }

    public void setAdress2(String adress2) {
        this.adress2 = adress2;
    }

    public String getUnlockAccount() {
        return unlockAccount;
    }

    public void setUnlockAccount(String unlockAccount) {
        this.unlockAccount = unlockAccount;
    }

    public String getAdress2Label() {
        return adress2Label;
    }

    public void setAdress2Label(String adress2Label) {
        this.adress2Label = adress2Label;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public List<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public SurveyResponse getSurveyResponse() {
        return surveyResponse;
    }

    public ContactMethodEnum getContactType() {
        return contactType;
    }

    public void setContactType(ContactMethodEnum contactType) {
        this.contactType = contactType;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public GenderTypeEnum getGender() {
        return gender;
    }

    public void setGender(GenderTypeEnum gender) {
        this.gender = gender;
    }

    public StatusEnum getStatus() {
        return status;
    }

    public void setStatus(StatusEnum status) {
        this.status = status;
    }

    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getFleetName() {
        return fleetName;
    }

    public String getFunctionality() {
        return functionality;
    }

    public void setFunctionality(String functionality) {
        this.functionality = functionality;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getVehiculeBrand() {
        return vehiculeBrand;
    }

    public String getVehiculeModel() {
        return vehiculeModel;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public Double getIncome() {
        return income;
    }

    public String getPreferedLanguage() {
        return preferedLanguage;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getCustomIdentification() {
        return customIdentification;
    }

    public void setCustomIdentification(String customIdentification) {
        this.customIdentification = customIdentification;
    }

    public Boolean getBiometricActivated() {
        return isBiometricActivated;
    }

    public void setBiometricActivated(Boolean biometricActivated) {
        isBiometricActivated = biometricActivated;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public String getPoBox() {
        return poBox;
    }

    public void setPoBox(String poBox) {
        this.poBox = poBox;
    }

    public Boolean getIsWoqodeUser() {
        return isWoqodeUser;
    }

    public void setWoqodeUser(Boolean woqodeUser) {
        isWoqodeUser = woqodeUser;
    }

    public void setFeedbacks(List<Feedback> feedbacks) {
        this.feedbacks = feedbacks;
    }

    public abstract static class Builder<T> {
        private Long id;
        private UserTypeEnum userType;
        private ContactMethodEnum contactType;
        private String firstName;
        private String lastName;
        private String jobTitle;
        private String qid;
        private String userName;
        private LocalDate birthDate;
        private GenderTypeEnum gender;
        private String phone;
        private String email;
        private String adress1;
        private String adress1Label;
        private String adress2;
        private String adress2Label;
        private StatusEnum status;
        private String employeeId;
        private String functionality;
        private String siteId;
        private List<Device> devices;
        private List<Feedback> feedbacks;
        private List<Car> cars;
        private List<UserRole> userRoles;
        private SurveyResponse surveyResponse;
        private Company company;
        private String createdBy;
        private String customerId;
        private Account account;
        private Double income;
        private String preferedLanguage;
        private String photo;
        private LocalDate createdAt;
        private String fleetName;
        private String vehiculeBrand;
        private String vehiculeModel;
        private String unlockAccount;
        private Area area;
        private String poBox;
        private String customIdentification;
        private Boolean isBiometricActivated;
        private QidCard qidCard;

        public T id(Long id) {
            this.id = id;
            return getThis();
        }

        public T qidCard(QidCard qidCard) {
            this.qidCard = qidCard;
            return getThis();
        }

        public T poBox(String poBox) {
            this.poBox = poBox;
            return getThis();
        }

        public T customIdentification(String customIdentification) {
            this.customIdentification = customIdentification;
            return getThis();
        }

        public T isBiometricActivated(Boolean isBiometricActivated) {
            this.isBiometricActivated = isBiometricActivated;
            return getThis();
        }

        public T userType(UserTypeEnum userType) {
            this.userType = userType;
            return getThis();
        }

        public T unlockAccount(String unlockAccount) {
            this.unlockAccount = unlockAccount;
            return getThis();
        }

        public T fleetName(String fleetId) {
            this.fleetName = fleetId;
            return getThis();
        }

        public T vehiculeBrand(String vehiculeBrand) {
            this.vehiculeBrand = vehiculeBrand;
            return getThis();
        }

        public T vehiculeModel(String vehiculeModel) {
            this.vehiculeModel = vehiculeModel;
            return getThis();
        }

        public T contactType(ContactMethodEnum contactType) {
            this.contactType = contactType;
            return getThis();
        }

        public T jobTitle(String jobTitle) {
            this.jobTitle = jobTitle;
            return getThis();
        }

        public T firstName(String firstName) {
            this.firstName = firstName;
            return getThis();
        }

        public T firstName(List<Feedback> feedbacks) {
            this.feedbacks = feedbacks;
            return getThis();
        }

        public T lastName(String lastName) {
            this.lastName = lastName;
            return getThis();
        }

        public T qid(String qid) {
            this.qid = qid;
            return getThis();
        }

        public T userName(String userName) {
            this.userName = userName;
            return getThis();
        }

        public T birthDate(LocalDate birthDate) {
            this.birthDate = birthDate;
            return getThis();
        }

        public T gender(GenderTypeEnum gender) {
            this.gender = gender;
            return getThis();
        }

        public T phone(String phone) {
            this.phone = phone;
            return getThis();
        }

        public T email(String email) {
            this.email = email;
            return getThis();
        }

        public T adress1(String adress1) {
            this.adress1 = adress1;
            return getThis();
        }

        public T adress1Label(String adress1Label) {
            this.adress1Label = adress1Label;
            return getThis();
        }

        public T adress2(String adress2) {
            this.adress2 = adress2;
            return getThis();
        }

        public T adress2Label(String adress2Label) {
            this.adress2Label = adress2Label;
            return getThis();
        }

        public T status(StatusEnum status) {
            this.status = status;
            return getThis();
        }

        public T employeeId(String employeeId) {
            this.employeeId = employeeId;
            return getThis();
        }

        public T functionality(String functionality) {
            this.functionality = functionality;
            return getThis();
        }

        public T siteId(String siteId) {
            this.siteId = siteId;
            return getThis();
        }

        public T company(Company company) {
            this.company = company;
            return getThis();
        }

        public T photo(String photo) {
            this.photo = photo;
            return getThis();
        }

        public T devices(List<Device> devices) {
            this.devices = devices;
            return getThis();
        }

        public T cars(List<Car> cars) {
            this.cars = cars;
            return getThis();
        }


        public T userRoles(List<UserRole> userRoles) {
            this.userRoles = userRoles;
            return getThis();
        }

        public T surveyResponse(SurveyResponse surveyResponse) {
            this.surveyResponse = surveyResponse;
            return getThis();
        }

        public T createdBy(String createdBy) {
            this.createdBy = createdBy;
            return getThis();
        }

        public T customerId(String customerId) {
            this.customerId = customerId;
            return getThis();
        }

        public T account(Account account) {
            this.account = account;
            return getThis();
        }

        public T income(Double income) {
            this.income = income;
            return getThis();
        }

        public T preferedLanguage(String preferedLanguage) {
            this.preferedLanguage = preferedLanguage;
            return getThis();
        }

        public T String(String photo) {
            this.photo = photo;
            return getThis();
        }

        public T createdAt(LocalDate createdAt) {
            this.createdAt = createdAt;
            return getThis();
        }

        public T area(Area area) {
            this.area = area;
            return getThis();
        }


        public abstract T getThis();
    }

}
