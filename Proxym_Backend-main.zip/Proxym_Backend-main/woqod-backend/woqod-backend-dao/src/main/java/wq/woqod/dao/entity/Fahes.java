package wq.woqod.dao.entity;

import com.google.common.collect.Sets;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Set;

/**
 * Created by ameni on 26/11/16.
 */
@Entity
@Table(name = Constants.TABLE_FAHES)
public class Fahes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected Long id;
    @Column(unique = true)
    private Long fahesId;
    private String title;
    @Column(name = "title_arabic")
    private String titleArabic;
    private String phone;
    private String icon;
    private String status;
    private Double longitude;
    private Double latitude;
    @OneToOne
    @JoinColumn(name = "area_id")
    private Area area;

    @Column(name = "working_days")
    private String workingDays;
    @Column(name = "arabic_working_days")
    private String arabicWorkingDays;
    @Column(name = "first_address")
    private String firstAddress;
    @Column(name = "arabic_first_address")
    private String arabicFirstAddress;
    @Column(name = "second_address")
    private String secondAddress;
    @Column(name = "arabic_second_address")
    private String arabicSecondAddress;
    @Column(name = "last_synchronisation_date")
    private LocalDateTime lastSynchronisationDate;

    @OneToMany(mappedBy = "station", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<wq.woqod.dao.entity.ServiceStation> serviceStations;

    public Fahes() {
    }

    private Fahes(Builder builder) {
        this.id = builder.id;
        this.fahesId = builder.fahesId;
        this.title = builder.title;
        this.titleArabic = builder.titleArabic;
        this.phone = builder.phone;
        this.status = builder.status;
        this.longitude = builder.longitude;
        this.latitude = builder.latitude;
        this.area = builder.area;
        this.workingDays = builder.workingDays;
        this.arabicWorkingDays = builder.arabicWorkingDays;
        this.firstAddress = builder.firstAddress;
        this.arabicFirstAddress = builder.arabicFirstAddress;
        this.secondAddress = builder.secondAddress;
        this.arabicSecondAddress = builder.arabicSecondAddress;
        this.lastSynchronisationDate = builder.lastSynchronisationDate;
        this.icon = builder.icon;
        this.serviceStations = Objects.isNull(builder.serviceStations) ? Sets.newHashSet() : builder.serviceStations;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public Long getFahesId() {
        return fahesId;
    }

    public String getTitle() {
        return title;
    }

    public String getTitleArabic() {
        return titleArabic;
    }

    public String getPhone() {
        return phone;
    }

    public String getStatus() {
        return status;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Area getArea() {
        return area;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public String getArabicWorkingDays() {
        return arabicWorkingDays;
    }

    public String getFirstAddress() {
        return firstAddress;
    }

    public String getArabicFirstAddress() {
        return arabicFirstAddress;
    }

    public String getSecondAddress() {
        return secondAddress;
    }

    public String getArabicSecondAddress() {
        return arabicSecondAddress;
    }

    public LocalDateTime getLastSynchronisationDate() {
        return lastSynchronisationDate;
    }

    public Set<wq.woqod.dao.entity.ServiceStation> getServiceStations() {
        return serviceStations;
    }

    public void addServices(Set<wq.woqod.dao.entity.ServiceStation> services) {
        services.forEach(this::addService);
    }

    /**
     * if service already exists (same station and same name),
     * we remove it and add it for update
     *
     * @param serviceStation
     */
    public void addService(wq.woqod.dao.entity.ServiceStation serviceStation) {
        if (serviceStations.contains(serviceStation)) {
            serviceStations.remove(serviceStation);
        }
        serviceStations.add(serviceStation);
    }

    public void removeServices(Set<wq.woqod.dao.entity.ServiceStation> serviceStations) {
        serviceStations.forEach(this::removeService);
    }

    public void removeService(wq.woqod.dao.entity.ServiceStation serviceStation) {
        serviceStations.remove(serviceStation);
    }

    public String getIcon() {
        return icon;
    }

    public static class Builder {

        protected Long id;
        protected Long fahesId;
        protected String title;
        protected String titleArabic;
        protected String phone;
        protected String status;
        protected Double longitude;
        protected Double latitude;
        protected Area area;
        protected String workingDays;
        protected String arabicWorkingDays;
        protected String firstAddress;
        protected String arabicFirstAddress;
        protected String secondAddress;
        protected String icon;
        protected String arabicSecondAddress;
        protected LocalDateTime lastSynchronisationDate;
        private Set<wq.woqod.dao.entity.ServiceStation> serviceStations;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder fahesId(Long fahesId) {
            this.fahesId = fahesId;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }
        public Builder icon(String icon) {
            this.icon = icon;
            return this;
        }

        public Builder titleArabic(String titleArabic) {
            this.titleArabic = titleArabic;
            return this;
        }

        public Builder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder longitude(Double longitude) {
            this.longitude = longitude;
            return this;
        }

        public Builder latitude(Double latitude) {
            this.latitude = latitude;
            return this;
        }

        public Builder area(Area area) {
            this.area = area;
            return this;
        }

        public Builder workingDays(String workingDays) {
            this.workingDays = workingDays;
            return this;
        }

        public Builder arabicWorkingDays(String arabicWorkingDays) {
            this.arabicWorkingDays = arabicWorkingDays;
            return this;
        }

        public Builder firstAddress(String firstAddress) {
            this.firstAddress = firstAddress;
            return this;
        }

        public Builder arabicFirstAddress(String arabicFirstAddress) {
            this.arabicFirstAddress = arabicFirstAddress;
            return this;
        }

        public Builder secondAddress(String secondAddress) {
            this.secondAddress = secondAddress;
            return this;
        }

        public Builder arabicSecondAddress(String arabicSecondAddress) {
            this.arabicSecondAddress = arabicSecondAddress;
            return this;
        }

        public Builder lastSynchronisationDate(LocalDateTime lastSynchronisationDate) {
            this.lastSynchronisationDate = lastSynchronisationDate;
            return this;
        }

        public Builder serviceStations(Set<ServiceStation> serviceStations) {
            this.serviceStations = serviceStations;
            return this;
        }

        public Fahes build() {
            return new Fahes(this);
        }

    }
}