package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * Created by ameni on 02/12/16.
 */
@Entity
@Table(name = Constants.TABLE_RATING)
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "device_serial")
    private String deviceId;

    @Column(name = "station_id")
    private Long stationId;

    @Column(name = "creation_date", columnDefinition = "DATE")
    private LocalDate creationDate;

    private int rating;

    public Rating() {
    }

    private Rating(Builder builder) {
        this.id = builder.id;
        this.creationDate = builder.creationDate;
        this.deviceId = builder.deviceId;
        this.stationId = builder.stationId;
        this.rating = builder.rating;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getRaiting() {
        return rating;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public Long getStationId() {
        return stationId;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Rating{" +
                "id=" + id +
                ", deviceId='" + deviceId + '\'' +
                ", stationId=" + stationId +
                ", creationDate=" + creationDate +
                ", rating=" + rating +
                '}';
    }

    public static class Builder {

        private Long id;
        private LocalDate creationDate;
        private String deviceId;
        private int rating;
        private Long stationId;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder creationDate(LocalDate creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder deviceId(String deviceId) {
            this.deviceId = deviceId;
            return this;
        }

        public Builder rating(int rating) {
            this.rating = rating;
            return this;
        }

        public Builder stationId(Long stationId) {
            this.stationId = stationId;
            return this;
        }

        public Rating build() {
            return new Rating(this);
        }

    }

}

