package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.entity.Device;
import wq.woqod.dao.entity.DeviceId;
import wq.woqod.dao.entity.User;
import wq.woqod.resources.enumerations.DeviceStatusEnum;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 12/27/2016.
 */
public interface DeviceRepository extends JpaRepository<Device, Long>, QuerydslPredicateExecutor<Device> {

    Optional<Device> findById(DeviceId id);
//FIXME
//    Optional<Device> findBySerial(String serial);
//
//    Optional<Device> findBySerialAndStatus(String serial, DeviceStatusEnum status);

    List<Device> findByOwner(User owner);

    @Modifying
    @Transactional
    @Query("update Device u set u.status = ?1 where u.deviceId = ?2 ")
    void updateStatus(DeviceStatusEnum status, String personId);

    /**
     * @param bioPin
     * @param customPwd
     * @param deviceId
     */
    @Modifying
    @Transactional
    @Query("update Device d set d.bioPin = ?1 , d.customPwd = ?2 where d.deviceId= ?3 and  d.owner.id =?4")
    void updateBioPin(String bioPin, String customPwd, String deviceId, Long userId);

    /**
     * @param deviceId
     * @param lastConnection
     */
    @Modifying
    @Transactional
    @Query("update Device d set d.lastConnection = ?3  where d.deviceId= ?1 and d.owner.id =?2")
    void updateLastConnection(String deviceId, Long userId, java.util.Date lastConnection);

    List<Device> findByOwnerAndStatus(User owner, Boolean isEnabled);

    /**
     * @param userName
     * @return
     */
    List<Device> findDeviceByDeviceIdAndOwnerUserNameNotAndCustomPwdNotNull(String deviceId, String userName);


    Device findByDeviceIdAndStatus(String deviceId, DeviceStatusEnum active);

    /**
     * @param deviceId
     */
    @Modifying
    @Transactional
    @Query("update Device d set  d.customPwd = null where d.deviceId= ?1")
    void disableFinger(String deviceId);

    Optional<List<Device>> findAllByStatus(DeviceStatusEnum status);

    @Modifying
    @Transactional
    @Query(value ="update Device d set d.creationDate= ?5 , d.deviceType = ?3, d.lastConnection = ?4, " +
            "d.deviceId = ?2 , d.owner.id =?6  where d.id= ?1 ")
    int saveAndFlushDevice(Long id, String deviceId, String deviceType, Date lastConnection,
                           Date creationDate,Long owner);
//@Modifying
//    @Transactional
//    @Query(value ="create  Device d set d.creationDate= ?5 , d.deviceType = ?3, d.lastConnection = ?4, " +
//            "d.deviceId = ?2 , d.owner.id =?6  where d.id= ?1 ")
//    int screateDevice(Long id, String deviceId, String deviceType, Date lastConnection,
//                           Date creationDate,Long owner);

Device findFirstByDeviceId(String deviceId);

    @Query("SELECT d.deviceId from  Device d where d.owner.isWoqodeUser = true ")
    List<String> getDevicesForWoqodeUsers();

    @Query("SELECT d.id from  users d where d.isWoqodeUser = true ")
    List<String> getWoqodeUsersId();


}

