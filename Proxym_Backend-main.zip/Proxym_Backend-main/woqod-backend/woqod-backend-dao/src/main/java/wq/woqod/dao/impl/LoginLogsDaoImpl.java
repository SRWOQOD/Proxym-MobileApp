package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.LoginLogsDao;
import wq.woqod.dao.entity.LoginLogs;
import wq.woqod.dao.entity.QLoginLogs;
import wq.woqod.dao.repository.LoginLogsRepository;
import wq.woqod.resources.enumerations.LoginStatusEnum;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.Date;
import java.util.Optional;

/**
 * Created by med-amine.dahmen on 03/11/2020.
 */
@Component
@Slf4j
@Transactional
public class LoginLogsDaoImpl implements LoginLogsDao {

    private final LoginLogsRepository loginLogsRepository;

    public LoginLogsDaoImpl(LoginLogsRepository loginLogsRepository) {
        this.loginLogsRepository = loginLogsRepository;
    }

    @Override
    public void save(LoginLogs loginLogs) {
        try {
            loginLogsRepository.save(loginLogs);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("LoginLogs", ex);
        }
    }

    @Override
    public Optional<LoginLogs> findLastLoginLogsByUsernameAndLoginStatusEnum(String username, LoginStatusEnum status) {
        return loginLogsRepository.findTopByUserNameAndLoginStatusEnumOrderByCreationDateDesc(username, status);
    }

    @Override
    public BigInteger getStatics(String qid, String from, String to, LoginStatusEnum success) throws ParseException {
        BigInteger x = new BigInteger("0");

        Predicate fromp = null;
        Predicate top = null;
        QLoginLogs qLoginLogs = QLoginLogs.loginLogs;

        if (from != null) {
            fromp = qLoginLogs.creationDate.after(DateFormatter.StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((DateFormatter.StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qLoginLogs.creationDate.before(tomorrow);
        }

        Predicate predicateSuccess = qLoginLogs.isNotNull()
                .and(top)
                .and(qLoginLogs.loginStatusEnum.eq(success))
                .and(fromp);

        return BigInteger.valueOf(loginLogsRepository.count(predicateSuccess));
    }


}
