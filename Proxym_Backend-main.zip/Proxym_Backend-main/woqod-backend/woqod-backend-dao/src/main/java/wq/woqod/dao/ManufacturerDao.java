package wq.woqod.dao;

import wq.woqod.dao.entity.Manufacturer;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
public interface ManufacturerDao {

    Manufacturer getManufacturerByGiveId(String manufacturerId);

    Manufacturer save(Manufacturer manufacturer);
}
