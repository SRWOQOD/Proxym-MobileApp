package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.UserUpdateTypeEnum;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = Constants.TABLE_AUDITTRAIL_UPDATE_USER)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditTrailUpdateUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String qid;

    private Date creationDate;

    private String ip;

    private String service;

    private String username;

    private UserUpdateTypeEnum userUpdateSourceEnum;

    @Lob
    private String oldValue;

    @Lob
    private String newValue;

}
