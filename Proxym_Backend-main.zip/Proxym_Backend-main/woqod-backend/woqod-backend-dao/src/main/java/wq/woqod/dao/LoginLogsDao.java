package wq.woqod.dao;

import wq.woqod.dao.entity.LoginLogs;
import wq.woqod.resources.enumerations.LoginStatusEnum;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.Optional;

/**
 * Created by med-amine.dahmen on 03/11/2020.
 */
public interface LoginLogsDao {

    void save(LoginLogs loginLogs);

    Optional<LoginLogs> findLastLoginLogsByUsernameAndLoginStatusEnum(String username, LoginStatusEnum status);

    BigInteger getStatics(String qid, String from, String to, LoginStatusEnum success) throws ParseException;
}
