package wq.woqod.dao.impl;

import com.google.common.collect.Lists;
import com.querydsl.core.BooleanBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.NotAllowedOperationException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.RoleDao;
import wq.woqod.dao.entity.QRole;
import wq.woqod.dao.entity.Role;
import wq.woqod.dao.repository.RoleRepository;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Created by bfitouri on 24/11/16.
 */
@Component
public class RoleDaoImpl implements RoleDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(RoleDaoImpl.class);
    private static Role roleAdmin = Role.newBuilder().designation("Admin").internalName("Administrator").isTemplate(false).build();
    private static Role roleAnonym = Role.newBuilder().designation("None").internalName("DefaultRole").isTemplate(false).build();
    private final RoleRepository roleRepository;

    @Autowired
    public RoleDaoImpl(final RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    //    @PostConstruct
    public void init() {
        Optional<Role> roleManager = roleRepository.findByDesignation("Admin");
        if (!roleManager.isPresent()) {
            roleRepository.save(roleAdmin);
        }
        Optional<Role> roleAnonymous = roleRepository.findByDesignation("None");
        if (!roleAnonymous.isPresent()) {
            roleRepository.save(roleAnonym);
        }
    }

    @Override
    public Role save(Role role) {
        try {
            return roleRepository.save(role);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("role", ex);
        }
    }

    @Override
    public Role getRoleById(Long id) {
        Optional<Role> role = roleRepository.findById(id);
        return role.orElseThrow(() -> new DataNotFoundException("role", String.valueOf(id), "Role"));
    }

    @Override
    public Role getRoleByDesignation(String designation) {
        Optional<Role> role = roleRepository.findByDesignation(designation);
        return role.orElseThrow(() -> new DataNotFoundException("role", designation, "Role"));
    }

    @Override
    public List<Role> getRoles(String designation, String internalName) {
        QRole role = QRole.role;

        BooleanBuilder where = new BooleanBuilder();
        if (!StringUtils.isEmpty(designation))
            where.and(role.designation.contains(designation));
        if (!StringUtils.isEmpty(internalName))
            where.and(role.internalName.contains(internalName));
        return Lists.newArrayList(roleRepository.findAll(where));
    }

    @Override
    public void update(Role role) {
        Role role1 = roleRepository.findById(role.getId()).get();
        if (Objects.isNull(role1)) throw new DataNotFoundException("role", role.getDesignation(), "Role");
        try {
            roleRepository.save(role);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("role", ex);
        }
    }

    @Override
    public void delete(Long roleId) {
        Role role = this.getRoleById(roleId);
        if (Objects.isNull(role)) {
            throw new DataNotFoundException("role", roleId.toString(), "users");
        }
        if (!CollectionUtils.isEmpty(role.getUserRoles())) {
            throw new NotAllowedOperationException("role", roleId.toString(), "users");
        }

        roleRepository.delete(role);
    }
}
