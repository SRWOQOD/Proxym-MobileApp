package wq.woqod.dao;


import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.RejectedVoucher;

import java.text.ParseException;
import java.util.List;

public interface RejectedVoucherDao {

    void save(RejectedVoucher voucher);

    List<RejectedVoucher> getAllVoucher();

    void saveList(List<RejectedVoucher> vouchers);

    void delete(RejectedVoucher voucher);

    RejectedVoucher findByReference(String reference);

    Page<RejectedVoucher> getFiltredVouchers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

}
