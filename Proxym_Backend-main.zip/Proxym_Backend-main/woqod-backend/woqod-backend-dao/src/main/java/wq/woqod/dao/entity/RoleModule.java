package wq.woqod.dao.entity;


import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by bfitouri on 14/11/16.
 */
@Entity
@Table(name = Constants.TABLE_ROLES_MODULE)
public class RoleModule implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    private Role role;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "module_id")
    private Module module;

    public RoleModule() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }
}
