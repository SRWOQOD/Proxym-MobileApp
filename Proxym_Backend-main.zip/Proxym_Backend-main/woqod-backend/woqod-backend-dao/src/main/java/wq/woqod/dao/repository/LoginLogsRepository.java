package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.LoginLogs;
import wq.woqod.resources.enumerations.LoginStatusEnum;

import java.util.Optional;

/**
 * Created by med-amine.dahmen on 03/11/2020.
 */
public interface LoginLogsRepository extends JpaRepository<LoginLogs, Long>, QuerydslPredicateExecutor<LoginLogs> {

    Optional<LoginLogs> findTopByUserNameAndLoginStatusEnumOrderByCreationDateDesc(String username, LoginStatusEnum status);

}
