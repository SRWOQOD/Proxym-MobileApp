package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.CarCategoryDao;
import wq.woqod.dao.entity.CarCategory;
import wq.woqod.dao.repository.CarCategoryRepository;

import java.util.List;

/**
 * The class {@code CarCategoryImpl} define the operations
 * of methods needed for car category database
 *
 * @author Meriam.Mejri
 */
@Component
public class CarCategoryImpl implements CarCategoryDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(CarCategoryImpl.class);

    private final CarCategoryRepository carCategoryRepository;


    @Autowired
    public CarCategoryImpl(CarCategoryRepository carCategoryRepository) {
        this.carCategoryRepository = carCategoryRepository;
    }


    /**
     * The method {@code save} allows to add a new car category
     *
     * @param carCategory
     */
    @Override
    public CarCategory save(CarCategory carCategory) {
        try {
            return carCategoryRepository.save(carCategory);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("car category", ex);
        }
    }


    /**
     * The method {@code findByCategoryId} allows to find car category
     * by ID
     *
     * @param categoryId
     * @return CarCategory
     */
    @Override
    public CarCategory findByCategoryId(String categoryId) {
        return carCategoryRepository.findByCategoryId(categoryId);
    }


    /**
     * The method {@code findByFee} allows to find car category
     * by fee
     *
     * @param fee
     * @return CarCategory
     */
    @Override
    public CarCategory findByFee(Double fee) {
        return carCategoryRepository.findByFee(fee);
    }


    /**
     * The method {@code findByNameEn} allows to find car category
     * by name_En
     *
     * @param nameEn
     * @return CarCategory
     */
    @Override
    public CarCategory findByNameEn(String nameEn) {
        return carCategoryRepository.findByNameEn(nameEn);
    }

    @Override
    public List<CarCategory> findAll() {
        return carCategoryRepository.findAll();
    }

    @Override
    public Page<CarCategory> getFiltredCarCategory(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) {
        return null;
    }

    @Override
    public void delete(Long id) {
        CarCategory carCategory = carCategoryRepository.getOne(id);
        carCategoryRepository.delete(carCategory);
    }
}
