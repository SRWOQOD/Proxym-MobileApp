package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by med-taher.ben-torkia on 11/15/2016.
 */
@Entity
@Table(name = Constants.TABLE_MODULE)
public class Module implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String designation;

    @OneToMany(mappedBy = "module", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL)
    private List<RoleModule> roleModules;

    @OneToMany(mappedBy = "module", fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.MERGE)
    private List<Feature> features;

    public Module() {
    }

    public Module(Long id) {
        this.id = id;
    }

    public Module(String designation) {
        this.designation = designation;
    }

    public Module(Long id, String designation) {
        this.id = id;
        this.designation = designation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public List<RoleModule> getRoleModules() {
        return roleModules;
    }

    public void setRoleModules(List<RoleModule> roleModules) {
        this.roleModules = roleModules;
    }

    public List<Feature> getFeatures() {
        if (features == null)
            features = new ArrayList<>();
        return features;
    }

    public void setFeatures(List<Feature> features) {
        this.features = features;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        Module other = (Module) obj;
        return Objects.equal(this.id, other.id) && Objects.equal(this.designation, other.designation)
                && Objects.equal(this.roleModules, other.roleModules) && Objects.equal(this.features, other.features);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), id, designation, roleModules, features);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("id", id).add("designation", designation).add("roleModules", roleModules).toString();
    }
}
