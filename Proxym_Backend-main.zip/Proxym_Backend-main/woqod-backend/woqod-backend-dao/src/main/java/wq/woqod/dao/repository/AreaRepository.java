package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.Area;


public interface AreaRepository extends JpaRepository<Area, Long>, QuerydslPredicateExecutor<Area> {
    Area findAreaByIdArea(String id);

    Area findByTitle(String title);

    Area findByArabicTitle(String arabicTitle);

    @Query("SELECT MAX(id) FROM Area")
    Long getId();
}
