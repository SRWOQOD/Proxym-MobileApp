package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.PromotionCategoryEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Created by ameni on 26/11/16.
 */
@Entity
@Table(name = Constants.TABLE_PROMOTION)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Getter
@Setter
public class Promotion extends NotificationContent implements Serializable {

    @Column(unique = true)
    private Long promotionId;

    @Enumerated(EnumType.STRING)
    private PromotionCategoryEnum category;

    private String title;

    @Column(name = "title_arabic")
    private String titleArabic;

    //    @Lob
    @Column(name = "brief_description", length = 2048)
    private String briefDescription;

    @Lob
    @Column(name = "brief_description_arabic", length = 1024)
    private String briefDescriptionArabic;

    private String image;

    private String link;

    private String imageList;

    @Column(name = "last_synchronisation_date")
    private LocalDateTime lastSynchronisationDate;


}
