package wq.woqod.dao;

import wq.woqod.dao.entity.PlateType;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
public interface PlateTypeDao {

    PlateType getPlateTypeByGivenId(String plateTypeId);

    PlateType save(PlateType plateType);
}
