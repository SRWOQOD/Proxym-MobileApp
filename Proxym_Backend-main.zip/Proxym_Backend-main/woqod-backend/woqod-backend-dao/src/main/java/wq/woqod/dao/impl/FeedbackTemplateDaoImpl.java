package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.FeedbackTemplateDao;
import wq.woqod.dao.entity.FeedbackTemplate;
import wq.woqod.dao.entity.QFeedbackTemplate;
import wq.woqod.dao.repository.FeedbackTemplateRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * The class {@code FeedbackTemplateDaoImpl} define the operations
 * of methods needed for feedback template database
 *
 * @author Samia.DHAHRI
 */
@Component
@Slf4j
public class FeedbackTemplateDaoImpl implements FeedbackTemplateDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeedbackTemplateDaoImpl.class);
    private FeedbackTemplateRepository templateRepository;

    @Autowired
    public FeedbackTemplateDaoImpl(FeedbackTemplateRepository templateRepository) {
        this.templateRepository = templateRepository;
    }


    @Override
    public List<FeedbackTemplate> getAllTemplates(MultiValueMap<String, String> parameters) {
        Predicate qcreatedDate = null;
        Predicate qcontent = null;
        Predicate qtitle = null;

        QFeedbackTemplate qTemplate = QFeedbackTemplate.feedbackTemplate;
        Date date;

        if (parameters.get("createdDate") != null) {
            try {
                Calendar cal1 = Calendar.getInstance();
                Calendar cal2 = Calendar.getInstance();
                date = new SimpleDateFormat("yyyy-MM-dd").parse(parameters.getFirst("createdDate"));
                cal1.setTime(date);
                cal1.set(Calendar.HOUR_OF_DAY, 0);
                cal1.set(Calendar.MINUTE, 0);
                cal1.set(Calendar.SECOND, 0);
                cal1.set(Calendar.MILLISECOND, 0);

                cal2.setTime(date);
                cal2.set(Calendar.HOUR_OF_DAY, 23);
                cal2.set(Calendar.MINUTE, 59);
                cal2.set(Calendar.SECOND, 59);
                cal2.set(Calendar.MILLISECOND, 0);

                qcreatedDate = qTemplate.createdDate.between(cal1.getTime(), cal2.getTime());
            } catch (ParseException e) {
                log.error("[FeedbackTemplateDaoImpl] getFiltredFeedbacks {}", e.getMessage());
            }

        }

        if (parameters.get("content") != null) {
            qcontent = qTemplate.content.containsIgnoreCase(parameters.getFirst("content"));
        }

        if (parameters.get("title") != null) {
            qtitle = qTemplate.title.containsIgnoreCase(parameters.getFirst("title"));
        }


        Predicate predicateTransaction = qTemplate.isNotNull()
                .and(qcreatedDate)
                .and(qcontent)
                .and(qtitle);
        return (List<FeedbackTemplate>) templateRepository.findAll(predicateTransaction);
    }

    /**
     * The method {@code save} allows to add a new feedback template
     *
     * @param feedback
     */
    @Override
    public void save(FeedbackTemplate feedback) {
        try {
            feedback.setCreatedDate(new Date());
            templateRepository.save(feedback);
        } catch (Exception ex) {
            log.error("Problem when persisting FeedbackTemplate entity..", ex);
        }
    }

    /**
     * Used to get a feedback Template by
     * given id
     *
     * @param id
     */
    @Override
    public FeedbackTemplate findById(Long id) {
        try {
            Optional<FeedbackTemplate> feedbackTemplate = templateRepository.findById(id);
            if (!feedbackTemplate.isPresent()){
                throw new DataNotFoundException("Feedback template", String.valueOf(id), "feedback template");
            }
            return feedbackTemplate.get();
        } catch (Exception e) {
            log.error("[FeedbackTemplateDaoImpl] findById", e);
            throw new DataNotFoundException("Feedback template", String.valueOf(id), "feedback template");
        }

    }

    /**
     * Used to get feedback template list
     *
     * @param pageable
     * @param parameters
     * @return Page
     */

    @Override
    public Page<FeedbackTemplate> getFiltredTemplates(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qcreatedDate = null;
        Predicate qcontent = null;
        Predicate qtitle = null;

        QFeedbackTemplate qTemplate = QFeedbackTemplate.feedbackTemplate;
        Date date;

        if (parameters.get("createdDate") != null) {
            try {
                Calendar cal1 = Calendar.getInstance();
                Calendar cal2 = Calendar.getInstance();
                date = new SimpleDateFormat("yyyy-MM-dd").parse(parameters.getFirst("createdDate"));
                cal1.setTime(date);
                cal1.set(Calendar.HOUR_OF_DAY, 0);
                cal1.set(Calendar.MINUTE, 0);
                cal1.set(Calendar.SECOND, 0);
                cal1.set(Calendar.MILLISECOND, 0);

                cal2.setTime(date);
                cal2.set(Calendar.HOUR_OF_DAY, 23);
                cal2.set(Calendar.MINUTE, 59);
                cal2.set(Calendar.SECOND, 59);
                cal2.set(Calendar.MILLISECOND, 0);

                qcreatedDate = qTemplate.createdDate.between(cal1.getTime(), cal2.getTime());
            } catch (ParseException e) {
                log.error("[FeedbackTemplateDaoImpl] getFiltredFeedbacks {}", e.getMessage());
            }
        }

        if (parameters.get("content") != null) {
            qcontent = qTemplate.content.containsIgnoreCase(parameters.getFirst("content"));
        }

        if (parameters.get("title") != null) {
            qtitle = qTemplate.title.containsIgnoreCase(parameters.getFirst("title"));
        }


        Predicate predicateTransaction = qTemplate.isNotNull()
                .and(qcreatedDate)
                .and(qcontent)
                .and(qtitle);
        return templateRepository.findAll(predicateTransaction, pageable);

    }

    /**
     * Used to update a feedback Template
     *
     * @param feedback
     */

    @Override
    public void update(FeedbackTemplate feedback) {
        try {
            templateRepository.save(feedback);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting FeedbackTemplate entity..", ex);
            throw new PersistingDataException("FeedbackTemplate", ex);
        }
    }

    /**
     * Used to delete a feedback Template by given id
     *
     * @param id
     */
    @Override
    public void deleteFeedback(Long id) {
        try {
            FeedbackTemplate feedbackTemplate = findById(id);
            templateRepository.delete(feedbackTemplate);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when Deleting FeedbackTemplate entity..", ex);
            throw new UpdatingDataException("FeedbackTemplate", ex);
        }
    }

    @Override
    public FeedbackTemplate getTemplateByTitle(String title) {
        return templateRepository.findByTitle(title);
    }

    @Override
    public Long count() {
        return templateRepository.count();
    }
}
