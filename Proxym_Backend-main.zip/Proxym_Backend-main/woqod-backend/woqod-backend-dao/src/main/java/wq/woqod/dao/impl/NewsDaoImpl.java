package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.NewsDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.NewsHome;
import wq.woqod.dao.entity.QNewsHome;
import wq.woqod.dao.repository.NewsRepository;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Component
public class NewsDaoImpl implements NewsDao {


    private final NewsRepository newsRepository;
    private static final String DATE_TO = "dateTo";
    private static final String DATE_FROM = "dateFrom";

    @Autowired
    public NewsDaoImpl(NewsRepository newsRepository) {
        this.newsRepository = newsRepository;
    }


    @Override
    public void save(NewsHome newsHome) {
        try {
            newsRepository.save(newsHome);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("NewsDaoImpl", ex);
        }
    }

    @Override
    public void saveAndFlush(NewsHome newsHome) {
        try {
            newsRepository.saveAndFlush(newsHome);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("NewsDaoImpl", ex);
        }
    }

    @Override
    public List<NewsHome> getNews() {
        return newsRepository.findAll();
    }

    @Override
    public Page<NewsHome> filter(Pageable pageable, Map<String, String> parameters) throws ParseException {
        Predicate active = null;
        Predicate title = null;
        Predicate date = null;
        Date startDate = DateFormatter.StringToDate(parameters.get(DATE_TO));
        Date endDate = DateFormatter.StringToDate(parameters.get(DATE_FROM));
        Calendar c = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        QNewsHome qNewsHome = QNewsHome.newsHome;
        if (parameters.get("active") != null) {
            active = qNewsHome.active.eq(Boolean.valueOf(parameters.get("active")));
        }
        if (parameters.get(FilterConstants.TITLE) != null) {
            title = qNewsHome.title.containsIgnoreCase(parameters.get("title"));
        }
        if (parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) != null) {
            c.setTime(startDate);
            c.add(Calendar.DATE, -1);
            startDate = c.getTime();
            c2.setTime(endDate);
            c2.add(Calendar.DATE, 1);
            endDate = c2.getTime();
            date = qNewsHome.creationDate.between(startDate, endDate);
        } else if (parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) == null) {
            c.setTime(startDate);
            c.add(Calendar.DATE, -1);
            startDate = c.getTime();
            c2.setTime(endDate);
            c2.add(Calendar.DATE, 1);
            endDate = c2.getTime();
            date = qNewsHome.creationDate.after(DateFormatter.StringToDate(parameters.get(DATE_FROM)));
        }
        if (parameters.get(DATE_TO) != null && parameters.get(DATE_FROM) == null) {
            c.setTime(startDate);
            c.add(Calendar.DATE, -1);
            c2.setTime(endDate);
            c2.add(Calendar.DATE, 1);
            date = qNewsHome.creationDate.before(DateFormatter.StringToDate(parameters.get(DATE_TO)));
        }

        Predicate predicate = qNewsHome.isNotNull().and(active).and(title).and(date);
        return newsRepository.findAll(predicate, pageable);
    }


    @Override
    public NewsHome getById(Long valueOf) {
        return newsRepository.getOne(valueOf);
    }

    @Override
    public void update(List<NewsHome> list) {
        newsRepository.saveAll(list);
    }

    @Override
    public Page<NewsHome> getActiveNews(Pageable pageable) {
        Predicate active = null;
        QNewsHome qNews = QNewsHome.newsHome;
        active = qNews.active.eq(true);
        Predicate predicate = qNews.isNotNull().and(active);
        return newsRepository.findAll(predicate, pageable);
    }

    @Override
    public Long count() {
        return newsRepository.count();
    }

    @Override
    public void delete(Long id) {
        newsRepository.deleteById(id);
    }
}
