package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.AdsBannerDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.AdsBanner;
import wq.woqod.dao.entity.QAdsBanner;
import wq.woqod.dao.repository.AdsBannerRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Component
public class AdsBannerDaoImpl implements AdsBannerDao {

    private final AdsBannerRepository adsBannerRepository;
    private static final String DATE_FROM = "dateFrom";
    private static final String DATE_TO = "dateTo";

    @Autowired
    public AdsBannerDaoImpl(AdsBannerRepository adsBannerRepository) {
        this.adsBannerRepository = adsBannerRepository;
    }

    @Override
    public void save(AdsBanner adsBanner) {
        AdsBanner old = adsBanner.getId() !=null ? getById(adsBanner.getId()) : null;
        if (old == null) {
            try {
                AdsBanner lastElement = adsBannerRepository.findTopByOrderByOrderItemDesc().orElse(null);
                adsBanner.setOrderItem(Objects.isNull(lastElement) ? 1 : lastElement.getOrderItem() + 1);
                adsBannerRepository.save(adsBanner);
            } catch (DataIntegrityViolationException ex) {
                throw new PersistingDataException("AdsBannerDaoImpl", ex);
            }
        } else {
            adsBanner.setOrderItem(old.getOrderItem());
            update(adsBanner);
        }
    }

    @Override
    public List<AdsBanner> getAdsbanner() {
        return adsBannerRepository.findAll();
    }

    @Override
    public List<AdsBanner> filter(MultiValueMap<String, String> parameters) {
        Predicate active = null;
        Predicate date = null;
        Predicate title = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        QAdsBanner qAdsBanner = QAdsBanner.adsBanner;
        if (parameters.get("active") != null) {
            active = qAdsBanner.active.eq(Boolean.valueOf(parameters.getFirst("active")));
        }
        if (parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) != null) {
            date = qAdsBanner.creationDate.between((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)), (LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        } else if(parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) == null) {
            date = qAdsBanner.creationDate.after((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)));
        } else if (parameters.get(DATE_TO) != null && parameters.get(DATE_FROM) == null) {
            date = qAdsBanner.creationDate.before((LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        }
        if (parameters.get(FilterConstants.TITLE) != null) {
            title = qAdsBanner.title.containsIgnoreCase(parameters.getFirst("title"));
        }
        Predicate predicateAdsBanner = qAdsBanner.isNotNull()
                .and(active).and(date).and(title);
        return (List<AdsBanner>) adsBannerRepository.findAll(predicateAdsBanner);
    }

    @Override
    public AdsBanner getById(Long valueOf) {
        return adsBannerRepository.getOne(valueOf);
    }

    @Override
    public void update(List<AdsBanner> list) {
        adsBannerRepository.saveAll(list);
    }

    @Override
    public void update(AdsBanner adsBanner) {
        adsBannerRepository.save(adsBanner);
    }

    @Override
    public List<AdsBanner> getActiveAdsBanner() {

        return adsBannerRepository.findAllByActive(true);
    }

    @Override
    public Long count() {
        return adsBannerRepository.count();
    }

    @Override
    public void delete(Long id) {
        adsBannerRepository.deleteById(id);
    }
}
