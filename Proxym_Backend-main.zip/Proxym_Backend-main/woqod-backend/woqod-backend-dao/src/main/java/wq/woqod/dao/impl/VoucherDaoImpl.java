package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.Expressions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.VoucherIsBurnedException;
import wq.woqod.commons.exception.VoucherIsNotValidException;
import wq.woqod.dao.VoucherDao;
import wq.woqod.dao.entity.QVoucher;
import wq.woqod.dao.entity.Voucher;
import wq.woqod.dao.repository.VoucherRepository;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;


/**
 * The class {@code VoucherDaoImpl} define the operations
 * of methods needed for voucher database
 *
 * @author Meriam.Mejri
 */
@Component
public class VoucherDaoImpl implements VoucherDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(VoucherDaoImpl.class);

    private final VoucherRepository voucherRepository;

    public VoucherDaoImpl(VoucherRepository voucherRepository) {
        this.voucherRepository = voucherRepository;
    }


    /**
     * The method {@code save} allows to add a new voucher
     *
     * @param voucher
     */
    @Override
    public void save(Voucher voucher) {
        LOGGER.info("DAO: save voucher");
        try {
            voucherRepository.save(voucher);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting voucher entity..", ex);
            throw new PersistingDataException("voucher", ex);
        }
    }

    /**
     * The method {@code getAllVoucher} Used to get All voucher
     *
     * @return list
     */
    @Override
    public List<Voucher> getAllVoucher() {
        LOGGER.info("DAO:  getAllVoucher");

        return voucherRepository.findAll();
    }

    /**
     * The method {@code save} allows to add a list
     * of voucher
     *
     * @param vouchers
     */
    @Override
    public void saveList(List<Voucher> vouchers) {
        LOGGER.info("DAO:  saveList");
        for (Voucher voucher : vouchers
        ) {
            voucherRepository.save(voucher);
        }
    }

    /**
     * Used to Delete a voucher
     *
     * @param voucher
     */
    @Override
    public void delete(Voucher voucher) {
        LOGGER.info("DAO:  delete");
        voucherRepository.delete(voucher);
    }

    /**
     * Used to filter  voucher list
     *
     * @param predicate
     * @param pageable
     * @param parameters
     * @return Page
     */
    @Override
    public Page<Voucher> getFiltredVouchers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException {
        LOGGER.info("DAO:  getFiltredVouchers");

        QVoucher voucher = QVoucher.voucher;

        Predicate predicateWithEquals;
        BooleanExpression voucherReference = null;
        BooleanExpression beginDate = null;
        BooleanExpression qid = null;
        BooleanExpression finishDate = null;
        BooleanExpression experied = null;

        BooleanExpression status = null;

        if (parameters.containsKey("voucherReferenceOP") || parameters.containsKey("type") || parameters.containsKey("beginDateOP") || parameters.containsKey("finishDateOP")) {
            if (parameters.containsKey("voucherReference") && (parameters.containsKey("voucherReferenceOP"))) {
                if (!Objects.isNull(voucher.voucherReference) && (!Objects.isNull(parameters.get("voucherReferenceOP")))) {
                    if (parameters.get("voucherReferenceOP").contains("equal"))
                        voucherReference = voucher.voucherReference.eq((parameters.get("voucherReference")).toString().substring(1, (parameters.get("voucherReference")).toString().length() - 1));
                    if (parameters.get("voucherReferenceOP").contains("contains"))
                        voucherReference = voucher.voucherReference.contains((parameters.get("voucherReference")).toString().substring(1, (parameters.get("voucherReference")).toString().length() - 1));
                }
            }
            if (parameters.containsKey("type")) {
                if (parameters.get("type").get(0).equals("USED")) {
                    qid = voucher.qid.isNotNull();
                    status = voucher.status.isFalse();

                } else if (parameters.get("type").get(0).equals("NOTUSED")) {
                    qid = voucher.qid.isNull();
                    experied = voucher.finishDate.after(LocalDate.now());
                    status = voucher.status.isTrue();

                } else {
                    experied = voucher.finishDate.before(LocalDate.now());
                    status = voucher.status.isTrue();
                }
            }
            if (parameters.containsKey("beginDate") && (parameters.containsKey("beginDateOP"))) {
                if (!Objects.isNull(voucher.beginDate) && (!Objects.isNull(parameters.get("beginDateOP")))) {
                    String dateString = "";
                    dateString = parameters.get("beginDate").get(0);
                    LocalDate localDate = null;
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    localDate = LocalDate.parse(dateString, formatter);


                    if (parameters.get("beginDateOP").contains("equal"))
                        beginDate = voucher.beginDate.eq(localDate);
                    if (parameters.get("beginDateOP").contains("less"))
                        beginDate = voucher.beginDate.before(localDate);
                    if (parameters.get("beginDateOP").contains("greater"))
                        beginDate = voucher.beginDate.after(localDate);
                }
            }
            if (parameters.containsKey("finishDate") && (parameters.containsKey("finishDateOP"))) {
                if (!Objects.isNull(voucher.finishDate) && (!Objects.isNull(parameters.get("finishDateOP")))) {
                    String dateString = "";
                    dateString = parameters.get("finishDate").get(0);
                    LocalDate localDate = null;
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    localDate = LocalDate.parse(dateString, formatter);


                    if (parameters.get("finishDateOP").contains("equal"))
                        finishDate = voucher.finishDate.eq(localDate);
                    if (parameters.get("finishDateOP").contains("less"))
                        finishDate = voucher.finishDate.before(localDate);
                    if (parameters.get("finishDateOP").contains("greater"))
                        finishDate = voucher.finishDate.after(localDate);
                }
            }
        }


        if (null == voucherReference)
            voucherReference = Expressions.asBoolean(true).isTrue();
        if (null == beginDate)
            beginDate = Expressions.asBoolean(true).isTrue();
        if (null == finishDate)
            finishDate = Expressions.asBoolean(true).isTrue();
        if (null == experied)
            experied = Expressions.asBoolean(true).isTrue();
        if (null == qid)
            qid = Expressions.asBoolean(true).isTrue();
        if (null == status)
            status = Expressions.asBoolean(true).isTrue();

        predicateWithEquals = voucherReference.and(beginDate).and(finishDate).and(qid).and(experied).and(status);


        Page<Voucher> page = voucherRepository.findAll(predicateWithEquals, pageable);
        return page;
    }

    /**
     * Used to find voucher by Reference
     *
     * @param reference
     */
    @Override
    public Voucher findByReference(String reference) {
        LOGGER.info("DAO:  findByReference");
        if (voucherRepository.findByVoucherReference(reference).isPresent()) {
            Voucher voucher = voucherRepository.findByVoucherReference(reference).get();
            if (voucher.isStatus()) {
                if (voucher.getBeginDate().isAfter(LocalDate.now()) || voucher.getBeginDate().isAfter(voucher.getFinishDate()))
                    throw new VoucherIsNotValidException(voucher.getVoucherReference());
                else if (voucher.getFinishDate().isBefore(LocalDate.now()))
                    throw new VoucherIsBurnedException(voucher.getVoucherReference());
                else
                    return voucher;
            } else {
                throw new VoucherIsBurnedException(voucher.getVoucherReference());
            }

        } else {
            throw new VoucherIsNotValidException(reference);
        }
    }


    @Override
    public Voucher findByRef(String reference) {
        LOGGER.info("DAO:  findByReference");
        if (voucherRepository.findByVoucherReference(reference).isPresent()) {
            return voucherRepository.findByVoucherReference(reference).get();
        } else {
            return null;
        }
    }
}
