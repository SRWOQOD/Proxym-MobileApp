package wq.woqod.dao.impl;


import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.PreRegistrationDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.PreRegistration;
import wq.woqod.dao.entity.QPreRegistration;
import wq.woqod.dao.repository.PreRegistrationRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;


/**
 * The class {@code PreRegistrationImpl} define the operations
 * of methods needed for pre registration database
 *
 * @author Meriam.Mejri
 */
@Slf4j
@Component
public class PreRegistrationImpl implements PreRegistrationDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(PreRegistrationImpl.class);
    private final PreRegistrationRepository preRegistrationRepository;
    @Autowired
    public PreRegistrationImpl(PreRegistrationRepository preRegistrationRepository) {
        this.preRegistrationRepository = preRegistrationRepository;
    }


    /**
     * The method {@code save} allows to add a new pre registration
     *
     * @param preRegistration
     */
    @Override
    public void save(PreRegistration preRegistration) {
        LOGGER.info("DAO: createRating preRegistration");
        try {
            preRegistrationRepository.save(preRegistration);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting preRegistration entity..", ex);
            throw new PersistingDataException("preRegistration", ex);
        }
    }

    @Override
    public void saveOrUpdate(PreRegistration preRegistration) {
        LOGGER.info("DAO: saveOrUpdate preRegistration");
        try {
            preRegistrationRepository.save(preRegistration);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting preRegistration entity..", ex);
            throw new PersistingDataException("preRegistration", ex);
        }
    }


    /**
     * Used to filter  PreRegistration list
     *
     * @param predicate
     * @param pageable
     * @return Page
     */
    @Override
    public Page<PreRegistration> getFiltredPreRegistrations(Predicate predicate, Pageable pageable, MultiValueMap<String, String> params) {

        LOGGER.info("DAO: GET filtered Pre Registration");

        QPreRegistration preRegistration = QPreRegistration.preRegistration;
        Predicate qid = null;
        Predicate dateCreation = null;
        Predicate plateType = null;
        Predicate plateNumber = null;
        Predicate predicateWithEquals;

        Predicate referenceNumber = null;

        if (params.get(FilterConstants.QID_PRG) != null) {
            qid = preRegistration.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.DATE_CREATION) != null) {
            try {
                dateCreation = preRegistration.creationDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst("dateCreation")));
            } catch (ParseException ignored) {
                log.error(ignored.getMessage());
            }
        }

        if (params.get(FilterConstants.PLATE_TYPE) != null) {
            plateType = preRegistration.car.plateType.nameEn.containsIgnoreCase(params.getFirst("plateType"));
        }

        if (params.get(FilterConstants.PLATE_NUMBER) != null) {
            plateNumber = preRegistration.car.plateNumber.containsIgnoreCase(params.getFirst("plateNumber"));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = preRegistration.referenceNumber.containsIgnoreCase(params.getFirst("referenceNumber"));
        }


        predicateWithEquals = preRegistration.isNotNull().and(referenceNumber).and(dateCreation).and(plateType).and(qid).and(plateNumber);


        return preRegistrationRepository.findAll(predicateWithEquals, pageable);
    }

    /**
     * Used to update a PreRegistration
     *
     * @param preRegistration
     */
    @Override
    public void update(PreRegistration preRegistration) {
        preRegistrationRepository.save(preRegistration);

    }

    /**
     * Used to Delete a PreRegistration
     *
     * @param id
     */
    @Override
    public void deletePreRegistration(Long id) {
        LOGGER.info("[DAO] DELETE PreRegistration");
        Optional<PreRegistration> preRegistration = preRegistrationRepository.findById(id);
        preRegistration.ifPresent(preRegistrationRepository::delete);
    }

    /**
     * The method {@code findById} allows to find Pre Registration
     * by ID
     *
     * @param id
     * @return PreRegistration
     */
    @Override
    public PreRegistration findById(Long id) {
        LOGGER.info("DAO: find One PreRegistration : id {}", id);
        Optional<PreRegistration> preRegistration = preRegistrationRepository.findById(id);
        return preRegistration.orElseThrow(() -> new DataNotFoundException("preRegistration", String.valueOf(id), "preRegistration"));
    }

    /**
     * The method {@code findByPlateNumber} allows to find Pre Registration
     * by plateNumber
     *
     * @param plateNumber
     * @return PreRegistration
     */
    @Override
    public PreRegistration findByPlateNumber(String plateNumber) {
        LOGGER.info("DAO: find One PlateNumber : plateNumber {}", plateNumber);
        Optional<PreRegistration> preRegistration = preRegistrationRepository.findByCar_PlateNumber(plateNumber);
        return preRegistration.orElseThrow(() -> new DataNotFoundException("preRegistration", String.valueOf(plateNumber), "preRegistration"));

    }
    @Override
    public List<PreRegistration> findAllByPlateNumber(String plateNumber) {
        LOGGER.info("DAO: find all PlateNumber : plateNumber {}", plateNumber);
        List<PreRegistration> preRegistration = preRegistrationRepository.findAllByCar_PlateNumber(plateNumber);
        if (preRegistration == null || preRegistration.size()==0)
            throw new DataNotFoundException("preRegistration", String.valueOf(plateNumber), "preRegistration");
        else
         return preRegistration;

    }

    /**
     * Used to get All Pre Registration
     */
    @Override
    public List<PreRegistration> getAllPreRegistrations(MultiValueMap<String, String> params) {
        LOGGER.info("DAO: find All PreRegistrations");

        QPreRegistration preRegistration = QPreRegistration.preRegistration;
        Predicate qid = null;
        Predicate dateCreation = null;
        Predicate plateType = null;
        Predicate plateNumber = null;
        Predicate predicateWithEquals;

        Predicate referenceNumber = null;

        if (params.get(FilterConstants.QID) != null) {
            qid = preRegistration.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.DATE_CREATION) != null) {
            try {
                dateCreation = preRegistration.creationDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst("dateCreation")));
            } catch (ParseException ignored) {
                log.error(ignored.getMessage());
            }
        }

        if (params.get(FilterConstants.PLATE_TYPE) != null) {
            plateType = preRegistration.car.plateType.nameEn.containsIgnoreCase(params.getFirst("plateType"));
        }

        if (params.get(FilterConstants.PLATE_NUMBER) != null) {
            plateNumber = preRegistration.car.plateNumber.containsIgnoreCase(params.getFirst("plateNumber"));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = preRegistration.referenceNumber.containsIgnoreCase(params.getFirst("referenceNumber"));
        }


        predicateWithEquals = preRegistration.isNotNull().and(referenceNumber).and(dateCreation).and(plateType).and(qid).and(plateNumber);


        return (List<PreRegistration>) preRegistrationRepository.findAll(predicateWithEquals);
    }

    /**
     * The method {@code getPreRegistrationByReferenceNumber} allows to find Pre Registration
     * by ReferenceNumber
     *
     * @param referenceNumber
     * @return PreRegistration
     */

  /*  @Override
    public PreRegistration getPreRegistrationByReferenceNumber(String referenceNumber) {
        LOGGER.info("DAO: find PreRegistrations by ReferenceNumber");
        Optional<PreRegistration> preRegistration = preRegistrationRepository.findByReferenceNumber(referenceNumber);
        return preRegistration.orElseThrow(() -> new CompleteRegistrationException("preRegistration", String.valueOf(referenceNumber), "preRegistration"));
    }*/
    @Override
    public PreRegistration getPreRegistrationByReferenceNumber(String referenceNumber) {
        LOGGER.info("DAO: find PreRegistrations by ReferenceNumber");
        PreRegistration preRegistration;
        List<PreRegistration> preRegistrationList = preRegistrationRepository.findAllByReferenceNumber(referenceNumber);
        if (preRegistrationList != null && preRegistrationList.size() > 0) {
            preRegistration = preRegistrationList.get(0);
        } else {
            throw new DataNotFoundException("preRegistration", String.valueOf(referenceNumber), "preRegistration");
        }
        return preRegistration;
    }

    @Override
    public PreRegistration getPreRegistrationByReferenceNumberAndTransactionUUID(String referenceNumber, String transactionUUID) {
        LOGGER.info("DAO: find PreRegistrations by ReferenceNumber and TransactionUUID");
        Optional<PreRegistration> transaction = preRegistrationRepository.findPreRegistrationByReferenceNumberAndTransactionUUID(referenceNumber, transactionUUID);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(transactionUUID), "transaction"));
    }

    @Override
    public PreRegistration findPreRegistrationByTransactionUUID(String transactionUUID) {
        LOGGER.info("DAO: find PreRegistrations by transactionUUID");
        Optional<PreRegistration> preRegistration = preRegistrationRepository.findPreRegistrationByTransactionUUID(transactionUUID);
        return preRegistration.orElseThrow(() -> new DataNotFoundException("preRegistration", String.valueOf(transactionUUID), "preRegistration"));
    }

    @Override
    public PreRegistration findByTransactionUUID(String transactionUUID) {
        Optional<PreRegistration> transaction = preRegistrationRepository.findByTransactionUUID(transactionUUID);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(transactionUUID), "transaction"));

    }

    @Override
    public List<PreRegistration> findByCar(Car car) {
        return preRegistrationRepository.findAllByCar(car);
    }

    @Override
    public List<PreRegistration> findByQid(String qid) {
        return preRegistrationRepository.findByQid(qid);
    }

    @Override
    public long count() {
        return preRegistrationRepository.count();
    }

}
