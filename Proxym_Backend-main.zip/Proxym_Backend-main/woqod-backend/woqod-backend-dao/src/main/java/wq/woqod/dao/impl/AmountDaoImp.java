package wq.woqod.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wq.woqod.commons.constants.WoqodConstant;
import wq.woqod.dao.AmountDao;
import wq.woqod.dao.entity.Amount;
import wq.woqod.dao.repository.AmountRepository;

import java.util.Optional;

@Component
public class AmountDaoImp implements AmountDao {

    private AmountRepository amountRepository;


    @Autowired
    public AmountDaoImp(AmountRepository amountRepository) {
        this.amountRepository = amountRepository;
    }

    //    @PostConstruct
    public void init() {
        Optional<Amount> transactionAmount = this.amountRepository.findByName(WoqodConstant.TRANSACTION_AMOUNT);
        if (!transactionAmount.isPresent()) {
            Amount trxAmount = new Amount();
            trxAmount.setName(WoqodConstant.TRANSACTION_AMOUNT);
            trxAmount.setMinAmount(WoqodConstant.TRANSACTION_AMOUNT_MIN);
            trxAmount.setMaxAmount(WoqodConstant.TRANSACTION_AMOUNT_MAX);
            this.amountRepository.save(trxAmount);
        }

    }


    @Override

    public void update(Amount amount) {
        this.amountRepository.saveAndFlush(amount);

    }

    @Override
    public Amount findByName(String s) {
        Optional<Amount> amount = this.amountRepository.findByName(s);
        return amount.orElseGet(Amount::new);

    }
}