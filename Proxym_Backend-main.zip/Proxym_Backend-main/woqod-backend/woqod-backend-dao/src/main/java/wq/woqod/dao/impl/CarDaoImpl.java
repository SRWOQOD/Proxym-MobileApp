package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.CarNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.CarDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.*;
import wq.woqod.dao.repository.CarRepository;
import wq.woqod.dao.repository.PlateTypeRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Created by med-taher.ben-torkia on 06/12/2016.
 */
@Component
@Slf4j
public class CarDaoImpl implements CarDao {

    public final PlateTypeRepository plateTypeRepository;
    private final CarRepository carRepository;

    @Autowired
    public CarDaoImpl(CarRepository carRepository, PlateTypeRepository plateTypeRepository) {
        this.carRepository = carRepository;
        this.plateTypeRepository = plateTypeRepository;
    }


    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public List<Car> getActiveCarByPlateNumberAndQidAndPlateType(String plateNumber, String qid, String plateType) {
        PlateType p = plateTypeRepository.getByPlateTypeId(plateType);
        return carRepository.findCarByActiveAndOwnerQidAndPlateNumberAndPlateType(true, qid, plateNumber, p);

    }

    @Override
    public Car getActiveCarByPlateNumberAndQidAndPlateTypeID(String plateNumber,String QID, String plateId){
        return carRepository.findCarByActiveAndPlateNumberAndOwnerQidAndPlateType_PlateTypeId(true,  plateNumber,QID, plateId);
    }
    @Override
    public Car save(Car car) {
        try {
            return carRepository.save(car);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting car entity..", ex);
            throw new PersistingDataException("car", ex);
        }
    }

    @Override
    public void save(List<Car> car) {
        try {
            carRepository.saveAll(car);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting list car entity..", ex);
            throw new PersistingDataException("car", ex);
        }
    }

    @Override
    public Car getActiveCarByPlateNumber(String plateNumber, String plateId) {
        return carRepository.findByActiveAndPlateNumberAndPlateType_PlateTypeId(true, plateNumber, plateId);
    }


    @Override
    public void updateStatus(String plate_number, String qid) {
        log.info("[CarDaoImpl] updateStatus");
        try {
            Car carToDesactivate = getActiveCarByPlateNumberAndQid(plate_number, qid);
            if (Objects.isNull(carToDesactivate)) {
                throw new CarNotFoundException("car", plate_number, "Car");
            }
            carToDesactivate.setActive(!carToDesactivate.isActive());
            carRepository.save(carToDesactivate);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when updating car entity..", ex);
            throw new PersistingDataException("car", ex);
        }
    }

    @Override
    public Page<Car> getFiltredCars(Pageable pageable, MultiValueMap<String, String> params) {
        log.info("[CarDaoImpl] getFiltredCars");
        Predicate predicateCar = this.getPredicateCar(params);
        return carRepository.findAll(predicateCar, pageable);
    }

    private Predicate getPredicateCar(MultiValueMap<String, String> params) {
        Predicate plateNumber = null;
        Predicate year = null;
        Predicate active = null;
        Predicate creationDate = null;
        Predicate plateType = null;
        Predicate manufacturer = null;
        Predicate model = null;
        Predicate dueDate = null;
        Predicate owner = null;
        Predicate vin = null;
        Predicate userName = null;

        QCar qCar = QCar.car;
        Date date;
        QPlateType qPlateType = QPlateType.plateType;

        QManufacturer qManufacturer = QManufacturer.manufacturer;

        QModel qmodel = QModel.model;

        if (params.get(FilterConstants.USERNAME) != null) {
            userName = qCar.owner.userName.containsIgnoreCase(params.getFirst(FilterConstants.USERNAME));
        }

        if (params.get(FilterConstants.PLATENUMBER) != null) {
            plateNumber = qCar.plateNumber.containsIgnoreCase(params.getFirst(FilterConstants.PLATENUMBER));
        }
        if (params.get(FilterConstants.YEAR) != null) {
            year = qCar.year.containsIgnoreCase(params.getFirst(FilterConstants.YEAR));
        }

        if (params.get(FilterConstants.ACTIVE) != null) {
            active = qCar.active.eq(Boolean.valueOf(params.getFirst(FilterConstants.ACTIVE)));
        }

        if (params.get(FilterConstants.CREATION_DATE) != null) {
            try {
                Calendar cal1 = Calendar.getInstance();
                Calendar cal2 = Calendar.getInstance();
                date = new SimpleDateFormat("yyyy-MM-dd").parse(params.getFirst(FilterConstants.CREATION_DATE));
                cal1.setTime(date);
                cal1.set(Calendar.HOUR_OF_DAY, 0);
                cal1.set(Calendar.MINUTE, 0);
                cal1.set(Calendar.SECOND, 0);
                cal1.set(Calendar.MILLISECOND, 0);

                cal2.setTime(date);
                cal2.set(Calendar.HOUR_OF_DAY, 23);
                cal2.set(Calendar.MINUTE, 59);
                cal2.set(Calendar.SECOND, 59);
                cal2.set(Calendar.MILLISECOND, 0);

                creationDate = qCar.creationDate.between(cal1.getTime(), cal2.getTime());
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
        }

        if (params.get(FilterConstants.PLATE_TYPE) != null) {
            plateType = qPlateType.nameEn.containsIgnoreCase(params.getFirst(FilterConstants.PLATE_TYPE));
            plateType = qmodel.isNotNull().and(plateType);
        }

        if (params.get(FilterConstants.MANUFACTUER) != null) {
            manufacturer = qManufacturer.nameEn.containsIgnoreCase(params.getFirst(FilterConstants.MANUFACTUER));
            manufacturer = qmodel.isNotNull().and(manufacturer);
        }

        if (params.get(FilterConstants.MODEL) != null) {
            model = qmodel.nameEn.containsIgnoreCase(params.getFirst(FilterConstants.MODEL));
            model = qmodel.isNotNull().and(model);

        }

        if (params.get(FilterConstants.DUE_DATE) != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(FilterConstants.DATEFORMAT).withLocale(Locale.ENGLISH);
            dueDate = qCar.dueDate.after(LocalDate.parse(params.getFirst(FilterConstants.DUE_DATE), formatter));
        }

        if (params.get(FilterConstants.OWNER) != null) {
            owner = qCar.ownerQid.containsIgnoreCase(params.getFirst(FilterConstants.OWNER));
        }

        if (params.get(FilterConstants.VIN) != null) {
            vin = qCar.vin.containsIgnoreCase(params.getFirst(FilterConstants.VIN));
        }

        Predicate predicateCar = qCar.isNotNull()
                .and(plateNumber)
                .and(year)
                .and(active)
                .and(creationDate)
                .and(plateType)
                .and(manufacturer)
                .and(model)
                .and(dueDate)
                .and(owner)
                .and(userName)
                .and(vin);

        return predicateCar;
    }


    @Override
    public Optional<Car> getCarByid(Long id) {
        return carRepository.findById(id);
    }

    @Override
    public List<Car> getActiveCarByPlateNumberAndOwnerAndPlateType(String plateNumber, User Owner, String plateType) {
        PlateType p = plateTypeRepository.getByPlateTypeId(plateType);
        return carRepository.findCarByActiveAndOwnerAndPlateNumberAndPlateType(true, Owner, plateNumber, p);

    }

    @Override
    public List<Car> getCarByPlateNumberAndQidAndPlateType(String plateNumber, String qid, String plateType) {
        PlateType p = plateTypeRepository.getByPlateTypeId(plateType);
        return carRepository.findCarByOwnerQidAndPlateNumberAndPlateType(qid, plateNumber, p);
    }

    @Override
    public List<Car> getCarsByUserId(Long id) {
        return carRepository.findAllByOwner_IdAndActive(id, true);
    }

    @Override
    public Car getActiveCarByPlateNumberAndQid(String plateNumber, String qid) {
        return carRepository.findCarByPlateNumberAndOwner_QidAndActive(plateNumber, qid, true);
    }

    @Override
    public List<Car> findCarsByRegExpirationDate(LocalDate date) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String strDate = date.format(dateFormatter);
        return carRepository.findCarsByRegExpirationDateEquals(strDate);
    }

    @Override
    public List<Car> getListCarByStatus(boolean active) {
        return carRepository.findCarsByActive(active);
    }

    @Override
    public List<Car> getCars(MultiValueMap<String, String> params) {
       Predicate predicateCar = this.getPredicateCar(params);
        return (List<Car>) carRepository.findAll(predicateCar);
    }

    @Override
    public Page<Car> all(Pageable pageable) {
        return carRepository.findAll(pageable);
    }

    @Override
    public void delete(Car car) {
         carRepository.delete(car);
    }

    @Override
    public Long count() {
        return carRepository.count();
    }
}
