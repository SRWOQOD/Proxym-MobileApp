package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Component;
import wq.woqod.dao.ContentDao;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.ContentInfoResource;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.NoSuchElementException;
import java.util.Optional;

@Slf4j
@Component
public class ContentDaoImpl implements ContentDao {
    @PersistenceContext
    EntityManager entityManager;

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");


    public ContentDaoImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public ContentInfoResource getContent(String entity, String field, ContentCategoryEnum categoryEnum) {
        log.info("entity : " + entity + " field : " + field + " categoryEnum : " + categoryEnum);

        try {
            ContentInfoResource tmp = new ContentInfoResource();
            tmp.setCategory(categoryEnum);
            tmp.setStatus(false);
            tmp.setSize(0);

            Object[] rs = new Object[0];
            Optional rs1 = entityManager.createNativeQuery("select TO_CHAR(" + field + ",'yyyy-MM-dd HH:mm:ss') ,(select CAST (sum(1) AS INTEGER)  from " + entity + ") as mysize from " + entity + "  ORDER BY id DESC").setMaxResults(1).getResultStream().findFirst();
            if (rs1.isPresent()) {
                rs = (Object[]) rs1.get();

                tmp.setLastSynchronisationDate(DateUtils.addDays(simpleDateFormat.parse(String.valueOf(rs[0]).replace(".0", "")), 1));
                tmp.setSize(((BigDecimal) rs[1]).intValue());
                // today
                Calendar date = new GregorianCalendar();
                // reset hour, minutes, seconds and millis
                date.set(Calendar.HOUR_OF_DAY, 0);
                date.set(Calendar.MINUTE, 0);
                date.set(Calendar.SECOND, 0);
                date.set(Calendar.MILLISECOND, 0);
                // Done on 21/01/2022
                // Workaround added for stock prices as Last_synchronization_date
                // is retrieved from API directly
                //if (categoryEnum == ContentCategoryEnum.STOCKPRICES) {
                tmp.setStatus(tmp.getLastSynchronisationDate() != null);
               /* } else {
                    tmp.setStatus(tmp.getLastSynchronisationDate().equals(date.getTime()));
                }*/
            }

            return tmp;
        } catch (NoSuchElementException | ParseException e) {
            log.error("Error : entity : " + entity + " field : " + field + " categoryEnum : " + categoryEnum + "error : " + e.getMessage());
            ContentInfoResource tmp = new ContentInfoResource();
            tmp.setCategory(categoryEnum);
            tmp.setSize(0);
            tmp.setStatus(false);
            return tmp;

        }
    }

//    public ContentInfoResource getContent(String entity, String field, ContentCategoryEnum categoryEnum) {
//        try {
//            Object[] rs = new Object[0];
//            Optional rs1 = entityManager.createNativeQuery("select TO_CHAR(" + field + ",'yyyy-MM-dd HH:mm:ss') ,(select CAST (sum(1) AS INTEGER)  from " + entity + ") as mysize from " + entity + "  ORDER BY id DESC").setMaxResults(1).getResultStream().findFirst();
//            if (rs1.isPresent()) {
//                rs = (Object[]) rs1.get();
//            }
//
//            ContentInfoResource tmp = new ContentInfoResource();
//
//            tmp.setCategory(categoryEnum);
//            if (tmp.getLastSynchronisationDate() != null) {
//                tmp.setLastSynchronisationDate(simpleDateFormat.parse(String.valueOf(rs[0]).replace(".0", "")));
//                tmp.setSize(((BigDecimal) rs[1]).intValue());
//                // today
//                Calendar date = new GregorianCalendar();
//                // reset hour, minutes, seconds and millis
//                date.set(Calendar.HOUR_OF_DAY, 0);
//                date.set(Calendar.MINUTE, 0);
//                date.set(Calendar.SECOND, 0);
//                date.set(Calendar.MILLISECOND, 0);
//                if (tmp.getStatus() != null) tmp.setStatus(tmp.getLastSynchronisationDate().equals(date.getTime()));
//                return tmp;
//            }
//            tmp.setLastSynchronisationDate(new Date());
//            tmp.setSize(0);
//            tmp.setStatus(false);
//            return tmp;
//
//        }
//        catch (NoSuchElementException | ParseException e) {
//            ContentInfoResource tmp = new ContentInfoResource();
//            tmp.setCategory(categoryEnum);
//            tmp.setSize(0);
//            tmp.setStatus(false);
//            return tmp;
//
//        }
//    }

    @Override
    public Long count() {
        return 0L;
    }
}
