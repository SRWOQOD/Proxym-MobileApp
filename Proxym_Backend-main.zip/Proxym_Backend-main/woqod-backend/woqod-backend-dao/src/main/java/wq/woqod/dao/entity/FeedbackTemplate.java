package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by meriam.mejri 24/03/2020
 */
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = Constants.TABLE_FEEDBACKTEMPLATE)
@Builder
@AllArgsConstructor
@Data
public class FeedbackTemplate extends Auditable implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, unique = true)
    private String title;

    @Column
    @Lob
    private String content;

    public FeedbackTemplate() {
        //FeedbackTemplate
    }

}
