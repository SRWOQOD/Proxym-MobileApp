package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Promotion;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/11/16.
 */
public interface PromotionDao {

    List<Promotion> getAllPromotions();

    List<Promotion> getAllPromotionsBo(MultiValueMap<String, String> parameters);

    void createPromotions(List<Promotion> promotions);

    Optional<Promotion> getPromotionByPromotionId(Long promotionId);

    Page<Promotion> getFilteredpromotions(Pageable pageable, MultiValueMap<String, String> parameters);

    void delete(Long id);

    Promotion getPromotionById(Long id);

    void editPromotion(Promotion promotion);

    List<Promotion> getActivePromotions();
}
