package wq.woqod.dao.impl;

import org.springframework.stereotype.Component;
import wq.woqod.dao.AppRedirectionDao;
import wq.woqod.dao.entity.AppRedirection;
import wq.woqod.dao.repository.AppRedirectionRepository;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class AppRedirectionDaoImpl implements AppRedirectionDao {
    private final AppRedirectionRepository appRedirectionRepository;

    public AppRedirectionDaoImpl(AppRedirectionRepository appRedirectionRepository) {
        this.appRedirectionRepository = appRedirectionRepository;
    }

    public AppRedirection getHomeRedirectionByName(String name) {
        return appRedirectionRepository.getHomeRedirectionByName(name);
    }

    @Override
    public List<AppRedirection> getHomeRedirectionList() {
        return appRedirectionRepository.findAll();
    }

    @PostConstruct
    public void init() {
        if (appRedirectionRepository.findAll().isEmpty()) {
            List<AppRedirection> appRedirections = Arrays.stream(wq.woqod.resources.enumerations.AppRedirection.values()).map(appRedirection -> new AppRedirection(1L, appRedirection.name())).collect(Collectors.toList());
            appRedirectionRepository.saveAll(appRedirections);
        }
    }
}
