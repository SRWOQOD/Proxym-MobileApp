package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.SurveyDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QSurvey;
import wq.woqod.dao.entity.Survey;
import wq.woqod.dao.repository.SurveyRepository;
import wq.woqod.resources.enumerations.SurveyTypeEnum;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class SurveyDaoImpl implements SurveyDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyDaoImpl.class);

    private final SurveyRepository surveyRepository;

    private final String SURVEY_STRING = "survey";

    @Autowired
    public SurveyDaoImpl(
            final SurveyRepository surveyRepository
    ) {
        this.surveyRepository = surveyRepository;
    }

    @Override
    public Survey getSurveyById(Long id) {
        LOGGER.info("[DAO] GET Survey by Id {}", id);
        Optional<Survey> survey = surveyRepository.findSurveyById(id);
        return survey.orElseThrow(() -> new DataNotFoundException(SURVEY_STRING, String.valueOf(id), "Survey"));
    }

    @Override
    public Survey getSurveyByTitle(String title) {
        LOGGER.info("[DAO] GET Survey by title {}", title);
        return surveyRepository.findSurveyByTitle(title);
    }

    @Override
    public List<Survey> getSurveyByType(SurveyTypeEnum type) {
        LOGGER.info("[DAO] GET Station by type {}", type);
        return surveyRepository.findSurveyByType(type);
    }

    @Override
    public List<Survey> getAllSurveys(MultiValueMap<String, String> params) {
        LOGGER.info("[DAO] GET All Surveys");

        Predicate predicate = this.getSurveyPredicate(params);
        return (List<Survey>) surveyRepository.findAll(predicate);
    }

    @Override
    public void createSurveys(Survey surveys) {
        surveyRepository.save(surveys);
    }


    @Override
    public void deleteSurveys(Long id) {
        LOGGER.info("[DAO] DELETE Survey");
        Optional<Survey> survey = surveyRepository.findById(id);
        survey.ifPresent(surveyRepository::delete);
    }

    @Override
    public void update(Survey survey) {
        Optional<Survey> survey1 = surveyRepository.findSurveyById(survey.getId());
        if (!survey1.isPresent()) {
            throw new DataNotFoundException(SURVEY_STRING, survey.getTitle(), "Survey");
        }
        try {
            surveyRepository.saveAndFlush(survey);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating survey entity..", ex);
            throw new UpdatingDataException(SURVEY_STRING, ex);
        }
    }

    @Override
    public Page<Survey> getFilteredSurveys(Pageable pageable, MultiValueMap<String, String> params) {
        LOGGER.info("DAO: GET filtered Survey");

        Predicate predicate = this.getSurveyPredicate(params);
        return surveyRepository.findAll(predicate, pageable);
    }

    private Predicate getSurveyPredicate(MultiValueMap<String, String> params) {
        Predicate title = null;
        Predicate creationDate = null;
        Predicate startDate = null;
        Predicate endDate = null;
        Predicate type = null;

        QSurvey qSurvey = QSurvey.survey;
        Date date;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        if (params.get(FilterConstants.TITLE) != null) {
            title = qSurvey.title.containsIgnoreCase(params.getFirst("title"));
        }

        if (params.get(FilterConstants.CREATION_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.CREATION_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            creationDate = qSurvey.creationDate.between(date1, date2);
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.START_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qSurvey.startDate.after(date1.minusDays(1));
        }


        if (params.get(FilterConstants.END_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.END_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            if(params.get(FilterConstants.START_DATE) == null) {
                endDate = qSurvey.endDate.before(date2);
            } else {
                endDate = qSurvey.endDate.before(date2.plusDays(1));
            }

        }

        if (params.get(FilterConstants.TYPE) != null) {
            type = qSurvey.type.eq(SurveyTypeEnum.valueOf(params.getFirst("type")));
        }

        Predicate predicate = qSurvey.isNotNull()
                .and(title)
                .and(creationDate)
                .and(startDate)
                .and(endDate)
                .and(type);

        return  predicate;
    }

    @Override
    public Long count() {
        return surveyRepository.count();
    }
}
