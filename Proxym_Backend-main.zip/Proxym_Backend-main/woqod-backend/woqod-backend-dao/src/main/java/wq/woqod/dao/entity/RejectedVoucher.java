package wq.woqod.dao.entity;

import org.springframework.format.annotation.DateTimeFormat;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Table(name = Constants.TABLE_REJECTEDVOUCHER)
public class RejectedVoucher {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(name = "voucher_reference", length = 13)
    private String voucherReference;


    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "begin_date")
    private LocalDate beginDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "finish_date")
    private LocalDate finishDate;


    @Column(name = "amount")
    private Double amount;

    @Column(name = "status")
    private boolean status;


    public RejectedVoucher() {

    }

    public RejectedVoucher(Builder builder) {
        this.id = builder.id;
        this.voucherReference = builder.voucherReference;
        this.beginDate = builder.beginDate;
        this.finishDate = builder.finishDate;
        this.creationDate = builder.creationDate;
        this.status = builder.status;
        this.amount = builder.amount;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public LocalDate getBeginDate() {
        return beginDate;
    }

    public LocalDate getFinishDate() {
        return finishDate;
    }

    public String getVoucherReference() {
        return voucherReference;
    }

    public Double getAmount() {
        return amount;
    }

    public boolean isStatus() {
        return status;
    }

    public static class Builder {

        private Long id;
        private String voucherReference;
        private LocalDateTime creationDate;
        private LocalDate beginDate;
        private boolean status;
        private LocalDate finishDate;
        private Double amount;

        public Builder amount(Double amount) {
            this.amount = amount;
            return this;
        }

        public Builder status(boolean status) {
            this.status = status;
            return this;
        }


        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder voucherReference(String voucherReference) {
            this.voucherReference = voucherReference;
            return this;
        }


        public Builder creationDate(LocalDateTime creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder beginDate(LocalDate beginDate) {
            this.beginDate = beginDate;
            return this;
        }

        public Builder finishDate(LocalDate finishDate) {
            this.finishDate = finishDate;
            return this;
        }


        public RejectedVoucher build() {
            return new RejectedVoucher(this);
        }

    }

}
