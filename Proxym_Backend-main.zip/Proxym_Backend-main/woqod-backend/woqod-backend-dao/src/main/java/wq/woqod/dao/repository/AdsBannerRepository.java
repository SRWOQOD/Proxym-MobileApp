package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.AdsBanner;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdsBannerRepository extends JpaRepository<AdsBanner, Long>, QuerydslPredicateExecutor<AdsBanner> {
    List<AdsBanner> findAllByActive(Boolean active);

    Optional<AdsBanner> findTopByOrderByOrderItemDesc();
}
