package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.TransactionLogDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QTransactionLog;
import wq.woqod.dao.entity.TransactionLog;
import wq.woqod.dao.repository.TransactionRepository;
import wq.woqod.dao.repository.WoqodeQpayTransactionRepository;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import static wq.woqod.commons.utils.DateFormatter.StringToDate;

@Component
@Slf4j
public class TransactionLogDaoImpl implements TransactionLogDao {
    private final TransactionRepository transactionRepository;
    private final WoqodeQpayTransactionRepository woqodeQpayTransactionRepository;


    @Value("${number.of.minutes}")
    private long numberOfMinutes;

    @Autowired
    public TransactionLogDaoImpl(TransactionRepository transactionRepository, WoqodeQpayTransactionRepository woqodeQpayTransactionRepository) {
        this.transactionRepository = transactionRepository;
        this.woqodeQpayTransactionRepository = woqodeQpayTransactionRepository;
    }

    @Override
    public void createTransactionLog(TransactionLog transactionLog) {
        try {

            this.transactionRepository.save(transactionLog);
        } catch (Exception ex) {
            log.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }

    }

    @Override
    public TransactionLog findByTransactionUUID(String transactionUUID) {
        Optional<TransactionLog> transaction = transactionRepository.findByTransactionUUID(transactionUUID);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(transactionUUID), "transaction"));
    }

    @Override
    public TransactionLog findByReferenceNumber(String referenceNumber) {
        return transactionRepository.findByReferenceNumber(referenceNumber).get();
    }

    @Override
    public TransactionLog update(TransactionLog transactionLog) {
        try {
            log.info("[TransactionLogDaoImpl] update, transactionUUID {} aa creationDate est : {}", transactionLog.getTransactionUUID(), transactionLog.getCreatedDate());
            return this.transactionRepository.saveAndFlush(transactionLog);
        } catch (Exception ex) {
            log.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }
    }

    @Override
    public Page<TransactionLog> findAll(Predicate predicate, Pageable pageable) {
        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public Page<TransactionLog> all(Pageable pageable) {
        return transactionRepository.findAll(pageable);
    }

    @Override
    public TransactionLog updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus) {
        log.info("[TransactionLogDaoImpl] updateStatus, transactionUUID {}, transactionStatus {}", transactionUUID, transactionStatus);
        Optional<TransactionLog> transactionLog = this.transactionRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            TransactionLog trxLog = transactionLog.get();
            if (trxLog.getTransactionStatus() != TransactionStatusEnum.PAID && trxLog.getTransactionStatus() != TransactionStatusEnum.PAIED) {
                log.info("[TransactionLogDaoImpl] updateStatus, transactionUUID {} transactionStatus {}", transactionUUID, transactionStatus);
                trxLog.setTransactionStatus(transactionStatus);
                this.transactionRepository.save(trxLog);
            }
            return transactionLog.get();
        } else
            throw new DataNotFoundException("TransactionLog", transactionUUID, "TransactionLog");
    }

    public TransactionLog updateTransactionId(String transactionUUID, String transactionID, String authReversal, String RPSStatus, TransactionStatusEnum statusEnum) {
        log.info("[TransactionLogDaoImpl] updateStatus, transactionUUID {}, transactionID {}, authReversal {}, RPSStatus {}", transactionUUID, transactionID, authReversal, RPSStatus);
        Optional<TransactionLog> transactionLog = this.transactionRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            TransactionLog trxLog = transactionLog.get();

            trxLog.setTransactionID(transactionID);
            trxLog.setAuthReversal(authReversal);
            if (authReversal != null && !authReversal.equalsIgnoreCase("FALSE") && !authReversal.equalsIgnoreCase("")) {
                trxLog.setAuthReversalStatus("Reversed");
            }
            trxLog.setRPSStatus(RPSStatus);
            trxLog.setTransactionStatus(statusEnum);

            this.transactionRepository.save(trxLog);

            return transactionLog.get();
        } else
            throw new DataNotFoundException("TransactionLog", transactionUUID, "TransactionLog");
    }

    @Override
    public Page<TransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate predicateTransaction = this.getTransactionLogPredicate(params);
        return transactionRepository.findAll(predicateTransaction, pageable);
    }

    private Predicate getTransactionLogPredicate(MultiValueMap<String, String> params) {
        Predicate transactionUUID = null;
        Predicate qid = null;
        Predicate userID = null;
        Predicate transactionStatus = null;
        Predicate referenceNumber = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate rpsStatus = null;
        Predicate mobile = null;
        Predicate startDate = null;
        Predicate endDate = null;

        Date date;

        QTransactionLog qtransactionLog = QTransactionLog.transactionLog;

        if (params.get(FilterConstants.TRANSACTION_UUID) != null) {
            transactionUUID = qtransactionLog.transactionUUID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_UUID));
        }

        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qtransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.QID_TRANSACTION_LOG) != null) {
            qid = qtransactionLog.qid.containsIgnoreCase(params.getFirst(FilterConstants.QID_TRANSACTION_LOG));
        }

        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qtransactionLog.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qtransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qtransactionLog.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }

        if (params.get(FilterConstants.CREATED_DATE) != null) {
            try {
                createdDate = qtransactionLog.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }

        if (params.get(FilterConstants.TRANSACTION_ID) != null) {
            transactionID = qtransactionLog.transactionID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_ID));
        }

        if (params.get(FilterConstants.RPS_STATUS) != null) {
            rpsStatus = qtransactionLog.RPSStatus.containsIgnoreCase(params.getFirst(FilterConstants.RPS_STATUS));
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.START_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qtransactionLog.createdDate.after(DateFormatter.localDateTimeToDate(date1));
        }

        if (params.get(FilterConstants.END_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.END_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qtransactionLog.createdDate.before(DateFormatter.localDateTimeToDate(date2));
        }

        return qtransactionLog.isNotNull()
                .and(transactionUUID)
                .and(qid)
                .and(mobile)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(startDate)
                .and(endDate)
                .and(rpsStatus);
    }


    /**
     * find transaction before 10min
     **/
    @Override
    public List<TransactionLog> findAllByCreatedDateBetween() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (numberOfMinutes * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);
        return transactionRepository.findAllByDescriptionAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus("CBQ",dateToday.getTime(), afterRemovingTenMins, TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);

    }

    /**
     * find transaction between now and given date
     *
     * @param date
     */
    @Override
    public List<TransactionLog> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException {
        // today - 1
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 23);
        dateToday.set(Calendar.MINUTE, 59);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);

        Date givenDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        return transactionRepository.findAllByCreatedDateBetweenAndTransactionStatusOrTransactionStatus(givenDate, dateToday.getTime(), TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);
    }

    @Override
    public BigDecimal getSum(String qid, String from, String to) throws ParseException {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        BigDecimal sumAmoutWoqodeTransactions = BigDecimal.valueOf(transactionRepository.calculateTotalWoqodeAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));
        BigDecimal sumAmoutWoqodeQpayTransactions = BigDecimal.valueOf(woqodeQpayTransactionRepository.calculateTotalQpayWoqodeTransactionsAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));

        return sumAmoutWoqodeTransactions.add(sumAmoutWoqodeQpayTransactions);
    }

    @Override
    public BigDecimal getSumCC(String qid, String from, String to) {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        return BigDecimal.valueOf(transactionRepository.calculateTotalWoqodeAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));
    }


    @Override
    public BigDecimal getSumDC(String qid, String from, String to) throws ParseException {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        return BigDecimal.valueOf(woqodeQpayTransactionRepository.calculateTotalQpayWoqodeTransactionsAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));

    }

    @Override
    public Page<TransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable) {
        log.info("DAO: GET filtered Transactions");
        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public TransactionLog updateTransactionDescription(String transactionUUID, TransactionStatusEnum statusEnum, String description) {
        TransactionLog transactionLog = this.findByTransactionUUID(transactionUUID);
        transactionLog.setTransactionStatus(statusEnum);
        transactionLog.setTransactionSearchDescription(description);
        return (this.update(transactionLog));
    }

    @Override
    public SFResource getSFTrans(String qid, String from, String to) throws ParseException {
        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QTransactionLog qprTransactionLog = QTransactionLog.transactionLog;

        if (qid != null && !qid.isEmpty()) {
            qidp = qprTransactionLog.qid.eq(qid);
        }
        if (from != null) {
            fromp = qprTransactionLog.createdDate.after(StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qprTransactionLog.createdDate.before(tomorrow);
        }

        Predicate predicateSuccess = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAID)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAIED)))
                .and(fromp);

        long successFahesTransaction = transactionRepository.count(predicateSuccess);

        Predicate predicateError = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.FAILED)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.ERROR)))
                .and(fromp);


        long failedFahesTransaction = transactionRepository.count(predicateError);

        return SFResource.builder()
                .success(successFahesTransaction)
                .failed(failedFahesTransaction)
                .build();

    }

    @Override
    public List<TransactionLog> findAll(MultiValueMap<String, String> params) {

        Predicate predicate = this.getTransactionLogPredicate(params);
        return (List<TransactionLog>) transactionRepository.findAll(predicate);
    }

    @Override
    public void saveAll(List<TransactionLog> transactionLogs) {
        try {
            transactionRepository.saveAll(transactionLogs);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting list TransactionLog entity..", ex);
            throw new PersistingDataException("TransactionLog", ex);
        }
    }

    @Override
    public Long count() {
        return transactionRepository.count();
    }
}
