package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.WoqodeQpayTransactionDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QWoqodeQpayTransaction;
import wq.woqod.dao.entity.WoqodeQpayTransaction;
import wq.woqod.dao.repository.WoqodeQpayTransactionRepository;
import wq.woqod.resources.resources.SFResource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import static wq.woqod.commons.utils.DateFormatter.StringToDate;

@Component
@Slf4j
public class WoqodeQpayTransactionDaoImpl implements WoqodeQpayTransactionDao {
    private final WoqodeQpayTransactionRepository transactionRepository;

    @Value("${number.of.minutes}")
    private long numberOfMinutes;

    @Value("${qpay.timeout.duration}")
    private long duration;

    @Autowired
    public WoqodeQpayTransactionDaoImpl(WoqodeQpayTransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public void createTransaction(WoqodeQpayTransaction transaction) {
        try {
            this.transactionRepository.save(transaction);
        } catch (Exception ex) {
            log.error("Problem when persisting Woqode Qpay Transaction entity..", ex);
            throw new PersistingDataException("Woqode Qpay transaction", ex);
        }

    }

    @Override
    public WoqodeQpayTransaction findByPun(String pun) {
        Optional<WoqodeQpayTransaction> transaction = transactionRepository.findByPun(pun);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(pun), "transaction"));
    }

    @Override
    public WoqodeQpayTransaction findByReferenceNumber(String referenceNumber) {
        return transactionRepository.findByReferenceNumber(referenceNumber).get();
    }

    @Override
    public WoqodeQpayTransaction update(WoqodeQpayTransaction transactionLog) {
        try {
            log.info("[TransactionLogDaoImpl] update, Pun {} aa creationDate est : {}", transactionLog.getPun(), transactionLog.getCreatedDate());
            return this.transactionRepository.saveAndFlush(transactionLog);
        } catch (Exception ex) {
            log.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }
    }

    @Override
    public Page<WoqodeQpayTransaction> findAll(Predicate predicate, Pageable pageable) {
        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public Page<WoqodeQpayTransaction> all(Pageable pageable) {
        return transactionRepository.findAll(pageable);
    }


    @Override
    public WoqodeQpayTransaction updateStatus(String pun, TransactionStatusEnum transactionStatus) {
        log.info("[TransactionLogDaoImpl] updateStatus, pun {}, transactionStatus {}", pun, transactionStatus);
        Optional<WoqodeQpayTransaction> transactionLog = this.transactionRepository.findByPun(pun);
        if (transactionLog.isPresent()) {
            WoqodeQpayTransaction trans = transactionLog.get();
            if (trans.getTransactionStatus() != TransactionStatusEnum.PAID && trans.getTransactionStatus() != TransactionStatusEnum.PAIED) {
                log.info("[TransactionLogDaoImpl] updateStatus, pun {} transactionStatus {}", pun, transactionStatus);
                trans.setTransactionStatus(transactionStatus);
                trans.setDescription("CBQ");
                this.transactionRepository.save(trans);
            }
            return transactionLog.get();
        } else
            throw new DataNotFoundException("Qpay Woqode Topup Transaction", pun, "Qpay Woqode Topup Transaction");
    }

    public WoqodeQpayTransaction updateTransactionId(String pun, String statusCode, String statusMessage, String transactionID, String rpsStatus, TransactionStatusEnum statusEnum) {
        log.info("[TransactionLogDaoImpl] updateStatus, pun {}, transactionID {}, RPSStatus {}", pun, transactionID, rpsStatus);
        Optional<WoqodeQpayTransaction> transactionLog = this.transactionRepository.findByPun(pun);
        if (transactionLog.isPresent()) {
            WoqodeQpayTransaction trxLog = transactionLog.get();

            trxLog.setTransactionID(transactionID);
            trxLog.setRPSStatus(rpsStatus);
            trxLog.setTransactionStatus(statusEnum);
            trxLog.setTransactionStatusCode(statusCode);
            trxLog.setTransactionStatusMessage(statusMessage);
            trxLog.setDescription("CBQ");
            this.transactionRepository.save(trxLog);

            return transactionLog.get();
        } else
            throw new DataNotFoundException("Woqode Qpay Transaction", pun, "WoqodeQpayTransaction");
    }

    @Override
    public Page<WoqodeQpayTransaction> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate pun = null;
        Predicate qid = null;
        Predicate userID = null;
        Predicate transactionStatus = null;
        Predicate referenceNumber = null;
        Predicate createdDate = null;
        Predicate rpsStatus = null;
        Predicate mobile = null;
        Predicate startDate = null;
        Predicate endDate = null;

        Date date;

        QWoqodeQpayTransaction qprTransactionLog = QWoqodeQpayTransaction.woqodeQpayTransaction;

        if (params.get(FilterConstants.PUN) != null) {
            pun = qprTransactionLog.pun.containsIgnoreCase(params.getFirst(FilterConstants.PUN));
        }

        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qprTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.QID_TRANSACTION_LOG) != null) {
            qid = qprTransactionLog.qid.eq(String.valueOf(params.getFirst(FilterConstants.QID_TRANSACTION_LOG)));
        }

        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qprTransactionLog.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qprTransactionLog.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }

        if (params.get(FilterConstants.CREATED_DATE) != null) {
            createdDate = qprTransactionLog.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
        }


        if (params.get(FilterConstants.RPS_STATUS) != null) {
            rpsStatus = qprTransactionLog.rpsStatus.containsIgnoreCase(params.getFirst(FilterConstants.RPS_STATUS));
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.START_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qprTransactionLog.createdDate.after(DateFormatter.localDateTimeToDate(date1));
        }

        if (params.get(FilterConstants.END_DATE) != null) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.END_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qprTransactionLog.createdDate.before(DateFormatter.localDateTimeToDate(date2));
        }

        Predicate predicateTransaction = qprTransactionLog.isNotNull()
                .and(pun)
                .and(qid)
                .and(mobile)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(startDate)
                .and(endDate)
                .and(rpsStatus);
        return transactionRepository.findAll(predicateTransaction, pageable);

    }


    /**
     * find transaction before 10min
     **/
    @Override
    public List<WoqodeQpayTransaction> findAllByCreatedDateBetween() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (duration * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);
        return transactionRepository.findAllByTransactionStatusOrTransactionStatusAndCreatedDateBetween(TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR, dateToday.getTime(), afterRemovingTenMins);

    }

    /**
     * find transaction between now and given date
     *
     * @param date
     */
    @Override
    public List<WoqodeQpayTransaction> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException {
        // today - 1
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 23);
        dateToday.set(Calendar.MINUTE, 59);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);

        Date givenDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        return transactionRepository.findAllByTransactionStatusOrTransactionStatusAndCreatedDateBetween(TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR, givenDate, dateToday.getTime());
    }

    @Override
    public Page<WoqodeQpayTransaction> getFiltredTransactions(Predicate predicate, Pageable pageable) {
        log.info("DAO: GET filtered Transactions");

        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public WoqodeQpayTransaction updateTransactionDescription(String pun, TransactionStatusEnum statusEnum, String description, String statusCode, String statusMessage, String rpsStatus, String authReversalStatus, String approvalCode) {
        WoqodeQpayTransaction transactionLog = this.findByPun(pun);
        transactionLog.setTransactionStatus(statusEnum);
        transactionLog.setTransactionSearchDescription(description);
        transactionLog.setTransactionStatusCode(statusCode);
        transactionLog.setTransactionStatusMessage(statusMessage);
        transactionLog.setRPSStatus(rpsStatus);
        transactionLog.setAuthReversalStatus(authReversalStatus);
        transactionLog.setApprovalCode(approvalCode);
        transactionLog.setDescription("CBQ");

        return (this.update(transactionLog));
    }

    @Override
    public List<WoqodeQpayTransaction> findAll(MultiValueMap<String, String> params) throws ParseException {
        Predicate pun = null;
        Predicate referenceNumber = null;
        Predicate transactionStatus = null;
        Predicate userID = null;
        Predicate qid = null;
        Predicate mobile = null;
        Predicate amount = null;
        Predicate currency = null;
        Predicate paymentMethod = null;
        Predicate apiStatus = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate description = null;
        Predicate rpsStatus = null;
        Predicate startDate = null;
        Predicate endDate = null;


        QWoqodeQpayTransaction qprTransactionLog = QWoqodeQpayTransaction.woqodeQpayTransaction;

        if (params.get(FilterConstants.QID_TRANSACTION_LOG) != null) {
            qid = qprTransactionLog.qid.eq(String.valueOf(params.getFirst(FilterConstants.QID_TRANSACTION_LOG)));
        }

        if (params.get(FilterConstants.AMOUNT) != null) {
            String searchAmount = "%" + Double.valueOf(params.getFirst(FilterConstants.AMOUNT)) + "%";
            amount = qprTransactionLog.amount.like(searchAmount);
        }


        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qprTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }


        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qprTransactionLog.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.RPS_STATUS) != null) {
            rpsStatus = qprTransactionLog.rpsStatus.containsIgnoreCase(params.getFirst(FilterConstants.RPS_STATUS));
        }

        if (params.get(FilterConstants.PUN) != null) {
            pun = qprTransactionLog.pun.containsIgnoreCase(params.getFirst(FilterConstants.PUN));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qprTransactionLog.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }


        if (params.get(FilterConstants.CREATED_DATE) != null) {
            createdDate = qprTransactionLog.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
        }

        if (params.get(FilterConstants.TRANSACTION_ID) != null) {
            transactionID = qprTransactionLog.transactionID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_ID));
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.START_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            startDate = qprTransactionLog.createdDate.after(localDateTime);
        }
        if (params.get(FilterConstants.END_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.END_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            endDate = qprTransactionLog.createdDate.before(localDateTime);
        }
        Predicate predicate = qprTransactionLog.isNotNull()
                .and(qid)
                .and(mobile)
                .and(amount)
                .and(paymentMethod)
                .and(currency)
                .and(apiStatus)
                .and(pun)
                .and(description)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(rpsStatus)
                .and(startDate)
                .and(endDate);

        return (List<WoqodeQpayTransaction>) transactionRepository.findAll(predicate);
    }

    @Override
    public Long count() {
        return transactionRepository.count();
    }

    @Override
    public List<WoqodeQpayTransaction> findAllByQid(Long qid) {
        return transactionRepository.findAllByQid(qid);
    }


    @Override
    public List<WoqodeQpayTransaction> findAllByStatusCodeAndCreatedDateBefore(String statusCode, Date date) {
        return transactionRepository.findAllByTransactionStatusCodeAndCreatedDateBefore(statusCode, date);
    }

    @Override
    public List<WoqodeQpayTransaction> findAllByQidAndStatusCodeAndCreatedDateBefore(String qid, String statusCode, Date date) {
        return transactionRepository.findAllByQidAndTransactionStatusCodeAndCreatedDateBefore(qid, statusCode, date);
    }

    @Override
    public List<WoqodeQpayTransaction> findAllByStatusCode(String statusCode) {
        return transactionRepository.findAllByTransactionStatusCode(statusCode);
    }

    /**
     * find transaction before 20min
     **/
    @Override
    public List<WoqodeQpayTransaction> findAllByCreatedDateBeforeTwentyMinutes() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (duration * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);
        return transactionRepository.findAllByDescriptionAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus ("CBQ",dateToday.getTime(),afterRemovingTenMins, TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);

    }

    @Override
    public SFResource getSFQpayTrans(String qid, String from, String to) throws ParseException {
        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QWoqodeQpayTransaction qprTransactionLog = QWoqodeQpayTransaction.woqodeQpayTransaction;

        if (qid != null && !qid.isEmpty()) {
            qidp = qprTransactionLog.qid.eq(String.valueOf(qid));
        }
        if (from != null) {
            fromp = qprTransactionLog.createdDate.after(StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qprTransactionLog.createdDate.before(tomorrow);
        }

        Predicate predicateSuccess = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAID)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAIED)))
                .and(fromp);

        long successFahesTransaction = transactionRepository.count(predicateSuccess);

        Predicate predicateError = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.FAILED)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.ERROR)))
                .and(fromp);


        long failedFahesTransaction = transactionRepository.count(predicateError);

        return SFResource.builder()
                .success(successFahesTransaction)
                .failed(failedFahesTransaction)
                .build();

    }

    @Override
    public void saveAll(List<WoqodeQpayTransaction> woqodeQpayTransactions) {
        try {
            transactionRepository.saveAll(woqodeQpayTransactions);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting list WoqodeQpayTransaction entity..", ex);
            throw new PersistingDataException("WoqodeQpayTransaction", ex);
        }
    }
}
