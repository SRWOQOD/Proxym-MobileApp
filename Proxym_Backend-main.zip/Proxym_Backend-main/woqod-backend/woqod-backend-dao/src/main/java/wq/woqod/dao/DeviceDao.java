package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Device;
import wq.woqod.dao.entity.User;

import java.util.List;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 12/27/2016.
 */
public interface DeviceDao {

    Device getById(Long id);

    Optional<Device> getBySerial(String serial);

    Optional<Device> getActiveByDeviceId(String serial, User userId);

    List<Device> getDevicesByOwner(User owner);

    void updateDevice(Device device);

    Device save(Device device);

    Device update(Device device);

    /**
     * Used to check if the device fingerprint is register
     *
     * @param deviceId
     * @param userName
     * @return
     */
    boolean checkFingerPrint(String deviceId, String userName);


    Page<Device> getDevicesEnabledForFinger(Pageable pageable, Predicate predicate, MultiValueMap<String, String> parameters, String customerNumber);

    /**
     * @param deviceId
     * @return
     */
    boolean disableFinger(String deviceId);

    /**
     * Update device row detail
     *
     * @param bioPin
     * @param customPwd
     * @param deviceId
     * @return
     */
    void updateDeviceBioPin(String bioPin, String customPwd, String deviceId, Long userId);

    /**
     * find device by deviceUIID
     */
    Device findByDeviceUUID(String deviceUIID);

    /**
     * this method aimes find all devices
     *
     * @param
     * @param
     * @return
     */
    List<Device> getAll();


    void addSurveyToDevice(String deviceId, Long surveyId);
    Device findDeviceByDeviceUUID(String deviceUUID);
}
