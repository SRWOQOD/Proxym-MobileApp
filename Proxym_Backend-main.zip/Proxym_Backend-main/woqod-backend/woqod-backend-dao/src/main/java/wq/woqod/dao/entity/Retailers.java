package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = Constants.TABLE_RETAILS)
public class Retailers {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(unique = true)
    private Long retailId;

    @Column(name = "last_synchronisation_date")
    private LocalDateTime lastSynchronisationDate;

    private String title;
    private String xPortalTitle;
    private String xPortalAdress;
    private String xPortalPhone;
    private String contactPerson;
    private String arabicTitle;
    private Long areaId;
    private String longitude;
    private String latitude;
    private String imageCaption;


    public Retailers(Builder builder) {
        this.id = builder.id;
        this.retailId = builder.retailId;
        this.title = builder.title;
        this.xPortalTitle = builder.xPortalTitle;
        this.xPortalPhone = builder.xPortalPhone;
        this.xPortalAdress = builder.xPortalAdress;
        this.contactPerson = builder.contactPerson;
        this.arabicTitle = builder.arabicTitle;
        this.areaId = builder.areaId;
        this.longitude = builder.longitude;
        this.latitude = builder.latitude;
        this.imageCaption = builder.imageCaption;
        this.lastSynchronisationDate = builder.lastSynchronisationDate;
    }

    public Retailers() {
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public Long getRetailId() {
        return retailId;
    }

    public LocalDateTime getLastSynchronisationDate() {
        return lastSynchronisationDate;
    }

    public String getTitle() {
        return title;
    }

    public String getxPortalTitle() {
        return xPortalTitle;
    }

    public String getxPortalAdress() {
        return xPortalAdress;
    }

    public String getxPortalPhone() {
        return xPortalPhone;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public String getArabicTitle() {
        return arabicTitle;
    }

    public Long getAreaId() {
        return areaId;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getImageCaption() {
        return imageCaption;
    }

    public static class Builder {

        private Long id;
        private Long retailId;
        private String title;
        private String xPortalTitle;
        private String xPortalAdress;
        private String xPortalPhone;
        private String contactPerson;
        private String arabicTitle;
        private Long areaId;
        private String longitude;
        private String latitude;
        private String imageCaption;
        private LocalDateTime lastSynchronisationDate;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder retailId(Long retailId) {
            this.retailId = retailId;
            return this;
        }

        public Builder lastSynchronisationDate(LocalDateTime lastSynchronisationDate) {
            this.lastSynchronisationDate = lastSynchronisationDate;
            return this;
        }

        public Builder xPortalAdress(String xPortalAdress) {
            this.xPortalAdress = xPortalAdress;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder xPortalTitle(String xPortalTitle) {
            this.xPortalTitle = xPortalTitle;
            return this;
        }

        public Builder xPortalPhone(String xPortalPhone) {
            this.xPortalPhone = xPortalPhone;
            return this;
        }

        public Builder contactPerson(String contactPerson) {
            this.contactPerson = contactPerson;
            return this;
        }

        public Builder arabicTitle(String arabicTitle) {
            this.arabicTitle = arabicTitle;
            return this;
        }

        public Builder areaId(Long areaId) {
            this.areaId = areaId;
            return this;
        }

        public Builder longitude(String longitude) {
            this.longitude = longitude;
            return this;
        }

        public Builder latitude(String latitude) {
            this.latitude = latitude;
            return this;
        }

        public Builder imageCaption(String imageCaption) {
            this.imageCaption = imageCaption;
            return this;
        }

        public Retailers build() {
            return new Retailers(this);
        }
    }
}
