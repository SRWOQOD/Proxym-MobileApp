package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wq.woqod.dao.NotificationContentDao;
import wq.woqod.dao.entity.NotificationContent;
import wq.woqod.dao.repository.NotificationContentRepository;

import java.util.List;

@Component
public class NotificationContentDaoImpl implements NotificationContentDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationContentDaoImpl.class);

    private final NotificationContentRepository notificationContentRepository;

    @Autowired
    public NotificationContentDaoImpl(
            final NotificationContentRepository notificationContentRepository
    ) {
        this.notificationContentRepository = notificationContentRepository;
    }

    @Override
    public List<NotificationContent> getAllNotificationContents() {
        return notificationContentRepository.findAll();
    }

    @Override
    public NotificationContent getNotificationContentById(Long id) {
        return notificationContentRepository.getOne(id);
    }
}
