package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Voucher;

import java.text.ParseException;
import java.util.List;

public interface VoucherDao {

    void save(Voucher voucher);

    List<Voucher> getAllVoucher();

    void saveList(List<Voucher> vouchers);

    void delete(Voucher voucher);

    Page<Voucher> getFiltredVouchers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    Voucher findByReference(String reference);

    Voucher findByRef(String reference);


}
