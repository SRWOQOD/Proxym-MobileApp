package wq.woqod.dao.entity;

import org.springframework.format.annotation.DateTimeFormat;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Created by Hassen.Ellouze on 14/03/2019.
 */
@Entity
@Table(name = Constants.TABLE_VOUCHER)
public class Voucher {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(name = "voucher_reference", unique = true, length = 13)
    private String voucherReference;

    @Column(name = "status")
    private boolean status;


    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "begin_date")
    private LocalDate beginDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "finish_date")
    private LocalDate finishDate;

    @Column(name = "used_at")
    private LocalDate usedAt;

    @Column(name = "qid")
    private Long qid;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "qnb_reference")
    private String qnbReference;

    @Column(name = "plate_number")
    private String plateNumber;

    @Column(name = "amount")
    private Double amount;


    public Voucher() {

    }

    public Voucher(Builder builder) {
        this.id = builder.id;
        this.voucherReference = builder.voucherReference;
        this.status = builder.status;
        this.beginDate = builder.beginDate;
        this.finishDate = builder.finishDate;
        this.creationDate = builder.creationDate;
        this.usedAt = builder.usedAt;
        this.qid = builder.qid;
        this.plateNumber = builder.plateNumber;
        this.userName = builder.userName;
        this.mobileNumber = builder.mobileNumber;
        this.amount = builder.amount;
        this.qnbReference = builder.qnbReference;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDate getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(LocalDate beginDate) {
        this.beginDate = beginDate;
    }

    public LocalDate getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(LocalDate finishDate) {
        this.finishDate = finishDate;
    }

    public String getVoucherReference() {
        return voucherReference;
    }

    public void setVoucherReference(String voucherReference) {
        this.voucherReference = voucherReference;
    }

    public Long getQid() {
        return qid;
    }

    public void setQid(Long qid) {
        this.qid = qid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public LocalDate getUsedAt() {
        return usedAt;
    }

    public void setUsedAt(LocalDate usedAt) {
        this.usedAt = usedAt;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getQnbReference() {
        return qnbReference;
    }

    public void setQnbReference(String qnbReference) {
        this.qnbReference = qnbReference;
    }

    public static class Builder {

        private Long id;
        private String voucherReference;
        private boolean status;
        private LocalDateTime creationDate;
        private LocalDate beginDate;
        private LocalDate finishDate;
        private LocalDate usedAt;
        private Long qid;
        private String userName;
        private String mobileNumber;
        private String plateNumber;
        private Double amount;
        private String qnbReference;

        public Builder qnbReference(String qnbReference) {
            this.qnbReference = qnbReference;
            return this;
        }

        public Builder amount(Double amount) {
            this.amount = amount;
            return this;
        }

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder voucherReference(String voucherReference) {
            this.voucherReference = voucherReference;
            return this;
        }

        public Builder status(boolean status) {
            this.status = status;
            return this;
        }

        public Builder creationDate(LocalDateTime creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder beginDate(LocalDate beginDate) {
            this.beginDate = beginDate;
            return this;
        }

        public Builder finishDate(LocalDate finishDate) {
            this.finishDate = finishDate;
            return this;
        }

        public Builder usedAt(LocalDate usedAt) {
            this.usedAt = usedAt;
            return this;
        }

        public Builder qid(Long qid) {
            this.qid = qid;
            return this;
        }

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Builder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public Builder plateNumber(String plateNumber) {
            this.plateNumber = plateNumber;
            return this;
        }


        public Voucher build() {
            return new Voucher(this);
        }

    }
}
