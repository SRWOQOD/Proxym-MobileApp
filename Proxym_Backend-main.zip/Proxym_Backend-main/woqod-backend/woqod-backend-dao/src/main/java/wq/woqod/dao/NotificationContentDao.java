package wq.woqod.dao;

import wq.woqod.dao.entity.NotificationContent;

import java.util.List;

public interface NotificationContentDao {

    List<NotificationContent> getAllNotificationContents();

    NotificationContent getNotificationContentById(Long id);
}
