package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.TransactionLog;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

public interface TransactionLogDao {

    void createTransactionLog(TransactionLog transactionLog);

    TransactionLog findByTransactionUUID(String transactionUUID);
    
    TransactionLog findByReferenceNumber(String referenceNumber);

    TransactionLog updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus);

    TransactionLog updateTransactionId(String transactionUUID, String transactionID, String authReversal, String RPSStatus, TransactionStatusEnum statusEnum);

    TransactionLog update(TransactionLog transactionLog);

    Page<TransactionLog> findAll(Predicate predicate, Pageable pageable);

    Page<TransactionLog> all(Pageable pageable);

    Page<TransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable);

    Page<TransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    /**
     * find transaction before 10min
     **/
    List<TransactionLog> findAllByCreatedDateBetween();

    /**
     * find transaction between now and given date
     **/
    List<TransactionLog> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException;

    BigDecimal getSum(String qid, String from, String to) throws ParseException;

    BigDecimal getSumCC(String qid, String from, String to) throws ParseException;

    BigDecimal getSumDC(String qid, String from, String to) throws ParseException;

    TransactionLog updateTransactionDescription(String transactionUUID, TransactionStatusEnum statusEnum, String description);

    SFResource getSFTrans(String qid, String from, String to) throws ParseException;

    List<TransactionLog> findAll(MultiValueMap<String, String> parameters);

    void saveAll(List<TransactionLog> transactionLogs);

    Long count();
}
