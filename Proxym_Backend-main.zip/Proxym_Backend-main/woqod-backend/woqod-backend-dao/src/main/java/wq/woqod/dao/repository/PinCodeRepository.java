package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.PinCode;

/**
 * Created by Hassen.Ellouze on 05/02/2019.
 */
public interface PinCodeRepository extends JpaRepository<PinCode, Long> {

    PinCode findPinCodeByUsername(String username);
}
