package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 26/11/2018.
 */
@Entity
@Table(name = Constants.TABLE_MANUFACTURER)
public class Manufacturer {
    //@OneToMany(mappedBy = "manufacturer", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
   // List<Car> carList;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "manufacturer_id")
    private String manufacturerId;
    @Column(name = "manufacturer_name_en")
    private String nameEn;
    @Column(name = "manufacturer_name_ar")
    private String nameAr;


    public Manufacturer() {
    }

    public Manufacturer(Builder builder) {
        this.id = builder.id;
        this.manufacturerId = builder.manufacturerId;
        this.nameEn = builder.nameEn;
        this.nameAr = builder.nameAr;
      //  this.carList = builder.carList;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getManufacturerId() {
        return manufacturerId;
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

   // public List<Car> getCarList() {
   //     return carList;
   // }

    public static class Builder {
        private Long id;
        private String manufacturerId;
        private String nameEn;
        private String nameAr;
        private List<Car> carList;

        public Builder id(Long id) {
            this.id = id;
            return this;

        }

        public Builder manufacturerId(String manufacturerId) {
            this.manufacturerId = manufacturerId;
            return this;
        }

        public Builder nameEn(String nameEn) {
            this.nameEn = nameEn;
            return this;
        }

        public Builder nameAr(String nameAr) {
            this.nameAr = nameAr;
            return this;
        }

     //   public Builder carList(List<Car> carList) {
     //       this.carList = carList;
      //      return this;
        //}

        public Manufacturer build() {
            return new Manufacturer(this);
        }
    }
}
