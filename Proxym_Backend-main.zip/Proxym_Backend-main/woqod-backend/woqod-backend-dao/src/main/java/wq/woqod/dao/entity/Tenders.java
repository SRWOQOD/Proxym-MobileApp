package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = Constants.TABLE_TENDERS)
public class Tenders implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "srno")
    private String sRNo;

    @Column(name = "tenderNumber")
    private String tenderNumber;

    @Lob
    private String description;

    @Lob
    private String details;

    @Column(name = "collectionDate")
    private LocalDateTime collectionDate;

    @Column(name = "bond")
    private String bond;

    @Column(name = "fee")
    private String fee;

    @Column(name = "tenderFee")
    private Boolean tenderFee;

    @Column(name = "category")
    private String categoryEnum;

    @Column(name = "closingDate")
    private LocalDateTime closingDate;

    @Column(name = "last_synchronisation_date")
    private LocalDateTime lastSynchronisationDate;

}
