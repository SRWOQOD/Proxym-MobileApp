package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.FahesQpayTransaction;
import wq.woqod.dao.entity.User;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface FahesQpayTransactionDao {

    void createTransaction(FahesQpayTransaction transaction, String plateNumber);

    FahesQpayTransaction findByPun(String pun);

    void updateStatus(String pun, TransactionStatusEnum transactionStatus);

    FahesQpayTransaction update(FahesQpayTransaction transaction);

    List<FahesQpayTransaction> findAll(MultiValueMap<String, String> parameters) throws ParseException;

    Page<FahesQpayTransaction> getFiltredTransactions(Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    BigDecimal getTransactionTotalNumber(String qid, String from, String to) throws ParseException;

    /**
     * find transaction before 10min
     **/
    List<FahesQpayTransaction> findAllByCreatedDateBetween();

    SFResource getQpayFahesTransactions(String qid, String from, String to) throws ParseException;

    /**
     * find transaction between now and given date
     **/
    List<FahesQpayTransaction> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException;

    List<FahesQpayTransaction> findAllByQid(String qid);

    List<FahesQpayTransaction> findAllByStatusCodeAndCreatedDateBefore(String statusCode, Date date);

    List<FahesQpayTransaction> findAllByQidAndStatusCodeAndCreatedDateBefore(String qid, String statusCode, Date date);

    List<FahesQpayTransaction> findAllByStatusCode(String statusCode);

    List<FahesQpayTransaction> findAllByCreatedDateBeforeTwentyMinutes();

    SFResource getSFQpayTrans(String qid, String from, String to) throws ParseException;

    Page<FahesQpayTransaction> all(Pageable pageable);

    List<FahesQpayTransaction> saveAll(List<FahesQpayTransaction> fahesQpayTransactions);

    Long count();
}
