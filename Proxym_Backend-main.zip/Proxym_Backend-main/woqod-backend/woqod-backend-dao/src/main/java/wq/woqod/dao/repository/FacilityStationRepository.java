package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.FacilityStation;
import wq.woqod.dao.entity.Station;

import java.util.Set;

/**
 * Created by med-taher.ben-torkia on 12/13/2016.
 */
public interface FacilityStationRepository extends JpaRepository<FacilityStation, Long> {

    Set<FacilityStation> findByStation(Station station);
}
