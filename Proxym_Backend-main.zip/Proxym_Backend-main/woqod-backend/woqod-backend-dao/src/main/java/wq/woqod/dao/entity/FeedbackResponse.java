package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = Constants.TABLE_FEEDBACK_RESPONSE)
public class FeedbackResponse implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "admin_name")
    private String adminName;

    @Column(nullable = false)
    private String content;

    @Column(name = "creation_date")
    private Date creationDate;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "feedback_id")
    private Feedback feedback;

    public FeedbackResponse() {
    }

    public FeedbackResponse(Builder builder) {
        this.id = builder.id;
        this.adminName = builder.adminName;
        this.content = builder.content;
        this.creationDate = builder.creationDate;
        this.feedback = builder.feedback;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getAdminName() {
        return adminName;
    }

    public String getContent() {
        return content;
    }

    public Date getCreationDate() {
        return this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public Feedback getFeedback() {
        return feedback;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "id=" + id +
                ", adminName='" + adminName + '\'' +
                ", content='" + content + '\'' +
                ", creationDate=" + creationDate +
                '}';
    }

    public static class Builder {
        private Long id;
        private String adminName;
        private String content;
        private Date creationDate;
        private Feedback feedback;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder adminName(String adminName) {
            this.adminName = adminName;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder creationDate(Date creationDate) {
            this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
            return this;
        }

        public Builder feedback(Feedback feedback) {
            this.feedback = feedback;
            return this;
        }

        public FeedbackResponse build() {
            return new FeedbackResponse(this);
        }
    }
}
