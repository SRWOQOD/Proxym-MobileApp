package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.JCTransactionLog;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface JCTransactionLogRepository extends JpaRepository<JCTransactionLog, Long>, QuerydslPredicateExecutor<JCTransactionLog> {
    Optional<JCTransactionLog> findByTransactionUUID(String TransactionUUID);

    @Modifying
    @Transactional
    @Query("update JCTransactionLog u set u.transactionStatus = ?2  where u.transactionUUID= ?1")
    void updateStatus(String TransactionUUID, TransactionStatusEnum statusEnum);

    @Query(value = "SELECT * FROM jctransactionlog  WHERE  (job_card_identity = :jobCardIdentity) AND (transaction_status = :transactionStatus) ", nativeQuery = true)
    Optional<JCTransactionLog> findByJobCardIdentityAndTransactionStatus(@Param("jobCardIdentity") String jobCardIdentity, @Param("transactionStatus") String transactionStatus);

    List<JCTransactionLog> findAllByCreatedDateBetweenAndTransactionStatus(Date dateNow, Date fin, TransactionStatusEnum transactionStatus);
}
