package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.FeedbackResponseDao;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.dao.entity.FeedbackResponse;
import wq.woqod.dao.repository.FeedbackRepository;
import wq.woqod.dao.repository.FeedbackResponseRepository;

import java.util.List;
import java.util.Optional;

@Component
public class FeedbackResponseDaoImpl implements FeedbackResponseDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeedbackResponseDaoImpl.class);

    private final FeedbackResponseRepository feedbackResponseRepository;
    private final FeedbackRepository feedbackRepository;

    @Autowired
    public FeedbackResponseDaoImpl(FeedbackResponseRepository feedbackResponseRepository, FeedbackRepository feedbackRepository) {
        this.feedbackResponseRepository = feedbackResponseRepository;
        this.feedbackRepository = feedbackRepository;
    }

    @Override
    public void save(FeedbackResponse feedbackResponse) {
        try {
            feedbackResponseRepository.save(feedbackResponse);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting feedbackResponse entity..", ex);
            throw new PersistingDataException("feedbackResponse", ex);
        }
    }

    @Override
    public List<FeedbackResponse> getAllFeedBackResponse(String id) {
        if (feedbackRepository.findById(Long.parseLong(id)).isPresent()) {
            Optional<Feedback> feedback = feedbackRepository.findById(Long.parseLong(id));
            return feedbackResponseRepository.getAllByFeedback(feedback.get());

        } else {
            throw new DataNotFoundException("feedback", String.valueOf(id), "feedback");
        }
    }

}
