package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.PlateType;
import wq.woqod.dao.entity.User;

import java.util.List;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 06/12/2016.
 */
@Repository
public interface CarRepository extends JpaRepository<Car, Long>, QuerydslPredicateExecutor<Car> {


    List<Car> findListCarsByPlateNumberAndOwner_QidOrderByCreationDateDesc(String plateNumber, String qid);

    List<Car> findCarByActiveAndOwnerQidAndPlateNumberAndPlateType(boolean active, String qid, String plateNumber, PlateType plateType);

    Car findCarByPlateNumberAndActive(String plateNumber, boolean active);

    List<Car> findByOwnerQid(String qid);

    List<Car> findCarByActiveAndOwnerAndPlateNumberAndPlateType(boolean active, User owner, String plateNumber, PlateType plateType);

    List<Car> findCarByOwnerQidAndPlateNumberAndPlateType(String qid, String plateNumber, PlateType plateType);

    Car findCarByPlateNumberAndOwner_QidAndActive(String plateNumber, String qid, boolean active);
    Car findCarByActiveAndPlateNumberAndOwnerQidAndPlateType_PlateTypeId(boolean active, String plate,String qid, String plateType);
    Car findByActiveAndPlateNumberAndPlateType_PlateTypeId(boolean active, String plate, String plateType);

    List<Car> findAllByOwner_IdAndActive(long id, boolean active);

    Optional<Car> findById(Long id);

    List<Car> findCarsByActive(boolean active);

    @Query(value = "Select * from Car c where c.registration_expires_on = TO_DATE(:date,'yyyy-mm-dd')", nativeQuery = true)
    List<Car> findCarsByRegExpirationDateEquals(@Param("date") String date);
}
