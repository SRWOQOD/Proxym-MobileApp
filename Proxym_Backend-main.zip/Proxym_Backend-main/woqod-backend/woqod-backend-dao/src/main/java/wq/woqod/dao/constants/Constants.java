package wq.woqod.dao.constants;

/**
 * Created by bfitouri on 14/11/16.
 */
public class Constants {
    private Constants() {
    }

    public static final String TABLE_PREREGISTRATION = "preregistration";
    public static final String TABLE_COMPANY = "company";
    public static final String TABLE_ACCOUNT = "account";
    public static final String TABLE_TENDERS_CAT = "tenders_category";
    public static final String TABLE_RECOVERY_ACCOUNT = "recoveryaccount";
    public static final String TABLE_CAR = "car";
    public static final String TABLE_CAR_PAPER = "carPaper";
    public static final String TABLE_USER = "users";
    public static final String TABLE_ROLE = "role";
    public static final String TABLE_USER_ROLE = "userrole";
    public static final String TABLE_DEVICE = "device_new";
    public static final String TABLE_FEATURE = "feature";
    public static final String TABLE_ROLES_MODULE = "rolemodule";
    public static final String TABLE_ROLES_MODULE_PERMISSION = "rolemodulepermission";
    public static final String TABLE_MODULE = "module";
    public static final String TABLE_PETROL = "petrol";
    public static final String TABLE_SHAFAF_RETAILER = "shafafretailer";
    public static final String TABLE_PROMOTION = "promotion";
    public static final String TABLE_NEWS = "news";
    public static final String TABLE_FEEDBACK = "feedback";
    public static final String TABLE_FEEDBACK_RESPONSE = "feedbackresponse";
    public static final String TABLE_RATING = "rating";
    public static final String TABLE_STATION = "station";
    public static final String TABLE_FACILITY_STATION = "facilitystation";
    public static final String TABLE_SERVICE_STATION = "servicestation";
    public static final String TABLE_NOTIFICATION_CONTENT = "notificationcontent";
    public static final String TABLE_SURVEY = "survey";
    public static final String TABLE_USER_SURVEY = "usersurvey";
    public static final String TABLE_SURVEY_RESPONSE = "surveyresponse";
    public static final String TABLE_QUESTION_RESPONSE = "surveyquestionresponse";
    public static final String TABLE_SURVEY_QUESTION = "surveyquestion";
    public static final String TABLE_SURVEY_OPTION = "SURVEY_OPTION";
    public static final String TABLE_RETAILS = "retails";
    public static final String TABLE_SUPERMARKET = "supermarket";
    public static final String TABLE_FAHES = "fahes";
    public static final String TABLE_STOCK_PRICES = "stock";
    public static final String TABLE_DISCOUNT = "discount";
    public static final String TABLE_PLATE_TYPE = "platetype";
    public static final String TABLE_MANUFACTURER = "manufacturer";
    public static final String TABLE_MODEL = "Model";
    public static final String TABLE_COLOUR = "colour";
    public static final String TABLE_PINCODE = "pincode";
    public static final String TABLE_CATEGORY = "category";
    public static final String TABLE_PR_TRANSACTION_LOG = "prtransactionlog";
    public static final String TABLE_JC_TRANSACTION_LOG = "jctransactionlog";
    public static final String TABLE_LOGIN_LOGS = "loginlogs";
    public static final String TABLE_JOB_CARD = "jobcard";
    public static final String TABLE_VOUCHER = "voucher";
    public static final String TABLE_REJECTEDVOUCHER = "rejectedvoucher";
    public static final String TABLE_QIDCARD = "qidcard";
    public static final String TABLE_TAG = "tag";
    public static final String TABLE_TRANSACTION_TAG = "TAGTRANSACTION";
    public static final String TABLE_FAHES_QPAY_TRANSACTION = "qpay_fahes_transaction";
    public static final String TABLE_WOQODE_QPAY_TRANSACTION = "qpay_woqode_transaction";
    public static final String TABLE_CONFIG = "Config";

    //ContactMethod Type
    public static final String SMS = "SMS";

    //Sector
    public static final String RETAIL = "Retail";

    // wave 4 entity
    public static final String TABLE_FEEDBACKTEMPLATE = "feedbacktemplate";
    public static final String TABLE_NOTIFICATION_TEMPLATE = "NotificationTemplate";
    public static final String TABLE_NOTIFICATION = "notifications";
    public static final String TABLE_CONTRACTOR = "contractor";
    public static final String TABLE_AUDITBACKEND = "auditbackend";
    public static final String TABLE_AUDITTRAIL_UPDATE_USER = "auditUpdateUser";

    public static final String TABLE_TENDERS = "tenders";
    public static final String TABLE_AREA = "area";
    public static final String TABLE_TOP_BANNER = "topbanner";
    public static final String TABLE_ADS_BANNER = "adsbanner";
    public static final String TABLE_BUSINESS_BANNER = "busniessbanner";
    public static final String TABLE_TEXT = "text";
    public static final String TABLE_APPTIPS = "apptips";
    public static final String TABLE_HOME_REDIRECTION = "homeredirection";

    //Reservation
    public static final String RESERVATIONS = "reservations";

}