package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.CarFilter;

@Repository
public interface CarFilterRepository extends JpaRepository<CarFilter, Long>, QuerydslPredicateExecutor<CarFilter> {
}
