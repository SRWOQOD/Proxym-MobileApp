package wq.woqod.dao.impl;


import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.JobCardDao;
import wq.woqod.dao.entity.JobCard;
import wq.woqod.dao.repository.JobCardRepository;

import java.util.List;
import java.util.Optional;

/**
 * The class {@code JobCardDaoImpl} define the operations
 * of methods needed for Job Card  database
 *
 * @author Meriam.Mejri
 */
@Component
public class JobCardDaoImpl implements JobCardDao {
    private final JobCardRepository jobCardRepository;

    public JobCardDaoImpl(JobCardRepository jobCardRepository) {
        this.jobCardRepository = jobCardRepository;
    }

    @Override
    public void save(JobCard jobCard) {

        try {
            this.jobCardRepository.save(jobCard);
        } catch (Exception ex) {
            throw new PersistingDataException("jobCard", ex);
        }
    }


    @Override
    public JobCard findById(Long id) {
        Optional<JobCard> jobCard = jobCardRepository.findById(id);
        return jobCard.orElseThrow(() -> new DataNotFoundException("job card", String.valueOf(id), "transaction"));
    }

    @Override
    public List<JobCard> getAllJobCards() {
        return jobCardRepository.findAll();
    }

    @Override
    public Page<JobCard> getFiltredJobCards(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) {
        return null;
    }

    @Override
    public void deleteJobCar(Long id) {
        JobCard jobCard = jobCardRepository.getOne(id);
        jobCardRepository.delete(jobCard);
    }

    @Override
    public void update(JobCard jobCard) {
        this.jobCardRepository.saveAndFlush(jobCard);
    }

    @Override
    public JobCard findJobCardByTransactionUUID(String transactionUUID) {
        return this.jobCardRepository.findByTransactionUUID(transactionUUID)
                .orElseThrow(() -> new DataNotFoundException("job card", String.valueOf(transactionUUID), "transaction"));
    }

}
