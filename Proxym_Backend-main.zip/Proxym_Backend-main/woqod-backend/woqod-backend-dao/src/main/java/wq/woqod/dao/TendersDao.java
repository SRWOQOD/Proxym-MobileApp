package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Tenders;

import java.util.List;

public interface TendersDao {
    Page<Tenders> getFiltredTenders(Pageable pageable, MultiValueMap<String, String> parameters);

    void createTenders(List<Tenders> tendersResources);

    Page<Tenders> getTenders(Pageable pageable);

    Page<Tenders> getAllTenders(MultiValueMap<String, String> parameters, Pageable pageable);

    Page<Tenders> getPaginatedTenders(Pageable pageable);
}
