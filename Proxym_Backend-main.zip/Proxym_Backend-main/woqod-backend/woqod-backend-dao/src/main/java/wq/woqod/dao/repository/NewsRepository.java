package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.NewsHome;

import java.util.List;

public interface NewsRepository extends JpaRepository<NewsHome, Long>, QuerydslPredicateExecutor<NewsHome> {
    List<NewsHome> findAllByActive(Boolean active);


}