package wq.woqod.dao.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Amount;

import java.util.Optional;

public interface AmountRepository extends JpaRepository<Amount, Long> {

    public Optional<Amount> findByName(String s);
}
