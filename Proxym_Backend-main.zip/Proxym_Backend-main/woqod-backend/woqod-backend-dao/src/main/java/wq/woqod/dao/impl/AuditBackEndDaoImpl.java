package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.AuditBackEndDao;
import wq.woqod.dao.UserDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.AuditBackEnd;
import wq.woqod.dao.entity.QAuditBackEnd;
import wq.woqod.dao.repository.AuditBackEndRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;


@Slf4j
@Component
public class AuditBackEndDaoImpl implements AuditBackEndDao {

    private final AuditBackEndRepository auditBackEndRepository;
    private final UserDao userDao;

    public AuditBackEndDaoImpl(AuditBackEndRepository auditBackEndRepository, UserDao userDao) {
        this.auditBackEndRepository = auditBackEndRepository;
        this.userDao = userDao;
    }

    @Override
    public AuditBackEnd save(AuditBackEnd auditBackEnd) {
        try {
            return auditBackEndRepository.save(auditBackEnd);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("auditBackEnd", ex);
        }

    }

    @Override
    public Page<AuditBackEnd> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {

        Predicate creationDate = null;
        Predicate qid = null;
        Predicate service = null;
        Predicate responseDescription = null;
       /* Predicate username = null;
        String qidUsernameParam = null;
        if (params.getFirst("username") != null)
            qidUsernameParam = userDao.getByUsername(params.getFirst("username")).getQid();
*/
        QAuditBackEnd qAuditBackEnd = QAuditBackEnd.auditBackEnd;
        Date date;

        if (params.get("qid") != null) {
            qid = qAuditBackEnd.qid.containsIgnoreCase(params.getFirst("qid"));
        }
        /*if (params.get("username") != null) {
            username = qAuditBackEnd.qid.containsIgnoreCase(qidUsernameParam);
        }*/
        if (params.get("responseDescription") != null) {
            responseDescription = qAuditBackEnd.responseDescription.containsIgnoreCase(params.getFirst("responseDescription"));
        }
        if (params.get("service") != null) {
            service = qAuditBackEnd.service.containsIgnoreCase(params.getFirst("service"));
        }

        // 2022-01-17 Yosri ZOUARI
        if (params.get("creationDate") != null) {
            try {
                Calendar cal1 = Calendar.getInstance();
                Calendar cal2 = Calendar.getInstance();
                date = new SimpleDateFormat("yyyy-MM-dd").parse(params.getFirst(FilterConstants.CREATION_DATE));
                cal1.setTime(date);
                cal1.set(Calendar.HOUR_OF_DAY, 0);
                cal1.set(Calendar.MINUTE, 0);
                cal1.set(Calendar.SECOND, 0);
                cal1.set(Calendar.MILLISECOND, 0);

                cal2.setTime(date);
                cal2.set(Calendar.HOUR_OF_DAY, 23);
                cal2.set(Calendar.MINUTE, 59);
                cal2.set(Calendar.SECOND, 59);
                cal2.set(Calendar.MILLISECOND, 0);
                creationDate = qAuditBackEnd.creationDate.between(cal1.getTime(), cal2.getTime());

            } catch (ParseException e) {
                log.error(e.getMessage());
            }
        } else {
            Date today = DateFormatter.StringToDate(LocalDate.now().toString());
            creationDate = qAuditBackEnd.creationDate.after(today);
        }

//        if (params.get("creationDate") != null) {
//            creationDate = qAuditBackEnd.creationDate.after(new SimpleDateFormat("yyyy-MM-dd").parse(params.getFirst("creationDate")));
//        }

        Predicate predicateAuditBE = qAuditBackEnd.isNotNull()
                .and(qid)
                .and(service)
                .and(responseDescription)
                .and(creationDate);
        return auditBackEndRepository.findAll(predicateAuditBE, pageable);
    }

    @Override
    public Long count() {
        return auditBackEndRepository.count();
    }
}
