package wq.woqod.dao.entity;

import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.PaymentMethodEnum;

import javax.persistence.*;

@Entity
@Table(name = Constants.TABLE_JC_TRANSACTION_LOG)
public class JCTransactionLog extends Auditable {
    @Column(length = 1024)
    public String transactionSearchDescription;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    @Column(name = "encrypted_qid")
    private String qid;
    private String mobile;
    @Column(unique = true)
    private String transactionUUID;
    private String referenceNumber;
    private Double amount;
    private String currency;
    private String email;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum transactionStatus;
    @Column(length = 1024)
    private String description;
    private boolean valid;
    @Enumerated(EnumType.STRING)
    private PaymentMethodEnum paymentMethod;
    private String voucherReference;
    private Double initialAmount;
    private String discountInfo;
    private String jobCardIdentity;
    private String transactionID;
    private String rpsStatus;
    private String authReversal;
    private String AuthReversalStatus;

    public String getTransactionSearchDescription() {
        return transactionSearchDescription;
    }

    public void setTransactionSearchDescription(String transactionSearchDescription) {
        this.transactionSearchDescription = transactionSearchDescription;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getRpsStatus() {
        return rpsStatus;
    }

    public void setRpsStatus(String rpsStatus) {
        this.rpsStatus = rpsStatus;
    }

    public String getAuthReversal() {
        return authReversal;
    }

    public void setAuthReversal(String authReversal) {
        this.authReversal = authReversal;
    }

    public String getAuthReversalStatus() {
        return AuthReversalStatus;
    }

    public void setAuthReversalStatus(String authReversalStatus) {
        AuthReversalStatus = authReversalStatus;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTransactionUUID() {
        return transactionUUID;
    }

    public void setTransactionUUID(String transactionUUID) {
        this.transactionUUID = transactionUUID;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public TransactionStatusEnum getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatusEnum transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PaymentMethodEnum getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethodEnum paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getDiscountInfo() {
        return discountInfo;
    }

    public void setDiscountInfo(String discountInfo) {
        this.discountInfo = discountInfo;
    }

    public Double getInitialAmount() {
        return initialAmount;
    }

    public void setInitialAmount(Double initialAmount) {
        this.initialAmount = initialAmount;
    }

    public String getVoucherReference() {
        return voucherReference;
    }

    public void setVoucherReference(String voucherReference) {
        this.voucherReference = voucherReference;
    }

    public String getJobCardIdentity() {
        return jobCardIdentity;
    }

    public void setJobCardIdentity(String jobCardIdentity) {
        this.jobCardIdentity = jobCardIdentity;
    }
}
