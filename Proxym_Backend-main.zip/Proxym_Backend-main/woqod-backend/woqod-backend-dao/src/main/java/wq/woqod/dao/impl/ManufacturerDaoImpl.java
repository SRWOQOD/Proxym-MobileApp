package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.ManufacturerDao;
import wq.woqod.dao.entity.Manufacturer;
import wq.woqod.dao.repository.ManufacturerRepository;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Component
public class ManufacturerDaoImpl implements ManufacturerDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(ManufacturerDaoImpl.class);

    @Autowired
    public ManufacturerRepository manufacturerRepository;

    @Override
    public Manufacturer getManufacturerByGiveId(String manufacturerId) {
        return manufacturerRepository.getByManufacturerId(manufacturerId);
    }

    @Override
    public Manufacturer save(Manufacturer manufacturer) {
        try {
            return manufacturerRepository.save(manufacturer);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting manufacturer entity..", ex);
            throw new PersistingDataException("manufacturer", ex);
        }
    }
}
