package wq.woqod.dao;

import wq.woqod.dao.entity.Model;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
public interface ModelDao {

    Model getModelByGivenId(String modelId);

    Model save(Model model);
}
