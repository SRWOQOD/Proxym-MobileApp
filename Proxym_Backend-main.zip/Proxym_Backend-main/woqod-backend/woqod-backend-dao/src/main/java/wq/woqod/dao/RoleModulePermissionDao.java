package wq.woqod.dao;

import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.entity.Role;
import wq.woqod.dao.entity.RoleModulePermission;

import java.util.List;

;

/**
 * Created by bfitouri on 14/11/16.
 */
public interface RoleModulePermissionDao {

    @Transactional(rollbackFor = Exception.class)
    void save(RoleModulePermission roleModulePermission);

    void update(RoleModulePermission roleModulePermission);

    void update(List<RoleModulePermission> roleModulePermissions);

    void create(List<RoleModulePermission> roleModulePermissions);

    List<RoleModulePermission> getAllRoleModulePermissions();

    List<RoleModulePermission> getRoleModulePermissionsByRole(Role role);

    void save(List<RoleModulePermission> roleModulePermissions);

    void delete(Long id);
}
