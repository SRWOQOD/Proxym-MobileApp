package wq.woqod.dao;

import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.BusinessBanner;

import java.util.List;

public interface BusinessBannerDao {
    void save(BusinessBanner adsBanner);

    List<BusinessBanner> getbanner();

    List<BusinessBanner> filter(MultiValueMap<String, String> parameters);

    BusinessBanner getById(Long valueOf);

    void update(List<BusinessBanner> list);

    List<BusinessBanner> getActiveBanner();

    Long count();

    void delete(Long id);
}
