package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.PreRegistration;

import java.util.List;

public interface PreRegistrationDao {

    void save(PreRegistration preRegistration);

    void saveOrUpdate(PreRegistration preRegistration);

    Page<PreRegistration> getFiltredPreRegistrations(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters);

    void update(PreRegistration preRegistration);

    void deletePreRegistration(Long id);

    PreRegistration findById(Long id);

    PreRegistration findByPlateNumber(String plateNumber);

    List<PreRegistration> findAllByPlateNumber(String plateNumber);
    List<PreRegistration> getAllPreRegistrations(MultiValueMap<String, String> parameters);

    PreRegistration getPreRegistrationByReferenceNumber(String referenceNumber);

    PreRegistration getPreRegistrationByReferenceNumberAndTransactionUUID(String referenceNumber, String transactionUUID);

    PreRegistration findPreRegistrationByTransactionUUID(String transactionUUID);

    PreRegistration findByTransactionUUID(String transactionUUID);

    List<PreRegistration> findByCar(Car car);

    List<PreRegistration> findByQid(String qid);


    long count();
}
