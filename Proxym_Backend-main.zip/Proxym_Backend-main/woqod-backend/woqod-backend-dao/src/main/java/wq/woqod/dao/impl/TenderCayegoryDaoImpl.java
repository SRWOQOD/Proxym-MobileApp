package wq.woqod.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.TenderCategoryDao;
import wq.woqod.dao.entity.TendersCategory;
import wq.woqod.dao.repository.TenderCategoryRepository;



@Repository
public class TenderCayegoryDaoImpl implements TenderCategoryDao {


    private final TenderCategoryRepository tenderCategoryRepository;

    @Autowired
    public TenderCayegoryDaoImpl(TenderCategoryRepository tenderCategoryRepository) {
        this.tenderCategoryRepository = tenderCategoryRepository;
    }


    @Override
    public TendersCategory findOneByCategory_id(String id) {
        return tenderCategoryRepository.findOneByCategoryId(id).isPresent() ? tenderCategoryRepository.findOneByCategoryId(id).get():null;
    }
}
