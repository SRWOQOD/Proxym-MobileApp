package wq.woqod.dao.entity;


import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 11/17/2016.
 */
@Entity
public class CorporateUser extends User implements Serializable {
    public CorporateUser() {
    }

    public CorporateUser(Builder builder) {
        super(builder);
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder extends User.Builder<Builder> {

        public Builder getThis() {
            return this;
        }

        public CorporateUser build() {
            return new CorporateUser(this);
        }

    }
}
