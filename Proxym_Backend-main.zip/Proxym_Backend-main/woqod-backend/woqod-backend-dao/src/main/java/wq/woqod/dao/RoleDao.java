package wq.woqod.dao;

import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.entity.Role;

import java.util.List;

/**
 * Created by bfitouri on 14/11/16.
 */
public interface RoleDao {

    @Transactional(rollbackFor = Exception.class)
    Role save(Role role);

    void update(Role role);

    List<Role> getRoles(String designation, String internalName);

    void delete(Long roleId);

    Role getRoleByDesignation(String designation);

    Role getRoleById(Long id);
}
