package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_AREA)
public class Area {

    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String idArea;

    private String title;

    private String arabicTitle;

    private String longitude;

    private String latitude;

   // @OneToMany(mappedBy = "area", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
   // private List<User> users;

}
