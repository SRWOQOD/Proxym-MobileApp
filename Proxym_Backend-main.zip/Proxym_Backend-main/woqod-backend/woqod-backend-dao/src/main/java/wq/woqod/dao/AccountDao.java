package wq.woqod.dao;

import wq.woqod.dao.entity.Account;

import java.util.List;

/**
 * Created by bfitouri on 14/11/16.
 */
public interface AccountDao {

    void save(Account account);

    void createAccounts(List<Account> accounts);

    boolean exist(String username);

    Account getAccountByUserName(String userName);

    void deleteUserById(Long id);
}
