package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.RoleModulePermissionDao;
import wq.woqod.dao.entity.Role;
import wq.woqod.dao.entity.RoleModulePermission;
import wq.woqod.dao.repository.RoleModulePermissionRepository;

import java.util.List;

/**
 * Created by bfitouri on 27/11/16.
 */
@Component
public class RoleModulePermissionDaoImpl implements RoleModulePermissionDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(RoleModulePermissionDaoImpl.class);

    private final RoleModulePermissionRepository roleModulePermissionRepository;

    @Autowired
    public RoleModulePermissionDaoImpl(RoleModulePermissionRepository roleModulePermissionRepository) {
        this.roleModulePermissionRepository = roleModulePermissionRepository;
    }

    @Override
    public void save(RoleModulePermission roleModulePermission) {
        try {
            roleModulePermissionRepository.save(roleModulePermission);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating role entity..", ex);
            throw new PersistingDataException("RoleModulePermission", ex);
        }
    }

    @Override
    public void save(List<RoleModulePermission> roleModulePermissions) {
        try {
            roleModulePermissionRepository.saveAll(roleModulePermissions);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating role entity..", ex);
            throw new PersistingDataException("RoleModulePermission", ex);
        }
    }

    @Override
    public void update(RoleModulePermission roleModulePermission) {
        try {
            roleModulePermissionRepository.save(roleModulePermission);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating roleModulePermission entity..", ex);
            throw new UpdatingDataException("RoleModulePermission", ex);
        }
    }

    @Override
    public void update(List<RoleModulePermission> roleModulePermissions) {
        try {
            roleModulePermissionRepository.saveAll(roleModulePermissions);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when updating roleModulePermission entity..", ex);
            throw new UpdatingDataException("RoleModulePermission", ex);
        }
    }

    @Override
    public void create(List<RoleModulePermission> roleModulePermissions) {
        try {
            roleModulePermissionRepository.saveAll(roleModulePermissions);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting roleModulePermission entity..", ex);
            throw new PersistingDataException("RoleModulePermission", ex);
        }
    }

    @Override
    public List<RoleModulePermission> getAllRoleModulePermissions() {
        return roleModulePermissionRepository.findAll();
    }

    @Override
    public List<RoleModulePermission> getRoleModulePermissionsByRole(Role role) {
        return roleModulePermissionRepository.findByRole(role);
    }

    @Override
    public void delete(Long id) {
        RoleModulePermission roleModulePermission = roleModulePermissionRepository.getOne(id);
        roleModulePermissionRepository.delete(roleModulePermission);
    }
}
