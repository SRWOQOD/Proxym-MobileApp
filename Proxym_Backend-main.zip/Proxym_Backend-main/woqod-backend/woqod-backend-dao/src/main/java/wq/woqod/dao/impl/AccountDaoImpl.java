package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.AccountDao;
import wq.woqod.dao.entity.Account;
import wq.woqod.dao.repository.AccountRepository;

import java.util.List;
import java.util.Optional;

/**
 * Created by bfitouri on 14/11/16.
 */
@Component
public class AccountDaoImpl implements AccountDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountDaoImpl.class);
    private static final String ACCOUNT = "account";

    private final AccountRepository accountRepository;

    @Autowired
    public AccountDaoImpl(final AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public void save(Account account) {
        LOGGER.info("[DAO] Save Account");
        try {
            accountRepository.save(account);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting account entity..", ex);
            throw new PersistingDataException(ACCOUNT, ex);
        }
    }

    @Override
    public void createAccounts(List<Account> accounts) {
        try {
            accountRepository.saveAll(accounts);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting accounts entity..", ex);
            throw new PersistingDataException(ACCOUNT, ex);
        }
    }

    @Override
    public boolean exist(String username) {
        Account account = Account.newBuilder().userName(username).build();
        return accountRepository.exists(Example.of(account));
    }

    @Override
    public Account getAccountByUserName(String userName) {
        Optional<Account> account = accountRepository.findOneByUsername(userName);
        return account.orElseThrow(() -> new DataNotFoundException(ACCOUNT, userName, "Account"));
    }

    @Override
    public void deleteUserById(Long id) {
        Account account = accountRepository.getOne(id);
        accountRepository.delete(account);
    }
}
