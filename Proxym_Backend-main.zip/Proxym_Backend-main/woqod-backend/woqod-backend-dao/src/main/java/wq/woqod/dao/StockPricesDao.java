package wq.woqod.dao;

import wq.woqod.dao.entity.Stock;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

public interface StockPricesDao {
    List<Stock> getStockPrices();

    void createStockPrices(Stock stock);

    Optional<Stock> findByDateStock(Timestamp dateStock);
}
