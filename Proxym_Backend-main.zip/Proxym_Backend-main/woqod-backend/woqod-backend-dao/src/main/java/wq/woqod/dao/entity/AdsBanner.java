package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_ADS_BANNER)
public class AdsBanner {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String fileUrl ;

    private Boolean active ;

    private Boolean redirection ;

    private RedirectionTypeEnum redirectionTypeEnum;

    private String redirectionPath ;

    private String redirectionArPath ;

    private String title ;

    private String titleArabic ;

    private Long orderItem ;

    private LocalDateTime creationDate;

    private String  appRedirection;

    private String videoThumbnail ;

    private String videoTitleEn ;

    private String videoTitleAr ;

    private FileTypeEnum fileTypeEnum;

    private Boolean titleDisplayed;
}
