package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

@AllArgsConstructor @NoArgsConstructor @Data
@Entity
@Table(name = Constants.TABLE_CONFIG)
public class Config {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(unique = true)
    private String proprety;
    private Boolean value;
}
