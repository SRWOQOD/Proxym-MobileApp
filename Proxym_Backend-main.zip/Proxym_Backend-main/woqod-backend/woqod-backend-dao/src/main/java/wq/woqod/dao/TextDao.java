package wq.woqod.dao;

import wq.woqod.dao.entity.Text;
import wq.woqod.resources.enumerations.TextType;

import java.util.List;

public interface TextDao {
    void update(List<Text> list);

    Text getByTextType(TextType textType);

    List<Text> getTexts();

    void update(TextType textType, Text text);

}
