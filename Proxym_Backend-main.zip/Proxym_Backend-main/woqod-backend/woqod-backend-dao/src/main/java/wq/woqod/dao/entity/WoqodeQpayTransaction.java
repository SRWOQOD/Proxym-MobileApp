package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.commons.enumerations.RefundStatusEnum;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = Constants.TABLE_WOQODE_QPAY_TRANSACTION)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WoqodeQpayTransaction extends Auditable {

    @Column(length = 1024)
    public String transactionSearchDescription;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    @Column(name = "encrypted_qid")
    private String qid;
    private String mobile;
    @Column(unique = true)
    private String pun;
    private String transactionID;
    private String referenceNumber;
    private Double amount;
    private String currency;
    private String email;
    private String rpsStatus;
    private String authReversalStatus;
    private String description;
    @Enumerated(EnumType.STRING)
    private TransactionStatusEnum transactionStatus;
    private String transactionStatusCode;
    private String transactionStatusMessage;
    private String purchasePun;
    private String approvalCode;
    @Enumerated(EnumType.STRING)
    private RefundStatusEnum refundStatus;
    private String refundStatusCode;
    private String refundStatusMessage;

    public String getTransactionSearchDescription() {
        return transactionSearchDescription;
    }

    public void setTransactionSearchDescription(String transactionSearchDescription) {
        this.transactionSearchDescription = transactionSearchDescription;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TransactionStatusEnum getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatusEnum transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPun() {
        return pun;
    }

    public void setPun(String pun) {
        this.pun = pun;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getRPSStatus() {
        return rpsStatus;
    }

    public void setRPSStatus(String rpsStatus) {
        this.rpsStatus = rpsStatus;
    }

    public String getAuthReversalStatus() {
        return authReversalStatus;
    }

    public void setAuthReversalStatus(String authReversalStatus) {
        this.authReversalStatus = authReversalStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPurchasePun() {
        return purchasePun;
    }

    public void setPurchasePun(String purchasePun) {
        this.purchasePun = purchasePun;
    }

    public String getApprovalCode() {
        return approvalCode;
    }

    public void setApprovalCode(String approvalCode) {
        this.approvalCode = approvalCode;
    }

    public RefundStatusEnum getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(RefundStatusEnum refundStatus) {
        this.refundStatus = refundStatus;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getTransactionStatusMessage() {
        return transactionStatusMessage;
    }

    public void setTransactionStatusMessage(String transactionStatusMessage) {
        this.transactionStatusMessage = transactionStatusMessage;
    }

    public String getRefundStatusCode() {
        return refundStatusCode;
    }

    public void setRefundStatusCode(String refundStatusCode) {
        this.refundStatusCode = refundStatusCode;
    }

    public String getRefundStatusMessage() {
        return refundStatusMessage;
    }

    public void setRefundStatusMessage(String refundStatusMessage) {
        this.refundStatusMessage = refundStatusMessage;
    }

}
