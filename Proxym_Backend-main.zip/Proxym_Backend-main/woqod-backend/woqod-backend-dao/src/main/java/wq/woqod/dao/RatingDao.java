package wq.woqod.dao;

import wq.woqod.dao.entity.Rating;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Created by ameni on 02/12/16.
 */
public interface RatingDao {

    void createRating(Rating rating);

    Optional<Rating> getRating(String deviceId, Long stationId, LocalDate creationDate);

    Long getNumberOfRatingsByStationId(Long stationId);

    Double getSumOfRatingsByStationId(Long stationId);

}
