package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import wq.woqod.dao.PetrolPricingDao;
import wq.woqod.dao.entity.Petrol;
import wq.woqod.dao.entity.QPetrol;
import wq.woqod.dao.repository.PetrolPricingRepository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by ameni on 26/11/16.
 */
@Component
public class PetrolPricingDaoImpl implements PetrolPricingDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(PetrolPricingDaoImpl.class);

    private final PetrolPricingRepository petrolRepository;


    @Autowired
    public PetrolPricingDaoImpl(PetrolPricingRepository petrolRepository) {
        this.petrolRepository = petrolRepository;
    }

    @Override
    public List<Petrol> getAllPetrolPricing() {
        LOGGER.info("[DAO] getAllPetrolPricing");
        List<String> petrolTypes = petrolRepository.findDistinctName();
        if (!ObjectUtils.isEmpty(petrolTypes)) {
            return petrolTypes.stream().map(this::getLatestPetrolPrices).collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }
    }

    Petrol getLatestPetrolPrices(String petrolType) {
        Predicate predicate;
        QPetrol qPetrol = QPetrol.petrol;
        //if(petrolType != null) {
        predicate = qPetrol.name.eq(petrolType);

        List<Petrol> petrolPerType = (ArrayList<Petrol>) petrolRepository.findAll(predicate);
        if (!ObjectUtils.isEmpty(petrolPerType)) {
            Optional<Petrol> result = petrolPerType.stream().filter(petrol -> petrol.getDate() != null).sorted(Comparator.comparing(Petrol::getDate).reversed()).findFirst();
            if (result.isPresent()) {
                return result.get();
            }
        }
        //}
        return null;
    }

    @Override
    public Optional<Petrol> getPetrolByPetrolId(Long petrolId) {
        return petrolRepository.findPetrolByPetrolId(petrolId);
    }

    @Override
    public void createPetrolPrices(List<Petrol> petrols) {
        System.out.println("petrols: " + petrols);
        petrolRepository.deleteAll();
//        petrolRepository.flush();
        petrolRepository.saveAll(petrols);
    }

    @Override
    public List<Petrol> getFilteredPrices(MultiValueMap<String, String> parameters) {

        Predicate qname = null;
        Predicate qprice = null;
        Predicate qarabicName = null;

        QPetrol qPetrol = QPetrol.petrol;

        if (parameters.get("name") != null) {
            qname = qPetrol.name.containsIgnoreCase(parameters.getFirst("name"));
        }

        if (parameters.get("price") != null) {
            qprice = qPetrol.price.eq(Double.valueOf(parameters.getFirst("price")));
        }

        if (parameters.get("arabicName") != null) {
            qarabicName = qPetrol.arabicName.containsIgnoreCase(parameters.getFirst("arabicName"));
        }

        Predicate predicateTransaction = qPetrol.isNotNull()
                .and(qname)
                .and(qprice)
                .and(qarabicName);
        return (List<Petrol>) petrolRepository.findAll(predicateTransaction, Sort.by(Sort.Direction.DESC, "date"));
    }
}