/**
 *
 */
package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ameni
 */
@Entity
@Table(name = Constants.TABLE_ROLE)
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "designation", unique = true)
    private String designation;

    @Column(name = "internal_name")
    private String internalName;

    @Column(name = "template")
    private boolean template;

    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserRole> userRoles = new ArrayList<>();

    @OneToMany(mappedBy = "role", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<RoleModulePermission> roleModulePermissions = new ArrayList<>();

    public Role() {
    }

    public Role(Builder builder) {
        this.id = builder.id;
        this.designation = builder.designation;
        this.internalName = builder.internalName;
        this.template = builder.template;
        this.roleModulePermissions = (builder.roleModulePermissions != null) ? builder.roleModulePermissions : new ArrayList<>();
    }

    public Role(String designation, String internalName) {
        this.designation = designation;
        this.internalName = internalName;
    }

    public Role(Long id, String designation, String internalName) {
        this.id = id;
        this.designation = designation;
        this.internalName = internalName;
    }

    public Role(Long id, String designation, String internalName, boolean template) {
        this.id = id;
        this.designation = designation;
        this.internalName = internalName;
        this.template = template;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public List<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public List<RoleModulePermission> getRoleModulePermissions() {
        return roleModulePermissions;
    }

    public void setRoleModulePermissions(List<RoleModulePermission> roleModulePermissions) {
        this.roleModulePermissions = roleModulePermissions;
    }

    public String getInternalName() {
        return internalName;
    }

    public void setInternalName(String internalName) {
        this.internalName = internalName;
    }

    public boolean isTemplate() {
        return template;
    }

    public void setTemplate(boolean template) {
        this.template = template;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        Role other = (Role) obj;
        return Objects.equal(this.id, other.id) && Objects.equal(this.designation, other.designation) && Objects.equal(this.internalName, other.internalName) && Objects.equal(this.template, other.template) && Objects.equal(this.userRoles, other.userRoles) && Objects.equal(this.roleModulePermissions, other.getRoleModulePermissions());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), id, designation, internalName, userRoles, roleModulePermissions);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("id", id)
                .add("designation", designation).add("internalName", internalName).add("userRoles", userRoles)
                .add("isTemplate", template).add("roleModulePermissions", roleModulePermissions)
                .toString();
    }

    public static class Builder {

        private Long id;
        private String designation;
        private String internalName;
        private boolean template;
        private List<RoleModulePermission> roleModulePermissions;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder designation(String designation) {
            this.designation = designation;
            return this;
        }

        public Builder internalName(String internalName) {
            this.internalName = internalName;
            return this;
        }

        public Builder isTemplate(boolean template) {
            this.template = template;
            return this;
        }

        public Builder roleModulePermissions(List<RoleModulePermission> roleModulePermissions) {
            this.roleModulePermissions = roleModulePermissions;
            return this;
        }

        public Role build() {
            return new Role(this);
        }
    }
}
