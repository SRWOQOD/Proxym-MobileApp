package wq.woqod.dao.entity;

import lombok.*;

import javax.persistence.Embeddable;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@Embeddable
public class Option {

    private Long id;

    private String optionEn;

    private String optionAr;


}
