package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.FahesQpayTransactionDao;
import wq.woqod.dao.PreRegistrationDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.FahesQpayTransaction;
import wq.woqod.dao.entity.PreRegistration;
import wq.woqod.dao.entity.QFahesQpayTransaction;
import wq.woqod.dao.entity.QPRTransactionLog;
import wq.woqod.dao.repository.FahesQpayTransactionRepository;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@Component
@Slf4j
public class FahesQpayTransactionDaoImpl implements FahesQpayTransactionDao {

    private final FahesQpayTransactionRepository transactionRepository;
    private final PreRegistrationDao preRegistrationDao;

    @Value("${fahes.number.of.minutes}")
    private long numberOfMinutes;

    @Value("${qpay.timeout.duration}")
    private Integer duration;

    @Autowired
    public FahesQpayTransactionDaoImpl(FahesQpayTransactionRepository trasnsactionRepository, PreRegistrationDao preRegistrationDao) {
        this.transactionRepository = trasnsactionRepository;
        this.preRegistrationDao = preRegistrationDao;
    }

    @Override
    public void createTransaction(FahesQpayTransaction transaction, String plateNumber) {
        try {
            this.transactionRepository.save(transaction);
        } catch (Exception ex) {
            log.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }
    }

    @Override
    public FahesQpayTransaction findByPun(String pun) {
        Optional<FahesQpayTransaction> transaction = transactionRepository.findByPun(pun);
        log.info("[FahesQpayTransactionDaoImpl] find, PUN {}", pun);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(pun), "transaction"));
    }

    @Override
    public FahesQpayTransaction update(FahesQpayTransaction transaction) {
        log.info("[FahesQpayTransactionDaoImpl] update, PUN {} AuthReversalStatus => {}", transaction.getPun(), transaction.getAuthReversalStatus());
        return this.transactionRepository.saveAndFlush(transaction);
    }

    @Override
    public List<FahesQpayTransaction> findAll(MultiValueMap<String, String> params) throws ParseException {
        Predicate pun = null;
        Predicate referenceNumber = null;
        Predicate transactionStatus = null;
        Predicate userID = null;
        Predicate qid = null;
        Predicate mobile = null;
        Predicate amount = null;
        Predicate currency = null;
        Predicate paymentMethod = null;
        Predicate apiStatus = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate authReversal = null;
        Predicate description = null;
        Predicate rpsStatus = null;
        Predicate startDate = null;
        Predicate endDate = null;


        QFahesQpayTransaction qFahesQpayTransaction = QFahesQpayTransaction.fahesQpayTransaction;

        if (params.get("qid") != null) {
            qid = qFahesQpayTransaction.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.AMOUNT) != null) {
            String searchAmount = "%" + Double.valueOf(params.getFirst(FilterConstants.AMOUNT)) + "%";
            amount = qFahesQpayTransaction.amount.like(searchAmount);
        }

        if (params.get(FilterConstants.CONRRENCY) != null) {
            currency = qFahesQpayTransaction.currency.containsIgnoreCase(params.getFirst(FilterConstants.CONRRENCY));
        }

        if (params.get(FilterConstants.PAYMENT_METHOD) != null) {
            paymentMethod = qFahesQpayTransaction.paymentMethod.eq(PaymentMethodEnum.valueOf(params.getFirst(FilterConstants.PAYMENT_METHOD)));
        }


        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qFahesQpayTransaction.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.API_STATUS) != null) {
            apiStatus = qFahesQpayTransaction.apiStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.API_STATUS)));
        }


        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qFahesQpayTransaction.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.PUN) != null) {
            pun = qFahesQpayTransaction.pun.containsIgnoreCase(params.getFirst(FilterConstants.PUN));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qFahesQpayTransaction.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }


        if (params.get(FilterConstants.CREATED_DATE) != null) {
            createdDate = qFahesQpayTransaction.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
        }

        if (params.get((FilterConstants.TRANSACTION_ID)) != null) {
            transactionID = qFahesQpayTransaction.transactionID.containsIgnoreCase(params.getFirst((FilterConstants.TRANSACTION_ID)));
        }

        if (params.get(FilterConstants.DESCRIPTION) != null) {
            description = qFahesQpayTransaction.description.containsIgnoreCase(params.getFirst(FilterConstants.DESCRIPTION));
        }

        if (params.get(FilterConstants.AUTH_RESERVAL_STATUS) != null) {
            authReversal = qFahesQpayTransaction.authReversalStatus.containsIgnoreCase(params.getFirst(FilterConstants.AUTH_RESERVAL_STATUS));
        }
        if (params.get(FilterConstants.RPS_STATUS) != null) {
            rpsStatus = qFahesQpayTransaction.rpsStatus.containsIgnoreCase(params.getFirst(FilterConstants.RPS_STATUS));
        }
        if (params.get(FilterConstants.START_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.START_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            startDate = qFahesQpayTransaction.createdDate.after(localDateTime);
        }
        if (params.get(FilterConstants.END_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.END_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            endDate = qFahesQpayTransaction.createdDate.before(localDateTime);
        }
        Predicate predicate = qFahesQpayTransaction.isNotNull()
                .and(qid)
                .and(mobile)
                .and(amount)
                .and(paymentMethod)
                .and(currency)
                .and(apiStatus)
                .and(pun)
                .and(description)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(rpsStatus)
                .and(startDate)
                .and(endDate)
                .and(authReversal);

        return (List<FahesQpayTransaction>) transactionRepository.findAll(predicate);
    }

    @Override
    public void updateStatus(String pun, TransactionStatusEnum transactionStatus) {
        log.info("[FahesQpayTransactionDaoImpl] updateStatus, transactionUUID {}, PUN {}", pun, transactionStatus);
        Optional<FahesQpayTransaction> transaction = this.transactionRepository.findByPun(pun);
        if (transaction.isPresent()) {
            FahesQpayTransaction transactionn = transaction.get();
            transactionn.setTransactionStatus(transactionStatus);
            if (transactionStatus == TransactionStatusEnum.CANCELED)
                transactionn.setApiStatus(TransactionStatusEnum.CANCELED);
            this.transactionRepository.save(transactionn);
        } else {
            throw new DataNotFoundException("FahesQpayTransaction", pun, "FahesQpayTransaction");
        }
    }


    @Override
    public Page<FahesQpayTransaction> getFiltredTransactions(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {
        log.info("[FahesQpayTransactionDaoImpl] getFiltredTransactions");

        Predicate pun = null;
        Predicate referenceNumber = null;
        Predicate transactionStatus = null;
        Predicate userID = null;
        Predicate qid = null;
        Predicate mobile = null;
        Predicate amount = null;
        Predicate currency = null;
        Predicate paymentMethod = null;
        Predicate apiStatus = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate description = null;
        Predicate rpsStatus = null;
        Predicate startDate = null;
        Predicate endDate = null;


        QFahesQpayTransaction qFahesQpayTransaction = QFahesQpayTransaction.fahesQpayTransaction;

        if (params.get("qid") != null) {
            qid = qFahesQpayTransaction.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.AMOUNT) != null) {
            String searchAmount = "%" + Double.valueOf(params.getFirst(FilterConstants.AMOUNT)) + "%";
            amount = qFahesQpayTransaction.amount.like(searchAmount);
        }

        if (params.get(FilterConstants.CONRRENCY) != null) {
            currency = qFahesQpayTransaction.currency.containsIgnoreCase(params.getFirst(FilterConstants.CONRRENCY));
        }

        if (params.get(FilterConstants.PAYMENT_METHOD) != null) {
            paymentMethod = qFahesQpayTransaction.paymentMethod.eq(PaymentMethodEnum.valueOf(params.getFirst(FilterConstants.PAYMENT_METHOD)));
        }


        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qFahesQpayTransaction.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.API_STATUS) != null) {
            apiStatus = qFahesQpayTransaction.apiStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.API_STATUS)));
        }


        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qFahesQpayTransaction.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.PUN) != null) {
            pun = qFahesQpayTransaction.pun.containsIgnoreCase(params.getFirst(FilterConstants.PUN));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qFahesQpayTransaction.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.START_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            startDate = qFahesQpayTransaction.createdDate.after(localDateTime);
        }
        if (params.get(FilterConstants.END_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.END_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            endDate = qFahesQpayTransaction.createdDate.before(localDateTime);
        }

        if (params.get((FilterConstants.TRANSACTION_ID)) != null) {
            transactionID = qFahesQpayTransaction.transactionID.containsIgnoreCase(params.getFirst((FilterConstants.TRANSACTION_ID)));
        }

        if (params.get(FilterConstants.DESCRIPTION) != null) {
            description = qFahesQpayTransaction.description.containsIgnoreCase(params.getFirst(FilterConstants.DESCRIPTION));
        }

        if (params.get(FilterConstants.PLATENUMBER) != null) {
            PreRegistration preRegistration = preRegistrationDao.findByPlateNumber(params.getFirst(FilterConstants.PLATENUMBER));
            pun = qFahesQpayTransaction.pun.containsIgnoreCase(preRegistration.getTransactionUUID());
        }

        if (params.get(FilterConstants.RPS_STATUS) != null) {
            if (Objects.requireNonNull(params.getFirst(FilterConstants.RPS_STATUS)).equalsIgnoreCase(FilterConstants.SUCCESS)) {
                rpsStatus = qFahesQpayTransaction.rpsStatus.eq(FilterConstants.SUCCESS);
            } else {
                rpsStatus = qFahesQpayTransaction.rpsStatus.ne(FilterConstants.SUCCESS);
            }
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.START_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qFahesQpayTransaction.createdDate.after(DateFormatter.localDateTimeToDate(date1));
        }

        if (params.get(FilterConstants.END_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.END_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qFahesQpayTransaction.createdDate.before(DateFormatter.localDateTimeToDate(date2));
        }

        Predicate predicate = qFahesQpayTransaction.isNotNull()
                .and(qid)
                .and(mobile)
                .and(amount)
                .and(paymentMethod)
                .and(currency)
                .and(apiStatus)
                .and(pun)
                .and(description)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(rpsStatus)
                .and(startDate)
                .and(endDate);

        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public BigDecimal getTransactionTotalNumber(String qid, String from, String to) throws ParseException {
        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QFahesQpayTransaction qFahesQpayTransaction = QFahesQpayTransaction.fahesQpayTransaction;

        if (qid != null && !qid.isEmpty()) {
            qidp = qFahesQpayTransaction.qid.equalsIgnoreCase(qid);
        }
        if (from != null) {
            fromp = qFahesQpayTransaction.createdDate.after(DateFormatter.StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((DateFormatter.StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qFahesQpayTransaction.createdDate.before(tomorrow);
        }

        Predicate predicate = qFahesQpayTransaction.isNotNull()
                .and(qidp)
                .and(top)
                .and(qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.PAID))
                .and(fromp);

        List<FahesQpayTransaction> transactions = new ArrayList<>();
        Iterable<FahesQpayTransaction> transactionResources = transactionRepository.findAll(predicate);
        transactionResources.forEach(transactions::add);

        BigDecimal sum = new BigDecimal(0);
        for (FahesQpayTransaction transaction : transactions
        ) {
            sum = sum.add(BigDecimal.valueOf(transaction.getAmount()));
        }

        return sum;
    }


    /**
     * find transaction before 10min
     **/
    @Override
    public List<FahesQpayTransaction> findAllByCreatedDateBetween() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (duration * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);
        List<FahesQpayTransaction> inProgressTransactions = transactionRepository.findAllByTransactionStatusAndApiStatusAndCreatedDateBetween(TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR, dateToday.getTime(), afterRemovingTenMins);
        List<FahesQpayTransaction> paidTransactions = transactionRepository.findAllByTransactionStatusAndApiStatusAndCreatedDateBetween(TransactionStatusEnum.PAID, TransactionStatusEnum.ERROR, dateToday.getTime(), afterRemovingTenMins);
        inProgressTransactions.addAll(paidTransactions);
        return inProgressTransactions;

    }

    @Override
    public List<FahesQpayTransaction> findAllByCreatedDateBeforeTwentyMinutes() {
        Calendar cal = Calendar.getInstance();

        log.info("Date before removing 20 minutes" + cal.getTime().toString());
        cal.add(Calendar.MINUTE, -duration);
        Date date = cal.getTime();
        log.info("Date after removing 20 minutes" + date.toString());
        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);

        List<FahesQpayTransaction> inProgressTransactions = transactionRepository.findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus("CBQ",dateToday.getTime(),date, TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);
        List<FahesQpayTransaction> paidTransactions = transactionRepository.findAllByRpsStatusAndTransactionStatusAndApiStatusAndCreatedDateBetween("CBQ",TransactionStatusEnum.PAID, TransactionStatusEnum.ERROR, dateToday.getTime(),date);
        inProgressTransactions.addAll(paidTransactions);
        return inProgressTransactions;

    }


    @Override
    public SFResource getQpayFahesTransactions(String qid, String from, String to) throws ParseException {


        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QFahesQpayTransaction qFahesQpayTransaction = QFahesQpayTransaction.fahesQpayTransaction;

        if (qid != null && !qid.isEmpty()) {
            qidp = qFahesQpayTransaction.qid.equalsIgnoreCase(qid);
        }
        if (from != null) {
            fromp = qFahesQpayTransaction.createdDate.after(DateFormatter.StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((DateFormatter.StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qFahesQpayTransaction.createdDate.before(tomorrow);
        }

        Predicate predicateSuccess = qFahesQpayTransaction.isNotNull()
                .and(qidp)
                .and(top)
                .and((qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.PAID)).or(qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.PAIED)))
                .and(fromp);

        Predicate predicateError = qFahesQpayTransaction.isNotNull()
                .and(qidp)
                .and(top)
                .and((qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.FAILED)).or(qFahesQpayTransaction.transactionStatus.eq(TransactionStatusEnum.ERROR)))
                .and(fromp);

        Iterable<FahesQpayTransaction> transactionResources = transactionRepository.findAll(predicateSuccess);

        Iterable<FahesQpayTransaction> failedTransactionResources = transactionRepository.findAll(predicateError);

        return SFResource.builder()
                .success(((ArrayList) transactionResources).size())
                .failed(((ArrayList) failedTransactionResources).size())
                .build();

    }

    /**
     * find transaction between now and given date
     **/
    @Override
    public List<FahesQpayTransaction> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException {
        // today - 1
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 23);
        dateToday.set(Calendar.MINUTE, 59);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);

        Date givenDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        return transactionRepository.findAllByTransactionStatusOrTransactionStatusAndCreatedDateBetween(TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR, givenDate, dateToday.getTime());
    }

    @Override
    public List<FahesQpayTransaction> findAllByQid(String qid) {
        return transactionRepository.findAllByQid(qid);
    }

    @Override
    public List<FahesQpayTransaction> findAllByStatusCodeAndCreatedDateBefore(String statusCode, Date date) {
        return transactionRepository.findAllByTransactionStatusCodeAndCreatedDateBefore(statusCode, date);
    }

    @Override
    public List<FahesQpayTransaction> findAllByQidAndStatusCodeAndCreatedDateBefore(String qid, String statusCode, Date date) {
        return transactionRepository.findAllByQidAndTransactionStatusCodeAndCreatedDateBefore(qid, statusCode, date);
    }

    @Override
    public List<FahesQpayTransaction> findAllByStatusCode(String statusCode) {
        return transactionRepository.findAllByTransactionStatusCode(statusCode);
    }

    @Override
    public SFResource getSFQpayTrans(String qid, String from, String to) throws ParseException {

        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QFahesQpayTransaction qprTransactionLog = QFahesQpayTransaction.fahesQpayTransaction;

        if (qid != null && !qid.isEmpty()) {
            qidp = qprTransactionLog.qid.equalsIgnoreCase(qid);
        }
        if (from != null) {
            fromp = qprTransactionLog.createdDate.after(DateFormatter.StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((DateFormatter.StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qprTransactionLog.createdDate.before(tomorrow);
        }

        Predicate predicateSuccess = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAID)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAIED)))
                .and(fromp);

        long successTransaction = transactionRepository.count(predicateSuccess);

        Predicate predicateError = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.FAILED)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.ERROR)))
                .and(fromp);

        long failedTransaction = transactionRepository.count(predicateError);


        return SFResource.builder()
                .success(successTransaction)
                .failed(failedTransaction)
                .build();

    }

    @Override
    public Page<FahesQpayTransaction> all(Pageable pageable) {
        return transactionRepository.findAll(pageable);
    }

    @Override
    public List<FahesQpayTransaction> saveAll(List<FahesQpayTransaction> fahesQpayTransactions) {
        try {
            return transactionRepository.saveAll(fahesQpayTransactions);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting list FahesQpayTrandaction entity..", ex);
            throw new PersistingDataException("FahesQpayTrandaction", ex);
        }
    }

    @Override
    public Long count() {
        return transactionRepository.count();
    }

}
