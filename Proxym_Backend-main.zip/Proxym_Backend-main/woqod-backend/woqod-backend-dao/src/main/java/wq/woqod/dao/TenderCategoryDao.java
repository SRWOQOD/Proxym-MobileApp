package wq.woqod.dao;

import wq.woqod.dao.entity.TendersCategory;

/**
 * Created by bfitouri on 14/11/16.
 */
public interface TenderCategoryDao {


    TendersCategory findOneByCategory_id(String id);


}
