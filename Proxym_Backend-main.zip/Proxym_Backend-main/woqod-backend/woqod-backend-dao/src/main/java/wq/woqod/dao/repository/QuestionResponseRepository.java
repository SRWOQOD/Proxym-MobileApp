package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import wq.woqod.dao.entity.QuestionResponse;

import java.util.List;


public interface QuestionResponseRepository extends JpaRepository<QuestionResponse, Long> {
    List<QuestionResponse> getBySurveyQuestionId(Long id);

    int countAllBySurveyQuestionIdAndResponses(Long surveyId, String response);

    List<QuestionResponse> getBySurveyQuestion_Id(Long id);

}
