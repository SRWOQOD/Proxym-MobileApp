package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.JobCard;

import java.util.Optional;

public interface JobCardRepository extends JpaRepository<JobCard, Long>, QuerydslPredicateExecutor<JobCard> {

    Optional<JobCard> findById(Long id);

    Optional<JobCard> findByTransactionUUID(String transactionUUID);


}
