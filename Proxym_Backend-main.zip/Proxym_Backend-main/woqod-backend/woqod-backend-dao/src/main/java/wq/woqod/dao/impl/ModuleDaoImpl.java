package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.ModuleDao;
import wq.woqod.dao.entity.Module;
import wq.woqod.dao.repository.ModuleRepository;

import java.util.List;

/**
 * Created by bfitouri on 27/11/16.
 */
@Component
public class ModuleDaoImpl implements ModuleDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(ModuleDaoImpl.class);

    private final ModuleRepository moduleRepository;

    @Autowired
    public ModuleDaoImpl(ModuleRepository moduleRepository) {
        this.moduleRepository = moduleRepository;
    }

    @Override
    public void save(Module module) {
        try {
            moduleRepository.save(module);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting module entity..", ex);
            throw new PersistingDataException("module", ex);
        }

    }

    @Override
    public void update(Module module) {
        try {
            moduleRepository.save(module);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting module entity..", ex);
            throw new UpdatingDataException("module", ex);
        }
    }

    @Override
    public List<Module> getAllModules() {
        return moduleRepository.findAll();
    }

    @Override
    public void delete(Long moduleId) {
        Module module = moduleRepository.getOne(moduleId);
        moduleRepository.delete(module);
    }
}
