package wq.woqod.dao;

import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.entity.Module;

import java.util.List;

;

/**
 * Created by bfitouri on 14/11/16.
 */
public interface ModuleDao {

    @Transactional(rollbackFor = Exception.class)
    void save(Module module);

    void update(Module module);

    List<Module> getAllModules();

    void delete(Long moduleId);
}
