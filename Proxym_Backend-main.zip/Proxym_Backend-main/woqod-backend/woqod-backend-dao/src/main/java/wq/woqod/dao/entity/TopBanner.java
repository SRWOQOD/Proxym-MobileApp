package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.FileTypeEnum;
import wq.woqod.resources.enumerations.RedirectionTypeEnum;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_TOP_BANNER)
public class TopBanner {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String fileUrl ;

    private Boolean active ;

    private Boolean redirection ;

    private RedirectionTypeEnum redirectionTypeEnum;

    private String redirectionPath ;

    private String redirectionArPath ;

    private String videoThumbnail ;

    private String title ;

    private String titleArabic ;

    private String videoTitleEn ;

    private String videoTitleAr ;

    private Long orderItem ;

    private LocalDateTime creationDate;

    private FileTypeEnum fileTypeEnum;

    private String  appRedirection;

    private Boolean titleDisplayed;

}
