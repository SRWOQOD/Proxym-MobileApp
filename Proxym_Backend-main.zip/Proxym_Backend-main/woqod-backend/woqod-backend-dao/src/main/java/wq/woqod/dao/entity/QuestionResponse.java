package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = Constants.TABLE_QUESTION_RESPONSE)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QuestionResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "responses")
    @ElementCollection(targetClass = String.class)
    private List<String> responses;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "surveyQuestion_id")
    private SurveyQuestion surveyQuestion;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "surveyResponse_id")
    private SurveyResponse surveyResponse;


}
