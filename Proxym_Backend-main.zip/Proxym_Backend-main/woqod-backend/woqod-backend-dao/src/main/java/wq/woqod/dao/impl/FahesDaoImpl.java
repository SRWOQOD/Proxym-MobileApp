package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.FahesDao;
import wq.woqod.dao.entity.Fahes;
import wq.woqod.dao.entity.QFahes;
import wq.woqod.dao.repository.FahesRepository;

import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/03/18.
 */
@Component
public class FahesDaoImpl implements FahesDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(FahesDaoImpl.class);

    private static final String STATUS_PARAM = "status";

    private final FahesRepository fahesRepository;

    @Autowired
    public FahesDaoImpl(FahesRepository fahesRepository) {
        this.fahesRepository = fahesRepository;
    }

    @Override
    public List<Fahes> getAllFahesStations() {
        LOGGER.info("Find All fahes");
        return fahesRepository.findAll();
    }

    @Override
    public void createFahesList(List<Fahes> fahesList) {
        try {
            LOGGER.info("[DAO] - create Fahes Stations {}", fahesList.size());
            fahesRepository.saveAll(fahesList);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting promotion entity..", ex);
            throw new PersistingDataException("promotion", ex);
        }
    }

    @Override
    public Optional<Fahes> getFahesByFahesId(Long fahesId) {
        return fahesRepository.findFahesByFahesId(fahesId);
    }

    @Override
    public Page<Fahes> getFilteredFahes(org.springframework.data.domain.Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qphone = null;
        Predicate qtitle = null;
        Predicate qstatus = null;
        Predicate area = null;

        QFahes qFahes = QFahes.fahes;

        if (parameters.get("phone") != null) {
            qphone = qFahes.phone.containsIgnoreCase(parameters.getFirst("phone"));
        }

        if (parameters.get("areaId") != null) {
            area = qFahes.area.idArea.eq((parameters.getFirst("areaId")));
        }
        if (parameters.get("title") != null) {
            qtitle = qFahes.title.containsIgnoreCase(parameters.getFirst("title"));
        }

        if (parameters.get(STATUS_PARAM) != null) {
            qstatus = qFahes.status.containsIgnoreCase(parameters.getFirst(STATUS_PARAM));
        }

        Predicate predicateTransaction = qFahes.isNotNull()
                .and(qtitle)
                .and(qphone)
                .and(area)
                .and(qstatus);

        return fahesRepository.findAll(predicateTransaction, pageable);
    }

}
