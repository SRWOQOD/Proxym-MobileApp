package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = Constants.TABLE_SUPERMARKET)
public class SuperMarket {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(unique = true)
    private Long marketId;

    @Column(name = "last_synchronisation_date")
    private LocalDateTime lastSynchronisationDate;

    @OneToOne
    @JoinColumn(name = "area_id")
    private Area area;

    private String title;
    private String xPortalAdress;
    private String xPortalPhone;
    private String contactPerson;
    private String arabicTitle;
    private String longitude;
    private String latitude;
    private String imageCaption;
    private String icon;


    public SuperMarket() {
    }

    public SuperMarket(Builder builder) {
        this.id = builder.id;
        this.marketId = builder.marketId;
        this.title = builder.title;
        this.xPortalPhone = builder.xPortalPhone;
        this.xPortalAdress = builder.xPortalAdress;
        this.contactPerson = builder.contactPerson;
        this.arabicTitle = builder.arabicTitle;
        this.longitude = builder.longitude;
        this.latitude = builder.latitude;
        this.imageCaption = builder.imageCaption;
        this.lastSynchronisationDate = builder.lastSynchronisationDate;
        this.area = builder.area;
        this.icon = builder.icon;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public Long getMarketId() {
        return marketId;
    }

    public LocalDateTime getLastSynchronisationDate() {
        return lastSynchronisationDate;
    }

    public String getTitle() {
        return title;
    }

    public String getxPortalAdress() {
        return xPortalAdress;
    }

    public String getxPortalPhone() {
        return xPortalPhone;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public String getArabicTitle() {
        return arabicTitle;
    }

    public String getIcon() {
        return icon;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getImageCaption() {
        return imageCaption;
    }

    public Area getArea() {
        return area;
    }

    public static class Builder {
        private Long id;
        private Long marketId;
        private String title;
        private String xPortalAdress;
        private String xPortalPhone;
        private String contactPerson;
        private String arabicTitle;
        private String longitude;
        private String latitude;
        private String imageCaption;
        private String icon;
        private Area area;
        private LocalDateTime lastSynchronisationDate;


        public Builder id(Long id) {
            this.id = id;
            return this;
        }
        public Builder area(Area area) {
            this.area = area;
            return this;
        }

        public Builder marketId(Long marketId) {
            this.marketId = marketId;
            return this;
        }

        public Builder lastSynchronisationDate(LocalDateTime lastSynchronisationDate) {
            this.lastSynchronisationDate = lastSynchronisationDate;
            return this;
        }

        public Builder xPortalAdress(String xPortalAdress) {
            this.xPortalAdress = xPortalAdress;
            return this;
        }

        public Builder icon(String icon) {
            this.icon = icon;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder xPortalPhone(String xPortalPhone) {
            this.xPortalPhone = xPortalPhone;
            return this;
        }

        public Builder contactPerson(String contactPerson) {
            this.contactPerson = contactPerson;
            return this;
        }

        public Builder arabicTitle(String arabicTitle) {
            this.arabicTitle = arabicTitle;
            return this;
        }

        public Builder longitude(String longitude) {
            this.longitude = longitude;
            return this;
        }

        public Builder latitude(String latitude) {
            this.latitude = latitude;
            return this;
        }

        public Builder imageCaption(String imageCaption) {
            this.imageCaption = imageCaption;
            return this;
        }

        public SuperMarket build() {
            return new SuperMarket(this);
        }

    }
}
