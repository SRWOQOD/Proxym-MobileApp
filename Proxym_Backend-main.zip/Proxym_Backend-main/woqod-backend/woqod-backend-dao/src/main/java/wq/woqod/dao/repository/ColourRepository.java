package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.entity.Colour;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Repository
public interface ColourRepository extends JpaRepository<Colour, Long> {
    Colour getByColourId(String colourId);


}
