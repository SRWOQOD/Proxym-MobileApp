package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by med-taher.ben-torkia on 12/23/2016.
 */
@Entity
@Table(name = Constants.TABLE_RECOVERY_ACCOUNT)
public class RecoveryAccount {

    private int wrongAttempt;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "username", unique = true, nullable = false)
    private String userName;
    @Column(nullable = false)
    private String pinCode;
    private LocalDateTime creationDate;
    @Column(columnDefinition = "INTEGER default 0")
    private boolean used;

    public RecoveryAccount() {
    }

    public RecoveryAccount(Builder builder) {
        this.id = builder.id;
        this.userName = builder.userName;
        this.pinCode = builder.pinCode;
        this.creationDate = builder.creationDate;
        this.used = builder.used;
        this.wrongAttempt = builder.wrongAttempt;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public String getPinCode() {
        return pinCode;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public boolean isUsed() {
        return used;
    }

    public int getWrongAttempt() {
        return wrongAttempt;
    }

    public static class Builder {

        private Long id;
        private String pinCode;
        private String userName;
        private LocalDateTime creationDate;
        private boolean used;
        private int wrongAttempt;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder pinCode(String pinCode) {
            this.pinCode = pinCode;
            return this;
        }

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Builder creationDate(LocalDateTime creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder used(boolean used) {
            this.used = used;
            return this;
        }

        public Builder wrongAttempt(int wrongAttempt) {
            this.wrongAttempt = wrongAttempt;
            return this;
        }

        public RecoveryAccount build() {
            return new RecoveryAccount(this);
        }
    }
}
