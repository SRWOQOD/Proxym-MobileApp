package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.JCTransactionLog;

import java.util.List;

public interface JCTransactionLogDao {

    public void createTransactionLog(JCTransactionLog transactionLog, String plateNumber);

    public JCTransactionLog findByTransactionUUID(String transactionUUID);

    public JCTransactionLog findByJobCardIdentity(String jobCardIdentity);

    public void updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus);

    public void updateDescription(String transactionUUID, String description);

    public void updateValidation(String transactionUUID, boolean isValid);

    public JCTransactionLog update(JCTransactionLog transactionLog);

    public Page<JCTransactionLog> findAll(Pageable pageable);

    Page<JCTransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable);

    Page<JCTransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters);

    /**
     * find transaction before 10min
     **/
    public List<JCTransactionLog> findAllByCreatedDateBetween();

    void saveAll(List<JCTransactionLog> transactionLogs);

    Long count();
}
