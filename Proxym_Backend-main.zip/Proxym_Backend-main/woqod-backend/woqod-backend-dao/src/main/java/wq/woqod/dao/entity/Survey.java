package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.SurveyTypeEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = Constants.TABLE_SURVEY)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@SuperBuilder
public class Survey extends NotificationContent implements Serializable {

    @Column(nullable = false)
    private String content;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String arabicContent;

    @Column(nullable = false)
    private String arabicTitle;

    @Column(nullable = false)
    private SurveyTypeEnum type;

    @Column(nullable = false, name = "creation_date")
    private LocalDateTime creationDate;

    @Column(nullable = false)
    private String resourceType;

    @Column(nullable = false)
    private String createdBy;

    @Column
    private Boolean expired;

    @Column
    private Boolean isWoqode;

    private String publishedBy;

    @OneToMany(mappedBy = "survey",cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SurveyQuestion> surveyQuestions = new ArrayList<>();

    @OneToMany(mappedBy = "survey", cascade = CascadeType.ALL)
    private List<SurveyResponse> surveysResponses = new ArrayList<>();

}
