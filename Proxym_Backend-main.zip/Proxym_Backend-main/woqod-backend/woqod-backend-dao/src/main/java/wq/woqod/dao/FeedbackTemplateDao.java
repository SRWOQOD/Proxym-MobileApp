package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.FeedbackTemplate;

import java.util.List;

public interface FeedbackTemplateDao {

    /**
     * The method {@code save} allows to get all feedback templates
     *
     * @param
     * @param parameters
     */
    List<FeedbackTemplate> getAllTemplates(MultiValueMap<String, String> parameters);


    /**
     * The method {@code save} allows to add a new feedback template
     *
     * @param feedback
     */
    void save(FeedbackTemplate feedback);


    /**
     * Used to get a feedback Template by
     * given id
     *
     * @param id
     */

    FeedbackTemplate findById(Long id);

    /**
     * Used to get feedback template list
     *
     * @param pageable
     * @param parameters
     * @return Page
     */
    Page<FeedbackTemplate> getFiltredTemplates(Pageable pageable, MultiValueMap<String, String> parameters);

    /**
     * Used to update a feedback Template
     *
     * @param feedback
     */
    void update(FeedbackTemplate feedback);

    /**
     * Used to delete a feedback Template by given id
     *
     * @param id
     */
    void deleteFeedback(Long id);

    FeedbackTemplate getTemplateByTitle(String title);

    Long count();
}
