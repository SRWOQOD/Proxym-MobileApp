package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import wq.woqod.dao.entity.Rating;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Created by ameni on 02/12/16.
 */
public interface RatingRepository extends JpaRepository<Rating, Long> {

    Optional<Rating> findByDeviceIdAndStationIdAndCreationDate(String deviceId, Long stationId, LocalDate creationDate);

    @Query("select count(r) from Rating r where r.stationId = ?1")
    Long getNumberOfRatingsByStationId(Long stationId);

    @Query("select sum(r.rating) from Rating r where r.stationId = ?1")
    Double getSumOfRatingsByStationId(Long stationId);
}
