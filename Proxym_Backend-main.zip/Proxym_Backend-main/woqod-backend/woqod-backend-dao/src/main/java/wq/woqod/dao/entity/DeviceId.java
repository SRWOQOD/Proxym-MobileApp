package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by Ameni.Berrich on 16/04/18.
 */

@Embeddable
public class DeviceId implements Serializable {

    private String serial;
    private Long personId;

    public DeviceId(String serial, Long personId) {
        this.serial = serial;
        this.personId = personId;
    }

    public DeviceId() {
    }

    public Long getPersonId() {
        return personId;
    }

    public String getSerial() {
        return serial;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        DeviceId other = (DeviceId) obj;
        return Objects.equal(this.serial, other.serial) && Objects.equal(this.personId, other.personId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), personId, serial);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("personId", personId).add("serial", serial).toString();
    }
}
