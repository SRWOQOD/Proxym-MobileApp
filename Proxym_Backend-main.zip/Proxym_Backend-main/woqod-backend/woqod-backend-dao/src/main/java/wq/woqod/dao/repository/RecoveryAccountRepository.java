package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.RecoveryAccount;

/**
 * Created by med-taher.ben-torkia on 12/23/2016.
 */
public interface RecoveryAccountRepository extends JpaRepository<RecoveryAccount, Long> {

    RecoveryAccount findOneByUserName(String userName);
}
