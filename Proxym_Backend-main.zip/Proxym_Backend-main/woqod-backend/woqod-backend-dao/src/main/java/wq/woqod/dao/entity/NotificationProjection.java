
package wq.woqod.dao.entity;

import java.util.Date;

public interface NotificationProjection {

    Long getID();
    String getTITLE_EN();
    String getDESCRIPTION_EN();
    Date getCREATED_DATE();
}
