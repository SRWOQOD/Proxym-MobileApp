package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Notification;
import wq.woqod.dao.entity.NotificationProjection;

import java.text.ParseException;
import java.util.List;

public interface NotificationDao {

    /**
     * this method aimes to save user notifciation
     *
     * @param
     * @param notification
     * @return
     */
    void save(Notification notification);

    /**
     * this method aimes find all notifications
     *
     * @param
     * @param
     * @param parameters
     * @return
     */
    List<NotificationProjection> getAll(MultiValueMap<String, String> parameters);

    /**
     * Delete notification from DB
     */
    void delete(Long id);

    /**
     * this method aimes find all notifications by device
     *
     * @param
     * @param
     * @return
     */
    List<Notification> getAllByDevice();


    /**
     * The method {@code update}  used to get filtres notifications
     *
     * @param pageable
     * @param predicate
     * @param parameters
     */

    Page<Notification> getFilteredNotifications(Pageable pageable, Predicate predicate, MultiValueMap<String, String> parameters) throws ParseException;


    Page<NotificationProjection> getFilteredNotifications(Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    /**
     * The method {@code findAllByDevice}  used to get list of  notifications
     * by Device UIID
     *
     * @param deviceID
     */
    List<Notification> findAllByDevice(String deviceID);

    /**
     * The method {@code findAllByUsername}  used to get list of  notifications
     * by username
     *
     * @param deviceId
     */
    List<Notification> findAllByUsername(String deviceId);

    Page<Notification> findAllForAnonymousUser(Pageable pageable);

    void updateStatus(Long valueOf, String username, String uniqueId, String deviceId);

    List<Notification> findAllForAnonymousUserList(String deviceId);

    void updateAll(Boolean username, String deviceid);

    void updateStatusAnswered(Long id,String deviceId);

    Boolean hasNotif(String deviceid,Boolean connected);

    Long count();
}
