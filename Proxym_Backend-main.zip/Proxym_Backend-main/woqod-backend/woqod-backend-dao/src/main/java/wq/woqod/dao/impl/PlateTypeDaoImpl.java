package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.PlateTypeDao;
import wq.woqod.dao.entity.PlateType;
import wq.woqod.dao.repository.PlateTypeRepository;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Component
@Slf4j
public class PlateTypeDaoImpl implements PlateTypeDao {

    @Autowired
    public PlateTypeRepository plateTypeRepository;

    @Override
    public PlateType getPlateTypeByGivenId(String plateTypeId) {
        return plateTypeRepository.getByPlateTypeId(plateTypeId);
    }

    @Override
    public PlateType save(PlateType plateType) {
        try {
            return plateTypeRepository.save(plateType);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting plate type entity..", ex);
            throw new PersistingDataException("plate type", ex);
        }
    }
}
