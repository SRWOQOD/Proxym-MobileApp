package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.collect.Sets;
import org.hibernate.annotations.NaturalId;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.StationCategoryEnum;
import wq.woqod.resources.enumerations.StationStatusEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Created by bfitouri on 08/12/16.
 */
@Entity
@Table(name = Constants.TABLE_STATION)
public class Station implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NaturalId
    @Column(unique = true)
    private Long stationId;

    private String title;

    private String arabicName;

    @Enumerated(EnumType.STRING)
    private StationCategoryEnum category;

    private String longitude;

    private String icon;

    private String latitude;

    private String phone;

    private String petrolCategory;

    private String isVisible;

    @Enumerated(EnumType.STRING)
    private StationStatusEnum status;

    @OneToMany(mappedBy = "station", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ServiceStation> serviceStations;

    @OneToMany(mappedBy = "station", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<FacilityStation> facilityStations;

    private Double rating;

    @ElementCollection(fetch = FetchType.EAGER)
    private Map<Integer, Double> stationRating;

    @Column(name = "last_synchronisation_date")
    private Date lastSynchronisationDate;

    public String getPetrolCategory() {
        return petrolCategory;
    }

    @OneToOne
    @JoinColumn(name = "area_id")
    private Area area;

    public Station() {
    }

    private Station(Builder builder) {
        this.id = builder.id;
        this.stationId = builder.stationId;
        this.title = builder.title;
        this.arabicName = builder.arabicName;
        this.category = builder.category;
        this.longitude = builder.longitude;
        this.latitude = builder.latitude;
        this.phone = builder.phone;
        this.status = builder.status;
        this.serviceStations = Objects.isNull(builder.serviceStations) ? Sets.newHashSet() : builder.serviceStations;
        this.facilityStations = Objects.isNull(builder.facilityStations) ? Sets.newHashSet() : builder.facilityStations;
        this.rating = builder.rating;
        this.stationRating = builder.stationRating;
        this.lastSynchronisationDate = builder.lastSynchronisationDate;
        this.area = builder.area;
        this.icon = builder.icon;
        this.petrolCategory = builder.petrolCategory;
        this.isVisible = builder.isVisible;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public Long getStationId() {
        return stationId;
    }

    public String getTitle() {
        return title;
    }

    public String getArabicName() {
        return arabicName;
    }

    public StationCategoryEnum getCategory() {
        return category;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public Area getArea() {
        return area;
    }

    public String getIcon() {
        return icon;
    }

    public String getPhone() {
        return phone;
    }

    public String getIsVisible() {
        return isVisible;
    }

    public StationStatusEnum getStatus() {
        return status;
    }

    public Set<ServiceStation> getServiceStations() {
        return serviceStations;
    }

    public Set<FacilityStation> getFacilityStations() {
        return facilityStations;
    }

    public Double getRating() {
        return rating;
    }

    public Map<Integer, Double> getStationRating() {
        return stationRating;
    }

    public Date getLastSynchronisationDate() {
        return lastSynchronisationDate;
    }

    public void addFacilities(Set<FacilityStation> facilities) {
        facilities.forEach(this::addFacility);
    }

    public void addFacility(FacilityStation facilityStation) {
        if (facilityStations.contains(facilityStation)) {
            facilityStations.remove(facilityStation);
        }
        facilityStations.add(facilityStation);
    }

    public void addServices(Set<ServiceStation> services) {
        services.forEach(this::addService);
    }

    /**
     * if service already exists (same station and same name),
     * we remove it and add it for update
     *
     * @param serviceStation
     */
    public void addService(ServiceStation serviceStation) {
        if (serviceStations.contains(serviceStation)) {
            serviceStations.remove(serviceStation);
        }
        serviceStations.add(serviceStation);
    }

    public void removeServices(Set<ServiceStation> serviceStations) {
        serviceStations.forEach(this::removeService);
    }

    public void removeService(ServiceStation serviceStation) {
        serviceStations.remove(serviceStation);
    }

    public void removeFacilities(Set<FacilityStation> facilityStations) {
        facilityStations.forEach(this::removeFacility);
    }

    public void removeFacility(FacilityStation facilityStation) {
        facilityStations.remove(facilityStation);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("title", title).add("status", status).add("arabicName", arabicName)
                .add("category", category).add("longitude", longitude).add("latitude", latitude).toString();
    }

    public static class Builder {

        private Long id;
        private Long stationId;
        private String title;
        private String arabicName;
        private StationCategoryEnum category;
        private String longitude;
        private String latitude;
        private String phone;
        private StationStatusEnum status;
        private Set<ServiceStation> serviceStations;
        private Set<FacilityStation> facilityStations;
        private Map<Integer, Double> stationRating;
        private Double rating;
        private Date lastSynchronisationDate;
        private Area area;
        private String icon;
        private String petrolCategory;
        private String isVisible;

        public Builder area(Area area) {
            this.area = area;
            return this;
        }
        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder stationId(Long stationId) {
            this.stationId = stationId;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }
        public Builder petrolCategory(String petrolCategory) {
            this.petrolCategory = petrolCategory;
            return this;
        }
        public Builder icon(String icon) {
            this.icon = icon;
            return this;
        }

        public Builder arabicName(String arabicName) {
            this.arabicName = arabicName;
            return this;
        }

        public Builder category(StationCategoryEnum category) {
            this.category = category;
            return this;
        }

        public Builder longitude(String longitude) {
            this.longitude = longitude;
            return this;
        }

        public Builder latitude(String latitude) {
            this.latitude = latitude;
            return this;
        }

        public Builder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder status(StationStatusEnum status) {
            this.status = status;
            return this;
        }

        public Builder serviceStations(Set<ServiceStation> serviceStations) {
            this.serviceStations = serviceStations;
            return this;
        }

        public Builder facilityStations(Set<FacilityStation> facilityStations) {
            this.facilityStations = facilityStations;
            return this;
        }

        public Builder rating(Double rating) {
            this.rating = rating;
            return this;
        }

        public Builder stationRating(Map<Integer, Double> stationRating) {
            this.stationRating = stationRating;
            return this;
        }

        public Builder lastSynchronisationDate(Date lastSynchronisationDate) {
            this.lastSynchronisationDate = lastSynchronisationDate;
            return this;
        }

        public Builder isVisible(String isVisible) {
            this.isVisible = isVisible;
            return this;
        }

        public Station build() {
            return new Station(this);
        }
    }


}
