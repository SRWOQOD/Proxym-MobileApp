package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.JobCard;

import java.util.List;

public interface JobCardDao {

    void save(JobCard jobCard);

    JobCard findById(Long id);

    List<JobCard> getAllJobCards();

    Page<JobCard> getFiltredJobCards(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters);

    void deleteJobCar(Long id);

    void update(JobCard jobCard);

    JobCard findJobCardByTransactionUUID(String transactionUUID);


}
