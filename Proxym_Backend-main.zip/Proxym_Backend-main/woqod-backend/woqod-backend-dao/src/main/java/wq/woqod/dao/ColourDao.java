package wq.woqod.dao;

import wq.woqod.dao.entity.Colour;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
public interface ColourDao {
    Colour getColourByGiveId(String colourId);

    Colour save(Colour colour);
}
