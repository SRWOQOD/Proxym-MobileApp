package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.RecoveryAccountDao;
import wq.woqod.dao.entity.RecoveryAccount;
import wq.woqod.dao.repository.RecoveryAccountRepository;

/**
 * Created by med-taher.ben-torkia on 12/23/2016.
 */
@Component
public class RecoveryAccountDaoImpl implements RecoveryAccountDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(RecoveryAccountDaoImpl.class);

    private final RecoveryAccountRepository recoveryAccountRepository;

    @Autowired
    public RecoveryAccountDaoImpl(RecoveryAccountRepository recoveryAccountRepository) {
        this.recoveryAccountRepository = recoveryAccountRepository;
    }

    @Override
    public void save(RecoveryAccount recoveryAccount) {
        try {
            recoveryAccountRepository.save(recoveryAccount);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("RecoveryAccount", ex);
        }
    }

    @Override
    public boolean exist(String userName) {
        return this.getRecoveryAccountByUserName(userName) != null;
    }

    @Override
    public RecoveryAccount getRecoveryAccountByUserName(String userName) {
        return recoveryAccountRepository.findOneByUserName(userName);
    }
}
