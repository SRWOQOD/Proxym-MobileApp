package wq.woqod.dao.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.CarCategory;


/**
 * The interface {@code CarCategoryRepository} eases the management
 * of car category database operations
 *
 * @author Meriam.Mejri
 */
public interface CarCategoryRepository extends JpaRepository<CarCategory, Long>, QuerydslPredicateExecutor<CarCategory> {

    CarCategory findByCategoryId(String categoryId);

    CarCategory findByFee(Double fee);

    CarCategory findByNameEn(String nameEn);


}
