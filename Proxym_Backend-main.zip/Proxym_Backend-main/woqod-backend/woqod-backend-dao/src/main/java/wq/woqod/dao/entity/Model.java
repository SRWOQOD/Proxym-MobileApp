package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 28/11/2018.
 */
@Entity
@Table(name = Constants.TABLE_MODEL)
public class Model {

    //@OneToMany(mappedBy = "model", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
   // List<Car> carList;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "model_id")
    private String modelId;
    @Column(name = "model_name_en")
    private String nameEn;
    @Column(name = "model_name_ar")
    private String nameAr;

    public Model() {
    }

    public Model(Builder builder) {
        this.id = builder.id;
        this.modelId = builder.modelId;
        this.nameEn = builder.nameEn;
        this.nameAr = builder.nameAr;
     //   this.carList = builder.carList;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getModelId() {
        return modelId;
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

  /*  public List<Car> getCarList() {
        return carList;
    }*/

    public static class Builder {
        private Long id;
        private String modelId;
        private String nameEn;
        private String nameAr;
     //   private List<Car> carList;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder modelId(String modelId) {
            this.modelId = modelId;
            return this;
        }

        public Builder nameEn(String nameEn) {
            this.nameEn = nameEn;
            return this;
        }

        public Builder nameAr(String nameAr) {
            this.nameAr = nameAr;
            return this;
        }

       /* public Builder carList(List<Car> carList) {
            this.carList = carList;
            return this;
        }*/

        public Model build() {
            return new Model(this);
        }
    }

    public static class CreateSearchRequest {
    }
}
