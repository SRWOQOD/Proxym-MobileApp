package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.ColourDao;
import wq.woqod.dao.entity.Colour;
import wq.woqod.dao.repository.ColourRepository;

/**
 * Created by Hassen.Ellouze on 06/12/2018.
 */
@Component
public class ColourDaoImpl implements ColourDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(ColourDaoImpl.class);

    @Autowired
    public ColourRepository colourRepository;

    @Override
    public Colour getColourByGiveId(String colourId) {
        return colourRepository.getByColourId(colourId);
    }

    @Override
    public Colour save(Colour colour) {
        try {
            return colourRepository.save(colour);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("colour", ex);
        }
    }
}
