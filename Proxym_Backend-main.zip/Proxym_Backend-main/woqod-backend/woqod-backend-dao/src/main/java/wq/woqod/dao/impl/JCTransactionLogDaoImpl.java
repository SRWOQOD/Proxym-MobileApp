package wq.woqod.dao.impl;


import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.Expressions;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.JCTransactionLogDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.JCTransactionLog;
import wq.woqod.dao.entity.QJCTransactionLog;
import wq.woqod.dao.entity.TransactionLog;
import wq.woqod.dao.repository.JCTransactionLogRepository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * The class {@code JCTransactionLogImpl} define the operations
 * of methods needed for Job Card Transaction Log database
 *
 * @author Meriam.Mejri
 */
@Slf4j
@Component
public class JCTransactionLogDaoImpl implements JCTransactionLogDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(JCTransactionLogDaoImpl.class);
    private JCTransactionLogRepository transactionLogRepository;

    @Value("${number.of.minutes}")
    private long numberOfMinutes;

    @Autowired
    public JCTransactionLogDaoImpl(JCTransactionLogRepository jcTransactionLogRepository) {
        this.transactionLogRepository = jcTransactionLogRepository;
    }


    /**
     * The method {@code createJCTransactionLog} allows to add a new Job Card TransactionLog
     *
     * @param transactionLog
     */


    @Override
    public void createTransactionLog(JCTransactionLog transactionLog, String plateNumber) {
        try {
            this.transactionLogRepository.save(transactionLog);
        } catch (Exception ex) {
            LOGGER.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }
    }

    /**
     * The method {@code findByTransactionUUID} allows to find Job Card TransactionLog
     * by TransactionUUID
     *
     * @param transactionUUID
     * @return JCTransactionLog
     */

    @Override
    public JCTransactionLog findByTransactionUUID(String transactionUUID) {
        Optional<JCTransactionLog> transaction = transactionLogRepository.findByTransactionUUID(transactionUUID);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(transactionUUID), "transaction"));
    }

    @Override
    public JCTransactionLog findByJobCardIdentity(String jobCardIdentity) {
        Optional<JCTransactionLog> transaction = transactionLogRepository.findByJobCardIdentityAndTransactionStatus(jobCardIdentity, TransactionStatusEnum.PAID.name());
        return transaction.orElseThrow(() -> new DataNotFoundException("jobCardIdentity", String.valueOf(jobCardIdentity), "transaction"));
    }


    /**
     * Used to update a Job Card TransactionLog Status
     *
     * @param transactionUUID
     * @param transactionStatus
     */

    @Override
    public void updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus) {
        LOGGER.info("[JCTransactionLogImpl] updateStatus, transactionUUID {}, transactionStatus {}", transactionUUID, transactionStatus);
        Optional<JCTransactionLog> transactionLog = this.transactionLogRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            JCTransactionLog trxLog = transactionLog.get();
            trxLog.setTransactionStatus(transactionStatus);
            this.transactionLogRepository.save(trxLog);
        } else {
            throw new DataNotFoundException(FilterConstants.TRANSACTION_LOG_SRING, transactionUUID, FilterConstants.TRANSACTION_LOG_SRING);
        }
    }

    @Override
    public void updateDescription(String transactionUUID, String description) {
        LOGGER.info("[TransactionLogDaoImpl] updateDescription, transactionUUID {}, description {}", transactionUUID, description);
        Optional<JCTransactionLog> transactionLog = this.transactionLogRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            JCTransactionLog trxLog = transactionLog.get();
            trxLog.setDescription(description);
            this.transactionLogRepository.save(trxLog);
        } else
            throw new DataNotFoundException(FilterConstants.TRANSACTION_LOG_SRING, transactionUUID, FilterConstants.TRANSACTION_LOG_SRING);
    }

    @Override
    public void updateValidation(String transactionUUID, boolean isValid) {
        LOGGER.info("[TransactionLogDaoImpl] updateValidatio, transactionUUID {}, IsValid {}", transactionUUID, isValid);
        Optional<JCTransactionLog> transactionLog = this.transactionLogRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            JCTransactionLog trxLog = transactionLog.get();
            trxLog.setValid(isValid);
            this.transactionLogRepository.save(trxLog);
        } else
            throw new DataNotFoundException(FilterConstants.TRANSACTION_LOG_SRING, transactionUUID, FilterConstants.TRANSACTION_LOG_SRING);
    }

    /**
     * Used to update a Job Card TransactionLog
     *
     * @param transactionLog
     */
    @Override
    public JCTransactionLog update(JCTransactionLog transactionLog) {
        LOGGER.info("[JCTransactionLogImpl] update, transactionUUID {}", transactionLog.getTransactionUUID());

        return this.transactionLogRepository.save(transactionLog);
    }

    @Override
    public void saveAll(List<JCTransactionLog> transactionLogs) {
        try {
            transactionLogRepository.saveAll(transactionLogs);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting list JCTransactionLog entity..", ex);
            throw new PersistingDataException("JCTransactionLog", ex);
        }
    }

    @Override
    public Long count() {
        return transactionLogRepository.count();
    }


    /**
     * Used to get All Job Card TransactionLog
     *
     * @return List
     */
    @Override
    public Page<JCTransactionLog> findAll(Pageable pageable) {
        return transactionLogRepository.findAll(pageable);
    }


    /**
     * Used to filter  Job Card TransactionLog list
     *
     * @param predicate
     * @param pageable
     * @return Page
     */
    @Override
    public Page<JCTransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable) {
        LOGGER.info("DAO: GET filtered Transactions");
        return transactionLogRepository.findAll(predicate, pageable);
    }

    /**
     * Used to filter  Job Card TransactionLog list
     *
     * @param predicate
     * @param pageable
     * @param parameters
     * @return Page
     */
    @Override
    public Page<JCTransactionLog> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) {
        LOGGER.info("DAO: GET filtered Transactions");

        QJCTransactionLog transactionLog = QJCTransactionLog.jCTransactionLog;

        Predicate predicateWithEquals;

        BooleanExpression transactionUUID = null;
        BooleanExpression qidTransaction = null;
        BooleanExpression mobileTransaction = null;
        BooleanExpression userID = null;
        BooleanExpression transactionStatus = null;
        BooleanExpression referenceNumber = null;
        BooleanExpression createdDate = null;

        if (parameters.containsKey(FilterConstants.TRANSACTION_UUID_OP_SRING) || parameters.containsKey(FilterConstants.MOBILE_TRANSACTION_OP_SRING) || parameters.containsKey(FilterConstants.USER_IDOP_STRING) || parameters.containsKey(FilterConstants.QID_TRANSATION_OP_STRING) || parameters.containsKey(FilterConstants.TRANSACTION_STATUS_OP_STRING) || parameters.containsKey(FilterConstants.REFERENCE_NUMBER_OP_STRING) || parameters.containsKey(FilterConstants.CREATED_DATE_STRING)) {


            if (parameters.containsKey(FilterConstants.REFERENCE_NUMBER_STRING) && (parameters.containsKey(FilterConstants.REFERENCE_NUMBER_OP_STRING)) && (!Objects.isNull(transactionLog.referenceNumber)) && (!Objects.isNull(parameters.get(FilterConstants.REFERENCE_NUMBER_OP_STRING)))) {
                if (parameters.get(FilterConstants.REFERENCE_NUMBER_OP_STRING).contains(FilterConstants.EQUAL_STRING)) {
                    referenceNumber = transactionLog.referenceNumber.eq((parameters.get(FilterConstants.REFERENCE_NUMBER_STRING)).toString().substring(1, (parameters.get(FilterConstants.REFERENCE_NUMBER_STRING)).toString().length() - 1));
                }
                if (parameters.get(FilterConstants.REFERENCE_NUMBER_OP_STRING).contains(FilterConstants.CONTAINS_STRING)) {
                    referenceNumber = transactionLog.referenceNumber.contains((parameters.get(FilterConstants.REFERENCE_NUMBER_STRING)).toString().substring(1, (parameters.get(FilterConstants.REFERENCE_NUMBER_STRING)).toString().length() - 1));
                }

            }

            if ((parameters.containsKey(FilterConstants.TRANSACTION_UUID_STRING)) && (parameters.containsKey(FilterConstants.TRANSACTION_UUID_OP_SRING)) && (!Objects.isNull(transactionLog.transactionUUID)) && (!Objects.isNull(parameters.get(FilterConstants.TRANSACTION_UUID_OP_SRING)))) {
                if (parameters.get(FilterConstants.TRANSACTION_UUID_OP_SRING).contains(FilterConstants.EQUAL_STRING)) {
                    transactionUUID = transactionLog.transactionUUID.eq((parameters.get(FilterConstants.TRANSACTION_UUID_STRING)).toString().substring(1, (parameters.get(FilterConstants.TRANSACTION_UUID_STRING)).toString().length() - 1));
                }
                if (parameters.get(FilterConstants.TRANSACTION_UUID_OP_SRING).contains(FilterConstants.CONTAINS_STRING)) {
                    transactionUUID = transactionLog.transactionUUID.contains((parameters.get(FilterConstants.TRANSACTION_UUID_STRING)).toString().substring(1, (parameters.get(FilterConstants.TRANSACTION_UUID_STRING)).toString().length() - 1));
                }
            }

            if (((parameters.containsKey(FilterConstants.QID_TRANSACTION_STRING)) && (parameters.containsKey(FilterConstants.QID_TRANSATION_OP_STRING)) && (!Objects.isNull(transactionLog.qid)) && (!Objects.isNull(parameters.get(FilterConstants.QID_TRANSATION_OP_STRING)))) && (parameters.get(FilterConstants.QID_TRANSATION_OP_STRING).contains(FilterConstants.EQUAL_STRING))) {
                qidTransaction = transactionLog.qid.eq((parameters.get(FilterConstants.QID_TRANSACTION_STRING)).toString().substring(1, (parameters.get(FilterConstants.QID_TRANSACTION_STRING)).toString().length() - 1));
            }


            if (((parameters.containsKey("transactionStatus")) && (parameters.containsKey(FilterConstants.TRANSACTION_STATUS_OP_STRING)) && (!Objects.isNull(transactionLog.transactionStatus)) && (!Objects.isNull(parameters.get(FilterConstants.TRANSACTION_STATUS_OP_STRING)))) && (parameters.get(FilterConstants.TRANSACTION_STATUS_OP_STRING).contains(FilterConstants.EQUAL_STRING))) {
                {
                    transactionStatus = transactionLog.transactionStatus.eq(TransactionStatusEnum.fromName(parameters.get("transactionStatus").get(0)));
                }
            }
            if ((parameters.containsKey(FilterConstants.MOBILE_TRANSACTION_STRING)) && (parameters.containsKey(FilterConstants.MOBILE_TRANSACTION_OP_SRING)) && (!Objects.isNull(transactionLog.mobile)) && (!Objects.isNull(parameters.get(FilterConstants.MOBILE_TRANSACTION_OP_SRING)))) {
                if (parameters.get(FilterConstants.MOBILE_TRANSACTION_OP_SRING).contains(FilterConstants.EQUAL_STRING)) {
                    mobileTransaction = transactionLog.mobile.eq((parameters.get(FilterConstants.MOBILE_TRANSACTION_STRING)).toString().substring(1, (parameters.get(FilterConstants.MOBILE_TRANSACTION_STRING)).toString().length() - 1));
                }
                if (parameters.get(FilterConstants.MOBILE_TRANSACTION_OP_SRING).contains(FilterConstants.CONTAINS_STRING)) {
                    mobileTransaction = transactionLog.mobile.contains((parameters.get(FilterConstants.MOBILE_TRANSACTION_STRING)).toString().substring(1, (parameters.get(FilterConstants.MOBILE_TRANSACTION_STRING)).toString().length() - 1));
                }
            }

            if ((parameters.containsKey(FilterConstants.USER_ID_STRING)) && (parameters.containsKey(FilterConstants.USER_IDOP_STRING)) && (!Objects.isNull(transactionLog.userID)) && (!Objects.isNull(parameters.get(FilterConstants.USER_IDOP_STRING)))) {
                if (parameters.get(FilterConstants.USER_IDOP_STRING).contains(FilterConstants.EQUAL_STRING)) {
                    userID = transactionLog.userID.eq((parameters.get(FilterConstants.USER_ID_STRING)).toString().substring(1, (parameters.get(FilterConstants.USER_ID_STRING)).toString().length() - 1));
                }
                if (parameters.get(FilterConstants.USER_IDOP_STRING).contains(FilterConstants.CONTAINS_STRING)) {
                    userID = transactionLog.userID.contains((parameters.get(FilterConstants.USER_ID_STRING)).toString().substring(1, (parameters.get(FilterConstants.USER_ID_STRING)).toString().length() - 1));
                }

            }


            if ((parameters.containsKey(FilterConstants.CREATED_DATE_STRING)) && (parameters.containsKey(FilterConstants.CREATED_DATE_OP_STRING)) && (!Objects.isNull(transactionLog.createdDate)) && (!Objects.isNull(parameters.get(FilterConstants.CREATED_DATE_OP_STRING)))) {
                String dateString = "";
                String dateString1 = "";
                Date date1 = null;
                Date date2 = null;
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
                dateString = parameters.get(FilterConstants.CREATED_DATE_STRING).get(0);
                dateString1 = parameters.get(FilterConstants.CREATED_DATE_STRING).get(0);

                dateString = dateString + " 00:00:00";
                dateString1 = dateString1 + " 23:59:00";

                try {

                    date1 = format.parse(dateString);

                    date2 = format.parse(dateString1);

                } catch (ParseException e) {
                    LOGGER.info(e.getMessage());
                }

                if (parameters.get(FilterConstants.CREATED_DATE_OP_STRING).contains(FilterConstants.EQUAL_STRING)) {
                    createdDate = transactionLog.createdDate.between(date1, date2);
                }
                if (parameters.get(FilterConstants.CREATED_DATE_OP_STRING).contains("less")) {
                    createdDate = transactionLog.createdDate.before(date1);
                }
                if (parameters.get(FilterConstants.CREATED_DATE_OP_STRING).contains("greater")) {
                    createdDate = transactionLog.createdDate.after(date1);
                }

            }

            if (null == transactionUUID) {
                transactionUUID = Expressions.asBoolean(true).isTrue();
            }
            if (null == mobileTransaction) {
                mobileTransaction = Expressions.asBoolean(true).isTrue();
            }
            if (null == userID) {
                userID = Expressions.asBoolean(true).isTrue();
            }
            if (null == qidTransaction) {
                qidTransaction = Expressions.asBoolean(true).isTrue();
            }
            if (null == transactionStatus) {
                transactionStatus = Expressions.asBoolean(true).isTrue();
            }
            if (null == referenceNumber) {
                referenceNumber = Expressions.asBoolean(true).isTrue();
            }
            if (null == createdDate) {
                createdDate = Expressions.asBoolean(true).isTrue();
            }

            predicateWithEquals = transactionUUID.and(mobileTransaction).and(userID).and(qidTransaction).and(transactionStatus).and(referenceNumber).and(createdDate);
        } else {
            predicateWithEquals = transactionUUID;
        }

        return transactionLogRepository.findAll(predicateWithEquals, pageable);
    }

    /**
     * find transaction before 10min
     **/
    @Override
    public List<JCTransactionLog> findAllByCreatedDateBetween() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (numberOfMinutes * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        return transactionLogRepository.findAllByCreatedDateBetweenAndTransactionStatus(dateToday.getTime(), afterRemovingTenMins, TransactionStatusEnum.INPROGRESS);
    }
}
