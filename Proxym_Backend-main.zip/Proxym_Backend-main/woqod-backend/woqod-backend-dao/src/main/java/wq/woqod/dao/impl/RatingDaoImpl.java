package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.RatingDao;
import wq.woqod.dao.entity.Rating;
import wq.woqod.dao.repository.RatingRepository;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Created by ameni on 02/12/16.
 */
@Component
public class RatingDaoImpl implements RatingDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(RatingDaoImpl.class);

    private final RatingRepository ratingRepository;

    @Autowired
    public RatingDaoImpl(RatingRepository ratingRepository) {
        this.ratingRepository = ratingRepository;
    }

    @Override
    public void createRating(Rating rating) {
        LOGGER.debug("Creating rating for user {} and station {}", rating.getDeviceId(), rating.getStationId());
        try {
            ratingRepository.save(rating);
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when persisting rating entity..", ex);
            throw new PersistingDataException("rating", ex);
        }
    }

    @Override
    public Optional<Rating> getRating(String deviceId, Long stationId, LocalDate creationDate) {
        return ratingRepository.findByDeviceIdAndStationIdAndCreationDate(deviceId, stationId, creationDate);
    }

    @Override
    public Long getNumberOfRatingsByStationId(Long stationId) {
        return ratingRepository.getNumberOfRatingsByStationId(stationId);
    }

    @Override
    public Double getSumOfRatingsByStationId(Long stationId) {
        return ratingRepository.getSumOfRatingsByStationId(stationId);
    }
}
