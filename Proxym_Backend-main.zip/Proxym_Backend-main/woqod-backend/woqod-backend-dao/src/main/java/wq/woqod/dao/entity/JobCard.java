package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = Constants.TABLE_JOB_CARD)
public class JobCard {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "ORGANIZATION_ID")
    private String organizationId;

    @Column(name = "ASSET_NUMBER")
    private String assetNumber;
    @Column(name = "ASSET_DESCRIPTION")
    private String assetDescription;
    @Column(name = "WIP_ENTITY_ID")
    private String wipEntityId;
    @Column(name = "WONO")
    private String wono;
    @Column(name = "WO_DESC")
    private String woDesc;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "DEPT")
    private String dept;
    @Column(name = "ACTIVITY")
    private String activity;
    @Column(name = "ACTIVITY_DESC")
    private String activityDesc;
    @Column(name = "CREATION_DATE")
    private Date creationDate;
    @Column(name = "DATE_RELEASED")
    private Date releasedDate;
    @Column(name = "DATE_COMPLETED")
    private Date completedDate;
    @Column(name = "DATE_CLOSED")
    private Date closedDate;
    @Column(name = "ACTUAL_START_DATE")
    private Date actualStartDate;
    @Column(name = "SCHEDULED_START_DATE")
    private Date scheduledStartDate;
    @Column(name = "SCHEDULED_COMPLETION_DATE")
    private Date scheduledCompletionDate;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "METER_READING")
    private String meterReading;
    @Column(name = "ACTUAL_END_DATE")
    private Date actualEndDate;
    @Column(name = "WIP_CLASS")
    private String wipClass;
    @Column(name = "NEXT_SERVICE")
    private String nextService;
    @Column(name = "STATION_NAME")
    private String stationName;
    @Column(name = "TOTAL_AMOUNT")
    private String totalAmount;
    @Column(name = "PAYMENT_STATUS")
    private String paymentStatus;
    @Column(name = "error_en")
    private String errorEn;
    @Column(name = "error_ar")
    private String errorAR;

    private String wsStatus;
    private String payStatus;


    @Column(name = "transactionUUID")
    private String transactionUUID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_id")
    private Car car;
    @Column(name = "discount_info")
    private String discountInfo;
    @Column(name = "voucher_reference")
    private String voucherReference;
    @Column(name = "final_amount")
    private Double finalAmount;

    @Column(name = "customer_name")
    private String customerName;
    @Column(name = "mobile_number")
    private String mobileNumber;
    @Column(name = "staff_number")
    private String staffNumber;
    @Column(name = "staff_name")
    private String staffName;
    @Column(name = "operation_seq_num")
    private String operationSeqNum;
    @Column(name = "paymen_method")
    private String paymenMethod;
    @Column(name = "invoice_line_number")
    private String invoiceLineNumber;
    @Column(name = "invoice_TRX_number")
    private String invoiceTRXNumber;
    @Column(name = "item")
    private String item;
    @Column(name = "quantity")
    private String quantity;
    @Column(name = "price")
    private String price;
    @Column(name = "woDate")
    private Date woDate;
    @Column(name = "item_description")
    private String itemDescription;

    public JobCard() {
    }

    public JobCard(Builder builder) {
        this.activity = builder.activity;
        this.activityDesc = builder.activityDesc;
        this.actualEndDate = builder.actualEndDate;
        this.actualStartDate = builder.actualStartDate;
        this.assetDescription = builder.assetDescription;
        this.assetNumber = builder.assetNumber;
        this.closedDate = builder.closedDate;
        this.completedDate = builder.completedDate;
        this.createdBy = builder.createdBy;
        this.creationDate = builder.creationDate;
        this.dept = builder.dept;
        this.errorAR = builder.errorAR;
        this.errorEn = builder.errorEn;
        this.id = builder.id;
        this.meterReading = builder.meterReading;
        this.organizationId = builder.organizationId;
        this.nextService = builder.nextService;
        this.releasedDate = builder.releasedDate;
        this.scheduledCompletionDate = builder.scheduledCompletionDate;
        this.scheduledStartDate = builder.scheduledStartDate;
        this.stationName = builder.stationName;
        this.totalAmount = builder.totalAmount;
        this.status = builder.status;
        this.wipClass = builder.wipClass;
        this.wipEntityId = builder.wipEntityId;
        this.woDesc = builder.woDesc;
        this.wono = builder.wono;
        this.paymentStatus = builder.paymentStatus;
        this.wsStatus = builder.wsStatus;
        this.payStatus = builder.payStatus;
        this.transactionUUID = builder.transactionUUID;
        this.car = builder.car;
        this.discountInfo = builder.discountInfo;
        this.voucherReference = builder.voucherReference;
        this.finalAmount = builder.finalAmount;
        this.customerName = builder.customerName;
        this.mobileNumber = builder.mobileNumber;
        this.staffNumber = builder.staffNumber;
        this.staffName = builder.staffName;
        this.operationSeqNum = builder.operationSeqNum;
        this.paymenMethod = builder.paymenMethod;
        this.invoiceLineNumber = builder.invoiceLineNumber;
        this.invoiceTRXNumber = builder.invoiceTRXNumber;
        this.item = builder.item;
        this.quantity = builder.quantity;
        this.price = builder.price;
        this.woDate = builder.woDate;
        this.itemDescription = builder.itemDescription;

    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public String getAssetNumber() {
        return assetNumber;
    }

    public void setAssetNumber(String assetNumber) {
        this.assetNumber = assetNumber;
    }

    public String getAssetDescription() {
        return assetDescription;
    }

    public void setAssetDescription(String assetDescription) {
        this.assetDescription = assetDescription;
    }

    public String getWipEntityId() {
        return wipEntityId;
    }

    public void setWipEntityId(String wipEntityId) {
        this.wipEntityId = wipEntityId;
    }

    public String getWono() {
        return wono;
    }

    public void setWono(String wono) {
        this.wono = wono;
    }

    public String getWoDesc() {
        return woDesc;
    }

    public void setWoDesc(String woDesc) {
        this.woDesc = woDesc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    public Date getCreationDate() {
        return creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public Date getReleasedDate() {
        return releasedDate != null ? new Date(releasedDate.getTime()) : null;
    }

    public void setReleasedDate(Date releasedDate) {
        this.releasedDate =  releasedDate != null ? new Date(releasedDate.getTime()) : null;
    }

    public Date getCompletedDate() {
        return completedDate = completedDate != null ? new Date(completedDate.getTime()) : null;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate != null ? new Date(completedDate.getTime()) : null;
    }

    public Date getClosedDate() {
        return closedDate != null ? new Date(closedDate.getTime()):null;
    }

    public void setClosedDate(Date closedDate) {
        this.closedDate = closedDate != null ? new Date(closedDate.getTime()):null;
    }

    public Date getActualStartDate() {
        return actualStartDate != null ? new Date(actualStartDate.getTime()):null;
    }

    public void setActualStartDate(Date actualStartDate) {
        this.actualStartDate =  actualStartDate != null ? new Date(actualStartDate.getTime()):null;
    }

    public Date getScheduledStartDate() {
        return scheduledStartDate != null ? new Date(scheduledStartDate.getTime()):null;
    }

    public void setScheduledStartDate(Date scheduledStartDate) {
        this.scheduledStartDate =  scheduledStartDate != null ? new Date(scheduledStartDate.getTime()):null;
    }

    public Date getScheduledCompletionDate() {
        return scheduledCompletionDate != null ? new Date(scheduledCompletionDate.getTime()) : null ;
    }

    public void setScheduledCompletionDate(Date scheduledCompletionDate) {
        this.scheduledCompletionDate =  scheduledCompletionDate != null ? new Date(scheduledCompletionDate.getTime()) : null;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getMeterReading() {
        return meterReading;
    }

    public void setMeterReading(String meterReading) {
        this.meterReading = meterReading;
    }

    public Date getActualEndDate() {
        return actualEndDate != null ? new Date(actualEndDate.getTime()):null;
    }


    public void setActualEndDate(Date actualEndDate) {
        this.actualEndDate =  actualEndDate != null ? new Date(actualEndDate.getTime()):null;
    }

    public String getWipClass() {
        return wipClass;
    }

    public void setWipClass(String wipClass) {
        this.wipClass = wipClass;
    }

    public String getNextService() {
        return nextService;
    }

    public void setNextService(String nextService) {
        this.nextService = nextService;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getErrorEn() {
        return errorEn;
    }

    public void setErrorEn(String errorEn) {
        this.errorEn = errorEn;
    }

    public String getErrorAR() {
        return errorAR;
    }

    public void setErrorAR(String errorAR) {
        this.errorAR = errorAR;
    }

    public String getWsStatus() {
        return wsStatus;
    }

    public void setWsStatus(String wsStatus) {
        this.wsStatus = wsStatus;
    }

    public String getOperationSeqNum() {
        return operationSeqNum;
    }

    public String getPaymenMethod() {
        return paymenMethod;
    }

    public String getInvoiceLineNumber() {
        return invoiceLineNumber;
    }

    public String getInvoiceTRXNumber() {
        return invoiceTRXNumber;
    }

    public String getItem() {
        return item;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getPrice() {
        return price;
    }

    public Date getWoDate() {
        return woDate != null ? new Date(woDate.getTime()):null;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

    public String getTransactionUUID() {
        return transactionUUID;
    }

    public void setTransactionUUID(String transactionUUID) {
        this.transactionUUID = transactionUUID;
    }

    public Double getFinalAmount() {
        return finalAmount;
    }

    public void setFinalAmount(Double finalAmount) {
        this.finalAmount = finalAmount;
    }

    public String getDiscountInfo() {
        return discountInfo;
    }

    public void setDiscountInfo(String discountInfo) {
        this.discountInfo = discountInfo;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getVoucherReference() {
        return voucherReference;
    }

    public void setVoucherReference(String voucherReference) {
        this.voucherReference = voucherReference;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getStaffNumber() {
        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {
        this.staffNumber = staffNumber;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public static class Builder {
        private Long id;
        private String organizationId;
        private String assetNumber;
        private String assetDescription;
        private String wipEntityId;
        private String wono;
        private String woDesc;
        private String status;
        private String dept;
        private String activity;
        private String activityDesc;
        private Date creationDate;
        private Date releasedDate;
        private Date completedDate;
        private Date closedDate;
        private Date actualStartDate;
        private Date scheduledStartDate;
        private Date scheduledCompletionDate;
        private String createdBy;
        private String meterReading;
        private Date actualEndDate;
        private String wipClass;
        private String nextService;
        private String stationName;
        private String totalAmount;
        private String paymentStatus;
        private String errorEn;
        private String errorAR;
        private String wsStatus;
        private String payStatus;
        private String transactionUUID;
        private Car car;
        private String discountInfo;
        private Double finalAmount;
        private String voucherReference;
        private String customerName;
        private String mobileNumber;
        private String staffNumber;
        private String staffName;
        private String operationSeqNum;
        private String paymenMethod;
        private String invoiceLineNumber;
        private String invoiceTRXNumber;
        private String item;
        private String quantity;
        private String price;
        private Date woDate;
        private String itemDescription;

        public Builder itemDescription(String itemDescription) {
            this.itemDescription = itemDescription;
            return this;
        }

        public Builder woDate(Date woDate) {
            this.woDate =  woDate != null ? new Date(woDate.getTime()):null;
            return this;
        }

        public Builder operationSeqNum(String operationSeqNum) {
            this.operationSeqNum = operationSeqNum;
            return this;
        }

        public Builder paymenMethod(String paymenMethod) {
            this.paymenMethod = paymenMethod;
            return this;
        }

        public Builder invoiceLineNumber(String invoiceLineNumber) {
            this.invoiceLineNumber = invoiceLineNumber;
            return this;
        }

        public Builder invoiceTRXNumber(String invoiceTRXNumber) {
            this.invoiceTRXNumber = invoiceTRXNumber;
            return this;
        }

        public Builder item(String item) {
            this.item = item;
            return this;
        }

        public Builder quantity(String quantity) {
            this.quantity = quantity;
            return this;
        }

        public Builder price(String price) {
            this.price = price;
            return this;
        }

        public Builder customerName(String customerName) {
            this.customerName = customerName;
            return this;
        }

        public Builder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public Builder staffNumber(String staffNumber) {
            this.staffNumber = staffNumber;
            return this;
        }

        public Builder staffName(String staffName) {
            this.staffName = staffName;
            return this;
        }

        public Builder car(Car car) {
            this.car = car;
            return this;
        }

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder organizationId(String organizationId) {
            this.organizationId = organizationId;
            return this;
        }

        public Builder assetNumber(String assetNumber) {
            this.assetNumber = assetNumber;
            return this;
        }

        public Builder assetDescription(String assetDescription) {
            this.assetDescription = assetDescription;
            return this;
        }

        public Builder wipEntityId(String wipEntityId) {
            this.wipEntityId = wipEntityId;
            return this;
        }

        public Builder wono(String wono) {
            this.wono = wono;
            return this;
        }

        public Builder woDesc(String woDesc) {
            this.woDesc = woDesc;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder dept(String dept) {
            this.dept = dept;
            return this;
        }

        public Builder activity(String activity) {
            this.activity = activity;
            return this;
        }

        public Builder activityDesc(String activityDesc) {
            this.activityDesc = activityDesc;
            return this;
        }

        public Builder creationDate(Date creationDate) {
            this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
            return this;
        }

        public Builder releasedDate(Date releasedDate) {
            this.releasedDate = releasedDate != null ? new Date(releasedDate.getTime()) : null;
            return this;
        }

        public Builder completedDate(Date completedDate) {
            this.completedDate = completedDate != null ? new Date(completedDate.getTime()) : null;
            return this;
        }

        public Builder closedDate(Date closedDate) {
            this.closedDate = closedDate != null ? new Date(closedDate.getTime()):null;
            return this;
        }

        public Builder scheduledStartDate(Date scheduledStartDate) {
            this.scheduledStartDate =  scheduledStartDate != null ? new Date(scheduledStartDate.getTime()):null;
            return this;
        }

        public Builder scheduledCompletionDate(Date scheduledCompletionDate) {
            this.scheduledCompletionDate =  scheduledCompletionDate != null ? new Date(scheduledCompletionDate.getTime()) : null;
            return this;
        }

        public Builder actualEndDate(Date actualEndDate) {
            this.actualEndDate =  actualEndDate != null ? new Date(actualEndDate.getTime()):null;
            return this;
        }

        public Builder actualStartDate(Date actualStartDate) {
            this.actualStartDate =  actualStartDate != null ? new Date(actualStartDate.getTime()):null;
            return this;
        }

        public Builder createdBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }

        public Builder meterReading(String meterReading) {
            this.meterReading = meterReading;
            return this;
        }

        public Builder wipClass(String wipClass) {
            this.wipClass = wipClass;
            return this;
        }

        public Builder nextService(String nextService) {
            this.nextService = nextService;
            return this;
        }

        public Builder stationName(String stationName) {
            this.stationName = stationName;
            return this;
        }

        public Builder totalAmount(String totalAmount) {
            this.totalAmount = totalAmount;
            return this;
        }

        public Builder paymentStatus(String paymentStatus) {
            this.paymentStatus = paymentStatus;
            return this;
        }

        public Builder errorEn(String errorEn) {
            this.errorEn = errorEn;
            return this;
        }

        public Builder errorAR(String errorAR) {
            this.errorAR = errorAR;
            return this;
        }

        public Builder wsStatus(String wsStatus) {
            this.wsStatus = wsStatus;
            return this;
        }

        public Builder payStatus(String payStatus) {
            this.payStatus = payStatus;
            return this;
        }

        public Builder transactionUUID(String transactionUUID) {
            this.transactionUUID = transactionUUID;
            return this;
        }

        public Builder discountInfo(String discountInfo) {
            this.discountInfo = discountInfo;
            return this;
        }

        public Builder finalAmount(Double finalAmount) {
            this.finalAmount = finalAmount;
            return this;
        }

        public Builder voucherReference(String voucherReference) {
            this.voucherReference = voucherReference;
            return this;
        }

        public JobCard build() {
            return new JobCard(this);
        }


    }

}
