package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Area;

import java.text.ParseException;
import java.util.List;


public interface AreaDao {

    void saveAll(List<Area> list);

    List<Area> getAreas(String arabicTitle, String title);

    Area findbyId(String id);

    Page<Area> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException;

    void save(Area area);

    void saveBO(Area area);

    void update(Area area);

    Area findAreaById(Long id);

    void checkArea(String areaNameAr, String areaNameEn);

    Long count();
}
