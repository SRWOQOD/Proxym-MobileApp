package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.PaymentMethodEnum;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = Constants.TABLE_TRANSACTION_TAG)
@NoArgsConstructor
@AllArgsConstructor
public class TagTransaction {

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    protected Date lastModifiedDate;

    private String transactionId;
    @Id
    @GeneratedValue
    private Long id;
    private String qid;

    //plate id = 1
    private String plateNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(unique = true)
    private String transactionUUID;
    private String email;

    private String mobile;

    private Double totalAmount;

    private String description;

    private TransactionStatusEnum transactionStatus;

    private PaymentMethodEnum paymentMethod;

    private String receiptUrl;

    private String RPSStatus;

    private String authReversal;

    private String authReversalStatus;


}
