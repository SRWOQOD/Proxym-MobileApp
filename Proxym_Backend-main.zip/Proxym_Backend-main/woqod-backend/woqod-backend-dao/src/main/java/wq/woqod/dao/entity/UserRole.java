package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by bfitouri on 14/11/16.
 */
@Entity
@Table(name = Constants.TABLE_USER_ROLE)
public class UserRole implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    private Role role;

    public UserRole() {
    }

    private UserRole(Builder builder) {
        this.id = builder.id;
        this.user = builder.user;
        this.role = builder.role;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("id", id).add("user", user).add("role", role).toString();
    }

    public static class Builder {

        private Long id;
        private User user;
        private Role role;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder user(User user) {
            this.user = user;
            return this;
        }

        public Builder role(Role role) {
            this.role = role;
            return this;
        }

        public UserRole build() {
            return new UserRole(this);
        }

    }
}
