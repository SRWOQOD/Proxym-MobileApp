package wq.woqod.dao.repository;

import com.querydsl.core.types.dsl.StringPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.repository.query.Param;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.dao.entity.FeedbackProjection;

import java.util.List;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 11/30/2016.
 */
public interface FeedbackRepository extends JpaRepository<Feedback, Long>, QuerydslPredicateExecutor<Feedback> {

    Optional<Feedback> findById(Long id);


    @Query(value = "select * from Feedback where id = ?1 and status = 1", nativeQuery = true)
    Optional<Feedback> findByIdAndActiveStatus(Long id);

    Feedback getByTicketNumber(String ticket);
}
