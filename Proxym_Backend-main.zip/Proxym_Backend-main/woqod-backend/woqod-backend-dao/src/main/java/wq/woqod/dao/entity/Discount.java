package wq.woqod.dao.entity;


import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.enumerations.PaymentTypeEnum;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by Hassen.Ellouze on 15/11/2018.
 */
@Entity
@Table(name = Constants.TABLE_DISCOUNT)
public class Discount {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Double amount;
    private boolean status;
    @Column(name = "minAmount")
    private Double min;

    @Column(name = "maxAmount")
    private Double max;

    @Enumerated(EnumType.STRING)

    @Column(name = "fahesService")
    private FahesServiceEnum fahesServiceEnum;

    @Enumerated(EnumType.STRING)
    @Column(name = "paymentMethod")
    private PaymentMethodEnum paymentMethodEnum;

    @Enumerated(EnumType.STRING)
    @Column(name = "paymentType")
    private PaymentTypeEnum paymentTypeEnum;

    @Column(name = "creation_date")
    private Date creationDate;

    public Discount() {
    }

    public Discount(Builder builder) {
        this.id = builder.id;
        this.amount = builder.amount;
        this.status = builder.status;
        this.fahesServiceEnum = builder.fahesServiceEnum;
        this.paymentMethodEnum = builder.paymentMethodEnum;
        this.paymentTypeEnum = builder.paymentTypeEnum;
        this.max = builder.max;
        this.min = builder.min;
        this.creationDate = builder.creationDate;

    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public Double getAmount() {
        return amount;
    }

    public boolean isStatus() {
        return status;
    }

    public FahesServiceEnum getFahesServiceEnum() {
        return fahesServiceEnum;
    }

    public Double getMin() {
        return min;
    }

    public Double getMax() {
        return max;
    }

    public PaymentMethodEnum getPaymentMethodEnum() {
        return paymentMethodEnum;
    }

    public Date getCreationDate() {
        return creationDate != null ? new Date(creationDate.getTime()) : null;
    }

    public PaymentTypeEnum getPaymentTypeEnum() {
        return paymentTypeEnum;
    }

    public static class Builder {

        private Long id;
        private Double amount;
        private boolean status;

        private FahesServiceEnum fahesServiceEnum;
        private PaymentMethodEnum paymentMethodEnum;
        private PaymentTypeEnum paymentTypeEnum;
        private Double min;
        private Double max;
        private Date creationDate;

        public Builder creationDate(Date creationDate) {
            this.creationDate = creationDate != null ? new Date(creationDate.getTime()) : null;
            return this;
        }

        public Builder min(Double min) {
            this.min = min;
            return this;
        }

        public Builder max(Double max) {
            this.max = max;
            return this;
        }

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder amount(Double amount) {
            this.amount = amount;
            return this;
        }

        public Builder status(boolean status) {
            this.status = status;
            return this;
        }

        public Builder fahesService(FahesServiceEnum fahesServiceEnum) {
            this.fahesServiceEnum = fahesServiceEnum;
            return this;
        }

        public Builder paymentMethod(PaymentMethodEnum paymentMethodEnum) {
            this.paymentMethodEnum = paymentMethodEnum;
            return this;
        }

        public Builder paymentType(PaymentTypeEnum paymentTypeEnum) {
            this.paymentTypeEnum = paymentTypeEnum;
            return this;
        }

        public Discount build() {
            return new Discount(this);
        }
    }


}
