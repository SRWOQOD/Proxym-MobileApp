package wq.woqod.dao.repository;


import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import wq.woqod.dao.entity.Discount;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;


/**
 * Created by Hassen.Ellouze on 15/11/2018.
 */
public interface DiscountRepository extends JpaRepository<Discount, Long>, QuerydslPredicateExecutor<Discount> {


    Discount getDiscountByFahesServiceEnumAndPaymentMethodEnum(FahesServiceEnum fahesService, PaymentMethodEnum paymentMethod);


    @Query(value = "SELECT * FROM DISCOUNT  WHERE  (DISCOUNT.MIN_AMOUNT <= :amount ) AND (DISCOUNT.MAX_AMOUNT>= :amount)AND (FAHES_SERVICE = :fahesService) AND (PAYMENT_METHOD = :paymentMethod) AND (status=1)", nativeQuery = true)
    Discount getDiscountByFahesServiceEnumAndPaymentMethodEnumAndAmount(@Param("fahesService") String fahesService, @Param("paymentMethod") String paymentMethod, @Param("amount") Double amount);

    @Query(value = "SELECT d from Discount d  WHERE  (d.min <= :amount ) AND (d.max >= :amount) ")
    Discount getDiscountByAmount(@Param("amount") Double amount);

    Page<Discount> findAllByOrderByCreationDateDesc(Predicate predicate, Pageable pageable);
}
