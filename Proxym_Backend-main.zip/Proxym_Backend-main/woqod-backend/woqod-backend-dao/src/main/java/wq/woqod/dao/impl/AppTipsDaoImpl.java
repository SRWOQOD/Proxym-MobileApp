package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.AppTipsDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.AppTips;
import wq.woqod.dao.entity.QAppTips;
import wq.woqod.dao.repository.AppTipsRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Component
public class AppTipsDaoImpl implements AppTipsDao {

    private final AppTipsRepository appTipsRepository;
    private static final String DATE_FROM = "dateFrom";
    private static final String DATE_TO = "dateTo";

    @Autowired
    public AppTipsDaoImpl(AppTipsRepository appTipsRepository) {
        this.appTipsRepository = appTipsRepository;
    }


    @Override
    public void save(AppTips appTips) {
        AppTips old = appTips.getId() != null ? getById(appTips.getId()) : null;
        if (old == null) {
            Long orderItem = NumberUtils.LONG_ONE;
            Long numberOgTopBannerItems = appTipsRepository.count();

            if(!NumberUtils.LONG_ZERO.equals(numberOgTopBannerItems)) {
                AppTips lastElement = appTipsRepository.findTopByOrderByOrderItemDesc().orElse(null);
                if(!Objects.isNull(lastElement) && lastElement.getOrderItem() != null) {
                    orderItem = lastElement.getOrderItem() + 1;
                } else {
                    orderItem = numberOgTopBannerItems + 1;
                }
            }
            appTips.setOrderItem(orderItem);
            appTipsRepository.save(appTips);
        } else {
            appTips.setOrderItem(old.getOrderItem());
            update(appTips);
        }
    }


    @Override
    public List<AppTips> filter(MultiValueMap<String, String> parameters) {
        Predicate active = null;
        Predicate date = null;
        Predicate title = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        QAppTips qAppTips = QAppTips.appTips;
        if (parameters.get("active") != null) {
            active = qAppTips.active.eq(Boolean.valueOf(parameters.getFirst("active")));
        }

        if (parameters.get(FilterConstants.TITLE) != null) {
            title = qAppTips.title.containsIgnoreCase(parameters.getFirst("title"));
        }

        if (parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) != null) {
            date = qAppTips.creationDate.between((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)), (LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        } else if(parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) == null) {
            date = qAppTips.creationDate.after((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)));
        } else if (parameters.get(DATE_TO) != null && parameters.get(DATE_FROM) == null) {
            date = qAppTips.creationDate.before((LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        }
        Predicate predicateAdsBanner = qAppTips.isNotNull()
                .and(active).and(title).and(date);
        return (List<AppTips>) appTipsRepository.findAll(predicateAdsBanner);
    }

    @Override
    public AppTips getById(Long valueOf) {
        return appTipsRepository.getOne(valueOf);
    }

    @Override
    public void update(List<AppTips> list) {
        appTipsRepository.saveAll(list);
    }

    @Override
    public void update(AppTips appTips) {
        appTipsRepository.save(appTips);
    }

    @Override
    public List<AppTips> getAppTips() {

        return appTipsRepository.findAllByActive(true);
    }

    @Override
    public Long count() {
        return appTipsRepository.count();
    }

    @Override
    public void delete(Long id) {
        appTipsRepository.deleteById(id);
    }
}
