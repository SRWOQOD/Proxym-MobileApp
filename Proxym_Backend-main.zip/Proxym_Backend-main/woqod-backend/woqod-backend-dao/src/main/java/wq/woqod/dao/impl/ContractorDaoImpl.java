package wq.woqod.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.dao.ContractorDao;
import wq.woqod.dao.entity.Contractor;
import wq.woqod.dao.repository.ContractorRepository;

import java.util.List;

@Component
@Transactional
public class ContractorDaoImpl implements ContractorDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContractorDaoImpl.class);
    private final ContractorRepository contractorRepository;

    @Autowired
    public ContractorDaoImpl(ContractorRepository contractorRepository) {
        this.contractorRepository = contractorRepository;
    }


    @Override
    public List<Contractor> getAllContractors() {
        return contractorRepository.findAll();
    }
}