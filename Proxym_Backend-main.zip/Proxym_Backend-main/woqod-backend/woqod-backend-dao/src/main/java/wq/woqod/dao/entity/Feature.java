package wq.woqod.dao.entity;


import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 11/15/2016.
 */
@Entity
@Table(name = Constants.TABLE_FEATURE)
public class Feature implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String designation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "module_id")
    private Module module;

    public Feature() {
    }

    public Feature(String designation) {
        this.designation = designation;
    }

    public Feature(Long id) {
        this.id = id;
    }

    public Feature(Long id, String designation) {
        this.designation = designation;
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}
