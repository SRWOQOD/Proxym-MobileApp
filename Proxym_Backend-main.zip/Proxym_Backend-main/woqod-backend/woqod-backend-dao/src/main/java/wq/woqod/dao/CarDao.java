package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Created by med-taher.ben-torkia on 06/12/2016.
 */
public interface CarDao {

    List<Car> getActiveCarByPlateNumberAndQidAndPlateType(String plateNumber, String qid, String plateType);
    Car getActiveCarByPlateNumberAndQidAndPlateTypeID(String plateNumber, String qid, String plateType);
    Car save(Car car);

    void save(List<Car> car);

    Car getActiveCarByPlateNumber(String plateNumber, String plateId);

    void updateStatus(String plate_number, String qid);

    Page<Car> getFiltredCars(Pageable pageable, MultiValueMap<String, String> parameters);

    Optional<Car> getCarByid(Long id);

    List<Car> getActiveCarByPlateNumberAndOwnerAndPlateType(String plateNumber, User owner, String plateType);

    List<Car> getCarByPlateNumberAndQidAndPlateType(String plateNumber, String qid, String plateType);

    List<Car> getCarsByUserId(Long id);

    Car getActiveCarByPlateNumberAndQid(String plateNumber, String qid);

    List<Car> findCarsByRegExpirationDate(LocalDate date);

    List<Car> getListCarByStatus(boolean active);

    List<Car> getCars(MultiValueMap<String, String> parameters);

    Page<Car> all(Pageable pageable);

    void delete(Car car);

    Long count();
}
