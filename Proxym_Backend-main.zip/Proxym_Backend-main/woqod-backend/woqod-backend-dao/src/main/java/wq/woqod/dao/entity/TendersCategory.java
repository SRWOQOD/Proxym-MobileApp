package wq.woqod.dao.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

/**
 * Created by bfitouri on 14/11/16.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = Constants.TABLE_TENDERS_CAT)
public class TendersCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(name = "description")
    private String description;

    @Column(name = "category_id")
    private String categoryId;


}
