package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * Created by med-taher.ben-torkia on 06/12/2016.
 */
@Entity
@Table(name = Constants.TABLE_CAR)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "vin")
    private String vin;

    @Column(name = "plate_number")
    private String plateNumber;

    @Column(name = "year")
    private String year;

    @Column(name = "active")
    private boolean active;

    @Column(name = "creation_date")
    private Date creationDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "plate_type_id")
    private PlateType plateType;

    @Column
    private String transactionLimit;

    @Column
    private String transactionType;

    @Column
    private String ownerMobile;

    @Column
    private Boolean fuelStatus;

    @Column
    private String fuelType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "manufacturer_id")
    private Manufacturer manufacturer;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "model_id")
    private Model model;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "colour_id")
    private Colour colour;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User owner;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "registration_expires_on")
    private LocalDate regExpirationDate;

    //@Column(name = "ownerQid")
    @Column(name = "encrypted_qid")
    private String ownerQid;

    @OneToMany(mappedBy = "car", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<PreRegistration> preRegistrations;

    @OneToMany(mappedBy = "car", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<JobCard> jobCards;


}
