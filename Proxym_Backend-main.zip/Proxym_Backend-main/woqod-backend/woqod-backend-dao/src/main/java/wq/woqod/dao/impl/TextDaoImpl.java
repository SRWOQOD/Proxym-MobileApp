package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wq.woqod.dao.TextDao;
import wq.woqod.dao.entity.Text;
import wq.woqod.dao.repository.TextRepository;
import wq.woqod.resources.enumerations.TextType;

import javax.annotation.PostConstruct;
import java.util.List;

@Slf4j
@Component
public class TextDaoImpl implements TextDao {
    private final TextRepository textRepository;

    @Autowired
    public TextDaoImpl(TextRepository textRepository) {
        this.textRepository = textRepository;
    }

    @PostConstruct
    public void init() {
        if(textRepository.getByTextType(TextType.TERMS_OF_USE)==null){
            textRepository.save(new Text(1L, TextType.TERMS_OF_USE, "",""));
        }
        if(textRepository.getByTextType(TextType.WOQODE_TERMS_AND_CONDITIONS)==null){
            textRepository.save(new Text(1L, TextType.WOQODE_TERMS_AND_CONDITIONS, "",""));
        }
        if(textRepository.getByTextType(TextType.ABOUT_US)==null){
            textRepository.save(new Text(1L, TextType.ABOUT_US, "",""));
        }
        if(textRepository.getByTextType(TextType.BUKLPG)==null){
            textRepository.save(new Text(1L, TextType.BUKLPG, "",""));
        }
        if(textRepository.getByTextType(TextType.ABOUT_FAHES)==null){
            textRepository.save(new Text(1L, TextType.ABOUT_FAHES, "",""));
        }
        if(textRepository.getByTextType(TextType.ABOUT_SHAHAF)==null){
            textRepository.save(new Text(1L, TextType.ABOUT_SHAHAF, "",""));
        }
        if(textRepository.getByTextType(TextType.INSCRIPTION_TIPS)==null){
            textRepository.save(new Text(1L, TextType.INSCRIPTION_TIPS, "",""));
        }
        if(textRepository.getByTextType(TextType.PRIVACY_POLICY)==null){
            textRepository.save(new Text(1L, TextType.PRIVACY_POLICY, "",""));
        }
        if(textRepository.getByTextType(TextType.ABOUT_WOQUOD)==null){
            textRepository.save(new Text(1L, TextType.ABOUT_WOQUOD, "",""));
        }
        if(textRepository.getByTextType(TextType.TERMS_AND_CONDITIONS_PAYMENT_FAHES)==null){
            textRepository.save(new Text(1L, TextType.TERMS_AND_CONDITIONS_PAYMENT_FAHES, "",""));
        }
        /*if(textRepository.getByTextType(TextType.TERMS_AND_CONDITIONS_PAYMENT_WOQOD)==null){
            textRepository.save(new Text(1L, TextType.TERMS_AND_CONDITIONS_PAYMENT_WOQOD, "",""));
        }*/
    }


    @Override
    public void update(List<Text> list) {
        textRepository.saveAll(list);
    }

    @Override
    public Text getByTextType(TextType textType) {
        return textRepository.getByTextType(textType);
    }

    @Override
    public List<Text> getTexts() {
        return textRepository.findAll();
    }

    @Override
    public void update(TextType textType, Text text) {
        Text textToUpdate = textRepository.getByTextType(textType);
        textRepository.saveAndFlush(textToUpdate);
    }

}
