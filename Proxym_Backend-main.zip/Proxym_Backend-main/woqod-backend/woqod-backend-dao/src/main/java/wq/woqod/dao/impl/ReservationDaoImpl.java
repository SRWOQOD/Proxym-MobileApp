package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.ReservationDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QReservations;
import wq.woqod.dao.entity.Reservations;
import wq.woqod.dao.repository.ReservationRepository;
import wq.woqod.resources.enumerations.ReservationEnum;

import java.time.LocalDateTime;
import java.util.*;

@Component
@Slf4j
public class ReservationDaoImpl implements ReservationDao {

    private final ReservationRepository reservationRepository;
    private static final String STATUS_PARAM = "status";
    private static final String MOBILE_NUMBER_PARAM = "mobileNumber";
    private static final String LICENCE_PLATE_PARAM = "licencePlate";

    @Autowired
    public ReservationDaoImpl(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    @Override
    public Reservations save(Reservations reservations) {
        return reservationRepository.save(reservations);
    }

    @Override
    public Reservations findByReservationId(String reservationId) {
        return reservationRepository.findByReservationId(reservationId);
    }

    @Override
    public Page<Reservations> filter(Pageable pageable, Map<String, String> parameters) {
        Predicate status = null;
        Predicate qid = null;
        Predicate mobileNumber = null;
        Predicate licencePlate = null;
        Predicate startDate = null;
        Predicate endDate = null;

        QReservations qReservations = QReservations.reservations;
        if (parameters.get(STATUS_PARAM) != null) {
            status = qReservations.status.eq(ReservationEnum.valueOf(parameters.get(STATUS_PARAM)));
        }

        if (parameters.get("qid") != null) {
            qid = qReservations.qid.eq(String.valueOf(parameters.get("qid")));
        }
        if (parameters.get(MOBILE_NUMBER_PARAM) != null) {
            mobileNumber = qReservations.mobileNumber.eq(String.valueOf(parameters.get(MOBILE_NUMBER_PARAM)));
        }
        if (parameters.get(LICENCE_PLATE_PARAM) != null) {
            licencePlate = qReservations.licencePlate.eq(String.valueOf(parameters.get(LICENCE_PLATE_PARAM)));
        }
        if (parameters.get(FilterConstants.START_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.get(FilterConstants.START_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qReservations.creationDate.after(DateFormatter.localDateTimeToDate(date1));
        }

        if (parameters.get(FilterConstants.END_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.get(FilterConstants.END_DATE))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qReservations.creationDate.before(DateFormatter.localDateTimeToDate(date2));
        }
        Predicate predicate = qReservations.isNotNull()
                .and(licencePlate)
                .and(mobileNumber).and(qid).and(status).and(startDate).and(endDate);

        return reservationRepository.findAll(predicate, pageable);
    }

    @Override
    public List<Reservations> getReservations(MultiValueMap<String, String> params) {
        Predicate status = null;
        Predicate qid = null;
        Predicate mobileNumber = null;
        Predicate licencePlate = null;

        QReservations qReservations = QReservations.reservations;
        if (params.get(STATUS_PARAM) != null) {
            status = qReservations.status.eq(ReservationEnum.valueOf((params.getFirst(FilterConstants.STATUS))));
        }
        if (params.get("qid") != null && !params.get("qid").isEmpty()) {
            qid = qReservations.qid.containsIgnoreCase(params.getFirst("qid"));
        }
        if (params.get(MOBILE_NUMBER_PARAM) != null && !params.get(MOBILE_NUMBER_PARAM).isEmpty()) {
            mobileNumber = qReservations.mobileNumber.containsIgnoreCase(params.getFirst(MOBILE_NUMBER_PARAM));
        }
        if (params.get(LICENCE_PLATE_PARAM) != null && !params.get(LICENCE_PLATE_PARAM).isEmpty()) {
            licencePlate = qReservations.licencePlate.containsIgnoreCase(params.getFirst(LICENCE_PLATE_PARAM));
        }

        Predicate predicate = qReservations.isNotNull()
                .and(licencePlate)
                .and(mobileNumber).and(qid).and(status);

        return (List<Reservations>) reservationRepository.findAll(predicate);
    }

    @Override
    public Page<Reservations> all(Pageable pageable) {
        return reservationRepository.findAll(pageable);
    }

    @Override
    public List<Reservations> saveAll(List<Reservations> reservations) {
        try {
            return reservationRepository.saveAll(reservations);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("reservation", ex);
        }
    }


    @Override
    public Long count() {
        return reservationRepository.count();
    }

}
