package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.TendersDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QTenders;
import wq.woqod.dao.entity.Tenders;
import wq.woqod.dao.repository.TendersRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;


@Slf4j
@Component
public class TendersDaoImpl implements TendersDao {


    private final TendersRepository tendersRepository;

    public TendersDaoImpl(TendersRepository tendersRepository) {
        this.tendersRepository = tendersRepository;
    }

    @Override
    public Page<Tenders> getFiltredTenders(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qcategory = null;
        Predicate qdescription = null;
        Predicate qcollectionDate = null;
        Predicate qbond = null;
        Predicate qTenderNumber = null;
        Predicate qCollectionDateFrom = null;
        Predicate qCollectionDateTo = null;
        Predicate qClosingDateFrom = null;
        Predicate qClosingDateTo = null;

        QTenders qTenders = QTenders.tenders;
        qTenderNumber = qTenders.tenderNumber.isNotNull();

        if (parameters.get(FilterConstants.CATEGORY_ENUM) != null) {
            qcategory = qTenders.categoryEnum.eq(parameters.getFirst(FilterConstants.CATEGORY_ENUM));
        }

        if (parameters.get(FilterConstants.BOND) != null) {
            qbond = qTenders.bond.containsIgnoreCase(parameters.getFirst(FilterConstants.BOND));
        }

        if (parameters.get(FilterConstants.DESCRIPTION) != null) {
            qdescription = qTenders.description.containsIgnoreCase(parameters.getFirst(FilterConstants.DESCRIPTION));
        }

        if (parameters.get("active") != null) {
            if (parameters.getFirst("active").equalsIgnoreCase("true")) {
                LocalDateTime today = LocalDateTime.now();
                qcollectionDate = qTenders.collectionDate.after(today);
            }
        }

        if (parameters.get(FilterConstants.COLLECTON_DATE) != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime dateTimeStart = LocalDate.parse(parameters.getFirst(FilterConstants.COLLECTON_DATE), formatter).atStartOfDay();
            LocalDateTime dateTimeEnd = LocalDate.parse(parameters.getFirst(FilterConstants.COLLECTON_DATE), formatter).atTime(LocalTime.MAX);
            qcollectionDate = qTenders.collectionDate.between(dateTimeStart, dateTimeEnd);
        }

        if (parameters.get(FilterConstants.COLLECTON_DATE_FROM) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.getFirst(FilterConstants.COLLECTON_DATE_FROM))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            qCollectionDateFrom = qTenders.collectionDate.after(date1.minusDays(1));
        }

        if (parameters.get(FilterConstants.COLLECTON_DATE_TO) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.getFirst(FilterConstants.COLLECTON_DATE_TO))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            qCollectionDateTo = qTenders.collectionDate.before(date2);
        }

        if (parameters.get(FilterConstants.CLOSING_DATE_FROM) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.getFirst(FilterConstants.CLOSING_DATE_FROM))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            qClosingDateFrom = qTenders.closingDate.after(date1);
        }

        if (parameters.get(FilterConstants.CLOSING_DATE_TO) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(Objects.requireNonNull(DateFormatter.stringlDateToLcalDateTim(parameters.getFirst(FilterConstants.CLOSING_DATE_TO))));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            qClosingDateTo = qTenders.closingDate.before(date2);
        }

        Predicate predicateTransaction = qTenders.isNotNull()
                .and(qcategory)
                .and(qdescription)
                .and(qTenderNumber)
                .and(qbond)
                .and(qCollectionDateFrom)
                .and(qCollectionDateTo)
                .and(qClosingDateFrom)
                .and(qClosingDateTo)
                .and(qcollectionDate);
        return tendersRepository.findAll(predicateTransaction, pageable);
    }

    @Override
    public void createTenders(List<Tenders> tendersResources) {
        tendersRepository.deleteAll();
        tendersRepository.flush();
        tendersRepository.saveAll(tendersResources);
    }

    @Override
    public Page<Tenders> getTenders(Pageable pageable) {
        LocalDateTime today = LocalDateTime.now();
        return tendersRepository.findAllByClosingDateAfter(today, pageable);
    }

    @Override
    public Page<Tenders> getAllTenders(MultiValueMap<String, String> parameters, Pageable pageable) {

        Predicate qcategory = null;
        Predicate qdescription = null;
        Predicate qcollectionDate = null;
        Predicate qbond = null;
        Predicate qTenderNumber;


        QTenders qTenders = QTenders.tenders;
        qTenderNumber = qTenders.tenderNumber.isNotNull();

        if (parameters.get(FilterConstants.CATEGORY_ENUM) != null) {
            qcategory = qTenders.categoryEnum.contains(parameters.getFirst(FilterConstants.CATEGORY_ENUM));
        }


        if (parameters.get(FilterConstants.BOND) != null) {
            qbond = qTenders.bond.containsIgnoreCase(parameters.getFirst(FilterConstants.BOND));
        }

        if (parameters.get(FilterConstants.DESCRIPTION) != null) {
            qdescription = qTenders.description.containsIgnoreCase(parameters.getFirst(FilterConstants.DESCRIPTION));
        }

        if (parameters.get(FilterConstants.COLLECTON_DATE) != null) {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime dateTimeStart = LocalDate.parse(parameters.getFirst(FilterConstants.COLLECTON_DATE), formatter).atStartOfDay();
            LocalDateTime dateTimeEnd = LocalDate.parse(parameters.getFirst(FilterConstants.COLLECTON_DATE), formatter).atTime(LocalTime.MAX);
            qcollectionDate = qTenders.collectionDate.between(dateTimeStart, dateTimeEnd);
        }

        Predicate predicateTransaction = qTenders.isNotNull()
                .and(qcategory)
                .and(qdescription)
                .and(qTenderNumber)
                .and(qbond)
                .and(qcollectionDate);

        return (Page<Tenders>) tendersRepository.findAll(predicateTransaction, pageable);
    }

    @Override
    public Page<Tenders> getPaginatedTenders(Pageable pageable) {
        QTenders qTenders = QTenders.tenders;
        Predicate predicate = qTenders.isNotNull();
        return tendersRepository.findAll(predicate, pageable);
    }
}
