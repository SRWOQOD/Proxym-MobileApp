package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Company;

import java.util.Optional;

/**
 * Created by ameni on 24/11/16.
 */
public interface CompanyRepository extends JpaRepository<Company, Long> {

    Optional<Company> findOneByCompanyId(String companyId);
}
