package wq.woqod.dao.entity;

import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 11/17/2016.
 */
@Entity
public class WoqodEmployee extends User implements Serializable {

    private String departement;

    public WoqodEmployee() {
    }

    public WoqodEmployee(Builder builder) {
        super(builder);
        this.departement = builder.departement;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public static class Builder extends User.Builder<Builder> {

        private String departement;

        public Builder departement(String departement) {
            this.departement = departement;
            return this;
        }

        public Builder getThis() {
            return this;
        }

        public WoqodEmployee build() {
            return new WoqodEmployee(this);
        }
    }
}
