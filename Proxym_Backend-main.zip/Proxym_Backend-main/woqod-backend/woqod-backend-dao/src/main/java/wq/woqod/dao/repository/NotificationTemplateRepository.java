package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import wq.woqod.dao.entity.NotificationTemplate;

/**
 * Created by Created by med-amine.dahmen 14/10/2020
 */
public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate, Long>, QuerydslPredicateExecutor<NotificationTemplate> {

}
