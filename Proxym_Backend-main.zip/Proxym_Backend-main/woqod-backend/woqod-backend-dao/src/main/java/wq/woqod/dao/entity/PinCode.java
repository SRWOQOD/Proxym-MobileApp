package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by Hassen.Ellouze on 04/02/2019.
 */
@Entity
@Table(name = Constants.TABLE_PINCODE)
public class PinCode {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String pincode;

    @Column(name = "username", unique = true)
    private String username;

    private LocalDateTime creationDate;

    private int wrongAttempt;

    private boolean used;


    public PinCode() {
    }

    public PinCode(Builder builder) {
        this.id = builder.id;
        this.username = builder.userName;
        this.pincode = builder.pincode;
        this.creationDate = builder.creationDate;
        this.wrongAttempt = builder.wrongAttempt;
        this.used = builder.used;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public String getPincode() {
        return pincode;
    }

    public String getUsername() {
        return username;
    }

    public int getWrongAttempt() {
        return wrongAttempt;
    }

    public boolean isUsed() {
        return used;
    }

    public void setUsed(boolean used) {
        this.used = used;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public static class Builder {

        private Long id;
        private String pincode;
        private String userName;
        private LocalDateTime creationDate;
        private int wrongAttempt;
        private boolean used;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder pincode(String pincode) {
            this.pincode = pincode;
            return this;
        }

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Builder creationDate(LocalDateTime creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public Builder wrongAttempt(int wrongAttempt) {
            this.wrongAttempt = wrongAttempt;
            return this;
        }

        public Builder isUsed(boolean used) {
            this.used = used;
            return this;
        }


        public PinCode build() {
            return new PinCode(this);
        }
    }
}
