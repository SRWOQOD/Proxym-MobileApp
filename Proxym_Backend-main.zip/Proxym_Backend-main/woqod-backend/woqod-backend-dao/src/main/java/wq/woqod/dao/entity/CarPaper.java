package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = Constants.TABLE_CAR_PAPER)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CarPaper {

    @Id
    @GeneratedValue
    private Integer id;

    private String side1;

    private String side2;
}
