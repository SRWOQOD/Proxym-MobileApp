package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 08/02/2019.
 */
@Entity
@Table(name = Constants.TABLE_CATEGORY)
@Data
@Builder
@AllArgsConstructor
public class CarCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "category_id")
    private String categoryId;

    @Column(name = "name_en")
    private String nameEn;

    @Column(name = "name_ar")
    private String nameAr;

    @Column(name = "fee")
    private Double fee;

    @OneToMany(mappedBy = "carCategory", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PreRegistration> preRegistrations;


    public CarCategory() {
    }

    public CarCategory(Builder builder) {
        this.id = builder.id;
        this.categoryId = builder.categoryId;
        this.nameEn = builder.nameEn;
        this.nameAr = builder.nameAr;
        this.fee = builder.fee;
        this.preRegistrations = builder.preRegistrations;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public List<PreRegistration> getPreRegistrations() {
        return preRegistrations;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public Long getId() {
        return id;
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameAr() {
        return nameAr;
    }

    public Double getFee() {
        return fee;
    }

    public static class Builder {
        private Long id;
        private String categoryId;
        private String nameEn;
        private String nameAr;
        private Double fee;
        private List<PreRegistration> preRegistrations;

        public Builder preRegistrations(List<PreRegistration> preRegistrations) {
            this.preRegistrations = preRegistrations;
            return this;
        }

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder categoryId(String categoryId) {
            this.categoryId = categoryId;
            return this;
        }

        public Builder nameEn(String nameEn) {
            this.nameEn = nameEn;
            return this;
        }

        public Builder nameAr(String nameAr) {
            this.nameAr = nameAr;
            return this;
        }

        public Builder fee(Double fee) {
            this.fee = fee;
            return this;
        }

        public CarCategory build() {
            return new CarCategory(this);
        }
    }
}
