package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.exception.DataNotFoundException;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.PRTransactionLogDao;
import wq.woqod.dao.PreRegistrationDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.PRTransactionLog;
import wq.woqod.dao.entity.PreRegistration;
import wq.woqod.dao.entity.QPRTransactionLog;
import wq.woqod.dao.repository.FahesQpayTransactionRepository;
import wq.woqod.dao.repository.PRTransactionRepository;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class PRTransactionLogDaoImpl implements PRTransactionLogDao {

    private final PRTransactionRepository transactionRepository;
    private final FahesQpayTransactionRepository fahesQpayTransactionRepository;
    private final PreRegistrationDao preRegistrationDao;

    @Value("${fahes.number.of.minutes}")
    private long numberOfMinutes;

    @Autowired
    public PRTransactionLogDaoImpl(PRTransactionRepository transactionRepository, FahesQpayTransactionRepository fahesQpayTransactionRepository, PreRegistrationDao preRegistrationDao) {
        this.transactionRepository = transactionRepository;
        this.fahesQpayTransactionRepository = fahesQpayTransactionRepository;
        this.preRegistrationDao = preRegistrationDao;
    }

    @Override
    public void createTransactionLog(PRTransactionLog transactionLog, String plateNumber) {
        try {
            this.transactionRepository.save(transactionLog);
        } catch (Exception ex) {
            log.error("Problem when persisting transactionLog entity..", ex);
            throw new PersistingDataException("transactionLog", ex);
        }

    }

    @Override
    public PRTransactionLog findByTransactionUUID(String TransactionUUID) {
        Optional<PRTransactionLog> transaction = transactionRepository.findByTransactionUUID(TransactionUUID);
        log.info("[TransactionLogDaoImpl] find, transactionUUID {}", TransactionUUID);
        return transaction.orElseThrow(() -> new DataNotFoundException("Transaction", String.valueOf(TransactionUUID), "transaction"));
    }

    @Override
    public PRTransactionLog update(PRTransactionLog transactionLog) {
        log.info("[TransactionLogDaoImpl] update, transactionUUID {} AuthReversalStatus => {}", transactionLog.getTransactionUUID(), transactionLog.getAuthReversalStatus());
        return this.transactionRepository.saveAndFlush(transactionLog);
    }

    @Override
    public List<PRTransactionLog> findAll(MultiValueMap<String, String> params) {
        Predicate transactionUUID = null;
        Predicate referenceNumber = null;
        Predicate transactionStatus = null;
        Predicate userID = null;
        Predicate qid = null;
        Predicate mobile = null;
        Predicate amount = null;
        Predicate currency = null;
        Predicate paymentMethod = null;
        Predicate apiStatus = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate authReversal = null;
        Predicate description = null;
        Predicate rpsStatus = null;
        Predicate startDate = null;
        Predicate endDate = null;

        QPRTransactionLog qprTransactionLog = QPRTransactionLog.pRTransactionLog;

        if (params.get("qid") != null) {
            qid = qprTransactionLog.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.AMOUNT) != null) {
            String searchAmount = "%" + Double.valueOf(params.getFirst(FilterConstants.AMOUNT)) + "%";
            amount = qprTransactionLog.amount.like(searchAmount);
        }

        if (params.get(FilterConstants.CONRRENCY) != null) {
            currency = qprTransactionLog.currency.containsIgnoreCase(params.getFirst(FilterConstants.CONRRENCY));
        }

        if (params.get(FilterConstants.PAYMENT_METHOD) != null) {
            paymentMethod = qprTransactionLog.paymentMethod.eq(PaymentMethodEnum.valueOf(params.getFirst(FilterConstants.PAYMENT_METHOD)));
        }


        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qprTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.API_STATUS) != null) {
            apiStatus = qprTransactionLog.apiStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.API_STATUS)));
        }


        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qprTransactionLog.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.TRANSACTION_UUID) != null) {
            transactionUUID = qprTransactionLog.transactionUUID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_UUID));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qprTransactionLog.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }


        if (params.get(FilterConstants.CREATED_DATE) != null) {
            try {
                createdDate = qprTransactionLog.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
            } catch (ParseException ignored) {
            }
        }

        if (params.get((FilterConstants.TRANSACTION_ID)) != null) {
            transactionID = qprTransactionLog.transactionID.containsIgnoreCase(params.getFirst((FilterConstants.TRANSACTION_ID)));
        }

        if (params.get(FilterConstants.DESCRIPTION) != null) {
            description = qprTransactionLog.description.containsIgnoreCase(params.getFirst(FilterConstants.DESCRIPTION));
        }

        if (params.get(FilterConstants.AUTH_RESERVAL) != null) {
            authReversal = qprTransactionLog.authReversal.containsIgnoreCase(params.getFirst(FilterConstants.AUTH_RESERVAL));
        }
        if (params.get(FilterConstants.RPS_STATUS) != null) {
            if (Objects.requireNonNull(params.getFirst(FilterConstants.RPS_STATUS)).equalsIgnoreCase(FilterConstants.SUCCESS)) {
                rpsStatus = qprTransactionLog.rpsStatus.eq(FilterConstants.SUCCESS);
            } else {
                rpsStatus = qprTransactionLog.rpsStatus.ne(FilterConstants.SUCCESS);
            }
        }
        if (params.get(FilterConstants.START_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.START_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            startDate = qprTransactionLog.createdDate.after(localDateTime);
        }
        if (params.get(FilterConstants.END_DATE) != null) {
            Date localDateTime = null;
            try {
                localDateTime = DateFormatter.StringToDate(params.getFirst(FilterConstants.END_DATE));
            } catch (ParseException e) {
                log.error(e.getMessage());
            }
            endDate = qprTransactionLog.createdDate.before(localDateTime);
        }
        Predicate predicate = qprTransactionLog.isNotNull()
                .and(qid)
                .and(mobile)
                .and(amount)
                .and(paymentMethod)
                .and(currency)
                .and(apiStatus)
                .and(transactionUUID)
                .and(description)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(rpsStatus)
                .and(startDate)
                .and(endDate)
                .and(authReversal);

        return (List<PRTransactionLog>) transactionRepository.findAll(predicate);
    }

    @Override
    public Page<PRTransactionLog> all(Pageable pageable) {
        return transactionRepository.findAll(pageable);
    }

    @Override
    public void updateStatus(String transactionUUID, TransactionStatusEnum transactionStatus) {
        log.info("[TransactionLogDaoImpl] updateStatus, transactionUUID {}, transactionStatus {}", transactionUUID, transactionStatus);
        Optional<PRTransactionLog> transactionLog = this.transactionRepository.findByTransactionUUID(transactionUUID);
        if (transactionLog.isPresent()) {
            PRTransactionLog trxLog = transactionLog.get();
            trxLog.setTransactionStatus(transactionStatus);
            if (transactionStatus == TransactionStatusEnum.CANCELED)
                trxLog.setApiStatus(TransactionStatusEnum.CANCELED);
            this.transactionRepository.save(trxLog);
        } else {
            throw new DataNotFoundException("TransactionLog", transactionUUID, "TransactionLog");
        }
    }


    @Override
    public Page<PRTransactionLog> getFiltredTransactions(Pageable pageable, MultiValueMap<String, String> params) throws ParseException {
        log.info("[PRTransactionLogDaoImpl] getFiltredTransactions");

        Predicate transactionUUID = null;
        Predicate ListTransactionUUID = null;
        Predicate referenceNumber = null;
        Predicate transactionStatus = null;
        Predicate userID = null;
        Predicate qid = null;
        Predicate mobile = null;
        Predicate amount = null;
        Predicate currency = null;
        Predicate paymentMethod = null;
        Predicate apiStatus = null;
        Predicate createdDate = null;
        Predicate transactionID = null;
        Predicate id = null;
        Predicate description = null;
        Predicate rpsStatus = null;
        Predicate startDate = null;
        Predicate endDate = null;


        QPRTransactionLog qprTransactionLog = QPRTransactionLog.pRTransactionLog;

        if (params.get("qid") != null) {
            qid = qprTransactionLog.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.AMOUNT) != null) {
            String searchAmount = "%" + Double.valueOf(params.getFirst(FilterConstants.AMOUNT)) + "%";
            amount = qprTransactionLog.amount.like(searchAmount);
        }

        if (params.get(FilterConstants.CONRRENCY) != null) {
            currency = qprTransactionLog.currency.containsIgnoreCase(params.getFirst(FilterConstants.CONRRENCY));
        }

        if (params.get(FilterConstants.PAYMENT_METHOD) != null) {
            paymentMethod = qprTransactionLog.paymentMethod.eq(PaymentMethodEnum.valueOf(params.getFirst(FilterConstants.PAYMENT_METHOD)));
        }


        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qprTransactionLog.mobile.containsIgnoreCase(params.getFirst(FilterConstants.MOBILE));
        }

        if (params.get(FilterConstants.API_STATUS) != null) {
            apiStatus = qprTransactionLog.apiStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.API_STATUS)));
        }


        if (params.get(FilterConstants.USER_ID) != null) {
            userID = qprTransactionLog.userID.containsIgnoreCase(params.getFirst(FilterConstants.USER_ID));
        }

        if (params.get(FilterConstants.TRANSACTION_STATUS) != null) {
            transactionStatus = qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.valueOf(params.getFirst(FilterConstants.TRANSACTION_STATUS)));
        }

        if (params.get(FilterConstants.TRANSACTION_UUID) != null) {
            transactionUUID = qprTransactionLog.transactionUUID.containsIgnoreCase(params.getFirst(FilterConstants.TRANSACTION_UUID));
        }

        if (params.get(FilterConstants.REFERENCE_NUMBER) != null) {
            referenceNumber = qprTransactionLog.referenceNumber.containsIgnoreCase(params.getFirst(FilterConstants.REFERENCE_NUMBER));
        }

        if (params.get(FilterConstants.CREATED_DATE) != null) {
            try {
                createdDate = qprTransactionLog.createdDate.after(new SimpleDateFormat("yyyy/MM/dd").parse(params.getFirst(FilterConstants.CREATED_DATE)));
            } catch (ParseException ignored) {
            }
        }

        if (params.get((FilterConstants.TRANSACTION_ID)) != null) {
            transactionID = qprTransactionLog.transactionID.containsIgnoreCase(params.getFirst((FilterConstants.TRANSACTION_ID)));
        }

        if (params.get(FilterConstants.DESCRIPTION) != null) {
            description = qprTransactionLog.description.containsIgnoreCase(params.getFirst(FilterConstants.DESCRIPTION));
        }

      /*  if (params.get(FilterConstants.AUTH_RESERVAL) != null) {
            authReversal = qprTransactionLog.authReversal.containsIgnoreCase(params.getFirst(FilterConstants.AUTH_RESERVAL));
        }*/

        if (params.get(FilterConstants.PLATENUMBER) != null) {
            List<PreRegistration> preRegistration = preRegistrationDao.findAllByPlateNumber(params.getFirst(FilterConstants.PLATENUMBER));
            ListTransactionUUID = qprTransactionLog.transactionUUID.in(preRegistration.stream().map(PreRegistration::getTransactionUUID).collect(Collectors.toList()));
        }

        if (params.get(FilterConstants.RPS_STATUS) != null) {
            if (Objects.requireNonNull(params.getFirst(FilterConstants.RPS_STATUS)).equalsIgnoreCase(FilterConstants.SUCCESS)) {
                rpsStatus = qprTransactionLog.rpsStatus.eq(FilterConstants.SUCCESS);
            } else {
                rpsStatus = qprTransactionLog.rpsStatus.ne(FilterConstants.SUCCESS);
            }
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.START_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            startDate = qprTransactionLog.createdDate.after(DateFormatter.localDateTimeToDate(date1));
        }

        if (params.get(FilterConstants.END_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst(FilterConstants.END_DATE)));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qprTransactionLog.createdDate.before(DateFormatter.localDateTimeToDate(date2));
        }

        Predicate predicate = qprTransactionLog.isNotNull()
                .and(qid)
                .and(mobile)
                .and(amount)
                .and(paymentMethod)
                .and(currency)
                .and(apiStatus)
                .and(ListTransactionUUID)
                .and(transactionUUID)
                .and(description)
                .and(userID)
                .and(transactionStatus)
                .and(referenceNumber)
                .and(createdDate)
                .and(transactionID)
                .and(rpsStatus)
                .and(startDate)
                .and(endDate);

        return transactionRepository.findAll(predicate, pageable);
    }

    @Override
    public BigDecimal getSum(String qid, String from, String to) {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        BigDecimal sumAmoutFahesTransactions = BigDecimal.valueOf(transactionRepository.calculateTotalFahesAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));
        BigDecimal sumAmoutFahesQpayTransactions = BigDecimal.valueOf(fahesQpayTransactionRepository.calculateTotalFahesQpayTransactionsAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));

        return sumAmoutFahesTransactions.add(sumAmoutFahesQpayTransactions);
    }

    @Override
    public BigDecimal getSumCC(String qid, String from, String to) {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        return BigDecimal.valueOf(transactionRepository.calculateTotalFahesAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));
    }

    @Override
    public BigDecimal getSumDC(String qid, String from, String to) {
        Date startDate;
        Date endDate;
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        startDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(from));
        cal1.setTime(startDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(startDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());

        endDate = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(to));
        cal1.setTime(endDate);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.setTime(endDate);
        cal2.set(Calendar.HOUR_OF_DAY, 23);
        cal2.set(Calendar.MINUTE, 59);
        cal2.set(Calendar.SECOND, 59);
        cal2.set(Calendar.MILLISECOND, 0);
        LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());

        return BigDecimal.valueOf(fahesQpayTransactionRepository.calculateTotalFahesQpayTransactionsAmount(DateFormatter.localDateTimeToDate(date1), DateFormatter.localDateTimeToDate(date2)).orElse(0L));
    }


    /**
     * find transaction before 10min
     **/
    @Override
    public List<PRTransactionLog> findAllByCreatedDateBetween() {
        long ONE_MINUTE_IN_MILLIS = 60000;
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date afterRemovingTenMins = new Date(t - (numberOfMinutes * ONE_MINUTE_IN_MILLIS));

        // today
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 0);
        dateToday.set(Calendar.MINUTE, 0);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);
        List<PRTransactionLog> list1 = transactionRepository.findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus("CBQ",dateToday.getTime(), afterRemovingTenMins, TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);
        List<PRTransactionLog> list2 = transactionRepository.findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusAndApiStatus("CBQ",dateToday.getTime(), afterRemovingTenMins, TransactionStatusEnum.PAID, TransactionStatusEnum.ERROR);
        List<PRTransactionLog> list3 = transactionRepository.findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusAndApiStatus("CBQ",dateToday.getTime(), afterRemovingTenMins, TransactionStatusEnum.PAIED, TransactionStatusEnum.ERROR);
        list1.addAll(list2);
        list1.addAll(list3);
        return list1;

    }

    @Override
    public SFResource getSFTrans(String qid, String from, String to) throws ParseException {

        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QPRTransactionLog qprTransactionLog = QPRTransactionLog.pRTransactionLog;

        if (qid != null && !qid.isEmpty()) {
            qidp = qprTransactionLog.qid.equalsIgnoreCase(qid);
        }
        if (from != null) {
            fromp = qprTransactionLog.createdDate.after(DateFormatter.StringToDate(from));
        }
        if (to != null) {
            Date tomorrow = new Date((DateFormatter.StringToDate(to)).getTime() + (1000 * 60 * 60 * 24));
            top = qprTransactionLog.createdDate.before(tomorrow);
        }

        Predicate predicateSuccess = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAID)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.PAIED)))
                .and(fromp);

        long successTransaction = transactionRepository.count(predicateSuccess);

        Predicate predicateError = qprTransactionLog.isNotNull()
                .and(qidp)
                .and(top)
                .and((qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.FAILED)).or(qprTransactionLog.transactionStatus.eq(TransactionStatusEnum.ERROR)))
                .and(fromp);

        long failedTransaction = transactionRepository.count(predicateError);


        return SFResource.builder()
                .success(successTransaction)
                .failed(failedTransaction)
                .build();

    }

    /**
     * find transaction between now and given date
     **/
    @Override
    public List<PRTransactionLog> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException {
        // today - 1
        Calendar dateToday = new GregorianCalendar();
        // reset hour, minutes, seconds and millis
        dateToday.set(Calendar.HOUR_OF_DAY, 23);
        dateToday.set(Calendar.MINUTE, 59);
        dateToday.set(Calendar.SECOND, 0);
        dateToday.set(Calendar.MILLISECOND, 0);
        dateToday.add(Calendar.DATE, -1);

        Date givenDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);

        List<PRTransactionLog> list1 = transactionRepository.findAllByCreatedDateBetweenAndTransactionStatusOrTransactionStatus(givenDate, dateToday.getTime(), TransactionStatusEnum.INPROGRESS, TransactionStatusEnum.ERROR);
        List<PRTransactionLog> list2 = transactionRepository.findAllByCreatedDateBetweenAndTransactionStatusAndApiStatus(givenDate, dateToday.getTime(), TransactionStatusEnum.PAID, TransactionStatusEnum.ERROR);
        List<PRTransactionLog> list3 = transactionRepository.findAllByCreatedDateBetweenAndTransactionStatusAndApiStatus(givenDate, dateToday.getTime(), TransactionStatusEnum.PAIED, TransactionStatusEnum.ERROR);
        list1.addAll(list2);
        list1.addAll(list3);
        return list1;
    }

    @Override
    public List<PRTransactionLog> saveAll(List<PRTransactionLog> prTransactionLogs) {
        try {
            return transactionRepository.saveAll(prTransactionLogs);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("Prtransactionlog", ex);
        }
    }

    @Override
    public Long count() {
        return transactionRepository.count();
    }

}
