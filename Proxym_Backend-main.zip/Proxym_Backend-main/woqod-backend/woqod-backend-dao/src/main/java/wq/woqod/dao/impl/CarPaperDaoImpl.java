package wq.woqod.dao.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.CarPaperDao;
import wq.woqod.dao.entity.CarPaper;
import wq.woqod.dao.repository.CarPaperRepository;


@Component
@Slf4j
public class CarPaperDaoImpl implements CarPaperDao {

    public final CarPaperRepository carPaperRepository;

    public CarPaperDaoImpl(CarPaperRepository carPaperRepository) {
        this.carPaperRepository = carPaperRepository;
    }


    @Override
    public CarPaper save(CarPaper carPaper) {
        try {
            return carPaperRepository.save(carPaper);
        } catch (DataIntegrityViolationException ex) {
            log.error("Problem when persisting carPaper entity..", ex);
            throw new PersistingDataException("carPaper", ex);
        }
    }
}
