package wq.woqod.dao;

import wq.woqod.dao.entity.CarPaper;

public interface CarPaperDao {

    CarPaper save(CarPaper carPaper);
}
