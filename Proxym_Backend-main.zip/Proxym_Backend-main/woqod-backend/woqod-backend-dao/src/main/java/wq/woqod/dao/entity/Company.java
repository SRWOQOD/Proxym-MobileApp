package wq.woqod.dao.entity;


import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.CompanySectorEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by bfitouri on 14/11/16.
 */
@Entity
@Table(name = Constants.TABLE_COMPANY)
public class Company implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private CompanySectorEnum sector;

    @Column(name = "company_id", unique = true)
    private String companyId;

    @Column(name = "company_creation_date")
    private LocalDate companyCreationDate;

    @OneToMany(mappedBy = "company", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<User> users;

    public Company() {
    }

    private Company(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.sector = builder.sector;
        this.companyId = builder.companyId;
        this.companyCreationDate = builder.companyCreationDate;
        this.users = builder.users != null ? builder.users : new ArrayList<>();
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public CompanySectorEnum getSector() {
        return sector;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public LocalDate getCompanyCreationDate() {
        return companyCreationDate;
    }

    public List<User> getUsers() {
        return users;
    }

    public static class Builder {

        private Long id;
        private String name;
        private CompanySectorEnum sector;
        private String companyId;
        private LocalDate companyCreationDate;
        private List<User> users = new ArrayList<>();

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder sector(CompanySectorEnum sector) {
            this.sector = sector;
            return this;
        }

        public Builder companyId(String companyId) {
            this.companyId = companyId;
            return this;
        }

        public Builder companyCreationDate(LocalDate companyCreationDate) {
            this.companyCreationDate = companyCreationDate;
            return this;
        }

        public Builder users(List<User> users) {
            this.users.addAll(users);
            return this;
        }

        public Builder user(User user) {
            this.users.add(user);
            return this;
        }

        public Company build() {
            return new Company(this);
        }

    }

}
