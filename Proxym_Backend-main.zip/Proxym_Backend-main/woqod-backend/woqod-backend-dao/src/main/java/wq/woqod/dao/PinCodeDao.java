package wq.woqod.dao;

import wq.woqod.dao.entity.PinCode;

/**
 * Created by Hassen.Ellouze on 06/02/2019.
 */
public interface PinCodeDao {

    PinCode getPinCodeByUsername(String username);

    void saveOrUpdatePinCode(PinCode pinCode);

}
