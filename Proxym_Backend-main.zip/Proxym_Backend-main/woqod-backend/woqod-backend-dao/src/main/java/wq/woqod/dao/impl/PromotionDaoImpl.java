package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.commons.exception.UpdatingDataException;
import wq.woqod.dao.PromotionDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.Promotion;
import wq.woqod.dao.entity.QPromotion;
import wq.woqod.dao.repository.PromotionRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by ameni on 26/11/16.
 */
@Component
public class PromotionDaoImpl implements PromotionDao {

    private final PromotionRepository promotionRepository;

    @Autowired
    public PromotionDaoImpl(PromotionRepository promotionRepository) {
        this.promotionRepository = promotionRepository;
    }

    @Override
    public List<Promotion> getAllPromotions() {
        QPromotion promotion = QPromotion.promotion;
        BooleanExpression stat = promotion.startDate.before(LocalDate.now().atTime(LocalTime.now()));
        BooleanExpression end = promotion.endDate.after(LocalDate.now().atTime(LocalTime.now()));

        Predicate dateCondition = stat.and(end);
        Iterable<Promotion> list = promotionRepository.findAll(dateCondition);
        if (ObjectUtils.isEmpty(list)) {
            return new ArrayList<>();
        }
        return (List<Promotion>) list;
    }

    @Override
    public List<Promotion> getAllPromotionsBo(MultiValueMap<String, String> parameters) {
        Predicate qpromotionId = null;
        Predicate qtitle = null;
        Predicate qdescription = null;

        QPromotion qPromotion = QPromotion.promotion;

        if (parameters.get(FilterConstants.PROMOTIONS_ID) != null) {
            String searchPromotionId = "%" + Long.valueOf(parameters.getFirst(FilterConstants.PROMOTIONS_ID)) + "%";
            qpromotionId = qPromotion.promotionId.like(searchPromotionId);
        }

        if (parameters.get(FilterConstants.TITLE) != null) {
            qtitle = qPromotion.title.containsIgnoreCase(parameters.getFirst(FilterConstants.TITLE));
        }

        if (parameters.get(FilterConstants.DESCRIPTION) != null) {
            qdescription = qPromotion.briefDescription.containsIgnoreCase(parameters.getFirst(FilterConstants.DESCRIPTION));
        }

        Predicate predicateTransaction = qPromotion.isNotNull()
                .and(qpromotionId)
                .and(qtitle)
                .and(qdescription);

        return (List<Promotion>) promotionRepository.findAll(predicateTransaction);
    }

    @Override
    public void createPromotions(List<Promotion> promotions) {
        try {

            promotionRepository.deleteAll();
            promotionRepository.flush();
            promotionRepository.saveAll(promotions);

        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("promotion", ex);
        }
    }

    @Override
    public Optional<Promotion> getPromotionByPromotionId(Long promotionId) {
        return promotionRepository.findPromotionByPromotionId(promotionId);
    }

    @Override
    public Page<Promotion> getFilteredpromotions(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qpromotionId = null;
        Predicate qtitle = null;
        Predicate qdescription = null;

        QPromotion qPromotion = QPromotion.promotion;

        if (parameters.get(FilterConstants.PROMOTIONS_ID) != null) {
            String searchPromotionId = "%" + Long.valueOf(parameters.getFirst(FilterConstants.PROMOTIONS_ID)) + "%";
            qpromotionId = qPromotion.promotionId.like(searchPromotionId);
        }

        if (parameters.get(FilterConstants.TITLE) != null) {
            qtitle = qPromotion.title.containsIgnoreCase(parameters.getFirst(FilterConstants.TITLE));
        }

        if (parameters.get(FilterConstants.DESCRIPTION) != null) {
            qdescription = qPromotion.briefDescription.containsIgnoreCase(parameters.getFirst(FilterConstants.DESCRIPTION));
        }

        Predicate predicateTransaction = qPromotion.isNotNull()
                .and(qpromotionId)
                .and(qtitle)
                .and(qdescription);

        return promotionRepository.findAll(predicateTransaction, pageable);
    }

    @Override
    public void delete(Long id) {
        try {
            Promotion promotion = getPromotionById(id);
            promotionRepository.delete(promotion);
        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("Promotion DAO", ex);
        }
    }

    @Override
    public Promotion getPromotionById(Long id) {
        return promotionRepository.getOne(id);
    }

    @Override
    public void editPromotion(Promotion promotion) {
        promotionRepository.save(promotion);
    }

    @Override
    public List<Promotion> getActivePromotions() {
        Predicate endDate = null;
        Predicate qstartDate = null;
        LocalDateTime nowDateTile = LocalDateTime.now();

        QPromotion qPromotion = QPromotion.promotion;

        endDate = qPromotion.endDate.after(nowDateTile);

        qstartDate = qPromotion.startDate.before(nowDateTile);

        Predicate predicateTransaction = qPromotion.isNotNull()
                .and(endDate)
                .and(qstartDate);

        return (List<Promotion>) promotionRepository.findAll(predicateTransaction);
    }

}
