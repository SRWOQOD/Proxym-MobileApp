package wq.woqod.dao;

import wq.woqod.dao.entity.AppRedirection;

import java.util.List;

public interface AppRedirectionDao {
    AppRedirection getHomeRedirectionByName(String name);
    List<AppRedirection> getHomeRedirectionList( );
}
