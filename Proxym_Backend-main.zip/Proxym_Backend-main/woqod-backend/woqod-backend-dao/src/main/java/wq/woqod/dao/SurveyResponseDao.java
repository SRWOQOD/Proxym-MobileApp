package wq.woqod.dao;

import wq.woqod.dao.entity.Survey;
import wq.woqod.dao.entity.SurveyResponse;

import java.util.List;

public interface SurveyResponseDao {

    List<SurveyResponse> getAllSurveysResponses();

    SurveyResponse getSurveyResponseById(Long id);

    List<SurveyResponse> getResponseBySurvey(Survey survey);

    void save(List<SurveyResponse> surveyResponse);

    void deleteSurveysResponses(Long id);

    List<SurveyResponse> findAllByDeviceId(String deviceId);
}
