package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.FahesQpayTransaction;
import wq.woqod.dao.entity.WoqodeQpayTransaction;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface FahesQpayTransactionRepository extends JpaRepository<FahesQpayTransaction, Long>, QuerydslPredicateExecutor<FahesQpayTransaction> {
    Optional<FahesQpayTransaction> findByPun(String pun);

    @Modifying
    @Transactional
    @Query("update FahesQpayTransaction u set u.transactionStatus = ?2  where u.pun= ?1")
    void updateStatus(String pun, TransactionStatusEnum statusEnum);

    List<FahesQpayTransaction> findAllByTransactionStatusOrTransactionStatusAndCreatedDateBetween(TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1, Date dateNow, Date fin);

    List<FahesQpayTransaction> findAllByTransactionStatusAndApiStatusAndCreatedDateBetween(TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1, Date dateNow, Date fin);
    List<FahesQpayTransaction>  findAllByCreatedDateBeforeAndTransactionStatusOrTransactionStatus( Date dateNow, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);
    List<FahesQpayTransaction>  findAllByCreatedDateBetweenAndTransactionStatusOrTransactionStatus( Date startDate,Date dateNow, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);
    List<FahesQpayTransaction>  findAllByRpsStatusAndTransactionStatusAndApiStatusAndCreatedDateBetween( String desc,  TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1, Date dateNow, Date fin);
    @Query("select t from FahesQpayTransaction t where  t.rpsStatus=?1 and t.createdDate BETWEEN ?2 AND ?3 and (t.transactionStatus=?4 or t.transactionStatus=?5) ")
    List<FahesQpayTransaction> findAllByRpsStatusAndCreatedDateBetweenAndTransactionStatusOrTransactionStatus(String desc,Date startDate,Date dateNow, TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1);

    @Query("select count(f) from FahesQpayTransaction f where (f.transactionStatus = 'PAID') and f.qid=?1 and f.createdDate between ?2 and ?3 ")
    Long getSuccessfulTransactionsNumber(String qid, Date fro, Date to);

    @Query("select count(t) from FahesQpayTransaction t where t.transactionStatus = 'ERROR' or t.transactionStatus = 'FAILED'")
    Long getFailedTransactionsNumber();

    @Query("select sum(t.amount) from FahesQpayTransaction t")
    Long getAmountSum();

    List<FahesQpayTransaction> findAllByQid(String qid);

    List<FahesQpayTransaction> findAllByTransactionStatusCodeAndCreatedDateBefore(String statusCode, Date date);

    List<FahesQpayTransaction> findAllByQidAndTransactionStatusCodeAndCreatedDateBefore(String qid, String statusCode, Date date);

    List<FahesQpayTransaction> findAllByTransactionStatusCode(String statusCode);

    List<FahesQpayTransaction> findAllByTransactionStatusOrTransactionStatusAndCreatedDateBefore(TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1, Date givenDate);

    List<FahesQpayTransaction> findAllByTransactionStatusAndApiStatusAndCreatedDateBefore(TransactionStatusEnum transactionStatus, TransactionStatusEnum transactionStatus1, Date givenDate);

    @Query("select sum(u.amount) from FahesQpayTransaction u " + "where (u.transactionStatus = 'PAID' or u.transactionStatus = 'PAIED') and u.createdDate between :creDatFrom and :creDatTo")
    Optional<Long> calculateTotalFahesQpayTransactionsAmount(@Param("creDatFrom") Date creDatFrom, @Param("creDatTo") Date creDatTo);

}
