package wq.woqod.dao;

import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.dao.entity.Car;
import wq.woqod.dao.entity.WoqodeQpayTransaction;
import wq.woqod.resources.resources.SFResource;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface WoqodeQpayTransactionDao {

    void createTransaction(WoqodeQpayTransaction transaction);

    WoqodeQpayTransaction findByPun(String pun);

    WoqodeQpayTransaction findByReferenceNumber(String referenceNumber);

    WoqodeQpayTransaction updateStatus(String pun, TransactionStatusEnum transactionStatus);

    WoqodeQpayTransaction updateTransactionId(String pun, String statusCode, String statusMessage, String transactionID, String rpstatus, TransactionStatusEnum statusEnum);

    WoqodeQpayTransaction update(WoqodeQpayTransaction transactionLog);

    Page<WoqodeQpayTransaction> findAll(Predicate predicate, Pageable pageable);

    Page<WoqodeQpayTransaction> all(Pageable pageable);

    Page<WoqodeQpayTransaction> getFiltredTransactions(Predicate predicate, Pageable pageable);

    Page<WoqodeQpayTransaction> getFiltredTransactions(Predicate predicate, Pageable pageable, MultiValueMap<String, String> parameters) throws ParseException;

    /**
     * find transaction before 10min
     **/
    List<WoqodeQpayTransaction> findAllByCreatedDateBetween();

    /**
     * find transaction between now and given date
     **/
    List<WoqodeQpayTransaction> findAllByCreatedDateBetweenNowAndGivenDate(String date) throws ParseException;

    WoqodeQpayTransaction updateTransactionDescription(String pun, TransactionStatusEnum statusEnum, String description, String statusCode, String statusMessage, String rpsStatus, String authReversalStatus, String approvalCode);

    List<WoqodeQpayTransaction> findAll(MultiValueMap<String, String> parameters) throws ParseException;

    Long count();

    List<WoqodeQpayTransaction> findAllByQid(Long qid);

    List<WoqodeQpayTransaction> findAllByStatusCodeAndCreatedDateBefore(String statusCode, Date date);

    List<WoqodeQpayTransaction> findAllByQidAndStatusCodeAndCreatedDateBefore(String qid, String statusCode, Date date);

    List<WoqodeQpayTransaction> findAllByStatusCode(String statusCode);

    /**
     * find transaction before 20min
     **/
    List<WoqodeQpayTransaction> findAllByCreatedDateBeforeTwentyMinutes();

    SFResource getSFQpayTrans(String qid, String from, String to) throws ParseException;

    void saveAll(List<WoqodeQpayTransaction> woqodeQpayTransactions);
}

