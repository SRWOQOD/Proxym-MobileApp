package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.PersistingDataException;
import wq.woqod.dao.BusinessBannerDao;
import wq.woqod.dao.entity.BusinessBanner;
import wq.woqod.dao.entity.QBusinessBanner;
import wq.woqod.dao.repository.BusinessBannerRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class BusinessBannerDaoImpl implements BusinessBannerDao {

    private final BusinessBannerRepository businessBannerRepository;
    private static final String DATE_FROM = "dateFrom";
    private static final String DATE_TO = "dateTo";

    @Autowired
    public BusinessBannerDaoImpl(BusinessBannerRepository businessBannerRepository) {
        this.businessBannerRepository = businessBannerRepository;
    }

    @Override
    public void save(BusinessBanner businessBanner) {
        BusinessBanner old = businessBanner.getId() != null ? getById(businessBanner.getId()) : null;
        if (old == null) {
            try {
                BusinessBanner lastElement = businessBannerRepository.findTopByOrderByOrderItemDesc().orElse(null);
                businessBanner.setOrderItem(Objects.isNull(lastElement) ? 1 : lastElement.getOrderItem() + 1);
                businessBannerRepository.save(businessBanner);
            } catch (DataIntegrityViolationException ex) {
                throw new PersistingDataException("BusinessBannerDaoImpl", ex);
            }
        } else {
            businessBanner.setOrderItem(old.getOrderItem());
            businessBannerRepository.save(businessBanner);
        }
    }

    @Override
    public List<BusinessBanner> getbanner() {
        return businessBannerRepository.findAll();
    }

    @Override
    public List<BusinessBanner> filter(MultiValueMap<String, String> parameters) {
        Predicate active = null;
        Predicate qcreatedDate = null;
        Predicate title = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        QBusinessBanner qBusinessBanner = QBusinessBanner.businessBanner;

        if (parameters.get("active") != null) {
            active = qBusinessBanner.active.eq(Boolean.valueOf(parameters.getFirst("active")));
        }
        if (parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) != null) {
            qcreatedDate = qBusinessBanner.creationDate.between((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)), (LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        } else if(parameters.get(DATE_FROM) != null && parameters.get(DATE_TO) == null) {
            qcreatedDate = qBusinessBanner.creationDate.after((LocalDateTime.parse(parameters.getFirst(DATE_FROM), formatter).minusDays(1)));
        } else if (parameters.get(DATE_TO) != null && parameters.get(DATE_FROM) == null) {
            qcreatedDate = qBusinessBanner.creationDate.before((LocalDateTime.parse(parameters.getFirst(DATE_TO), formatter).plusDays(1)));
        }

        if (parameters.get("title") != null) {
            title = qBusinessBanner.title.containsIgnoreCase(parameters.getFirst("title"));
        }

        Predicate predicateAdsBanner = qBusinessBanner.isNotNull()
                .and(active)
                .and(qcreatedDate)
                .and(title);
        return (List<BusinessBanner>) businessBannerRepository.findAll(predicateAdsBanner);
    }

    @Override
    public BusinessBanner getById(Long valueOf) {
        return businessBannerRepository.getOne(valueOf);
    }

    @Override
    public void update(List<BusinessBanner> list) {
        businessBannerRepository.saveAll(list);
    }

    @Override
    public List<BusinessBanner> getActiveBanner() {

        return businessBannerRepository.findAllByActive(true);
    }

    @Override
    public Long count() {
        return businessBannerRepository.count();
    }

    @Override
    public void delete(Long id) {
        businessBannerRepository.deleteById(id);
    }
}
