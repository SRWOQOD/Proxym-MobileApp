package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.TopBannerDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.QTopBanner;
import wq.woqod.dao.entity.TopBanner;
import wq.woqod.dao.repository.TopBannerRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Component

public class TopBannerDaoImpl implements TopBannerDao {

    private final TopBannerRepository topBannerRepository;

    public TopBannerDaoImpl(TopBannerRepository topBannerRepository) {
        this.topBannerRepository = topBannerRepository;
    }

    @Override
    public void save(TopBanner topBanner) {
        TopBanner old = topBanner.getId() != null ? getById(topBanner.getId()) : null;
        if ( old == null) {
            Long orderItem = NumberUtils.LONG_ONE;
            Long numberOgTopBannerItems = topBannerRepository.count();

            if(!NumberUtils.LONG_ZERO.equals(numberOgTopBannerItems)) {
                TopBanner lastElement = topBannerRepository.findTopByOrderByOrderItemDesc().orElse(null);
                if(!Objects.isNull(lastElement) && lastElement.getOrderItem() != null) {
                    orderItem = lastElement.getOrderItem() + 1;
                } else {
                    orderItem = numberOgTopBannerItems + 1;
                }
            }
            topBanner.setOrderItem(orderItem);
            topBannerRepository.save(topBanner);
        } else {
            topBanner.setOrderItem(old.getOrderItem());
            topBannerRepository.save(topBanner);
        }
    }

    @Override
    public List<TopBanner> getTopBanner() {
        return topBannerRepository.findAll();
    }

    @Override
    public List<TopBanner> filter(MultiValueMap<String, String> parameters) {
        Predicate active = null;
        Predicate date = null;
        Predicate title = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        QTopBanner qTopBanner = QTopBanner.topBanner;
        if (parameters.get("active") != null) {
            active = qTopBanner.active.eq(Boolean.valueOf(parameters.getFirst("active")));
        }
        if (parameters.get("dateFrom") != null && parameters.get("dateTo") != null) {
            date = qTopBanner.creationDate.between((LocalDateTime.parse(parameters.getFirst("dateFrom"), formatter).minusDays(1)), (LocalDateTime.parse(parameters.getFirst("dateTo"), formatter).plusDays(1)));
        } else if(parameters.get("dateFrom") != null && parameters.get("dateTo") == null) {
            date = qTopBanner.creationDate.after((LocalDateTime.parse(parameters.getFirst("dateFrom"), formatter).minusDays(1)));
        } else if (parameters.get("dateTo") != null && parameters.get("dateFrom") == null) {
            date = qTopBanner.creationDate.before((LocalDateTime.parse(parameters.getFirst("dateTo"), formatter).plusDays(1)));
        }
        if (parameters.get(FilterConstants.TITLE) != null) {
            title = qTopBanner.title.containsIgnoreCase(parameters.getFirst("title"));
        }
        Predicate predicateAdsBanner = qTopBanner.isNotNull()
                .and(active).and(date).and(title);
        return (List<TopBanner>) topBannerRepository.findAll(predicateAdsBanner);
    }

    @Override
    public TopBanner getById(Long valueOf) {
        return topBannerRepository.getOne(valueOf);
    }

    @Override
    public void update(List<TopBanner> list) {
        topBannerRepository.saveAll(list);
    }

    @Override
    public List<TopBanner> getActiveTopBanner() {
        return topBannerRepository.findAllByActive(true);
    }

    @Override
    public Long count() {
        return topBannerRepository.count();
    }

    @Override
    public void delete(Long id) {
        topBannerRepository.deleteById(id);
    }
}
