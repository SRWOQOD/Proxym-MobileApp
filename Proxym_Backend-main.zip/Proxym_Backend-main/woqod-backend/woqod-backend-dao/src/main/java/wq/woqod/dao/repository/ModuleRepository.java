package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Module;


/**
 * Created by med-taher.ben-torkia on 11/2/2016.
 */
public interface ModuleRepository extends JpaRepository<Module, Long> {


}
