package wq.woqod.dao.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 11/17/2016.
 */
@Entity
public class RetailerUser extends User implements Serializable {

    @Column(name = "retailer_id")
    private String retailerId;

    @Column(name = "driver_id")
    private String driverId;

    public RetailerUser() {
    }

    public RetailerUser(Builder builder) {
        super(builder);
        this.retailerId = builder.retailerId;
        this.driverId = builder.driverId;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public String getRetailerId() {
        return retailerId;
    }

    public void setRetailerId(String retailerId) {
        this.retailerId = retailerId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public static class Builder extends User.Builder<Builder> {

        private String retailerId;
        private String driverId;

        public Builder retailerId(String retailerId) {
            this.retailerId = retailerId;
            return this;
        }

        public Builder driverId(String driverId) {
            this.driverId = driverId;
            return this;
        }

        public Builder getThis() {
            return this;
        }

        public RetailerUser build() {
            return new RetailerUser(this);
        }
    }
}
