package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by med-amine.dahmen 14/10/2020
 */
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = Constants.TABLE_NOTIFICATION_TEMPLATE)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class NotificationTemplate extends Auditable implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, unique = true)
    private String title;

    @Column(nullable = false)
    @Lob
    private String content;
    @Column(nullable = false, unique = true)
    private String arabicTitle;

    @Column(nullable = false)
    @Lob
    private String arabicContent;

}
