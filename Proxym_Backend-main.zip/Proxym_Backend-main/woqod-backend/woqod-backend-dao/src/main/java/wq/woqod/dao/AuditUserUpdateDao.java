package wq.woqod.dao;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.AuditTrailUpdateUser;
import wq.woqod.resources.resources.AuditUserUpdateResource;

import java.text.ParseException;


public interface AuditUserUpdateDao {
    AuditTrailUpdateUser save(AuditTrailUpdateUser auditTrailUpdateUser);

    Page<AuditTrailUpdateUser> filter(Pageable pageable, MultiValueMap<String, String> params) throws ParseException;

    Long count();
}
