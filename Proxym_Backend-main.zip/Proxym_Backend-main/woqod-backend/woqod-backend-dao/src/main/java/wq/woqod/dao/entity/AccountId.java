package wq.woqod.dao.entity;


import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

import javax.persistence.Embeddable;

/**
 * Created by bfitouri on 14/11/16.
 */
@Embeddable
public class AccountId {

    private String pincode;
    private String username;

    public AccountId(String username, String pincode) {
        this.username = username;
        this.pincode = pincode;
    }

    public AccountId() {
    }

    public String getPincode() {
        return pincode;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public boolean equals(final Object obj) { // NOSONAR
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        AccountId other = (AccountId) obj;
        return Objects.equal(this.pincode, other.pincode) && Objects.equal(this.username, other.username);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), pincode, username);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("pincode", pincode).add("username", username).toString();
    }
}
