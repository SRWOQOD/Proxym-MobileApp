package wq.woqod.dao.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Contractor;


public interface ContractorRepository extends JpaRepository<Contractor, Long> {


}
