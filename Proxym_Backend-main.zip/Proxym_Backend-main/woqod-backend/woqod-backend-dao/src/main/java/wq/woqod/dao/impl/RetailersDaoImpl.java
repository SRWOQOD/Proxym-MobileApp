package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.RetailersDao;
import wq.woqod.dao.entity.QRetailers;
import wq.woqod.dao.entity.Retailers;
import wq.woqod.dao.repository.RetailersRepository;

import java.util.List;
import java.util.Optional;

@Component
public class RetailersDaoImpl implements RetailersDao {


    private static final Logger LOGGER = LoggerFactory.getLogger(RetailersDaoImpl.class);
    private final RetailersRepository retailersRepository;

    @Autowired
    public RetailersDaoImpl(RetailersRepository retailersRepository) {
        this.retailersRepository = retailersRepository;
    }

    @Override
    public List<Retailers> getAllRetailers() {
        return retailersRepository.findAll();
    }

    @Override
    public Page<Retailers> getFilteredShafafRetailers(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qretailId = null;
        Predicate qtitle = null;
        Predicate qcontactPerson = null;

        QRetailers qRetailers = QRetailers.retailers;

        if (parameters.get("retailId") != null) {
            qretailId = qRetailers.retailId.eq(Long.valueOf(parameters.getFirst("retailId")));
        }

        if (parameters.get("title") != null) {
            qtitle = qRetailers.title.containsIgnoreCase(parameters.getFirst("title"));
        }

        if (parameters.get("contactPerson") != null) {
            qcontactPerson = qRetailers.contactPerson.containsIgnoreCase(parameters.getFirst("contactPerson"));
        }

        Predicate predicateTransaction = qRetailers.isNotNull()
                .and(qretailId)
                .and(qtitle)
                .and(qcontactPerson);

        return retailersRepository.findAll(predicateTransaction, pageable);

    }

    @Override
    public Optional<Retailers> getRetailerByRetailId(Long retailId) {
        return retailersRepository.findRetailersByRetailId(retailId);
    }

    @Override
    public void createRetailer(List<Retailers> retailers) {
        retailersRepository.saveAll(retailers);
    }
}
