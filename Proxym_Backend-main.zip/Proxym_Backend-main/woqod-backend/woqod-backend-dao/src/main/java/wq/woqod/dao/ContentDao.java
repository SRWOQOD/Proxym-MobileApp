package wq.woqod.dao;

import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.resources.ContentInfoResource;

public interface ContentDao {
    ContentInfoResource getContent(String entity, String field, ContentCategoryEnum categoryEnum);

    Long count();
}
