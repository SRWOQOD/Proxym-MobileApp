package wq.woqod.dao.entity;

import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.TextType;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = Constants.TABLE_TEXT)
public class Text {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private TextType textType;
    @Lob
    private String content;
    @Lob
    private String contentAr;
}
