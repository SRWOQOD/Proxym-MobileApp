package wq.woqod.dao;

import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.TopBanner;

import java.util.List;

public interface TopBannerDao {
    void save(TopBanner topBanner);

    List<TopBanner> getTopBanner();

    List<TopBanner> filter(MultiValueMap<String, String> parameters);

    TopBanner getById(Long valueOf);

    void update(List<TopBanner> list);

    List<TopBanner> getActiveTopBanner();

    Long count();

    void delete(Long id);
}
