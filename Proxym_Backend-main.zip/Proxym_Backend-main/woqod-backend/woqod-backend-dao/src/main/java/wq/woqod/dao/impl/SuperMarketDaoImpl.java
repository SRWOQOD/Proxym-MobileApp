package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.SuperMarketDao;
import wq.woqod.dao.entity.QSuperMarket;
import wq.woqod.dao.entity.SuperMarket;
import wq.woqod.dao.repository.SuperMarketRepository;

import java.util.List;
import java.util.Optional;

@Component
public class SuperMarketDaoImpl implements SuperMarketDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(SuperMarketDaoImpl.class);
    private final SuperMarketRepository superMarketRepository;

    @Autowired
    public SuperMarketDaoImpl(SuperMarketRepository superMarketRepository) {
        this.superMarketRepository = superMarketRepository;
    }

    @Override
    public List<SuperMarket> getAllSuperMarkets() {
        return superMarketRepository.findAll();
    }

    @Override
    public Optional<SuperMarket> getSuperMarketByMarketId(Long marketId) {
        return superMarketRepository.findSuperMarketByMarketId(marketId);
    }

    @Override
    public void create(List<SuperMarket> superMarkets) {
        superMarketRepository.saveAll(superMarkets);
    }

    @Override
    public Page<SuperMarket> getFilteredSupermarkets(Pageable pageable, MultiValueMap<String, String> parameters) {

        Predicate qmarketId = null;
        Predicate qtitle = null;
        Predicate qcontactPerson = null;
        Predicate area = null;

        QSuperMarket qSuperMarket = QSuperMarket.superMarket;

        if (parameters.get("marketId") != null) {
            String searchMarketId = "%" + Long.valueOf(parameters.getFirst("marketId")) + "%";
            qmarketId = qSuperMarket.marketId.like(searchMarketId);
        }
        if (parameters.get("areaId") != null) {
            area = qSuperMarket.area.idArea.eq((parameters.getFirst("areaId")));
        }
        if (parameters.get("title") != null) {
            qtitle = qSuperMarket.title.containsIgnoreCase(parameters.getFirst("title"));
        }

        if (parameters.get("contactPerson") != null) {
            qcontactPerson = qSuperMarket.contactPerson.containsIgnoreCase(parameters.getFirst("contactPerson"));
        }
        Predicate predicateTransaction = qSuperMarket.isNotNull()
                .and(qmarketId)
                .and(area)
                .and(qtitle)
                .and(qcontactPerson);

        return superMarketRepository.findAll(predicateTransaction, pageable);
    }
}
