package wq.woqod.dao.entity;

import wq.woqod.dao.constants.Constants;

import javax.persistence.*;

@Entity
@Table(name = Constants.TABLE_USER_SURVEY)
public class UserSurvey {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "survey_id")
    private Survey survey;

    public UserSurvey() {
    }

    private UserSurvey(Builder builder) {
        this.id = builder.id;
        this.user = builder.user;
        this.survey = builder.survey;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Survey getSurvey() {
        return survey;
    }

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }

    public static class Builder {

        private Long id;
        private User user;
        private Survey survey;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder user(User user) {
            this.user = user;
            return this;
        }

        public Builder survey(Survey survey) {
            this.survey = survey;
            return this;
        }

        public UserSurvey build() {
            return new UserSurvey(this);
        }


    }
}
