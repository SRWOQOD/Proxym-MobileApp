package wq.woqod.dao.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.DeviceStatusEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by bfitouri on 14/11/16.
 */
@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = Constants.TABLE_DEVICE)
public class Device implements Serializable {

    @ManyToOne
    User owner;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String phone;
    private String deviceType;
    private String deviceId;
    private Date creationDate;
    private Date lastConnection;
    @Enumerated(EnumType.STRING)
    private DeviceStatusEnum status;
    private String bioPin;
    private String customPwd;
    private Boolean surveystatus;
    @ElementCollection
    private List<Long> surveyList;
}
