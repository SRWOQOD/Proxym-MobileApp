package wq.woqod.dao.entity;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.ServiceNameEnum;
import wq.woqod.resources.enumerations.ServiceStateEnum;
import wq.woqod.resources.enumerations.ServiceStatusEnum;
import wq.woqod.resources.resources.FahesVO;


import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by med-taher.ben-torkia on 12/13/2016.
 */
@Entity
@Table(name = Constants.TABLE_SERVICE_STATION)
public class ServiceStation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ServiceNameEnum name;

    @Enumerated(EnumType.STRING)
    private ServiceStatusEnum status;

    @Column(name = "opening_hour", nullable = false)
    private String openingHour;

    @Column(name = "closing_hour", nullable = false)
    private String closingHour;

    @Enumerated(EnumType.STRING)
    private ServiceStateEnum state;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "station_id")
    private Station station;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fahes_id")
    private Fahes fahesStation;

    public ServiceStation() {
    }

    private ServiceStation(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.status = builder.status;
        this.openingHour = builder.openingHour;
        this.closingHour = builder.closingHour;
        this.state = builder.state;
        this.station = builder.station;
        this.fahesStation = builder.fahesStation;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null || !getClass().equals(obj.getClass())) {
            return false;
        }
        ServiceStation other = (ServiceStation) obj;
        return Objects.equal(this.name, other.name) && Objects.equal(this.station, other.station);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getClass(), name, station);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("name", name).add("status", status).add("openingHour", openingHour)
                .add("closingHour", closingHour).add("state", state).add("station", station).toString();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ServiceNameEnum getName() {
        return name;
    }

    public void setName(ServiceNameEnum name) {
        this.name = name;
    }

    public ServiceStatusEnum getStatus() {
        return status;
    }

    public void setStatus(ServiceStatusEnum status) {
        this.status = status;
    }

    public String getOpeningHour() {
        return openingHour;
    }

    public void setOpeningHour(String openingHour) {
        this.openingHour = openingHour;
    }

    public String getClosingHour() {
        return closingHour;
    }

    public void setClosingHour(String closingHour) {
        this.closingHour = closingHour;
    }

    public ServiceStateEnum getState() {
        return state;
    }

    public void setState(ServiceStateEnum state) {
        this.state = state;
    }

    public Station getStation() {
        return station;
    }

    public void setStation(Station station) {
        this.station = station;
    }

    public Fahes getFahesStation() {
        return fahesStation;
    }

    public void setFahesStation(Fahes fahesStation) {
        this.fahesStation = fahesStation;
    }

    public static class Builder {

        private Long id;
        private ServiceNameEnum name;
        private ServiceStatusEnum status;
        private String openingHour;
        private String closingHour;
        private ServiceStateEnum state;
        private Station station;
        private Fahes fahesStation;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder name(ServiceNameEnum name) {
            this.name = name;
            return this;
        }

        public Builder status(ServiceStatusEnum status) {
            this.status = status;
            return this;
        }

        public Builder openingHour(String openingHour) {
            this.openingHour = openingHour;
            return this;
        }

        public Builder closingHour(String closingHour) {
            this.closingHour = closingHour;
            return this;
        }

        public Builder state(ServiceStateEnum state) {
            this.state = state;
            return this;
        }

        public Builder station(Station station) {
            this.station = station;
            return this;
        }

        public Builder fahesStation(Fahes fahesStation) {
            this.fahesStation = fahesStation;
            return this;
        }

        public ServiceStation build() {
            return new ServiceStation(this);
        }
    }
}
