package wq.woqod.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import wq.woqod.dao.constants.Constants;
import wq.woqod.resources.enumerations.CarTagStatusEnum;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = Constants.TABLE_TAG)
@NoArgsConstructor
@AllArgsConstructor
public class Tag {

    @Id
    @GeneratedValue
    private Long id;

    @Column
    private Double cost;

    @Column
    private Double fees;

    @Column
    private CarTagStatusEnum carTagStatusEnum;

    @OneToOne
    @JoinColumn(name = "car_id")
    private Car car;

    @Column(name = "tag_reference")
    private String tagReference;

    @Column(name = "registration_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date registrationDate;

    private String transactionUUID;
}
