package wq.woqod.dao.impl;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import wq.woqod.dao.StockPricesDao;
import wq.woqod.dao.entity.Stock;
import wq.woqod.dao.repository.StockPricesRepository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class StockPricesDaoImpl implements StockPricesDao {
    private final StockPricesRepository stockPricesRepository;

    public StockPricesDaoImpl(StockPricesRepository stockPricesRepository) {
        this.stockPricesRepository = stockPricesRepository;
    }

    @Override
    public List<Stock> getStockPrices() {
        return stockPricesRepository.findAll(Sort.by(Sort.Direction.DESC, "dateStock"));
    }

    @Override
    public void createStockPrices(Stock stock) {
        stockPricesRepository.save(stock);
    }

    @Override
    public Optional<Stock> findByDateStock(Timestamp dateStock) {
        return stockPricesRepository.findByDateStock(dateStock);
    }
}
