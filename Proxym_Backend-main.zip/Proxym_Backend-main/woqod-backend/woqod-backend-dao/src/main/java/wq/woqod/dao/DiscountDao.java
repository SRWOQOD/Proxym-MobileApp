package wq.woqod.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.util.MultiValueMap;
import wq.woqod.dao.entity.Discount;

import java.util.List;

/**
 * Created by Hassen.Ellouze on 15/11/2018.
 */
public interface DiscountDao {
    List<Discount> getAllDiscount();

    void updateDiscount(Discount discount);

    void save(Discount discount);

    Discount getDiscountByServiceAndPaymentMethode(String fahesService, String paymentMethod);

    Discount getDiscountByServiceAndPaymentMethodeAndAmount(String fahesService, String paymentMethod, Double amount);

    Discount getDiscountByAmount(Double amount);

    Boolean checkInterval(Double min, Double max, String method, String type, String service, String status);

    Boolean checkIntervalForUpdate(Long id, Double min, Double max, String method, String type, String service, String status);


    Page<Discount> getFiltredDiscounts(Pageable pageable, MultiValueMap<String, String> parameters);

    void delete(Long id);

    Discount getById(Long id);
}
