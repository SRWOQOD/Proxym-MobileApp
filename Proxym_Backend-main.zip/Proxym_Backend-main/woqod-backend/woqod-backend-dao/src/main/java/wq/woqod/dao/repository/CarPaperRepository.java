package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.CarPaper;


public interface CarPaperRepository extends JpaRepository<CarPaper, Long> {
}
