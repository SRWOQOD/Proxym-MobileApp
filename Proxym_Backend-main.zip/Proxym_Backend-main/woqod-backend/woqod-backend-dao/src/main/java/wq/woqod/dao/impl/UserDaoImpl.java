package wq.woqod.dao.impl;

import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import wq.woqod.commons.exception.*;
import wq.woqod.commons.utils.DateFormatter;
import wq.woqod.dao.DeviceDao;
import wq.woqod.dao.UserDao;
import wq.woqod.dao.constants.FilterConstants;
import wq.woqod.dao.entity.Device;
import wq.woqod.dao.entity.IndividualUser;
import wq.woqod.dao.entity.QUser;
import wq.woqod.dao.entity.User;
import wq.woqod.dao.repository.AccountRepository;
import wq.woqod.dao.repository.DeviceRepository;
import wq.woqod.dao.repository.SurveyResponseRepository;
import wq.woqod.dao.repository.UserRepository;
import wq.woqod.resources.enumerations.DeviceStatusEnum;
import wq.woqod.resources.enumerations.StatusEnum;
import wq.woqod.resources.enumerations.UserTypeEnum;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Created by bfitouri on 14/11/16.
 */
@Component
public class UserDaoImpl implements UserDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserDaoImpl.class);

    private final UserRepository userRepository;

    private final AccountRepository accountRepository;


    private final DeviceDao deviceDao;
    private final DeviceRepository deviceRepository;

    @Autowired
    public UserDaoImpl(UserRepository userRepository, AccountRepository accountRepository, DeviceDao deviceDao, DeviceRepository deviceRepository) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.deviceDao = deviceDao;
        this.deviceRepository = deviceRepository;
    }

    @Override
    public Page<User> all(Pageable pageable) {
        return userRepository.findAll(pageable);
    }

    @Override
    public User save(User user) {
        try {
            return userRepository.saveAndFlush(user);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("user", ex);
        }
    }

    @Override
    public List<User> save(List<User> users) {
        try {
            return userRepository.saveAll(users);
        } catch (DataIntegrityViolationException ex) {
            throw new PersistingDataException("user", ex);
        }
    }

    @Override
    public void update(User user) {
        try {
            userRepository.saveAndFlush(user);

        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("user", ex);
        }
    }

    @Override
    public User getByQid(String qid) {
        Optional<User> user = userRepository.findOneByQidAndStatusNotAndStatusNot(qid, StatusEnum.InActive, StatusEnum.Deleted);
        return user.orElseThrow(() -> new WrongUserIdentifierException("qid", qid, "user"));
    }

    @Override
    public Optional<User> getUserByQid(String qid) {
        return userRepository.findOneByQidAndStatusNotAndStatusNot(qid, StatusEnum.InActive, StatusEnum.Deleted);
    }

    @Override
    public Optional<User> getUserByQidAndMobileAndActive(String qid, String mobile){
        return userRepository.findOneByQidAndPhoneAndStatus(qid, mobile,StatusEnum.Active);
    }
    @Override
    public User getByUserNameAndUserType(String userName, UserTypeEnum userType) {
        Optional<User> user = userRepository.findOneByUserNameAndUserTypeAndStatusNot(userName, userType, StatusEnum.Deleted);
        return user.orElseThrow(() -> new DataNotFoundException("user", userName, "User"));
    }

    @Override
    public User getByUserNameAndStatusNot(String userName) {
        Optional<User> user = userRepository.findOneByUserNameAndStatusNot(userName, StatusEnum.Deleted);
        return user.orElseThrow(() -> new DataNotFoundException("user", userName, "User"));
    }

    @Override
    public User updateDeviceIdByUsername(String userName, String deviceId, String deviceType) {
        Optional<User> user = userRepository.findOneByUserNameAndStatusNot(userName, StatusEnum.Deleted);
        User usr;
        if (user.isPresent()) {
                    usr = user.get();
                    Optional<Device> device = Optional.ofNullable(deviceDao.findDeviceByDeviceUUID(deviceId));
                    LOGGER.info("device registred");
                    Device deviceX;
                    if (device.isPresent()) {
                        deviceX = Device.builder()
                                .id(device.get().getId())
                                .deviceId(deviceId)
                                .deviceType(deviceType)
                                .lastConnection(device.get().getCreationDate())
                                .creationDate(new Date())
                                .owner(user.get())
                                .status(DeviceStatusEnum.Active)
                                .build();
                        deviceDao.update(deviceX);
                    } else {
                        deviceX = Device.builder()
                                .deviceId(deviceId)
                                .deviceType(deviceType)
                                .owner(user.get())
                                .creationDate(new Date())
                                .status(DeviceStatusEnum.Active)
                                .build();
                        deviceDao.save(deviceX);
                        LOGGER.info("new device");

                    }

                    return usr;
                }
        throw new DataNotFoundException("user", userName, "User");
    }

    @Override
    public boolean exist(String userName) {
        IndividualUser user = IndividualUser.newBuilder().userName(userName).build();
        return userRepository.exists(Example.of(user));
    }

    @Override
    public User getByUserId(Long id) {
        Optional<User> user = userRepository.findOneById(id);
        return user.orElseThrow(() -> new DataNotFoundException("user", String.valueOf(id), "User"));
    }

    @Override
    public boolean checkExistanceByQidAndUserType(String qid, UserTypeEnum userType) {
        try {
            Optional<User> user = userRepository.findOneByQidAndUserTypeAndStatusNotAndStatusNot(qid, userType, StatusEnum.InActive, StatusEnum.Deleted);
            return user.isPresent();
        } catch (Exception e) {
            throw new QIDAlreadyExistException(qid);
        }
    }

    @Override
    public boolean checkExistanceByEmailAndUserType(String email, UserTypeEnum userType) {
        try {
            Optional<User> user = userRepository.findOneByEmailAndUserTypeAndStatusNotAndStatusNot(email, userType, StatusEnum.InActive, StatusEnum.Deleted);
            return user.isPresent();
        } catch (Exception e) {
            throw new EmailAlreadyExistException(email);
        }
    }

    @Override
    public boolean checkExistanceByMobileAndUserType(String mobile, UserTypeEnum userType) {
        try {
            Optional<User> user = userRepository.findOneByPhoneAndUserTypeAndStatusNotAndStatusNot(mobile, userType, StatusEnum.InActive, StatusEnum.Deleted);
            return user.isPresent();
        } catch (Exception e) {
            throw new MobileAlreadyExistException(mobile);
        }
    }

    @Override
    public boolean checkExistanceByUsernameAndUserType(String username, UserTypeEnum userType) {
        try {
            Optional<User> user = userRepository.findOneByUserNameAndUserTypeAndStatusNotAndStatusNot(username, userType, StatusEnum.InActive, StatusEnum.Deleted);
            return user.isPresent();
        } catch (Exception e) {
            throw new UserNameAlreadyExistException(username);
        }
    }

    /**
     * @param predicate
     * @param pageable
     * @param params
     * @return
     */
    @Override
    public Page<User> getFiltredUsers(Predicate predicate, Pageable pageable, MultiValueMap<String, String> params) {

        Predicate predicateWithEquals = this.getPredicateWithEquals(params);
        return userRepository.findAll(predicateWithEquals, pageable);
    }

    private Predicate getPredicateWithEquals ( MultiValueMap<String, String> params) {
        QUser qUser = QUser.user;

        Predicate predicateWithEquals;
        BooleanExpression username = null;
        BooleanExpression mobile = null;
        BooleanExpression qid = null;
        BooleanExpression email = null;
        BooleanExpression status = null;
        BooleanExpression startDate = null;
        BooleanExpression endDate = null;
        BooleanExpression woqode = null;
        BooleanExpression createdAt = null;

        if (params.get("isWoqodeUser") != null) {
            if (params.getFirst("isWoqodeUser").equalsIgnoreCase("true")) {
                woqode = qUser.isWoqodeUser.eq(Boolean.TRUE);
            }
        }

        if (params.get(FilterConstants.USERNAME1) != null) {
            username = qUser.userName.containsIgnoreCase((params.getFirst(FilterConstants.USERNAME1)).toLowerCase());
        }

        if (params.get(FilterConstants.MOBILE) != null) {
            mobile = qUser.phone.containsIgnoreCase((params.getFirst(FilterConstants.MOBILE)));
        }

        if (params.get("qid") != null) {
            qid = qUser.qid.containsIgnoreCase(params.getFirst("qid"));
        }

        if (params.get(FilterConstants.EMAIL) != null) {
            email = qUser.email.containsIgnoreCase((params.getFirst(FilterConstants.EMAIL)));
        }

        if (params.get(FilterConstants.STATUS) != null) {
            status = qUser.status.eq(StatusEnum.valueOf((params.getFirst(FilterConstants.STATUS))));
        }

        if (params.get(FilterConstants.START_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst("startDate")));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date1 = LocalDateTime.ofInstant(cal1.toInstant(), cal1.getTimeZone().toZoneId());
            startDate = qUser.createdAt.after(LocalDate.from(date1.minusDays(1)));
        }

        if (params.get(FilterConstants.END_DATE) != null) {
            Date date;
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            date = DateFormatter.localDateTimeToDate(DateFormatter.stringlDateToLcalDateTim(params.getFirst("endDate")));
            cal1.setTime(date);
            cal1.set(Calendar.HOUR_OF_DAY, 0);
            cal1.set(Calendar.MINUTE, 0);
            cal1.set(Calendar.SECOND, 0);
            cal1.set(Calendar.MILLISECOND, 0);

            cal2.setTime(date);
            cal2.set(Calendar.HOUR_OF_DAY, 23);
            cal2.set(Calendar.MINUTE, 59);
            cal2.set(Calendar.SECOND, 59);
            cal2.set(Calendar.MILLISECOND, 0);
            LocalDateTime date2 = LocalDateTime.ofInstant(cal2.toInstant(), cal2.getTimeZone().toZoneId());
            endDate = qUser.createdAt.before(LocalDate.from(date2.plusDays(1)));
        }

        predicateWithEquals = qUser.isNotNull()
                .and(username)
                .and(mobile)
                .and(qid)
                .and(status)
                .and(email)
                .and(woqode)
                .and(createdAt)
                .and(startDate)
                .and(endDate)
        ;
        return predicateWithEquals;
    }

    @Override
    public void deleteUserById(Long id, UserTypeEnum type) {
        try {
            Optional<User> user = userRepository.findOneById(id);
            if (user.isPresent()) {
                //Delete User Account
                accountRepository.delete(user.get().getAccount());
                //Delete User Survey Responses
            }
            userRepository.delete(user.get());

        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("user", ex);
        }
    }


    @Override
    public void deleteUser(Long id, UserTypeEnum type) {
        try {
            Optional<User> user = userRepository.findOneById(id);
            if (user.isPresent()) {
                //Delete User Account
                accountRepository.delete(user.get().getAccount());
                user.get().setAccount(null);
                user.get().setUserName(user.get().getUserName().concat("_deleted"));
            }
            updateUserStatusById(user.get().getId(), StatusEnum.Deleted, user.get().getUserType(), user.get().getQid());

        } catch (DataIntegrityViolationException ex) {
            throw new UpdatingDataException("user", ex);
        }
    }

    @Override
    public void updateUserStatusById(Long id, StatusEnum status, UserTypeEnum type, String qid) {
        try {
            switch (type) {
                case Individual_Customer: {
                    userRepository.updateIndividualStatus(status, id, qid);
                    break;
                }
                case Corporate_Manager_Customer:
                case Corporate_Employee_Customer: {
                    userRepository.updateCorporateStatus(status, id);
                    break;
                }
            }
        } catch (DataIntegrityViolationException ex) {
            LOGGER.error("Problem when Deleting user entity..", ex);
            throw new UpdatingDataException("user", ex);
        }
    }


    @Override
    public User getByQidAndStatus(String qid, StatusEnum status) {
        Optional<User> user = userRepository.findOneByQidAndStatus(qid, status);
        return user.orElseThrow(() -> new DataNotFoundException("qid", qid, "User"));
    }

    @Override
    public User getUserByEmail(String email) {
        Optional<User> user = userRepository.findByEmailAndStatusNotAndStatusNot(email, StatusEnum.InActive, StatusEnum.Deleted);
        return user.orElseThrow(() -> new WrongUserIdentifierException("email", email, "User"));
    }

    @Override
    public User getUserByPhoneNumber(String phone) {
        Optional<User> user = userRepository.findByPhoneAndStatusNotAndStatusNot(phone, StatusEnum.InActive, StatusEnum.Deleted);
        return user.orElseThrow(() -> new WrongUserIdentifierException("phone", phone, "User"));
    }

    @Override
    public User getByUsername(String username) {
        Optional<User> user = userRepository.findOneByUserNameAndStatusNot(username, StatusEnum.Deleted);
        if (user.isPresent()) {
            return user.get();
        }
        return null;
    }

    @Override
    public User getUserDetailsByUsername(String username) {
        Optional<User> user = userRepository.findOneByUserName(username);
        if (user.isPresent()) {
            return user.get();
        }
        return null;
    }

    @Override
    public BigInteger countUsers(String qid, String from, String to, boolean b) {
        Predicate qidp = null;
        Predicate fromp = null;
        Predicate top = null;
        QUser qUser = QUser.user;
        if (from != null) {
            fromp = qUser.createdAt.after(DateFormatter.stringlDateToLcalDat(from).minusDays(1));
        }
        if (to != null) {
            top = qUser.createdAt.before(DateFormatter.stringlDateToLcalDat(to).plusDays(1));
        }

        Predicate predicate;
        if (b) {
            predicate = qUser.isNotNull()
                    .and(qidp)
                    .and(top)
                    .and(qUser.status.eq(StatusEnum.Active))
                    .and(fromp);

        } else {
            predicate = qUser.isNotNull()
                    .and(qidp)
                    .and(top)
                    .and(fromp);
        }


        return BigInteger.valueOf(userRepository.count(predicate));
    }

    @Override
    public List<String> getAllDeviceUUIDByUserId(Long id) {
        User user = userRepository.findOneById(id).get();
        List<Device> devices = deviceDao.getDevicesByOwner(user);
        List<String> devicesIds = new ArrayList<>();
        for (Device d : devices) {
            devicesIds.add(d.getDeviceId());
        }
        return devicesIds;
    }

    public List<String> getAllDeviceId(Long id) {
        User user = userRepository.findOneById(id).get();
        List<Device> devices = deviceDao.getDevicesByOwner(user);
        List<String> devicesIds = new ArrayList<>();
        for (Device d : devices) {
            devicesIds.add(d.getId().toString());
        }
        return devicesIds;
    }

    @Override
    public List<User> getusers(MultiValueMap<String, String> params) {

        Predicate predicateWithEquals = this.getPredicateWithEquals(params);
        return (List<User>) userRepository.findAll(predicateWithEquals);
    }

    public List<String> getDevicesForWoqodeUsers() {
        return deviceRepository.getDevicesForWoqodeUsers();
    }

    @Override
    public Long getWoqodeUsers(String from, String to) {

        Predicate fromp = null;
        Predicate top = null;
        Predicate isWoqodeUser = null;
        QUser qUser = QUser.user;
        if (from != null) {
            fromp = qUser.createdAt.after(DateFormatter.stringlDateToLcalDat(from).minusDays(1));
        }
        if (to != null) {
            top = qUser.createdAt.before(DateFormatter.stringlDateToLcalDat(to).plusDays(1));
        }

        isWoqodeUser = qUser.isWoqodeUser.isTrue();
        Predicate predicate;
        predicate = qUser.isNotNull()
                .and(fromp)
                .and(isWoqodeUser)
                .and(top)
        ;
        return userRepository.count(predicate);
    }

    @Override
    public List<String> getWoqodeUsersId() {
        return deviceRepository.getWoqodeUsersId();
    }

    @Override
    public Long count() {
        return userRepository.count();
    }
}
