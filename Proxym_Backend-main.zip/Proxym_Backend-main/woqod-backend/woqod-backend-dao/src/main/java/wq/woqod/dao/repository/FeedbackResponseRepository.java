package wq.woqod.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.dao.entity.FeedbackResponse;

import java.util.List;

public interface FeedbackResponseRepository extends JpaRepository<FeedbackResponse, Long> {

    List<FeedbackResponse> getAllByFeedback(Feedback feedback);

}
