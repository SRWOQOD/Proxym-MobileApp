#!/bin/sh

/opt/SoapUI-5.2.1/bin/mockservicerunner.sh -m "MockService 1" "/home/user/woqod/mocks/ICT/CMVS-soapui-project.xml" &
