--
-- Table structure for table QPAY_FAHES_TRANSACTION
--
CREATE TABLE QPAY_FAHES_TRANSACTION
(
    ID                             NUMBER(19) not null
        primary key,
    CREATED_DATE                   TIMESTAMP(6),
    LAST_MODIFIED_DATE             TIMESTAMP(6),
    AUTH_REVERSAL_STATUS           VARCHAR2(255 char),
    AMOUNT                         FLOAT,
    API_STATUS                     VARCHAR2(255 char),
    AUTH_REVERSAL                  VARCHAR2(255 char),
    CURRENCY                       VARCHAR2(255 char),
    DESCRIPTION                    VARCHAR2(1024 char),
    DISCOUNT_INFO                  VARCHAR2(255 char),
    EMAIL                          VARCHAR2(255 char),
    INITIAL_AMOUNT                 FLOAT,
    MOBILE                         VARCHAR2(255 char),
    PAYMENT_METHOD                 VARCHAR2(255 char),
    PLATE_TYPE                     VARCHAR2(255 char),
    PUN                            VARCHAR2(255 char)
        constraint UK_L51GVDLYX3OWB7I3VIX3FF50T
            unique,
    QID                            VARCHAR2(255 char),
    REFERENCE_NUMBER               VARCHAR2(255 char),
    RPS_STATUS                     VARCHAR2(255 char),
    TRANSACTIONID                  VARCHAR2(255 char),
    TRANSACTION_SEARCH_DESCRIPTION VARCHAR2(1024 char),
    TRANSACTION_STATUS             VARCHAR2(255 char),
    USERID                         VARCHAR2(255 char),
    VALID                          NUMBER(1)  not null,
    PURCHASE_PUN                   VARCHAR2(255 char),
    APPROVAL_CODE                  VARCHAR2(255 char),
    REFUND_STATUS                  VARCHAR2(255 char),
    TRANSACTION_STATUS_CODE        VARCHAR2(255 char),
    TRANSACTION_STATUS_MESSAGE     VARCHAR2(255 char),
    REFUND_STATUS_CODE             VARCHAR2(255 char),
    REFUND_STATUS_MESSAGE          VARCHAR2(255 char)
)

drop table QPAY_WOQODE_TRANSACTION;
--
-- Table structure for table QPAY_WOQODE_TRANSACTION
--
create table QPAY_WOQODE_TRANSACTION
(
    ID                             NUMBER(19) not null
        primary key,
    CREATED_DATE                   TIMESTAMP(6),
    LAST_MODIFIED_DATE             TIMESTAMP(6),
    RPS_STATUS                     VARCHAR2(255 char),
    AMOUNT                         FLOAT,
    AUTH_REVERSAL                  VARCHAR2(255 char),
    AUTH_REVERSAL_STATUS           VARCHAR2(255 char),
    CURRENCY                       VARCHAR2(255 char),
    DESCRIPTION                    VARCHAR2(255 char),
    EMAIL                          VARCHAR2(255 char),
    MOBILE                         VARCHAR2(255 char),
    PUN                            VARCHAR2(255 char)
        constraint UK_L0EPIX5LJ54BODY6PWCC0EVAV
            unique,
    QID                            NUMBER(19),
    REFERENCE_NUMBER               VARCHAR2(255 char),
    TRANSACTIONID                  VARCHAR2(255 char),
    TRANSACTION_SEARCH_DESCRIPTION VARCHAR2(1024 char),
    TRANSACTION_STATUS             VARCHAR2(255 char),
    USERID                         VARCHAR2(255 char),
    PURCHASE_PUN                   VARCHAR2(255 char),
    APPROVAL_CODE                  VARCHAR2(255 char),
    REFUND_STATUS                  VARCHAR2(255 char),
    TRANSACTION_STATUS_CODE        VARCHAR2(255 char),
    TRANSACTION_STATUS_MESSAGE     VARCHAR2(255 char),
    REFUND_STATUS_CODE             VARCHAR2(255 char),
    REFUND_STATUS_MESSAGE          VARCHAR2(255 char)
)

-- 
-- Add Arabic Redirection ans Arabic Link to Banners
--
ALTER TABLE NEWS ADD LINK_AR VARCHAR2(255 char);
ALTER TABLE TOPBANNER ADD REDIRECTION_AR_PATH VARCHAR2(255 char);
ALTER TABLE BUSNIESSBANNER ADD REDIRECTION_AR_PATH VARCHAR2(255 char);
ALTER TABLE ADSBANNER ADD REDIRECTION_AR_PATH VARCHAR2(255 char);

-- 
-- Add TITLE_DISPLAYED to TOPBANNER and ADSBANNER
--
ALTER TABLE TOPBANNER ADD TITLE_DISPLAYED NUMBER(1) default 0;
ALTER TABLE ADSBANNER ADD TITLE_DISPLAYED NUMBER(1) default 0;
UPDATE ADSBANNER SET FILE_TYPE_ENUM = 0;

-- 
-- Add IS_VISIBLE to STATION
--
ALTER TABLE STATION ADD IS_VISIBLE VARCHAR2(255 char);

-- 
-- Add SERVICESTATION to FAHES
--
ALTER TABLE SERVICESTATION ADD FAHES_ID     NUMBER(19)
        constraint FKE7PIYLB8XBWNQDGMMMSR7GBJR
            references FAHES


-- 
-- Add TEXT_LIMIT, MIN, MAX to SURVEYQUESTION
--
ALTER TABLE SURVEYQUESTION ADD TEXT_LIMIT NUMBER(10);
ALTER TABLE SURVEYQUESTION ADD MAX FLOAT;
ALTER TABLE SURVEYQUESTION ADD MIN FLOAT;




