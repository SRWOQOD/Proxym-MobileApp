insert into AMOUNT (ID, MAX_AMOUNT, MIN_AMOUNT, NAME) values (1, 1000.0, 0.0, 'Transaction_Amount');

