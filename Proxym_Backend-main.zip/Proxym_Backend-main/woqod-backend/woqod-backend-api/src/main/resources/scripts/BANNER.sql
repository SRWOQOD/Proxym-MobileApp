alter table TOPBANNER
    drop column ORDER_ITEM;

alter table TOPBANNER
    add ORDER_ITEM number;

alter table ADSBANNER
    drop column ORDER_ITEM;

alter table ADSBANNER
    add ORDER_ITEM number;

alter table APPTIPS
    drop column ORDER_ITEM;

alter table APPTIPS
    add ORDER_ITEM number;

alter table BUSNIESSBANNER
    drop column ORDER_ITEM;

alter table BUSNIESSBANNER
    add ORDER_ITEM number;


