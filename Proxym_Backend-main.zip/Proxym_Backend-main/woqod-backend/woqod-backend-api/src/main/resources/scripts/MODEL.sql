INSERT INTO MODEL (ID, MODEL_ID, MODEL_NAME_AR, MODEL_NAME_EN)
VALUES (1, null, 'فيراري اف 8 سبايدر', 'Ferrari F8 Spider');
INSERT INTO MODEL (ID, MODEL_ID, MODEL_NAME_AR, MODEL_NAME_EN)
VALUES (2, null, 'فيراري اف 8 تريبوتو', 'Ferrari F8 Tributo');
INSERT INTO MODEL (ID, MODEL_ID, MODEL_NAME_AR, MODEL_NAME_EN)
VALUES (3, null, 'فيراري بورتوفينو', 'Ferrari Portofino');