Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('1','1','225,55','category1','category1');
Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('2','2','112,5','category2','category2');
Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('3','3','450','category3','category3');
Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('4','4','4500','category1','category1');
Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('5','5','10','category2','category2');
Insert into CATEGORY (ID,CATEGORY_ID,FEE,NAME_AR,NAME_EN) values ('6','6','1000000','category3','category3');
