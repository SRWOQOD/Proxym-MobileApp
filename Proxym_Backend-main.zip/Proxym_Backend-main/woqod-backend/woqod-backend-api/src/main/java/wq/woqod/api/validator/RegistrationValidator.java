package wq.woqod.api.validator;


import org.apache.commons.lang3.StringUtils;
import wq.woqod.commons.exception.InputDataMissingException;
import wq.woqod.resources.enumerations.LanguageEnum;

/**
 * Created by ameni on 09/01/17.
 */
public class RegistrationValidator {
    private RegistrationValidator() {
    }

    public static void preSendPinCode(String username, LanguageEnum language) {
        if (StringUtils.isBlank(username)) {
            throw new InputDataMissingException("username");
        }
        if ((!(LanguageEnum.isArabic(language))) && (!(LanguageEnum.isEnglish(language)))) {
            throw new InputDataMissingException("language");
        }
    }
}