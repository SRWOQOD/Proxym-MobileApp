package wq.woqod.api.validator;

import org.apache.commons.lang3.StringUtils;
import wq.woqod.commons.exception.InputDataMissingException;
import wq.woqod.resources.resources.FeedbackResource;

/**
 * Created by bfitouri on 03/01/17.
 */
public class FeedBackValidator {
    private FeedBackValidator() {
    }

    public static void prePost(FeedbackResource feedback) {
        if (feedback.getConnected() && StringUtils.isBlank(feedback.getUserName())) {
            throw new InputDataMissingException("username");
        }

        if (!feedback.getConnected() && (StringUtils.isBlank(feedback.getName()) || StringUtils.isBlank(feedback.getContactNumber()))) {
            throw new InputDataMissingException("name and contactNumber");
        }

    }
}
