package wq.woqod.api.controller;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FahesResource;
import wq.woqod.service.FahesQpayTransactionService;
import wq.woqod.service.FahesService;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;


@RestController
@RequestMapping(value = "/fahes")
public class FahesController {
    private static final String PROFILE = "profile_id";
    private static final String ACCE = "access_key";
    private static final String SECRET = "secret_key";
    private static final String BANK_ID = "BankID";
    private static final String QPAY_PAYMENT_DESCRIPTION_FAHES_EN = "Online Payment for FAHES Inspection";
    private static final String QPAY_PAYMENT_DESCRIPTION_WOQODE_EN = "Online Payment for WOQODe Topup";
    private static final String QPAY_PAYMENT_DESCRIPTION_FAHES_AR = "تسديد رسوم الفحص الفني لدى فاحص";
    private static final String QPAY_PAYMENT_DESCRIPTION_WOQODE_AR = "تعبئة رصيد وقودي";
    private static final String CURRENCY_CODE = "CurrencyCode";
    private static final String MERCHANT_ID = "MerchantID";
    private static final String ACTION = "Action";
    private static final String AMOUNT = "Amount";
    private static final String LANG = "Lang";
    private static final String MERCHANT_MODULE_SESSION_ID = "MerchantModuleSessionID";
    private static final String PUN = "PUN";
    private static final String PAYMENT_DESCRIPTION = "PaymentDescription";
    private static final String QUANTITY = "Quantity";
    private static final String TRANSACTION_REQUEST_DATE = "TransactionRequestDate";
    private static final String CURRENCYCODE = "634";
    private static final String EXTRA_FIELDS_F14 = "ExtraFields_f14";
    private static final String SECURE_HASH = "SecureHash";
    private static final String MERCHANT_URL = "PG_REDIRECT_URL";
    private static final String REQUEST_REFERRER = "referer";
    private static final String QPAY_SECRET_KEY = "secretKey";

    private final FahesService fahesService;
    protected final FahesQpayTransactionService fahesQpayTransactionService;

    @Value("${fahes.accessKey}")
    private String fahesAccessKey;
    @Value("${fahes.profileId}")
    private String fahesProfileId;
    @Value("${fahes.secretKey}")
    private String fahesSecretKey;
    @Value("${fahes.fahesQpayMerchantId}")
    private String fahesQpayMerchantId;
    @Value("${fahes.qpaySecretKey}")
    private String fahesQpaySecretKey;

    @Value("${woqode.accessKey}")
    private String woqodeAccessKey;
    @Value("${woqode.profileId}")
    private String woqodeProfileId;
    @Value("${woqode.secretKey}")
    private String woqodeSecretKey;
    @Value("${woqode.qpayMerchantId}")
    private String woqodeQpayMerchantId;
    @Value("${woqode.qpaySecretKey}")
    private String woqodeQpaySecretKey;
    @Value("${fahes.extraFieldsF14}")
    private String extraFieldsF14;
    @Value("${woqode.extraFieldsF14}")
    private String woqodeExtraFieldsF14;
    @Value("${merchant.url}")
    private String merchantUrl;
    @Value("${referer.url}")
    private String refererUrl;
    @Value("${BANKID}")
    private String BANKID;


    @Autowired
    public FahesController(FahesService fahesService, FahesQpayTransactionService fahesQpayTransactionService) {
        this.fahesService = fahesService;
        this.fahesQpayTransactionService = fahesQpayTransactionService;
    }

    @GetMapping(value = "station")
    public GenericResponse<ObjectResponse<FahesResource>> getFahes() {
        List<FahesResource> fahesResources = (fahesService.getAllFahesStations());
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(fahesResources), Provider.WOQOD);
    }

    @GetMapping(value = "/getSingParam")
    public GenericResponse<ObjectResponse<FahesResource>> getSingParam(@RequestParam(value = "name") String name) {
        HashMap<String, String> rep = new HashMap<>();

        if (name.equals("Fahes")) {
            rep.put(PROFILE, fahesProfileId);
            rep.put(ACCE, fahesAccessKey);
            rep.put(SECRET, fahesSecretKey);
        } else if (name.equals("Woqode")) {
            rep.put(PROFILE, woqodeProfileId);
            rep.put(ACCE, woqodeAccessKey);
            rep.put(SECRET, woqodeSecretKey);
        } else {
            rep.put(PROFILE, "");
            rep.put(ACCE, "");
            rep.put(SECRET, "");
        }

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(rep), Provider.WOQOD);

    }


    /**
     * @param name
     * @param action
     * @param amount
     * @param lang
     * @param merchantModuleSessionID
     * @param pun
     * @param quantity
     * @param transactionRequestDate
     * @return
     */
    @GetMapping(value = "/getQpaySignParam")
    public GenericResponse<ObjectResponse<FahesResource>> getQpaySingParam(@RequestParam(value = "name") String name,
                                                                           @RequestParam(value = "action") String action,
                                                                           @RequestParam(value = "amount") String amount,
                                                                           @RequestParam(value = "lang") String lang,
                                                                           @RequestParam(value = "merchantModuleSessionID") String merchantModuleSessionID,
                                                                           @RequestParam(value = "pun") String pun,
                                                                           @RequestParam(value = "quantity") String quantity,
                                                                           @RequestParam(value = "transactionRequestDate") String transactionRequestDate) {
        HashMap<String, String> rep = new HashMap<>();

        StringBuilder orderedString = new StringBuilder();

        if (name.equals("Fahes")) {
            //Create an Ordered String of The Parameters Map with Secret Key
            orderedString.append(fahesQpaySecretKey).append(action).append(amount).append(BANKID).append(CURRENCYCODE).append(extraFieldsF14)
                    .append(lang).append(fahesQpayMerchantId).append(merchantModuleSessionID).append(pun).append((lang.equals("en")) ? QPAY_PAYMENT_DESCRIPTION_FAHES_EN : QPAY_PAYMENT_DESCRIPTION_FAHES_AR).append(quantity).append(transactionRequestDate);

            // Generate SecureHash with SHA256
            // Using DigestUtils from appache.commons.codes.jar Library
            String secureHash = generateSecureHash(orderedString);

            rep.put(ACTION, action);
            rep.put(AMOUNT, amount);
            rep.put(LANG, lang);
            rep.put(PUN, pun);
            rep.put(MERCHANT_MODULE_SESSION_ID, merchantModuleSessionID);
            rep.put(PAYMENT_DESCRIPTION, (lang.equals("en")) ? QPAY_PAYMENT_DESCRIPTION_FAHES_EN : QPAY_PAYMENT_DESCRIPTION_FAHES_AR);
            rep.put(QUANTITY, quantity);
            rep.put(TRANSACTION_REQUEST_DATE, transactionRequestDate);
            rep.put(BANK_ID, BANKID);
            rep.put(CURRENCY_CODE, CURRENCYCODE);
            rep.put(MERCHANT_ID, fahesQpayMerchantId);
            rep.put(EXTRA_FIELDS_F14, extraFieldsF14);
            rep.put(SECURE_HASH, secureHash);
            rep.put(MERCHANT_URL, merchantUrl);
            rep.put(REQUEST_REFERRER, refererUrl);

        } else if (name.equals("Woqode")) {
            orderedString.append(woqodeQpaySecretKey).append(action).append(amount).append(BANKID).append(CURRENCYCODE).append(woqodeExtraFieldsF14)
                    .append(lang).append(woqodeQpayMerchantId).append(merchantModuleSessionID).append(pun).append((lang.equals("en")) ? QPAY_PAYMENT_DESCRIPTION_WOQODE_EN : QPAY_PAYMENT_DESCRIPTION_WOQODE_AR).append(quantity).append(transactionRequestDate);

            // Generate SecureHash with SHA256
            // Using DigestUtils from appache.commons.codes.jar Library
            String secureHash = generateSecureHash(orderedString);

            rep.put(ACTION, action);
            rep.put(AMOUNT, amount);
            rep.put(LANG, lang);
            rep.put(PUN, pun);
            rep.put(MERCHANT_MODULE_SESSION_ID, merchantModuleSessionID);
            rep.put(PAYMENT_DESCRIPTION, (lang.equals("en")) ? QPAY_PAYMENT_DESCRIPTION_WOQODE_EN : QPAY_PAYMENT_DESCRIPTION_WOQODE_AR);
            rep.put(QUANTITY, quantity);
            rep.put(TRANSACTION_REQUEST_DATE, transactionRequestDate);
            rep.put(BANK_ID, BANKID);
            rep.put(CURRENCY_CODE, CURRENCYCODE);
            rep.put(MERCHANT_ID, woqodeQpayMerchantId);
            rep.put(EXTRA_FIELDS_F14, woqodeExtraFieldsF14);
            rep.put(SECURE_HASH, secureHash);
            rep.put(MERCHANT_URL, merchantUrl);
            rep.put(REQUEST_REFERRER, refererUrl);

        } else {
            rep.put(BANK_ID, "");
            rep.put(CURRENCY_CODE, "");
            rep.put(MERCHANT_ID, "");
            rep.put(ACTION, "");
            rep.put(AMOUNT, "");
            rep.put(LANG, "");
            rep.put(MERCHANT_MODULE_SESSION_ID, "");
            rep.put(PUN, "");
            rep.put(PAYMENT_DESCRIPTION, "");
            rep.put(QUANTITY, "");
            rep.put(TRANSACTION_REQUEST_DATE, "");
            rep.put(EXTRA_FIELDS_F14, "");
            rep.put(SECURE_HASH, "");
            rep.put(MERCHANT_URL, "");
            rep.put(REQUEST_REFERRER, "");
        }

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(rep), Provider.WOQOD);

    }

    /**
     * @param name
     * @return
     */
    @GetMapping(value = "/getQpayPaymentSecretKey")
    public GenericResponse<ObjectResponse<FahesResource>> getQpayPaymentSecretKey(@RequestParam(value = "name") String name) {
        HashMap<String, String> rep = new HashMap<>();


        if (name.equals("Fahes")) {
            rep.put(QPAY_SECRET_KEY, fahesQpaySecretKey);
        } else if (name.equals("Woqode")) {
            rep.put(QPAY_SECRET_KEY, woqodeQpaySecretKey);

        } else {
            rep.put(QPAY_SECRET_KEY, "");
        }

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(rep), Provider.WOQOD);

    }

    private static String generateSecureHash(StringBuilder orderedString) {
        return new String(DigestUtils.sha256Hex(orderedString.toString()).getBytes());
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<FahesResource>> getFilteredFahes(Pageable pageable, PagedResourcesAssembler assembler,
                                                                           @RequestParam MultiValueMap<String, String> parameters) {
        Page<FahesResource> fahesResources = fahesService.getFilteredFahes(pageable, parameters);
        PagedModel result = assembler.toModel(fahesResources);
        List<FahesResource> fahesResourceList = Collections.unmodifiableList(fahesResources.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, fahesResourceList), Provider.WOQOD);
    }
}