package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.service.ILogsService;

@Api(value = "Logs Controller")
@RestController
@Slf4j
@RequestMapping(value = "/logs")
public class LogsController {

    private final ILogsService logsService;

    public LogsController(ILogsService logsService) {
        this.logsService = logsService;
    }

}
