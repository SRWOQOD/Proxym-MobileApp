package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.CredentialsResource;
import wq.woqod.service.CredentialsService;

/**
 * Created by ameni on 21/12/16.
 */
@RestController
@RequestMapping(value = "/credentials")
public class CredentialsController {

    private final CredentialsService credentailsService;

    @Autowired
    public CredentialsController(CredentialsService credentailsService) {
        this.credentailsService = credentailsService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<CredentialsResource>> getCredentials(@Param("firstName") String firstName, @Param("lastName") String lastName) {
        CredentialsResource credentials = ((firstName != null) && (lastName != null)) ? credentailsService.generateNewCredentials(firstName, lastName) : credentailsService.generateNewCredentials();
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(credentials), Provider.WOQOD);
    }
}
