package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.AppRedirectionRessource;
import wq.woqod.resources.resources.TopBannerResource;
import wq.woqod.service.AppRedirectionService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/appRedirection")

public class AppRedirectionController {
    private final AppRedirectionService appRedirectionService;
    public AppRedirectionController(AppRedirectionService appRedirectionService) {
        this.appRedirectionService = appRedirectionService;
    }
    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<AppRedirectionRessource>> getAdsbanner() {

        List<AppRedirectionRessource> list;
        list = appRedirectionService.getAppRedirectionList();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }
    @GetMapping(value = "/{name}")
    public GenericResponse<ObjectResponse<TopBannerResource>> getById(@PathVariable String name) {
        AppRedirectionRessource appRedirectionRessource=appRedirectionService.getHomeRedirectionByName(name);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(appRedirectionRessource), Provider.WOQOD);
    }
}
