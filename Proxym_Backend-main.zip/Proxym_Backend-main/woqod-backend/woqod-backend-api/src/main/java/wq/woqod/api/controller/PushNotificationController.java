package wq.woqod.api.controller;

import com.google.gson.Gson;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.exception.RestBackendException;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.Notification;
import wq.woqod.resources.resources.NotificationTemplateRessource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.UpdateStatusResource;
import wq.woqod.resources.resources.notifications.NotificationLogResource;
import wq.woqod.resources.resources.notifications.NotificationResource;
import wq.woqod.resources.resources.notifications.NotificationResourceForMobileListing;
import wq.woqod.resources.resources.notifications.SendDeviceNotificationResource;
import wq.woqod.service.DeviceService;
import wq.woqod.service.NotificaionTemplateService;
import wq.woqod.service.NotificationService;
import wq.woqod.service.SurveyService;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/notification")
@Slf4j
public class PushNotificationController {

    private final NotificationService pushNotificationService;
    private final NotificaionTemplateService notificaionTemplateService;
    private final NotificationService notificationService;
    private final SurveyService surveyService;
    private static final Logger LOGGER = LoggerFactory.getLogger(PushNotificationController.class);

    @Autowired
    public PushNotificationController(NotificationService pushNotificationService, NotificaionTemplateService notificaionTemplateService, DeviceService deviceService, NotificationService notificationService, SurveyService surveyService) {
        this.pushNotificationService = pushNotificationService;
        this.notificaionTemplateService = notificaionTemplateService;
        this.notificationService = notificationService;
        this.surveyService = surveyService;
    }

    @PostMapping(value = "/send")
    public GenericResponse sendNotification(@RequestBody SendDeviceNotificationResource notificationResource) throws SQLException {
        pushNotificationService.send(notificationResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<NotificationResource>> getFiltredNotificarionq(@PageableDefault(sort = {"sendDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                         @QuerydslPredicate(root = Notification.class) Predicate predicate,
                                                                                         @RequestParam(required = false) MultiValueMap<String, String> parameters) throws ParseException {
        Page<NotificationResource> notificationResources = pushNotificationService.getFilteredNotifications(pageable, predicate, parameters);
        PagedModel result = assembler.toModel(notificationResources);
        List<NotificationResource> notificationResourceList = Collections.unmodifiableList((notificationResources.getContent()));
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, notificationResourceList), Provider.WOQOD);

    }

    @GetMapping(value = "/filter")
    public GenericResponse<ObjectResponse<NotificationLogResource>> getFiltredNotificarion(@PageableDefault() Pageable pageable, PagedResourcesAssembler assembler,
                                                                                           @QuerydslPredicate(root = Notification.class) Predicate predicate,
                                                                                           @RequestParam(required = false) MultiValueMap<String, String> parameters) throws ParseException {
        Page<NotificationLogResource> notificationResources = pushNotificationService.slimFilter(pageable, parameters);
        PagedModel result = assembler.toModel(notificationResources);
        List<NotificationLogResource> notificationResourceList = Collections.unmodifiableList((notificationResources.getContent()));

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, notificationResourceList), Provider.WOQOD);

    }

    @GetMapping(value = "/listByDevice")
    public GenericResponse<ObjectResponse<NotificationResource>> findAllByDevice(@RequestParam(value = "device") String device) {
        List<NotificationResourceForMobileListing> notificationResources = pushNotificationService.findAllByDevice(device);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(notificationResources), Provider.WOQOD);
    }


    @GetMapping("/anonymous")
    public GenericResponse<PaginatedListResponse<NotificationResourceForMobileListing>> findAllForAnonymousUser(@PageableDefault(sort = {"sendDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler
            , @RequestParam String deviceId) {
        Page<NotificationResourceForMobileListing> notifications = pushNotificationService.findAllForAnonymousUser(pageable, deviceId);
        PagedModel result = assembler.toModel((notifications));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse(result, notifications.getContent())), Provider.WOQOD);
    }

    @GetMapping(value = "/listByUsername")
    public GenericResponse<PaginatedListResponse<NotificationResourceForMobileListing>> listByUsername(@PageableDefault(sort = {"sendDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler
            , @RequestParam String deviceId
    ) {
        Page<NotificationResourceForMobileListing> notificationResources = pushNotificationService.findAllByUsername(deviceId, pageable);
        PagedModel result = assembler.toModel(notificationResources);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse<>(result, notificationResources.getContent())), Provider.WOQOD);
    }

    @GetMapping(value = "/template/filter")
    public GenericResponse<ObjectResponse<NotificationTemplateRessource>> filter(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                 @RequestParam(required = false) MultiValueMap<String, String> parameters) {
        Page<NotificationTemplateRessource> notificationResources = notificaionTemplateService.filter(pageable, parameters);
        PagedModel result = assembler.toModel(notificationResources);
        List<NotificationTemplateRessource> notificationTemplateRessources = Collections.unmodifiableList((notificationResources.getContent()));
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, notificationTemplateRessources), Provider.WOQOD);
    }

    @PostMapping(value = "/template/save")
    public GenericResponse saveTemplate(@RequestBody NotificationTemplateRessource notificationTemplateRessource) {
        notificaionTemplateService.save(notificationTemplateRessource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/template/update")
    public GenericResponse updateTemplate(@RequestBody NotificationTemplateRessource notificationTemplateRessource) {
        notificaionTemplateService.update(notificationTemplateRessource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @DeleteMapping(value = "/delete")
    public GenericResponse deleteNotif(@RequestParam Long id) {
        notificaionTemplateService.deleteNotif(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @DeleteMapping(value = "/template/delete")
    public GenericResponse deleteTemplate(@RequestParam Long id) {
        notificaionTemplateService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/template/findById")
    public GenericResponse findById(@RequestParam Long id) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(notificaionTemplateService.findById(id)), Provider.WOQOD);
    }

    @PostMapping(value = "/sendNotificationTemplate")
    public GenericResponse sendNotificationTemplate(@RequestBody SendDeviceNotificationResource usersAndNotificationTemplateRessource) {
        notificaionTemplateService.sendNotificationTemplate(usersAndNotificationTemplateRessource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);

    }

    @GetMapping(value = "/getAll")
    public GenericResponse<ObjectResponse<NotificationLogResource>> getAll() {
        List<NotificationLogResource> notificationResources = pushNotificationService.findAll();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(notificationResources), Provider.WOQOD);
    }

    @PostMapping(value = "save")
    public GenericResponse save(@RequestBody SendDeviceNotificationResource notificationResource) throws SQLException {
        notificationService.save(notificationResource, null);
        SurveysResource surveysResource = surveyService.getSurveyById(2141L);
        Gson gson = new Gson();
        String jsonInString = gson.toJson(surveysResource);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(jsonInString), Provider.WOQOD);

    }

    @PostMapping(value = "updateStatus")
    public GenericResponse<BooleanResponse> updateStatus(@RequestBody UpdateStatusResource updateStatusResource) throws RestBackendException {
        LOGGER.info(updateStatusResource.getDeviceId(), updateStatusResource.getUniqueId(), updateStatusResource.getIdnotif(),
                updateStatusResource.getUsername());
        notificationService.updateStatus(Long.valueOf(updateStatusResource.getIdnotif()), updateStatusResource.getUsername()
                , updateStatusResource.getUniqueId(), updateStatusResource.getDeviceId());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "testFahesInspection")
    public GenericResponse<BooleanResponse> testFahesInspection() throws RestBackendException {
        notificationService.fahesInspectionReminder();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "updateAll")
    public GenericResponse<BooleanResponse> updateAll(@RequestParam Boolean connected, @RequestParam String deviceid) throws RestBackendException {
        notificationService.updateAll(connected, deviceid);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @GetMapping(value = "/notificationLogs")
    public GenericResponse<ObjectResponse<NotificationLogResource>> getAllNotificationLogs(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        List<NotificationLogResource> notificationLogsResource = pushNotificationService.getAllNotificationLogs(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(notificationLogsResource), Provider.WOQOD);
    }

    @GetMapping(value = "/template")
    public GenericResponse<ObjectResponse<NotificationTemplateRessource>> getAllNotificationTemplates(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        List<NotificationTemplateRessource> notificationTemplateResource = notificaionTemplateService.getAllNotificationTemplates(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(notificationTemplateResource), Provider.WOQOD);
    }

    @GetMapping("/template/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(notificaionTemplateService.count()), Provider.WOQOD);
    }

    @GetMapping("/template/report/count")
    public GenericResponse countNotificationReports() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(pushNotificationService.count()), Provider.WOQOD);
    }

}