package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.enumerations.TextType;
import wq.woqod.resources.resources.TextRessource;
import wq.woqod.service.TextService;

import javax.validation.Valid;
import java.util.List;

@Api(value = "Text Controller")
@RestController
@RequestMapping(value = "/text")
public class TextController {
    private final TextService textService;
    private static final Logger LOGGER = LoggerFactory.getLogger(TextController.class);

    public TextController(TextService textService) {
        this.textService = textService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<TextRessource>> getTexts(PagedResourcesAssembler assembler) {
        LOGGER.info("[ TextController ] GET TEXT");
        List<TextRessource> texts = textService.getTexts();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(texts), Provider.WOQOD);
    }

    @PutMapping(value = "")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateText(@RequestBody @Valid List<TextRessource> list) {
        textService.update(list);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/getTextByType")
    public GenericResponse<ObjectResponse<TextRessource>> getTextByType(@RequestParam(value = "type") TextType type) {
        LOGGER.info("[ TextController ] getTextByType");
        TextRessource texts = textService.getByTextType(type);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(texts), Provider.WOQOD);
    }
}
