package wq.woqod.api.controller;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.PreRegistration;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.service.FahesQpayTransactionService;
import wq.woqod.service.PRTransactionLogService;
import wq.woqod.service.PreRegistrationService;

import javax.mail.MessagingException;
import javax.validation.Valid;
import java.awt.*;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;


@RestController
@RequestMapping(value = "prtransactionlog")
@Slf4j
public class PrTransactionLogController {

    private final PRTransactionLogService prTransactionLogService;
    private final FahesQpayTransactionService fahesQpayTransactionService;

    private final PreRegistrationService preRegistrationService;


    public PrTransactionLogController(PRTransactionLogService prTransactionLogService, FahesQpayTransactionService fahesQpayTransactionService, PreRegistrationService preRegistrationService) {
        this.prTransactionLogService = prTransactionLogService;
        this.fahesQpayTransactionService = fahesQpayTransactionService;
        this.preRegistrationService = preRegistrationService;
    }


    @GetMapping(value = "/filtred")
    public GenericResponse<PaginatedListResponse<PRTransactionLogResource>> getFiltredPRTansactionLog(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                                      @RequestParam MultiValueMap<String, String> parameters) throws ParseException {
        Page<PRTransactionLogResource> prTransactionLogModels = prTransactionLogService.getFilteredTransactions(pageable, parameters);
        PagedModel result = assembler.toModel(prTransactionLogModels);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, prTransactionLogModels.getContent()), Provider.WOQOD);

    }

    @GetMapping(value = "")
    public GenericResponse<ListResponse<PRTransactionLogResource>> getPRTransactionLogs(@RequestParam MultiValueMap<String, String> parameters) {
        List<PRTransactionLogResource> promotionResourceList = prTransactionLogService.getAllTransactions(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(promotionResourceList), Provider.WOQOD);
    }

    @ApiOperation(value = "Update PR transaction Log  ", response = GenericResponse.class)
    @PutMapping(value = "/updateTransactionUUID")
    public GenericResponse<BooleanResponse> update(@RequestParam String transactionUUID, @RequestParam TransactionStatusEnum status) {
        prTransactionLogService.updateStatus(transactionUUID, status);
        if (status == TransactionStatusEnum.CANCELED) {
            PreRegistration preRegistration = preRegistrationService.findByTransactionUUID(transactionUUID);
            preRegistration.setWsStatus(TransactionStatusEnum.CANCELED.toString());
            preRegistration.setPayStatus(TransactionStatusEnum.CANCELED.toString());
            preRegistrationService.update(preRegistration);
        }
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @ApiOperation(value = "find prTrans by uuid")
    @GetMapping(value = "/find_by_uuid")
    public GenericResponse findByTransactionUUID(@RequestParam String uuid) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(prTransactionLogService.findByTransactionUUID(uuid)), Provider.WOQOD);
    }


    @ApiOperation(value = "Add a Pre Registration Transaction Log")
    @PostMapping(value = "creditcard/save")
    public GenericResponse savePRTransactionLog(@RequestBody @Valid PRTransactionLogResource prTransactionLogResource, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type") String plateType, @RequestParam(value = "anonym", required = true) Boolean anonym) {
        boolean result = prTransactionLogService.createTransaction(prTransactionLogResource, plateNumber, plateType, anonym);
        if (result) {
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
        } else {
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(false), Provider.WOQOD);
        }

    }

    @ApiOperation(value = "Add a free Pre Registration Transaction Log")
    @PostMapping(value = "free/save")
    public GenericResponse savePRTransactionLogFree(@RequestBody @Valid PRTransactionLogResource prTransactionLogResource, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type") String plateType, @RequestParam(value = "anonym", required = true) Boolean anonym) {
        HashMap<String, String> responses = prTransactionLogService.createTransactionFree(prTransactionLogResource, plateNumber, plateType, anonym);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);


    }

    @PostMapping(value = "/success")
    public GenericResponse getTransactionsHistoryByUserName(@RequestParam(value = "transactionUUID") String transactionUUID, @RequestParam(value = "decision") String decision, @RequestParam(value = "reason_code") String reasonCode, @RequestParam(value = "transaction_id") String transactionId) {
        log.info("[Controller] POST - QNB Payment success call for transaction UUID {} and the DECISION is {}", transactionUUID, decision);
        HashMap<String, String> responses = prTransactionLogService.updateTopupTransaction(transactionUUID, decision, transactionId, reasonCode);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping("/cron")
    public GenericResponse cron() throws FontFormatException, MessagingException, IOException {
        prTransactionLogService.startCron();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping("/cronDebitCard")
    public GenericResponse cronFahesQpay() throws FontFormatException, IOException {
        fahesQpayTransactionService.startCron();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(prTransactionLogService.count()), Provider.WOQOD);
    }

    @GetMapping("/cronByDate")
    public GenericResponse cronByDate(@RequestParam(value = "date") String date) throws ParseException, FontFormatException {
        log.info("[Controller] POST - Cron : check transaction by date");
        prTransactionLogService.startCronByDate(date);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(true), Provider.WOQOD);
    }

    @GetMapping("/cronByDateDebitCard")
    public GenericResponse cronByDateFahesQpay(@RequestParam(value = "date") String date) throws ParseException, FontFormatException {
        log.info("[Controller] POST - Cron : check debit card transaction by date");
        fahesQpayTransactionService.startCronByDate(date);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(true), Provider.WOQOD);
    }
}