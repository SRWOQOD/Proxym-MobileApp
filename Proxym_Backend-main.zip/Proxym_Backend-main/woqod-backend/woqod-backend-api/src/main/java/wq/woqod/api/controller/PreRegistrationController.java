package wq.woqod.api.controller;


import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.Code128Writer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.querydsl.core.types.Predicate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.PreRegistration;
import wq.woqod.resources.resources.EmailResource;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.PRTransactionLogResource;
import wq.woqod.resources.resources.PreRegistrationResource;
import wq.woqod.service.PRTransactionLogService;
import wq.woqod.service.PreRegistrationService;
import wq.woqod.service.impl.FahesQpayTransactionServiceImpl;
import wq.woqod.service.mapper.PreRegistrationMapper;
import wq.woqod.service.utils.SendMail;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * * The class {@code PreRegistrationController} controls the data
 * of pre registartion model and updates the view whenever data changes
 *
 * @author Meriam Mejri
 */

@Api(value = "Pre Registration Controller")
@RestController
@RequestMapping(value = "/preregistration")
public class PreRegistrationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PreRegistrationController.class);

    private final PreRegistrationService preRegistrationService;
    private final PRTransactionLogService prTransactionLogService;
    private final FahesQpayTransactionServiceImpl fahesQpayTransactionService;
    private final SendMail sendMail;

    @Autowired
    public PreRegistrationController(PreRegistrationService preRegistrationService, PRTransactionLogService prTransactionLogService, FahesQpayTransactionServiceImpl fahesQpayTransactionService, SendMail sendMail) {
        this.preRegistrationService = preRegistrationService;
        this.prTransactionLogService = prTransactionLogService;
        this.fahesQpayTransactionService = fahesQpayTransactionService;
        this.sendMail = sendMail;
    }

    public static byte[] getBarCodeImage(String text, int width, int height) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            HashMap<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<>();
            hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            Writer writer = new Code128Writer();
            BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.CODE_128, width, height);

            MatrixToImageWriter.writeToStream(bitMatrix, "png", byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            LOGGER.info(e.getMessage());
        }
        return byteArrayOutputStream.toByteArray();

    }

    @GetMapping(value = "saveTest")
    public GenericResponse save() throws IOException {
        PreRegistration pr = PreRegistration.builder()
                .car(null)
                .payStatus("")
                .transactionUUID("")
                .finalAmount(14.00)
                .inspectionType("")
                .creationDate(new Date())
                .carCategory(null)
                .referenceNumber("123456789")
                .id(1L)
                .mobileNumber("25252525")
                .build();
        preRegistrationService.save(pr);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);

    }

    @ApiOperation(value = "View a list of Pre Registartion with filter ", response = GenericResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list with filter"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })

    @GetMapping(value = "/filtered")
    public GenericResponse getFiltredPreRegistration(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                     @QuerydslPredicate(root = wq.woqod.dao.entity.PreRegistration.class) Predicate predicate,
                                                     @RequestParam MultiValueMap<String, String> parameters) {
        LOGGER.info("[Controller] GET All Pre Registartion with Filters");
        Page<PreRegistrationResource> preRegistrations = preRegistrationService.getFiltredPreRegistrations(predicate, pageable, parameters);
        PagedModel result = assembler.toModel(preRegistrations);
        List<PreRegistrationResource> preRegistrationResources = Collections.unmodifiableList(preRegistrations.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, preRegistrationResources), Provider.WOQOD);

    }

    @ApiOperation(value = "Delete Pre Registration ", response = GenericResponse.class)
    @DeleteMapping(value = "/{id}")
    public GenericResponse deletePreRegistration(@PathVariable String id) {
        LOGGER.info("DELETE - Pre Registration : id {}", id);
        preRegistrationService.deletePreRegistration(Long.parseLong(id));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Pre Registration by ID ", response = GenericResponse.class)
    @GetMapping(value = "/findById/{id}")
    public GenericResponse findPreRegistrationById(@PathVariable String id) {
        LOGGER.info("[Controller] Get Pre Registration By ID ");
        PreRegistration preRegistration = preRegistrationService.findById(Long.parseLong(id));
        PreRegistrationResource preRegistrationResource = PreRegistrationMapper.mapEntityToPreRegistrationModel(preRegistration);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(preRegistrationResource), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Pre Registration by Reference Number ", response = GenericResponse.class)
    @GetMapping(value = "/findByReferenceNumber/{referenceNumber}")
    public GenericResponse findPreRegistrationByReferenceNumber(@PathVariable String referenceNumber) {
        LOGGER.info("[Controller] Get Pre Registration By ReferenceNumber ");
        PreRegistration preRegistration = preRegistrationService.getPreRegistrationByReferenceNumber(referenceNumber);
        PreRegistrationResource preRegistrationResource = PreRegistrationMapper.mapEntityToPreRegistrationModel(preRegistration);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(preRegistrationResource), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Pre Registration by Reference Number ", response = GenericResponse.class)
    @GetMapping(value = "/findByTransactionuuid")
    public GenericResponse findPreRegistrationByTransactionUUID(@RequestParam(value = "transactionuuid") String transactionuuid) {
        LOGGER.info("[Controller] Get Pre Registration By Transactionuuid ");
        PreRegistration preRegistration = preRegistrationService.findPreRegistrationByTransactionUUID(transactionuuid);
        PreRegistrationResource preRegistrationResource = PreRegistrationMapper.mapEntityToPreRegistrationModel(preRegistration);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(preRegistrationResource), Provider.WOQOD);
    }

    @ApiOperation(value = "Update Pre Registration ", response = GenericResponse.class)
    @PutMapping(value = "/update")
    public GenericResponse updatePreRegistartion(@RequestBody @Valid PreRegistrationResource preRegistrationResource) throws ParseException {
        LOGGER.info("[Controller] Update Registration  ");
        preRegistrationService.update(PreRegistrationMapper.mapModelToPreRegistration(preRegistrationResource));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(preRegistrationResource), Provider.WOQOD);
    }

    @ApiOperation(value = "Send Mail with barcode ", response = GenericResponse.class)
    @GetMapping(value = "/sendMailBo")
    public GenericResponse sendBo(@RequestParam(value = "reference_number") String referencenumber, @RequestParam(value = "transactionuuid") String transactionuuid) throws FontFormatException {
        PreRegistration preRegistration = preRegistrationService.getPreRegistrationByReferenceNumber(referencenumber);

        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(preRegistrationService.sendFahesRegistrationReceiptByEmailFromBo(preRegistration)), Provider.WOQOD);
    }

    @ApiOperation(value = "Send Mail with barcode ", response = GenericResponse.class)
    @PostMapping(value = "/sendMail")
    public GenericResponse send(@RequestBody EmailResource emailResource) throws Exception {
        LOGGER.info("reference_number: {} && email: {}", emailResource.getReferencenumber(), emailResource.getEmail());
        PreRegistration preRegistration = preRegistrationService.getPreRegistrationByReferenceNumber(emailResource.getReferencenumber());
        boolean resp = false;
        if (emailResource.getConnected()) {
            resp = sendMail.send(preRegistration.getCar().getOwner().getEmail(), preRegistrationService.generatePDF(preRegistration));
        } else {
            resp = sendMail.send(URLDecoder.decode(emailResource.getEmail(), "UTF-8"), preRegistrationService.generatePDF(preRegistration));
        }

        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(resp), Provider.WOQOD);
    }

    @ApiOperation(value = "Get barcode image ", response = GenericResponse.class)
    @GetMapping(value = "/barcode/{referenceNumber}")
    public void barcode(@PathVariable("referenceNumber") String referenceNumber, HttpServletResponse response) throws IOException {
        response.setContentType("image/png");
        OutputStream outputStream = response.getOutputStream();
        outputStream.write(getBarCodeImage(referenceNumber, 200, 200));
        outputStream.flush();
        outputStream.close();
    }

    @ApiOperation(value = "Get image base64 string", response = GenericResponse.class)
    @GetMapping(value = "/barcodeGenerator/{id}")
    public GenericResponse generateBarcode(@PathVariable String id) throws FontFormatException {

        PreRegistration preregistration = preRegistrationService.findById(Long.parseLong(id));

        String string = preRegistrationService.generateEReceipt(preregistration);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(string), Provider.WOQOD);

    }

    @ApiOperation(value = "Get pdf base64 string", response = GenericResponse.class)
    @GetMapping(value = "/generatePDF")
    public GenericResponse generatePDF(@RequestParam(value = "reference_number") String referencenumber) throws FontFormatException {
        LOGGER.info("[Controller] GET - PreRegistration : generatePDF");

        PreRegistration preregistration = preRegistrationService.getPreRegistrationByReferenceNumber(referencenumber);

        String string = preRegistrationService.generatePDF(preregistration);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(string), Provider.WOQOD);

    }

    @ApiOperation(value = "Get PreRegistration By qid", response = GenericResponse.class)
    @GetMapping(value = "/findByQid")
    public GenericResponse findByQid(@RequestParam(value = "qid") String qid) {
        List<PreRegistrationResource> preRegistrations = preRegistrationService.findByQid(qid);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(preRegistrations), Provider.WOQOD);

    }

    @GetMapping(value = "/preregistrations")
    public GenericResponse<ListResponse<PreRegistrationResource>> getPreRegistrationBo(@RequestParam MultiValueMap<String, String> parameters) {
        LOGGER.info("[Controller] GET Pre Registration find all for BO ");
        List<PreRegistrationResource> preRegistrationResourceList = preRegistrationService.getAllPreRegistrations(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(preRegistrationResourceList), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(preRegistrationService.count()), Provider.WOQOD);
    }
}
