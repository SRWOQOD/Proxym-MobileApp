package wq.woqod.api.validator;

import org.springframework.util.StringUtils;
import wq.woqod.commons.exception.InputDataMissingException;
import wq.woqod.resources.resources.StationUpdateResource;

import java.util.List;

/**
 * Created by bfitouri on 02/01/17.
 */
public class StationValidator {
    private StationValidator() {
    }

    public static void prePut(List<StationUpdateResource> resources) {
        resources.forEach(resource -> prePut(resource));
    }

    public static void prePut(StationUpdateResource resource) {
        if (StringUtils.isEmpty(resource.getStationId())) {
            throw new InputDataMissingException("StationId");
        }
    }
}