package wq.woqod.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.exception.RestBackendException;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.Reservations;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.resources.resources.reservation.*;
import wq.woqod.service.ReservationService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/reservation")
public class ReservationController {
    private final ReservationService reservationService;

    @Autowired
    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }


    @GetMapping(value = "/getAvailableStations")
    public GenericResponse getAvailableStations(@RequestParam String preReservationReferenceId) throws RestBackendException, IOException {
        List<AvailableStationsResource> list = reservationService.getAvailableStations(preReservationReferenceId);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping(value = "/availableByCustomer")
    public GenericResponse isReservationAvailable(@RequestParam String customerId) throws RestBackendException, IOException {
       boolean responce= reservationService.isReservationAvailable(customerId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(responce), Provider.WOQOD);
    }

    @GetMapping(value = "/getPlateTypeWithShape")
    public GenericResponse getPlateTypeWithShape() throws RestBackendException, JsonProcessingException {
        List<PlateTypeWithShapeResource> list = reservationService.getPlateTypeWithShape();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @PostMapping(value = "/getPreReservationReference")
    public GenericResponse getPreReservationReference(@RequestBody PreReservationResource preReservationResource) throws RestBackendException, IOException {
        PreReservationResource reference = reservationService.getPreReservationReference(preReservationResource);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(reference), Provider.WOQOD);
    }

    @PostMapping(value = "/otpValidation")
    public GenericResponse otpValidation(@RequestParam String preReservationReferenceId, @RequestParam String otp) throws RestBackendException, IOException {
        Boolean reference = reservationService.otpValidation(preReservationReferenceId, otp);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(reference), Provider.WOQOD);
    }

    @PutMapping(value = "/resendOtp")
    public GenericResponse resendOtp(@RequestParam String preReservationReferenceId) throws RestBackendException, IOException {
        Boolean reference = reservationService.resendOtp(preReservationReferenceId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(reference), Provider.WOQOD);
    }

    @GetMapping(value = "/getSlots")
    public GenericResponse getSlots(@RequestParam String preReservationReferenceId,
                                    @RequestParam String stationId,
                                    @RequestParam String date) throws RestBackendException, IOException {
        List<AvailableSlotsResource> list = reservationService.getSlots(preReservationReferenceId, stationId, date);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping(value = "/getAppointmentDates")
    public GenericResponse getAppointmentDates(@RequestParam String preReservationReferenceId,
                                    @RequestParam String stationId) throws RestBackendException, IOException {
        List<AppointmentDateResource> list = reservationService.getAppointmentDates(preReservationReferenceId, stationId);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping(value = "/rescheduling")
    public GenericResponse rescheduling(@RequestParam String reservationId) throws RestBackendException, IOException {
        Long id = reservationService.rescheduling(reservationId);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(id), Provider.WOQOD);
    }

    @PostMapping(value = "/getDetails")
    public GenericResponse getDetails(@RequestBody PreReservationResource preReservationResource) throws RestBackendException, IOException {
        ReservationResource resource = reservationService.getDetails(preReservationResource);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(resource), Provider.WOQOD);
    }

    @PostMapping(value = "/reservation")
    public GenericResponse<ObjectResponse<ReservationResource>> reservation(@RequestParam String vehiculeShapeName,
                                       @RequestParam String preReservationReferenceId,
                                       @RequestParam String userType,
                                       @RequestParam String slotId
                                       ) throws RestBackendException, IOException {
        ReservationResource resource = reservationService.reservation(vehiculeShapeName, preReservationReferenceId, slotId,userType);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(resource), Provider.WOQOD);
    }

    @PostMapping(value = "/cancellation")
    public GenericResponse cancellation(@RequestParam String reservationId) throws RestBackendException, IOException {
        Boolean resource = reservationService.cancellation(reservationId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(resource), Provider.WOQOD);
    }


    @PostMapping(value = "/getDetailsByCustomer")
    public GenericResponse getDetailsByCustomer(@RequestParam String customerId) throws RestBackendException, IOException {
        List<ReservationResource> resource = reservationService.getDetailsByCustomer(customerId);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(resource), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFiltredReservation(Pageable pageable, PagedResourcesAssembler assembler,
                                                 @QuerydslPredicate(root = Reservations.class) Predicate predicate,
                                                 @RequestParam Map<String, String> parameters) {
        Page<ReservationResource> resources = reservationService.getFilteredList(predicate, pageable, parameters);
        PagedModel result = assembler.toModel(resources);
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, resources.getContent()), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(reservationService.count()), Provider.WOQOD);
    }

    @PostMapping(value = "/canPayOnline")
    public GenericResponse canPayOnline(@RequestParam String preReservationReferenceId,
                                    @RequestParam String slotId) throws RestBackendException, IOException {
        Boolean response = reservationService.canPayOnline(preReservationReferenceId, slotId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }

    @PostMapping(value = "/vehiculeDetails")
    public GenericResponse vehiculeDetails(@RequestParam String customerId,
                                        @RequestParam String plateNumber, @RequestParam String plateTypeId) throws RestBackendException, IOException {
        CarResource resource = reservationService.vehiculeDetails(customerId, plateNumber, plateTypeId);
        return ResponseBuilder.buildSuccessResponse((new ObjectResponse<>(resource)), Provider.WOQOD);
    }

    @PostMapping(value = "/vehiculeRegistrationValidity")
    public GenericResponse vehiculeRegistrationValidity(@RequestParam String customerId,
                                           @RequestParam String plateNumber, @RequestParam String plateTypeId) throws RestBackendException, IOException {
        VehiculeRegistrationResource response = reservationService.vehiculeRegistrationValidity(customerId, plateNumber, plateTypeId);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(response), Provider.WOQOD);
    }

    @GetMapping(value = "/reservations")
    public GenericResponse<ListResponse<ReservationResource>> getAllReservations(@RequestParam MultiValueMap<String, String> parameters) {

        List<ReservationResource> reservations = reservationService.getReservations(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(reservations), Provider.WOQOD);
    }


}
