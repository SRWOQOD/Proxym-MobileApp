package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.TendersResource;
import wq.woqod.service.TendersService;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping(value = "/tenders")
public class TendersController {

    private final TendersService tendersService;

    @Autowired
    public TendersController(TendersService tendersService) {
        this.tendersService = tendersService;
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<TendersResource>> getFilteredTenders(@PageableDefault(sort = {"closingDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                               @RequestParam MultiValueMap<String, String> parameters) {
        Page<TendersResource> tenders = tendersService.getFilteredTenders(pageable, parameters);
        PagedModel result = assembler.toModel(tenders);
        List<TendersResource> tendersResources = Collections.unmodifiableList(tenders.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, tendersResources), Provider.WOQOD);
    }

    @GetMapping(value = "/tenders")
    public GenericResponse<PaginatedListResponse<TendersResource>> getTenders(@PageableDefault(sort = "sRNo",
            direction = Sort.Direction.DESC) Pageable pageable , PagedResourcesAssembler assembler) {
        Page<TendersResource> tenders = tendersService.getTenders(pageable);
        PagedModel result = assembler.toModel(tenders);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse<>(result, tenders.getContent())), Provider.WOQOD);
    }

    @GetMapping(value = "/tendersBo")
    public GenericResponse<PaginatedListResponse<TendersResource>> getTendersBo(@RequestParam MultiValueMap<String, String> parameters, @PageableDefault(sort = "lastSynchronisationDate",
            direction = Sort.Direction.DESC) Pageable pageable , PagedResourcesAssembler assembler) {
        Page<TendersResource> tenders = tendersService.getAllTenders(parameters, pageable);
        PagedModel result = assembler.toModel(tenders);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse<>(result, tenders.getContent())), Provider.WOQOD);

    }


    @GetMapping(value = "/paginatedTenders")
    public GenericResponse<PaginatedListResponse<TendersResource>> getPaginatedTenders(@PageableDefault(sort = "lastSynchronisationDate",
            direction = Sort.Direction.DESC) Pageable pageable , PagedResourcesAssembler assembler) {
        Page<TendersResource> tenders = tendersService.getPaginatedTenders(pageable);
        PagedModel result = assembler.toModel(tenders);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse<>(result, tenders.getContent())), Provider.WOQOD);
    }

}
