package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PetrolResource;
import wq.woqod.service.PetrolPricingService;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping(value = "/petrol")
@Slf4j
public class PetrolPricingController {

    private final PetrolPricingService petrolPricingService;

    @Autowired
    public PetrolPricingController(PetrolPricingService petrolPricingService) {
        this.petrolPricingService = petrolPricingService;
    }

    @GetMapping(value = "/prices")
    public GenericResponse getPetrolPrices() {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(petrolPricingService.getAllPetrolPricing()), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFiltredPrices(Pageable pageable, PagedResourcesAssembler assembler,
                                            @RequestParam MultiValueMap<String, String> parameters) {
        Page<PetrolResource> petrolResources = petrolPricingService.getFilteredPrices(pageable, parameters);
        PagedModel result = assembler.toModel(petrolResources);
        List<PetrolResource> petrolResourceListFiltered = petrolResources.getContent().stream().collect(Collectors.groupingBy(PetrolResource::getName)).values().stream()
                .map(plans -> plans.stream().findFirst().get())
                .collect(Collectors.toList());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, petrolResourceListFiltered), Provider.WOQOD);
    }

}