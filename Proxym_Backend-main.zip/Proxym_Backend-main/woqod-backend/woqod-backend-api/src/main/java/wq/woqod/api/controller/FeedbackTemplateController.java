package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FeedbackTemplateResource;
import wq.woqod.service.FeedbackTemplateService;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;

/**
 * Created by Samia DHAHRI on 08/06/20.
 */
@RestController
@RequestMapping(value = "/templates")
public class FeedbackTemplateController {

    private final FeedbackTemplateService feedbackTemplateService;

    @Autowired
    public FeedbackTemplateController(final FeedbackTemplateService feedbackTemplateService) {
        this.feedbackTemplateService = feedbackTemplateService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> getAllFeedbackTemplates(@RequestParam MultiValueMap<String, String> parameters) {
        List<FeedbackTemplateResource> templateResources = feedbackTemplateService.getAllTemplates(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(templateResources), Provider.WOQOD);
    }

    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> createFeedbackTemplate(@RequestBody @Valid FeedbackTemplateResource templateResource) {
        feedbackTemplateService.create(templateResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> updateFeedbackTemplate(@RequestBody @Valid FeedbackTemplateResource templateResource) {
        feedbackTemplateService.update(templateResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/template/{id}")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> getFeedbackTemplate(@PathVariable Long id) {
        FeedbackTemplateResource feedbackTemplateResource = feedbackTemplateService.find(id);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feedbackTemplateResource), Provider.WOQOD);
    }

    @GetMapping(value = "/templatebytitle/{title}")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> getFeedbackTemplateByTitle(@PathVariable String title) {
        FeedbackTemplateResource feedbackTemplateResource = feedbackTemplateService.findByTitle(title);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feedbackTemplateResource), Provider.WOQOD);
    }

    @DeleteMapping(value = "/template/{id}")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> deleteFeedbackTemplate(@PathVariable Long id) {
        feedbackTemplateService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<FeedbackTemplateResource>> getFilteredFeedbackTemplates(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                                  @RequestParam MultiValueMap<String, String> parameters) {
        Page<FeedbackTemplateResource> feedbackTemplates = feedbackTemplateService.getFilteredFeedbackTemplates(pageable, parameters);
        PagedModel result = assembler.toModel(feedbackTemplates);
        List<FeedbackTemplateResource> feedbackResources = Collections.unmodifiableList(feedbackTemplates.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, feedbackResources), Provider.WOQOD);
    }
    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(feedbackTemplateService.count()), Provider.WOQOD);
    }
}
