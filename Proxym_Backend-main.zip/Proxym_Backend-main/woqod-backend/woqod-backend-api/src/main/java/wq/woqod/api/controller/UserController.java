package wq.woqod.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.api.validator.UserValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.enumerations.UserTypeEnum;
import wq.woqod.resources.resources.*;
import wq.woqod.service.AreaService;
import wq.woqod.service.UserService;
import wq.woqod.service.mapper.UserModelMapperService;
import wq.woqod.service.mapper.UserResourceMapper;
import wq.woqod.service.models.User;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Created by bfitouri on 14/11/16.
 */
@Slf4j
@RestController
@RequestMapping(value = "/users")
public class UserController {

    private final UserService userService;
    private final UserModelMapperService userModelMapperService;
    private final AreaService areaService;

    @Autowired
    public UserController(final UserService userService, final UserModelMapperService userModelMapperService, AreaService areaService) {
        this.userService = userService;
        this.userModelMapperService = userModelMapperService;
        this.areaService = areaService;
    }

    @PostMapping(value = "/manager")
    public GenericResponse createCorporateManagerUser(@RequestBody @Valid CorporateUserResource userResource) {
        UserValidator.prePost(userResource);
        userService.createCorporateManagerUser(userModelMapperService.mapToCorporateUserModel(userResource, true));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/employees/anonymous")
    public GenericResponse createAnonymousEmployees(@RequestBody @Valid AnonymousEmployeeResource anonymousEmployeeResource) {
        List<User> users = userService.createCorporateAnonymousEmployees(anonymousEmployeeResource.getNumber(), anonymousEmployeeResource.getCompanyId());
        EmployeesResource employeesResource = UserResourceMapper.mapToEmployeesResource(users);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(employeesResource), Provider.WOQOD);
    }

    @PostMapping(value = "/employees/archive")
    public GenericResponse archive(@RequestBody EmployeesResource employeesResource) {
        UserValidator.prePost(employeesResource.getEmployees());
        List<User> employees = employeesResource.getEmployees().stream()
                .map(employeeResource -> userModelMapperService.mapToEmployeeUserModel(employeeResource, true))
                .collect(Collectors.toList());
        List<User> users = userService.archive(employees, employeesResource.getCompanyId());
        EmployeesResource result = UserResourceMapper.mapToEmployeesResource(users);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(result), Provider.WOQOD);
    }

    @PutMapping(value = "/employees/anonym/send")
    public GenericResponse sendCredentialsToAll(@RequestBody @Valid EmployeesResource employeesResource) {
        UserValidator.prePut(employeesResource.getEmployees());
        List<User> employees = employeesResource.getEmployees().stream()
                .map(employeeResource -> userModelMapperService.mapToEmployeeUserModel(employeeResource, true))
                .collect(Collectors.toList());
        userService.sendEmployeesCredentials(employees, employeesResource.getCompanyId(), false);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/employees/identified/send")
    public GenericResponse sendCredentialsToManager(@RequestBody EmployeesResource employeesResource) {
        UserValidator.prePut(employeesResource.getEmployees());
        List<User> employees = employeesResource.getEmployees().stream()
                .map(employeeResource -> userModelMapperService.mapToEmployeeUserModel(employeeResource, true))
                .collect(Collectors.toList());
        userService.sendEmployeesCredentials(employees, employeesResource.getCompanyId(), true);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/updateUser")
    public GenericResponse updateUserBO(@RequestBody @Valid UserRegisterResource userResource, HttpServletRequest request) throws JsonProcessingException {
        AreaResource areaResource = areaService.findbyId(userResource.getIdArea());
        User user = userService.updateUserBo(userModelMapperService.mapToRegisterUserModel(userResource, false, areaResource), userResource, request.getRemoteAddr());
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(UserResourceMapper.mapToUserResource(user)), Provider.WOQOD);
    }

    @PutMapping(value = "")
    public GenericResponse updateUser(@RequestBody @Valid UserUpdateResource userResource) throws JsonProcessingException {
        AreaResource areaResource = areaService.findbyId(userResource.getIdArea());
        User user = userService.updateUser(userModelMapperService.mapToUpdateUserModel(userResource, areaResource), userResource.getIpAddress());
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(UserResourceMapper.mapToUserResource(user)), Provider.WOQOD);
    }

    @GetMapping(value = "/{username:.+}")
    public GenericResponse getUserByUserName(@PathVariable String username) {
        String encodedUserName;
        try {
            encodedUserName = URLDecoder.decode(username, "utf-8");
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError("UTF-8 not supported");
        }
        User user = userService.getUserByUserName(encodedUserName);
        UserResource userResource = UserResourceMapper.mapToIndividualUserResource(user);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(userResource), Provider.WOQOD);
    }

    @GetMapping(value = "/getUser/{username:.+}")
    public GenericResponse getUserByUserNamebo(@PathVariable String username) {
        String encodedUserName;
        try {
            encodedUserName = URLDecoder.decode(username, "utf-8");
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError("UTF-8 not supported");
        }

        User user = userService.getUserDetailsByUserName(encodedUserName);
        UserResource userResource = UserResourceMapper.mapToIndividualUserResourcebo(user);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(userResource), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse getUserByUserNameAndUserType(@RequestParam(value = "username") String userName,
                                                        @RequestParam(value = "usertype") UserTypeEnum userType) {
        User user = userService.getUserByUserNameAndType(userName, userType);
        UserResource userResource = UserResourceMapper.mapToUserResource(user);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(userResource), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFilteredUsers(Pageable pageable, PagedResourcesAssembler assembler,
                                            @QuerydslPredicate(root = wq.woqod.dao.entity.User.class) Predicate predicate,
                                            @RequestParam MultiValueMap<String, String> parameters) {
        Page<User> users = userService.getFilteredUsers(pageable, predicate, parameters);
        PagedModel result = assembler.toModel(users);
        List<UserResource> userResources = Collections.unmodifiableList(UserResourceMapper.mapToUsersResource(users.getContent()));
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, userResources), Provider.WOQOD);
    }

    @GetMapping(value = "/users")
    public GenericResponse getusers(@RequestParam MultiValueMap<String, String> parameters) {

        List<UserResource> users = userService.getusers(parameters);

        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(users), Provider.WOQOD);

    }

    @DeleteMapping(value = "/delete")
    public GenericResponse deleteUser(@RequestParam(value = "username") String userName) {
        UserValidator.preDelete(userName);
        userService.deleteUser(userName);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/block")
    public GenericResponse blockUser(@RequestBody @Valid BlockUserResource blockUserResource) {
        UserValidator.preBlock(blockUserResource.getUserName(), blockUserResource.getStatus());
        userService.blockUser(blockUserResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/password")
    public GenericResponse resetPassword(@RequestBody @Valid UserPasswordResource userPasswordResource) {
        userService.resetPassword(userPasswordResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/unlock/{username}")
    public GenericResponse unlock(@PathVariable String username) {
        userService.unlock(username);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping("/updateProfilePhoto")
    public GenericResponse updateProfilePhoto(@RequestBody UpdatePhotoResource userResource) {
        User user = userService.updateProfilePhoto(userResource);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(UserResourceMapper.mapToUserResource(user)), Provider.WOQOD);
    }

    @GetMapping("/getProfilePhoto")
    public GenericResponse getProfilePhoto(@RequestParam String username) {
        String profilePictureByCustomerNumber = userService.getProfilePhotoByUserName(username);
        if (profilePictureByCustomerNumber == null) {
            return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(null), Provider.WOQOD);
        }
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(profilePictureByCustomerNumber), Provider.WOQOD);
    }

    @GetMapping("/getProfilePhotoBo")
    public GenericResponse getProfilePhotoBO(@RequestParam String username) {
        String profilePictureByCustomerNumber = userService.getProfilePhotoByUserNameBO(username);
        if (profilePictureByCustomerNumber == null) {
            return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(null), Provider.WOQOD);
        }
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(profilePictureByCustomerNumber), Provider.WOQOD);
    }

    @PostMapping(value = "/updatePhoto")
    public GenericResponse updatePhoto(@RequestParam String username, @RequestParam(value = "photo", required = false) String photo) {
        byte[] sformatter = photo.getBytes(StandardCharsets.UTF_8);
        userService.updateProfilePhoto(username, Base64.getEncoder().encodeToString(sformatter));
        User user = userService.getUserByUserNameAndType(username, UserTypeEnum.Individual_Customer);
        UserResource userResource = UserResourceMapper.mapToUserResource(user);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(userResource), Provider.WOQOD);
    }


    @GetMapping(value = "/usernameCheck")
    public GenericResponse usernameCheck(@RequestParam String username) {
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(userService.usernameCheck(username)), Provider.WOQOD);
    }

    /**
     * User Register - STEP1
     *
     * @param userCheckResource
     * @return
     */
    @PostMapping(value = "/checkUser")
    public GenericResponse checkUser(@RequestBody UserCheckResource userCheckResource) {
        userService.checkUser(userCheckResource.getQid(), userCheckResource.getPhone(), userCheckResource.getEmail(), userCheckResource.getUsername());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/updatePhoneNumber")
    public GenericResponse updatePhoneNumber(@RequestBody ProfileUpadateRessource profileUpadateRessource, String remoteIpAddress) {
        userService.updatePhoneNumber(profileUpadateRessource.getUsername(), profileUpadateRessource.getPhone(), remoteIpAddress);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/updateEmail")
    public GenericResponse updateEmail(@RequestBody ProfileUpadateRessource profileUpadateRessource,  String remoteIpAddress) {
        userService.updateEmail(profileUpadateRessource.getUsername(), profileUpadateRessource.getEmail(), remoteIpAddress);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/sendMail")
    public GenericResponse sendMail(@RequestBody ProfileUpadateRessource profileUpadateRessource) {
        log.info("user name : {} && email: {}", profileUpadateRessource.getUsername(), profileUpadateRessource.getEmail());
        boolean resp;
        resp = userService.sendMailToUpdateUserEmail(profileUpadateRessource.getEmail(), profileUpadateRessource.getUsername());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(resp), Provider.WOQOD);
    }

    @PostMapping(value = "/deleteFromLdap")
    public GenericResponse deleteFromLdap(@RequestParam String user) {
        userService.deleteFromLdap(user);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(userService.count()), Provider.WOQOD);
    }

    @GetMapping("/checkWoqodeUsers")
    public GenericResponse checkWoqodeUsers() {
        userService.checkIfWoqodeUser();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


}


