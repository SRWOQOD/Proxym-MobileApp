package wq.woqod.api.validator;


import org.apache.commons.lang3.StringUtils;
import wq.woqod.commons.exception.BlockNotAllowed;
import wq.woqod.commons.exception.InputDataMissingException;
import wq.woqod.resources.enumerations.LanguageEnum;
import wq.woqod.resources.enumerations.UserTypeEnum;
import wq.woqod.resources.resources.CorporateUserResource;
import wq.woqod.resources.resources.EmployeeUserResource;
import wq.woqod.resources.resources.IndividualUserResource;
import wq.woqod.resources.resources.UserResource;

import java.util.List;
import java.util.Objects;

/**
 * Created by bfitouri on 02/01/17.
 */
public class UserValidator {
    private UserValidator() {
    }

    public static void prePost(CorporateUserResource resource) {
        DefaultResourceValidator.prePost(resource);
        DefaultResourceValidator.prePost(resource.getCompany());
    }

    public static void prePost(IndividualUserResource resource, LanguageEnum language) {
        DefaultResourceValidator.prePost(resource);
        validate(resource);
        if ((!(LanguageEnum.isArabic(language))) && (!(LanguageEnum.isEnglish(language)))) {
            throw new InputDataMissingException("language");
        }
    }

    public static void prePost(List<EmployeeUserResource> resources) {
        resources.forEach(resource -> DefaultResourceValidator.prePost(resource));
    }

    public static void prePut(List<EmployeeUserResource> resources) {
        resources.forEach(resource -> DefaultResourceValidator.prePut(resource));
    }

    public static void validate(UserResource resource) {
        if (StringUtils.isBlank(resource.getMobileNumber())) {
            throw new InputDataMissingException("mobile Number");
        }
        if (StringUtils.isBlank(resource.getEmail())) {
            throw new InputDataMissingException("email");
        }
        if (StringUtils.isBlank(resource.getFirstName())) {
            throw new InputDataMissingException("firstname");
        }
        if (StringUtils.isBlank(resource.getLastName())) {
            throw new InputDataMissingException("familyName");
        }
        if (Objects.isNull(resource.getBirthdate())) {
            throw new InputDataMissingException("birthdate");
        }
    }

    public static void prePut(UserResource resource) {
        DefaultResourceValidator.prePut(resource);
        if (UserTypeEnum.isCorporateManager(resource.getType())) {
            prePutCorporateUser((CorporateUserResource) resource);
        }
        if (UserTypeEnum.isCorporateEmployee(resource.getType())) {
            prePutEmployeeUser((EmployeeUserResource) resource);
        }
        if (UserTypeEnum.isIndividual(resource.getType())) {
            validate(resource);
        }
        if (Objects.isNull(resource.getStatus())) {
            throw new InputDataMissingException("patStatus");
        }
    }

    public static void prePutCorporateUser(CorporateUserResource resource) {
        DefaultResourceValidator.prePut(resource.getCompany());
        if (Objects.isNull(resource.getDesignationRoles())) {
            throw new InputDataMissingException("designationRoles");
        }
    }

    public static void prePutEmployeeUser(EmployeeUserResource resource) {
        if (Objects.isNull(resource.getDesignationRoles())) {
            throw new InputDataMissingException("designationRoles");
        }
    }

    public static void preSendRecoveryCode(String username, LanguageEnum language) {
        if (StringUtils.isBlank(username)) {
            throw new InputDataMissingException(username);
        }
        if ((!(LanguageEnum.isArabic(language))) && (!(LanguageEnum.isEnglish(language)))) {
            throw new InputDataMissingException("language");
        }
    }

    public static void preDelete(String username) {
        if (StringUtils.isBlank(username)) {
            throw new InputDataMissingException(username);
        }
    }

    public static void preBlock(String username, wq.woqod.resources.enumerations.StatusEnum status) {
        if (StringUtils.isBlank(username)) {
            throw new InputDataMissingException(username);
        }
        if ((!(wq.woqod.resources.enumerations.StatusEnum.isActive(status))) && (!(wq.woqod.resources.enumerations.StatusEnum.isInActive(status)))) {
            throw new BlockNotAllowed();
        }
    }
}
