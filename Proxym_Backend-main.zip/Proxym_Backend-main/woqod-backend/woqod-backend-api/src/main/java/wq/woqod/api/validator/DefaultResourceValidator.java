package wq.woqod.api.validator;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import wq.woqod.commons.exception.IdNotRequiredException;
import wq.woqod.commons.exception.IdRequiredException;
import wq.woqod.resources.resources.WoqodResource;

import java.util.Collection;

/**
 * Created by bfitouri on 02/01/17.
 */
public final class DefaultResourceValidator {
    private DefaultResourceValidator() {
    }

    public static void prePost(WoqodResource resource) {
        if (!StringUtils.isEmpty(resource.getId())) {
            throw new IdNotRequiredException("POST");
        }
    }

    public static void prePut(WoqodResource resource) {
        if (StringUtils.isEmpty(resource.getId())) {
            throw new IdRequiredException("PUT");
        }
    }

    public static void prePost(Collection<? extends WoqodResource> resources) {
        if (!CollectionUtils.isEmpty(resources)) {
            resources.forEach(resource -> prePost(resource));
        }
    }

    public static void prePut(Collection<? extends WoqodResource> resources) {
        if (!CollectionUtils.isEmpty(resources)) {
            resources.forEach(resource -> prePut(resource));
        }
    }

}
