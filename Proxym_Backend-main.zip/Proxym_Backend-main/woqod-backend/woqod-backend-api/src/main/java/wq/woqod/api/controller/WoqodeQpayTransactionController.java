package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.QpayInquiryResponseResource;
import wq.woqod.resources.resources.QpayRefundResponseResource;
import wq.woqod.resources.resources.WoqodeQpayTransactionResource;
import wq.woqod.service.WoqodeQpayTransactionService;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.HashMap;

@RestController
@RequestMapping(value = "/payement/qpay")
@Slf4j
public class WoqodeQpayTransactionController {

    private final WoqodeQpayTransactionService transactionService;

    public WoqodeQpayTransactionController(WoqodeQpayTransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping(value = "/createTransaction")
    public GenericResponse createTransaction(@RequestBody WoqodeQpayTransactionResource ressource) throws ParseException {
        transactionService.createTransaction(ressource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @PutMapping(value = "/updateTopupQpayTransaction")
    public GenericResponse updateTopupQpayTransaction(@RequestParam(value = "pun") String pun,
                                                      @RequestParam(value = "statusEnum") TransactionStatusEnum statusEnum,
                                                      @RequestParam(value = "statusCode") String statusCode,
                                                      @RequestParam(value = "statusMessage") String statusMessage,
                                                      @RequestParam(value = "transactionID") String transactionID,
                                                      @RequestParam(value = "RPSStatus") String rpsStatus) throws ParseException {


        WoqodeQpayTransactionResource transactionLogModel = transactionService.updateTransactionStatus(pun, statusCode, statusMessage, transactionID, rpsStatus, statusEnum);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(transactionLogModel), Provider.WOQOD);
    }

    @PostMapping(value = "/success", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public GenericResponse afterPaiementCallBack(@RequestParam(value = "pun") String pun, @RequestParam String statusCode, @RequestParam String statusMessage) throws UnsupportedEncodingException {
        log.info("[Controller] POST - CBQ Payment success call for PUN {} and the DECISION is {}", pun, statusCode);
        HashMap<String, String> responses = transactionService.updateTopupTransaction(pun, statusCode, statusMessage);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping(value = "/getTransaction")
    public GenericResponse getTransactionByPun(@RequestParam(value = "pun") String pun) {
        WoqodeQpayTransactionResource model = transactionService.findByPun(pun);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(model), Provider.WOQOD);
    }

    @PostMapping(value = "/inquiryTransaction")
    public GenericResponse getInquiryTransaction(@RequestParam(value = "pun") String originalPun) throws IOException {
        log.info("[Controller] POST -QPAY Payment Inquiry Transaction call for transaction PUN {} ", originalPun);
        QpayInquiryResponseResource response = transactionService.getInquiryTransaction(originalPun);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(response), Provider.WOQOD);
    }

    @GetMapping(value = "/refundTransaction")
    public GenericResponse refundTransaction(@RequestParam(value = "pun") String pun, @RequestParam(value = "amount") String amount) throws IOException {
        log.info("[Controller] POST -QPAY Payment Refund Transaction call for transaction");
        QpayRefundResponseResource responses = transactionService.refundTransaction(pun, amount);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping("/cronByDate")
    public GenericResponse cronByDate(@RequestParam(value = "date") String date) throws ParseException {
        log.info("[Controller] POST - Cron : check debit card transaction by date");
        transactionService.startCronByDate(date);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(true), Provider.WOQOD);
    }
}
