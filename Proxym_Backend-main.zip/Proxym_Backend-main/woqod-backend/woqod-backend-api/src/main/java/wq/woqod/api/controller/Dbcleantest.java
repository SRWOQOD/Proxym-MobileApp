package wq.woqod.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.dao.UserDao;
import wq.woqod.dao.entity.User;
import wq.woqod.service.client.LdapClient;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/dbcleantest")
class Dbcleantest {
    private final UserDao userDao;
    private final LdapClient ldapClient;

    public Dbcleantest(UserDao userDao, LdapClient ldapClient) {
        this.userDao = userDao;
        this.ldapClient = ldapClient;
    }

//    @GetMapping(value = "")
//    public GenericResponse<ListResponse<String>> getDevicesByOwner() {
//        List<String> names = new ArrayList<>();
//        List<User> l = userDao.all();
//        for (User u : l
//        ) {
//            try {
//                ldapClient.getUserByUserName(u.getUserName());
//            } catch (Exception e) {
//                names.add(u.getUserName());
//            }
//
//        }
//        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(names), Provider.WOQOD);
//    }

}
