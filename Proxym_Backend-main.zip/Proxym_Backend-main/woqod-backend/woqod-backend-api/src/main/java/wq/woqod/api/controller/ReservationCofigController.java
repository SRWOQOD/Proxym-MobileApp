package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.ConfigRessource;
import wq.woqod.service.ConfigService;

@RestController
@Slf4j
@RequestMapping(value = "/reservation-config")
public class ReservationCofigController {

    private final ConfigService configService;

    public ReservationCofigController(ConfigService configService) {
        this.configService = configService;
    }


    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<ConfigRessource>> isReservationHidden() {
        log.info("[TopBannerController] is Reservation Hidden ?");
        ConfigRessource configRessource = configService.isReservationHidden();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(configRessource.getValue()), Provider.WOQOD);
    }


    @PutMapping(value = "")
    public GenericResponse<ObjectResponse<BooleanResponse>>  updateReservation() {
        log.info("[ConfigController]update Reservation");
        configService.updateReservationConfig();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
     }
}
