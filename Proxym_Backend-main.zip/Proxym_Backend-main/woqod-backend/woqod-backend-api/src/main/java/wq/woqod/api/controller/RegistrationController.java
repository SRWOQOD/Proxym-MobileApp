package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;
import wq.woqod.api.validator.RegistrationValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.enumerations.LanguageEnum;
import wq.woqod.resources.resources.Activation;
import wq.woqod.resources.resources.ActivationResource;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.resources.resources.UserRegisterResource;
import wq.woqod.service.AreaService;
import wq.woqod.service.RegistrationService;
import wq.woqod.service.mapper.UserModelMapperService;

import javax.validation.Valid;

/**
 * Created by bfitouri on 14/11/16.
 */
@RestController
public class RegistrationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(RegistrationController.class);
    private final RegistrationService registerService;
    private final UserModelMapperService userModelMapperService;
    private final AreaService areaService;
    @Autowired
    private Environment environment;
    @Value("${devMod:false}")
    private Boolean devMod;

    @Autowired
    public RegistrationController(final RegistrationService registerService, final UserModelMapperService userModelMapperService, AreaService areaService) {
        this.registerService = registerService;
        this.userModelMapperService = userModelMapperService;
        this.areaService = areaService;
    }

    /**
     * User Register - STEP2
     *
     * @param qid
     * @param userMobile
     * @return
     */
    @GetMapping(value = "/checkqidvalidity")
    public GenericResponse checkQidValidity(@RequestParam(value = "qid") String qid,
                                            @RequestParam(value = "number") String userMobile) {
        LOGGER.info("[Controller] GET - checkQidValidity :  qid {}, userMobile {}", qid, userMobile);
        // TODO:HSN add profile to test dev
//        if (environment.getProperty("mode", "prod").equals("dev")) {
//            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
//        } else {
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(registerService.checkQidValidity(qid, userMobile)), Provider.WOQOD);
//        }
    }

    /**
     * User register - STEP 3
     *
     * @param userResource
     * @param sendEmail
     * @param language
     * @return
     */
    @PostMapping(value = "/register")
    public GenericResponse register(@RequestBody @Valid UserRegisterResource userResource, @RequestParam(required = false, defaultValue = "false") Boolean sendEmail,
                                    @RequestParam(value = "language") LanguageEnum language) {
        LOGGER.info("[Controller] POST - register individual user with username {}", userResource.getUsername());
        AreaResource areaResource = areaService.findbyId(userResource.getIdArea());
        registerService.register(userModelMapperService.mapToRegisterUserModel(userResource, true, areaResource), LanguageEnum.valueOf(language.name()), sendEmail);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/activate")
    public GenericResponse activate(@RequestBody @Valid ActivationResource activationResource) {
        LOGGER.info("[Controller] POST - user for activation code : username {}", activationResource.getUsername());
        Activation activation = Activation.newBuilder()
                .userName(activationResource.getUsername())
                .pincode(activationResource.getPinCode())
                .deviceSerial(activationResource.getDeviceSerial())
                .deviceType(activationResource.getDeviceType())
                .build();
        registerService.activateAccount(activation);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/sendpincode")
    public GenericResponse updatePinCode(@RequestParam(value = "username") String userName,
                                         @RequestParam(value = "language") LanguageEnum languag) {
        LOGGER.info("[Controller] PUT - username {}", userName);
        RegistrationValidator.preSendPinCode(userName, languag);
        registerService.updatePinCode(userName, LanguageEnum.valueOf(languag.name()));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/checkQidAndMobileValidity")
    public GenericResponse checkQidAndMobileValidity(@RequestParam(value = "qid") String qid,
                                                     @RequestParam(value = "number") String userMobile) {
        LOGGER.info("[Controller] GET - checkQidAndMobileValidity :  qid {}, userMobile {}", qid, userMobile);
        // TODO:HSN add profile to test dev
//        if ((Boolean.TRUE.equals(devMod))) {
//            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
//        } else {
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(registerService.checkQidAndMobileNumberValidity(qid, userMobile)), Provider.WOQOD);
//        }
    }

}
