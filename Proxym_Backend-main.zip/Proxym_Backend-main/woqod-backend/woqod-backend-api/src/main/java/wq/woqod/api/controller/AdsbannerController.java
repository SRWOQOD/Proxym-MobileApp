package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.AdsBannerResource;
import wq.woqod.resources.resources.DiscountResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.UpdateAdsResource;
import wq.woqod.service.AdsBannerService;
import wq.woqod.service.NotificationService;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/adsbanner")
public class AdsbannerController {

    @Autowired
    private AdsBannerService adsBannerService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<AdsBannerResource>> getAdsbanner() {
        List<AdsBannerResource> list;
        list = adsBannerService.getAdsbanner();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping(value = "hasNotif")
    public GenericResponse<BooleanResponse> hasNotif(@RequestParam String deviceid,
                                                     @RequestParam Boolean connected
    ) {
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(notificationService.hasNotif(
                deviceid, connected
        )), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ListResponse<AdsBannerResource>> getFilteredList(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        log.info("getFilteredList");

        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(adsBannerService.filter(parameters)), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<DiscountResource>> getById(@PathVariable String id) {
        log.info("[AdsbannerController] getById");
        AdsBannerResource adsBannerResource = adsBannerService.getById(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(adsBannerResource), Provider.WOQOD);
    }

    @PutMapping(value = "/all")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateArea(@RequestBody @Valid UpdateAdsResource list) {
        adsBannerService.update(list.getList());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateAdsBanner(@RequestBody @Valid AdsBannerResource adsBannerResource) {
        adsBannerService.update(adsBannerResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/activebanner")
    public GenericResponse getActiveAdsBanner() {

        List<AdsBannerResource> list;
        list = adsBannerService.getActiveAdsBanner();

        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(adsBannerService.count()), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> delete(@PathVariable String id) {
        adsBannerService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
