package wq.woqod.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.resources.resources.PlateTypeResource;
import wq.woqod.service.PlateTypeService;

import java.util.List;

/**
 * Created by Hassen.Ellouze on 29/01/2019.
 */
@RestController
@RequestMapping("/plate")
public class PlateTypeController {

    private final PlateTypeService plateTypeService;

    public PlateTypeController(PlateTypeService plateTypeService) {
        this.plateTypeService = plateTypeService;
    }

    @GetMapping(value = "")
    public GenericResponse getAllPlateTypes() {
        List<PlateTypeResource> plateTypeList = (plateTypeService.getAllPlateTypes());
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(plateTypeList), Provider.WOQOD);
    }

}
