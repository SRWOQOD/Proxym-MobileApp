package wq.woqod.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.enumerations.SurveyTypeEnum;
import wq.woqod.resources.resources.OptionResultRessource;
import wq.woqod.resources.resources.SurveyQuestionResource;
import wq.woqod.resources.resources.SurveyResultRessource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.service.SurveyQuestionService;
import wq.woqod.service.SurveyService;
import wq.woqod.service.mapper.SurveyMapper;

import javax.validation.Valid;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

@RestController
@RequestMapping(value = "/surveys")
@Slf4j
public class SurveyController {

    private final SurveyService surveyService;
    private final SurveyQuestionService surveyQuestionService;

    public SurveyController(SurveyService surveyService, SurveyQuestionService surveyQuestionService) {
        this.surveyService = surveyService;
        this.surveyQuestionService = surveyQuestionService;
    }

    @GetMapping(value = "/all")
    public GenericResponse<ObjectResponse<SurveysResource>> getAllSurveys(@RequestParam MultiValueMap<String, String> parameters) {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(surveyService.getAllSurveys(parameters)), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> getStationById(@PathVariable Long id) throws SQLException {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(surveyService.getSurveyById(id)), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<SurveysResource>> getStationByType(@RequestParam(value = "type", required = false) SurveyTypeEnum type) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(surveyService.getSurveyByType(type)), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> deleteSurvey(@PathVariable Long id) {
        surveyService.deleteSurvey(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<SurveysResource>> createSurvey(@RequestBody @Valid SurveysResource surveysResource) throws SQLException {
        surveyService.createSurveys(SurveyMapper.mapToEntity(surveysResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<SurveysResource>> updateSurvey(@RequestBody @Valid SurveysResource surveysResource) {
        surveyService.updateSurvey(SurveyMapper.mapToEntity(surveysResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/question/{id}")
    public GenericResponse getQuestionById(@PathVariable Long id) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(surveyQuestionService.getSurveyQuestionByQuestionId(id)), Provider.WOQOD);
    }

    @PutMapping(value = "/publish/{id}")
    public GenericResponse updateSurveyToPublished(@PathVariable Long id) throws SQLException {
        surveyService.updateToPublishedSurvey(SurveyMapper.mapToEntity(surveyService.getSurveyById(id)));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/publish")
    public GenericResponse publishSurvey(@RequestParam Long id,@RequestParam String publishedBy ) throws SQLException, JsonProcessingException {
        log.info("sending push notification to users list");
        surveyService.publishSurvey(id,new ArrayList<>(), publishedBy);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse getFilteredSurvey(Pageable pageable, PagedResourcesAssembler assembler,
                                             @RequestParam MultiValueMap<String, String> parameters) {
        Page<SurveysResource> surveysResources = surveyService.getFilteredSurvey(pageable, parameters);
        PagedModel result = assembler.toModel(surveysResources);
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, surveysResources.getContent()), Provider.WOQOD);
    }

    @ApiOperation("get Survey results")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully updated"), @ApiResponse(code = 404, message = "Schema not found"), @ApiResponse(code = 400, message = "Missing or invalid request body"), @ApiResponse(code = 500, message = "Internal error")})
    @GetMapping(value = "/results/{surveyId}")
    public GenericResponse<ObjectResponse<SurveyResultRessource>> getSurveyResults(@PathVariable Long surveyId) {
        log.info("[Survey Controller] Get Survey Results");
        SurveyResultRessource surveyResultRessource = surveyService.getSurveyResults(surveyId);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(surveyResultRessource), Provider.WOQOD);
    }
    @ApiOperation("get Surveys Number")
    @GetMapping("/count")
    public GenericResponse count() {
        Long count =  surveyService.count();
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(count), Provider.WOQOD);
    }

    @GetMapping("/questionResponse/{questionId}")
    public GenericResponse<ObjectResponse<OptionResultRessource>> getOptionResultRessourceFromSurveyQuestion(@PathVariable Long questionId) {
        SurveyQuestionResource surveyQuestionResource = surveyQuestionService.getSurveyQuestionByQuestionId(questionId);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(surveyService.getOptionResultRessourceFromSurveyQuestion(surveyQuestionResource)), Provider.WOQOD);
    }

}
