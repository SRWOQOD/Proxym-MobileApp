package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.resources.inputs.AccountWaqod;
import wq.woqod.service.WaqoodeProcessService;

@Api(value = "Waqoode proceess controller")
@RestController
@Slf4j
@RequestMapping(value = "process")
public class WaqoodeProcessController {

    private final WaqoodeProcessService waqoodeProcessService;

    public WaqoodeProcessController(WaqoodeProcessService waqoodeProcessService) {
        this.waqoodeProcessService = waqoodeProcessService;
    }

    @PostMapping("submit")
    public GenericResponse submit(@RequestBody AccountWaqod accountWaqod) {
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(waqoodeProcessService.submit(accountWaqod)), Provider.WOQOD);

    }
}
