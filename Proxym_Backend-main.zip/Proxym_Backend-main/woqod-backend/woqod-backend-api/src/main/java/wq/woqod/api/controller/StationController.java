package wq.woqod.api.controller;

import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.api.validator.StationValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.Station;
import wq.woqod.resources.enumerations.StationCategoryEnum;
import wq.woqod.resources.resources.*;
import wq.woqod.service.RatingService;
import wq.woqod.service.StationService;
import wq.woqod.service.mapper.StationEntityMapper;
import wq.woqod.service.mapper.StationModelMapper;

import javax.validation.Valid;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by ameni on 14/12/16.
 */
@RestController
@RequestMapping(value = "/stations")
@Slf4j
public class StationController {


    private final StationService stationService;
    private final RatingService ratingService;

    private ModelMapper mapper = new ModelMapper();

    @Autowired
    public StationController(StationService stationService, RatingService ratingService) {
        this.stationService = stationService;
        this.ratingService = ratingService;
    }

    @GetMapping(value = "")
    public GenericResponse getStations(@RequestParam(value = "category", required = false) StationCategoryEnum category) {
        log.info("[Controller] GET All stations");
        List<StationResource> stationsVOList = StationModelMapper.mapToListStationResources(
                StationEntityMapper.mapToListStationEntity(stationService.getAllStations(
                        category == null ? null : StationCategoryEnum.valueOf(category.name())
                )));
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(stationsVOList), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse getStationById(@PathVariable Long id) {
        log.info("[Controller] GET Station : id {}", id);
        StationResource station = StationModelMapper.mapToStationResource(StationEntityMapper.mapToStationEntity(stationService.getStationById(id)));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(station), Provider.WOQOD);
    }

    @GetMapping(value = "/infos")
    public GenericResponse getStationsInfo() {
        log.info("[Controller] GET All Stations Information");
        List<StationInfo> stationsInfo = stationService.getStationsInfo();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(stationsInfo), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse updateStationsServicesState(@RequestBody @Valid StationUpdateResources stationUpdateResources) {
        log.info("[StationController] updateStationsServicesState");
        StationValidator.prePut(stationUpdateResources.getStationUpdateResources());
        stationService.updateServicesStationState(stationUpdateResources.getStationUpdateResources().stream().map(c -> mapper.map(c, StationUpdate.class)).collect(Collectors.toList()));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFiltredDiscount(Pageable pageable, PagedResourcesAssembler assembler,
                                              @QuerydslPredicate(root = Station.class) Predicate predicate,
                                              @RequestParam MultiValueMap<String, String> parameters) throws ParseException, SQLException {
        log.info("[DiscountController] GET All Discount  with Filters");
        Page<StationResource> stationResources = stationService.getFilteredList(pageable, predicate, parameters);
        for (StationResource s: stationResources
        ) {
            s.setRating(ratingService.getSumOfRatingsByStationId(s.getStationId()));
            s.setRatedBy(ratingService.getNumberOfRatingsByStationId(s.getStationId()));
        }
        PagedModel result = assembler.toModel(stationResources);
        List<StationResource> stationResourceList = Collections.unmodifiableList((stationResources.getContent()));
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, stationResourceList), Provider.WOQOD);
    }
}
