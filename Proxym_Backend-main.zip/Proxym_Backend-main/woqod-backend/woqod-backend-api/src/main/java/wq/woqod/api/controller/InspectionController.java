package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.InspectionResource;
import wq.woqod.service.FahesQpayTransactionService;
import wq.woqod.service.InspectionService;
import wq.woqod.service.PRTransactionLogService;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 07/02/2019.
 */
@RestController
@RequestMapping(value = "/inspection")
@Slf4j
public class InspectionController {

    private final InspectionService inspectionService;

    private final PRTransactionLogService prTransactionLogService;

    private final FahesQpayTransactionService fahesQpayTransactionService;

    public InspectionController(InspectionService inspectionService, PRTransactionLogService prTransactionLogService, FahesQpayTransactionService fahesQpayTransactionService) {
        this.inspectionService = inspectionService;
        this.prTransactionLogService = prTransactionLogService;
        this.fahesQpayTransactionService = fahesQpayTransactionService;
    }

    @GetMapping(value = "/listDetails")
    public GenericResponse<ObjectResponse<InspectionResource>> getListInspectionDetails(@RequestParam(value = "vin") String vin, @RequestParam(value = "page") String page) {
        log.info("[InspectionController] getListInspectionDetails ");
        List<InspectionResource> inspectionResourceList = inspectionService.getInspectionDetailsByVin(vin, page);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(inspectionResourceList), Provider.WOQOD);
    }

    @GetMapping(value = "/listDetailsByPlate")
    public GenericResponse<ObjectResponse<InspectionResource>> getListInspectionDetailsByPlate(@RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "owner_id") String ownerId, @RequestParam(value = "plate_type_id") String plateTypeId) {
        log.info("[Controller] getListInspectionDetailsByPlate");
        List<InspectionResource> inspectionResourceList = inspectionService.getInspectionDetailsByPlate(plateNumber, ownerId, plateTypeId);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(inspectionResourceList.get(0)), Provider.WOQOD);
    }

    @GetMapping(value = "/details")
    public GenericResponse<ObjectResponse<InspectionResource>> getListInspectionDetails(@RequestParam(value = "inspection_id") String inspectionId) {
        log.info("[InspectionController] getListInspectionDetails");
        List<HashMap<String, Object>> inspectionDetail = inspectionService.getInspectionDefectDetails(inspectionId);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(inspectionDetail), Provider.WOQOD);
    }

    @GetMapping(value = "/fee")
    public GenericResponse<ObjectResponse<InspectionResource>> getFee(@RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type_id") String plateTypeId, @RequestParam(value = "qid") String qid) {
        log.info("[InspectionController] getFee ");

        HashMap<String, Object> feeDetails0 = new HashMap<>();
        feeDetails0.put("service_category", "MAIN INSPECTION");
        feeDetails0.put("inspection_cycle_ends_on", null);
        feeDetails0.put("inspection_type", 1);
        HashMap<String, Object> category0;
        category0 = new HashMap<>();
        category0.put("id", "");
        category0.put("name_en", "CAR");
        category0.put("name_ar", "");
        category0.put("fee", 0);
        feeDetails0.put("category", category0);

        byte[] decodedBytes = java.util.Base64.getDecoder().decode(qid);
        String decodedQid = new String(decodedBytes);

        if (plateNumber.equals("112233") && decodedQid.equals("11111111111") && plateTypeId.equals("1")) {
            return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feeDetails0), Provider.WOQOD);

        }
        HashMap<String, Object> feeDetails = inspectionService.getFee(plateNumber, plateTypeId, decodedQid);
        Object c = feeDetails.get("category");

        if (((LinkedHashMap) c).get("fee").equals(0)) {
            return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feeDetails), Provider.WOQOD);
        } else {
            if (decodedQid.equals("00000000000") && plateNumber.equals("001100")) {
                return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feeDetails), Provider.WOQOD);
            } else {
                HashMap<String, Object> testPreRegistration = prTransactionLogService.checkPreRegistrationBeforeInsert(qid, plateTypeId, plateNumber);
                HashMap<String, Object> testQpayPreRegistration = fahesQpayTransactionService.checkPreRegistrationBeforeInsert(qid, plateTypeId, plateNumber);

                if (testPreRegistration.get("error_en") == null && testQpayPreRegistration.get("error_en") == null) {
                    return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feeDetails), Provider.WOQOD);
                } else if (testPreRegistration.get("error_en") != null && testQpayPreRegistration.get("error_en") == null) {
                    return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(testPreRegistration), Provider.WOQOD);
                } else if (testPreRegistration.get("error_en") == null && testQpayPreRegistration.get("error_en") != null) {
                    return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(testQpayPreRegistration), Provider.WOQOD);
                }  else {
                    return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(testPreRegistration), Provider.WOQOD);
                }

            }
        }
    }
}
