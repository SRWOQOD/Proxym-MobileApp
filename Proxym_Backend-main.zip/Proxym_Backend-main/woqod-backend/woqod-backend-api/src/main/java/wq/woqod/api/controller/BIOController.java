package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.enumerations.LanguageEnum;
import wq.woqod.resources.resources.BioResources;
import wq.woqod.resources.resources.UpdateBioResource;
import wq.woqod.resources.resources.UserResource;
import wq.woqod.service.BioConfigService;
import wq.woqod.service.PinCodeService;
import wq.woqod.service.UserService;

/**
 * Created by med-amine.ben-ahmed on 14-Jun-17.
 */
@RestController
@Slf4j
@RequestMapping(value = "/bio")
public class BIOController {
    protected final BioConfigService bioConfigService;
    protected final PinCodeService pinCodeService;
    protected final UserService userService;


    @Autowired
    public BIOController(BioConfigService bioConfigService, PinCodeService pinCodeService, UserService userService) {
        this.bioConfigService = bioConfigService;
        this.pinCodeService = pinCodeService;
        this.userService = userService;
    }

    /**
     * Used to add bio-bin value
     *
     * @param bioResources
     * @return
     */
    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<BioResources>> addBioPin(@RequestBody BioResources bioResources) {
        String customPwd = bioConfigService.addBioPin(bioResources);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(customPwd), Provider.WOQOD);
    }

    /**
     * Used to update bio-bin value
     *
     * @param updateBioResource
     * @return
     */
    @PutMapping(value = "/status")
    public GenericResponse<ObjectResponse<BioResources>> updateBioPin(@RequestBody UpdateBioResource updateBioResource) {
        bioConfigService.updateBioPin(updateBioResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    /**
     * Used to update bio-bin value
     *
     * @param updateBioResource
     * @return
     */
    @PutMapping(value = "/resetBioPin")
    public GenericResponse<ObjectResponse<BioResources>> resetBioPin(@RequestBody UpdateBioResource updateBioResource) {
        bioConfigService.resetBioPin(updateBioResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    /**
     *
     * @param bioResources
     * @return
     */
    @PostMapping(value = "/validate")
    public GenericResponse<ObjectResponse<BioResources>> validateBioPin(@RequestBody BioResources bioResources) {
        boolean isValidPin = bioConfigService.verifyFingerPrint(bioResources);
        if (isValidPin) {
            boolean response = pinCodeService.sendPinCode(bioResources.getUsername(), LanguageEnum.en, true);
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
        }
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(isValidPin), Provider.WOQOD);
    }

    /**
     * Get custom password used to enroll 'bio pin' for current user device
     *
     * @return
     */
    @PostMapping(value = "/getUser")
    public GenericResponse getUser(@RequestBody UpdateBioResource updateBioResource) {
        UserResource userResource = userService.getuser(updateBioResource);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(userResource), Provider.WOQOD);
    }


    /**
     * Used to check if fingerprint exist
     *
     * @param bioResources
     * @return
     */
    @PostMapping(value = "/checkFingerPrint")
    public GenericResponse<ObjectResponse<BioResources>> checkFingerPrint(@RequestBody BioResources bioResources) {
        boolean exist = bioConfigService.verifyFingerPrint(bioResources);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(exist), Provider.WOQOD);
    }


}
