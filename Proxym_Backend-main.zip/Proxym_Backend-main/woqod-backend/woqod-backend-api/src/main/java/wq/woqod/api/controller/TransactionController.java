package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.TransactionsHistoryResource;
import wq.woqod.service.TransactionLogService;
import wq.woqod.service.TransactionService;
import wq.woqod.service.WoqodeQpayTransactionService;


/**
 * Created by med-taher.ben-torkia on 12/8/2016.
 */
@RestController
@RequestMapping(value = "/transactions")
public class TransactionController {
    private final TransactionService transactionService;
    private final WoqodeQpayTransactionService qpayTransactionService;

    @Autowired
    public TransactionController(TransactionService transactionService, TransactionLogService transactionLogService, WoqodeQpayTransactionService qpayTransactionService) {
        this.transactionService = transactionService;
        this.qpayTransactionService = qpayTransactionService;
    }

    @GetMapping(value = "")
    public GenericResponse getTransactionsHistoryByUserName(@RequestParam(value = "username") String userName) {
        TransactionsHistoryResource transactionsHistory = transactionService.getTransactionsHistory(userName);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(transactionsHistory), Provider.WOQOD);
    }

    @GetMapping(value = "startCron")
    public GenericResponse startCron() {
        transactionService.startCron();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "startCronInprogressQpayTransaction")
    public GenericResponse startQpayCron() {
        qpayTransactionService.startCron();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


}
