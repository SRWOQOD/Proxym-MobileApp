package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.api.validator.CronValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.service.CronService;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by bfitouri on 20/11/16.
 */
@RestController
@RequestMapping(value = "/crons")
public class CronController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CronController.class);

    private final CronService cronService;

    @Autowired
    public CronController(CronService cronService) {
        this.cronService = cronService;
    }

    @PutMapping(value = "")
    public GenericResponse startCron(@RequestParam ContentCategoryEnum category) throws UnknownHostException {

        LOGGER.info("[Controller] PUT - Cron : Start a new cron to refresh categories :{}", category);
        CronValidator.prePut(category);
        ContentCategoryEnum cat = ContentCategoryEnum.valueOf(category.name());
        cronService.startCron(Arrays.asList(cat));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);


    }

    @GetMapping(value = "/test")
    public void test() {
        Stream<ContentCategoryEnum> categories = Stream.of(ContentCategoryEnum.values());
        List<ContentCategoryEnum> cats = categories
                .map(category -> ContentCategoryEnum.valueOf(category.name()))
                .collect(Collectors.toList());

        cronService.startCron(cats);
    }

    @PutMapping(value = "/all")
    public GenericResponse<ObjectResponse<ContentCategoryEnum>> startCron() {

        LOGGER.info("[Controller] PUT - Cron : Start a new cron to refresh all the categories :{}", (Object) ContentCategoryEnum.values());
        Stream<ContentCategoryEnum> categories = Stream.of(ContentCategoryEnum.values());
        List<ContentCategoryEnum> cats = categories
                .map(category -> ContentCategoryEnum.valueOf(category.name()))
                .collect(Collectors.toList());
        LOGGER.info("[Controller] PUT - Cron : Start a new cron to refresh all the categories :{}", (Object) ContentCategoryEnum.values());

        cronService.startCron(cats);

        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}