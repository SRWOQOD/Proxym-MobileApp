package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.AreaCheckResource;
import wq.woqod.resources.resources.AreaResource;
import wq.woqod.service.AreaService;
import wq.woqod.service.client.AreaCronClient;
import wq.woqod.service.client.api.SharedPointAreaResponse;
import wq.woqod.service.mapper.AreaMapper;

import javax.validation.Valid;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/area")
public class AreaController {

    @Autowired
    private AreaCronClient areaCronClient;

    @Autowired
    private AreaService areaService;


    @GetMapping(value = "/test")
    public GenericResponse<ObjectResponse<AreaResource>> area() {

        List<SharedPointAreaResponse> l = new ArrayList<>();
        List<SharedPointAreaResponse> list = areaCronClient.getArea(null, l);
        List<AreaResource> areaResources = AreaMapper.mapToList(list);
        areaService.saveAll(areaResources);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(areaResources), Provider.WOQOD);
    }


    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<AreaResource>> addArea(@RequestBody @Valid AreaResource areaResource) {
        log.debug("[AreaController] addArea ");
        areaService.saveBO(areaResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<AreaResource>> getAreas(@RequestParam(value = "title", required = false) String title,
                                                                  @RequestParam(value = "arabicTitle", required = false) String arabicTitle) {

        List<AreaResource> list;
        list = areaService.getAreas(arabicTitle, title);

        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);

    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<AreaResource>> getFilteredArea(@PageableDefault(sort = {"title"}, direction = Sort.Direction.ASC) Pageable pageable,
                                                                         PagedResourcesAssembler assembler, @RequestParam(required = false) MultiValueMap<String, String> parameters) throws ParseException {
        log.info("[AreaController] getFilteredArea");
        Page<AreaResource> areaResources = areaService.filter(pageable, parameters);

        PagedModel result = assembler.toModel(areaResources);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, areaResources.getContent()), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<AreaResource>> updateArea(@RequestBody @Valid AreaResource areaResource) {
        areaService.updateArea(areaResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<AreaResource>> getAreaById(@PathVariable Long id) {
        log.info("[Controller] GET Area : id {}", id);
        AreaResource areaResource = areaService.findAreaById(id);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(areaResource), Provider.WOQOD);
    }

    @PostMapping(value = "/check")
    public GenericResponse checkUser(@RequestBody AreaCheckResource areaCheckResource) {
        areaService.checkArea(areaCheckResource.getAreaNameAr(), areaCheckResource.getAreaNameEn());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(areaService.count()), Provider.WOQOD);
    }
}
