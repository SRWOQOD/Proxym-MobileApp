package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.resources.resources.DeviceResource;
import wq.woqod.service.DeviceService;
import wq.woqod.service.mapper.DeviceEntityMapper;

import javax.validation.Valid;
import java.util.List;

/**
 * Created by med-taher.ben-torkia on 12/28/2016.
 */
@RestController
@RequestMapping(value = "/devices")
public class DeviceController {
    private final DeviceService deviceService;

    @Autowired
    public DeviceController(final DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @GetMapping(value = "")
    public GenericResponse<ListResponse<DeviceResource>> getDevicesByOwner(@RequestParam(value = "username") String userName) {
        List<DeviceResource> devices = DeviceEntityMapper.mapToListDeviceModel(deviceService.getDevicesByOwner(userName));
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(devices), Provider.WOQOD);
    }

    @PutMapping(value = "")
    public GenericResponse<BooleanResponse> putDevice(@RequestBody @Valid DeviceResource deviceResource) {
        deviceService.updateDevice(DeviceEntityMapper.mapToDeviceEntity(deviceResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "getSurveyStatus")
    public GenericResponse<BooleanResponse> getSurveyStatus(@RequestParam String deviceId) {
        Boolean status = deviceService.getSurveyStatus(deviceId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(status), Provider.WOQOD);
    }

    @PostMapping(value = "changeStatus")
    public GenericResponse<BooleanResponse> changeStatus(@RequestParam String deviceId) {
        deviceService.changeStatus(deviceId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
    @PostMapping(value = "register")
    public GenericResponse<BooleanResponse> register(@RequestParam String deviceId) {
        deviceService.register(deviceId);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
