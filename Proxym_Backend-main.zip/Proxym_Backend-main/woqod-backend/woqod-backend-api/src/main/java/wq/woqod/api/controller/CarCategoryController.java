package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.CarCategoryResource;
import wq.woqod.service.CarCategoryServie;
import wq.woqod.service.mapper.CarCategoryMapper;

import javax.validation.Valid;
import java.util.List;

/**
 * * The class {@code CarCategoryController} controls the data
 * of car category model and updates the view whenever data changes
 *
 * @author Meriam Mejri
 */


@Api(value = "Car Category Controller")
@RestController
@RequestMapping(value = "/carCategory")
public class CarCategoryController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CarCategoryController.class);
    private final CarCategoryServie carCategoryServie;

    @Autowired
    public CarCategoryController(CarCategoryServie carCategoryServie) {
        this.carCategoryServie = carCategoryServie;
    }

    @ApiOperation(value = "View a list of Car Category ", response = GenericResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @GetMapping(value = "/all")
    public GenericResponse<ObjectResponse<CarCategoryResource>> getAllCarCategory() {
        LOGGER.info("[Controller] GET - CarCategory : All Car Categorys");
        List<CarCategoryResource> carCategories = CarCategoryMapper.mapEntityToCarCategoryModelList(carCategoryServie.findAll());
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(carCategories), Provider.WOQOD);
    }

    @ApiOperation(value = "Add a Car Category")
    @PostMapping(value = "save")
    public GenericResponse<ObjectResponse<CarCategoryResource>> saveCarCategory(@RequestBody @Valid CarCategoryResource carCategoryResource) {
        LOGGER.info("[Controller] POST - save Car Category ");
        carCategoryServie.save(CarCategoryMapper.mapToCarCategory(carCategoryResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);

    }


    @ApiOperation(value = "Delete Car Category ", response = GenericResponse.class)
    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<CarCategoryResource>> deleteCarCategory(@PathVariable Long id) {
        LOGGER.info("DELETE - Car Category : id {}", id);
        carCategoryServie.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Car Category by ID ", response = GenericResponse.class)
    @GetMapping(value = "/findById/{id}")
    public GenericResponse<ObjectResponse<CarCategoryResource>> findCarCategoryById(@PathVariable String id) {
        LOGGER.info("[Controller] Get Car Category By ID ");
        CarCategoryResource carCategory = CarCategoryMapper.mapEntityToCarCategoryModel(carCategoryServie.findByCategoryId(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(carCategory), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Car Category by English Name  ", response = GenericResponse.class)
    @GetMapping(value = "/findByNameEn/{nameEn}")
    public GenericResponse<ObjectResponse<CarCategoryResource>> findCarCategoryByNameEn(@PathVariable String nameEn) {
        LOGGER.info("[Controller] Get Car Category By English Name ");
        CarCategoryResource carCategory = CarCategoryMapper.mapEntityToCarCategoryModel(carCategoryServie.findByNameEn(nameEn));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(carCategory), Provider.WOQOD);
    }

    @ApiOperation(value = "Get Car Category by English Name  ", response = GenericResponse.class)
    @GetMapping(value = "/findByFee/{fee}")
    public GenericResponse<ObjectResponse<CarCategoryResource>> findCarCategoryByFee(@PathVariable Double fee) {
        LOGGER.info("[Controller] Get Car Category By Fee ");
        CarCategoryResource carCategory = CarCategoryMapper.mapEntityToCarCategoryModel(carCategoryServie.findByFee(fee));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(carCategory), Provider.WOQOD);
    }


}
