package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.enumerations.FahesServiceEnum;
import wq.woqod.resources.enumerations.PaymentMethodEnum;
import wq.woqod.resources.resources.DiscountResource;
import wq.woqod.service.DiscountService;
import wq.woqod.service.mapper.DiscountMapper;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;

/**
 * Created by Hassen.Ellouze on 15/11/2018.
 */
@RestController
@RequestMapping(value = "/discount")
public class DiscountController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscountController.class);

    private final DiscountService discountService;

    @Autowired
    public DiscountController(final DiscountService discountService) {
        this.discountService = discountService;
    }

    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<DiscountResource>> save(@RequestBody DiscountResource discountResource) throws ParseException {
        LOGGER.info("[Controller] POST - Discount : save");
        discountService.createNewDiscount(DiscountMapper.discountToEntity(discountResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "saveAndCheck")
    public GenericResponse<ObjectResponse<DiscountResource>> saveAndCheck(@RequestBody DiscountResource discountResource) throws ParseException {
        LOGGER.info("[Controller] POST - Discount : save");
        discountService.saveAndCheck(DiscountMapper.discountToEntity(discountResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "checkAndUpdate")
    public GenericResponse<ObjectResponse<DiscountResource>> checkAndUpdate(@RequestBody DiscountResource discountResource) throws ParseException {
        LOGGER.info("[Controller] Put - Discount : checkAndUpdate");
        discountService.checkAndUpdate(DiscountMapper.discountToEntity(discountResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/checkInterval")
    public GenericResponse<ObjectResponse<DiscountResource>> checkInterval(@RequestParam(value = "min") Double min, @RequestParam(value = "max") Double max, @RequestParam(value = "method") String method, @RequestParam(value = "type") String type, @RequestParam(value = "service") String service, @RequestParam(value = "status") String status) {
        LOGGER.info("[Controller] GET - Discount : checkInterval");
        Boolean response = discountService.checkInterval(min, max, method, type, service, status);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(response), Provider.WOQOD);
    }

    @GetMapping(value = "/checkIntervalForUpdate")
    public GenericResponse<ObjectResponse<DiscountResource>> checkIntervalForUpdate(@RequestParam(value = "id") Long id, @RequestParam(value = "min") Double min, @RequestParam(value = "max") Double max, @RequestParam(value = "method") String method, @RequestParam(value = "type") String type, @RequestParam(value = "service") String service, @RequestParam(value = "status") String status) {
        LOGGER.info("[Controller] GET - Discount : checkIntervalForUpdate");
        Boolean response = discountService.checkIntervalForUpdate(id, min, max, method, type, service, status);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(response), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<DiscountResource>> updateDiscount(@RequestBody DiscountResource discountResource) throws ParseException {
        LOGGER.info("[Controller] POST - Discount : Update Discount");
        discountService.updateDiscount(DiscountMapper.discountToEntity(discountResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/byType")
    public GenericResponse<ObjectResponse<DiscountResource>> getDiscountByType(@RequestParam(value = "fahes_service") String fahesService, @RequestParam(value = "payment_method") String paymentMethod) {
        DiscountResource discount = DiscountMapper.discountToResource(discountService.getDiscountByServiceAndPaymentMethode(fahesService, paymentMethod));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(discount), Provider.WOQOD);
    }

    @GetMapping(value = "/byTypeAndAmount")
    public GenericResponse<ObjectResponse<DiscountResource>> getDiscountByTypeAndAmount(@RequestParam(value = "fahes_service") String fahesService, @RequestParam(value = "payment_method") String paymentMethod, @RequestParam(value = "amount") Double amount) {
        DiscountResource discount = DiscountMapper.discountToResource(discountService.getDiscountByServiceAndPaymentMethodeAndAmount(fahesService, paymentMethod, amount));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(discount), Provider.WOQOD);
    }

    @GetMapping(value = "/byAmount")
    public GenericResponse<ObjectResponse<DiscountResource>> getDiscountByAmount(@RequestParam(value = "amount") Double amount) {
        DiscountResource discount = DiscountMapper.discountToResource(discountService.getDiscountByAmount(amount));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(discount), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<DiscountResource>> delete(@PathVariable Long id) {
        LOGGER.info("DELETE - Discount : id {}", id);
        discountService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<DiscountResource>> getById(@PathVariable Long id) {
        LOGGER.info("getById - Discount : id {}", id);
        DiscountResource discountResource = discountService.getById(id);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(discountResource), Provider.WOQOD);
    }

    @GetMapping(value = "/check")
    public GenericResponse<ObjectResponse<DiscountResource>> check() {
        DiscountResource discount = DiscountMapper.discountToResource(discountService.getDiscountByServiceAndPaymentMethodeAndAmount(FahesServiceEnum.FAHES.name(), PaymentMethodEnum.CREDIT_CARD.name(), 150d));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(discount), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<DiscountResource>> getFiltredDiscount(Pageable pageable, PagedResourcesAssembler assembler,
                                                                                @RequestParam MultiValueMap<String, String> parameters) throws SQLException {
        LOGGER.info("[DiscountController] GET All Discount  with Filters");
        Page<DiscountResource> discountResources = discountService.getFilteredDiscount(pageable, parameters);
        PagedModel<DiscountResource> result = assembler.toModel(discountResources);
        List<DiscountResource> discountResourceList = Collections.unmodifiableList((discountResources.getContent()));
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, discountResourceList), Provider.WOQOD);
    }
}
