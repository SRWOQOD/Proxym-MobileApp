package wq.woqod.api.controller;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.FahesQpayTransactionResource;
import wq.woqod.resources.resources.QpayInquiryResponseResource;
import wq.woqod.resources.resources.QpayRefundResponseResource;
import wq.woqod.service.FahesQpayTransactionService;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;



@RestController
@RequestMapping(value = "/qpay/prtransaction")
@Slf4j
public class FahesQpayTransactionController {

    private final FahesQpayTransactionService fahesQpayTransactionService;

    public FahesQpayTransactionController(FahesQpayTransactionService fahesQpayTransactionService) {
        this.fahesQpayTransactionService = fahesQpayTransactionService;
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<PaginatedListResponse<FahesQpayTransactionResource>> getFiltredFahesQpayTansactions(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                                               @RequestParam MultiValueMap<String, String> parameters) throws ParseException {
        Page<FahesQpayTransactionResource> transactionModels = fahesQpayTransactionService.getFilteredTransactions(pageable, parameters);
        PagedModel<FahesQpayTransactionResource> result = assembler.toModel(transactionModels);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, transactionModels.getContent()), Provider.WOQOD);

    }

    @GetMapping(value = "")
    public GenericResponse<ListResponse<FahesQpayTransactionResource>> getFahesQpayTransactions(@RequestParam MultiValueMap<String, String> parameters) throws ParseException {
        List<FahesQpayTransactionResource> list = fahesQpayTransactionService.getAllTransactions(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @ApiOperation(value = "Update Fahes Qpay transaction  ", response = GenericResponse.class)
    @PutMapping(value = "/updatePun")
    public GenericResponse<BooleanResponse> update(@RequestParam String pun, @RequestParam String statusCode, @RequestParam String statusMessage) {
        this.fahesQpayTransactionService.updateStatus(pun, statusCode, statusMessage);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @ApiOperation(value = "find transaction by PUN")
    @GetMapping(value = "/findByPun")
    public GenericResponse findByPun(@RequestParam String pun) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(fahesQpayTransactionService.findByPun(pun)), Provider.WOQOD);
    }


    @ApiOperation(value = "Add a Pre Registration Fahes Qpay Transaction")
    @PostMapping(value = "/debitcard/save")
    public GenericResponse<BooleanResponse> saveFahesQpayTransaction(@RequestBody @Valid FahesQpayTransactionResource resource, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type") String plateType, @RequestParam(value = "anonym", required = true) Boolean anonym) {
        boolean result = fahesQpayTransactionService.createTransaction(resource, plateNumber, plateType, anonym);
        if (result) {
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
        } else {
            return ResponseBuilder.buildSuccessResponse(new BooleanResponse(false), Provider.WOQOD);
        }

    }

    @ApiOperation(value = "Add a free Pre Registration Fahes Qpay Transaction")
    @PostMapping(value = "/free/save")
    public GenericResponse saveFahesQpayTransactionFree(@RequestBody @Valid FahesQpayTransactionResource resource, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type") String plateType, @RequestParam(value = "anonym", required = true) Boolean anonym) {
        HashMap<String, String> responses = fahesQpayTransactionService.createTransactionFree(resource, plateNumber, plateType, anonym);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @PostMapping(value = "/success")
    public GenericResponse afterPaiementCallBack(@RequestParam(required = false, value = "pun") String pun, @RequestParam(required = false, value = "statusCode") String statusCode, @RequestParam(required = false, value = "statusMessage") String statusMessage, @RequestParam(required = false, value = "transaction_id") String transactionId, @RequestParam(required = false, value = "amount") String amount) {
        log.info("[Controller] POST -QPAY Payment success call for transaction PUN {} and the Status is {}", pun, statusCode, statusMessage);
        HashMap<String, String> responses = fahesQpayTransactionService.updateTopupTransaction(pun,  statusMessage, transactionId, statusCode, amount);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @PostMapping(value = "/inquiryTransaction")
    public GenericResponse getInquiryTransaction(@RequestParam(value = "pun") String originalPun) throws IOException {
        log.info("[Controller] POST -QPAY Payment Inquiry Transaction call for transaction PUN {} ", originalPun);
        QpayInquiryResponseResource responses = fahesQpayTransactionService.getInquiryTransaction(originalPun);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping(value = "/refundTransaction")
    public GenericResponse getRefundTransaction(@RequestParam(value = "pun") String pun, @RequestParam(value = "amount") String amount) throws IOException {
        log.info("[Controller] POST -QPAY Payment Refund Transaction call for transaction");
        QpayRefundResponseResource responses = fahesQpayTransactionService.refundTransaction(pun, amount);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(fahesQpayTransactionService.count()), Provider.WOQOD);
    }

    @ApiOperation(value = "find transactions by QID")
    @GetMapping(value = "/getTransactionsByQid")
    public GenericResponse<ListResponse<FahesQpayTransactionResource>> getTransactionsByQid(@RequestParam String qid) {
        List<FahesQpayTransactionResource> list = fahesQpayTransactionService.getAllTransactionsByQid(qid);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping(value = "/getTransaction")
    public GenericResponse getTransactionByPun(@RequestParam(value = "pun") String pun){
        FahesQpayTransactionResource model = fahesQpayTransactionService.findByPun(pun);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(model), Provider.WOQOD);
    }
}