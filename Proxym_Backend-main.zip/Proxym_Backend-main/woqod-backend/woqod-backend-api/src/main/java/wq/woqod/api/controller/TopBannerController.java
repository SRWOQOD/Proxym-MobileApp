package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.TopBannerResource;
import wq.woqod.service.TopBannerService;

import javax.validation.Valid;
import java.util.List;

@Api(value = "Top Banner Controller")
@RestController
@RequestMapping(value = "/topbanner")
public class TopBannerController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TopBannerController.class);
    private final TopBannerService topBannerService;

    @Autowired
    public TopBannerController(TopBannerService topBannerService) {
        this.topBannerService = topBannerService;
    }

    @ApiOperation(value = "View a list of Top Banner", response = GenericResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })

    @GetMapping(value = "/all")
    public GenericResponse getTopBanner() {
        LOGGER.info("[TopBannerController] GET Top Banner Items");
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(topBannerService.getTopbanner()), Provider.WOQOD);
    }

    @ApiOperation(value = "View a list of Top Banner For BO", response = GenericResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })

    @GetMapping(value = "/active")
    public GenericResponse getTopBannerForBo(PagedResourcesAssembler assembler) {
        LOGGER.info("[TopBannerController] GET Top Banner Items");
        List<TopBannerResource> topBanners = topBannerService.getActiveTopBanner();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(topBanners), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ListResponse<TopBannerResource>> getFilteredList(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        LOGGER.info("getFilteredList");
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(topBannerService.filter(parameters)), Provider.WOQOD);
    }

    @PutMapping(value = "/all")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateTop(@RequestBody @Valid List<TopBannerResource> list) {
        topBannerService.update(list);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping
    public GenericResponse<ObjectResponse<BooleanResponse>> updateTop(@RequestBody @Valid TopBannerResource topBannerResource) {
        topBannerService.update(topBannerResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<TopBannerResource>> getById(@PathVariable String id) {
        LOGGER.info("[TopBannerController] getById");
        TopBannerResource topBannerResource = topBannerService.getById(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(topBannerResource), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(topBannerService.count()), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> delete(@PathVariable String id) {
        topBannerService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
