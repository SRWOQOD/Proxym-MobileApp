package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.enumerations.TransactionStatusEnum;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.TransactionLogResource;
import wq.woqod.service.TransactionService;

import java.text.ParseException;
import java.util.HashMap;

@RestController
@RequestMapping(value = "/payement")
@Slf4j
public class WoqodeTransaction {

    private final TransactionService transactionService;

    public WoqodeTransaction(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping(value = "/createTransactionUUID")
    public GenericResponse createTransactionUUID(@RequestBody TransactionLogResource transactionLogResource) throws ParseException {
        transactionService.createTransactionUUID(transactionLogResource);

        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @PutMapping(value = "/updateTransactionUUID")
    public GenericResponse updateStatus(@RequestParam(value = "transactionUUID") String transactionUUID,
                                        @RequestParam(value = "statusEnum") TransactionStatusEnum statusEnum,
                                        @RequestParam(value = "transactionID") String transactionID,
                                        @RequestParam(value = "authReversal") String authReversal,
                                        @RequestParam(value = "RPSStatus") String rpsStatus) {


        TransactionLogResource transactionLogModel = transactionService.updateTransactionId(transactionUUID, transactionID, authReversal, rpsStatus,statusEnum);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(transactionLogModel), Provider.WOQOD);
    }

    @PostMapping(value = "/success")
    public GenericResponse getTransactionsHistoryByUserName(@RequestParam(value = "transactionUUID") String transactionUUID, @RequestParam(value = "decision") String decision) {
        log.info("[Controller] POST - QNB Payment success call for transaction UUID {} and the DECISION is {}", transactionUUID, decision);
        HashMap<String, String> responses = transactionService.updateTopupTransaction(transactionUUID, decision);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(responses), Provider.WOQOD);
    }

    @GetMapping(value = "/getTransaction")
    public GenericResponse getTransactionByTransactionUid(@RequestParam(value = "transactionID") String transactionId){
        TransactionLogResource model = transactionService.findByTransactionUUID(transactionId);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(model), Provider.WOQOD);
    }
}
