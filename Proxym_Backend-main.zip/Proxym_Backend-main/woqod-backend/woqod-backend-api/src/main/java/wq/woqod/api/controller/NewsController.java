package wq.woqod.api.controller;

import com.google.gson.JsonElement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.NewsResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.service.NewsService;

import javax.validation.Valid;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping(value = "/news")
public class NewsController {

    private final NewsService newsService;

    public NewsController(NewsService newsService) {
        this.newsService = newsService;
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<NewsResource>> getFilteredList(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable,
                                                                         PagedResourcesAssembler assembler, @RequestParam(required = false) Map<String, String> parameters) throws ParseException {
        log.info("[NewsController] getFilteredList");
        Page<NewsResource> resources = newsService.filter(pageable, parameters);

        PagedModel result = assembler.toModel(resources);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, resources.getContent()), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<NewsResource>> getById(@PathVariable String id) {
        log.info("[NewsController] getById");
        NewsResource newsResource = newsService.getById(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(newsResource), Provider.WOQOD);
    }

    @GetMapping(value = "/views/{id}")
    public GenericResponse<BooleanResponse> getByIdForMobile(@PathVariable String id) {
        newsService.getByIdForMobile(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

//    @PutMapping(value = "")
//    public GenericResponse<ObjectResponse<BooleanResponse>> updateNews(@RequestBody @Valid List<NewsResource> list) {
//        newsService.update(list);
//        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
//    }

    @PutMapping
    public GenericResponse<ObjectResponse<BooleanResponse>> updateNews(@RequestBody @Valid NewsResource newsResource) {
        newsService.save(newsResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse<PaginatedListResponse<NewsResource>> getActiveNews(@PageableDefault(sort = "creationDate",
            direction = Sort.Direction.DESC) Pageable pageable , PagedResourcesAssembler assembler) {
        log.info("[NewsController] Active News");
        Page<NewsResource> news = newsService.getActiveNews(pageable);
        PagedModel result = assembler.toModel(news);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(new PaginatedListResponse<>(result, news.getContent())), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(newsService.count()), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> delete(@PathVariable String id) {
        newsService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
