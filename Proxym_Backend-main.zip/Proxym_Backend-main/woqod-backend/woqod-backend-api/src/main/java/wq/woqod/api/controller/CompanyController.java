package wq.woqod.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.resources.resources.CompanyResource;
import wq.woqod.service.CompanyService;
import wq.woqod.service.mapper.CompanyModelMapper;

import java.util.List;

/**
 * Created by bfitouri on 20/11/16.
 */
@RestController
@RequestMapping(value = "/companies")
public class CompanyController {

    private final CompanyService companyService;

    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping(value = "")
    public GenericResponse<ListResponse<CompanyResource>> getCompanies() {
        List<CompanyResource> companiesVOList = CompanyModelMapper.mapToListCompanyModel(companyService.getAllCompanies());
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(companiesVOList), Provider.WOQOD);
    }
}
