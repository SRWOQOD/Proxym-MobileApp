package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.ContentInfoResource;
import wq.woqod.service.ContentService;

import java.util.List;

@RestController
@RequestMapping(value = "/content")
public class ContentManagementController {
    private final ContentService contentService;

    @Autowired
    public ContentManagementController(ContentService contentService) {
        this.contentService = contentService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<ContentInfoResource>> getContents(PagedResourcesAssembler assembler) {
        List<ContentInfoResource> contentInfoResources = contentService.getContents();
        Page<ContentInfoResource> page = new PageImpl<>(contentInfoResources);
        PagedModel result = assembler.toModel(page);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, contentInfoResources), Provider.WOQOD);
    }

    @GetMapping(value = "/{category}")
    public GenericResponse<ObjectResponse<ContentInfoResource>> updateContentsInfoByCategory(@PathVariable String category) {
        ContentInfoResource contentInfoResources = contentService.updateContentsByCategory(category);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(contentInfoResources), Provider.WOQOD);
    }
    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(contentService.count()), Provider.WOQOD);
    }

}
