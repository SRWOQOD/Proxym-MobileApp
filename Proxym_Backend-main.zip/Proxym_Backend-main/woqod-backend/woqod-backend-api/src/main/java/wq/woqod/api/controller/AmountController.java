package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.constants.WoqodConstant;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.AmountResource;
import wq.woqod.service.AmountService;
import wq.woqod.service.mapper.AmountModelMapper;

@RestController
@RequestMapping(value = "/amount")
public class AmountController {

    AmountService amountService;

    @Autowired
    public AmountController(AmountService amountService) {
        this.amountService = amountService;
    }

    @GetMapping(value = "/getMaxMin")
    public GenericResponse<ObjectResponse<AmountResource>> getAmount() {
        AmountResource amountResource = AmountModelMapper.mapToModel(this.amountService.findByName(WoqodConstant.TRANSACTION_AMOUNT));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(amountResource), Provider.WOQOD);
    }

    @GetMapping(value = "/updateAmount")
    public GenericResponse<BooleanResponse> updateAmount(@RequestParam(value = "max") String max,
                                                         @RequestParam(value = "min") String min) {
        AmountResource amountToUpdate = AmountModelMapper.mapToModel(this.amountService.findByName(WoqodConstant.TRANSACTION_AMOUNT));
        amountToUpdate.setMaxAmount(Double.valueOf(max));
        amountToUpdate.setMinAmount(Double.valueOf(min));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(this.amountService.update(AmountModelMapper.mapToEntity(amountToUpdate))), Provider.WOQOD);
    }

    @GetMapping("")
    public String x() {
        return "ok";
    }
}
