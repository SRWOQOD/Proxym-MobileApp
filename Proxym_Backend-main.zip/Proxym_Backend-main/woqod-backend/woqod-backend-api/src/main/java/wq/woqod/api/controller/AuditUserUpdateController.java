package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.AuditUserUpdateResource;
import wq.woqod.service.AuditUserUpdateService;

import java.text.ParseException;


/**
 * Created by nada.achour  on 18/10/2022.
 */
@RestController
@Slf4j
@RequestMapping(value = "/auditUserUpdate")
public class AuditUserUpdateController {

    private final AuditUserUpdateService auditUserUpdateService;

    public AuditUserUpdateController(AuditUserUpdateService auditUserUpdateService) {
        this.auditUserUpdateService = auditUserUpdateService;
    }


    @PostMapping(value = "/save")
    public GenericResponse<ObjectResponse<AuditUserUpdateResource>> save(@RequestBody AuditUserUpdateResource auditUserUpdateResource) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(auditUserUpdateService.save(auditUserUpdateResource)), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<AuditUserUpdateResource>> getFilteredUserUpdates(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                           @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) throws ParseException {

        Page<AuditUserUpdateResource> auditUserUpdateResources = auditUserUpdateService.filter(pageable, parameters);

        PagedModel result = assembler.toModel(auditUserUpdateResources);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, auditUserUpdateResources.getContent()), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(auditUserUpdateService.count()), Provider.WOQOD);
    }

}

