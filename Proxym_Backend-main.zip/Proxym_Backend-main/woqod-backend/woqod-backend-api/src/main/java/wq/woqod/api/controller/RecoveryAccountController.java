package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.api.validator.UserValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.enumerations.LanguageEnum;
import wq.woqod.resources.resources.RecoverPasswordResource;
import wq.woqod.service.RecoveryAccountService;

import javax.validation.Valid;

/**
 * Created by med-taher.ben-torkia on 1/16/2017.
 */

@RestController
@RequestMapping(value = "")
public class RecoveryAccountController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RecoveryAccountController.class);

    private final RecoveryAccountService recoveryAccountService;

    @Autowired
    public RecoveryAccountController(final RecoveryAccountService recoveryAccountService) {
        this.recoveryAccountService = recoveryAccountService;
    }

    @PostMapping(value = "/sendrecoverycode")
    public GenericResponse sendRecoveryCode(@RequestBody @Valid RecoverPasswordResource recoverPasswordResource) {
        LOGGER.info("[Controller] POST send recovery code : userName {} in {}", recoverPasswordResource.getUsername(), recoverPasswordResource);
        UserValidator.preSendRecoveryCode(recoverPasswordResource.getUsername(), recoverPasswordResource.getLanguage());
        recoveryAccountService.createRecoveryAccount(recoverPasswordResource.getUsername(), LanguageEnum.valueOf(recoverPasswordResource.getLanguage().name()), recoverPasswordResource.getType());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/checkrecoverycode")
    public GenericResponse checkrecoverycode(@RequestBody @Valid RecoverPasswordResource recoverPasswordResource) {
        LOGGER.info("[Controller] POST check recovery code : username {} in {}", recoverPasswordResource.getUsername(), recoverPasswordResource.getType());
        recoveryAccountService.checkrecoverycode(recoverPasswordResource.getUsername(), recoverPasswordResource.getPincode(), recoverPasswordResource.getType());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/recover")
    public GenericResponse recoverPassword(@RequestBody @Valid RecoverPasswordResource recoverPasswordResource) {
        LOGGER.info("[Controller] POST recover Password to userName: {}", recoverPasswordResource.getUsername());
        recoveryAccountService.recoverPassword(recoverPasswordResource.getUsername(), recoverPasswordResource.getNewpassword(), recoverPasswordResource.getType());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
