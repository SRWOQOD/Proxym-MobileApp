package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.AuthenticationResource;
import wq.woqod.resources.resources.UserResource;
import wq.woqod.service.LoginService;
import wq.woqod.service.mapper.UserResourceMapper;
import wq.woqod.service.models.User;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * @author med-amine.ben-ahmed
 */

@RestController
@RequestMapping(value = "/")
@Slf4j
public class LoginController {
    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    /**
     * Used for User auhentication
     *
     * @param authenticationResource
     * @return
     */
    @PostMapping(value = "/login")
    public GenericResponse<ObjectResponse<UserResource>> login(@RequestBody @Valid AuthenticationResource authenticationResource) {
        User user = loginService.login(authenticationResource);
        UserResource userResource = UserResourceMapper.mapToUserResource(user);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(userResource), Provider.WOQOD);
    }

    /**
     * Used for User auhentication
     *
     * @param deviceId
     * @return
     */
    @GetMapping(value = "/logoutt")
    public GenericResponse<BooleanResponse> logout(@RequestParam(value = "deviceId") String deviceId) {
        loginService.logout(deviceId);

        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);

    }

    /**
     * Used for User auhentication
     *
     * @param authenticationResource
     * @return
     */
    @PostMapping(value = "/verifyCredentials")
    public GenericResponse verifyCredentials(@RequestBody @Valid AuthenticationResource authenticationResource) {
        Boolean res = loginService.verifyCredentials(authenticationResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(res), Provider.WOQOD);

    }

    @PostMapping(value = "/updateWoqodeUser")
    public GenericResponse<BooleanResponse>  updateWoqodeUser(@RequestParam(value = "qid") String qid, @RequestParam(value = "mobile") String mobile,@RequestParam(value = "isWoqode") boolean isWoqode) {
        loginService.updateWoqodeUser(qid, mobile, isWoqode);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
