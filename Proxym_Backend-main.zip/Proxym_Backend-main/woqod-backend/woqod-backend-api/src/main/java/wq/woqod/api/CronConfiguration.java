package wq.woqod.api;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import wq.woqod.dao.entity.Car;
import wq.woqod.resources.enumerations.ContentCategoryEnum;
import wq.woqod.resources.enumerations.PushNotifEnum;
import wq.woqod.resources.resources.notifications.SendDeviceNotificationResource;
import wq.woqod.service.*;
import wq.woqod.service.utils.SendMail;

import javax.mail.MessagingException;
import java.awt.*;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Component
public class CronConfiguration {
    private static final String REMINDER_ENGLISH_MESSAGE = "Hello %s, the registration of your vehicle with plate %s will expire in less than 30 days";
    private static final String REMINDER_ARABIC_MESSAGE = "مرحبًا, ينتهي تسجيل سيارتك برقم اللوحة %s  في أقل من 30 يومًا ";
    private static final String ENGLISG_ARABIC_SEPARATOR = "*-*-*-*-*-*-*-*-*-*";
    private final CronService cronService;
    String messageAr = "";
    String messageEn = "";
    @Autowired
    private NotificationService sendPushNotification;
    @Autowired
    private CarService carService;
    @Autowired
    private TransactionService transactionService;

    @Autowired
    private PRTransactionLogService prTransactionLogService;

    @Autowired
    private FahesQpayTransactionService qpayFahesTransactionService;

    @Autowired
    private WoqodeQpayTransactionService woqodeQpayTransactionService;


    @Autowired
    SendMail sendMail;

    private String contentAddress;
    private String cronEmail;
    private String address;

    @Autowired
    public CronConfiguration(final CronService cronService) {
        this.cronService = cronService;
    }

    @Value("${cron.content.address}")
    public void setContentAdress(String contentAddress) {
        this.contentAddress = contentAddress;
    }

    @Value("${cron.woqode.email}")
    public void setCronEmail(String cronEmail) {
        this.cronEmail = cronEmail;
    }

    @Scheduled(cron = "${sharepoint.cron.time}")
    public void startSharepointCron() throws UnknownHostException {
        try {
            if (InetAddress.getLocalHost().getHostAddress().equals(contentAddress)) {

                Stream<ContentCategoryEnum> categories = Stream.of(ContentCategoryEnum.values());
                List<ContentCategoryEnum> cats = categories
                        .map(category -> ContentCategoryEnum.valueOf(category.name()))
                        .collect(Collectors.toList());

                //TODO: HSN UNCOMMENT IF YOU WANT TEST PROMOTION SYNCHRO
                cronService.startCron(cats);
            }
        } catch (Exception e) {
            sendMail.sendMailError(cronEmail, e.getMessage());
        }
    }


    public void fahesInspectionReminder() {
        LocalDate today = LocalDate.now().plusDays(30);
        List<Car> carList = carService.findCarsByRegExpirationDate(today);

        carList.forEach(car -> {
            if (!(Objects.isNull(car.getOwner()))) {
                messageEn = String.format(REMINDER_ENGLISH_MESSAGE, car.getOwner().getFirstName(), car.getPlateNumber());
                messageAr = String.format(REMINDER_ARABIC_MESSAGE, car.getPlateNumber());

                SendDeviceNotificationResource notificationResource = new SendDeviceNotificationResource();
                notificationResource.setId(car.getId());
                notificationResource.setDescriptionEn(messageEn + ENGLISG_ARABIC_SEPARATOR + messageAr);
                notificationResource.setTitleEn("Reminder");
                notificationResource.setType(PushNotifEnum.FAHES);
                notificationResource.setUserIds(Arrays.asList(car.getOwner().getId().toString()));
                try {
                    sendPushNotification.send(notificationResource);
                } catch (SQLException throwables) {
                    log.error(throwables.getMessage());
                }
            }
        });


    }


    public void updateAllCarCron() {
        carService.updateAllCarsCron();
    }

    @Scheduled(cron = "${transaction.cron.time}")
    public void checkTransaction() throws UnknownHostException {
        if (InetAddress.getLocalHost().getHostAddress().equals(address)) {
            transactionService.startCron();
        }
    }

    @Scheduled(cron = "${fahes.transaction.cron.time}")
    public void checkPRTransaction() throws IOException, MessagingException, FontFormatException {
        if (InetAddress.getLocalHost().getHostAddress().equals(address)) {
            prTransactionLogService.startCron();
        }
    }

    /**
     * QPay payment cron jobs
     **/
    @Scheduled(cron = "${fahes.qpay.transaction.cron.time}")
    public void checkInProgressFahesQpayTransactions() throws IOException, FontFormatException {
        if (InetAddress.getLocalHost().getHostAddress().equals(address)) {
            qpayFahesTransactionService.startCron();
        }
    }

    @Scheduled(cron = "${woqode.qpay.transaction.cron.time}")
    public void checkInProgressWoqodeQpayTransaction() throws IOException {
        if (InetAddress.getLocalHost().getHostAddress().equals(address)) {
            woqodeQpayTransactionService.startCron();
        }
    }

    @Value("${cron.address}")
    public void setAdress(String address) {
        this.address = address;
    }

}
