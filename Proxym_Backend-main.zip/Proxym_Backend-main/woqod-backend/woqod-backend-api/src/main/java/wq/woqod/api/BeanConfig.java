package wq.woqod.api;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfig {
}
