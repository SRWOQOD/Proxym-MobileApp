package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.resources.RatingResource;
import wq.woqod.service.RatingService;

import javax.validation.Valid;

/**
 * Created by ameni on 02/12/16.
 */
@RestController
@RequestMapping(value="/ratings")
public class RatingController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RatingController.class);

    private final RatingService ratingService;

    @Autowired
    public RatingController(RatingService ratingService) {
        this.ratingService = ratingService;
    }

    @PostMapping(value="")
    public GenericResponse postRating(@RequestBody @Valid RatingResource ratingResource) {
        LOGGER.info("[Controller] POST - Rating : for station {} and user {}", ratingResource.getStationId(), ratingResource.getDeviceId());
        ratingService.createRating(ratingResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
