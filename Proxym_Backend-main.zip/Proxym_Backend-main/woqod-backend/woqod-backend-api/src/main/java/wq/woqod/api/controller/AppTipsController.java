package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.AppTipsResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.UpdateAppTipsResource;
import wq.woqod.service.AppTipsService;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/apptips")
public class AppTipsController {

    @Autowired
    private AppTipsService appTipsService;

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<AppTipsResource>> getAdsbanner(@RequestParam(value = "device") String device) {

        List<AppTipsResource> list;
        list = appTipsService.getAppTips(device);

        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);

    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ListResponse> getFilteredList(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        log.info("[AppTipsController] getFilteredList");
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(appTipsService.filter(parameters)), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<AppTipsResource>> getById(@PathVariable String id) {
        log.info("[AppTipsController] getById");
        AppTipsResource adsBannerResource = appTipsService.getById(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(adsBannerResource), Provider.WOQOD);
    }

   @PutMapping(value = "/all")
    public GenericResponse<BooleanResponse> updateArea(@RequestBody @Valid UpdateAppTipsResource list) {
        appTipsService.update(list.getList());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateAppTip(@RequestBody @Valid AppTipsResource appTipsResource) {
        appTipsService.update(appTipsResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/active")
    public GenericResponse activebanner() {

        List<AppTipsResource> list;
        list = appTipsService.getActiveAppTips();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(appTipsService.count()), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> delete(@PathVariable String id) {
        appTipsService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
