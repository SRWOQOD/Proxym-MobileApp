package wq.woqod.api.controller;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.TendersResource;
import wq.woqod.service.TendersService;
import wq.woqod.service.client.TenderCronItemClient;
import wq.woqod.service.client.TendersCronClient;
import wq.woqod.service.client.api.SharedPointTenderItemResponse;
import wq.woqod.service.client.api.SharedPointTendersResponse;
import wq.woqod.service.mapper.TenderModelMapper;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/tender")
@Slf4j
public class TenderTest {

    private final TendersCronClient tendersCronClient;
    private final TenderCronItemClient tenderCronItemClient;
    private final TendersService tendersService;

    @Autowired
    public TenderTest(TendersCronClient tendersCronClient, TenderCronItemClient tenderCronItemClient, TendersService tendersService) {
        this.tendersCronClient = tendersCronClient;
        this.tenderCronItemClient = tenderCronItemClient;
        this.tendersService = tendersService;
    }

    @GetMapping(value = "")
    public GenericResponse getTenders() {
        List<SharedPointTenderItemResponse> ids = new ArrayList<>();
        ids = tendersCronClient.getTenders(null, ids);
        List<SharedPointTendersResponse> list = new ArrayList<>();
        for (SharedPointTenderItemResponse sharedPointTenderItemResponse : ids
        ) {
            list.add(tenderCronItemClient.getTendersDetails(sharedPointTenderItemResponse.getId().toString()));
        }
        List<TendersResource> tendersResources = TenderModelMapper.mapToListTender(list);
        tendersService.createTenders(tendersResources);

        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(list), Provider.WOQOD);
    }
}
