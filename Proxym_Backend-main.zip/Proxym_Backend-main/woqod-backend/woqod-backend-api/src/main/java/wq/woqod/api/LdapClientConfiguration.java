package wq.woqod.api;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.ldap.ppolicy.PasswordPolicyAwareContextSource;

@Configuration
public class LdapClientConfiguration {

    final Environment env;

    public LdapClientConfiguration(Environment env) {
        this.env = env;
    }

    @Bean
    public PasswordPolicyAwareContextSource contextSource() {
        PasswordPolicyAwareContextSource contextSource = new PasswordPolicyAwareContextSource(env.getRequiredProperty("ldap.url"));
        contextSource.setBase(env.getRequiredProperty("ldap.base"));
        contextSource.setUserDn(env.getRequiredProperty("ldap.managerDn"));
        contextSource.setPassword(env.getRequiredProperty("ldap.password"));
        return contextSource;
    }

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

}
