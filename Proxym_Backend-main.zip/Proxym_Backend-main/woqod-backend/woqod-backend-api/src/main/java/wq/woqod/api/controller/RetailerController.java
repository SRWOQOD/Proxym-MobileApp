package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.RetailersResource;
import wq.woqod.service.RetailerService;

import java.util.Collections;
import java.util.List;


@RestController
@RequestMapping(value = "/retailers")
@Slf4j
public class RetailerController {

    private final RetailerService retailerService;

    public RetailerController(RetailerService retailerService) {
        this.retailerService = retailerService;
    }

    @GetMapping(value = "")
    public GenericResponse getShafafRetailers() {
        log.info("[RetailerController] getShafafRetailers");
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(retailerService.getAllRetailers()), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFilteredShafafRetailers(Pageable pageable, PagedResourcesAssembler assembler,
                                                      @RequestParam MultiValueMap<String, String> parameters) {
        Page<RetailersResource> retailersResources = retailerService.getFilteredShafafRetailers(pageable, parameters);
        PagedModel result = assembler.toModel(retailersResources);
        List<RetailersResource> retailersResourceList = Collections.unmodifiableList(retailersResources.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, retailersResourceList), Provider.WOQOD);
    }


}
