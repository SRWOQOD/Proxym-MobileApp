package wq.woqod.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.resources.PinCodeResource;
import wq.woqod.resources.resources.ProfileUpadateRessource;
import wq.woqod.service.PinCodeService;

/**
 * Created by Hassen.Ellouze on 06/02/2019.
 */
@RestController
@RequestMapping(value = "/pincode")
public class PinCodeController {

    @Autowired
    PinCodeService pinCodeService;

    @PostMapping(value = "/send")
    public GenericResponse sendPinCode(@RequestBody PinCodeResource pinCodeResource) {
        boolean response = pinCodeService.sendPinCode(pinCodeResource.getUsername(), pinCodeResource.getLanguage(), pinCodeResource.getBiostatus());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }

    @PostMapping(value = "/validatePinCode")
    public GenericResponse validateBioPin(@RequestBody PinCodeResource pinCodeResource) {
        boolean response = pinCodeService.isValidPinCode(pinCodeResource.getUsername(), pinCodeResource.getPincode(), pinCodeResource.getBiostatus());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }

    /**
     * uthentication - STEP2
     * @param pinCodeResource
     * @return
     */
    @PostMapping(value = "/login/send")
    public GenericResponse sendPinCodeLogin(@RequestBody PinCodeResource pinCodeResource) {
        boolean response = pinCodeService.sendPinCodeLogin(pinCodeResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }

    /**
     * Authentication -STEP3
     * @param pinCodeResource
     * @return
     */
    @PostMapping(value = "/login/validatePinCode")
    public GenericResponse validateBioPinLogin(@RequestBody PinCodeResource pinCodeResource) {
        boolean response = pinCodeService.validateBioPinLogin(pinCodeResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }

        @PostMapping(value = "/sendPinCodeToUpdateUserEMail")
        public GenericResponse sendPinCodeToUpdateUserEMail(@RequestBody ProfileUpadateRessource profileUpadateRessource) {
            boolean response = pinCodeService.sendPinCodeToEmail(profileUpadateRessource.getUsername(), profileUpadateRessource.getLanguage(),profileUpadateRessource.getEmail());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }
        @PostMapping(value = "/sendPinCodeToUpdateUserPhone")
        public GenericResponse sendPinCodeToUpdatePhone(@RequestBody ProfileUpadateRessource profileUpadateRessource) {
            boolean response = pinCodeService.sendPinCodeToUpdatePhone(profileUpadateRessource.getUsername(), profileUpadateRessource.getLanguage(),profileUpadateRessource.getPhone());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(response), Provider.WOQOD);
    }
}
