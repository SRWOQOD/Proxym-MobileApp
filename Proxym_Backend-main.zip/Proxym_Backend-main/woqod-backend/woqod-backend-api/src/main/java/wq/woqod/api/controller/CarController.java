package wq.woqod.api.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.spring.web.json.Json;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.exception.RestBackendException;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.CarResource;
import wq.woqod.service.CarService;
import wq.woqod.service.mapper.CarMapper;

import javax.validation.Valid;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * Created by med-amine.dahhmen on ?
 */

@Api(value = "Car Controller")
@RestController
@Slf4j
@RequestMapping(value = "/car")
public class CarController {

    private final CarService carService;

    public CarController(CarService carService) {
        this.carService = carService;
    }


    @ApiOperation(value = "Add list of cars")
    @PostMapping(value = "registerCars")
    public GenericResponse<ListResponse<CarResource>> registerNewCars(@RequestBody @Valid List<CarResource> carResources, @RequestParam(value = "pincode") String pinCode, @RequestParam(value = "qid") String qid) {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(carService.createList(qid, carResources)), Provider.WOQOD);
    }


    @ApiOperation(value = "Delete a car")
    @DeleteMapping(value = "")
    public GenericResponse<BooleanResponse> deleteCar(@RequestParam long id, @RequestParam String qid) {
        carService.delete(qid, id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @ApiOperation(value = "update car fuel status")
    @PutMapping(value = "update")
    public GenericResponse<BooleanResponse> updateCarFuelStatus(@RequestParam String id, @RequestParam String qid, @RequestParam Boolean status) throws RestBackendException {
        carService.updateCarFuelStatus(Long.valueOf(id), qid, status);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @ApiOperation(value = "update car fuel Limit")
    @PutMapping(value = "updateCarFuelLimit")
    public GenericResponse<BooleanResponse> updateCarFuelLimit(@RequestParam String id, @RequestParam String qid, @RequestParam String fuel) throws RestBackendException {
        carService.updateCarFuelLimit(Long.valueOf(id), qid, fuel);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<PaginatedListResponse<CarResource>> getFilteredCars(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                               @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) {
        Page<CarResource> transactionLogModel = carService.getFiltered(pageable, parameters);
        PagedModel result = assembler.toModel(transactionLogModel);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, transactionLogModel.getContent()), Provider.WOQOD);
    }


    @GetMapping(value = "/getCarsByQid")
    public GenericResponse<ListResponse<CarResource>> getCarsByQid(@RequestParam(value = "qid") String qid) {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(carService.getCarsByQid(qid)), Provider.WOQOD);
    }


    @ApiOperation(value = "Check if a car exist", response = GenericResponse.class)
    @GetMapping(value = "checkCar")
    public GenericResponse<ObjectResponse<Json>> checkCar(@RequestParam(value = "qid", required = false) String qid, @RequestParam(value = "plate_number", required = false) String plateNumber, @RequestParam(value = "plate_type_id", required = false) String plateType) {
        CarResource car = carService.checkCar(qid, plateNumber, plateType);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(car), Provider.WOQOD);
    }

    @PostMapping(value = "register")
    public GenericResponse<BooleanResponse> registerNewCar(@RequestBody @Valid CarResource carResource, @RequestParam(value = "pincode") String pinCode, @RequestParam(value = "qid") String qid) {
        carService.create(qid, pinCode, CarMapper.mapToCarEntity(carResource));
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "isOwner")
    public GenericResponse<ObjectResponse<CarResource>> isOwner(@RequestParam(value = "qid") String qid, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type_id") String plateType) throws IOException {
        HashMap<String, Object> car = carService.isOwner(qid, plateNumber, plateType);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(car), Provider.WOQOD);
    }

    @GetMapping(value = "isOwnerAddCar")
    public GenericResponse<ObjectResponse<CarResource>> isOwnerAddCar(@RequestParam(value = "qid") String qid, @RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "plate_type_id") String plateType) {
        HashMap<String, Object> car = carService.isOwnerAddCar(qid, plateNumber, plateType);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(car), Provider.WOQOD);
    }

    @PutMapping(value = "/changeStatus")
    public GenericResponse<ObjectResponse<CarResource>> changeStatus(@RequestParam(value = "plate_number") String plateNumber, @RequestParam(value = "qid") String qid) {
        log.info("[Controller] PATCH  DESCATIVATE/ACTIVATE CAR BY PLATE NUMBER : {}", plateNumber);
        carService.updateStatus(plateNumber, qid);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/cars")
    public GenericResponse<ObjectResponse<CarResource>> getCars(@RequestParam MultiValueMap<String, String> parameters) {

        List<CarResource> list;
        list = carService.getCars(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);

    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(carService.count()), Provider.WOQOD);
    }
}
