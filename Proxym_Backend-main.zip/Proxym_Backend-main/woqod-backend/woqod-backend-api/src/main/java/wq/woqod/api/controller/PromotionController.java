package wq.woqod.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.PromotionResource;
import wq.woqod.service.PromotionService;
import wq.woqod.service.mapper.PromotionRessourceMapper;

import java.util.Collections;
import java.util.List;


@RestController
@RequestMapping(value = "/promotions")
public class PromotionController {
    private static final Logger LOGGER = LoggerFactory.getLogger(PromotionController.class);

    private final PromotionService promotionService;

    @Autowired
    public PromotionController(PromotionService promotionService) {
        this.promotionService = promotionService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<PromotionResource>> getPromotions() {
        LOGGER.info("[Controller] GET All Promotions ");
        List<PromotionResource> promotionsModelList = promotionService.getAllPromotions();
        List<PromotionResource> promotionResourceList = PromotionRessourceMapper.mapToListPromotionsRessource(promotionsModelList);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(promotionResourceList), Provider.WOQOD);
    }

    @GetMapping(value = "/promotions")
    public GenericResponse<ListResponse<PromotionResource>> getPromotionsBo(@RequestParam MultiValueMap<String, String> parameters) {
        LOGGER.info("[Controller] GET All Promotions for BO ");
        List<PromotionResource> promotionResourceList = promotionService.getAllPromotionsBo(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(promotionResourceList), Provider.WOQOD);
    }


    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<PromotionResource>> getFilteredPromotions(Pageable pageable, PagedResourcesAssembler assembler,
                                                                                    @RequestParam MultiValueMap<String, String> parameters) {
        Page<PromotionResource> promotions = promotionService.getFilteredPromotions(pageable, parameters);
        PagedModel result = assembler.toModel(promotions);
        List<PromotionResource> promotionResources = Collections.unmodifiableList(promotions.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, promotionResources), Provider.WOQOD);
    }

    @DeleteMapping(value = "/promotion/{id}")
    public GenericResponse<ObjectResponse<PromotionResource>> deletePromotion(@PathVariable Long id) {
        promotionService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/promotion/{id}")
    public GenericResponse<ObjectResponse<PromotionResource>> getPromotionById(@PathVariable Long id) {
        PromotionResource promotionResource = promotionService.getPromotionByID(id);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(promotionResource), Provider.WOQOD);
    }

    @PutMapping(value = "/promotion")
    public GenericResponse<ObjectResponse<PromotionResource>> editPromotion(@RequestBody PromotionResource promotionResource) {
        promotionService.editPromotion(promotionResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/active")
    public GenericResponse<ObjectResponse<PromotionResource>> getActivePromoitions() {
        List<PromotionResource> promotionResource = promotionService.getActivePromottions();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(promotionResource), Provider.WOQOD);
    }
}