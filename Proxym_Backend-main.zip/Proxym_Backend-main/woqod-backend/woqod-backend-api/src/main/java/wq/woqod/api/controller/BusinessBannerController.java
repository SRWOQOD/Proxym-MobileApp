package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.BusinessBannerResource;
import wq.woqod.resources.resources.DiscountResource;
import wq.woqod.resources.resources.SurveysResource;
import wq.woqod.resources.resources.UpdateBusinessResource;
import wq.woqod.service.BusinessBannerService;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/businessbanner")
public class BusinessBannerController {
    @Autowired
    private BusinessBannerService businessBannerService;

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<BusinessBannerResource>> getAdsbanner() {
        List<BusinessBannerResource> list;
        list = businessBannerService.getbanner();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);

    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ListResponse> getFilteredList(@RequestParam(required = false) MultiValueMap<String, String> parameters) {
        log.info("[BusinessBannerController] getFilteredList");
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(businessBannerService.filter(parameters)), Provider.WOQOD);
    }

    @GetMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<DiscountResource>> getById(@PathVariable String id) {
        log.info("[BusinessBannerController] getById");
        BusinessBannerResource adsBannerResource = businessBannerService.getById(Long.valueOf(id));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(adsBannerResource), Provider.WOQOD);
    }

    @PutMapping(value = "/all")
    public GenericResponse<BooleanResponse> update(@RequestBody @Valid UpdateBusinessResource list) {
        businessBannerService.update(list.getList());
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<BooleanResponse>> updateArea(@RequestBody @Valid BusinessBannerResource businessBannerResource) {
        businessBannerService.update(businessBannerResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/activebanner")
    public GenericResponse activebanner() {
        List<BusinessBannerResource> list;
        list = businessBannerService.getActiveBanner();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(list), Provider.WOQOD);

    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(businessBannerService.count()), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<SurveysResource>> delete(@PathVariable String id) {
        businessBannerService.delete(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
