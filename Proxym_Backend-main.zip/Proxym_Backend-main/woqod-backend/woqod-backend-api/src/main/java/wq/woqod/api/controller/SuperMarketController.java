package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.SuperMarketResource;
import wq.woqod.service.SuperMarketService;
import wq.woqod.service.mapper.SuperMarketResourceMapper;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping(value = "/SuperMarket")
@Slf4j
public class SuperMarketController {

    private final SuperMarketService superMarketService;

    @Autowired
    public SuperMarketController(SuperMarketService superMarketService) {
        this.superMarketService = superMarketService;
    }

    @GetMapping(value = "")
    public GenericResponse getSuperMarkets() {
        List<SuperMarketResource> superMarketVos = superMarketService.getAllSuperMarkets();
         List<SuperMarketResource> superMarketResources = SuperMarketResourceMapper.mapToListSuperMarketResource(superMarketVos);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(superMarketResources), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse getFilteredSupermarkets(Pageable pageable, PagedResourcesAssembler assembler,
                                                   @RequestParam MultiValueMap<String, String> parameters) {
        Page<SuperMarketResource> superMarketResources = superMarketService.getFilteredSupermarkets(pageable, parameters);
        PagedModel result = assembler.toModel(superMarketResources);
        List<SuperMarketResource> superMarketResourceList = Collections.unmodifiableList(superMarketResources.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, superMarketResourceList), Provider.WOQOD);
    }

}
