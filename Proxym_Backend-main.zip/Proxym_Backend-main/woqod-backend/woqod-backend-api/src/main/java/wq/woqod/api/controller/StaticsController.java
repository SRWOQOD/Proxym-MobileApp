package wq.woqod.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.service.DashboardService;

import java.text.ParseException;

@RestController
@RequestMapping(value = "/statics")
public class StaticsController {

    private final DashboardService dashboardService;

    public StaticsController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping
    public GenericResponse<ObjectResponse> getLoginStatics(@RequestParam(required = false) String qid, @RequestParam(required = false) String dateFrom, @RequestParam(required = false) String category, @RequestParam(required = false) String dateTo) throws ParseException {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(dashboardService.getStatics(qid, category, dateFrom, dateTo)), Provider.WOQOD);
    }

}
