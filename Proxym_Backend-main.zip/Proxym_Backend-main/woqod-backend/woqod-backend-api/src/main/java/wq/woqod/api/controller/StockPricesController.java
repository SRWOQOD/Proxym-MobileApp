package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.StockPricesRessource;
import wq.woqod.service.StockPricesService;

import javax.validation.Valid;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping(value = "/stockPrices")
@Slf4j
public class StockPricesController {
    private final StockPricesService stockPricesService;

    @Autowired
    public StockPricesController(StockPricesService stockPricesService) {
        this.stockPricesService = stockPricesService;
    }

    @GetMapping(value = "/getLastStockPrices")
    public GenericResponse getStockPrices() throws ParseException {
        StockPricesRessource stockPricesRessource = stockPricesService.getLastStockPrices();
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(stockPricesRessource), Provider.WOQOD);
    }

    @GetMapping
    public GenericResponse getLastStockPrices() {
        List<StockPricesRessource> stockPricesRessources = stockPricesService.getStockPrices();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(stockPricesRessources), Provider.WOQOD);
    }

    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<StockPricesRessource>> createStockPricesRessource(@RequestBody @Valid StockPricesRessource stockPricesRessource) {
        stockPricesService.createStockPrices(stockPricesRessource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
