package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.ContractorResource;
import wq.woqod.service.ContractorService;

import java.util.List;

@RestController
@RequestMapping(value = "/Contractor")
@Slf4j
public class ContractorController {

    private final ContractorService contractorService;

    @Autowired
    public ContractorController(ContractorService contractorService) {
        this.contractorService = contractorService;
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<ContractorResource>> getAllContractors() {
        log.info("[Controller] GET All Contractors ");
        List<ContractorResource> contractorResources = contractorService.getAllContractors();
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(contractorResources), Provider.WOQOD);
    }
}
