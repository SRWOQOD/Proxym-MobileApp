package wq.woqod.api.controller;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.errors.WoqodError;
import wq.woqod.commons.exception.AccessDataException;
import wq.woqod.commons.exception.WoqodException;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;

import java.text.MessageFormat;

@Slf4j
@ControllerAdvice
public class ExceptionHandlerController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandlerController.class);
    private static final String EXCEPTION = "exception";

    @ExceptionHandler(WoqodException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<WoqodException>> handleProxymExceptions(WoqodException e) {
        log.error(e.getMessage());
        return e.buildErrorResponse();
    }


    @ExceptionHandler(RuntimeException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<RuntimeException>> handleNullPointerExceptions(RuntimeException e) {
        String exceptionKey = e.toString();
        WoqodError error = WoqodError.ERROR_GENERAL_FAILURE;
        LOGGER.error(EXCEPTION, e.getStackTrace()[0].getFileName(), e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), e);
        return ResponseBuilder.buildErrorResponse(error.getCode(), error.getMsgEN(), error.getMsgAR(), exceptionKey, e.getMessage(), Provider.WOQOD, null, null);
    }


    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<HttpRequestMethodNotSupportedException>> handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
        String supportedMethods = String.join(", ", e.getSupportedMethods());
        WoqodError error = WoqodError.METHOD_NOT_SUPPORTED;
        String titleEN = MessageFormat.format(error.getMsgEN(), e.getMethod(), supportedMethods);
        String titleAR = MessageFormat.format(error.getMsgAR(), e.getMethod(), supportedMethods);
        LOGGER.error(EXCEPTION, e.getStackTrace()[0].getFileName(), e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), e);
        return ResponseBuilder.buildErrorResponse(error.getCode(), titleEN, titleAR, null, e.getMessage(), Provider.WOQOD, null, null);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<HttpMessageNotReadableException>> handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {

        LOGGER.error(EXCEPTION, e.getStackTrace()[0].getFileName(), e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), e);

        if (e.getCause() instanceof InvalidFormatException) {
            InvalidFormatException exception = (InvalidFormatException) e.getCause();
            String field = exception.getValue().toString();
            String targetEnum = exception.getTargetType().getName();

            WoqodError error = WoqodError.BINDING_FAILED;
            String titleEN = MessageFormat.format(error.getMsgEN(), field, targetEnum);
            String titleAR = MessageFormat.format(error.getMsgAR(), field, targetEnum);
            return ResponseBuilder.buildErrorResponse(error.getCode(), titleEN, titleAR, null, exception.getMessage(), Provider.WOQOD, null, null);
        } else {
            WoqodError error = WoqodError.ERROR_GENERAL_FAILURE;
            return ResponseBuilder.buildErrorResponse(error.getCode(), error.getMsgEN(), error.getMsgAR(), null, e.getMessage(), Provider.WOQOD, null, null);
        }
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<MethodArgumentTypeMismatchException>> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException e) {
        LOGGER.error("[exception] {0} {1} {2} {3}", e.getStackTrace()[0].getFileName(), e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), e);
        String field = null;
        String targetEnum = null;

        if (e.getCause() instanceof ConversionFailedException) {
            ConversionFailedException exception = (ConversionFailedException) e.getCause();
            Object exceptionValue = exception.getValue();
            TypeDescriptor exceptionTargetType = exception.getTargetType();

            if (exceptionValue != null) {
                field = exceptionValue.toString();
            }
            targetEnum = exceptionTargetType.getName();


            WoqodError error = WoqodError.BINDING_FAILED;
            String titleEN = MessageFormat.format(error.getMsgEN(), field, targetEnum);
            String titleAR = MessageFormat.format(error.getMsgAR(), field, targetEnum);
            return ResponseBuilder.buildErrorResponse(error.getCode(), titleEN, titleAR, null, exception.getMessage(), Provider.WOQOD, null, null);
        } else {
            WoqodError error = WoqodError.ERROR_GENERAL_FAILURE;
            return ResponseBuilder.buildErrorResponse(error.getCode(), error.getMsgEN(), error.getMsgAR(), null, e.getMessage(), Provider.WOQOD, null, null);
        }

    }

    @ExceptionHandler(AccessDataException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<AccessDataException>> handleAccessDataExceptionExceptions(AccessDataException e) {

        String message = e.getMessage();
        if (e.getCause() != null && e.getCause().getCause() instanceof ConstraintViolationException) {
            ConstraintViolationException exception = (ConstraintViolationException) e.getCause().getCause();
            message = exception.getSQLException().getMessage();
        }
        return ResponseBuilder.buildErrorResponse("", e.getEnMsg(), e.getArbMsg(), e.getKey(), message,
                Provider.WOQOD, null, null);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<MethodArgumentNotValidException>> handleNullPointerExceptions(MethodArgumentNotValidException e) {
        String fieldName = null;

        WoqodError error = WoqodError.INPUT_DATA_MISSING;
        FieldError bindingResult = e.getBindingResult().getFieldError();
        if (bindingResult != null) {
            fieldName = bindingResult.getField();
        }
        return ResponseBuilder.buildErrorResponse(error.getCode(), error.getMsgEN(fieldName), error.getMsgAR(fieldName), null, e.getMessage(),
                Provider.WOQOD, null, null);
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public GenericResponse<ObjectResponse<Exception>> handleDefaultExceptions(Exception e) {
        WoqodError error = WoqodError.ERROR_GENERAL_FAILURE;
        LOGGER.debug("An exception have been occurred please see logging error");
        LOGGER.error("[exception] {0} {1} {2} {3}", e.getStackTrace()[0].getFileName(), e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), e);
        return ResponseBuilder.buildErrorResponse(error.getCode(), error.getMsgEN(), error.getMsgAR(), null, e.getMessage(),
                Provider.WOQOD, null, null);
    }

}
