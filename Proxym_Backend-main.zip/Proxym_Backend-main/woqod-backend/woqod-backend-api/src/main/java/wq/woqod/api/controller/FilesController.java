package wq.woqod.api.controller;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.resources.resources.FileUploadResource;
import wq.woqod.service.AzureFileStorage;
import wq.woqod.service.FilesStorageService;
@RestController
@RequestMapping(value = "/file")
public class FilesController {

    @Autowired
    FilesStorageService storageService;
    @Autowired
    AzureFileStorage azureFileStorage;

    @PostMapping("/upload-ftp")
    public GenericResponse<BooleanResponse> uploadFile(@RequestBody FileUploadResource file) throws JSchException {
            storageService.save(file);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);

    }
    @PostMapping("/upload")
    public GenericResponse<BooleanResponse> uploadFileAzure(@RequestBody FileUploadResource file)  {
        azureFileStorage.saveOrUpdateEntry(file);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
