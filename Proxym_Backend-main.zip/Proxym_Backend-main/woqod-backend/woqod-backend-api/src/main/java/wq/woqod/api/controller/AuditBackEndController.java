package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.AuditBackEndResource;
import wq.woqod.service.AuditBackEndService;

import java.text.ParseException;


/**
 * Created by amal.kamel  on 18/11/2020.
 */
@RestController
@Slf4j
@RequestMapping(value = "/auditBackEnd")
public class AuditBackEndController {

    private final AuditBackEndService auditBackEndService;

    @Autowired
    public AuditBackEndController(AuditBackEndService auditBackEndService) {
        this.auditBackEndService = auditBackEndService;
    }

    @PostMapping(value = "/save")
    public GenericResponse<ObjectResponse<AuditBackEndResource>> save(@RequestBody AuditBackEndResource auditBackEndResource) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(auditBackEndService.save(auditBackEndResource)), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<AuditBackEndResource>> getFilteredAuditBackEnd(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                         @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) throws ParseException {

        Page<AuditBackEndResource> auditBackEndResources = auditBackEndService.filter(pageable, parameters);

        PagedModel result = assembler.toModel(auditBackEndResources);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, auditBackEndResources.getContent()), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(auditBackEndService.count()), Provider.WOQOD);
    }

}

