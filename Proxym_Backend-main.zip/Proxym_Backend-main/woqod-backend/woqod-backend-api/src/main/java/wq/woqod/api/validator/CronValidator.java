package wq.woqod.api.validator;

import wq.woqod.commons.exception.InputDataMissingException;
import wq.woqod.resources.enumerations.ContentCategoryEnum;

import java.util.Objects;

/**
 * Created by ameni on 10/01/17.
 */
public class CronValidator {

    private CronValidator() {
    }

    public static void prePut(ContentCategoryEnum category) {
        if (Objects.isNull(category)) {
            throw new InputDataMissingException("category");
        }
    }
}
