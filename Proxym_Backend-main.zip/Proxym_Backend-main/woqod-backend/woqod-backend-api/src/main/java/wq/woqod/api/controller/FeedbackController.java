package wq.woqod.api.controller;

import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.api.validator.FeedBackValidator;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.Feedback;
import wq.woqod.resources.resources.FeedbackResource;
import wq.woqod.resources.resources.FeedbackResourceWithoutPhoto;
import wq.woqod.resources.resources.FeedbackResponseResource;
import wq.woqod.service.FeedbackResponseService;
import wq.woqod.service.FeedbackService;
import wq.woqod.service.mapper.FeedbackMapper;
import wq.woqod.service.mapper.FeedbackResponseMapper;

import javax.validation.Valid;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;


@RestController
@RequestMapping(value = "/feedbacks")
public class FeedbackController {


    private final FeedbackService feedbackService;
    private final FeedbackResponseService feedbackResponseService;

    @Autowired
    public FeedbackController(final FeedbackService feedbackService, final FeedbackResponseService feedbackResponseService) {
        this.feedbackService = feedbackService;
        this.feedbackResponseService = feedbackResponseService;
    }

    @GetMapping(value = "/responses")
    public GenericResponse<ObjectResponse<FeedbackResponseResource>> getAllFeedbackResponse(@RequestParam(value = "id") String id) {
        List<FeedbackResponseResource> feedbackResources = feedbackResponseService.getAllFeedBackResponse(id);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(feedbackResources), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<FeedbackResource>> getFeedbackHistoryByUserName(@RequestParam(value = "username") String userName) throws SQLException {
        List<FeedbackResource> feedbackResources;
        feedbackResources = feedbackService.getFeedbacksHistoryByUserName(userName);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(feedbackResources), Provider.WOQOD);
    }

    @GetMapping(value = "/lazyFeedbackHistory")
    public GenericResponse<ObjectResponse<FeedbackResourceWithoutPhoto>> getLazyFeedbackHistoryByUserName(@RequestParam(value = "username") String userName) throws SQLException {
        List<FeedbackResourceWithoutPhoto> feedbackResources = feedbackService.getLazyFeedbackHistoryByUserName(userName);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(feedbackResources), Provider.WOQOD);
    }

    @PostMapping(value = "")
    public GenericResponse<ObjectResponse<FeedbackResource>> postFeedback(@RequestBody @Valid FeedbackResource feedbackResource) {
        FeedBackValidator.prePost(feedbackResource);
        feedbackService.create(feedbackResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/response")
    public GenericResponse<ObjectResponse<FeedbackResponseResource>> postFeedbackResponse(@RequestBody @Valid FeedbackResponseResource feedbackResponseResource) throws SQLException {
        Feedback feedback = feedbackService.findByIdAndActiveStatus(feedbackResponseResource.getFeedbackId());
        feedback.setTicketNumber(feedbackResponseResource.getTicketNumber());
        feedbackService.update(FeedbackMapper.mapToResource(feedback));
        FeedbackResponseResource feedbackResponse = FeedbackResponseMapper.mapToResource(feedbackResponseResource, feedback);
        feedbackResponseService.createAndGetUserId(feedbackResponse);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @PostMapping(value = "/responseAnonym")
    public GenericResponse<ObjectResponse<FeedbackResponseResource>> postFeedbackResponseAnonym(@RequestBody @Valid FeedbackResponseResource feedbackResponseResource) {
        Feedback feedback = feedbackService.findByIdAndActiveStatus(feedbackResponseResource.getFeedbackId());
        feedback.setTicketNumber(feedbackResponseResource.getTicketNumber());
        feedbackService.update(FeedbackMapper.mapToResource(feedback));
        feedbackResponseService.create(feedbackResponseResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @GetMapping(value = "/feedback/{id}")
    public GenericResponse<ObjectResponse<FeedbackResource>> getFeedbackResponse(@PathVariable Long id) throws SQLException {
        FeedbackResource feedbackResource = feedbackService.find(id);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feedbackResource), Provider.WOQOD);
    }

    @GetMapping(value = "/filtred")
    public GenericResponse<ObjectResponse<FeedbackResourceWithoutPhoto>> getFilteredFeedbacks(@PageableDefault(sort = {"creationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                  @QuerydslPredicate(root = wq.woqod.dao.entity.Feedback.class) Predicate predicate,
                                                                                  @RequestParam MultiValueMap<String, String> parameters) throws SQLException {
        Page<FeedbackResourceWithoutPhoto> feedbacks = feedbackService.getFilteredFeedbacks(pageable, parameters);
        PagedModel result = assembler.toModel(feedbacks);
        List<FeedbackResourceWithoutPhoto> feedbackResources = Collections.unmodifiableList(feedbacks.getContent());
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, feedbackResources), Provider.WOQOD);
    }

    @PutMapping(value = "/close")
    public GenericResponse<ObjectResponse<FeedbackResource>> closeFeedback(@RequestBody @Valid FeedbackResource feedbackResource) {
        feedbackService.update(feedbackResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }

    @DeleteMapping(value = "/{id}")
    public GenericResponse<ObjectResponse<FeedbackResponseResource>> deleteFeedback(@PathVariable Long id) {
        feedbackService.deleteFeedback(id);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @GetMapping(value = "/getFeedbackById")
    public GenericResponse<ObjectResponse<FeedbackResponseResource>> getFeedbackById(@RequestParam(value = "id") String id) {
        FeedbackResource feedbackResource;
        feedbackResource = FeedbackMapper.mapToResource(feedbackService.findById(Long.valueOf(id)));
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(feedbackResource), Provider.WOQOD);
    }

    @GetMapping(value = "/feedbacks")
    public GenericResponse<ListResponse<FeedbackResource>> getFeedbacks(@RequestParam MultiValueMap<String, String> parameters) throws SQLException {
        List<FeedbackResource> feedbackResourceList = feedbackService.findAllFeedbacks(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(feedbackResourceList), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(feedbackService.count()), Provider.WOQOD);
    }
}
