package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.TagTransactionResource;
import wq.woqod.resources.resources.inputs.InputUpdateTransaction;
import wq.woqod.service.TagTransactionService;

import java.text.ParseException;
import java.util.List;

/**
 * Created by med-amine.dahmen on 15/11/2018.
 */
@RestController
@Slf4j
@RequestMapping(value = "/tagTransaction")
public class TagTransactionController {

    private final TagTransactionService tagTransactionService;

    @Autowired
    public TagTransactionController(TagTransactionService tagTransactionService) {
        this.tagTransactionService = tagTransactionService;
    }

    @PostMapping(value = "/register")
    public GenericResponse<ObjectResponse<TagTransactionResource>> register(@RequestBody TagTransactionResource tagTransactionResource) {
        log.info("[TagTransactionController] register");
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(tagTransactionService.save(tagTransactionResource)), Provider.WOQOD);
    }


    @PutMapping(value = "/update")
    public GenericResponse<ObjectResponse<TagTransactionResource>> update(@RequestBody InputUpdateTransaction inputUpdateTransaction) {
        log.info("[TagTransactionController] update");
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(tagTransactionService.update(inputUpdateTransaction)), Provider.WOQOD);
    }


    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<TagTransactionResource>> getFilteredTransactions(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                                           @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) throws ParseException {
        log.info("[TagTransactionController] getFilteredTransactions");
        Page<TagTransactionResource> tagTransactionResources = tagTransactionService.filter(pageable, parameters);
        PagedModel result = assembler.toModel(tagTransactionResources);

        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, tagTransactionResources.getContent()), Provider.WOQOD);
    }

    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<TagTransactionResource>> getAllTagTransactions(@RequestParam MultiValueMap<String, String> parameters) throws ParseException {
        List<TagTransactionResource> resource = tagTransactionService.getAllTagTransactions(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<TagTransactionResource>(resource), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(tagTransactionService.count()), Provider.WOQOD);
    }

}

