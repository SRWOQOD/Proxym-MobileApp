package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.ConfigRessource;
import wq.woqod.service.ConfigService;

@RestController
@Slf4j
@RequestMapping(value = "/fahesQpayRefund-config")
public class FahesPaymentRefundConfigController {

    private final ConfigService configService;

    public FahesPaymentRefundConfigController(ConfigService configService) {
        this.configService = configService;
    }


    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<ConfigRessource>> isFahesQpayRefundHidden() {
        log.info("[FahesPaymentRefundConfigController] is Fahes QPay Payment Refund Process Hidden ?");
        ConfigRessource configRessource = configService.isFahesQpayPaymentRefundHidden();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(configRessource.getValue()), Provider.WOQOD);
    }


    @PutMapping(value = "")
    public GenericResponse<ObjectResponse<BooleanResponse>>  updateFahesQpayRefundProcess() {
        log.info("[FahesPaymentRefundConfigController]update Fahes QPay Payment Refund Process");
        configService.updateFahesQpayPaymentRefundConfig();
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
     }
}
