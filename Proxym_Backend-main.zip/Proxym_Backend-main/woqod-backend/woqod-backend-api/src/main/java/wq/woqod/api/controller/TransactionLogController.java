package wq.woqod.api.controller;

import com.querydsl.core.types.Predicate;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.dao.entity.TransactionLog;
import wq.woqod.resources.resources.EmailResource;
import wq.woqod.resources.resources.TransactionLogResource;
import wq.woqod.service.TransactionLogService;
import wq.woqod.service.TransactionService;
import wq.woqod.service.utils.SendMail;

import java.awt.*;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.List;

/**
 * Created by med-amine.dahmen on 15/11/2018.
 */
@RestController
@Slf4j
@RequestMapping(value = "/transactionLog")
public class TransactionLogController {

    private final TransactionLogService transactionLogService;
    private  TransactionService transactionService;

    @Autowired
    SendMail sendMail;

    @Autowired
    public TransactionLogController(final TransactionLogService transactionLogService,  TransactionService transactionService) {
        this.transactionLogService = transactionLogService;
        this.transactionService =transactionService;
    }

    @GetMapping(value = "/all")
    public GenericResponse getAllTransactionLog(@RequestParam(required = false) MultiValueMap<String, String> parameters
    ) {
        List<TransactionLogResource> transactionLogs = transactionLogService.getAll(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(transactionLogs), Provider.WOQOD);
    }

    @GetMapping(value = "/filtered")
    public GenericResponse getFilteredTransactions(@PageableDefault(sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                   @QuerydslPredicate(root = TransactionLog.class) Predicate predicate,
                                                   @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) throws ParseException {
        Page<TransactionLogResource> transactionLogModel = transactionLogService.getFiltered(predicate, pageable, parameters);
        PagedModel result = assembler.toModel(transactionLogModel);
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse(result, transactionLogModel.getContent()), Provider.WOQOD);
    }

    @ApiOperation(value = "Generating Woqode Receipt", response = GenericResponse.class)
    @GetMapping(value = "/receipt")
    public GenericResponse generateReceipt(@RequestParam(value = "reference_number") String referenceNumber) throws FontFormatException {
        log.info("Generating Woqode Receipt");
        String receipt = transactionLogService.createPDF(referenceNumber);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(receipt), Provider.WOQOD);
    }

    @ApiOperation(value = "Send Mail with barcode ", response = GenericResponse.class)
    @PostMapping(value = "/sendMail")
    public GenericResponse sendMail(@RequestBody EmailResource emailResource) throws Exception {
        log.info("reference_number: {} && email: {}", emailResource.getReferencenumber(), emailResource.getEmail());
        TransactionLogResource transactionLogResource = transactionLogService.findByReferenceNumber(emailResource.getReferencenumber());
        boolean resp;
        if (Boolean.TRUE.equals(emailResource.getConnected())) {
            resp = sendMail.sendWoqode(emailResource.getEmail(), transactionLogService.createPDF(transactionLogResource.getReferenceNumber()));
        } else {
            resp = sendMail.sendWoqode(URLDecoder.decode(emailResource.getEmail(), "UTF-8"), transactionLogService.createPDF(transactionLogResource.getReferenceNumber()));
        }
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(resp), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(transactionLogService.count()), Provider.WOQOD);
    }

    @GetMapping("/cronByDate")
    public GenericResponse cronByDate(@RequestParam(value = "date") String date) throws ParseException {
        log.info("[Controller] POST - Cron : check transaction by date");
        transactionService.startCronByDate(date);
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(true), Provider.WOQOD);
    }

}

