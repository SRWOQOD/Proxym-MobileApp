package wq.woqod.api.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.BooleanResponse;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.resources.resources.SurveyResponseResource;
import wq.woqod.service.SurveyResponseService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "/surveysResponses")
public class SurveyResponseController {

    private final SurveyResponseService surveyResponseService;

    @Autowired
    public SurveyResponseController(SurveyResponseService surveyResponseService) {
        this.surveyResponseService = surveyResponseService;
    }

    @GetMapping(value = "/all")
    public GenericResponse getAllSurveysResponse() {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(surveyResponseService.getAllResponses()), Provider.WOQOD);
    }

    @PostMapping(value = "")
    public GenericResponse createSurveyResponse(@RequestBody @Valid SurveyResponseResource surveyResponseResource) {
        surveyResponseService.createSurveyResponse(surveyResponseResource);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }


    @GetMapping(value = "/surveys/{id}")
    public GenericResponse getSurveysResponseBySurveyId(@PathVariable Long id) {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(surveyResponseService.getSurveyResponseBySurvey(id)), Provider.WOQOD);
    }

    @GetMapping(value = "/survey_response/{id}")
    public GenericResponse getSurveysResponseById(@PathVariable Long id) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(surveyResponseService.getSurveyResponseById(id)), Provider.WOQOD);
    }

    @GetMapping(value = "/survey/{id}")
    public GenericResponse getSurveysResponse(@PathVariable Long id) {
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(surveyResponseService.getSurveyResponse(id)), Provider.WOQOD);
    }


    @GetMapping(value = "/survey/update")
    public GenericResponse updateStatusAnswered(@RequestParam Long id,@RequestParam String  device) {
        surveyResponseService.updateStatusAnswered(id,device);
        return ResponseBuilder.buildSuccessResponse(new BooleanResponse(true), Provider.WOQOD);
    }
}
