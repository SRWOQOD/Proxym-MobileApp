package wq.woqod.api.log;

import com.google.common.base.Strings;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import wq.woqod.resources.resources.AuditBackEndResource;
import wq.woqod.service.AuditBackEndService;
import wq.woqod.service.UserService;
import wq.woqod.service.models.User;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

/**
 * A filter which logs web requests that lead to an error in the system.
 */
@Component
@Slf4j
public class LogRequestFilter extends OncePerRequestFilter implements Ordered {


    private static final String UERNAME = "username";
    // put filter at the end of all other filters to make sure we are processing after all others
    private int order = Ordered.LOWEST_PRECEDENCE - 8;
    @Autowired
    private AuditBackEndService auditBackEndService;

    @Autowired
    private UserService userService;

    @Value("${woqod.audit.services}")
    private List<String> services;

    @Override
    public int getOrder() {
        return order;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        AuthenticationRequestWrapper authenticationRequestWrapper = new AuthenticationRequestWrapper(request);
        AuthenticationResponseWrapper authenticationResponseWrapper = new AuthenticationResponseWrapper(response);
        log.info("Request: "+authenticationRequestWrapper);
        String paramString = "";
        StringBuilder buf = new StringBuilder();
        Enumeration<String> e1 = authenticationRequestWrapper.getParameterNames();
        while (e1.hasMoreElements()) {
            String params = e1.nextElement();
            if (params != null) {
                buf.append(" :: " + authenticationRequestWrapper.getParameter(params) + " , ");
            }
        }
        paramString = buf.toString();

        StringBuilder buf1 = new StringBuilder();
        String headersString = "";
        Enumeration<String> e = authenticationRequestWrapper.getHeaderNames();
        while (e.hasMoreElements()) {
            String headers = e.nextElement();
            if (headers != null) {
                buf1.append(" :: " + authenticationRequestWrapper.getHeader(headers) + " , ");
            }
        }
        headersString = buf1.toString();
        boolean reqb = isContentJson(authenticationRequestWrapper.getContentType());

        filterChain.doFilter(authenticationRequestWrapper, authenticationResponseWrapper);


        log.info("Service name : {}", authenticationRequestWrapper.getRequestURI());

        String serviceName = authenticationRequestWrapper.getRequestURI() == null ? "" : authenticationRequestWrapper.getRequestURI();
        log.info("Service name : {}", serviceName);

        if(services.contains(serviceName)) {

            boolean resb = isContentJson(authenticationResponseWrapper.getContentType());

            AuditBackEndResource auditBackEndResource = new AuditBackEndResource();
            auditBackEndResource.setCreationDate(new Date());
            auditBackEndResource.setIp(authenticationRequestWrapper.getRemoteAddr() == null ? "" : authenticationRequestWrapper.getRemoteAddr());
            String req = authenticationRequestWrapper.getRequestURI() + "  " + authenticationRequestWrapper.getMethod() + "\n" +
                    "HEADERS :: [ " + headersString + " ]" + "\n";

            if (!paramString.isEmpty()) {
                req += "PARAMS :: [" + paramString + "]";
            }
            if (!authenticationRequestWrapper.payload.isEmpty()) {
                req += "BODY :: [" + authenticationRequestWrapper.payload.isEmpty() + "]";
            }
            auditBackEndResource.setRequest(req);
            auditBackEndResource.setResponse((resb) ? authenticationResponseWrapper.getContent() : "");
            String qid = "";
            String username = "";

            if (authenticationRequestWrapper.getParameter("qid") != null) {
                qid = authenticationRequestWrapper.getParameter("qid");
            } else if (authenticationRequestWrapper.getParameter(UERNAME) != null) {
                username = authenticationRequestWrapper.getParameter(UERNAME);
                if (username.contains("#;")) {
                    username = username.split("#;")[1];
                }
                User user = userService.getByUsername(username);
                if (user != null) {
                    qid = user.getQid();
                    log.info("user.getQid(): {}", user.getQid());
                } else {
                    qid = "";
                }

            } else if (reqb && !(authenticationRequestWrapper.payload.isEmpty())) {
                JsonObject jsonObject = new JsonParser().parse(authenticationRequestWrapper.payload).getAsJsonObject();

                if (jsonObject.get("qid") != null) {
                    qid = jsonObject.get("qid").getAsString();
                }

                log.info("String.valueOf(jsonObject.get(\"qid\")): {}", qid);

            }


            auditBackEndResource.setQid(qid);
            auditBackEndResource.setService(authenticationRequestWrapper.getRequestURI() == null ? "" : authenticationRequestWrapper.getRequestURI());
            log.info("status: {}", authenticationResponseWrapper.getStatus());
            auditBackEndResource.setResponseDescription((authenticationResponseWrapper.getStatus()) == 200 ? "SUCCESS" : "FAILED");


            auditBackEndService.save(auditBackEndResource);
        }
    }

    private boolean isContentJson(String contentType) {
        if (contentType != null) {
            return contentType.startsWith("application/json");
        }
        return false;
    }

}