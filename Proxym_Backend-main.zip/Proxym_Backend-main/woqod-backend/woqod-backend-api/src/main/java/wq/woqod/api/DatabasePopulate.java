package wq.woqod.api;


import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;
import java.util.List;


@Slf4j
@Configuration
public class DatabasePopulate {

    private final DataSource dataSource;

    public DatabasePopulate(DataSource dataSource) {
        this.dataSource = dataSource;
    }


    public void executeScripts(List<ClassPathResource> scripts) {
        for (ClassPathResource script : scripts) {
            try {
                ResourceDatabasePopulator resourceDatabasePopulator;
                resourceDatabasePopulator = new ResourceDatabasePopulator();
                resourceDatabasePopulator.addScript(script);
                DatabasePopulatorUtils.execute(resourceDatabasePopulator, dataSource);

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
    }

}
