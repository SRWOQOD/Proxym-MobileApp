package wq.woqod.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedModel;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import wq.woqod.commons.constants.Provider;
import wq.woqod.commons.response.GenericResponse;
import wq.woqod.commons.response.ResponseBuilder;
import wq.woqod.commons.response.body.ListResponse;
import wq.woqod.commons.response.body.ObjectResponse;
import wq.woqod.commons.response.body.PaginatedListResponse;
import wq.woqod.resources.resources.TagResource;
import wq.woqod.service.TagService;

import java.text.ParseException;
import java.util.List;

/**
 * Created by med-amine.dahmen on 15/11/2018.
 */
@RestController
@Slf4j
@RequestMapping(value = "/tag")
public class TagController {

    private final TagService tagService;

    @Autowired
    public TagController(TagService tagService) {
        this.tagService = tagService;
    }

    @PostMapping(value = "/register")
    public GenericResponse<ObjectResponse<TagResource>> register(@RequestBody TagResource tagResource) {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(tagService.save(tagResource)), Provider.WOQOD);
    }


    @PostMapping(value = "/getCoastAndFees")
    public GenericResponse<ObjectResponse<TagResource>> getCoastAndFees() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse<>(new TagResource(0L, 100D, 200D)), Provider.WOQOD);
    }


    @GetMapping(value = "/filtered")
    public GenericResponse<ObjectResponse<TagResource>> getFilteredTag(@PageableDefault(sort = {"registrationDate"}, direction = Sort.Direction.DESC) Pageable pageable, PagedResourcesAssembler assembler,
                                                                       @RequestParam(required = false) MultiValueMap<String, String> parameters
    ) throws ParseException {
        Page<TagResource> tagResources = tagService.filter(pageable, parameters);

        PagedModel result = assembler.toModel(tagResources);
        return ResponseBuilder.buildSuccessResponse(new PaginatedListResponse<>(result, tagResources.getContent()), Provider.WOQOD);
    }


    @GetMapping(value = "")
    public GenericResponse<ObjectResponse<TagResource>> getAllTags(@RequestParam MultiValueMap<String, String> parameters) throws ParseException {
        List<TagResource> resource = tagService.getAll(parameters);
        return ResponseBuilder.buildSuccessResponse(new ListResponse<>(resource), Provider.WOQOD);
    }

    @GetMapping("/count")
    public GenericResponse count() {
        return ResponseBuilder.buildSuccessResponse(new ObjectResponse(tagService.count()), Provider.WOQOD);
    }

}

