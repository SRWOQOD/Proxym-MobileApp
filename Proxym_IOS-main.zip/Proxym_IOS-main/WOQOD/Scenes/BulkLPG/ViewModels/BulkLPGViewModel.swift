//
//  BulkLPGViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine
import UIKit

class BulkLPGViewModel: ViewModel {

    // MARK: - Public properties
    var contractorsList: [Contractor] = []
    var bulkLPGStaticText: String?
    let staticScreenType = StaticScreenType.buklPG.rawValue

    // MARK: - overrides
    override init() {
        super.init()
    }

    // MARK: - private methods

    func getContractors() {

        let stateHandler: StateHandler = { (result) in
            switch result {
            case .finished:
                self.state.send(.finishedLoading)
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receiveValue: ([ContractorDTO], [Contractor]) -> Void = { (_, contractors) in

            self.contractorsList = contractors
        }

        ContractorAPIManager.getContractors()
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

    func getBulkLPGStaticText() {
            let stateHandler: StateHandler = { (result) in
                switch result {
                case .finished: self.state.send(.finishedLoading)
                case .failure(let error): self.state.send(.error(error as? WQError ?? WQError()))
                }
            }

            let receivedValue: ReceivedValue<StaticScreenDTO, StaticScreenModel>  = { (_, result) in
                self.bulkLPGStaticText =  result.content
            }

        StaticScreensAPIManager.getStaticScreen(type: staticScreenType)
                .sink(receiveCompletion: stateHandler, receiveValue: receivedValue)
                .store(in: &cancellable)
    }

}
