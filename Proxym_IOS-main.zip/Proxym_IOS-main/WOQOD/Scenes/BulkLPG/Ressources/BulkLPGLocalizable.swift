//
//  LocalizableBulkLPG.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum LocalizableBulkLPG: String, LocalizableDelegate {

    case bulkLPGTitle = "BulkLpgAboutBulkLpg"
    case bulkLPGDescription = "BulkLpgDescription"
    case bulkContractorsTitle = "BulkLpgContractors"

    var tableName: String? {
        return "BulkLPG"
    }
}
