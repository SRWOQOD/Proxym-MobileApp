//
//  BulkLPGViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class BulkLPGViewController: UIViewController {

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var bulkLpgView: UIView!
    @IBOutlet weak var bulkLPGTitle: UILabel!
    @IBOutlet weak var descriptionView: UITextView!
    @IBOutlet weak var contractorTitle: UILabel!
    @IBOutlet weak var bulkLPGTableView: DynamicTableView!
    private var bulkLPGVM = BulkLPGViewModel()
    private var bindings = Set<AnyCancellable>()
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        setUpBindings()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.bulkLPGVM.getBulkLPGStaticText()
        initDescriptionView()
        iniTitletLables()
        showActivityIndicator()
        self.bulkLPGVM.getContractors()
    }
    private func initUI() {
        headerView.menuAction = presentMenu
        initViews()
        iniTitletLables()
        initTableView()
    }
    private func iniTitletLables() {
        bulkLPGTitle.setText(text: LocalizableBulkLPG.bulkLPGTitle.localized.uppercased(),
                             font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
        contractorTitle.setText(text: LocalizableBulkLPG.bulkContractorsTitle.localized.uppercased(),
                                font: Fonts.boldFontName, size: 15, forgroundColor: .wqBlue)
    }

    private func initViews() {
        bulkLpgView.border(borderColor: UIColor.white, borderwidth: 1)
        bulkLpgView.roundTopCorners(radius: 15)
    }

    private func initDescriptionView() {
        descriptionView.htmlAttributedStringUtf16(text: bulkLPGVM.bulkLPGStaticText ?? "",
                                             fontSize: 13,
                                             fontName: Fonts.bookFontName,
                                             hexColor: "#002280")
    }

    private func initTableView() {
        bulkLPGTableView.registerCellNib(ContractorsCardTableViewCell.self)
        bulkLPGTableView.dataSource = self
        bulkLPGTableView.delegate = self
    }

    private func reloadTableView() {
        bulkLPGTableView.reloadData()
    }

    private func setUpBindings() {
        bulkLPGVM.state.sink { (state) in
            hideActivityIndicator()
            switch state {
            case .finishedLoading :
                self.initDescriptionView()
                self.reloadTableView()
            case .error(let error) :
                self.showErrorAlertView(descriptionMessage: error.message)
            case .loading:
                break
            }
        }
        .store(in: &bindings)
    }
}

extension BulkLPGViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bulkLPGVM.contractorsList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ContractorsCardTableViewCell", for: indexPath)
                as? ContractorsCardTableViewCell
        else {return UITableViewCell()}
        cell.setUp(contractor: bulkLPGVM.contractorsList[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
