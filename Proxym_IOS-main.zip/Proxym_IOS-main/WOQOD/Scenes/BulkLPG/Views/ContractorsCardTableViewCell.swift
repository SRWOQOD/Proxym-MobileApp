//
//  ContractorsCardTableViewCell.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class ContractorsCardTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var stackView: UIStackView!

    var contractorElements: [ItemContentModel] = []
    var contractorData: Contractor?
    let undefinedValue = ""

    // Initialization code
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    // Configure the view for the selected state
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        selectionStyle = .none
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        containerView.addShadow(cornerRadius: 11.adjusted)
        containerView.roundCorners(radius: 11)
    }

    func setUp(contractor: Contractor) {
        let phoneValue = contractor.phone.compactMap({ $0 }).joined(separator: " , ")
        let nameValue = contractor.title ?? undefinedValue
        contractorElements =  [ ItemContentModel(title: LocalizableShared.address.localized + " :",
                                                 value: contractor.address ?? undefinedValue),
                                ItemContentModel(title: LocalizableShared.phone.localized + " :",
                                                 value: phoneValue, valueIsSelected: true),
                                ItemContentModel(title: LocalizableShared.fax.localized + " :",
                                                 value: contractor.fax ?? undefinedValue, valueIsSelected: true),
                                ItemContentModel(title: LocalizableShared.email.localized + " :",
                                                 value: contractor.email ?? undefinedValue, valueIsSelected: true)]

        // stop stack from appending view while scrolling
        stackView.subviews.forEach { (view) in
            view.removeFromSuperview()
        }

        let nameLabel = UILabel()
        stackView.addArrangedSubview(nameLabel)
        nameLabel.setText(text: nameValue, font: Fonts.mediumFontName, size: 13,
                          forgroundColor: .wqGreen, align: languageIsEnglish ? .left : .right)

        contractorElements.forEach({
            let itemView = WQCardItemContentView()
            itemView.title = $0.title
            itemView.value = $0.value
            itemView.valueIsSelected = $0.valueIsSelected

            if !(itemView.value?.isEmpty ?? true) {
                stackView.addArrangedSubview(itemView)
                let constraints = [
                    NSLayoutConstraint(item: itemView, attribute: .leading, relatedBy: .equal,
                                       toItem: stackView,
                                       attribute: .leading, multiplier: 1.0, constant: 0),
                    NSLayoutConstraint(item: nameLabel, attribute: .leading, relatedBy: .equal,
                                       toItem: stackView,
                                       attribute: .leading, multiplier: 1.0, constant: 11)
                ]
                NSLayoutConstraint.activate(constraints)
            }
        })

        stackView.spacing = 7
        stackView.alignment = .fill
    }
}
