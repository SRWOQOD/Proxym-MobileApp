//
//  RegistrationStepsView.swift
//  WOQOD
//
//  Created by rim.ktari on 14/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit

class RegistrationStepsView: UIView {

    @IBOutlet weak var firstStepView: UIView!
    @IBOutlet weak var secondStepView: UIView!
    @IBOutlet weak var thirdStepView: UIView!

    let unselectedBgColor = UIColor(hexString: "#98A5CC").withAlphaComponent(0.63)

    var stepNumber: Int = 1 {
        didSet {
            updateStepsView(stepNumber)
        }
    }
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUI()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initUI()
    }

    func initUI() {
        loadNibContent()
    }

    func updateStepsView(_ numbber: Int? ) {
        switch  numbber {
        case 1:
            firstStepView.backgroundColor = .wqBlue
            secondStepView.backgroundColor = unselectedBgColor
            thirdStepView.backgroundColor = unselectedBgColor
        case 2:
            firstStepView.backgroundColor = unselectedBgColor
            secondStepView.backgroundColor = .wqBlue
            thirdStepView.backgroundColor = unselectedBgColor

        case 3:
            firstStepView.backgroundColor = unselectedBgColor
            secondStepView.backgroundColor = unselectedBgColor
            thirdStepView.backgroundColor = .wqBlue

        default: break

        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        firstStepView.round()
        secondStepView.round()
        thirdStepView.round()
    }
}
