//
//  RegisterViewController.swift
//  WOQOD
//
//  Created by rim ktari on 7/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine
import SwiftUI
/// This is the second step for registring user
class RegisterViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var customerDetailsLabel: UILabel!
    @IBOutlet weak var registrationStepsView: RegistrationStepsView!
    @IBOutlet weak var registerButton: WQButton!
    // MARK: - Properties
    var registerViewModel: RegisterViewModel?
    var cancellable = Set<AnyCancellable>()
    let kStepNumber = 2

    var lastStepRegisterViewController = LastStepRegisterViewController()

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        setUpBindings()
    }

    // MARK: - Private Methods

    private func setUpBindings() {

        registerViewModel?.registrationState.sink {  [unowned self] state  in
            hideActivityIndicator()
            switch state {
            case .validEmailAndUsername : self.showNextStepRegistration()
            case .error(let error ) : self.showErrorAlertView(descriptionMessage: error.message)

            default : break
            }
        }.store(in: &cancellable)
    }

    private func showNextStepRegistration() {
        lastStepRegisterViewController.viewModel = self.registerViewModel
        self.push(viewController: lastStepRegisterViewController)
    }

    func initUI() {

        registerButton.title = LocalizableShared.next.localized.uppercased()
        registerButton.style = Buttontype.primary

        initStackView()
        initBgViews()
        initHeaderView()
        titleLabel.setText(text: LocalizedAuthentication.registrationTitle.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22,
                           forgroundColor: .wqBlue)
        registrationStepsView.stepNumber = kStepNumber
        self.lastStepRegisterViewController =
            LastStepRegisterViewController.instantiate(appStoryboardName: AppStoryboard.authentification)

    }

    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    func initBgViews() {
        contentView.border(borderColor: UIColor.white.withAlphaComponent(0.5), borderwidth: 2)
        contentView.roundTopCorners(radius: 15)
    }
    func initStackView() {
        registerViewModel?.registerElements?.forEach({
            var textfieldView: CommonInputFieldView?
            switch $0.inputFieldType {
            case .dropDown:
                textfieldView = WQDropDownMenu()
                textfieldView?.title = $0.title
                textfieldView?.placeholder = $0.placeholer
                textfieldView?.dataArray = $0.dataArray
                guard let dropMenuView = (textfieldView as? WQDropDownMenu) else {return}
                dropMenuView.$selectedText
                    .assign(to: $0.published, on: registerViewModel!)
                    .store(in: &cancellable)
                stackView.addArrangedSubview(textfieldView!)
            default:
                textfieldView = WQTextFieldView()
                textfieldView?.title = $0.title
                textfieldView?.fieldType = $0.type ?? .text
                textfieldView?.textField.textPublisher
                    .assign(to: $0.published, on: registerViewModel!)
                    .store(in: &cancellable)
                stackView.addArrangedSubview(textfieldView!)
            }
        })

        stackView.spacing = 0
        stackView.alignment = .fill
    }

    // MARK: - Actions

    @IBAction func registerAction(_ sender: Any) {
        if stackView.validCommonInputFields() {
            showActivityIndicator()
            registerViewModel?.checkUserEmailAndUserName()

        }
    }
}
