//
//  LastStepRegisterViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/13/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine
/// This is the last step for registring user 
class LastStepRegisterViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var registerButton: WQButton!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var privacyPolicyView: WQCheckBoxView!
    @IBOutlet weak var termsOfUseView: WQCheckBoxView!
    @IBOutlet weak var registrationStepsView: RegistrationStepsView!
    // MARK: - Properties
    var cancellable = Set<AnyCancellable>()
    var viewModel: RegisterViewModel?
    let kStepNumber = 3

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    func initUI() {
        titleLabel.setText(text: LocalizedAuthentication.registrationTitle.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22,
                           forgroundColor: .wqBlue)
        registrationStepsView.stepNumber = kStepNumber
        registerButton.title = LocalizableShared.next.localized.uppercased()
        initStackView()
        initTermsViews()
        initBgViews()
        initHeaderView()
        viewModel?.getAreas()
        setUpBindings()

    }
    // MARK: - Private Methods
    private func initTermsViews() {
        privacyPolicyView.termsButtonTitle = Localizable.menuPrivacyPolicy.localized
        privacyPolicyView.tapOnTermsButton = {
            let staticScreensVC =  WQStaticScreenViewController.instantiate(
                appStoryboardName: AppStoryboard.staticScreen)
                as? WQStaticScreenViewController
            staticScreensVC?.strategy = PrivacyPolicyStrategy()
            staticScreensVC?.path = .fromRegistration
            self.push(viewController: staticScreensVC ?? WQStaticScreenViewController())
        }

        termsOfUseView.termsButtonTitle = Localizable.menuTermsOfUse.localized
        termsOfUseView.tapOnTermsButton = {
            let staticScreensVC =  WQStaticScreenViewController.instantiate(
            appStoryboardName: AppStoryboard.staticScreen)
            as? WQStaticScreenViewController
            staticScreensVC?.strategy = TermsOfUseStrategy()
            staticScreensVC?.path = .fromRegistration
            self.push(viewController: staticScreensVC ?? WQStaticScreenViewController())

        }
    }
    private func initBgViews() {
        contentView.border(borderColor: UIColor.white.withAlphaComponent(0.5), borderwidth: 2)
        contentView.roundTopCorners(radius: 15)
    }

    private func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    private func initStackView() {
        viewModel?.lastRegistrationElements?.forEach({
            var textfieldView: CommonInputFieldView?
            switch $0.inputFieldType {
            case .dropDown:
                textfieldView = WQDropDownMenu()
                textfieldView?.title = $0.title
                textfieldView?.fieldType = $0.type ?? .dropDown()
                textfieldView?.placeholder = $0.placeholer
                textfieldView?.dataArray = $0.dataArray
                guard let dropMenuView = (textfieldView as? WQDropDownMenu) else {return}
                dropMenuView.$selectedText
                    .assign(to: $0.published, on: viewModel!)
                    .store(in: &cancellable)
                stackView.addArrangedSubview(textfieldView!)
            default:
                let textfieldView = $0.inputFieldType == .textfield ? WQTextFieldView() : WQTextView()
                textfieldView.title = $0.title
                textfieldView.fieldType = $0.type ?? .text
                textfieldView.hint = $0.hint
                textfieldView.hintLabel.isHidden = $0.inputFieldType == .textview || $0.hint == nil
                textfieldView.textPublisher?
                    .assign(to: $0.published, on: viewModel!)
                    .store(in: &cancellable)
                stackView.addArrangedSubview(textfieldView)
            }
        })
        stackView.spacing = 0
    }

    private func showSendEmailVC() {
        AuthenticationRouter.shared.sendEmailViewController(strategy: RegistrationLastStepStrategy())
    }
    private func reloadViews() {
        let areasView = stackView.getWqDropDownViewFor(.dropDown(type: .area))
        areasView?.dataArray = viewModel?.areasListStrings
    }
    private func setUpBindings() {
        showActivityIndicator()
        viewModel?.registrationState.sink {  [unowned self] state  in
            hideActivityIndicator()
            switch state {
            case .finishRegistration : self.showSendEmailVC()
            case .error(let error ) : self.showErrorAlertView(descriptionMessage: error.message)
            case .finishFetchingAreas : self.reloadViews()
            default : break
            }
        }.store(in: &cancellable)
    }

    // MARK: - Actions
    @IBAction func registerAction(_ sender: Any) {
        if  !(viewModel?.validPassword)! {
            let confirmPassTFV = stackView.getWqTFViewFor(.confirmPassword)
            confirmPassTFV?.errorText =
                LocalizableShared.confirmationPasswordNotValid.localized
        } else {
            let confirmPassTFV = stackView.getWqTFViewFor(.confirmPassword)
            if confirmPassTFV?.value?.isEmpty == true {
                confirmPassTFV?.errorText =
                    LocalizedAccount.confirmPasswordEmpty.localized
            }
        }

        if stackView.validCommonInputFields() && (viewModel?.validPassword)! {
            if (!privacyPolicyView.isSelected) ||  (!termsOfUseView.isSelected) {
                termsOfUseView.errorLabel.isHidden = true
                privacyPolicyView.errorLabel.isHidden = true
                showErrorAlertView(descriptionMessage: LocalizedAuthentication.acceptTermsErrorMsg.localized)
            } else {
                showActivityIndicator()
                self.viewModel?.registerUser()
            }
        }
    }
}
