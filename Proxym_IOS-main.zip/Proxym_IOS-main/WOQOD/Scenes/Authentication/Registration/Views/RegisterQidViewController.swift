//
//  RegisterQidViewController.swift
//  WOQOD
//
//  Created by rim ktari on 7/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

enum RegistrationPath {
    case fromSignin
    case fromMenu
}

class RegisterQidViewController: UIViewController {

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nextButton: WQButton!
    @IBOutlet weak var mobileTextfieldView: WQTextFieldView!
    @IBOutlet weak var qidTextfieldView: WQTextFieldView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var registrationStepsView: RegistrationStepsView!

    // MARK: - Properties
    var viewModel = RegisterViewModel()
    var cancellable = Set<AnyCancellable>()
    var registerViewController = RegisterViewController()
    let kStepNumber = 1
    var registrationPath: RegistrationPath = .fromSignin

    override func viewDidLoad() {
        super.viewDidLoad()

        initTextFields()
        bindData()
        initButton()
        initBgViews()
        initHeaderView()
        registrationStepsView.stepNumber = kStepNumber
        registerViewController = RegisterViewController.instantiate(appStoryboardName: AppStoryboard.authentification)
        setUpBindings()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        nextButton.title = LocalizableShared.next.localized.uppercased()
        initTextFields()
        self.view.layoutIfNeeded()
    }
    // MARK: - Private Methods
    private func setUpBindings() {

        viewModel.registrationState.sink {  [unowned self] state  in
            hideActivityIndicator()
            switch state {
            case .validQidAndMobile : self.showNextStepRegistration()
            case .error(let error ) : self.showErrorAlertView(descriptionMessage: error.message)

            default : break
            }
        }.store(in: &cancellable)
    }

    func initHeaderView() {
        switch registrationPath {
        case .fromMenu:
            headerView.sideMenuButton.setImage(UIImage(named: "ic_menu"), for: .normal)
            headerView.menuAction = presentMenu
        case .fromSignin:
            headerView.sideMenuButton.setImage(
                UIImage(named: "ic_back"), for: .normal)
            headerView.menuAction = {self.pop()}
        }
    }
    func showNextStepRegistration() {
        registerViewController.registerViewModel = self.viewModel
        self.push(viewController: registerViewController)
    }

    func initButton() {
        nextButton.title = LocalizableShared.next.localized.uppercased()
        nextButton.style = Buttontype.primary
    }

    func initTextFields() {
        messageLabel.setText(text: LocalizedAuthentication.registrationStep1Title.localized,
                           font: Fonts.mediumFontName, size: 15,
                           forgroundColor: .wqBlue,
                           align: languageIsEnglish ? .left : .right)

        titleLabel.setText(text: LocalizedAuthentication.registrationTitle.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22,
                           forgroundColor: .wqBlue)

        qidTextfieldView.title = LocalizableShared.qid.localized + "*"
        qidTextfieldView.fieldType = .qatariId

        mobileTextfieldView.title =  LocalizableShared.mobileNumber.localized + "*"
        mobileTextfieldView.fieldType = .mobileNumber
        bindData()

    }

    func initBgViews() {
        contentView.border(borderColor: UIColor.white.withAlphaComponent(0.5), borderwidth: 2)
        contentView.roundTopCorners(radius: 15)
    }

    func bindData() {
        mobileTextfieldView.textField.textPublisher
            .assign(to: \.userToRegister.mobileNumber, on: viewModel)
            .store(in: &cancellable)
        qidTextfieldView.textField.textPublisher
            .assign(to: \.userToRegister.qid, on: viewModel)
            .store(in: &cancellable)

    }

    // MARK: - Actions
    @IBAction func confirmAction(_ sender: Any) {

        let isValidMobile = mobileTextfieldView.isValid
        let isValidQID = qidTextfieldView.isValid

        if isValidMobile && isValidQID {
            showActivityIndicator()
            viewModel.checkUserQIDandMobile()
        }
    }

}
