//
//  uploadImageView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 03/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

/// UploadImageView is a reusable view when user take a photo from gallery or camera
class UploadImageView: UIView {

    // MARK: - Outlets
    @IBOutlet weak var stackViewContent: UIView!

    @IBOutlet var contentView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var takePictureView: WQCustomButtonView!
    @IBOutlet weak var uploadPictureView: WQCustomButtonView!
    @IBOutlet weak var stackView: UIStackView!

    // MARK: - public variables
    var numberAllowedImages: Int = 2
    var imagePicker: ImagePicker?
    var didpickImages : (() -> Void) = {}

    var imagesList: [UIImage] = [UIImage]() {
        didSet {
           didpickImages()
        }
    }
    var didChooseAnImage : ((_ image: UIImage) -> Void) = {_ in}

    var title: String? {
        didSet {
            titleLabel.setText(text: title, font: Fonts.mediumFontName,
                               size: 15, forgroundColor: .wqBlue, align: .center)
        }
    }

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        initUI()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        initUI()
        stackViewContent.isHidden = true
    }

    // MARK: - Private methods

    /// Initialise Views
    private func initUI() {

        title = LocalizableFeedback.attachement.localized
        imagePicker = ImagePicker(delegate: self)
        initButtonsView()
    }

    private func initButtonsView() {
        takePictureView.backgroudColor = .wqGrayBlue
        takePictureView.textLabel.setText(text: LocalizableShared.takePicture.localized,
                                          font: Fonts.boldFontName, size: 14,
                                          forgroundColor: .wqBlue, align: .center)
        takePictureView.image = #imageLiteral(resourceName: "ic_feedback_takePicture")
        uploadPictureView.backgroudColor = .wqGrayBlue
        uploadPictureView.textLabel.setText(text: LocalizableShared.uploadFromDevice.localized,
                                            font: Fonts.boldFontName, size: 14,
                                            forgroundColor: .wqBlue, align: .center)
        uploadPictureView.image = #imageLiteral(resourceName: "ic_feedback_uploadPicture")
        uploadPictureView.didClickOn  = {
            self.imagePicker?.showGallery()
        }
        takePictureView.didClickOn  = {
            self.imagePicker?.showCamera()
        }
    }

    /// This function used to add an image in the stackView
    /// - Parameter image: selected Image
    private func addImageView(image: UIImage) {

        imagesList.append(image)

        self.updateImagesStatus()

        stackViewContent.isHidden =  false

        let displayImView = DisplayPhotoView()

        displayImView.image = image
        stackView.addArrangedSubview(displayImView)

        /// If user delete a photo we should update  the stackView
        displayImView.didDeleteImage = {
            self.deleteImage(view: displayImView, image: image)
            self.updateImagesStatus()
        }
    }

    /// Update the status of the stackView when the number of images selected more than 2
    private func updateImagesStatus() {
        self.uploadPictureView.isUserInteractionEnabled = self.imagesList.count < numberAllowedImages
        self.takePictureView.isUserInteractionEnabled = self.imagesList.count < numberAllowedImages
    }

    /// When user tap on the delete button we update the View
    private func deleteImage(view: UIView, image: UIImage) {
        self.stackView.removeArrangedSubview(view)
        view.removeFromSuperview()
        self.imagesList.delete(element: image)
        self.stackViewContent.isHidden =  (self.imagesList.count ==  0)

    }

    func deleteAllImages() {
        stackView.subviews.forEach { (view) in
            view.removeFromSuperview()
        }

        self.imagesList.removeAll()
        self.stackViewContent.isHidden =  true
        self.uploadPictureView.isUserInteractionEnabled = true
        self.takePictureView.isUserInteractionEnabled = true

    }

    override func layoutSubviews() {
        super.layoutSubviews()
        self.layoutIfNeeded()
    }
}

extension UploadImageView: ImagePickerDelegate {

    /// This function returns the image taken by the user
    /// - Parameter image: selected Image
    func didSelect(image: UIImage?) {

        guard let selectedImage = image else {
            return
        }
        didChooseAnImage(selectedImage)
        addImageView(image: selectedImage)

    }
}
