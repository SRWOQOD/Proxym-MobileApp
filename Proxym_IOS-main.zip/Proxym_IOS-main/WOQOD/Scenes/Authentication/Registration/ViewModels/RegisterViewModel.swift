//
//  RegisterViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 7/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

import Combine

struct  RegisterElement {
    var inputFieldType: InputFieldType = .textfield
    var type: FieldType?
    var title: String?
    var value: String?
    var hint: String?
    var placeholer: String?
    var published: RegisterKeyPath
    var dataArray: [String]?
}
enum RegistrationState {
    case validQidAndMobile
    case validEmailAndUsername
    case finishRegistration
    case finishFetchingAreas
    case error(WQError)
}

enum GenderDropDownKeys: String {
    case female = "Female"
    case male = "Male"

}

typealias RegisterKeyPath = ReferenceWritableKeyPath<RegisterViewModel, String>

class RegisterViewModel: ViewModel, ObservableObject {

    var registrationState = PassthroughSubject<RegistrationState, Never>()

    var userToRegister: UserToRegister {
        return AuthManager.shared.userToRegister
    }

    let firstNameKeyPath: RegisterKeyPath = \.userToRegister.firstName
    let userameKeyPath: RegisterKeyPath = \.userToRegister.username
    let familyNameKeyPath: RegisterKeyPath = \.userToRegister.familyName
    let emailKeyPath: RegisterKeyPath = \.userToRegister.email
    let birthDateKeyPath: RegisterKeyPath = \.userToRegister.birthdate
    let passwordKeyPath: RegisterKeyPath = \.userToRegister.password
    let confirmPassKeyPath: RegisterKeyPath = \.userToRegister.confirmPassword
    let genderKeyPath: RegisterKeyPath = \.userToRegister.gender

    private var areasList: [Area] = []
    var areasListStrings: [String] {
        return areasList.map({(languageIsArabic ? $0.titleAR ?? "" : $0.title ?? "")})
    }

    private let genderDropDownDataArray = [DropDownElement(key: GenderDropDownKeys.male.rawValue,
                                                           name: LocalizedAuthentication.genderMale.localized),
                                           DropDownElement(key: GenderDropDownKeys.female.rawValue,
                                                           name: LocalizedAuthentication.genderFemale.localized)
    ]

    var genderList: [String] {
        return genderDropDownDataArray.map({$0.name})
    }

    var validPassword: Bool? {
        return  (userToRegister.password == userToRegister.confirmPassword)
    }

    override init() {
        super.init()

        AuthManager.shared.userToRegister = UserToRegister()
    }

    // Step 1 elements : qid + mobile

    // Step 2 elements : firstname, lastname, username, dateOfBirth, email and password
    var registerElements: [RegisterElement]? {

        return [  RegisterElement(type: .name, title: LocalizableShared.firstName.localized + "*",
                                  value: userToRegister.firstName, published: firstNameKeyPath),
                  RegisterElement(type: .familyName, title: LocalizableShared.lastName.localized + "*",
                                  value: userToRegister.familyName, published: familyNameKeyPath),
                  RegisterElement(type: .username, title: LocalizableShared.username.localized + "*",
                                  value: userToRegister.username, published: userameKeyPath),
                  RegisterElement(type: .dateOfBirth, title: LocalizableShared.dateOfBirth.localized + "*",
                                  value: userToRegister.birthdate, published: birthDateKeyPath),
                  RegisterElement(type: .email, title: LocalizableShared.email.localized + "*",
                                  value: userToRegister.email, published: emailKeyPath),
                  RegisterElement(inputFieldType: .dropDown,
                                  type: .dropDown(),
                                  title: LocalizedAuthentication.gender.localized + "*",
                      value: userToRegister.gender, placeholer:
                      LocalizedAuthentication.genderPlaceholder.localized,
                      published: genderKeyPath, dataArray: genderList)

        ]
    }

    // Step 3 elements : area, address and poBox
    var lastRegistrationElements: [RegisterElement]? {
        let areaKeyPath: RegisterKeyPath = \.userToRegister.areaName
        let addressKeyPath: RegisterKeyPath = \.userToRegister.address
        let poBoxKeyPath: RegisterKeyPath = \.userToRegister.poBox
        return       [
            RegisterElement(inputFieldType: .dropDown,
                            type: .dropDown(type: .area),
                            title: LocalizedAuthentication.areaOfResidencePlaceholder.localized + "*",
                            value: userToRegister.areaName,
                            placeholer: LocalizableShared.areaOfResidence.localized,
                            published: areaKeyPath, dataArray: areasListStrings),
            RegisterElement(inputFieldType: .textview, type: .address, title: LocalizableShared.address.localized,
                            value: userToRegister.address,
                            hint: nil, published: addressKeyPath),
            RegisterElement(type: .poBox, title: LocalizableShared.poBox.localized,
                            value: userToRegister.poBox,
                            hint: nil, published: poBoxKeyPath),
            RegisterElement(type: .password,
                            title: LocalizableShared.password.localized + "*",
                            value: userToRegister.password,
                            hint: LocalizableShared.passwordNotValid.localized, published: passwordKeyPath),
            RegisterElement(type: .confirmPassword, title: LocalizableShared.confirmPassword.localized + "*",
                            value: userToRegister.confirmPassword,
                            hint: nil, published: confirmPassKeyPath)

        ]

    }
    /// This func is used to get the id of area that user has selected from the dropDown
    func getIdArea() {
        userToRegister.idArea = areasList.filter({ languageIsArabic
            ? $0.titleAR == userToRegister.areaName
            : $0.title == userToRegister.areaName }).first?.idArea ?? ""
    }

    func getGender() {
        userToRegister.gender = genderDropDownDataArray.filter({ $0.name == userToRegister.gender}).first?.key ?? ""
    }

    /// This function is to register the user
    func registerUser() {
        getIdArea()
        getGender()
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                let err = error as? WQError
                self.registrationState.send(.error(err ?? WQError()))
            case .finished :
                self.registrationState.send(.finishRegistration)
            }

        }

        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in
            //
        }

        RegisterApiManager.register(user: self.userToRegister)
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)

    }
    // Step1: Checking qid and mobile if exist! AND VALIDITY
    // Step1.1
    func checkUserQIDandMobile() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                let err = error as? WQError
                self.registrationState.send(.error(err ?? WQError()))
            case .finished :
                // After checking if qid and mobile exist, we check also the validity
                self.checkUserQIDandMobileValidity()
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in}
        RegisterApiManager.checkUser(qid: userToRegister.qid, mobile: userToRegister.mobileNumber)
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }
    // Step1.2
    /// This func is used to check qid and mobile validity
    func checkUserQIDandMobileValidity() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                self.registrationState.send(.error(error as? WQError ?? WQError()))
            case .finished :
                self.registrationState.send(.validQidAndMobile)
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in  }
        RegisterApiManager.checkQidValidity(qid: userToRegister.qid,
                                            mobile: userToRegister.mobileNumber)
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    // Step2: Checking email and username if exist!
    func checkUserEmailAndUserName() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                let err = error as? WQError
                self.registrationState.send(.error(err ?? WQError()))
            case .finished :
                self.registrationState.send(.validEmailAndUsername)
            }

        }

        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in
            //
        }

        RegisterApiManager.checkUser(email: userToRegister.email, username: userToRegister.username.lowercased())
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)

    }
    func getAreas() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                let err = error as? WQError
                self.registrationState.send(.error(err ?? WQError()))
            case .finished :
                self.registrationState.send(.finishFetchingAreas)
            }
        }

        let resultHandler: (([AreaDTO], [Area]) -> Void ) = { (_, areas) in
            self.areasList = areas
        }

        UserAPIManager.getAreas()
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }
}
