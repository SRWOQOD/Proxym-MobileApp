//
//  UserViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class UserViewModel: ViewModel {

    var username: String = ""
    var familyName: String = ""
    var firstName: String = ""
    var fullName: String = ""
    var mobile: String = ""
    var email: String = ""
    var address: String = AuthManager.shared.currentUser?.address ?? ""
    var qid: String = ""
    var birthdate: String = ""
    var idArea: String = AuthManager.shared.currentUser?.area?.idArea ?? ""
    var userPassword: String = ""
    var typeLogin: String = ""
    var poBox: String = AuthManager.shared.currentUser?.poBox ?? ""
    var area: Area = AuthManager.shared.currentUser?.area ?? Area()
    var newUser: User {
        return User.init(qid: (qid == "") ? user?.qid : qid,
                         userName: (username == "" ) ? user?.userName : username ,
                         email: (email == "" ) ? user?.email : email ,
                         birthdate: (birthdate == "" )
                            ? user?.birthdate
                            : birthdate.getDate("dd-MM-yyyy",isNeededTimeZone: true).timeStamp ,
                         mobileNumber: (mobile == "" ) ? user?.mobileNumber : mobile ,
                         type: UserType.individualCustomer,
                         contactType: .mail,
                         firstName: (firstName == "" ) ? user?.firstName : firstName ,
                         familyName: (familyName == "" ) ? user?.familyName : familyName ,
                         fullName: fullName,
                         address: address ,
                         poBox: poBox ,
                         unlockAccount: user?.unlockAccount,
                         fleetName: user?.fleetName,
                         gender: user?.gender,
                         area: area,
                         isBiometricActivated: user?.isBiometricActivated,
                         customIdentification: user?.customIdentification)
    }
    var credentials: Credentials {
        return Credentials(username: username, password: userPassword, rememberMe: false, type: typeLogin)
    }

    override init() {}

    // added to compare current user in keychain with the edited user in profile,
    // that's why it contains only editable element from edit profile,
    // add more in case of need
    init(user: User?) {
        self.qid = user?.qid ?? ""
        self.username = user?.userName ?? ""
        self.familyName = user?.familyName ?? ""
        self.firstName = user?.firstName ?? ""
        self.mobile = user?.mobileNumber ?? ""
        self.email = user?.email ?? ""
        self.address = user?.address ?? ""
        self.birthdate =  user?.birthdate?.getDateFromInt64().getStringDate() ?? ""
        self.poBox = user?.poBox ?? ""
        self.area = user?.area ?? Area()
    }
}
