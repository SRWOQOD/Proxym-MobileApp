//
//  LoginType.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 23/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum LoginTypeKeys: String {

    case bioAuth = "Bio_Auth"
    case usernameAuth = "Username_Auth"
    case emailAuth = "Email_Auth"
    case qidAuth = "Qid_Auth"
    case mobilenumberAuth = "Mobile_number_Auth"

    init(fromRawValue: String) {
        self = LoginTypeKeys(rawValue: fromRawValue) ?? .usernameAuth
    }
}

struct LoginType {

    var key: String
    var name: String
}
