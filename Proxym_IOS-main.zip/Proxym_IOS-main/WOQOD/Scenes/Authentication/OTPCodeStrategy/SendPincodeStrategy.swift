//
//  SendPincodeStrategy.swift
//  WOQOD
//
//  Created by rim ktari on 10/21/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

protocol OTPStrategyProtocol {
    var username: String { get }
    var connectionType: String { get set }
    var maximumDigits: Int { get set }
    var image: UIImage { get set }
    var titleText: String { get set }
    var descriptionText: String { get set }
    var resendButtonIsHidden: Bool { get set }
    var resendButtonTitle: String { get set }
    var confirmButtonTitle: String { get set }
}

class RegisterStepOneWithFingerPrintStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_confirmCodeEmail")

    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized

    var resendButtonIsHidden: Bool = false
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue

}

class RegisternStepTwoWithFingerPrintStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 4
    var image: UIImage = #imageLiteral(resourceName: "ic_fingerPrint")
    var titleText: String = ""
    var descriptionText: String = LocalizedAuthentication.loginWithFingerPrint.localized
    var resendButtonIsHidden: Bool = true
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}

class LoginWithFingerPrintStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")
    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized
    var resendButtonIsHidden: Bool = false
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized.uppercased()
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}
class LoginOTPStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")
    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized
    var resendButtonIsHidden: Bool = false
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized.uppercased()
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}

class ForgetBioPinStrategy: OTPStrategyProtocol {
    // TO change titles
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_confirmCodeEmail")
    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized
    var resendButtonIsHidden: Bool = false
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var username: String = ""
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue

}

class ForgetPasswordStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")

    var titleText: String = LocalizableShared.codeVerification.localized

    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized

    var resendButtonIsHidden: Bool = false
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var username: String = ""
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue

}

class AccountResetPasswordStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")

    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized

    var resendButtonIsHidden: Bool = false
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}

class RegistrationLastStepStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")

    var titleText: String =  LocalizableShared.codeVerification.localized

    var descriptionText: String =  LocalizableShared.sentToPhoneMessage.localized

    var resendButtonIsHidden: Bool = false
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var username: String {
        return AuthManager.shared.userToRegister.username
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue

}

class UpdateUserEmailStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_email")

    var titleText: String =  LocalizableShared.verifyEmail.localized

    var descriptionText: String =  LocalizableShared.sentToEmailMessage.localized

    var resendButtonIsHidden: Bool = false // To verify
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue

}

class UpdateUserPhoneStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")

    var titleText: String =  LocalizableShared.verifyPhone.localized

    var descriptionText: String =  LocalizableShared.sentToPhoneMessage.localized

    var resendButtonIsHidden: Bool = false // To verify
    var confirmButtonTitle: String = LocalizableShared.confirm.localized
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}

class EnableBiometricIDStrategy: OTPStrategyProtocol {
    var maximumDigits: Int = 6
    var image: UIImage = #imageLiteral(resourceName: "ic_verification_phone")
    var titleText: String = LocalizableShared.codeVerification.localized
    var descriptionText: String = LocalizableShared.sentToPhoneMessage.localized
    var resendButtonIsHidden: Bool = false
    var resendButtonTitle: String = LocalizableShared.resendCode.localized
    var confirmButtonTitle: String = LocalizableShared.confirm.localized.uppercased()
    var username: String {
        return AuthManager.shared.currentUser?.userName ?? ""
    }
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
}
