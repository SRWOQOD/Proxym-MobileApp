//
//  SendPincodeViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/18/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class SendPincodeViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var otpCodeView: WQOTPInsertView!

    // MARK: - Properties
    var viewModel = SendPincodeViewModel()
    var cancellable = Set<AnyCancellable>()
    var strategy: OTPStrategyProtocol?

    // MARK: - overrides
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        initUI()
        cancellable.removeAll()
        setUpBindings()
        initStrategy()
        initHeaderView()
    }

    // MARK: - Private functions
    private func initHeaderView() {
        switch strategy {
        case is AccountResetPasswordStrategy:
            headerView.menuAction = presentMenu
        default :
            headerView.sideMenuButton.setImage(
                UIImage(named: "ic_back"), for: .normal)
            headerView.menuAction = {self.pop()}
        }
    }

    fileprivate func initUI() {
        self.setUpNavigationItem()
        headerView.menuAction = presentMenu
    }

    fileprivate func initStrategy() {

        otpCodeView?.strategy = strategy
        viewModel.username = strategy?.username

        switch strategy {

        case is RegisterStepOneWithFingerPrintStrategy: viewModel.sendPincode()

        case is ForgetBioPinStrategy: viewModel.sendPincode(bioStatus: true)

        case is AccountResetPasswordStrategy:
            showActivityIndicator()
            self.viewModel.sendPincode()

        case is ForgetPasswordStrategy:
            showActivityIndicator()
            self.viewModel.connectionType = strategy?.connectionType ?? ""
            self.viewModel.sendRecoveryCode()
        case is UpdateUserEmailStrategy:
            showActivityIndicator()
            self.viewModel.sendPinCodeToUpdateEmail(newEmail: self.viewModel.email)
        case is UpdateUserPhoneStrategy:
            showActivityIndicator()
            self.viewModel.sendPinCodeToUpdatePhone(newPhone: self.viewModel.phone)
        case is EnableBiometricIDStrategy:
            self.viewModel.sendPincode()
        default: break

        }

        otpCodeView.resendIsTapped = tapOnResendButton

        otpCodeView.confirmIsTapped = tapOnConfirmButton
    }

    private func tapOnConfirmButton() {
        showActivityIndicator()
        self.viewModel.pincode = self.otpCodeView.typedCode
        self.callWSConfirm()
    }
    private func tapOnResendButton() {
//        self.otpCodeView.clearOTPFields()
        showActivityIndicator()

        switch self.strategy {
        case is ForgetPasswordStrategy: self.viewModel.sendRecoveryCode()
        case is ForgetBioPinStrategy: self.viewModel.sendPincode(bioStatus: true)
        case is LoginWithFingerPrintStrategy: AuthenticationRouter.shared.showForgetBioPinViewController()
        case is RegistrationLastStepStrategy: self.viewModel.resendRegisterPincode()
        case is UpdateUserEmailStrategy:
            self.viewModel.sendPinCodeToUpdateEmail(newEmail: self.viewModel.email)
        case is UpdateUserPhoneStrategy:
            self.viewModel.sendPinCodeToUpdatePhone(newPhone: self.viewModel.phone)
        default: self.viewModel.sendPincode()
        }

    }
    private func callWSConfirm() {

        switch strategy {

        case is RegisterStepOneWithFingerPrintStrategy, is AccountResetPasswordStrategy:
            self.viewModel.validatePincode()

        case is RegisternStepTwoWithFingerPrintStrategy:
            self.viewModel.sendBioPinCode()

        case is LoginWithFingerPrintStrategy:
            break
        case is RegistrationLastStepStrategy:
            self.viewModel.activateUserAccount()

        case is ForgetPasswordStrategy: self.viewModel.checkrecoverycode()

        case is ForgetBioPinStrategy, is UpdateUserPhoneStrategy, is UpdateUserEmailStrategy:
            self.viewModel.validatePincode()
        case is EnableBiometricIDStrategy :
            self.viewModel.validatePincode()
        default: break

        }
    }

    private func setUpBindings() {

        viewModel.pincodeState.sink { [unowned self]   state in
            hideActivityIndicator()
            switch state {
            case .didSendPincode :
                break
            case .didResendPinCodeToRegister:
                break
            case .error(let error ) :
                self.showErrorAlertView(descriptionMessage: error.message) {
                    self.otpCodeView.otpCodeView.clearAllFields()
                }
            case .didFinishAction :
                switch self.strategy {
                case is UpdateUserEmailStrategy:
                    self.viewModel.updateEmail()
                case is UpdateUserPhoneStrategy:
                    self.viewModel.updatePhone()
                case is EnableBiometricIDStrategy:
                    self.viewModel.updateBioLoginStaus()
                default:
                    self.redirectUser()
                }
            case .didFailOnSendRecoveryCode(let error):
                self.showErrorAlertView(descriptionMessage: error.message) {
                    self.pop()
                }
            default :
                self.redirectUser()
            }
        }.store(in: &cancellable)
    }

    private func redirectUser() {

        switch strategy {

        case is AccountResetPasswordStrategy: AuthenticationRouter.shared.goToResetPasswodVC()
        // If user active his code
        case is RegistrationLastStepStrategy: successRegistration()
        case is RegisterStepOneWithFingerPrintStrategy:
            AuthenticationRouter.shared.showValidateCodePinViewController()

        case is RegisternStepTwoWithFingerPrintStrategy:
            self.popToRootViewController()
            AppRouter.shared.reloadMenuView()

        case is LoginWithFingerPrintStrategy:
            AppRouter.shared.reloadMenuView()
            self.popToRootViewController()

        case is ForgetPasswordStrategy:
            AuthenticationRouter.shared
                .goToRecoverPasswodVC(username: strategy?.username ?? "",
                                      connectionType: strategy?.connectionType ?? "")
        case is ForgetBioPinStrategy: AuthenticationRouter.shared.goToRecoverBioPinVC()
        case is UpdateUserEmailStrategy :
            self.showSuccessAlertView(message: LocalizedAccount.successEmailUpdate.localized, didConfirm: {
                self.popToRootViewController()
            })
        case is UpdateUserPhoneStrategy:
            self.showSuccessAlertView(message: LocalizedAccount.successPhoneUpdate.localized, didConfirm: {
                self.popToRootViewController()
            })
        case is EnableBiometricIDStrategy:
            self.showSuccessAlertView(message: LocalizedAuthentication.successBioMessage.localized, didConfirm: {
                self.popToRootViewController()
            })
        default: break
        }
    }

    // After activating user
    private func successRegistration() {
        AuthManager.shared.isBiometicEnabled = false
        self.showSuccessAlertView(message: LocalizedAuthentication.registrationSuccessMessage.localized) {
            self.popToRootViewController()
            AppRouter.shared.updateViewController(LoginViewController
                                                    .instantiate(appStoryboardName:
                                                                    AppStoryboard.authentification
                                                    ))
        }
    }
}
