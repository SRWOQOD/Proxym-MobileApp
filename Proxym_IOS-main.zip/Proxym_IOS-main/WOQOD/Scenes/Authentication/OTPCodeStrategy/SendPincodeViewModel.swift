//
//  SendCodeInEmailViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 10/18/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import  Combine

enum ListPincodeState {
    case didFinishUpdatingEmail
    case didFinishUpdatingPhone
    case didFinishAction
    case didSendPincode
    case didSendPincodeToUpdateEmail
    case didSendPincodeToUpdatePhone
    case didResendPinCodeToRegister
    case didFinishEnableBiometric
    case didFailOnSendRecoveryCode(WQError)
    case error(WQError)
}

class SendPincodeViewModel: ViewModel {

    var pincodeState = PassthroughSubject<ListPincodeState, Never>()
    var authChallengeHand = AuthChallengeHandler.shared
    var stateLogin = PassthroughSubject<ListPincodeState, Never>()
    var pincode: String = ""
    var username: String?
    var email: String = ""
    var phone: String = ""
    var userVM = UserViewModel()
    var connectionType: String = ""
    // var type: String = ""

    override init() {
        super.init()
        username = user?.userName
        // type = LoginTypeKeys.init(fromRawValue: connectionType).rawValue
    }

    func sendPincode(bioStatus: Bool = false) {

        let state: StateHandler = { [unowned self]  result in
            switch result {
            case .finished: break
            case .failure(let error):
                let err = error as? WQError
                self.pincodeState.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in
//            if sent {
                self.pincodeState.send(.didSendPincode)

//        }
        }

        OTPCodeAPIManager.getOTPCode(username: self.username ?? "", bioStatus: bioStatus)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

    func validatePincode(bioStatus: Bool = false) {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: break
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in
//            if valid {
                self.pincodeState.send(.didFinishAction)

//        }
//            else {
//                self.pincodeState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
//            }
        }
        OTPCodeAPIManager.validateOTPCode(username: self.username ?? "", pincode: pincode, bioStatus: bioStatus)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }

    func activateUserAccount() {

        let state: StateHandler = { (result) in
            switch result {
            case .finished: self.pincodeState.send(.didFinishAction)
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in}

        RegisterApiManager.activateUser(username: self.username ?? "", pincode: self.pincode)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

    func sendBioPinCode() {

        let bioAuthentication = BioAuthentication(bioPin: pincode,
                                                  deviceId: getDeviceId(),
                                                  userName: self.username ?? "")

        let stateHandler: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.pincodeState.send(.didFinishAction)
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }

        BioAPIManager.sendBioPin(bioAuth: bioAuthentication)
            .sink(receiveCompletion: stateHandler, receiveValue: { pwd in
                pwdInKeyChain = pwd.1
            }).store(in: &cancellable)
    }

    func sendRecoveryCode() {
        let state: StateHandler = { [unowned self]  result in
            switch result {
            case .finished: break
            case .failure(let error):
                let err = error as? WQError
                self.pincodeState.send(.didFailOnSendRecoveryCode(
                    err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in
//            if sent {
                self.pincodeState.send(.didSendPincode)
//        }
        }

        RegisterApiManager.getRecoveryCode(username: username ?? "", connectionType: connectionType)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }

    func checkrecoverycode() {
//        checkTappedType()
        let state: StateHandler = { (result) in
            switch result {
            case .finished: break
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in
//            if valid {
                self.pincodeState.send(.didFinishAction)
//
//            } else {
//                self.pincodeState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
//            }
        }

        RegisterApiManager.checkRecoveryCode(username: username ?? "", connectionType: connectionType, pincode: pincode)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }
    /**
     * check the format of login input : Email / MobileNumber / QID / else it's Username
     */
    func checkTappedType() {
        if username?.isValidRegex(regex: Regex.email) == true {
            self.connectionType = LoginTypeKeys.emailAuth.rawValue
        }
        if username?.isValidRegex(regex: Regex.qatariIdLength) == true {
            self.connectionType = LoginTypeKeys.qidAuth.rawValue

        } else if username?.isValidRegex(regex: Regex.mobileLength) == true {
            self.connectionType = LoginTypeKeys.mobilenumberAuth.rawValue
        } else {
            self.connectionType = LoginTypeKeys.usernameAuth.rawValue
        }
    }

    /// UPDATE EMAIL : To update email , a pin code must be sent to the new user email to verify it
    func sendPinCodeToUpdateEmail(newEmail: String) {
        let sendPinCodeEmailState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let sendPinCodeEmailResult: ReceivedValue<Bool, Bool>  = { (_, sent) in
            if sent {
                self.pincodeState.send(.didSendPincode)
            } else {
                self.pincodeState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        UserAPIManager.sendPinCodeToUpdateEmail(email: email)
            .sink(receiveCompletion: sendPinCodeEmailState, receiveValue: sendPinCodeEmailResult)
            .store(in: &cancellable)
    }

    /// UPDATE PHONE : To update phone number , a pin code must be sent to the new user phone to verify it
    func sendPinCodeToUpdatePhone(newPhone: String) {
        let sendPinCodePhoneState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let sendPinCodePhoneResult: ReceivedValue<Bool, Bool>  = { (_, sent) in
            if sent {
                self.pincodeState.send(.didSendPincode)
            } else {
                self.pincodeState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        UserAPIManager.sendPinCodeToUpdatePhone(phone: phone)
            .sink(receiveCompletion: sendPinCodePhoneState, receiveValue: sendPinCodePhoneResult)
            .store(in: &cancellable)

    }

    /// UPDATE EMAIL : After verifing the new email , the email adress will be updated
    func updateEmail() {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: self.pincodeState.send(.didFinishUpdatingEmail)
            case .failure(let error):
                let err = error as? WQError
                self.pincodeState.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, result) in
            if result {
                self.user?.email = self.email
                AuthManager.shared.currentUser = self.user
            }
        }
        UserAPIManager.upateEmail(username: user?.userName ?? "", email: email)
            .sink(receiveCompletion: state, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    /// UPDATE PHONE : After verifing the new phone number , the mobile number will be updated
    func updatePhone() {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: self.pincodeState.send(.didFinishUpdatingEmail)
            case .failure(let error):
                let err = error as? WQError
                self.pincodeState.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, result) in
            if result {
                self.user?.mobileNumber = self.phone
                AuthManager.shared.currentUser = self.user
            }
        }
        UserAPIManager.upateMobileNumber(username: user?.userName ?? "", phone: phone)
            .sink(receiveCompletion: state, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    func resendRegisterPincode() {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: break
            case .failure(let error):
                self.pincodeState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, valid) in
            if valid {
                self.pincodeState.send(.didResendPinCodeToRegister)
            } else {
                self.pincodeState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        RegisterApiManager.resendPinCode(username: self.username ?? "")
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }

    /// UPDATE Biometric enable : After verifing the new phone number , the mobile number will be updated
    func updateBioLoginStaus() {
        let stateHandler: StateHandler = { result in
            switch result {
            case .finished:  self.pincodeState.send(.didFinishEnableBiometric)
            case .failure(let error):

                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receivedValue: (Bool, Bool) -> Void = { (_, updated) in
            if updated {
                pwdInKeyChain = self.user?.customIdentification
                self.user?.isBiometricActivated = true
                AuthManager.shared.isBiometicEnabled = true
                AuthManager.shared.currentUser = self.user
                self.state.send(.finishedLoading)
            }
        }

        BioAPIManager.updateStatus(username: user?.customIdentification ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

}
