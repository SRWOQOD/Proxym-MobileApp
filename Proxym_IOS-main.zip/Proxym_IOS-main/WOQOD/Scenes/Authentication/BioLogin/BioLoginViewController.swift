//
//  BioLoginViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 23/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import LocalAuthentication
import Combine

class BioLoginViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var biometricLoginView: UIView!
    @IBOutlet weak var authentificationTitle: UILabel!
    @IBOutlet weak var authentificationStatusLabel: UILabel!
    @IBOutlet weak var finguerPrintImage: UIImageView!
    @IBOutlet weak var continueButton: WQButton!
    @IBOutlet weak var cancelButton: UIButton!

    // MARK: - Public properties
    var biometricManager: BiometricManager?
    var isEnabledBio = false
    var isLogInType = false
    var viewModel = LoginViewModel()
    var cancellable = Set<AnyCancellable>()
    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        bindData()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        cancellable.removeAll()
    }

    // MARK: - Private functions

    private func bindData() {
        // Binding data for setting biometrics
        func bindDataForSetupBio() {
            self.viewModel.state.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading :
                    self.showSuccessAlertView(message:
                                                LocalizedAuthentication.successBioMessage.localized,
                                              didConfirm: {self.pop()})
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, didConfirm: {self.pop()})
                default : break
                }
            }
            .store(in: &cancellable)

        }
               // Binding data for logging with
        func bindDataForLoginState() {
            self.viewModel.stateLogin.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading :
                    self.popToRootViewController()
                    AppRouter.shared.reloadMenuView()
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, didConfirm: {self.pop()})
                default : break
                }
            }
            .store(in: &cancellable)
        }
        bindDataForSetupBio()
        bindDataForLoginState()
    }

    fileprivate func initUI() {
        update(enabled: isEnabledBio)
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        initBiometricLoginView()

    }

    fileprivate func initBiometricLoginView() {
        biometricLoginView.border(borderColor: UIColor.white.withAlphaComponent(0.5), borderwidth: 2)
        biometricLoginView.roundTopCorners(radius: 15)
        cancelButton.title = LocalizableShared.cancel.localized
        authentificationTitle.setText(text: LocalizedAuthentication.bioAuthTitle.localized,
                            font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
    }

    /// update ui when authentication with finguer print is successfull
    /// - Parameter enabled: value if authentication is true or false
    fileprivate func update(enabled: Bool) {
        continueButton.round()
        continueButton.font = UIFont(name: Fonts.boldFontName, size: 13.adjusted)
        continueButton.backgroundColor = .wqGreen
        continueButton.style = enabled ? Buttontype.primary : .cancel
        continueButton.title = enabled ? LocalizableShared.commonContinue.localized.uppercased() :
            LocalizableShared.tryAgain.localized.uppercased()
        authentificationStatusLabel
            .setText(text: enabled ? LocalizedAuthentication.bioAuthSuccess.localized:
                        LocalizedAuthentication.bioAuthFailure.localized,
                     font: Fonts.mediumFontName,
                     size: 15,
                     forgroundColor: .wqBlue)
        cancelButton.isHidden = enabled
        finguerPrintImage.image = enabled ?  #imageLiteral(resourceName: "ic_fingerSuccess") : #imageLiteral(resourceName: "ic_fingerFailure")
    }

    func redirectToOTPScreen() {
        SendPincodeViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification, completion: {  (viewC) in
            if let viewC = viewC as? SendPincodeViewController {
                viewC.strategy = EnableBiometricIDStrategy()
            }
        })
    }

    // MARK: - IBActions
    @IBAction func continueLoginButton(_ sender: Any) {
        if isEnabledBio {
            showActivityIndicator()
            isLogInType ? viewModel.loginWithBio() :  redirectToOTPScreen()
        } else {
            // Try again
            self.pop()
            biometricManager?.biometricAuthentication()
        }
    }

    @IBAction func cancelAction(_ sender: Any) {
        popToRootViewController()
    }
}
