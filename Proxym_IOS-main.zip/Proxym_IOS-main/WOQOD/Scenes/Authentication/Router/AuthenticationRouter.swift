//
//  AuthenticationRouter.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 10/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class AuthenticationRouter {

    static var shared = AuthenticationRouter()

    // Login
    func initLoginView() {
        LoginViewController.showViewWithNavigationControllerFor(appStoryboard:
                                                                    AppStoryboard.authentification,
                                                                withNavigationBar: true)
    }
    func showValidateOTPcodeViewController() {
        sendEmailViewController(strategy: RegisterStepOneWithFingerPrintStrategy())
    }
    func showValidateCodePinViewController() {
        sendEmailViewController(strategy: RegisternStepTwoWithFingerPrintStrategy())
    }
    func showBioLoginViewController(viewModel: LoginViewModel = LoginViewModel(),
                                    isLogInType: Bool = false, isEnabled: Bool = false,
                                    biometricManager: BiometricManager?) {
        BioLoginViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.authentification) { (viewC) in
            if  let viewC = viewC as? BioLoginViewController {
                viewC.viewModel = viewModel
                viewC.isLogInType = isLogInType
                viewC.isEnabledBio = isEnabled
                viewC.biometricManager = biometricManager
            }
        }
    }
    func showPinCodeViewController() {
        sendEmailViewController(strategy: LoginWithFingerPrintStrategy())
    }

    func showForgetBioPinViewController() {
        let strategy = ForgetBioPinStrategy()
        guard let pass = pwdInKeyChain else {
            return
        }
        strategy.username = pass
        sendEmailViewController(strategy: strategy)
    }

    func showForgetPasswordViewController(username: String, connectionType: String) {
        let strategy = ForgetPasswordStrategy()
        strategy.username = username
        strategy.connectionType = connectionType
        sendEmailViewController(strategy: strategy)
    }

    func goToRecoverPasswodVC(username: String, connectionType: String) {
        let strategy = RecoverPasswordStrategy()
        strategy.username = username
        strategy.connectionType = connectionType
        showPasswordViewController(strategy: strategy)
    }

    // Register
    func showRegisterQidViewController() {
        RegisterQidViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.authentification) { (viewC) in
            if  let viewC = viewC as? RegisterQidViewController {
                viewC.registrationPath = .fromSignin
            }
        }
    }

    func showRegisterViewController(viewModel: RegisterViewModel?) {
        RegisterViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.authentification) { (viewC) in
            if  let viewC = viewC as? RegisterViewController {
                viewC.registerViewModel = viewModel
            }
        }
    }

    func showLastRegisterViewController(viewModel: RegisterViewModel?) {
        LastStepRegisterViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification) { (viewC) in
            if  let viewC = viewC as? LastStepRegisterViewController {
                viewC.viewModel = viewModel
            }
        }
    }

    func sendEmailViewController(strategy: OTPStrategyProtocol) {
        SendPincodeViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification, completion: {  (viewC) in
            if let viewC = viewC as? SendPincodeViewController {
                viewC.strategy = strategy
            }
        })
    }

    // Account
    func goToResetPasswodVC() {
        showPasswordViewController(strategy: ResetPasswordStrategy())
    }

    // Profile
    func showEditProfileViewController(editVM: EditProfileViewModel) {
        EditProfileViewController.pushViewControllerFor(
            appStoryboardName: AppStoryboard.account, completion: { (viewC) in
            if let viewC = viewC as? EditProfileViewController {
                viewC.editProfileVM = editVM
            }
        })
    }
    func showProfileViewController() {
        ProfileViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.account)
    }

    func showAccountWith(viewController: UIViewController) {
        AccountViewController.pushViewControllerFor(viewController: viewController)
    }

    // RecoverBioPin
    func goToRecoverBioPinVC() {
        showPasswordViewController(strategy: RecoverBioPinStrategy())
    }

    // Strategy for Redundant password screen like reset or recover password
    func showPasswordViewController(strategy: PasswordStrategyProtocol) {
        ResetPasswordViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.account, completion: {  (viewC) in
            if let viewC = viewC as? ResetPasswordViewController {
                viewC.strategy = strategy
            }
        })
    }

    func showLoginSendPincodeController(viewModel: LoginViewModel, strategy: OTPStrategyProtocol?) {
        LoginSendPincodeViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification, completion: {  (viewC) in
            if let viewC = viewC as? LoginSendPincodeViewController {
                viewC.viewModel = viewModel
                viewC.strategy = strategy
            }
        })
    }

    func showTermsOfUseViewController() {
        TermsOfUseViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.gdpr)
    }
    func showPrivacyPolicyViewController() {
        PrivacyPolicyViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.gdpr)
    }

}
