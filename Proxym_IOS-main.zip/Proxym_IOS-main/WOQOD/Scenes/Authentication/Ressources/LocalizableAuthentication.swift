//
//  File.swift
//  combineUITest
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 Oumayma.guefrej. All rights reserved.
//

import Foundation

enum LocalizedAuthentication: String, LocalizableDelegate {

    /* Login page */

    case loginLoginGoBtn = "AuthenticationLoginLoginGoBtn"
    case loginSignup = "AuthenticationLoginSignup"
    case loginContinueAsGuest = "AuthenticationLoginContinueAsGuest"
    case loginLoginWithFingerprint = "AuthenticationLoginLoginWithFingerprint"
    case loginForgotYourPassword = "AuthenticationLoginForgotYourPassword"
    case loginSignIn = "AuthenticationLoginSignIn"
    case loginBiometricSignIn = "AuthenticationBiometricSignIn"
    case bioAuthTitle = "AuthentificationBiometricLogin"
    case bioAuthSuccess = "AuthentificationBiometricLoginSuccess"
    case bioAuthFailure = "AuthentificationBiometricLoginFailure"
    case bioSetUpTitle = "AuthentificationBiometricIdSetup"
    case bioSetUpMessage = "AuthentificationBiometricIdSetupMessage"
    case loginConnectionTypes = "AuthenticationLoginConnectionTypes"
    case loginUserBlockedError = "AuthenticationLoginUserBlocked"
    case loginPassword = "AuthenticationLoginPassword"
    case successBioMessage = "AuthenticationActivateBioSuccessAlert"
    /* Code Verification */
    case loginCodeVerification = "AuthenticationLoginCodeVerification"
    case loginCodeVerificationMessage = "AuthenticationLoginCodeVerificationMessage"

    /* Forget password */

    case forgetPasswordVerifyMailSubTitle = "ForgetPasswordVerifyMailSubTitle"
    case forgetPasswordRecoverCodeDialogMessage = "ForgetPasswordRecoverCodeDialogMessage"
    case forgetPasswordTitle = "ForgetPasswordTitle"
    case forgetPasswordUserIdEmpty = "ForgetPasswordUserIdEmpty"
    case recoveryPasswordTitle = "RecoveryPasswordTitle"
    case recoveryPasswordText = "RecoveryPasswordText"

    /* Registration */
    case registrationTitle = "AuthenticationRegistrationTitle"
    case registrationStep1Title = "AuthenticationRegistrationStep1Title"
    case datePlaceholder = "AuthenticationRegistrationDatePlaceholder"
    case registrationSuccessMessage = "AuthenticationRegistrationSuccessMessage"
    case registrationPinCodeSentSuccess = "AuthenticationRegistrationPinCodeSentSuccess"
    case emailUpdatePinCodeSentSuccess = "AuthenticationUpdateEmailPinCodeSentSuccess"
    case genderPlaceholder = "AuthenticationRegistrationGenderPlaceholder"
    case areaOfResidencePlaceholder = "AuthenticationRegistrationAreaOfResidencePlaceholder"
    /* Finger print */

    case loginWithBiometricsDescription = "AuthenticationLoginWithBiometricsDescription"
    case loginWithBiometricsPasscode = "AuthenticationLoginWithBiometricsPasscode"
    case loginWithFingerPrint = "AuthenticationLoginWithFingerPrint"
    case loginTouchId = "AuthenticationLoginTouchId"
    case loginTouchIdMessage = "AuthenticationLoginTouchIdMessage"
    case loginWellDone = "AuthenticationLoginWellDone"
    case loginTouchIdSetup = "AuthenticationLoginTouchIdSetup"
    case forgotBioPin = "AuthenticationLoginForgotBioPin"
    case recoverBioPinTitle = "AuthenticationLoginRecoverBioPinTitle"
    case newBioPin = "AuthenticationLoginNewBioPin"
    case bioPin = "AuthenticationLoginBioPin"
    case confirmBioPin = "AuthenticationLoginBioPinConfirm"
    case genderMale = "AuthenticationGenderMale"
    case genderFemale = "AuthenticationGenderFemale"
    case gender = "AuthenticationGender"
    case acceptTermsErrorMsg = "AuthenticationRegistrationAcceptTermsErrorMsg"
    case rememberMe = "AuthenticationRememberMe"
    var tableName: String? {
        return "Authentication"
    }
}
