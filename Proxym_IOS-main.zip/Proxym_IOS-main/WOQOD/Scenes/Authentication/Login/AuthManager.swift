//
//  AuthentificationManager.swift
//  WOQOD
//
//  Created by rim ktari on 7/9/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine
import KeychainAccess

class AuthManager {

    static var shared = AuthManager()
    private let defaults = UserDefaults.standard
    public var userToRegister = UserToRegister()

    public var currentUser: User? {
        didSet {
            savedCurrentUser = currentUser
        }
    }
    public var currentUsername: String? {
        didSet {
            savedLastUsername = currentUsername
        }
    }

    // Extract user from Keychain with get & save it to Keychain with set
    private var savedCurrentUser: User? {
        get {
            if let savedUser = try? keychain.getData(KeychainKeys.currentUserKey) {
                let decoder = JSONDecoder()
                return try? decoder.decode(User.self, from: savedUser)
            }
            return nil
        }

        set {
            do {
                let encoder = JSONEncoder()
                if newValue != nil {
                    if let userData = try? encoder.encode(newValue) {
                        do {
                            try keychain.set(userData, key: KeychainKeys.currentUserKey)
                        } catch let error {
                            #if DEBUG
                            print("error storing in keychain: \(error)")
                            #endif
                        }
                    }
                } else {
                    do {
                        try keychain.remove(KeychainKeys.currentUserKey)
                    } catch let error {
                        #if DEBUG
                        print("error removing from keychain: \(error)")
                        #endif
                    }
                }
            }
        }
    }

    // Extract user from Keychain with get & save it to Keychain with set
    private var savedLastUsername: String? {
        get {
            if let savedUsername = try? keychain.getData(KeychainKeys.savedCurrentUsername) {
                let decoder = JSONDecoder()
                return try? decoder.decode(String.self, from: savedUsername)
            }
            return nil
        }

        set {
            do {
                let encoder = JSONEncoder()
                if newValue != nil {
                    if let userData = try? encoder.encode(newValue) {
                        do {
                            try keychain.set(userData, key: KeychainKeys.savedCurrentUsername)
                        } catch let error {
                            #if DEBUG
                            print("error storing in keychain: \(error)")
                            #endif
                        }
                    }
                } else {
                    do {
                        try keychain.remove(KeychainKeys.savedCurrentUsername)
                    } catch let error {
                        #if DEBUG
                        print("error removing from keychain: \(error)")
                        #endif
                    }
                }
            }
        }
    }

    // Extract imageUrl from userDefault & save it to userDefault
     var photo: String? {

        didSet {
            currentUser?.photo = photo
            savedCurrentUser = currentUser
        }
    }

    public var firstBioAuth: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.firstBioAuth) as? Bool
        }

        set {
            defaults.set(newValue, forKey: UserDefaultKeys.firstBioAuth)

        }
    }
    public var isFirstLogin: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.firstLogin) as? Bool
        }

        set {
            defaults.set(newValue, forKey: UserDefaultKeys.firstLogin)

        }
    }

    public var isGuestModeActivated: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.isGuest) as? Bool

        }
        set {
            defaults.set(newValue, forKey: UserDefaultKeys.isGuest)
        }
    }

    public var isRemembred: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.isRemembered) as? Bool
        }
        set {
            defaults.set(newValue, forKey: UserDefaultKeys.isRemembered)
        }
    }

    public var isBiometicEnabled: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.isBiometricActivated) as? Bool
        }
        set {
            defaults.set(newValue, forKey: UserDefaultKeys.isBiometricActivated)
        }
    }

    public var shouldHideAppTips: Bool? {
        get {
            return defaults.object(forKey: UserDefaultKeys.shouldHideAppTips) as? Bool
        }
        set {
            defaults.setValue(newValue, forKey: UserDefaultKeys.shouldHideAppTips)
        }
    }

    public var serverDate: CurrentDate? {
        get {
            do {
                if let serverDate = defaults.data(forKey: UserDefaultKeys.qatarDateString) {
                    let decoder = JSONDecoder()
                    return try decoder.decode(CurrentDate.self, from: serverDate)
                }
            } catch {
                #if DEBUG
                print(error.localizedDescription)
                #endif
            }
            return nil
        }
        
        set {
            if newValue != nil {
                do {
                    let serverDate = try JSONEncoder().encode(newValue)
                    defaults.setValue(serverDate, forKey: UserDefaultKeys.qatarDateString)
                } catch {
                    #if DEBUG
                    print("error storing in userDefaults: \(error)")
                    #endif
                }
            }
        }
    }


    @Published var didChangeLanguage: Bool = false
    @Published var didUpdateLocation: Bool = false
    @Published var didUpdateBiometric: Bool = false

    init() {
        currentUser = savedCurrentUser
        currentUsername = savedLastUsername
    }

    func logout() {
        currentUser = nil
        AccountManager.shared.userAccount = nil
        AuthManager.shared.photo = nil
        // Logout using mfp
        AuthChallengeHandler.shared.logout()
    }

    func cancelChallenge() {
        currentUser = nil
        AccountManager.shared.userAccount = nil
        AuthManager.shared.photo = nil
        AuthChallengeHandler.shared.cancelChallange()
    }

}
