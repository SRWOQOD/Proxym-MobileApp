//
//  LoginViewController.swift
//  WOQOD
//
//  Created by rim ktari on 7/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import IBMMobileFirstPlatformFoundation
import  Combine
import  LocalAuthentication

/// Description
/*
 //              ---- Steps in a happy path -----
 // step1: the User do a login by username ad password
 // Step2: if it is the user's firt login, he will receive
 // an alert informing him if he wants to activate his finger print login
 // Step3: if user accepts to activate his finger print, he will receive an OTP Code by email (for instance)
 // stap4: user will type his otp & validate it
 // step5: user will insert his finger print
 // step6: user will type his chosen bio pin
 */
import IBMMobileFirstPlatformFoundationPush
class LoginViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var biometricLoginView: UIView!
    @IBOutlet var backgroundView: UIView!
    @IBOutlet weak var usernameView: WQTextFieldView!
    @IBOutlet weak var passwordView: WQTextFieldView!
    @IBOutlet weak var registerButton: WQButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var biometricLoginButton: UIButton!
    @IBOutlet weak var continueGuestButton: WQButton!
    @IBOutlet weak var forgetPasswordButton: UIButton!
    @IBOutlet weak var signInTitle: UILabel!
    @IBOutlet weak var remeberMeView: WQCheckBoxView!
    @IBOutlet weak var biometricLoginLabel: UILabel!
    // MARK: - Public properties
    let loginViewModel = LoginViewModel()

    // MARK: - Private properties
    private var cancelBag = CancelBag()
    private var cancellable = Set<AnyCancellable>()
    var fingerPrintClicked: Bool = false
    var type: LoginTypeKeys = .usernameAuth
    var biometricManager: BiometricManager?

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reloadLabels()
        setUpBindings()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        cancellable.removeAll()
    }

    // MARK: - Private functions
    private func initUI() {
        title = LocalizedAuthentication.loginSignIn.localized
        headerView.menuAction = presentMenu
        initLoginView()
        initButtons()
        initTextFields()
        initRemeberMeView()
        initBiometricLoginView()
    }

    private func initLoginView() {
        loginView.border(borderColor: UIColor.white.withAlphaComponent(0.5), borderwidth: 2)
        loginView.roundTopCorners(radius: 15)

        signInTitle.setText(text: LocalizedAuthentication.loginSignIn.localized,
                            font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
    }

    private func initBiometricLoginView() {
        biometricLoginView.isHidden = loginViewModel.shouldHideFinguerPrintButton
        biometricLoginLabel.setText(text: LocalizedAuthentication.loginBiometricSignIn.localized,
                                    font: Fonts.bookFontName, size: 15, forgroundColor: .wqBlue,
                                    align: languageIsArabic ? .right : .left)
    }

    private func initButtons() {

        // Login button
        loginButton.title = LocalizedAuthentication.loginLoginGoBtn.localized
        loginButton.round()
        loginButton.font = UIFont(name: Fonts.boldFontName, size: 13.adjusted)
        loginButton.backgroundColor = .wqGreen

        // ForgetPassword button
        forgetPasswordButton.setTitle(LocalizedAuthentication.loginForgotYourPassword.localized, for: .normal)
        forgetPasswordButton.setTitleColor(.wqBlue, for: .normal)
        forgetPasswordButton.font = UIFont(name: Fonts.mediumFontName, size: 12.adjusted)
        // Continue button
        continueGuestButton.backgroundColor = .wqLightGreen
        continueGuestButton.title = LocalizedAuthentication.loginContinueAsGuest.localized

        // Register button
        registerButton.title = LocalizedAuthentication.loginSignup.localized
        registerButton.backgroundColor = .wqBlue
    }
    func reloadLabels() {
        loginButton.title = LocalizedAuthentication.loginLoginGoBtn.localized
        continueGuestButton.title = LocalizedAuthentication.loginContinueAsGuest.localized
        registerButton.title = LocalizedAuthentication.loginSignup.localized
        usernameView.title = LocalizableShared.signIn.localized
        usernameView.placeholder = LocalizableShared.signInPlaceholder.localized
        passwordView.title = LocalizableShared.password.localized
        passwordView.placeholder = ""
        signInTitle.setText(text: LocalizedAuthentication.loginSignIn.localized,
                            font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
        biometricLoginLabel.setText(text: LocalizedAuthentication.loginBiometricSignIn.localized,
                                    font: Fonts.bookFontName, size: 15, forgroundColor: .wqBlue,
                                    align: languageIsArabic ? .right : .left)
        remeberMeView.textLabel = LocalizedAuthentication.rememberMe.localized
        forgetPasswordButton.setTitle(LocalizedAuthentication.loginForgotYourPassword.localized, for: .normal)
    }

    private func initTextFields() {
        // field usernameView
        usernameView.title = LocalizableShared.signIn.localized
        usernameView.titleColor = .wqBlue
        usernameView.fieldType = .usernameLogin
        usernameView.placeholder = LocalizableShared.signInPlaceholder.localized
        if isRemembred {
            usernameView.value = AuthManager.shared.currentUsername
            loginViewModel.username = AuthManager.shared.currentUsername ?? ""
        }
        // field passwordView
        passwordView.title = LocalizableShared.password.localized
        passwordView.placeholder = ""
        passwordView.titleColor = .wqBlue
        passwordView.fieldType = .passwordLogin
    }
    private func clearFields() {
        usernameView.value = ""
        passwordView.value = ""
        clearErrors()
    }

    private func clearErrors() {
        usernameView.errorValue = ""
        passwordView.errorValue = ""
    }

    private func setUpBindings() {
        // send written values of username & password to viewModel
        func bindViewToViewModel() {
                usernameView.textChanged.assign(to: \.username, on: loginViewModel).store(in: &cancellable)
                passwordView.textChanged.assign(to: \.password, on: loginViewModel).store(in: &cancellable)
        }

        func subsribeOnLoginState() {
            loginViewModel.stateLogin.sink { state in
                hideActivityIndicator()

                switch state {
                case .validCredentials:
                    AuthenticationRouter.shared
                        .showLoginSendPincodeController(viewModel: self.loginViewModel,
                                                        strategy: LoginOTPStrategy())
                case .error(let error):
                    let statusCode =  ErrorCode.init(fromRawValue: error.statusCode ?? "")
                    switch statusCode {
                    case .userBlocked:
                        self.showErrorAlertView(isCounterAlert: true)
                    default:
                        self.showErrorAlertView(descriptionMessage: error.message)
                    }
                default:
                    break
                }
            }.store(in: &cancellable)
        }
        subsribeOnLoginState()
        bindViewToViewModel()
    }

    /// This func is used to redirect user from where it comes (Fahes/Woqode/Simple Login)
    func redirectUser() {
        self.popToRootViewController()
        switch self.loginViewModel.loginPath {
        case .fromFahes:
            AppRouter.shared.updateViewController(FahesMenuViewController
                                                    .instantiate(appStoryboardName: AppStoryboard.fahes))
        case .fromWoqode:
            HomeRouter.shared.redirectUserToWoqodeFeatures()
        default:
            AppRouter.shared.reloadMenuView()
        }
    }

    /// This view is added to allow user to remember his creds
    func initRemeberMeView() {
        remeberMeView.textLabel = LocalizedAuthentication.rememberMe.localized
        remeberMeView.hideButton()
        remeberMeView.isMandatory = false
        if isRemembred {
            remeberMeView.checkBoxButton.isSelected.toggle()
            remeberMeView.checkBoxButton.isSelected ? remeberMeView.checkBoxButton.setImage(#imageLiteral(resourceName: "ic_selected_checkbox.png"), for: .selected)
                : remeberMeView.checkBoxButton.setImage(#imageLiteral(resourceName: "ic_unselected_checkbox.png"), for: .normal)
        }
    }

    func rememberCurrentUsername() {
        if remeberMeView.isSelected {
            AuthManager.shared.isRemembred = true
            AuthManager.shared.currentUsername = self.loginViewModel.username
        } else {
            AuthManager.shared.isRemembred = false
            AuthManager.shared.currentUsername = ""
        }
    }

    // MARK: - Actions
    @IBAction func loginAction(_ sender: Any) {

        let isValidUsername = usernameView.isValid
        let isValidPassword = passwordView.isValid
        let isValidTappedType = loginViewModel.checkAndValidateTappedType()

        if !isValidTappedType {
            // to change hardcoded text
            usernameView.errorText = "Sign in credentials does not match any type"
        }

        if isValidUsername && isValidPassword && loginViewModel.userIsBlocked == false && isValidTappedType {
            rememberCurrentUsername()
//            if isRemembred {
//                loginViewModel.username = AuthManager.shared.currentUsername ?? ""
//            }
            showActivityIndicator()
            loginViewModel.verifyCredentials()
        } else if loginViewModel.userIsBlocked {
            self.showErrorAlertView(isCounterAlert: true)
        }
    }

    fileprivate func initBiometricAuthentication() {

        biometricManager = BiometricManager(delegate: self)

        if deviceSupportsBiometric {
            biometricManager?.biometricAuthentication()
        }
    }

    @IBAction func registerAction(_ sender: Any) {
        AuthenticationRouter.shared.showRegisterQidViewController()
    }

    @IBAction func biometricLogin(_ sender: Any) {
        initBiometricAuthentication()
    }

    @IBAction func continueGuestButton(_ sender: Any) {
        AuthManager.shared.isGuestModeActivated = true
        redirectUser()
    }

    @IBAction func forgetPasswordAction(_ sender: Any) {
        _ = loginViewModel.checkAndValidateTappedType()
        if usernameView.value == "" {
            self.showErrorAlertView(descriptionMessage: LocalizedAuthentication
                                        .forgetPasswordUserIdEmpty.localized,
                                    errorImage: UIImage(named: "ic_warning_close"))
        } else if usernameView.isValid {
            self.showCustomAlertView(title: LocalizedAuthentication.forgetPasswordTitle.localized.uppercased(),
                                     text: LocalizedAuthentication.forgetPasswordRecoverCodeDialogMessage.localized,
                                     image: #imageLiteral(resourceName: "ic_recovery_password"),
                                     didConfirm: {
                                        AuthenticationRouter.shared
                                        .showForgetPasswordViewController(
                                            username: self.usernameView.value!,
                                            connectionType: self.loginViewModel.type
                                        )},
                                     didDiscard: {
                                        self.pop()
                                     })
        }

    }
}

// Biometric Manager
extension LoginViewController: BiometricDelegate {

    func cancelAuthentification() {
        AuthenticationRouter.shared.showBioLoginViewController(
            viewModel: loginViewModel,
            isLogInType: true, isEnabled: false,
            biometricManager: biometricManager)
    }

    func authenticationSuccess() {
        // Update UI when authentication was successful
        AuthenticationRouter.shared.showBioLoginViewController(
            viewModel: loginViewModel,
            isLogInType: true, isEnabled: true,
            biometricManager: biometricManager)
    }
    func authenticationError() {
        AuthenticationRouter.shared.showBioLoginViewController(
            viewModel: loginViewModel,
            isLogInType: true, isEnabled: false,
            biometricManager: biometricManager)
    }

}
