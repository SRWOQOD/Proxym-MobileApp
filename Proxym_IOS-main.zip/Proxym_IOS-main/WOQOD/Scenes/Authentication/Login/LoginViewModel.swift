//
//  LoginViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 7/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
import Combine

enum LoginViewModelState {
    case shouldVerifyOtp
    case shouldLoginWithMFP
    case shouldAskUserToActivateFingerPrint
    case finishedLoading
    case finishGettingBalance
    case validCredentials
    case error(WQError)
    case authError(WQError)
    case uiError
}

public enum LoginPath {
    case fromFahes
    case fromWoqode
    case fromFeedback
    case none
}

class LoginViewModel: ViewModel {

    // MARK: - Public properties
    var authChallengeHandler = AuthChallengeHandler.shared
    var stateLogin = PassthroughSubject<LoginViewModelState, Never>()
    var shouldHideFinguerPrintButton: Bool {
        return (pwdInKeyChain == "")
            || (deviceSupportsBiometric == false)
            || !(AuthManager.shared.isBiometicEnabled ?? false)}
   var type: String = ""
    var password: String  = ""
    var username: String = ""
    var pincode: String = ""

    let userIsBlocked: Bool = TimerManager().startTime != 0
    var kLoginWithBioEmptyPass = "LOGIN_WITH_BIO_EMPTY_PASSWORD"

    var rememberMeIsSelected = false
    var loginPath: LoginPath = .none

    var feedBackNotifId: String? // This Id is used when the feedback is from notification

    // MARK: - overrides
    override init() {
        super.init()
        subscribeToAuthResult()
    }

    // MARK: - Public methods

    /// Login using mfp
    func login() {
        // try? keychain.removeAll() //this line is just for test

        // For test : i ignored the user login type
        let credentials = Credentials(username: username.lowercased(),
                                      password: password,
                                      rememberMe: rememberMeIsSelected,
                                      type: self.type)
        authChallengeHandler.login(credentials: credentials)
    }
    func loginWithBio() {
        self.type = LoginTypeKeys.bioAuth.rawValue
        self.username = pwdInKeyChain ?? ""
        self.password = kLoginWithBioEmptyPass

        login()
    }

    /// Subscribe to get the result from mfp
    func subscribeToAuthResult() {
        authChallengeHandler.authResult.sink { result in
            switch result {
            case .success( let user ) :
                AuthManager.shared.currentUser = user
                self.checkFingerPrint()
                print("*******************************************************")
                self.stateLogin.send(.finishedLoading)

            case .failure(let error):
                self.stateLogin.send(.authError(error as? WQError ?? WQError()))

            case .none:
                break
            }
        }.store(in: &cancellable)
    }

    /// Check if user has a finguer print
    func checkFingerPrint() {
        if user?.isBiometricActivated == false && deviceSupportsBiometric
            && AuthManager.shared.isFirstLogin == nil {
            self.stateLogin.send(.shouldAskUserToActivateFingerPrint)
        }
    }

    /// Step 1: First user should veriify if credentials are valid
    func verifyCredentials() {
        let validateCredsState: StateHandler = { (completion) in

            switch completion {
            case .finished: break
            case .failure(let error):
                self.stateLogin.send(.error(error as? WQError ?? WQError()))
            }
        }

        let validateCredsResult: ReceivedValue<Bool, Bool>  = { (_, valid) in
            if valid {
                self.stateLogin.send(.validCredentials)
            }
        }
        LoginAPIManager.checkCredsValidity(username: username.lowercased(),
                                           type: type, password: password)
            .sink(receiveCompletion: validateCredsState, receiveValue: validateCredsResult)
            .store(in: &cancellable)

    }
    /// Step 2 :Second  user should veriify if credentials are valid
    func requestOTP() {
        let requestOTPState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                self.stateLogin.send(.error(error as? WQError ?? WQError()))
            }
        }

        let requestOTPResult: ReceivedValue<Bool, Bool>  = { (_, _) in
//            if sent {
                self.stateLogin.send(.shouldVerifyOtp)
//            }else {
//                self.stateLogin.send(.error(WQError(message: "PIN CODE IS NOT SENT", statusCode: "11")))
//            }
        }
        LoginAPIManager.requestOTP(username: username.lowercased(), type: type)
            .sink(receiveCompletion: requestOTPState, receiveValue: requestOTPResult)
            .store(in: &cancellable)

    }

    /// Step 3 : Pincode should be valid
    func validatePinCode() {
        let validatePinCodeState: StateHandler = { (completion) in

            switch completion {
            case .finished: break
            case .failure(let error):
                self.stateLogin.send(.error(error as? WQError ?? WQError()))

            }
        }

        let validatePinCodeResult: ReceivedValue<Bool, Bool>  = { (_, valid) in
            if valid {
                self.stateLogin.send(.shouldLoginWithMFP)
            }
        }

        LoginAPIManager.validatePinCode(username: username.lowercased(), pincode: pincode, type: type)
            .sink(receiveCompletion: validatePinCodeState, receiveValue: validatePinCodeResult)
            .store(in: &cancellable)

    }
    /**
     * check the format of login input : Email / MobileNumber / QID / else it's Username
     * This func should send error if the type does not much any type
     */
    func checkAndValidateTappedType() -> Bool {
        if username.isValidRegex(regex: Regex.email) {
            self.type = LoginTypeKeys.emailAuth.rawValue
        } else if username.isNumeric {
            if username.isValidRegex(regex: Regex.qatariIdLength) {
                self.type = LoginTypeKeys.qidAuth.rawValue

            } else if username.isValidRegex(regex: Regex.mobileLength) {
                self.type = LoginTypeKeys.mobilenumberAuth.rawValue
            } else {
                return false
            }
        } else {
            self.type = LoginTypeKeys.usernameAuth.rawValue
        }
        return true
    }
    /// Login with biometric and setup BIO

    func updateBioLoginStaus() {
        let stateHandler: StateHandler = { result in
            switch result {
            case .finished: break
            case .failure(let error):

                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receivedValue: (Bool, Bool) -> Void = { (_, updated) in
            if updated {
                pwdInKeyChain = self.user?.customIdentification
                self.user?.isBiometricActivated = true
                AuthManager.shared.isBiometicEnabled = true
                AuthManager.shared.currentUser = self.user
                self.state.send(.finishedLoading)
            }
        }

        BioAPIManager.updateStatus(username: user?.customIdentification ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

    func getBalance() {
        let balanceState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure: AccountManager.shared.userAccount = nil
            }
            self.stateLogin.send(.finishGettingBalance)
        }
        let accountResult: ReceivedValue<AccountDTO, Account>  = { (_, account) in
            AccountManager.shared.userAccount = account
        }
        UserAPIManager.getBalance(qid: user?.qid, mobile: user?.mobileNumber)
            .sink(receiveCompletion: balanceState, receiveValue: accountResult)
            .store(in: &cancellable)
    }
}
