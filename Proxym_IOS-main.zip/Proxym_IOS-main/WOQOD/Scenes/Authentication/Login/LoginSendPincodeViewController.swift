//
//  LoginSendPincodeViewController.swift
//  WOQOD
//
//  Created by rim.ktari on 18/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine
class LoginSendPincodeViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var otpView: WQOTPInsertView!
    @IBOutlet weak var headerView: WQHeaderView!

    // MARK: - Properties
    var viewModel: LoginViewModel?
    var strategy: OTPStrategyProtocol?
    var biometricManager: BiometricManager?
    private var cancellable = Set<AnyCancellable>()

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpBindings()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        cancellable.removeAll()
    }

    // MARK: - Private methods
    func initUI() {
        initHeaderView()
        initOTPView()
    }

    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    func initOTPView() {
        otpView.strategy = strategy
        otpView.confirmIsTapped = didConfirmAction
        otpView.resendIsTapped = tapOnResendButton
    }

    private func didConfirmAction() {
        showActivityIndicator()
        self.viewModel?.pincode = self.otpView.typedCode
        self.viewModel?.validatePinCode()
    }

    private func setUpBindings() {
        showActivityIndicator()
        viewModel?.requestOTP()

        viewModel?.stateLogin.sink { state in
                hideActivityIndicator()
                switch state {
                case .shouldVerifyOtp:
                    break
                case .shouldLoginWithMFP :
                    showActivityIndicator()
                    self.viewModel?.login()

                case .finishedLoading:
                    if self.viewModel?.loginPath == .fromWoqode {
                        showActivityIndicator()
                        self.viewModel?.getBalance()
                    } else {
                        AuthManager.shared.isGuestModeActivated = false
                        self.redirectUser()
                    }
                case .shouldAskUserToActivateFingerPrint:
                    self.checkIfUserWantsToActivateBioLogin()

                case .error(let error):
                    self.otpView.otpCodeView.clearAllFields()
                    self.showErrorAlertView(descriptionMessage: error.message) {
                        self.otpView.otpCodeView.clearAllFields()
                    }
                case .authError(let error):
                    self.showErrorAlertView(descriptionMessage: error.message, didConfirm: {
                        self.pop()
                    })
                case .finishGettingBalance:
                    self.popToRootViewController()
                    HomeRouter.shared.redirectUserToWoqodeFeatures()
                    AppRouter.shared.menuVC?.reloadElements()
                default:
                    break
                }
            }.store(in: &cancellable)
        }

    func redirectUser() {
        self.popToRootViewController()
        switch self.viewModel?.loginPath {
        case .fromFahes:
            AppRouter.shared.updateViewController(FahesMenuViewController
                                                    .instantiate(appStoryboardName: AppStoryboard.fahes))
        case .fromFeedback:
            AppRouter.shared.reloadMenuView()
            FeedbackDetailsViewController
                .pushViewControllerFor(appStoryboardName: AppStoryboard.feedback) { (viewC) in
                if let viewC = viewC as? FeedbackDetailsViewController {
                    viewC.feedBackNotifId=self.viewModel?.feedBackNotifId
                }
            }
        default:
            AppRouter.shared.reloadMenuView()
        }
        AppRouter.shared.menuVC?.reloadElements()
    }

    private func tapOnResendButton() {
        showActivityIndicator()
        self.viewModel?.requestOTP()

    }

    fileprivate func initBiometricAuthentication() {

        biometricManager = BiometricManager(delegate: self)

        if deviceSupportsBiometric {
            biometricManager?.biometricAuthentication()
        }
    }

    /// display an alert checking if user wants to active the biometric login
    fileprivate func checkIfUserWantsToActivateBioLogin() {
        AuthManager.shared.isFirstLogin = false

        self.showCustomAlertView(title: LocalizedAuthentication.bioSetUpTitle.localized,
                                 text: LocalizedAuthentication.bioSetUpMessage.localized,
                                 image: UIImage(named: "ic_biometricSetUp") ,
                                 didConfirm: {
                                    AuthManager.shared.firstBioAuth = true
                                    UIApplication.topViewController()?.pop()
                                    self.initBiometricAuthentication()

                                 }, didDiscard: {
                                    self.popToRootViewController()
                                    AppRouter.shared.reloadMenuView()
                                 })
    }
}
// Biometric Manager
extension LoginSendPincodeViewController: BiometricDelegate {

    func cancelAuthentification() {
        AuthenticationRouter.shared.showBioLoginViewController(viewModel: viewModel ?? LoginViewModel(),
                                                               isEnabled: false,
                                                               biometricManager: biometricManager)
    }

    func authenticationSuccess() {
        // Update UI when authentication was successful
        AuthenticationRouter.shared.showBioLoginViewController(viewModel: viewModel ?? LoginViewModel(),
                                                               isEnabled: true,
                                                               biometricManager: biometricManager)
    }
    func authenticationError() {
        AuthenticationRouter.shared.showBioLoginViewController(viewModel: viewModel ?? LoginViewModel(),
                                                               isEnabled: false,
                                                               biometricManager: biometricManager)
    }

}
