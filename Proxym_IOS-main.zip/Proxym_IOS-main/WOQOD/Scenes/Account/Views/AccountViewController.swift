//
//  AccountViewController.swift
//  WOQOD
//
//  Created by rim ktari on 7/30/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class AccountViewController: UIViewController {

    @IBOutlet weak var subMenuView: SubMenuView!

    @IBOutlet weak var titleLabel: UILabel!

    private var cancellable = Set<AnyCancellable>()
    private let accountMenuVM = AccountMenuViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.setText(text: LocalizedAccount.accountTitle.localized,
                           font: Fonts.boldFontName, size: 17, forgroundColor: .wqBlue)

        initAccountSubMenu()
    }
    /// Init fahes sub menu items
    func initAccountSubMenu() {

        subMenuView.menuItems = accountMenuVM.menuItems

        subMenuView.subMenuVM.selectedItem.sink { (menuElement) in
            DispatchQueue.main.async {
                if let viewControllerType = menuElement.viewControllerType, let storyboard = menuElement.storyboard {
                    let viewController =  viewControllerType.instantiate(appStoryboardName: storyboard)
                    AuthenticationRouter.shared.showAccountWith(viewController: viewController)
                }

                if let viewC = menuElement.viewController {
                    AuthenticationRouter.shared.showAccountWith(viewController: viewC)
                }
            }

        }.store(in: &cancellable)
    }

}
