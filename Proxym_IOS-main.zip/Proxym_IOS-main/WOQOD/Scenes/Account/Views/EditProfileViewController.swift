//
//  EditProfileViewController.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class EditProfileViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var saveButton: WQButton!
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var editProfileView: UIView!
    @IBOutlet weak var editEmailTextField: WQTextFieldView!
    @IBOutlet weak var editEmailButton: WQButton!
    @IBOutlet weak var editMobileNumberButton: WQButton!
    @IBOutlet weak var editMobileNumberTextField: WQTextFieldView!
    // MARK: - Properties
    var editProfileVM: EditProfileViewModel?
    var cancellable = Set<AnyCancellable>()

    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        initStackView()

        saveButton.title = LocalizableShared.save.localized.uppercased()

        editProfileView.border(borderColor: UIColor.white, borderwidth: 1)
        editProfileView.roundTopCorners(radius: 15)
        titleLabel.setText(text: LocalizedAccount.menuPersonalInformation.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue,
                           align: languageIsEnglish ? .left : .right)
        initUserPhoto()
        setUpBindings()
    }
    func backToRoot() {
        AppRouter.shared.reloadUserPhoto()
        self.showSuccessAlertView(message: LocalizedAccount.successUpdate.localized, didConfirm: {
            self.pop()
        })
    }

    // MARK: - Private Methods
    private func initUserPhoto() {

        self.userImageView.image = editProfileVM?.user?.photo != nil ? editProfileVM?.user?.photo?.base64ToImage() : #imageLiteral(resourceName: "ic_default_img_profile.png")
        userImageView.round()
        self.userImageView.deactivateRTL()
    }

    // todo (generelize this)
    func showUploadImage() {

        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()

        let uploadImageView = UploadImageView(frame: CGRect(x: 0, y: 0, width: 327.adjusted, height: 250.adjusted))
        uploadImageView.contentView.backgroundColor = .white
        uploadImageView.titleLabel.text = LocalizableShared.selectImage.localized
        // TOrefactor
        uploadImageView.didChooseAnImage = {image in
            uploadImageView.stackView.isHidden = true
            self.dismiss(animated: false, completion: {
                showActivityIndicator()
            })

            self.editProfileVM?.photo = image.toBase64()
            self.editProfileVM?.updatePhoto()
        }

        popUpViewControler.contentView = uploadImageView
        popUpViewControler.dismissWhenTappingOutside = true
        PopupView.show(popUpViewControler, on: self)
    }
    private func reloadViews() {
        let areasView = stackView.getWqDropDownViewFor(.dropDown())
        areasView?.dataArray = editProfileVM?.areasListStrings
        areasView?.defaultValueDropDownMenu = languageIsArabic ? editProfileVM?.user?.area?.titleAR
        : editProfileVM?.user?.area?.title
    }

    func setUpBindings() {
        func bindViewModelState() {
            showActivityIndicator()
            editProfileVM?.getAreas()
            let stateHandler: ((EditProfileViewModelState) -> Void) = { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading: self.backToRoot()
                case .error(let error) :   self.showErrorAlertView(descriptionMessage: error.message)
                case .loading: self.reloadViews()
                case .finishCheckingQID:
                    self.showSendPincodePhoneController(phone: self.editProfileVM?.userVM.mobile ?? "",
                                                   strategy: UpdateUserPhoneStrategy())
                }
            }
            self.editProfileVM?.editProfileState
                .sink(receiveValue: stateHandler)
                .store(in: &cancellable)
        }

        func bindImageState() {
            let stateHandler: ((ListViewModelState) -> Void) = { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading:
                    self.userImageView.image = self.editProfileVM?.photo.base64ToImage()
                    self.showSuccessAlertView(message: LocalizedAccount.successUpdateImage.localized) {
                        AppRouter.shared.reloadUserPhoto()
                    }
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message)
                default: break

                }
            }

            self.editProfileVM?.imageState
                .sink(receiveValue: stateHandler)
                .store(in: &cancellable)

        }
        bindViewModelState()
        bindImageState()

    }
    func initStackView() {
        editProfileVM?.editProfileElements.forEach({
            let textfieldView: CommonInputFieldView?
            switch $0.inputFieldType {
            case .dropDown:
                textfieldView = WQDropDownMenu()
                textfieldView?.title = $0.title
                textfieldView?.fieldType = $0.type
                textfieldView?.dataArray = $0.dataArray
                guard let dropMenuView = (textfieldView as? WQDropDownMenu) else {return}
                dropMenuView.shouldSelectFirstItem = true
                dropMenuView.defaultValueDropDownMenu = $0.value ?? ""
                dropMenuView.$selectedText
                    .assign(to: $0.published, on: editProfileVM!)
                    .store(in: &cancellable)
                stackView.addArrangedSubview(textfieldView!)
            default:
                textfieldView = $0.inputFieldType == .textfield ? WQTextFieldView() : WQTextView()
                textfieldView?.title = $0.title
                textfieldView?.value =  $0.value
                textfieldView?.fieldType = $0.type
                textfieldView?.hintLabel.isHidden = true
                textfieldView?.placeholder = ""
                switch $0.type {
                case .dateOfBirth :
                    (textfieldView as? WQTextFieldView)?.defaultValueDatePicker = $0.value?.getDate("dd-MM-yyyy",isNeededTimeZone: true)
                    (textfieldView as? WQTextFieldView)?.$pickerSelectedText
                        .assign(to: $0.published, on: editProfileVM!)
                        .store(in: &cancellable)
                    textfieldView?.textPublisher?.assign(to: $0.published, on: editProfileVM!).store(in: &cancellable)
                    stackView.addArrangedSubview(textfieldView!)
                default:
                    textfieldView?.textPublisher?.assign(to: $0.published, on: editProfileVM!).store(in: &cancellable)
                    stackView.addArrangedSubview(textfieldView!)
                }

            }
        })
        initViews()
    }

    func showSendPincodeEmailController(email: String, strategy: OTPStrategyProtocol?) {
        SendPincodeViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification, completion: {  (viewC) in
            if let viewC = viewC as? SendPincodeViewController {
                viewC.strategy = strategy
                viewC.viewModel.email = email
            }
        })
    }
    func showSendPincodePhoneController(phone: String, strategy: OTPStrategyProtocol?) {
        SendPincodeViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.authentification, completion: {  (viewC) in
            if let viewC = viewC as? SendPincodeViewController {
                viewC.strategy = strategy
                viewC.viewModel.phone = phone
            }
        })
    }

    func initViews() {
        editEmailTextField.title = LocalizedAccount.editEmail.localized + "*"
        editEmailTextField.value = editProfileVM?.user?.email
        editEmailTextField.fieldType = .email
        editEmailTextField.textField.textPublisher.assign(to: editProfileVM!.emailKeyPath,
                                                          on: editProfileVM!).store(in: &cancellable)
        editMobileNumberTextField.title = LocalizedAccount.editMobileNumber.localized + "*"
        editMobileNumberTextField.value = editProfileVM?.user?.mobileNumber
        editMobileNumberTextField.fieldType = .mobileNumber
        editMobileNumberTextField.textField.textPublisher.assign(to: editProfileVM!.mobileKeyPath,
                                                                 on: editProfileVM!).store(in: &cancellable)
        editEmailButton.title = LocalizableShared.save.localized.uppercased()
        editMobileNumberButton.title = LocalizableShared.save.localized.uppercased()
    }

    @IBAction func saveAction(_ sender: Any) {
        var validationTextFieldsArray: [Bool] = []
        stackView.arrangedSubviews.forEach {
            if let value = $0 as? CommonInputFieldView {
                validationTextFieldsArray.append(value.isValid)
            }
        }
        if validationTextFieldsArray.allSatisfy({ $0 == true}) {
            if self.editProfileVM?.didUpdateUser ?? false {
                showActivityIndicator()
                editProfileVM?.submitAction()
            } else {
                self.showErrorAlertView(
                    descriptionMessage: LocalizedAccount.editProfileNoChanges.localized,
                    errorImage: UIImage(named: "ic_warning_close"))
            }
        }
    }

    @IBAction func editImageAction(_ sender: Any) {
        showUploadImage()
    }

    @IBAction func updateUserEmailAction(_ sender: Any) {
        if editEmailTextField.isValid {
            if editProfileVM?.userVM.email != editProfileVM?.user?.email {
                showSendPincodeEmailController(email: self.editProfileVM?.userVM.email ?? "" ,
                                               strategy: UpdateUserEmailStrategy())
            } else {
                self.showErrorAlertView(
                    descriptionMessage: LocalizedAccount.editProfileNoChanges.localized,
                    errorImage: UIImage(named: "ic_warning_close"))
            }
        }
    }

    @IBAction func updateUserPhoneAction(_ sender: Any) {
        if editMobileNumberTextField.isValid {
            if editProfileVM?.userVM.mobile != editProfileVM?.user?.mobileNumber {
                self.editProfileVM?.checkUserQIDandMobile()
            } else {
                self.showErrorAlertView(
                    descriptionMessage: LocalizedAccount.editProfileNoChanges.localized,
                    errorImage: UIImage(named: "ic_warning_close"))
            }
        }
    }
}
