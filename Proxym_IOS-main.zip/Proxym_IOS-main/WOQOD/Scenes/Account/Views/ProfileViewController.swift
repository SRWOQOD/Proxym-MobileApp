//
//  ProfileViewController.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class ProfileViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var editButton: WQButton!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var editEmailTextField: WQItemContent!
    @IBOutlet weak var editMobileNumberTextField: WQItemContent!

    var profileVM = EditProfileViewModel()
    var cancellable = Set<AnyCancellable>()


    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        initUI()
        initUserPhoto()
    }

    // MARK: - Private Methods

    private func initUserPhoto() {
        self.userImageView.image = profileVM.user?.photo != nil ? profileVM.user?.photo?.base64ToImage() : #imageLiteral(resourceName: "ic_default_img_profile.png")
        userImageView.round()
    }

    func initUI() {
        self.setUpNavigationItem()
        headerView.menuAction = presentMenu
        profileView.border(borderColor: UIColor.white, borderwidth: 1)
        profileView.roundTopCorners(radius: 15)
        titleLabel.setText(text: LocalizedAccount.menuPersonalInformation.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue,
                           align: languageIsEnglish ? .left : .right)

        editButton.backgroundColor = .wqBlue
        editButton.title = LocalizableShared.edit.localized.uppercased()
        initStackView()
    }
    func initStackView() {
        stackView.removeAllArrangedSubviews()

        profileVM.profileElements.forEach({
            let itemContent = WQItemContent()
            itemContent.title = $0.title
            itemContent.value = $0.value
            if $0.value == "" && $0.title == LocalizableShared.address.localized {
                itemContent.containerViewHeightConstraint.constant = 80
            }
            stackView.addArrangedSubview(itemContent)

        })
        editEmailTextField.title = LocalizableShared.email.localized
        editEmailTextField.value = profileVM.user?.email ?? ""
        editMobileNumberTextField.title = LocalizableShared.mobileNumber.localized
        editMobileNumberTextField.value = profileVM.user?.mobileNumber ?? ""

    }
    
    
    @IBAction func editAction(_ sender: Any) {
        profileVM.userVM = UserViewModel(user: AuthManager.shared.currentUser)
        AuthenticationRouter.shared.showEditProfileViewController(editVM: profileVM)
    }
}
