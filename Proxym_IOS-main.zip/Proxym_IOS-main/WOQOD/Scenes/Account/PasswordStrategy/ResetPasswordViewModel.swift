//
//  ResetPasswordViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 10/21/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class ResetPasswordViewModel: ViewModel {

    var password = ""
    var connectionType: String = ""
    var username: String = ""

    override init() {
        super.init()
    }

    func resetPassword() {

        let state: StateHandler = { (result) in

            switch result {

            case .finished: self.state.send(.finishedLoading)

            case .failure(let error):
                let err = error as? WQError
                self.state.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in}

        UserAPIManager.resetPassword(username: user?.userName ?? "", password: self.password)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

    func recoverPassword() {

        let state: StateHandler = { (result) in

            switch result {

            case .finished: self.state.send(.finishedLoading)

            case .failure(let error):
                let err = error as? WQError
                self.state.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in }

        RegisterApiManager.recoverPassword(username: username, connectionType: connectionType, newpassword: password)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)

    }

    func resetBioPin() {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: self.state.send(.finishedLoading)
            case .failure(let error):
                let err = error as? WQError
                self.state.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }

        let receivedValue: ReceivedValue < Bool, Bool > = {(_, _) in }

        BioAPIManager.recoverBioPin(bioPin: password)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }

}
