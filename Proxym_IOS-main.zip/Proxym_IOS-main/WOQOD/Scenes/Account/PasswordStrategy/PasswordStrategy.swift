//
//  PasswordStrategy.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 06/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

protocol PasswordStrategyProtocol {
    var username: String { get set }
    var connectionType: String { get set }
    var titleText: String { get set }
    var alertTitle: String { get set }

    var firstTFTitle: String { get set }
    var firstTFPlaceholder: String { get set }
    var secondTFTitle: String { get set }
    var secondTFPlaceholder: String { get set }
}

// Forget Password from login
class RecoverPasswordStrategy: PasswordStrategyProtocol {

    var titleText: String = LocalizedAuthentication.forgetPasswordTitle.localized
    var username: String = ""
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
    var alertTitle: String  = LocalizedAccount.successResetPassword.localized
    var firstTFTitle = LocalizedAccount.newPassword.localized + "*"
    var firstTFPlaceholder = LocalizableShared.password.localized
    var secondTFTitle: String = LocalizableShared.confirmPassword.localized + "*"
    var secondTFPlaceholder = LocalizedAccount.confirmPassword.localized
}

// Reset Password from Account
class ResetPasswordStrategy: PasswordStrategyProtocol {

    var titleText: String = LocalizedAccount.menuResetPassword.localized
    var username: String = ""
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
    var alertTitle: String  = LocalizedAccount.successResetPassword.localized
    var firstTFTitle = LocalizedAccount.newPassword.localized + "*"
    var firstTFPlaceholder = LocalizableShared.password.localized
    var secondTFTitle: String = LocalizableShared.confirmPassword.localized + "*"
    var secondTFPlaceholder = LocalizedAccount.confirmPassword.localized
}

class RecoverBioPinStrategy: PasswordStrategyProtocol {

    var titleText: String = LocalizedAuthentication.recoverBioPinTitle.localized
    var username: String = pwdInKeyChain ?? ""
    var connectionType: String = LoginTypeKeys.usernameAuth.rawValue
    var alertTitle: String  = LocalizedAccount.successResetPassword.localized
    var firstTFTitle = LocalizedAuthentication.newBioPin.localized
    var firstTFPlaceholder = LocalizedAuthentication.bioPin.localized
    var secondTFTitle: String = LocalizableShared.confirmPassword.localized
    var secondTFPlaceholder = LocalizedAuthentication.confirmBioPin.localized
}
