//
//  ResetPasswordViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/21/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class ResetPasswordViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var newPassTFV: WQTextFieldView!
    @IBOutlet weak var confirmPassTFV: WQTextFieldView!
    @IBOutlet weak var submitButton: WQButton!
    @IBOutlet weak var resetPasswordView: UIView!
    @IBOutlet weak var headerView: WQHeaderView!

    // MARK: - Properties
    var viewModel = ResetPasswordViewModel()
    var cancellable = Set<AnyCancellable>()
    var strategy: PasswordStrategyProtocol?

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()

        initUI()
        bindData()

    }
    // MARK: - Private methods
    private func clearFields() {
        confirmPassTFV.textField.text = ""
        newPassTFV.textField.text = ""
    }
    private func bindData() {

        self.viewModel.state.sink { (state) in
            hideActivityIndicator()

            switch state {
            case .finishedLoading : self.successResetPassword()
            case .error(let error) : self.showErrorAlertView(descriptionMessage: error.message)
            case .loading:break
            }
        }
        .store(in: &cancellable)

    }

    private func successResetPassword() {
        self.showSuccessAlertView(message: strategy?.alertTitle) {
            self.clearFields()

            switch self.strategy {
            case is RecoverBioPinStrategy:
                AuthenticationRouter.shared.showPinCodeViewController()
            default:
                self.goHome()
            }
        }
    }

    func goHome() {
        self.popToRootViewController()
        AppRouter.shared.reloadMenuView()
    }

    private func initUI() {
        self.setUpNavigationItem()
        titleLabel.setText(text: strategy?.titleText.uppercased(),
                                   font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue,
                                   align: languageIsEnglish ? .left : .right)
        submitButton.title = LocalizableShared.submit.localized.uppercased()
        submitButton.backgroundColor = UIColor.wqBlue
        resetPasswordView.border(borderColor: UIColor.white, borderwidth: 1)
        resetPasswordView.roundTopCorners(radius: 15)
        initStrategy()
        initTFV()
    }

    func initStrategy() {
        viewModel.connectionType = strategy?.connectionType ?? ""
        viewModel.username = strategy?.username ?? ""
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = handleBackAction
    }

    private func handleBackAction () {
        switch strategy {
        case is ResetPasswordStrategy :
            return goHome()
        default :
            return self.popToRootViewController()
        }
    }

    // Init TextfieldViews
    private func initTFV() {
        // New password TFV
        newPassTFV.title = strategy?.firstTFTitle
        newPassTFV.placeholder = ""
        newPassTFV.titleColor = .wqBlue
        newPassTFV.hint = LocalizableShared.passwordNotValid.localized
        newPassTFV.hintLabel.textColor = UIColor.wqlightBlue
        newPassTFV.fieldType = strategy is RecoverBioPinStrategy ? .bioPin : .password
        // Confirm password TFV
        confirmPassTFV.fieldType = .confirmPassword
        confirmPassTFV.title = strategy?.secondTFTitle
        confirmPassTFV.placeholder = ""
        confirmPassTFV.textField.isSecureTextEntry = true
        confirmPassTFV.hint = nil
        // Assign value to password
        confirmPassTFV.textPublisher?.assign(to: \.password, on: viewModel).store(in: &cancellable)
    }

    private func managePassword() {

        switch strategy {

        case is ResetPasswordStrategy: viewModel.resetPassword()

        case is RecoverPasswordStrategy: viewModel.recoverPassword()

        case is RecoverBioPinStrategy: viewModel.resetBioPin()

        default: break

        }
    }

    @IBAction func submitAction(_ sender: Any) {
        newPassTFV.value = newPassTFV.value?.trimmingCharacters(in: .whitespaces)
        confirmPassTFV.value = confirmPassTFV.value?.trimmingCharacters(in: .whitespaces)
        let validPass = newPassTFV.isValid
        let validConfirmPAss = confirmPassTFV.isValid
        if validPass && validConfirmPAss {

            if confirmPassTFV.value == newPassTFV.value {
                showActivityIndicator()
                managePassword()
            } else {
                confirmPassTFV.errorText = LocalizedAccount.passDontMatch.localized
            }
        }
    }
}
