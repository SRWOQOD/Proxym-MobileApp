//
//  LocalizableAccount.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/21/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum LocalizedAccount: String, LocalizableDelegate {

    /* Menu account */

    case accountTitle = "AccountTitle"
    case menuPersonalInformation = "AccountMenuPersonalInformation"
    case menuResetPassword = "AccountMenuResetPassword"

    /* Menu account */

    case editEmail = "EditProfileEditEmailTitle"
    case editMobileNumber = "EditProfileEditMobileNumberTitle"

    /* Reset Password */

    case securityCode = "AccountResetPasswordSecurityCode"
    case enterSecurityCode = "AccountResetPasswordEnterSecurityCode"
    case retrySecurityCode = "AccountResetPasswordRetrySecurityCode"
    case newPassword = "AccountResetPasswordNewPassword"
    case password = "AccountResetPasswordPassword"
    case confirmPassword = "AccountResetPasswordConfirmPassword"
    case pinCodeDialogTitle = "AccountResetPasswordPinCodeDialogTitle"
    case pinCodeDialogMessage = "AccountResetPasswordPinCodeDialogMessage"
    case detailsEditProfile = "AccountAccountDetailsEditProfile"
    case personalInformation = "AccountAccountPersonalInformation"
    case resetPassword = "AccountAccountResetPassword"
    case passDontMatch = "AccountPasswordDontMatch"
    case confirmPasswordEmpty = "AccountConfirmPasswordEmptyMsg"
    case successResetPassword = "AccountSuccessResetPasswordMsg"
    case successUpdate = "AccountUserUpdateSuccessMsg"
    case successEmailUpdate = "AccountUserUpdateEmailSuccessMsg"
    case successPhoneUpdate = "AccountUserUpdatePhoneSuccessMsg"
    case editProfileNoChanges = "AccountUserUpdateConfirmation"
    case successUpdateImage = "AccountUserUpdateProfilePicMsg"
    
    var tableName: String? {
        return "Account"
    }

}
