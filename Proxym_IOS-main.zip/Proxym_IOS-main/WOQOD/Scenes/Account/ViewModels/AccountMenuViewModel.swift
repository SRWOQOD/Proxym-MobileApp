//
//  AccountMenuViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 10/13/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class AccountMenuViewModel: ViewModel {

    var menuItems: [SubMenuItemViewModel] = []

    override init() {
        super.init()
        initAccountMenuItems()
    }

    /// Init fahes sub menu items
    func initAccountMenuItems() {

        let profileMenuItem = SubMenuItemViewModel.init(title: LocalizedAccount.menuPersonalInformation.localized,
                                                        image: #imageLiteral(resourceName: "ic_personal_information.png"),
                                                        viewControllerType: ProfileViewController.self,
                                                        storyboard: AppStoryboard.account)

        let sendPincodeViewController =
            SendPincodeViewController.instantiate(appStoryboardName: AppStoryboard.authentification)
            as? SendPincodeViewController ?? SendPincodeViewController()
        sendPincodeViewController.strategy = AccountResetPasswordStrategy()

        menuItems = [
            profileMenuItem,
            SubMenuItemViewModel.init(title: LocalizedAccount.resetPassword.localized,
                                      image: #imageLiteral(resourceName: "ic_reset_pass.png"), viewController: sendPincodeViewController)
          ]

    }

}
