//
//  EditProfileViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

struct  EditProfileElement {
    var inputFieldType: InputFieldType = .textfield
    var type: FieldType
    var title: String?
    var placeholder: String?
    var published: EditProfileKeyPath
    var value: String?
    var dataArray: [String]?
}

enum EditProfileViewModelState {
    case finishCheckingQID
    case finishedLoading
    case loading
    case error(WQError)
}

typealias EditProfileKeyPath = ReferenceWritableKeyPath<EditProfileViewModel, String>

class EditProfileViewModel: ViewModel {

    var profileElements: [ItemContentModel] {
        return [
            ItemContentModel(title: LocalizableShared.name.localized, value: user?.firstName ?? ""),
            ItemContentModel(title: LocalizableShared.familyName.localized, value: user?.familyName ?? ""),
//            ItemContentModel(title: LocalizableShared.mobileNumber.localized, value: user?.mobileNumber ?? ""),
//            ItemContentModel(title: LocalizableShared.email.localized, value: user?.email ?? ""),
            ItemContentModel(title: LocalizableShared.address.localized, value: user?.address ?? ""),
            ItemContentModel(title: LocalizableShared.poBox.localized, value: user?.poBox ?? ""),
            ItemContentModel(title: LocalizableShared.dateOfBirth.localized,
                             value: user?.birthdate?.getDateFromInt64ServerTime("yyyy-MM-dd HH:mm:ssZ").toLongString() ?? ""),
            ItemContentModel(title: LocalizableShared.areaOfResidence.localized,
                             value: languageIsArabic ? user?.area?.titleAR ?? ""
                                : user?.area?.title ?? "")
        ]
    }

    var photo = ""
    var email: String = AuthManager.shared.currentUser?.email ?? ""
    var phone: String = AuthManager.shared.currentUser?.mobileNumber ?? ""
    var userVM = UserViewModel()
    var imageState = PassthroughSubject<ListViewModelState, Never>()
    var editProfileState = PassthroughSubject<EditProfileViewModelState, Never>()
    private var areasList: [Area] = []
    var areasListStrings: [String] {
        return areasList.map({(languageIsArabic ? $0.titleAR ?? "" : $0.title ?? "")})
    }
    let mobileKeyPath: EditProfileKeyPath = \.userVM.mobile
    let emailKeyPath: EditProfileKeyPath = \.userVM.email
    var  editProfileElements : [ EditProfileElement ] {
        let firstNameKeyPath: EditProfileKeyPath = \.userVM.firstName
        let familyNameKeyPath: EditProfileKeyPath = \.userVM.familyName
        let addressKeyPath: EditProfileKeyPath = \.userVM.address
        let poBoxKeyPath: EditProfileKeyPath = \.userVM.poBox
        let birthdateKeyPath: EditProfileKeyPath = \.userVM.birthdate
        let areaKeyPath: EditProfileKeyPath = \.userVM.idArea
        return [
            EditProfileElement(type: .name, title: LocalizableShared.name.localized + "*",
                               published: firstNameKeyPath, value: userVM.firstName),
            EditProfileElement(type: .familyName, title: LocalizableShared.familyName.localized + "*",
                               published: familyNameKeyPath, value: userVM.familyName),
            EditProfileElement(inputFieldType: .textview, type: .address, title: LocalizableShared.address.localized,
                               published: addressKeyPath, value: userVM.address),
            EditProfileElement(type: .poBox, title: LocalizableShared.poBox.localized,
                               published: poBoxKeyPath, value: userVM.poBox),
            EditProfileElement(type: .dateOfBirth, title: LocalizableShared.dateOfBirth.localized + "*",
                               published: birthdateKeyPath, value: userVM.birthdate),
            EditProfileElement(inputFieldType: .dropDown, type: .dropDown(),
                               title: LocalizableShared.areaOfResidence.localized + "*",
                               published: areaKeyPath, value: languageIsArabic
                                ? userVM.area.titleAR : userVM.area.title,
                               dataArray: areasListStrings)
        ]
    }

    var didUpdateUser: Bool { return
        self.userVM.qid != self.user?.qid ||
        self.userVM.firstName != self.user?.firstName ||
        self.userVM.familyName != self.user?.familyName ||
        self.userVM.birthdate != "" ||
        self.userVM.address != self.user?.address ||
        self.userVM.poBox != self.user?.poBox ||
        self.userVM.idArea != (languageIsArabic ? self.user?.area?.titleAR : self.user?.area?.title)
    }

    func getAreas() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                let err = error as? WQError
                self.editProfileState.send(.error(err ?? WQError()))
            case .finished :
                self.editProfileState.send(.loading)
            }
        }
        let resultHandler: (([AreaDTO], [Area]) -> Void ) = { (_, areas) in
            self.areasList = areas
        }
        UserAPIManager.getAreas()
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    /// This func is used to get the id of area that user has selected from the dropDown
    func getIdArea() {
        userVM.area=areasList.filter({ languageIsArabic
                                        ? $0.titleAR == userVM.idArea
                                        : $0.title == userVM.idArea }).first ?? Area()
    }

    func checkEmail() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                self.editProfileState.send(.error(error as? WQError ?? WQError()))
            case .finished : self.updateUser() // Update user if email is valid
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in  }
        RegisterApiManager.checkUser(email: userVM.newUser.email ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    /// This func is used to check qid and mobile validity
    func checkUserQIDandMobile() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                self.editProfileState.send(.error(error as? WQError ?? WQError()))
            case .finished :
                self.editProfileState.send(.finishCheckingQID)
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in  }
        RegisterApiManager.checkQidMobileValidity(qid: user?.qid ?? "", mobile: userVM.newUser.mobileNumber  ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    func checkMobile() {
        let stateHandler: StateHandler = { (completion) in
            switch completion {
            case .failure(let error):
                self.editProfileState.send(.error(error as? WQError ?? WQError()))
            case .finished :
                // We need to check if the mobile number matches the owner of the QID
                self.checkUserQIDandMobile()
            }
        }
        let resultHandler: ((Bool, Bool) -> Void ) = { (_, _) in  }
        RegisterApiManager.checkUser(mobile: userVM.newUser.mobileNumber ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    func updateUser() {
        getIdArea()
        let stateHandler: StateHandler = { (result) in
            switch result {
            case .finished:
                self.editProfileState.send(.finishedLoading)
            case .failure(let error):
                self.editProfileState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let resultHandler: ((UserDTO, User) -> Void ) = { (_, user) in
            // In this case we have to get the last value of the image
            self.photo = AuthManager.shared.photo ?? ""
            AuthManager.shared.currentUser = user
            // And then we have to reset it to the current image value
            AuthManager.shared.photo = (self.photo != "" ) ?  self.photo  : nil
        }
        UserAPIManager.upateUser(user: userVM.newUser)
            .sink(receiveCompletion: stateHandler, receiveValue: resultHandler)
            .store(in: &cancellable)
    }

    func updatePhoto() {
        let state: StateHandler = { (result) in
            switch result {
            case .finished: self.imageState.send(.finishedLoading)
            case .failure(let error):
                let err = error as? WQError
                self.imageState.send(.error(err ?? WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        let resultHandler: ((UserDTO, User) -> Void ) = { (_, user) in
            AuthManager.shared.currentUser = user
            AuthManager.shared.photo = self.photo
        }
        UserAPIManager.resetPhoto(username: user?.userName ?? "", photo: photo)
            .sink(receiveCompletion: state, receiveValue: resultHandler)
            .store(in: &cancellable)
    }
    
    func submitAction() {
        updateUser()
    }
}
