//
//  FahesRouter.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 10/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class FahesRouter {

    static var shared = FahesRouter()

    // Fahes
    func showFahesWith(viewController: UIViewController) {
        FahesMenuViewController.pushViewControllerFor(viewController: viewController)
    }

    // Inspection Report
    func showInspectionDetailskWith(viewController: UIViewController) {
        InspectionDetailsViewController.pushViewControllerFor(viewController: viewController)
    }

    func showFahesReceiptDetailskWith(viewModel: ReceiptViewModel?) {
        ReceiptDetailsViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) { (viewC) in
            if let viewC = viewC as? ReceiptDetailsViewController {
                viewC.receiptItemVM = viewModel
            }
        }
    }

    func showNewInspectionRegister(viewModel: NewInspectionRegisterViewModel?,isFromPayment: Bool = false ) {
        NewInspectionRegisterViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) { (viewC) in
            if let viewC = viewC as? NewInspectionRegisterViewController {
                viewC.registerVM = viewModel
                viewC.isFromPayment = isFromPayment
            }
        }
    }

    func showPaymentViewController(viewModel: FahesPaymentViewModel?) {
        FahesInspectionPayementViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) { (viewC) in
            if let viewC = viewC as? FahesInspectionPayementViewController {
                viewC.viewModel = viewModel
            }
        }
    }

    func openPaymentVC(completion : @escaping((_ viewC: PayementTransactionWebViewController ) -> Void)) {

        PayementTransactionWebViewController
            .pushViewControllerFor(appStoryboardName: AppStoryboard.payment) {(viewC) in
            if let viewC = viewC as? PayementTransactionWebViewController {
                viewC.sourceType = .fahes
                completion(viewC)
            }
        }
    }

    func showCarRegisterVC(viewModel: FahesCarRegisterViewModel? ) {
        FahesCarRegisterViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? FahesCarRegisterViewController {
                viewC.viewModel = viewModel
            }
        }
    }

    func showPincodeScreen(viewModel: FahesCarRegisterViewModel? ) {
        FahesSendPincodeViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? FahesSendPincodeViewController {
                viewC.viewModel = viewModel
            }
        }
    }

    func showBookingFirstViewController(viewModel: FahesCarViewModel?, registerCarVM: NewInspectionRegisterViewModel?) {
        FahesBookingFirstViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? FahesBookingFirstViewController {
                viewC.bookVehicleInspectionViewModel.fahesCarVM = viewModel ?? FahesCarViewModel()
                viewC.registerCarVM = registerCarVM
            }
        }
    }

    func showBookingSecondViewController(viewModel: BookVehicleInspectionViewModel?,
                                         registerCarVM: NewInspectionRegisterViewModel?) {
        FahesBookingSecondViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? FahesBookingSecondViewController {
                viewC.viewModel = viewModel
                viewC.registerCarVM = registerCarVM
            }
        }
    }

    func showFahesReservationOtpVC(viewModel: BookVehicleInspectionViewModel?,
                                   registerCarVM: NewInspectionRegisterViewModel? ) {
        FahesReservationOTPViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? FahesReservationOTPViewController {
                viewC.viewModel = viewModel
                viewC.registerCarVM = registerCarVM

            }
        }

    }

    func showModifyBookingDetailsViewController(bookingModel: FahesBooking?, fahesCar: Car) {
        ModifyBookingDetailsViewController.pushViewControllerFor(appStoryboardName: AppStoryboard.fahes) {(viewC) in
            if let viewC = viewC as? ModifyBookingDetailsViewController {
                viewC.viewModel.bookingModel = bookingModel
                viewC.viewModel.fahesCarVM = FahesCarViewModel(car: fahesCar)
                viewC.guestNewInspectionViewModel.carDetails = fahesCar
                let registerCarVM = NewInspectionRegisterViewModel(preRegistrationFee: nil, car: fahesCar)
                viewC.registerCarVM = registerCarVM

            }
        }
    }
}
