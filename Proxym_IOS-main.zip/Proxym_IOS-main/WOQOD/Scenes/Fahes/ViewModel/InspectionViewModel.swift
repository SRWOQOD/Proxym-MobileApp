//
//  InspectionViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

enum InspectionDetailsViewModelState {
    case finishGettingHistory
    case finishGettingDetails
    case errorGettingInspectionDetails
    case error(WQError)
}

class InspctionViewModel: ViewModel {

    // MARK: - Public properties
    var listCars: [CarViewModel] = [] // listCars

    var inspectionsHistory =  InspectionsHistoryViewModel(inspection: nil)

    var selectedItem: CarViewModel?
    var inspectionDetailsList: [InspectionDetailsViewModel] = []
    var legalInfosList: [InspectionDetailsViewModel] = []
    var technicalInfosList: [InspectionDetailsViewModel] = []
    var commentsList: [InspectionDetailsViewModel] = []
    var numberOfSection: Int = 3
    var inspecDetailsState = PassthroughSubject<InspectionDetailsViewModelState, Never>()
    var sectionsItems: [InspectionDetailsSectionViewModel] = []
    // MARK: - Overrides
    override init() {
        super.init()
        updateSectionsArray()
    }

    /// Get list of cars
    func getListOfCars() {

        let stateHandler: ((Subscribers.Completion<Error>) -> Void) = { (result) in
            switch result {
            case .finished:
                self.state.send(.finishedLoading)
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: ([CarDTO<String>], [Car]) -> Void = { (_, cars) in
            self.listCars = cars.map {
                CarViewModel.init(car: $0)
            }
        }

        FahesAPIManager.getCarsList(qid: user?.qid ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)

    }

    /// Get list of inspections
    func getInspectionsHistory() {

        let stateHandler: ((Subscribers.Completion<Error>) -> Void) = { (result) in
            switch result {
            case .finished:
                break
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: (InspectionsHistoryDTO<String>, InspectionsHistory) -> Void = { (_, inspectHistory) in

            self.inspectionsHistory = InspectionsHistoryViewModel(inspection: inspectHistory)
            self.getInspectionDetails(inspectionId: "\(inspectHistory.inspection ?? 0)")
            // For test
//             self.getInspectionDetails(inspectionId: "20210803120009")
            self.inspecDetailsState.send(.finishGettingHistory)
        }

        let carDetail = Car(plateNumber: selectedItem?.carPlatenumber ?? "",
                            ownerQid: selectedItem?.ownerQid ?? "",
                            plateTypeId: selectedItem?.plateTypeId! ?? 1 )

        FahesAPIManager.getInspectionsHistory(inspection: carDetail)
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

    func getInspectionDetails(inspectionId: String) {

        let stateHandler: ((Subscribers.Completion<Error>) -> Void) = { (result) in
            switch result {
            case .finished:
                break
            case .failure:
                self.setupInspectionDetails()
                self.inspecDetailsState.send(.errorGettingInspectionDetails)
            }
        }

        let receiveValue: ([InspectionDetailsDTO<String>], [InspectionDetails]) -> Void = { (_, listDetails) in
            self.inspectionDetailsList = listDetails.map({
                InspectionDetailsViewModel(detail: $0)
            })
            self.setupInspectionDetails()
            self.inspecDetailsState.send(.finishGettingDetails)
        }

        FahesAPIManager.getInspectionsDetails(inspectionId: inspectionId)
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

    private func setupInspectionDetails() {
        self.getCommentsList()
        self.getLegalInfosList()
        self.getTechnicalInfosList()
        self.updateSectionsArray()
    }

    func getCommentsList() {
        commentsList = inspectionDetailsList.filter {
            ($0.defectType?.id == 3)
        }
        if commentsList.count == 0 {
            commentsList = [
                InspectionDetailsViewModel(
                    detail: InspectionDetails(
                        evaluation: nil, defectComment:
                            DefectComment(code: "0",
                                          name: LocalizableFahes.inspectionDetailsNoComments.localized,
                                          defectSub: nil),
                        location: nil, additionalComment: nil,
                        defectType: nil))
            ]
        }
    }

    func getLegalInfosList() {
        legalInfosList = inspectionDetailsList.filter {
            ($0.defectType?.id == 2)
        }
        if legalInfosList.count == 0 {
            legalInfosList = [
                InspectionDetailsViewModel(
                    detail: InspectionDetails(
                        evaluation: nil, defectComment:
                            DefectComment(code: "0",
                                          name: LocalizableFahes.inspectionDetailsNoDetails.localized,
                                          defectSub: nil),
                        location: nil, additionalComment: nil,
                        defectType: nil))
            ]
        }
    }

    func getTechnicalInfosList() {
        technicalInfosList = inspectionDetailsList.filter {
            ($0.defectType?.id == 1)
        }
        if technicalInfosList.count == 0 {
            technicalInfosList = [
                InspectionDetailsViewModel(
                    detail: InspectionDetails(
                        evaluation: nil, defectComment:
                            DefectComment(code: "0",
                                          name: LocalizableFahes.inspectionDetailsNoDetails.localized,
                                          defectSub: nil),
                        location: nil, additionalComment: nil,
                        defectType: nil))
            ]
        }
    }

    func updateSectionsArray() {
        sectionsItems.removeAll()
        sectionsItems = [
            InspectionDetailsSectionViewModel(
                title: LocalizableFahes.inspectionDetailsLegalInformationsTitle.localized,
                isHidden: true,
                items: legalInfosList),
            InspectionDetailsSectionViewModel(
                title: LocalizableFahes.inspectionDetailsTechnicalInformations.localized,
                isHidden: true,
                items: technicalInfosList),
            InspectionDetailsSectionViewModel(
                title: LocalizableFahes.inspectionDetailscommentsTitle.localized,
                isHidden: true,
                items: commentsList)
        ]
    }

}
