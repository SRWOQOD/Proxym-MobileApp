//
//  InspectionBookingListViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 10/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

enum InspectionBookingModelState {
    case successGetPlateTypes
    case error(WQError)
}

class InspectionBookingListViewModel: ViewModel {

    // MARK: - Public properties
    var listBooking: [InspectionBookingItemViewModel] = [] // bookingList
    var plateTypesArray = [Details]() // Returnes from getPlateTypes API

    // MARK: - Overrides
    override init() {
        super.init()
    }

    func getPlateID(forName name: String) -> Int? {
        return plateTypesArray.filter({ $0.name == name  }).first?.id
    }

    /// Get list of booking
    func getBooking() {

        let stateHandler: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.state.send(.finishedLoading)
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: ([FahesBookingDTO], [FahesBooking]) -> Void = { (_, bookings) in

            self.listBooking = bookings.map({
                InspectionBookingItemViewModel.init(booking: $0)
            })
        }

        ReservationAPIManager.detailsByCustomer(
            qid: (AuthManager.shared.currentUser?.qid) ?? AccountManager.shared.guestQID)
        // Just for test
//        ReservationAPIManager.detailsByCustomer(qid: "27263400979")
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
             .store(in: &cancellable)

    }

    func getPlateTypes() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished: break
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }
        let plateTypesResult: ReceivedValue < [DetailsDTO], [ Details ] > = {(_, platetTypes) in
            self.plateTypesArray = platetTypes
        }

        FahesAPIManager.getPlateTypes()
            .sink(receiveCompletion: state, receiveValue: plateTypesResult)
            .store(in: &cancellable)
    }

}
