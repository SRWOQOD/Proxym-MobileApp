//
//  FahesStationsViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 6/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class FahesStationsViewModel: ViewModel {

    // MARK: - Public properties
    let stationsListDidChange = ObservableObjectPublisher()
    var stationsList: [Place]? {
           didSet {
               stationsListDidChange.send()
           }
       }

    var initialValuesPlaces: [Place] = []
    // MARK: - Private properties
    private var subscriptions = Set<AnyCancellable>()

    // MARK: - Public methods
    func getFahesStations() {
        var list: [Place]? = []
        self.state.send(.loading)

        let stateHandler: StateHandler = { (result) in
            switch result {
            case .finished:
                self.state.send(.finishedLoading)
            case .failure(let error):
                self.state.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: ([FahesStationDTO], [FahesStation]) -> Void = { (_, stations) in
            stations.forEach({ (station) in
                list?.append( Place(id: station.id, stationId: station.fahesId,
                                        title: station.title,
                                        titleAR: station.titleAR,
                                        address: station.address,
                                        addressAR: station.addressAR,
                                        secondAddress: station.secondAddress,
                                        secondAddressAR: station.secondAddressAR,
                                        phone: station.phone,
                                        latitude: station.latitude,
                                        longitude: station.longitude,
                                        workingDays: station.workingDays,
                                        workingDaysAR: station.workingDaysAR,
                                        serviceStations: station.serviceStations,
                                        icon: station.icon,
                                        status: station.status,
                                        area: station.area))
            })
            self.stationsList = list?.removeDuplicates()
            self.initialValuesPlaces = list ?? []
        }

        FahesAPIManager.getFahesStationss()
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &subscriptions)
    }

    func resetStationss() {
        stationsList = LocationsManager.shared.filtredLocations?.removeDuplicates()
    }

}
