//
//  InspectionBookingItemViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 11/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

class InspectionBookingItemViewModel: RowViewModel {

    var booking: FahesBooking?
    init(booking: FahesBooking ) {
        self.booking = booking
    }

    // Those elements to display Car details
    var bookingElements: [ItemContentModel] {
        return [
            ItemContentModel(title: LocalizableShared.station.localized + ":",
                             value: self.booking?.station ?? "" ),
            ItemContentModel(title: LocalizableShared.carPlate.localized + ":",
                             value: self.booking?.plateNumber ?? "" ),
            ItemContentModel(title: LocalizableShared.plateType.localized + ":",
                             value: self.booking?.plateTypeName ?? "")
        ]
    }
}
