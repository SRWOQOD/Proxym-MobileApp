//
//  ListOfReceiptsViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

enum ReceiptsState {
    case finishFetchingList
    case finishFetchingPDF
    case error(WQError)
}
enum PaymentStatus: String {
    case paid = "PAID"
    case canceled = "CANCELED"
    case failed = "FAILED"
    case paied = "PAIED"
}

class ListOfReceiptsViewModel: ViewModel {

    // MARK: - Public properties
    var allReceipts: [ReceiptViewModel] = [] // all received receipts
    var receiptsState = PassthroughSubject<ReceiptsState, Never>()
    var receiptPDF: String = ""
    var receiptNumber: String = ""
    // MARK: - Overrides
    override init() {
        super.init()
    }

    /// Get list of receipts
    func getReceipts() {

        let stateHandler: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.receiptsState.send(.finishFetchingList)
            case .failure(let error):
                self.receiptsState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: ([ReceiptDTO<String>], [Receipt]) -> Void = { (_, receipts) in
            self.allReceipts = receipts.map({
                ReceiptViewModel.init(receipt: $0)
            }).filter({$0.payStatus == PaymentStatus.paid.rawValue || $0.payStatus == PaymentStatus.paied.rawValue})
            self.allReceipts = self.allReceipts.sorted{ $0.creationDate > $1.creationDate }
        }
        FahesAPIManager.getListReceipts(qid: (AuthManager.shared.currentUser?.qid) ?? "")
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
             .store(in: &cancellable)

    }

    func getReceiptPDF(receiptVM: ReceiptViewModel) {

        let state: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.receiptsState.send(.finishFetchingPDF)
            case .failure(let error):
                self.receiptsState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let receiveValue: (String, String) -> Void = { (_, pdf) in
            #if DEBUG
            print("Pdfffff ", pdf)
            #endif
            self.receiptPDF = pdf
        }

        let receiptRef = receiptVM.receiptNumber
        FahesAPIManager.getReceiptPDF(reference: receiptRef)
            .sink(receiveCompletion: state, receiveValue: receiveValue)
             .store(in: &cancellable)

    }

}
