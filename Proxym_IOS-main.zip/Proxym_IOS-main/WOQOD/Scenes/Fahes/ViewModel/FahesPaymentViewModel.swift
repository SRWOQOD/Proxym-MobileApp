//
//  FahesPaymentViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 11/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Combine
import Foundation
enum FahesPaymentState {
    case finishFetchingData
    case finishFreeCar
    case finishCollectingWebViewData
    case failedCollectingWebViewData
    case finishGettingStaticText
    case error(WQError)
}

class FahesPaymentViewModel: ViewModel {
    var fahesPaymentState = PassthroughSubject<FahesPaymentState, Never>()

    var preRegistrationFee: PreRegistrationFee?
    var car: Car?
    // This is used when user is not logged in
    var guestQID: String? {
        return AccountManager.shared.guestQID
    }
    var guestMobile: String? {
        return AccountManager.shared.guestMobile
    }
    var guestEmail: String? {
        return AccountManager.shared.guestEmail
    }

    var secretKeyParam: String?
    var debitCardHidden = true
    @Published var signatureValue: String?
    var fahesPaymenttaticText: String?
    let staticScreenType = StaticScreenType.fahesPaymentTermsOfUse.rawValue
    var fahesTransactionUUidModel: FahesTransactionUUIDModel?
    var fahesTransactionPUNModel: FahesTransactionPUNModel?
    var signedDate = ""
    var paymentType: PaymentType?
    var receiptViewModel = ReceiptViewModel() // This will be generated when fee is 0
    func createTransation() {
        paymentRequestModel = PaymentRequestModel(amount: "\(preRegistrationFee?.totalAmount ?? 0)",
                                                  transactionUUID: fahesTransactionUUidModel?.transactionUUID,
                                                  referenceNumber: fahesTransactionUUidModel?.referenceNumber )

        self.fahesTransactionUUidModel =
            FahesTransactionUUIDModel(userID: (userIsConnected ? car?.ownerFullname ?? "" : guestQID) ?? "",
                                      qid: car?.ownerQid ?? "",
                                      mobile: car?.ownerMobile ?? "",
                                      email: car?.ownerEmail ?? "",
                                      amount: "\(preRegistrationFee?.totalAmount ?? 0)",
                                      inspectionType: "\(preRegistrationFee?.inspectionType ?? 0)",
                                      serviceCategory: preRegistrationFee?.serviceCategory ?? "",
                                      categoryId: preRegistrationFee?.categoryId ?? 0,
                                      categoryNameEn: preRegistrationFee?.categoryNameEn ?? "",
                                      categoryNameAr: preRegistrationFee?.categoryNameAr ?? "",
                                      categoryFee: preRegistrationFee?.categoryFee ?? 0,
                                      plateNumber: car?.plateNumber ?? "",
                                      plateType: car?.plateTypeId ?? 0 ,
                                      referenceNumber: AuthManager.shared.serverDate?.dateTimeStamp ?? "" ,
                                      anonym: !userIsConnected)
    }
    func createQpayTransaction() {
        qpayRequestModel = QPayParamsRequestModel(name: PaymentSignatureTypes.fahes.rawValue,
                                                  amount: "\((Int(preRegistrationFee?.totalAmount ?? 0) * 100))",
                                                  pun: self.fahesTransactionPUNModel?.pun)
        self.fahesTransactionPUNModel =
        FahesTransactionPUNModel(userID: (userIsConnected ? car?.ownerFullname ?? "" : guestQID) ?? "",
                                 qid: car?.ownerQid ?? "",
                                 mobile: car?.ownerMobile ?? "",
                                 email: car?.ownerEmail ?? "",
                                 amount: "\(Int(preRegistrationFee?.totalAmount ?? 0))",
                                 inspectionType: "\(preRegistrationFee?.inspectionType ?? 0)",
                                 serviceCategory: preRegistrationFee?.serviceCategory ?? "",
                                 categoryId: preRegistrationFee?.categoryId ?? 0,
                                 categoryNameEn: preRegistrationFee?.categoryNameEn ?? "",
                                 categoryNameAr: preRegistrationFee?.categoryNameAr ?? "",
                                 categoryFee: preRegistrationFee?.categoryFee ?? 0,
                                 plateNumber: car?.plateNumber ?? "",
                                 plateType: car?.plateTypeId ?? 0,
                                 currency: paymentResponseModel?.currencyCode ?? "",
                                 anonym: !userIsConnected)
    }


    var paymentRequestModel = PaymentRequestModel(amount: "", transactionUUID: "", referenceNumber: "")
    var qpayRequestModel = QPayParamsRequestModel()
    var refererUrl: String?
    var qpayURL: String?
    var paymentResponseModel: QPayParamsResponseModel?
    init(preRegistrationFee: PreRegistrationFee?, car: Car?) {
        self.preRegistrationFee = preRegistrationFee
        self.car = car
    }
    
    
    /// Step1 : Get payment params for fahes
    func getSignatureParam() {

        let receivedValue: ReceivedValue<PaymentKeysDTO, PaymentKeys> = { (_, paymentKeys) in
            self.paymentRequestModel.accessKey = paymentKeys.accessKey
            self.paymentRequestModel.profileId = paymentKeys.profileID
            self.secretKeyParam = paymentKeys.secretKey
            self.getSignature()
        }

        let state: StateHandler = { completion in
            switch completion {
            case .finished : break
            case .failure(let error) : self.fahesPaymentState.send(.error(error as? WQError ?? WQError()))
            }
        }

        PaymentAPIManager.getSignatureParam(name: PaymentSignatureTypes.fahes.rawValue)
            .sink(receiveCompletion: state, receiveValue: receivedValue)
            .store(in: &cancellable)
    }
    /// Step 2 : Get payment signature
    func getSignature() {

        let signatureState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                self.fahesPaymentState.send(.error(error as? WQError ?? WQError()))
            }
        }

        let signatureResult: ReceivedValue<SignatureDTO, Signature >  = { (_, signature) in
            guard let value = signature.value else {  return  }
            self.signatureValue = value
            self.paymentRequestModel.transactionUuid = self.fahesTransactionUUidModel?.transactionUUID
            self.createTransactionUUID()
        }

        guard let amount = preRegistrationFee?.totalAmount else { return }
        paymentRequestModel.signedDateTime =  AuthManager.shared.serverDate?.utcDateTime
        self.paymentRequestModel.referenceNumber =  AuthManager.shared.serverDate?.dateTimeStamp ?? ""

        PaymentAPIManager.getSignature(amount: "\(amount)", uuid: fahesTransactionUUidModel?.transactionUUID ?? "",
                                       signedDate: AuthManager.shared.serverDate?.utcDateTime ?? "",
                                       accessKey: self.paymentRequestModel.accessKey ?? "",
                                       profileID: self.paymentRequestModel.profileId ?? "" ,
                                       secretKey: self.secretKeyParam ?? "",
                                       referenceNumber: self.paymentRequestModel.referenceNumber )
            .sink(receiveCompletion: signatureState, receiveValue: signatureResult)
            .store(in: &cancellable)
    }
    /// Step 3 : Create transaction
    func createTransactionUUID() {

        let  stateHandler: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                if let err = error as? WQError {
                    self.fahesPaymentState.send(.error(err ))
                } else {
                    self.fahesPaymentState.send(.error(WQError()))
                }
            }
        }

        // To check when user is not connected
        fahesTransactionUUidModel?.email = (userIsConnected ? user?.email : self.guestEmail) ?? ""
        fahesTransactionUUidModel?.mobile  = (userIsConnected ? user?.mobileNumber : self.guestMobile) ?? ""
        fahesTransactionUUidModel?.qid = (userIsConnected ? user?.qid : self.guestQID) ?? ""

        guard let amount = fahesTransactionUUidModel?.amount else { return }

        fahesTransactionUUidModel?.amount = "\(amount)"
        fahesTransactionUUidModel?.referenceNumber = self.paymentRequestModel.referenceNumber

        let transactionResult: ReceivedValue<Bool, Bool>  = { (_, transactionCreated) in
            if transactionCreated {
                self.paymentRequestModel.amount = amount
                self.fahesPaymentState.send(.finishCollectingWebViewData)
            } else {
                self.fahesPaymentState.send(.failedCollectingWebViewData)
            }
        }

        FahesAPIManager.create(transactionUUID: fahesTransactionUUidModel! )
            .sink(receiveCompletion: stateHandler, receiveValue: transactionResult)
            .store(in: &cancellable)

    }

    /// Step 3 : Create transaction if fee == 0
    func createFreeTransactionUUID() {
        let  stateHandler: StateHandler = { (completion) in
            switch completion {
            case .finished:
               break
            case .failure(let error):
                self.fahesPaymentState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let transactionResult: ReceivedValue<PaymentModelDTO, PaymentModel>  = { (paymentModelDTO, paymentModel) in
            if paymentModelDTO.decision == .paid {
                self.receiptViewModel = ReceiptViewModel(receipturl: paymentModel.receipt,
                                                         receiptNumber: paymentModel.reference)
                self.fahesPaymentState.send(.finishFreeCar)
            }else {
                self.fahesPaymentState.send(.error(WQError(message: paymentModelDTO.response, statusCode: "0", errorId: "0")))
            }

        }

        // To check when user is not connected
        fahesTransactionUUidModel?.email = (userIsConnected ? user?.email : self.guestEmail) ?? ""
        fahesTransactionUUidModel?.mobile  = (userIsConnected ? user?.mobileNumber : self.guestMobile) ?? ""
        fahesTransactionUUidModel?.qid = (userIsConnected ? user?.qid : self.guestQID) ?? ""

        FahesAPIManager.freeCar(transactionUUID: fahesTransactionUUidModel! )
            .sink(receiveCompletion: stateHandler, receiveValue: transactionResult)
            .store(in: &cancellable)
    }

    /*
     Payment Type card WS
     */
    
    func submit(paymentType: PaymentType) {
        self.paymentType = paymentType
        self.getCurrentDate()
    }
    
    /// Step 1 : Get payment params
    func getQpayParams() {
        let signatureState: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                self.fahesPaymentState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let signatureResult: ReceivedValue<QPayParamsResponseDTO, QPayParamsResponseModel >  = { (_, params) in
            self.paymentResponseModel = QPayParamsResponseModel(action: params.action, amount: "\(params.amount ?? "0")", lang: params.lang, merchantModuleSessionID: params.merchantModuleSessionID, pun: params.pun, paymentDescription: params.paymentDescription, quantity: params.quantity, transactionRequestDate: params.transactionRequestDate, bankID: params.bankID, currencyCode: params.currencyCode, merchantID: params.merchantID, secureHash: params.secureHash, extraFields_f14: params.extraFields_f14)
            self.qpayURL = params.redirectUrl ?? ""
            self.refererUrl = params.referer ?? ""
            self.fahesTransactionPUNModel?.currency = params.currencyCode ?? ""
            self.createTransactionPUN()
        }
        
        self.qpayRequestModel.pun = self.fahesTransactionPUNModel?.pun
        self.qpayRequestModel.amount = "\((Int(self.preRegistrationFee?.totalAmount ?? 0.0) ) * 100)"
        self.qpayRequestModel.transactionRequestDate = AuthManager.shared.serverDate?.qpayDate ?? ""
        PaymentAPIManager.getQPayParams(qpayParams: self.qpayRequestModel)
            .sink(receiveCompletion: signatureState, receiveValue: signatureResult)
            .store(in: &cancellable)
    }
    
    ///Step 2 : Create transaction
    func createTransactionPUN() {
        let  stateHandler: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure(let error):
                if let err = error as? WQError {
                    self.fahesPaymentState.send(.error(err ))
                } else {
                    self.fahesPaymentState.send(.error(WQError()))
                }
            }
        }

        // To check when user is not connected
        fahesTransactionPUNModel?.email = (userIsConnected ? user?.email : self.guestEmail) ?? ""
        fahesTransactionPUNModel?.mobile  = (userIsConnected ? user?.mobileNumber : self.guestMobile) ?? ""
        fahesTransactionPUNModel?.qid = (userIsConnected ? user?.qid : self.guestQID) ?? ""

        guard let amount = fahesTransactionPUNModel?.amount else { return }
        fahesTransactionPUNModel?.amount = "\(Int(amount) ?? 0)"
        
        let transactionResult: ReceivedValue<Bool, Bool>  = { (_, transactionCreated) in
            if transactionCreated {
                self.fahesPaymentState.send(.finishCollectingWebViewData)
            } else {
                self.fahesPaymentState.send(.failedCollectingWebViewData)
            }
        }

        FahesAPIManager.createQPay(transactionPUN: fahesTransactionPUNModel!)
            .sink(receiveCompletion: stateHandler, receiveValue: transactionResult)
            .store(in: &cancellable)
    }
    
    func getTermsOfUseFahesPaymentText() {
            let stateHandler: StateHandler = { (result) in
                switch result {
                case .finished: break
                case .failure(let error): self.state.send(.error(error as? WQError ?? WQError()))
                }
                self.isDebitCardHidden()
            }

            let receivedValue: ReceivedValue<StaticScreenDTO, StaticScreenModel>  = { (_, result) in
                self.fahesPaymenttaticText =  result.content
            }

        StaticScreensAPIManager.getStaticScreen(type: staticScreenType)
                .sink(receiveCompletion: stateHandler, receiveValue: receivedValue)
                .store(in: &cancellable)
    }
    
    func handlePaymentPerType() {
        if self.paymentType == .creditCard {
            self.getSignatureParam()
        } else {
            self.getQpayParams()
        }
    }
    
    func getCurrentDate() {
        let  stateHandler: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure:
                saveCurrentDateForPayment()
            }
            self.handlePaymentPerType()
        }
        let dateResult: ReceivedValue<CurrentDateDTO, CurrentDate  >  = { (_, dateModel) in
            AuthManager.shared.serverDate = CurrentDate(
                dateTimeStamp: dateModel.dateTimeStamp?.isEmpty ?? true ? "\(Date().timeStamp)" : dateModel.dateTimeStamp,
                utcDateTime: dateModel.utcDateTime?.isEmpty ?? true ? Date().toString() : dateModel.utcDateTime,
                qpayDate: dateModel.qpayDate?.isEmpty ?? true ? Date().getStringDate("ddMMyyyyHHmmss") : dateModel.qpayDate)        }
        PaymentAPIManager.getCurrentDate()
            .sink(receiveCompletion: stateHandler, receiveValue: dateResult)
            .store(in: &cancellable)
    }
    
    func isDebitCardHidden() {
        let  stateHandler: StateHandler = { (completion) in
            switch completion {
            case .finished: break
            case .failure: self.fahesPaymentState.send(.finishGettingStaticText)
            }
        }
        let receivedValue: ReceivedValue<Bool, Bool>  = { (_, isHidden) in
            self.debitCardHidden = isHidden
            self.fahesPaymentState.send(.finishGettingStaticText)
            
        }
        PaymentAPIManager.isDebitCardHidden()
            .sink(receiveCompletion: stateHandler, receiveValue: receivedValue)
            .store(in: &cancellable)
    }
}
