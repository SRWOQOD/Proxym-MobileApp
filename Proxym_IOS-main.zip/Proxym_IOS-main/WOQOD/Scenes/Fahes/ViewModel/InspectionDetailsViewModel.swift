//
//  InspectionDetailsViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 13/11/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class InspectionDetailsViewModel: RowViewModel {

    var evaluation: Evaluation?
    var defectComment: DefectComment?
    var location: Location?
    var additionalComment: String?
    var defectType: Evaluation?

    init(detail: InspectionDetails?) {
        self.evaluation = detail?.evaluation
        self.defectComment = detail?.defectComment
        self.location = detail?.location
        self.additionalComment = detail?.additionalComment
        self.defectType = detail?.defectType
    }

}
