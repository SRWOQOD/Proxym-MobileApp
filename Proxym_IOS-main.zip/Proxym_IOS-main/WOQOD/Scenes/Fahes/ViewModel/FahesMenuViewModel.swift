//
//  FahesMenuViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class FahesMenuViewModel: ViewModel {

    var menuItems: [SubMenuItemViewModel] {
        return (userIsConnected ? connectedMenuItems : guestMenuItems) ?? []
    }

    var connectedMenuItems: [SubMenuItemViewModel]?
    var guestMenuItems: [SubMenuItemViewModel]?
    var reservationHidden = false

    override init() {
        super.init()
    }

    /// Init fahes sub menu items
    func initFahesMenuItems() {

        let inspectionTipsViewController =  WQStaticScreenViewController.instantiate(
            appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
        inspectionTipsViewController?.strategy = InspectionTipsStrategy()

        let aboutFahesViewController =  WQStaticScreenViewController.instantiate(
            appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
        aboutFahesViewController?.strategy = AboutFahesStrategy()

        let connectedOnlinePayViewController =  ConnectedNewInspectionViewController.instantiate(
            appStoryboardName: AppStoryboard.fahes) as? ConnectedNewInspectionViewController
        connectedOnlinePayViewController?.isBooking = false

        let connectedNewInspectionViewController =  ConnectedNewInspectionViewController.instantiate(
            appStoryboardName: AppStoryboard.fahes) as? ConnectedNewInspectionViewController
        connectedNewInspectionViewController?.isBooking = true

        let guestBookingMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.bookNewVehicle.localized,
            image: #imageLiteral(resourceName: "ic_fahes_booking"), viewControllerType: FahesBookingFirstViewController.self,
            storyboard: AppStoryboard.fahes )

        let guestCancelBookingMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.cancelModifyBooking.localized,
            image: #imageLiteral(resourceName: "ic_modifyBooking"), viewControllerType: ModifyBookingDetailsViewController.self,
            storyboard: AppStoryboard.fahes )

        let guestNewInspectionMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.onlinePayementForInspection.localized, image: #imageLiteral(resourceName: "ic_online_pay"),
            viewControllerType: GuestNewInspectionViewController.self,
            storyboard: AppStoryboard.fahes)
        let connectedCancelBookingMenuItem =
            SubMenuItemViewModel.init(
                title: LocalizableFahes.cancelModifyBooking.localized, image: #imageLiteral(resourceName: "ic_modifyBooking"),
                viewControllerType: InspectionBookingListViewController.self,
                storyboard: AppStoryboard.fahes)
        let inspectionReportMenuItem =
            SubMenuItemViewModel.init(
                title: LocalizableFahes.inspectionReport.localized, image: #imageLiteral(resourceName: "ic_inspectionReport"),
                viewControllerType: InspectionViewController.self, storyboard: AppStoryboard.fahes)
        let stationsMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.stations.localized, image: #imageLiteral(resourceName: "ic_Stations"),
            viewControllerType: FahesStationsViewController.self, storyboard: AppStoryboard.fahes)
        let aboutFahesMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.aboutTitle.localized, image: #imageLiteral(resourceName: "ic_AboutFahes"),
            viewController: aboutFahesViewController)
        let receiptMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.listOfReceipt.localized, image: #imageLiteral(resourceName: "ic_ListOfReceipt"),
            viewControllerType: ReceiptViewController.self, storyboard: AppStoryboard.fahes)
        let inspectionTipMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.inspectionTipsTitle.localized, image: #imageLiteral(resourceName: "id_fahes_Inspection Tips.png"),
            viewController: inspectionTipsViewController)
        let connectedOnlinePayMenuItem = SubMenuItemViewModel.init(
            title: LocalizableFahes.onlinePayementForInspection.localized, image: #imageLiteral(resourceName: "ic_online_pay"),
            viewController: connectedOnlinePayViewController)
        let connectedNewInspectionMenuItem =
            SubMenuItemViewModel.init(
                title: LocalizableFahes.bookNewVehicle.localized,
                image: #imageLiteral(resourceName: "ic_fahes_booking"),
                viewController: connectedNewInspectionViewController)

        if reservationHidden {
            connectedMenuItems = [connectedOnlinePayMenuItem,
                                  inspectionReportMenuItem, stationsMenuItem,
                                  aboutFahesMenuItem, inspectionTipMenuItem,
                                  receiptMenuItem]
            guestMenuItems = [guestNewInspectionMenuItem, stationsMenuItem, inspectionTipMenuItem, aboutFahesMenuItem]
        } else {
            connectedMenuItems=[connectedNewInspectionMenuItem, connectedOnlinePayMenuItem,
                                connectedCancelBookingMenuItem, inspectionReportMenuItem,
                                receiptMenuItem,
                                stationsMenuItem,
                                aboutFahesMenuItem,
                                inspectionTipMenuItem]
            guestMenuItems=[guestBookingMenuItem, guestNewInspectionMenuItem,
                            guestCancelBookingMenuItem, stationsMenuItem,
                            aboutFahesMenuItem, inspectionTipMenuItem]
        }
    }

    func isReservationHidden() {
        let stateHandler: StateHandler = { _ in
                self.state.send(.finishedLoading)
        }

        let receiveValue: (Bool, Bool) -> Void = { (_, isHidden) in
            self.reservationHidden = isHidden
        }
        ReservationAPIManager.isReservationHidden()
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

}
