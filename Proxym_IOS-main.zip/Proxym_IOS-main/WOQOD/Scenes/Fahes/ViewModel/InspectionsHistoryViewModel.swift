//
//  InspectionDetailViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class InspectionsHistoryViewModel: RowViewModel {

    var inspection: String = ""
    var inspectionOn: String = ""
    var plateType: String = ""
    var legalEvaluation: String = ""
    var technicalEvaluation: String = ""
    var plateNumber: String = ""

    init(inspection: InspectionsHistory?) {
        self.inspection = String(inspection?.inspection ?? 0)
        self.inspectionOn = inspection?.inspectionOn ?? ""
        self.plateType = inspection?.plateType ?? ""
        self.legalEvaluation = inspection?.legalEvaluation ?? ""
        self.technicalEvaluation = inspection?.technicalEvaluation ?? ""
        self.plateNumber = inspection?.plateNumber ?? ""

    }

}
