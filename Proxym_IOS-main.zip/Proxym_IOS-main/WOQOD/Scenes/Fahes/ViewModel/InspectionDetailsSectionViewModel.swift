//
//  InspectionDetailsSectionViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 14/11/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
struct InspectionDetailsSectionViewModel {
    var title: String?
    var isHidden: Bool = true
    var items: [InspectionDetailsViewModel]?
}
