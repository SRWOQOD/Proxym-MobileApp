//
//  BookVehicleInspectionViewModel.swift
//  WOQOD
//
//  Created by rim.ktari on 02/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Combine
import Foundation

struct  BookVehicleInspectionElement {
    var inputFieldType: InputFieldType = .textfield
    var title: String?
    var type: FieldType
    var dataArray: [String]?
    var published: BookingKeyPath
    var value: String?
    var editable: Bool?
    var isMandatory: Bool = true
}

enum FahesBookingModelState {
    case successGetReference
    case finishedFetchingData
    case successOTP
    case successGetStations
    case successAppointementDates
    case successGetSlots
    case successReservation
    case successReschedule
    case successCancellation
    case successGetBookingList
    case successGetBookingForGuest
    case successGetCarsList
    case successResendOtp
    case successCheckingPayingOnline
    case successCheckingBookingValidity(CarValidity)
    case errorReschedule(WQError)
    case errorReservation(WQError)
    case errorGettingReference(WQError)
    case errorCheckingOwnership(WQError)
    case errorCancellation
    case errorCheckingPayOnline
    case error(WQError)
}
typealias BookingKeyPath = ReferenceWritableKeyPath<BookVehicleInspectionViewModel, String>

class BookVehicleInspectionViewModel: ViewModel {
    var listCars: [CarViewModel] = [] // listCars
    var bookingModel: FahesBooking?
    var bookingState = PassthroughSubject<FahesBookingModelState, Never>()
    var selectedStationName = ""
    var listOfSlots = [Slot]()
    var selectedSlotID: Int?
    var entredPinCode: String?
    var stationsList: [Station] = []
    var fahesCarVM = FahesCarViewModel()
    var availableDatesList: [Date] = []
    var fromRescheduling: Bool = false
    var bookingBeforePayment: Bool = false
    var selectedDate: String = ""
    var lastSelectedDate: Date = Date()
    var canPay: Bool?
    var selectedCarIndex: IndexPath?
    /// Customer types
    let customerTypeArray = [
        CutomerTypeElement(key: CustomerType.individual.rawValue,
                           name: LocalizableFahes.customerTypeIndividual.localized),
        CutomerTypeElement(key: CustomerType.corporate.rawValue, name: LocalizableFahes.customerTypeCorporate.localized)
    ]
    var plateTypeNames: [String] {
        return plateTypesArray.map({$0.name ?? ""})
    }
    var vehicleShapeNames: [String] {
        return vehicleShapeList.map({$0.name ?? ""})
    }
    var vehicleShapeList: [VehicleShape] = []
    var plateTypesArray = [Details]() // Returnes from getPlateTypes API
    var plateTypeWithShapeList = [PlateTypeWithShape]() // Returned from plateTypeWithShape API
    var reservationReference: Int?
    var shouldHideQatariIdView: Bool {
        guard let value =  self.customerTypeArray.filter({
            $0.name == self.fahesCarVM.customerType
        }).first?.key else { return false }
        return CustomerType(rawValue: value) == .individual
    }
    let customerTypeKeyPath: BookingKeyPath = \.fahesCarVM.customerType
    let qatariIDKeyPath: BookingKeyPath = \.fahesCarVM.qid
    let mobileKeyPath: BookingKeyPath = \.fahesCarVM.mobile
    let plateNumberKeyPath: BookingKeyPath = \.fahesCarVM.plateNumber
    let plateTypeKeyPath: BookingKeyPath = \.fahesCarVM.plateType
    let emailKeyPath: BookingKeyPath = \.fahesCarVM.email
    let vehicleShapeKeyPath: BookingKeyPath = \.fahesCarVM.vehicleShape
    var listBooking: [InspectionBookingItemViewModel] = [] // bookingList

    var elementsGuestMode : [ BookVehicleInspectionElement ] {
        return [
            BookVehicleInspectionElement(
                                         inputFieldType: .dropDown,
                                         title: LocalizableFahes.customerType.localized  + "*",
                                         type: .dropDown(type: .customerTypes),
                                         dataArray: customerTypeArray.map({$0.name}),
                                         published: customerTypeKeyPath,
                                         value: customerTypeArray.map({$0.name}).first
            ),
            BookVehicleInspectionElement(title: LocalizableShared.qid.localized + "*", type: .qatariId,
                                         published: qatariIDKeyPath, value: fahesCarVM.qid),
            BookVehicleInspectionElement(title: LocalizableFahes.companyId.localized + "*",
                                         type: .companyID, published: qatariIDKeyPath),

            BookVehicleInspectionElement(title: LocalizableShared.mobileNumber.localized + "*",
                                         type: .mobileNumber, published: mobileKeyPath,
                                         value: fahesCarVM.mobile),
//            BookVehicleInspectionElement(title: LocalizableShared.email.localized,
//                                         type: .email, published: emailKeyPath,
//                                         value: fahesCarVM.email,
//                                         isMandatory: false),
            BookVehicleInspectionElement(inputFieldType: .dropDown, title: LocalizableShared.plateType.localized + "*",
                                         type: .dropDown(type: .plateTypes), dataArray: plateTypeNames,
                                         published: plateTypeKeyPath, value: fahesCarVM.plateType),
            BookVehicleInspectionElement(title: LocalizableShared.carPlate.localized + "*",
                                         type: .carPlate(), published: plateNumberKeyPath,
                                         value: fahesCarVM.plateNumber),
            BookVehicleInspectionElement(
                                         inputFieldType: .dropDown,
                                         title: LocalizableShared.vehicleShape.localized + "*",
                                         type: .dropDown(type: .vehicleShapes),
                                         dataArray: vehicleShapeNames, published: vehicleShapeKeyPath,
                                         value: fahesCarVM.vehicleShape)
        ]
    }

    var bookingElementsForConnectedMode : [ ItemContentModel ] {
        if userIsConnected && (fahesCarVM.plateType != "" ) {
            plateTypesArray.insert(Details(name: fahesCarVM.plateType, id: fahesCarVM.plateTypeId), at: 0)
        }
        return [
            ItemContentModel(title: LocalizableFahes.customerType.localized,
                             value: customerTypeArray.map({$0.name}).first ?? ""
            ),
            ItemContentModel(title: LocalizableShared.qid.localized,
                             value: checkQid() ?? ""),

            ItemContentModel(title: LocalizableShared.mobileNumber.localized,
                             value: user?.mobileNumber ?? ""),

            ItemContentModel(title: LocalizableShared.carPlate.localized,
                             value: fahesCarVM.plateNumber),
            ItemContentModel(title: LocalizableShared.plateType.localized,
                             value: fahesCarVM.plateType)
        ]
    }
    
    private func checkQid() -> String? {
        return userIsConnected ? fahesCarVM.qid.from64ToString(): fahesCarVM.qid
    }

    var vehicleShapeBookElement: BookVehicleInspectionElement {
        return BookVehicleInspectionElement(
            title: LocalizableShared.vehicleShape.localized + "*",
            type: .dropDown(type: .vehicleShapes),
            dataArray: vehicleShapeNames,
            published: vehicleShapeKeyPath,
            value: fahesCarVM.vehicleShape
        )
    }
    var elementsToShowForModifyGuestMode : [ BookVehicleInspectionElement ] {
        return [
            BookVehicleInspectionElement(
                inputFieldType: .dropDown,
                title: LocalizableFahes.customerType.localized + "*",
                type: .dropDown(type: .customerTypes),
                dataArray: customerTypeArray.map({$0.name}),
                published: customerTypeKeyPath,
                value: customerTypeArray.map({$0.name}).first,
                editable: !userIsConnected
            ),
            BookVehicleInspectionElement(title: LocalizableShared.qid.localized + "*", type: .qatariId,
                                         published: qatariIDKeyPath,
                                         value: user?.qid,
                                         editable: !userIsConnected),
            BookVehicleInspectionElement(title: LocalizableFahes.companyId.localized + "*",
                                         type: .companyID,
                                         published: qatariIDKeyPath,
                                         value: fahesCarVM.qid ),

            BookVehicleInspectionElement(title: LocalizableShared.mobileNumber.localized + "*",
                                         type: .mobileNumber,
                                         published: mobileKeyPath,
                                         value: user?.mobileNumber ?? "",
                                         editable: !userIsConnected),
//            BookVehicleInspectionElement(title: LocalizableShared.email
//                                            .localized,
//                                         type: .email,
//                                         published: emailKeyPath,
//                                         isMandatory: false),

            BookVehicleInspectionElement(inputFieldType: .dropDown, title: LocalizableShared.plateType.localized + "*",
                                         type: .dropDown(type: .plateTypes), dataArray: plateTypeNames,
                                         published: plateTypeKeyPath,
                                         value: fahesCarVM.plateType,
                                         editable: !userIsConnected),
            BookVehicleInspectionElement(title: LocalizableShared.carPlate.localized + "*",
                                         type: .carPlate(),
                                         published: plateNumberKeyPath,
                                         value: fahesCarVM.plateNumber,
                                         editable: !userIsConnected)
        ]
    }

    var elementsToShowForModify : [ ItemContentModel ] {
        return  [
//            ItemContentModel(title: LocalizableFahes.customerType.localized,
//                             value: customerTypeArray.map({$0.name}).first ?? ""),
            ItemContentModel(title: LocalizableShared.qid.localized,
                             value: bookingModel?.customerID ?? ""),
            ItemContentModel(title: LocalizableShared.mobileNumber.localized,
                             value: user?.mobileNumber ?? ""),
            ItemContentModel(title: LocalizableShared.carPlate.localized,
                             value: bookingModel?.plateNumber ?? ""),
            ItemContentModel(title: LocalizableShared.plateType.localized,
                             value: bookingModel?.plateTypeName?.uppercased() ?? "")
        ]
    }

    func getVehicleShapesForPlateType() {
        self.vehicleShapeList =  self.plateTypeWithShapeList.filter({
            if !(userIsConnected) {
                self.getPlateTypeId()
            }
            return $0.plateTypeID == fahesCarVM.plateTypeId
        }).first?.vehicleShapes ?? []
    }

    /// Function to get plateTypes
    func getPlateTypes() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished: break
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
            self.getPlateTypeWithShape()
        }
        let plateTypesResult: ReceivedValue < [DetailsDTO], [ Details ] > = {(_, platetTypes) in
            self.plateTypesArray = platetTypes
        }

        FahesAPIManager.getPlateTypes()
            .sink(receiveCompletion: state, receiveValue: plateTypesResult)
            .store(in: &cancellable)
    }

    /// Function to get PlateTypeWithShape
    func getPlateTypeWithShape() {

        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.finishedFetchingData)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let plateTypesResult: ReceivedValue <[PlateTypeWithShapeDTO], [ PlateTypeWithShape ]>
            = {(_, plateTypeWithShapeList) in
                self.plateTypeWithShapeList = plateTypeWithShapeList
                self.plateTypesArray = plateTypeWithShapeList.map {
                    Details.init(name: $0.plateTypeName, id: $0.plateTypeID)
                }
            }

        ReservationAPIManager.getPlateTypeWithShape()
            .sink(receiveCompletion: state, receiveValue: plateTypesResult)
            .store(in: &cancellable)
    }

    func getPreReservationReference() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successGetReference)
            case .failure(let error):
                self.bookingState.send(.errorGettingReference(error as? WQError ?? WQError()))
            }
        }
        let referenceResult: ReceivedValue <ReservationReferenceDTO, ReservationReference>
            = {(_, reservationReferenceModel) in
            self.reservationReference = reservationReferenceModel.referenceID
        }
        // getVehicleShapeId
        if !(userIsConnected) {
            // getPlateTypeId
            getPlateTypeId()
        }
            getVehicleShapeId()
        ReservationAPIManager.getPreReservationReference(fahesCar: fahesCarVM.fahesCar)
            .sink(receiveCompletion: state, receiveValue: referenceResult)
            .store(in: &cancellable)

    }
    func getVehicleShapeId() {
        self.fahesCarVM.vehicleShapeId =  self.vehicleShapeList.filter({
            $0.name?.uppercased() == fahesCarVM.vehicleShape.uppercased()
        }).first?.id
    }
    func getPlateTypeId() {
        self.fahesCarVM.plateTypeId =  self.plateTypesArray.filter({
            $0.name?.uppercased() == fahesCarVM.plateType.uppercased()
        }).first?.id
    }

    func validateOTP() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished: break
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let referenceResult: ReceivedValue <Bool, Bool> = {(_, valid) in
            if !valid {
                self.bookingState.send(.error(
                                        WQError(message: LocalizableShared.wrongPincode.localized,
                                                statusCode: "0", errorId: "")))
            } else {
                self.bookingState.send(.successOTP)
            }
        }

        ReservationAPIManager.otpValidation(refId: reservationReference, otp: entredPinCode)
            .sink(receiveCompletion: state, receiveValue: referenceResult)
            .store(in: &cancellable)

    }

    func getAvailableStations() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successGetStations)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let stationsResult: ReceivedValue <[StationDTO], [Station]> = {(_, stationsList) in
            self.stationsList.append(contentsOf: stationsList)
        }

        ReservationAPIManager.getAvailableStations(refId: reservationReference)
            .sink(receiveCompletion: state, receiveValue: stationsResult)
            .store(in: &cancellable)

    }
    func getAppointmentDates() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successAppointementDates)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let datesResult: ReceivedValue <[AppointmentDateDTO], [AppointmentDate]> = {(_, availableDates) in
            self.availableDatesList = availableDates.map({$0.date ?? Date()})
        }

        ReservationAPIManager.getAppointmentDates(refId: reservationReference,
                                                  stationID: getSelectedStationId())
            .sink(receiveCompletion: state, receiveValue: datesResult)
            .store(in: &cancellable)

    }
    func getSelectedStationId() -> Int {
        return self.stationsList.filter({$0.name == selectedStationName}).first?.id ?? 0

    }
    func getSelectedSlotValue() -> String {
        return self.listOfSlots.filter({$0.identifier == selectedSlotID}).first?.value ?? ""
    }

    func getSlots(forDate: Date?) {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successGetSlots)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let slotsResult: ReceivedValue <[SlotDTO], [Slot]> = {(_, slotsList) in
            self.listOfSlots = slotsList
        }

        ReservationAPIManager.getSlots(refId: reservationReference,
                                       stationID: getSelectedStationId(),
                                       date: forDate)
            .sink(receiveCompletion: state, receiveValue: slotsResult)
            .store(in: &cancellable)

    }
    func reservation() {

        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successReservation)
            case .failure(let error):
                self.bookingState.send(.errorReservation(error as? WQError ?? WQError()))
            }
        }
        let reservationResult: ReceivedValue <FahesBookingResultDTO, FahesBooking> = {(_, bookingModel) in
            self.bookingModel = bookingModel
        }
        ReservationAPIManager.reservation(refId: reservationReference, slotID: selectedSlotID,
                                          userType: getUserType(), fahesCar: fahesCarVM.fahesCar)
            .sink(receiveCompletion: state, receiveValue: reservationResult)
            .store(in: &cancellable)
    }
    func checkPayOnline() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successCheckingPayingOnline)
            case .failure:
                self.canPay = false
                self.bookingState.send(.errorCheckingPayOnline)
            }
        }
        let reservationResult: ReceivedValue <Bool, Bool> = {(_, canPay) in
            self.canPay = canPay
        }
        ReservationAPIManager.canPayOnline(refId: String(reservationReference ?? 0),
                                           slotID: String(selectedSlotID ?? 0))
            .sink(receiveCompletion: state, receiveValue: reservationResult)
            .store(in: &cancellable)
    }

    func getUserType() -> String {
        guard let value =  self.customerTypeArray.filter({
            $0.name == self.fahesCarVM.customerType
        }).first?.key else { return CustomerType.individual.rawValue }
        return value
    }

    func reschedule() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                self.bookingState.send(.successReschedule)
            case .failure(let error):
                self.bookingState.send(.errorReschedule(error as? WQError ?? WQError()))
            }
        }
        let referenceResult: ReceivedValue <Int, Int> = {(_, referenceID) in
            self.reservationReference = referenceID
            if userIsConnected {
                self.fahesCarVM.qid = self.fahesCarVM.qid.toBase64()
            }
        }

        ReservationAPIManager.rescheduling(reservationId: bookingModel?.reservationID)
            .sink(receiveCompletion: state, receiveValue: referenceResult)
            .store(in: &cancellable)
    }

    func cancellation() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished: break
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let referenceResult: ReceivedValue <Bool, Bool> = {(_, isCancelled) in
            if isCancelled {
                self.bookingState.send(.successCancellation)
            } else {
                self.bookingState.send(.errorCancellation)
            }
        }

        ReservationAPIManager.cancellation(reservationId: bookingModel?.reservationID)
            .sink(receiveCompletion: state, receiveValue: referenceResult)
            .store(in: &cancellable)
    }

    /// Get list of booking
    func getBookings() {
        let stateHandler: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.bookingState.send(.successGetBookingList)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receiveValue: ([FahesBookingDTO], [FahesBooking]) -> Void = { (_, bookings) in
            self.listBooking = bookings.map({
                InspectionBookingItemViewModel.init(booking: $0)
            })
        }
        ReservationAPIManager.detailsByCustomer(qid: fahesCarVM.qid)
            // Just for test
            //        ReservationAPIManager.detailsByCustomer(qid: "27263400979")
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }
    /// Get list of booking for guest mode
    func getBookingsForGuest() {
        getPlateTypeId()
        let stateHandler: StateHandler  = { (result) in
            switch result {
            case .finished:
                self.bookingState.send(.successGetBookingForGuest)
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receiveValue: (FahesBookingResultDTO, FahesBooking) -> Void = { (_, booking) in
            self.bookingModel = booking
            self.reservationReference = booking.reservationID
        }
        ReservationAPIManager.detailsByGuest(fahesCar: fahesCarVM.fahesCar)
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

    func resendOtp() {

        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                break
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let reservationResult: ReceivedValue <Bool, Bool> = {(_, sent) in
            if sent {
                self.bookingState.send(.successResendOtp)
            } else {
                self.bookingState.send(.error(WQError(errorCode: ErrorCode.serverError.rawValue)))
            }
        }
        ReservationAPIManager.resendOtp(refId: reservationReference)
            .sink(receiveCompletion: state, receiveValue: reservationResult)
            .store(in: &cancellable)
    }
    /// This WS was added to check isOwner for booking
    func checkIsOwnerBooking() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                break
            case .failure(let error):
                self.bookingState.send(.errorCheckingOwnership(error as? WQError ?? WQError()))
            }
        }
        let reservationResult: ReceivedValue < CarDTO<String>, Car > = {(_, _) in
            /// In case of success, check reservation validity
            self.checkBookingValidity()
        }
        ReservationAPIManager.checkOwner(fahesCar: fahesCarVM.fahesCar)
            .sink(receiveCompletion: state, receiveValue: reservationResult)
            .store(in: &cancellable)
    }
    /// This WS was added to check if the booking is valid or not and remove reservation expiry test
    func checkBookingValidity() {
        let state: StateHandler = { [unowned self] result  in
            switch result {
            case .finished:
                break
            case .failure(let error):
                self.bookingState.send(.error(error as? WQError ?? WQError()))
            }
        }
        let reservationResult: ReceivedValue <CarValidtyDTO, CarValidity> = {(_, carValidity) in
            self.bookingState.send(.successCheckingBookingValidity(carValidity))
        }
        ReservationAPIManager.checkBookingValidity(fahesCar: fahesCarVM.fahesCar)
            .sink(receiveCompletion: state, receiveValue: reservationResult)
            .store(in: &cancellable)
    }

}
