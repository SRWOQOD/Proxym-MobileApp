//
//  FahesReservationOTPViewController.swift
//  WOQOD
//
//  Created by rim.ktari on 04/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesReservationOTPViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var otpInsertView: WQOTPInsertView!
    @IBOutlet weak var headerView: WQHeaderView!

    // MARK: Properties
    var viewModel: BookVehicleInspectionViewModel?
    var cancellable = Set<AnyCancellable>()
    var registerCarVM: NewInspectionRegisterViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpBindings()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cancellable.removeAll()
    }
    private func validateOTP() {
        self.viewModel?.entredPinCode = self.otpInsertView.typedCode
        showActivityIndicator()
        viewModel?.validateOTP()

    }

    private func resendOTP() {
        self.otpInsertView.otpCodeView.clearAllFields()
        showActivityIndicator()
        viewModel?.resendOtp()
    }
    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.popToRootViewController()}
    }

    private func setUpBindings() {

        func bindViewToViewModelState() {
            viewModel?.bookingState.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .successOTP:
                    FahesRouter.shared
                        .showBookingSecondViewController(viewModel: self.viewModel, registerCarVM: self.registerCarVM)
                case .successResendOtp:
                    break
                case .error(let error) :
                    self.otpInsertView.otpCodeView.clearAllFields()
                    self.showErrorAlertView(descriptionMessage: error.message,
                                            fromFahes: true,
                                            didConfirm: {self.otpInsertView.otpCodeView.clearAllFields()})
                default : break
                }
            }
            .store(in: &cancellable)
        }
        bindViewToViewModelState()
    }
    func initUI() {
        initHeaderView()
        otpInsertView.verificationImage = #imageLiteral(resourceName: "ic_verification_phone")
        otpInsertView.titleText = LocalizableShared.codeVerification.localized
        otpInsertView.messageText = LocalizableShared.sentToPhoneMessage.localized
        otpInsertView.confirmButtonTitle = LocalizableShared.confirm.localized
        otpInsertView.otpCodeView.configure(with: 6)
        otpInsertView.resendCodeButton.isHidden = false
        otpInsertView.resendButtonTitle = LocalizableShared.resendCode.localized
        otpInsertView.resendIsTapped = resendOTP
        otpInsertView.confirmIsTapped = validateOTP
    }

}
