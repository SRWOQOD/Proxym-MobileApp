//
//  FahesBookingFirstViewController.swift
//  WOQOD
//
//  Created by rim.ktari on 02/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesBookingFirstViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var bookingImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var proceedButton: WQButton!

    // MARK: - Properties

    var bookVehicleInspectionViewModel = BookVehicleInspectionViewModel()
    var registerCarVM: NewInspectionRegisterViewModel?
    var cancellable=Set<AnyCancellable>()

    // MARK: - Overrides
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.hideElementsIFNeeded()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        bindData()
    }
    // MARK: - Binding
    func bindData() {
        showActivityIndicator()
        bookVehicleInspectionViewModel.getPlateTypeWithShape()
        bookVehicleInspectionViewModel.bookingState.sink { state in
            hideActivityIndicator()
            switch state {
            case .finishedFetchingData: self.updatePlateTypesView()
            case .successGetReference:
                FahesRouter.shared.showFahesReservationOtpVC(viewModel: self.bookVehicleInspectionViewModel,
                                                             registerCarVM: self.registerCarVM)
            case .successCheckingBookingValidity(let carValidty) :
                /// If reservation is still valid, show popup to ask user if he want to continue
                /// If is not valid -> pass to the next step of booking
                if !(carValidty.canProceed ?? false) {
                    self.bookVehicleInspectionViewModel.getPreReservationReference()
                } else {
                    self.showProceedToBookingActionPopUp(message: carValidty.message)
                }
            case .errorGettingReference(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
            default:break
            }
        }.store(in: &cancellable)
    }
    // MARK: - Methods

    func initUI() {
        initHeaderView()
        initContentView()
        setUpStackView()
        initButtons()
        titleLabel.setText(text: LocalizableFahes.bookNewVehicle.localized.uppercased(),
                           font: Fonts.boldFontName,
                           size: 22,
                           forgroundColor: UIColor.wqBlue,
                           align: languageIsEnglish ? .left : .right)
        bookingImageView.setTintedImage(image: UIImage(named: "ic_fahes_booking"),
                                        color: UIColor.wqBlue.withAlphaComponent(0.05))
    }

    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    func initContentView() {
        contentView.border(borderColor: UIColor.white, borderwidth: 1)
        contentView.roundTopCorners(radius: 15)
    }
    func initButtons() {
        proceedButton.title = LocalizableShared.proceed.localized.uppercased()
        proceedButton.style = Buttontype.secondary
        proceedButton.titleLabel?.numberOfLines = 1
    }

    /// We have to reload the plate type view when we get the response from the API
    private func updatePlateTypesView() {
        if userIsConnected {
            bookVehicleInspectionViewModel.getVehicleShapesForPlateType()
            stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.shouldSelectFirstItem
                = bookVehicleInspectionViewModel.vehicleShapeNames.count == 1 ? true : false
            stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?
                .dataArray = bookVehicleInspectionViewModel.vehicleShapeNames
            stackView.getWqDropDownViewFor(
                .dropDown(type: .vehicleShapes))?.defaultValueDropDownMenu =
                bookVehicleInspectionViewModel.vehicleShapeNames.first
        } else {
            stackView.getWqDropDownViewFor(.dropDown(type: .plateTypes))?
                .dataArray = bookVehicleInspectionViewModel.plateTypeNames
        }
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?
            .isHidden = bookVehicleInspectionViewModel.vehicleShapeNames.count == 0
    }

    func reloadElementsForDropDown() {
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.resetLabel()
        bookVehicleInspectionViewModel.getVehicleShapesForPlateType()
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.isHidden
            = bookVehicleInspectionViewModel.vehicleShapeNames.count == 0
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.shouldSelectFirstItem
            = bookVehicleInspectionViewModel.vehicleShapeNames.count == 1
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.dataArray =
            bookVehicleInspectionViewModel.vehicleShapeNames
        if bookVehicleInspectionViewModel.vehicleShapeNames.count == 1 {
            stackView.getWqDropDownViewFor(
                .dropDown(type: .vehicleShapes))?.defaultValueDropDownMenu =
                stackView.getWqDropDownViewFor(.dropDown(
                                                type:.vehicleShapes))?.dataArray?.first
        } else {
            stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.clearDropMenu()
        }
    }
    func showProceedToBookingActionPopUp(message: String?) {
        showCustomAlertView(title: LocalizableFahes.bookNewVehicle.localized.uppercased(),
                            text: message,
                            didConfirm: {
                                self.bookVehicleInspectionViewModel.getPreReservationReference()
                            }, didDiscard: {
                                self.popToRootViewController()
                            },
                            confirmText: LocalizableShared.commonContinue.localized, fromFahes: true)
    }

    // In case "corporate"  : We have a company Id
    // In case "private" : We have a qatari Id
    private func hideElementsIFNeeded() {
        stackView.getWqTFViewFor(.qatariId)?.isHidden =  !(bookVehicleInspectionViewModel.shouldHideQatariIdView)
        stackView.getWqTFViewFor(.companyID)?.isHidden =  bookVehicleInspectionViewModel.shouldHideQatariIdView
        stackView.getWqDropDownViewFor(.dropDown(type: .vehicleShapes))?.isHidden
            = bookVehicleInspectionViewModel.vehicleShapeNames.count == 0
    }

    func setUpStackView() {
        if userIsConnected {
            bookVehicleInspectionViewModel.bookingElementsForConnectedMode.forEach {
                let textFieldView = WQItemContent()
                textFieldView.title = $0.title
                textFieldView.value = $0.value
                stackView.addArrangedSubview(textFieldView)
            }
            self.setupVehiculeShapeConnectedMode()
        } else {
            bookVehicleInspectionViewModel.elementsGuestMode.forEach {
                var textfieldView: CommonInputFieldView?
                switch $0.inputFieldType {
                case .dropDown:
                    textfieldView = WQDropDownMenu()
                    textfieldView?.title = $0.title
                    textfieldView?.fieldType = $0.type
                    guard let dropMenuView = (textfieldView as? WQDropDownMenu) else {return}
                    dropMenuView.shouldSelectFirstItem = ($0.type == .dropDown(type: .customerTypes))
                    textfieldView?.dataArray = $0.dataArray
                    if dropMenuView.shouldSelectFirstItem {
                        dropMenuView.defaultValueDropDownMenu = $0.value ?? ""
                    }
                    dropMenuView.$selectedText
                        .assign(to: $0.published, on: bookVehicleInspectionViewModel)
                        .store(in: &cancellable)
                    if $0.type == .dropDown(type: .plateTypes) {
                        dropMenuView.pickerViewWillChangeValue
                            .sink {
                                self.reloadElementsForDropDown()
                                self.stackView.handleCarPLateTypeChange(dropMenu: dropMenuView)
                            }.store(in: &cancellable)
                    } else if $0.type == .dropDown(type: .customerTypes) {
                        dropMenuView.pickerViewWillChangeValue
                            .sink { self.hideElementsIFNeeded()}
                            .store(in: &cancellable)
                    }
                    stackView.addArrangedSubview(textfieldView!)
                default:
                    textfieldView = WQTextFieldView()
                    textfieldView?.fieldType = $0.type
                    textfieldView?.title = $0.title
                    textfieldView?.placeholder = ""
                    textfieldView?.value = $0.value
                    textfieldView?.isMandatory = $0.isMandatory
                    textfieldView?.textPublisher?.assign(to: $0.published, on: bookVehicleInspectionViewModel)
                        .store(in: &cancellable)
                    stackView.addArrangedSubview(textfieldView!)
                }
            }
        }
    }

    func setupVehiculeShapeConnectedMode() {
        let vehicleShapeElement = bookVehicleInspectionViewModel.vehicleShapeBookElement
        let vehicleTextFieldView = WQDropDownMenu()
        vehicleTextFieldView.fieldType = vehicleShapeElement.type
        vehicleTextFieldView.title = vehicleShapeElement.title
        vehicleTextFieldView.placeholder = ""
        vehicleTextFieldView.dataArray = vehicleShapeElement.dataArray
        vehicleTextFieldView.value = vehicleShapeElement.value
        vehicleTextFieldView.shouldSelectFirstItem = false
        vehicleTextFieldView.pickerViewWillChangeValue
            .sink {
                self.stackView.handleCarPLateTypeChange(dropMenu: vehicleTextFieldView)
            }.store(in: &cancellable)
        vehicleTextFieldView.textPublisher?.assign(to: vehicleShapeElement.published,
                                                   on: bookVehicleInspectionViewModel)
            .store(in: &cancellable)
        vehicleTextFieldView.$selectedText
            .assign(to: vehicleShapeElement.published, on: bookVehicleInspectionViewModel)
            .store(in: &cancellable)
        vehicleTextFieldView.selectedText = vehicleShapeElement.value ?? ""
        stackView.addArrangedSubview(vehicleTextFieldView)
    }
    @IBAction func proceedAction(_ sender: Any) {
        if stackView.validCommonInputFields() {
            showActivityIndicator()
            if userIsConnected {
                bookVehicleInspectionViewModel.getPreReservationReference()
            } else {
                bookVehicleInspectionViewModel.checkBookingValidity()
                AccountManager.shared.guestEmail = bookVehicleInspectionViewModel.fahesCarVM.email
            }
        }
    }
}
