//
//  FahesBookingSecondViewController.swift
//  WOQOD
//
//  Created by rim.ktari on 02/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine
class FahesBookingSecondViewController: UIViewController {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var bookingImageView: UIImageView!
    @IBOutlet weak var calendarView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var nextButton: WQButton!
    @IBOutlet weak var stationsDropDown: WQDropDownMenu!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var slotsCollectionView: DynamicCollectionView!

    // MARK: Properties
    var calendar: AMCalendarRootViewController?
    var selectedDate: Date?
    var viewModel: BookVehicleInspectionViewModel?
    var cancellable = Set<AnyCancellable>()

    var registerCarVM: NewInspectionRegisterViewModel?
    var guestNewInspectionViewModel = GuestNewInspectionViewModel()
    let connectedNewInspectionViewModel =  ConnectedNewInspectionViewModel()
    var shouldReloadSlots = PassthroughSubject<Bool, Never>()

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        bindData()
    }

    func bindData() {
        showActivityIndicator()
        viewModel?.getAvailableStations()
        viewModel?.bookingState.sink { state in
            hideActivityIndicator()
            switch state {
            case .successGetStations:
                self.updateStationsList()
            case .successAppointementDates:
                // ToBe checked
                if self.viewModel?.availableDatesList.count == 0 {
                    self.viewModel?.listOfSlots = []
                }
                self.reloadSlotsCollectionView()
                self.updateCalendar(listDates: self.viewModel?.availableDatesList)
            case .successGetSlots:
                self.viewModel?.selectedSlotID = nil
                self.reloadSlotsCollectionView()
            case .successReservation:
                if self.viewModel?.bookingBeforePayment == true {
                    userIsConnected ? self.submitActionForConnected() : self.submitActionForGuest()
                } else {
                    self.popToRootViewController()
                }
            case .successReschedule:
                break
            case .successCheckingPayingOnline:
                self.viewModel?.bookingModel = FahesBooking(time: self.viewModel?.getSelectedSlotValue(),
                                                            date: self.viewModel?.selectedDate,
                                                            station: self.viewModel?.selectedStationName,
                                                            pay: self.viewModel?.canPay)
                self.showBookingView()
            case .errorReschedule(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            case .errorCheckingPayOnline:
                self.viewModel?.bookingModel = FahesBooking(time: self.viewModel?.getSelectedSlotValue(),
                                                            date: self.viewModel?.selectedDate,
                                                            station: self.viewModel?.selectedStationName,
                                                            pay: self.viewModel?.canPay)
                self.showBookingView()
            case .errorReservation(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.shouldReloadSlots.send(true)
                    if error.statusCode == LocalizableFahes.duplicatedReservationCodeError.localized {
                        self.popToRootViewController()
                    } else {
                        self.popToViewController(ofClass: FahesBookingSecondViewController.self)
                    }
                }
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.dismiss(animated: true, completion: nil)
                }
            default:break
            }
        }.store(in: &cancellable)

        guestNewInspectionViewModel.guestNewInspectionState.sink { state in
            hideActivityIndicator()
            switch state {
            case .didEndSubmitAction :
                self.registerCarVM =  NewInspectionRegisterViewModel(
                    preRegistrationFee: self.guestNewInspectionViewModel.preRegistrationFee,
                    car: self.guestNewInspectionViewModel.carDetails)
                self.showNewInspectionRegister()
            case .errorCheckingIsOwner(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToViewController(ofClass: FahesBookingSecondViewController.self)
                }
            case .errorGettingFee(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            default : break
            }
        }.store(in: &cancellable)

        connectedNewInspectionViewModel.connectedNewInspectionState.sink { state in
            hideActivityIndicator()
            switch state {
            case .didEndFetchingFeeConnectedMode :
                self.registerCarVM =  NewInspectionRegisterViewModel(
                    preRegistrationFee: self.connectedNewInspectionViewModel.preRegistrationFee,
                    car: self.connectedNewInspectionViewModel.carDetails)
                self.showNewInspectionRegister()
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToViewController(ofClass: FahesBookingSecondViewController.self)
                }
            case .errorCheckingIsOwner(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            case .errorGettingFee(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            default: break
            }
        }.store(in: &cancellable)
        self.shouldReloadSlots.sink { shouldReload in
            if shouldReload {
                self.viewModel?.listOfSlots = []
                self.viewModel?.getSlots(forDate: self.viewModel?.lastSelectedDate)
            }
        }.store(in: &cancellable)
    }

    func initUI() {
        initHeaderView()
        initContentView()
        initButtons()
        initLabels()
        bookingImageView.setTintedImage(image: UIImage(named: "ic_fahes_booking"),
                                        color: UIColor.wqBlue.withAlphaComponent(0.05))
        initCalendar()
        initDropDownView()
        initCollectionView()
    }
    func reloadSlotsCollectionView() {
        slotsCollectionView.reloadData()
        let message = viewModel?.selectedStationName.isEmpty ??
            true ? LocalizableFahes.selectSationAndDate.localized
            : LocalizableShared.emptySlots.localized

        setEmptyMessage(message: message)
    }

    func updateStationsList() {
        stationsDropDown.shouldSelectFirstItem = false
        stationsDropDown.dataArray = viewModel?.stationsList.map({$0.name ?? ""})
    }

    func initLabels() {
        titleLabel.setText(text: LocalizableFahes.bookNewVehicle.localized.uppercased(),
                           font: Fonts.boldFontName,
                           size: 22,
                           forgroundColor: UIColor.wqBlue,
                           align: languageIsEnglish ? .left : .right)
        dateLabel.setText(text: LocalizableShared.date.localized,
                          font: Fonts.mediumFontName,
                          size: 15,
                          forgroundColor: UIColor.wqBlue)
        timeLabel.setText(text: LocalizableShared.time.localized,
                          font: Fonts.mediumFontName,
                          size: 15,
                          forgroundColor: UIColor.wqBlue)
    }

    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.popToRootViewController()}
    }

    func initContentView() {
        contentView.border(borderColor: UIColor.white, borderwidth: 1)
        contentView.roundTopCorners(radius: 15)
    }
    func initCollectionView() {
        slotsCollectionView.delegate = self
        slotsCollectionView.dataSource = self
        slotsCollectionView.registerCellNib(CheckboxCollectionViewCell.self)
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: 140.adjusted, height: 40.adjusted)
        slotsCollectionView.collectionViewLayout = flowLayout
        self.reloadSlotsCollectionView()
    }
    func initButtons() {
        nextButton.title = LocalizableShared.next.localized.uppercased()
        nextButton.style = Buttontype.secondary
    }

    private func initCalendar() {
        calendarView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1, cornerRadius: 11)
        calendar = AMCalendarRootViewController.setCalendar(onView: calendarView,
                                                            parentViewController: self,
                                                            selectedDate: Date(), calendarTheme: wqCalender(),
                                                            delegate: self, shouldDisablePassedDates: true,
                                                            listOfDatesToActivate: [])
    }
    func  updateCalendar(listDates: [Date]?) {
        calendar = AMCalendarRootViewController.setCalendar(onView: calendarView,
                                                            parentViewController: self,
                                                            selectedDate: Date(), calendarTheme: wqCalender(),
                                                            delegate: self, shouldDisablePassedDates: true,
                                                            listOfDatesToActivate: listDates)

    }

    /// Redirect user to NewInspectionRegisterViewController
    private func showNewInspectionRegister() {
        FahesRouter.shared
            .showNewInspectionRegister(viewModel:
                                        self.registerCarVM)

    }
    func submitActionForGuest() {
        showActivityIndicator()
        guestNewInspectionViewModel.fahesCarVM = viewModel?.fahesCarVM ?? FahesCarViewModel()
        AccountManager.shared.guestQID = guestNewInspectionViewModel.fahesCarVM.qid
        AccountManager.shared.guestMobile = guestNewInspectionViewModel.fahesCarVM.mobile
        if !guestNewInspectionViewModel.fahesCarVM.email.isEmpty {
        AccountManager.shared.guestEmail = guestNewInspectionViewModel.fahesCarVM.email
        }
        guestNewInspectionViewModel.plateTypesArray = self.viewModel?.plateTypesArray ?? []
        guestNewInspectionViewModel.checkIsOwner()
    }
    func submitActionForConnected() {
        connectedNewInspectionViewModel.fahesCarVM = viewModel?.fahesCarVM ?? FahesCarViewModel()
        let item = viewModel?.fahesCarVM ?? FahesCarViewModel()
        connectedNewInspectionViewModel.carDetails = Car(
            modelName: item.model ?? "",
            plateNumber: item.plateNumber,
            carPlateId: item.plateTypeId ?? 1,
            manufacturerName: item.name ?? "",
            expirationDate: item.expirationDate,
            ownerQid: item.qid,
            ownerFullname: connectedNewInspectionViewModel.user?.fullName,
            ownerEmail: connectedNewInspectionViewModel.user?.email,
            ownerMobile: connectedNewInspectionViewModel.user?.mobileNumber ?? ""
        )
        connectedNewInspectionViewModel.checkIsOwner()
    }

    func showBookingView() {

        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()
        let bookingView = BookingDetailsView(frame: CGRect(x: 0, y: 0, width: 300.adjusted, height: 300.adjusted))
        bookingView.setupView(stationName: viewModel?.bookingModel?.station ?? "",
                              bookingDate: viewModel?.bookingModel?.bookingDate ?? "",
                              bookingTime: viewModel?.bookingModel?.time ?? "")
        bookingView.didClickOnConfirmExit = {
            self.viewModel?.bookingBeforePayment = false
            popUpViewControler.dismiss(animated: true)
            showActivityIndicator()
            self.viewModel?.reservation()
        }
        if viewModel?.bookingModel?.pay == true {
            bookingView.didClickOnConfirmPay = {
                self.viewModel?.bookingBeforePayment = true
                popUpViewControler.dismiss(animated: true)
                showActivityIndicator()
                self.viewModel?.reservation()
            }
        } else {
            bookingView.confirmPayButton.isHidden = true
        }
        bookingView.didClickOnModify = {
            popUpViewControler.dismiss(animated: true)
        }
        bookingView.backToFahesButton.isHidden = true
        bookingView.didClickOnBackToFahes = {
            popUpViewControler.dismiss(animated: true)
            self.popToRootViewController()
        }
        popUpViewControler.contentView = bookingView
        PopupView.show(popUpViewControler, on: self)
    }
    func getAppointmentDates() {
        viewModel?.selectedDate = Date().getStringDate()
        showActivityIndicator()
        viewModel?.getAppointmentDates()
    }

    func initDropDownView() {
        // stationsDropDown
        stationsDropDown.title = LocalizableShared.station.localized + "*"
        stationsDropDown.fieldType = .dropDown(type: .stations)
        stationsDropDown.shouldSelectFirstItem = false
        guard let bookingViewModel = self.viewModel else {return}
        stationsDropDown.$selectedText
            .assign(to: \.selectedStationName, on: bookingViewModel)
            .store(in: &cancellable)

        stationsDropDown.pickerViewWillChangeValue.sink(receiveValue: {
            if self.stationsDropDown.selectedText != "" {
                self.getAppointmentDates()
                self.viewModel?.getSlots(forDate: Date())
            }
        }).store(in: &cancellable)

    }

    private func setEmptyMessage(message: String = LocalizableShared.emptySlots.localized) {
        if viewModel?.listOfSlots.count == 0 {
            self.slotsCollectionView.setEmptyMessage(message)
        } else {
            self.slotsCollectionView.restore()
        }
        self.timeLabel.isHidden = viewModel?.listOfSlots.count == 0
    }

    @IBAction func nextAction(_ sender: Any) {
        if  viewModel?.selectedSlotID != nil {
            showActivityIndicator()
//            viewModel?.reservation()
            viewModel?.checkPayOnline()
        } else {
            showErrorAlertView(descriptionMessage: LocalizableFahes.selectSationAndDate.localized, fromFahes: true)
        }
    }

}

// MARK: AMCalendarRootViewControllerDelegate
extension FahesBookingSecondViewController: AMCalendarRootViewControllerDelegate {
    func calendarRootViewController(_ calendarRootViewController: AMCalendarRootViewController,
                                    didSelectDate date: Date?) {
        viewModel?.selectedDate = date?.getStringDate() ?? Date().getStringDate()
        viewModel?.lastSelectedDate = date ?? Date()
        // Get slots
        if stationsDropDown.selectedText != "" {
            showActivityIndicator()
            viewModel?.getSlots(forDate: viewModel?.lastSelectedDate)
        }
    }
}
extension FahesBookingSecondViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel?.listOfSlots.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath)
    -> UICollectionViewCell {
        let cell: CheckboxCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath)
        cell.valueText = self.viewModel?.listOfSlots[indexPath.row].value
        cell.updateImage()
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        for iteration in 0...(viewModel?.listOfSlots.count ?? 0) {
            if iteration == indexPath.row {
                if let cell = collectionView.cellForItem(at: indexPath) as? CheckboxCollectionViewCell {
                    cell.updateImage()
                    self.viewModel?.selectedSlotID = viewModel?.listOfSlots[indexPath.row].identifier
                }

            }
            if let otherCell = collectionView.cellForItem(at: IndexPath(row: iteration, section: 0))
                as? CheckboxCollectionViewCell {
                otherCell.updateImage()
            }
        }
    }

}
