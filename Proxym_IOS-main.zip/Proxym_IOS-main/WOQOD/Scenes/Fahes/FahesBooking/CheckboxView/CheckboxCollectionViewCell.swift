//
//  CheckboxCollectionViewCell.swift
//  WOQOD
//
//  Created by rim.ktari on 05/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit

class CheckboxCollectionViewCell: UICollectionViewCell, ReusableView {
    @IBOutlet weak var checkImageView: UIImageView!
    @IBOutlet weak var valueLabel: UILabel!

    var valueText: String? {
        didSet {
            valueLabel.setText(text: valueText,
                               font: Fonts.bookFontName,
                               size: 13,
                               forgroundColor: .wqBlue,
                               align: languageIsEnglish ? .left : .right)
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        valueLabel.adjustsFontSizeToFitWidth = false
    }
    func updateImage() {
        checkImageView.image = self.isSelected ?
            UIImage(named: "ic_fahes_checked_btn") :  UIImage(named: "ic_fahes_unchecked_btn")
    }

}
