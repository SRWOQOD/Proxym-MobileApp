//
//  ReceiptDetailsViewController.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 03/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine
import MessageUI

class ReceiptDetailsViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var webView: WQWebView!
    @IBOutlet weak var sendByEmailButtonView: WQCustomButtonView!
    @IBOutlet weak var downloadButtonView: WQCustomButtonView!
    @IBOutlet weak var backToFahesButton: UIButton!
    var receiptItemVM: ReceiptViewModel?
    var receiptDetailVM = ReceiptDetailsViewModel()
    // MARK: - Private properties
    private var bindings = Set<AnyCancellable>()

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        setUpBindings()
    }

    private func initFeedbackHistoryTableView() {
        self.view.layoutIfNeeded()

    }

    private func initUI() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.popToRootViewController()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        webView.roundCorners(radius: 11)
        webView.addShadow(cornerRadius: 11.adjusted)
        titleLabel.setText(text: LocalizableFahes.inspectionPreregitration.localized.uppercased(),
                                      font: Fonts.boldFontName,
                                      size: 22, forgroundColor: .wqBlue,
                                      align: languageIsEnglish ? .left : .right)
        webView.scrollIsEnabled = false
        initButtonsView()
    }

    private func initButtonsView() {
        sendByEmailButtonView.backgroudColor = .wqDarkYellow
        sendByEmailButtonView.text = LocalizableFahes.sendByMail.localized
        sendByEmailButtonView.image = #imageLiteral(resourceName: "ic_direct_send")
        downloadButtonView.backgroudColor = .wqBlue
        downloadButtonView.text = LocalizableFahes.download.localized
        downloadButtonView.image = #imageLiteral(resourceName: "ic_download")
        backToFahesButton.title = LocalizableFahes.backToFahesMenu.localized
        backToFahesButton.titleColor = .wqBlue
        backToFahesButton.font = UIFont(name: Fonts.mediumFontName, size: 13.adjusted)
        backToFahesButton.underline()
        handleButtonsActions()
    }

    private func setupWebView() {
        webView.loadPDFFile = receiptDetailVM.receiptPDF
    }

    private func handleButtonsActions() {
        downloadButtonView.didClickOn = {
            let pdfData = self.receiptDetailVM.receiptPDF.base64ToPDF()
            let receiptNumber = self.receiptItemVM?.receiptNumber
            if savePdf(pdfData: pdfData, fileName: receiptNumber ?? "" ) {
                self.showSuccessAlertView(message: LocalizableFahes.successDownload.localized, fromFahes: true)
            }
        }
        sendByEmailButtonView.didClickOn = {
            let receiptNumber = self.receiptItemVM?.receiptNumber
            let userMail = userIsConnected ? AuthManager.shared.currentUser?.email
                ?? "" : AccountManager.shared.guestEmail
            let connectionStatus = userIsConnected
            showActivityIndicator()
            self.sendReceiptByMail(reference: receiptNumber ?? "", mail: userMail, isConnected: connectionStatus)
        }
    }

    func sendReceiptByMail(reference: String, mail: String, isConnected: Bool) {
            receiptDetailVM.sendReceiptByMail(reference: reference, mail: mail, isConnected: isConnected)
        }

    private func setUpBindings() {

        func bindViewToViewModelState() {

            receiptDetailVM.receiptDetailsState.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishFetchingPDF :
                    self.setupWebView()
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                        self.popToRootViewController()
                    }
                case .didEndSending:
                    let userEmail = userIsConnected
                        ? AuthManager.shared.currentUser?.email ?? ""
                        : AccountManager.shared.guestEmail
                    self.showSuccessAlertView(message:
                                                LocalizableFahes.successsendByMail.localized,
                                              description: userEmail,
                                              fromFahes: true)
                }
            }
            .store(in: &bindings)
        }

        bindViewToViewModelState()
        guard let itemVM = receiptItemVM else { return }
        receiptDetailVM.getReceiptPDF(receiptVM: itemVM)
    }

    @IBAction func backToFahesAction(_ sender: Any) {
        self.popToRootViewController()
    }
}
