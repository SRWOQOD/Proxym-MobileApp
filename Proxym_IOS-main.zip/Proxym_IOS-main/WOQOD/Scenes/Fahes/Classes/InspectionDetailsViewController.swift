//
//  InspectionDetailsViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 18/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class InspectionDetailsViewController: UIViewController {

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var inspectionDetailsTitle: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var inspectionView: WQItemContent!
    @IBOutlet weak var inspectionOnView: WQItemContent!
    @IBOutlet weak var plateTypeView: WQItemContent!
    @IBOutlet weak var tableView: DynamicTableView!
    @IBOutlet weak var legalEvaluationTitleLabel: UILabel!
    @IBOutlet weak var legalEvaluationStatusLabel: UILabel!
    @IBOutlet weak var technicalEvaluationTitleLabel: UILabel!
    @IBOutlet weak var technicalEvaluationStatusLabel: UILabel!

    // MARK: - Public properties
    private var bindings = Set<AnyCancellable>()

    // MARK: - Private properties
    var inspectionViewModel: InspctionViewModel?

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        setUpBindings()
    }

    // MARK: - Private Methods

    private func updateUI() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        inspectionDetailsTitle.setText(text: LocalizableFahes.inspectionDetailsTitle.localized.uppercased(),
                                       font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue,
                                       align: languageIsEnglish ? .left : .right)
        inspectionView.title = LocalizableFahes.inspection.localized
        inspectionOnView.title = LocalizableFahes.inspectionOn.localized
        plateTypeView.title = LocalizableFahes.inspectionDetailsPlateDetails.localized
        inspectionView.value = ""
        inspectionOnView.value = ""
        plateTypeView.value = ""
        setupTableView()
    }

    private func updateFields() {
        let inspectionDetails = inspectionViewModel?.inspectionsHistory
        inspectionView.value = inspectionDetails?.inspection
        inspectionOnView.value = inspectionDetails?.inspectionOn.getDate("yyyy-MM-dd HH:mm:ss").toLongString()
        plateTypeView.value = (inspectionDetails?.plateNumber ?? "") + " - " + (inspectionDetails?.plateType ?? "")
    }

    private func updateEvaluationViewFields() {
        let inspectionDetails = inspectionViewModel?.inspectionsHistory
        legalEvaluationTitleLabel.setText(
            text: LocalizableFahes.inspectionDetailsLegalInformationsTitle.localized,
            font: Fonts.mediumFontName,
            size: 15,
            forgroundColor: .wqBlue,
            align: .center)
        legalEvaluationStatusLabel.setText(
            text: inspectionDetails?.legalEvaluation == "0" ? LocalizableShared.passed.localized.uppercased()
                : LocalizableShared.failed.localized.uppercased(),
            font: Fonts.boldFontName,
            size: 15,
            forgroundColor: inspectionDetails?.legalEvaluation == "0" ? .wqGreen
                : .wqRed,
            align: .center)
        technicalEvaluationTitleLabel.setText(
            text: LocalizableFahes.inspectionDetailsTechnicalEvaluation.localized,
            font: Fonts.mediumFontName,
            size: 15,
            forgroundColor: .wqBlue,
            align: .center)
        technicalEvaluationStatusLabel.setText(
            text: inspectionDetails?.technicalEvaluation == "0" ? LocalizableShared.passed.localized.uppercased()
                : LocalizableShared.failed.localized.uppercased(),
            font: Fonts.boldFontName, size: 15,
            forgroundColor: inspectionDetails?.technicalEvaluation == "0" ? .wqGreen
                : .wqRed,
            align: .center)
    }

    private func setUpBindings() {
        inspectionViewModel?.inspecDetailsState.sink { (state) in
            hideActivityIndicator()
            switch state {
            case .finishGettingHistory :
                self.updateFields()
                self.updateEvaluationViewFields()
            case .finishGettingDetails :
                self.tableView.reloadData()
            case .error(let error) :
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
            case .errorGettingInspectionDetails:
                self.tableView.reloadData()
            }
        }
        .store(in: &bindings)
        showActivityIndicator()
        inspectionViewModel?.getInspectionsHistory()
    }

    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.registerCellNib(FahesInspectionDetailsSectionCell.self)
        tableView.registerCellNib(FahesInspectionDetailsCustomCell.self)
        tableView.separatorStyle = .none
        tableView.estimatedSectionHeaderHeight = 50
        tableView.sectionHeaderHeight = UITableView.automaticDimension
        if #available(iOS 15.0, *) {
            tableView.sectionHeaderTopPadding = 0
        }
    }

}

extension InspectionDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return inspectionViewModel?.sectionsItems.count ?? 0
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let item = inspectionViewModel?.sectionsItems[section]
            ?? InspectionDetailsSectionViewModel(title: "", isHidden: false, items: nil)
        if item.isHidden {
            return 0
        } else {
            return item.items?.count ?? 0
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
                withIdentifier: "FahesInspectionDetailsCustomCell", for: indexPath)
                as? FahesInspectionDetailsCustomCell
        else {return UITableViewCell()}
        let item = inspectionViewModel?.sectionsItems[indexPath.section]
            .items?[indexPath.row] ?? InspectionDetailsViewModel(detail: nil)
        cell.setup(viewModel: item)
        return cell
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FahesInspectionDetailsSectionCell")
                as? FahesInspectionDetailsSectionCell
        else {return UITableViewCell()}
        let item = inspectionViewModel?.sectionsItems[section]
            ?? InspectionDetailsSectionViewModel(title: "", isHidden: false, items: nil)
        cell.setup(viewModel: item)
        cell.button.tag = section
        cell.button.addTarget(self, action: #selector(tapSection(sender:)), for: .touchUpInside)
        return cell
    }

    @objc func tapSection(sender: UIButton) {
        self.inspectionViewModel?.sectionsItems[sender.tag].isHidden.toggle()
        self.tableView.reloadData()
        }
}
