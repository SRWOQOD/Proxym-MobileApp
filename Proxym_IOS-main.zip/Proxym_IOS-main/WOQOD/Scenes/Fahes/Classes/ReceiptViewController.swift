//
//  ReceiptViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class ReceiptViewController: UIViewController {

    // MARK: - Public properties
    var listOfReceiptsViewModel = ListOfReceiptsViewModel()
    // MARK: - Private properties
    private var bindings = Set<AnyCancellable>()

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var receiptTitle: UILabel!
    @IBOutlet weak var listReceiptTableView: DynamicTableView!

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        receiptTitle.setText(text: LocalizableFahes.listOfReceipt.localized.uppercased(),
                             font: Fonts.boldFontName,
                             size: 22, forgroundColor: .wqBlue)
        initFeedbackHistoryTableView()

        setUpBindings()
    }

    private func initFeedbackHistoryTableView() {
        self.view.layoutIfNeeded()
        listReceiptTableView.registerCellNib(ReceiptTableViewCell.self)

        listReceiptTableView.dataSource = self
        listReceiptTableView.delegate = self

        listReceiptTableView.separatorStyle = .none
        listReceiptTableView.separatorColor = .clear

        listReceiptTableView.tableFooterView = UIView()
    }

    /// Display a message informing user that he has no receipts
    private func setEmptyMessage() {
        if self.listOfReceiptsViewModel.allReceipts.count == 0 {
            self.listReceiptTableView.setEmptyMessage(LocalizableFahes.noReceipts.localized)
        } else {
            self.listReceiptTableView.restore()
        }
    }

    /// reload tableView
    private func reloadTableView() {
        self.listReceiptTableView.reloadData()
        self.setEmptyMessage()
    }

    private func downloadPDF() {
        let pdfData = self.listOfReceiptsViewModel.receiptPDF.base64ToPDF()
        let receiptNumber = self.listOfReceiptsViewModel.receiptNumber
        if savePdf(pdfData: pdfData, fileName: receiptNumber ) {
            self.showSuccessAlertView(message: LocalizableFahes.successDownload.localized, fromFahes: true)
        }
    }

    private func setUpBindings() {

        func bindViewToViewModelState() {

            listOfReceiptsViewModel.receiptsState.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishFetchingList :
                    self.reloadTableView()
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
                case .finishFetchingPDF:
                    self.downloadPDF()
                }
            }
            .store(in: &bindings)
        }

        bindViewToViewModelState()
        showActivityIndicator()
        listOfReceiptsViewModel.getReceipts()
    }
}

extension ReceiptViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listOfReceiptsViewModel.allReceipts.count

    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell =
                tableView.dequeueReusableCell(withIdentifier: "ReceiptTableViewCell", for: indexPath)
                as? ReceiptTableViewCell
        else {return UITableViewCell()}
        let item = listOfReceiptsViewModel.allReceipts[indexPath.row]
        cell.setup(receiptViewModel: item)
        cell.didClickOnPreviewReceipt = {
            FahesRouter.shared.showFahesReceiptDetailskWith(viewModel: item)
        }
        cell.didClickOnDownloadReceipt = {
            self.listOfReceiptsViewModel.receiptNumber = item.receiptNumber
            self.listOfReceiptsViewModel.getReceiptPDF(receiptVM: item)
        }

        return cell

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableView.automaticDimension

    }

}
