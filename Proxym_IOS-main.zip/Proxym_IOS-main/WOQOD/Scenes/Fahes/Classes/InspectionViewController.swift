//
//  InspectionViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class InspectionViewController: UIViewController {

    // MARK: - Public properties
    var inspectionViewModel = InspctionViewModel()

    // MARK: - Private properties
    private var bindings = Set<AnyCancellable>()

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var listCarsTableView: DynamicTableView!

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()

        initUI()
        setUpBindings()
    }
    // MARK: - Private Methods

    private func initUI() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        titleLabel.setText(text: LocalizableFahes.inspectionReport.localized.uppercased(),
                                      font: Fonts.boldFontName,
                                      size: 22, forgroundColor: .wqBlue,
                                      align: languageIsArabic ? .right : .left)
        initFeedbackHistoryTableView()
    }

    private func initFeedbackHistoryTableView() {
        self.view.layoutIfNeeded()
        listCarsTableView.registerCellNib(InspectionReportTableViewCell.self)

        listCarsTableView.dataSource = self
        listCarsTableView.delegate = self

        listCarsTableView.separatorColor = UIColor.clear
        listCarsTableView.separatorStyle = .none
    }

    /// Display a message informing user that he has no cars
    private func setEmptyMessage() {
        if self.inspectionViewModel.listCars.count == 0 {
            self.listCarsTableView.setEmptyMessage( LocalizableWoqode.manageCarNoCarsFound.localized)
        } else {
            self.listCarsTableView.restore()
        }
    }

    private func reloadTableView() {
        self.listCarsTableView.reloadData()
        self.setEmptyMessage()
    }

    private func setUpBindings() {

        func bindViewToViewModelState() {

            inspectionViewModel.state.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading :
                    // stop loader
                    self.reloadTableView()
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
                case .loading:
                    // show loader
                    break
                }
            }
            .store(in: &bindings)
        }

        bindViewToViewModelState()
        inspectionViewModel.getListOfCars()
        showActivityIndicator()
    }

    /// go to inspectionDetailsViewController
    private func showInspectionDetails() {

        let inspectionDetailsViewController: InspectionDetailsViewController =
            InspectionDetailsViewController.instantiate(appStoryboardName: AppStoryboard.fahes)

        inspectionDetailsViewController.inspectionViewModel = inspectionViewModel

        FahesRouter.shared.showInspectionDetailskWith(viewController: inspectionDetailsViewController)
    }

}

extension InspectionViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // for test
//        return 10
        return inspectionViewModel.listCars.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell =
                tableView.dequeueReusableCell(withIdentifier: "InspectionReportTableViewCell", for: indexPath)
                as? InspectionReportTableViewCell
        else {return UITableViewCell()}
//        //For test
//        let item = inspectionViewModel.listCars.first
        let item = inspectionViewModel.listCars[indexPath.row]
        cell.setup(carVM: item)
        cell.tapCellAction = {
            // This is for test: inspectionViewModel.selectedItem =
            // CarViewModel.init(car: Car(plateNumber: "355654", ownerQid: "28278800821", plateTypeId: 1))
            self.inspectionViewModel.selectedItem = self.inspectionViewModel.listCars[indexPath.row]
            self.showInspectionDetails()
        }
        return cell

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableView.automaticDimension

    }

}
