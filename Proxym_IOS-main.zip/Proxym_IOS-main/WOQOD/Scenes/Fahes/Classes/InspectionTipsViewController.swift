//
//  InspectionTipsViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 07/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

enum InspectionTipsCellType: Int {

    case firstParagraph = 1
    case frequencyCard = 2

    init(fromRawValue: Int) {
        self = InspectionTipsCellType(rawValue: fromRawValue) ?? .firstParagraph
    }
}

class InspectionTipsViewController: UIViewController {

    @IBOutlet weak var inspectionRequirementsTableView: UITableView!
    @IBOutlet weak var aboutVCTitle: UILabel!

    let inspectionFrequencyElements =
    [InspectionFrequencyModel(type: LocalizableFahes.inspectionTipsFirstVehicleType.localized,
                                  frequency:
                                    LocalizableFahes.inspectionTipsFirstFrequency.localized),
                                       InspectionFrequencyModel(type:
   LocalizableFahes.inspectionTipsSecondVehicleType.localized,
         frequency: LocalizableFahes.inspectionTipsSecondFrequency.localized),
          InspectionFrequencyModel(type: LocalizableFahes.inspectionTipsThirdVehicleType.localized,
       frequency: LocalizableFahes.inspectionTipsFirstFrequency.localized),
       InspectionFrequencyModel(type: LocalizableFahes.inspectionTipsFourthVehicleType.localized,
                                frequency: LocalizableFahes.inspectionTipsFirstFrequency.localized),
           InspectionFrequencyModel(type: LocalizableFahes.inspectionTipsFifthVehicleType.localized,
                                    frequency: LocalizableFahes.inspectionTipsFirstFrequency.localized)]

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }

    fileprivate func initUI() {
        aboutVCTitle.setText(text: LocalizableFahes.inspectionTipsTitle.localized,
                             font: Fonts.boldFontName, size: 15, forgroundColor: .wqBlue)

        inspectionRequirementsTableView.registerCellNib(ReceiptTableViewCell.self)
        initTableView()
    }

    fileprivate func initTableView() {

        inspectionRequirementsTableView.registerCellNib(InspectionTipsParagraphTableViewCell.self)
        inspectionRequirementsTableView.registerCellNib(InspectionTipCardTableViewCell.self)
        inspectionRequirementsTableView.dataSource = self
        inspectionRequirementsTableView.delegate = self
    }
}

extension InspectionTipsViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if section == InspectionTipsCellType.firstParagraph.rawValue {
            return 1 // one paragraph
        } else {
            return inspectionFrequencyElements.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if indexPath.row == 0 {
            // First paragraph Cell
           guard let cell =
                    tableView.dequeueReusableCell(withIdentifier: "InspectionTipsParagraphTableViewCell",
                                                  for: indexPath)
                    as? InspectionTipsParagraphTableViewCell
           else {return UITableViewCell()}
            return cell
        } else {
            // Inspection frequency requirements Cell
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "InspectionTipCardTableViewCell",
                                                           for: indexPath)
                as? InspectionTipCardTableViewCell
            else {return UITableViewCell()}
            cell.setUp(inspectionFrequency: inspectionFrequencyElements[indexPath.row])
            return cell

        }

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension

    }

}
