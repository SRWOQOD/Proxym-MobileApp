//
//  InspectionBookingListViewController.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 10/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine

class InspectionBookingListViewController: UIViewController {

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: DynamicTableView!

    // MARK: - Public properties
    var listBookingsViewModel = InspectionBookingListViewModel()

    // MARK: - Private properties
    private var bindings = Set<AnyCancellable>()

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()

        setUpBindings()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showActivityIndicator()
        listBookingsViewModel.listBooking.removeAll()
        listBookingsViewModel.getPlateTypes()
        listBookingsViewModel.getBooking()
    }

    private func initUI() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        titleLabel.setText(text: LocalizableFahes.cancelModifyBooking.localized.uppercased(),
                             font: Fonts.boldFontName,
                             size: 22, forgroundColor: .wqBlue,
                             align: languageIsEnglish ? .left : .right)
        initTableView()
    }
    private func initTableView() {
        self.view.layoutIfNeeded()
        tableView.registerCellNib(InspectionBookingTableViewCell.self)

        tableView.dataSource = self
        tableView.delegate = self

        tableView.separatorStyle = .none
        tableView.separatorColor = .clear

        tableView.tableFooterView = UIView()
    }

    /// Display a message informing user that he has no receipts
    private func setEmptyMessage() {
        if self.listBookingsViewModel.listBooking.count == 0 {
            self.tableView.setEmptyMessage(LocalizableFahes.emptyReservation.localized)
        } else {
            self.tableView.restore()
        }
    }

    /// reload tableView
    private func reloadTableView() {
        self.tableView.reloadData()
        self.setEmptyMessage()
    }

    private func setUpBindings() {
            listBookingsViewModel.state.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading :
                    // stop loader
                    self.reloadTableView()
                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
                case .loading:
                    // show loader
                    break
                }
            }
            .store(in: &bindings)
    }

}

extension InspectionBookingListViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listBookingsViewModel.listBooking.count

    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell =
                tableView.dequeueReusableCell(withIdentifier: "InspectionBookingTableViewCell", for: indexPath)
                as? InspectionBookingTableViewCell
        else {return UITableViewCell()}
        let item = listBookingsViewModel.listBooking[indexPath.row]
        cell.tapCellAction = {
            let carItem = Car(
                plateNumber: item.booking?.plateNumber ?? "",
                carPlateId: self.listBookingsViewModel.getPlateID(forName: item.booking?.plateTypeName ?? "") ?? 1,
                ownerQid: self.listBookingsViewModel.user?.qid,
                ownerFullname: self.listBookingsViewModel.user?.fullName,
                ownerEmail: self.listBookingsViewModel.user?.email,
                ownerMobile: self.listBookingsViewModel.user?.mobileNumber ?? "")

            FahesRouter.shared.showModifyBookingDetailsViewController(
                bookingModel: item.booking, fahesCar: carItem)
        }
        cell.setup(rowVM: item)

        return cell

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableView.automaticDimension

    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }

}
