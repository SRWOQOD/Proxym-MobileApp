//
//  FahesInspectionPayementViewController.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 09/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesInspectionPayementViewController: UIViewController {

    @IBOutlet weak var fahesImageView: UIImageView!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var creditCardButton: WQCustomButtonView!
    @IBOutlet weak var debitCardButton: WQCustomButtonView!
    @IBOutlet weak var continueButton: WQButton!
    @IBOutlet weak var cardStackView: UIStackView!
    @IBOutlet weak var continueButtonHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var cardStackViewHeightConstraint: NSLayoutConstraint!
    var cancellable = Set<AnyCancellable>()
    var viewModel: FahesPaymentViewModel?
    var paymentType: PaymentType?
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        bindData()

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showActivityIndicator()
        self.viewModel?.getTermsOfUseFahesPaymentText()
    }

    private func bindData() {
        let stateHandler: ((FahesPaymentState) -> Void) = { (state) in
            hideActivityIndicator()
            switch state {
            case .finishFetchingData:
                break
            case .finishCollectingWebViewData:
                self.showPaymentView()
            case .failedCollectingWebViewData:
                self.showErrorAlertView(descriptionMessage: LocalizableShared.errorUnexpectedMessage.localized)
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
            case .finishFreeCar:
                FahesRouter.shared.showFahesReceiptDetailskWith(viewModel: self.viewModel?.receiptViewModel)
            case .finishGettingStaticText:
                self.updateStaticTextView()
            }
        }

        viewModel?.fahesPaymentState
            .sink(receiveValue: stateHandler)
            .store(in: &cancellable)

    }

    func showPaymentView() {
        FahesRouter.shared.openPaymentVC { (viewC) in
            switch self.paymentType {
            case .creditCard:
                viewC.paymentVM = PaymentViewModel(paymentRequestModel: self.viewModel?.paymentRequestModel
                                                    ?? PaymentRequestModel() ,
                                                   signature: self.viewModel?.signatureValue! ?? "" )
                viewC.paymentType = self.paymentType
            default:
                viewC.paymentVM = PaymentViewModel(qpayRequestModel: self.viewModel?.paymentResponseModel
                                                   ?? QPayParamsResponseModel(),
                                                   refererUrl: self.viewModel?.refererUrl ?? "",
                                                   qpayUrl: self.viewModel?.qpayURL ?? "")
                viewC.paymentType = self.paymentType
            }


        }
    }

    private func initUI() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.popToRootViewController()}
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)
        titleLabel.setText(text: LocalizableFahes.inspectionPreregitration.localized.uppercased(),
                                      font: Fonts.boldFontName,
                                      size: 22, forgroundColor: .wqBlue,
                                      align: languageIsArabic ? .right : .left)
        initButtonsView()
        fahesImageView.setTintedImage(image: UIImage(named: "ic_fahes"),
                                      color: UIColor.wqBlue.withAlphaComponent(0.05) )
    }
    private func updateStaticTextView() {
        textView.isScrollEnabled = false
        textView.isUserInteractionEnabled = false
        textView.htmlAttributedString(text: viewModel?.fahesPaymenttaticText ?? "",
                                      fontSize: 14,
                                      fontName: Fonts.bookFontName)
        hideElementsIfNeeded()
    }

    private func initButtonsView() {
        creditCardButton.backgroudColor = .wqBlue
        creditCardButton.text = LocalizableFahes.paymentModeCreditCard.localized
        creditCardButton.image = #imageLiteral(resourceName: "ic_creditCard")
        debitCardButton.backgroudColor = .wqBlue
        debitCardButton.text = LocalizableFahes.paymentModeDebitCard.localized
        debitCardButton.image = #imageLiteral(resourceName: "ic_debitCard")
        creditCardButton.didClickOn  = {
            self.paymentType = .creditCard
            showActivityIndicator()
            self.viewModel?.createTransation()
            self.viewModel?.submit(paymentType: .creditCard)
        }
        debitCardButton.didClickOn = {
            self.paymentType = .debitCard
            showActivityIndicator()
            self.viewModel?.createQpayTransaction()
            self.viewModel?.submit(paymentType: .debitCard)
        }
        continueButton.title = LocalizableShared.commonContinue.localized.uppercased()
        continueButton.style = Buttontype.secondary
        continueButton.isHidden = true
    }

    private func hideElementsIfNeeded() {
        if viewModel?.preRegistrationFee?.totalAmount ?? 0.0 > 0.0 {
            continueButton.isHidden =  true
            cardStackViewHeightConstraint.constant = 110
        } else {
            continueButton.isHidden = false
        }
        creditCardButton.isHidden =  viewModel?.preRegistrationFee?.totalAmount == 0.0
        debitCardButton.isHidden =  viewModel?.preRegistrationFee?.totalAmount == 0.0 || self.viewModel?.debitCardHidden ?? true
        continueButton.isHidden ? continueButtonHeightConstraint.constant = 0.0 : ()
    }

    @IBAction func continueAction(_ sender: Any) {
        showActivityIndicator()
        self.viewModel?.createTransation()
        self.viewModel?.createFreeTransactionUUID()
    }
}
