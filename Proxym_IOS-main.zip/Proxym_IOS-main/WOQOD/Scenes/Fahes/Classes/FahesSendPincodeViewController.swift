//
//  FahesSendPincodeViewController.swift
//  WOQOD
//
//  Created by rim ktari on 11/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesSendPincodeViewController: UIViewController {

    @IBOutlet weak var otpInsertView: WQOTPInsertView!

    @IBOutlet weak var headerView: WQHeaderView!
    var viewModel: FahesCarRegisterViewModel?
    var cancellable = Set<AnyCancellable>()

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()

        setUpBindings()
    }
    private func sendPincode() {
        showActivityIndicator()
        viewModel?.sendPinCode()

    }
    func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    private func setUpBindings() {
        sendPincode()

        func bindViewToViewModelState() {
            viewModel?.fahesCarState.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .pinCodeSent :
                    break
                case .validOTP :
                    self.showCarRegisterVC()

                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message,
                                            fromFahes: true) {
                        self.otpInsertView.otpCodeView.clearAllFields()
                    }
                default : break
                }
            }
            .store(in: &cancellable)
        }
        bindViewToViewModelState()
    }
    // todo
    func initUI() {
        initHeaderView()
        otpInsertView.verificationImage = #imageLiteral(resourceName: "ic_verification_phone")
        otpInsertView.titleText = LocalizableShared.codeVerification.localized
        otpInsertView.messageText = LocalizableShared.sentToPhoneMessage.localized
        otpInsertView.confirmButtonTitle = LocalizableShared.confirm.localized
        otpInsertView.otpCodeView.configure(with: 6)
        otpInsertView.resendButtonTitle =  LocalizableShared.resendCode.localized
        otpInsertView.resendIsTapped = { self.sendPincode() }
        otpInsertView.confirmIsTapped = {
            self.viewModel?.entredPinCode = self.otpInsertView.typedCode
            showActivityIndicator()
            self.viewModel?.validatePinCode()
        }
    }

    /// Redirect user to FahesCarRegisterViewController
    private func showCarRegisterVC() {
        FahesRouter.shared
            .showCarRegisterVC(viewModel: self.viewModel)

    }

}
