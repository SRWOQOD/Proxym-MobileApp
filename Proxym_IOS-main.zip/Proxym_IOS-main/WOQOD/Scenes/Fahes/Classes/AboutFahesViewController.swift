//
//  AboutFahesViewController.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 06/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class AboutFahesViewController: UIViewController {

    @IBOutlet weak var webView: WQWebView!
    @IBOutlet weak var aboutVCTitle: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        aboutVCTitle.setText(text: LocalizableFahes.aboutTitle.localized,
                             font: Fonts.boldFontName, size: 15,
                             forgroundColor: .wqBlue)
        webView.loadHtmlPageWithName = languageIsEnglish ? .aboutFahesEN :  .aboutFahesAR

    }

}
