//
//  FahesStationsViewController.swift
//  WOQOD
//
//  Created by rim ktari on 6/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import IBMMobileFirstPlatformFoundation
import Foundation
import Combine
import GoogleMaps

class FahesStationsViewController: UIViewController {

    // MARK: - Private properties
    private var bindings = Set<AnyCancellable>()
    private var mapVC: MapViewController?
    private var fahesViewModel = FahesStationsViewModel()

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        LocationsRouter.shared.resetSharedItems()
        initUI()
        setUpBindings()
    }

    override func viewWillAppear(_ animated: Bool) {
         fahesViewModel.resetStationss()
    }

    // MARK: - Private methods

    private func initUI() {
        title = LocalizableFahes.title.localized
        setUpMap()
        LocationsRouter.shared.filterVC =
            LocationsFilterViewController.instantiate(appStoryboardName: AppStoryboard.locations)
        mapVC?.didSelectFilter = {self.selectFilter()}
        mapVC?.autoCompleteView.didTapOnSearchField = { searchResult, searchValue in
            if (searchResult?.isEmpty ?? true) && (searchValue?.isEmpty ?? true) {
                self.mapVC?.mapVM.isFromSearch = false
                self.mapVC?.mapVM.places = self.fahesViewModel.stationsList
            } else {
                self.reloadMapWithSearchData(searchResult: searchResult ?? [])
            }
        }
        fahesViewModel.stationsListDidChange.sink {
            self.reloadMap()

        }.store(in: &bindings)
    }

    private func selectFilter() {
        if LocationsRouter.shared.shouldResetSelectedFeatures {
            self.resetFilterItemOnBack()
        }
        LocationsRouter.shared.showFahesShafafStationsFilter(
            viewC: self, listOfPlaces: self.fahesViewModel.initialValuesPlaces, strategy: FahesStrategy())
    }
    private func resetFilterItemOnBack() {
        LocationsRouter.shared.filterVC?.view.setNeedsDisplay()
        LocationsRouter.shared.filterVC?.filterView.pickedFeature = LocationsRouter.shared.sharedSelectedFeatures
        LocationsRouter.shared.filterVC?.filterView.searchByServicesView
            .pickedService = LocationsRouter.shared.sharedSelectedServices
        LocationsRouter.shared.filterVC?.filterView.searchByServicesView.slider.slider
            .pickedValue = LocationsRouter.shared.sharedSelectedTime
        LocationsRouter.shared.filterVC?.filterView.searchByZoneView
            .selectedZoneId = LocationsRouter.shared.sharedSelectedArea
        LocationsRouter.shared.filterVC?.filterView.slider.slider
            .pickedValue = LocationsRouter.shared.sharedSelectedDistance
    }

    private func setUpMap() {

        mapVC  = MapViewController.instantiate(appStoryboardName: AppStoryboard.main) as? MapViewController
        mapVC?.locationsElementPath = .secondLevel
        self.addViewController(targetView: self.view, targetViewController: mapVC)
    }

    private func reloadMap() {
        mapVC?.mapVM.places = fahesViewModel.stationsList
        LocationsRouter.shared.filterVC?.shouldUpdateZoomMapForSelectedArea = { selectedArea in
            if selectedArea != nil {
                self.mapVC?.resetZoomMap(withLatitude: Double((selectedArea?.latitude)!),
                                         longitude: Double((selectedArea?.longitude)!))
            } else {
                self.mapVC?.resetZoomMap()
            }
        }
    }

    private func reloadMapWithSearchData(searchResult: [Place]) {
        mapVC?.mapVM.isFromSearch = true
        mapVC?.mapVM.places = searchResult
    }

    private func setUpBindings() {

        func getFahesStations() {
            fahesViewModel.getFahesStations()
            showActivityIndicator()
        }

        func bindViewToViewModelState() {

            fahesViewModel.state.sink { (state) in
                hideActivityIndicator()
                switch state {
                case .finishedLoading :
                    LocationsManager.shared.locations = self.fahesViewModel.stationsList
                    LocationsManager.shared.filtredLocations = self.fahesViewModel.stationsList

                case .error(let error) :
                    self.showErrorAlertView(descriptionMessage: error.message)
                case .loading:
                    break
                }
            }
            .store(in: &bindings)
        }

        bindViewToViewModelState()
        getFahesStations()
    }

}
