//
//  FahesMenuViewController.swift
//  WOQOD
//
//  Created by Oumayma Guefrej on 8/29/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesMenuViewController: UIViewController {

    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var fahesImageView: UIImageView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var fahesTitle: UILabel!
    @IBOutlet weak var subMenuView: SubMenuView!

    // MARK: - Private Properties
    private var cancellable = Set<AnyCancellable>()
    private let fahesMenuVM = FahesMenuViewModel()
    var fromBanner: Bool = false
    var appRedirection: AppRedirectionType?
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        navigateToFahesSubmenu()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fahesMenuVM.initFahesMenuItems()
        subMenuView.menuItems = fahesMenuVM.menuItems
        self.subMenuView.reloadElements()
        fahesTitle.setText(text: LocalizableFahes.title.localized.uppercased(),
                           font: Fonts.boldFontName,
                           size: 22, forgroundColor: .wqBlue)
        bindData()
    }

    /// Init fahes sub menu items
    func initFahesSubMenu() {
        fahesMenuVM.initFahesMenuItems()
        subMenuView.menuItems = fahesMenuVM.menuItems
        self.subMenuView.reloadElements()

        self.view.layoutIfNeeded()
    }
    
    func navigateToFahesSubmenu() {
        subMenuView.subMenuVM.selectedItem.sink { (menuElement) in
            DispatchQueue.main.async {
                if let viewC = menuElement.viewController {
                    FahesRouter.shared.showFahesWith(viewController: viewC)
                } else if
                    let viewControllerType = menuElement.viewControllerType, let storyboard = menuElement.storyboard {
                    let viewController =  viewControllerType.instantiate(appStoryboardName: storyboard)
//                    if viewController is FahesStationsViewController {
//                        AppRouter.shared.updateViewController(viewController)
//                    } else {
                        FahesRouter.shared.showFahesWith(viewController: viewController)
//                    }

                }
            }
        }.store(in: &cancellable)
    }

    /// Init fahes sub menu items
    func bindData() {
        if !(fromBanner) {
            showActivityIndicator()
        }
        fahesMenuVM.isReservationHidden()
        fahesMenuVM.state.sink { _ in
            hideActivityIndicator()
            self.initFahesSubMenu()
            if self.fromBanner {
                switch self.appRedirection {
                case .fahesBookVehicle:
                    if !(self.fahesMenuVM.reservationHidden) {
                        if userIsConnected {
                            let viewController = ConnectedNewInspectionViewController.instantiate(
                                appStoryboardName: AppStoryboard.fahes) as? ConnectedNewInspectionViewController
                            viewController?.isBooking = true
                            self.push(viewController: viewController ?? ConnectedNewInspectionViewController())
                        } else {
                            let viewController = FahesBookingFirstViewController.instantiate(
                                appStoryboardName: AppStoryboard.fahes)
                            self.push(viewController: viewController)
                        }
                    }
                case .fahesOnlinePayment:
                    if userIsConnected {
                        let viewController = ConnectedNewInspectionViewController.instantiate(
                            appStoryboardName: AppStoryboard.fahes) as? ConnectedNewInspectionViewController
                        viewController?.isBooking = false
                        self.push(viewController: viewController ?? ConnectedNewInspectionViewController())
                    } else {
                        let viewController = GuestNewInspectionViewController.instantiate(
                            appStoryboardName: AppStoryboard.fahes)
                        self.push(viewController: viewController)
                    }
                case .fahesCancelModifyBooking:
                    if !(self.fahesMenuVM.reservationHidden) {
                        if userIsConnected {
                            let viewController = InspectionBookingListViewController.instantiate(
                                appStoryboardName: AppStoryboard.fahes) as? InspectionBookingListViewController
                            self.push(viewController: viewController ?? InspectionBookingListViewController())
                        } else {
                            let viewController = ModifyBookingDetailsViewController.instantiate(
                                appStoryboardName: AppStoryboard.fahes)
                            self.push(viewController: viewController)
                        }
                    }
                case .fahesStations:
                    let viewController = FahesStationsViewController.instantiate(
                        appStoryboardName: AppStoryboard.fahes)
                    self.push(viewController: viewController)
                case .aboutFahes:
                    let viewController = WQStaticScreenViewController.instantiate(
                        appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
                    viewController?.strategy = AboutFahesStrategy()
                    self.push(viewController: viewController ?? WQStaticScreenViewController())
                case .fahesInspectionTips:
                    let viewController = WQStaticScreenViewController.instantiate(
                        appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
                    viewController?.strategy = InspectionTipsStrategy()
                    self.push(viewController: viewController ?? WQStaticScreenViewController())
                default: break
                }
            }
        }.store(in: &cancellable)
    }

    private func backHome() {
        self.popToRootViewController()
        AppRouter.shared.reloadMenuView()
    }

    func initUI() {
        fahesTitle.setText(text: LocalizableFahes.title.localized.uppercased(),
                           font: Fonts.boldFontName,
                           size: 22, forgroundColor: .wqBlue)
        initBgViews()
        headerView.menuAction = presentMenu
    }

    func initBgViews() {
        containerView.border(borderColor: UIColor.white, borderwidth: 1)
        containerView.roundTopCorners(radius: 15)

        fahesImageView.setTintedImage(image: UIImage(named: "ic_fahes"),
                                      color: UIColor.wqBlue.withAlphaComponent(0.05) )
    }

}
