//
//  FahesCarRegisterViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/5/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FahesCarRegisterViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var addButton: WQButton!

    @IBOutlet weak var fahesImageView: UIImageView!
    @IBOutlet weak var cancelButton: WQButton!
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var contentView: UIView!
    // MARK: - Properties
    var viewModel: FahesCarRegisterViewModel?
    var cancellable = Set<AnyCancellable>()

    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()

        initUI()
        bindData()
    }
    // MARK: - Private Methods
    private func bindData() {
        viewModel?.fahesCarState.sink { (state) in
            hideActivityIndicator()
            switch state {

            case .didAddCar :
                self.showSuccessAlertView(message: LocalizableFahes.successAddingNewCar.localized.uppercased(),
                                          fromFahes: true) {
                    self.popToViewController(ofClass: ConnectedNewInspectionViewController.self)
                }
            case .error(let error) :
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.pop()
                }
            default : break
            }
        }
        .store(in: &cancellable)

    }
    private func initUI() {
        cancelButton.title = LocalizableShared.cancel.localized.uppercased()
        cancelButton.style  = Buttontype.secondary

        addButton.title = LocalizableShared.add.localized.uppercased()
        addButton.backgroundColor = .wqOrange
        titleLabel.setText(text: LocalizableFahes.carRegistrationConfirmation.localized.uppercased(),
                           font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue,
                           align: languageIsArabic ? .right : .left)
        setUpStackView()
        initBgViews()
        initHeaderView()
    }

    private func setUpStackView() {
        viewModel?.registrationElements.forEach({
            let itemContent = WQItemContent()

            itemContent.title = $0.title
            itemContent.value = $0.value
            self.stackView.addArrangedSubview(itemContent)
        })

    }
    func initBgViews() {
        contentView.border(borderColor: UIColor.white, borderwidth: 1)
        contentView.roundTopCorners(radius: 15)

        fahesImageView.setTintedImage(image: UIImage(named: "ic_fahes"),
                                      color: UIColor.wqBlue.withAlphaComponent(0.05) )
    }

    private func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.popToRootViewController()}
    }

    @IBAction func cancelAction(_ sender: Any) {
        self.popToViewController(ofClass: ConnectedNewInspectionViewController.self)
    }

    @IBAction func addAction(_ sender: Any) {
        showActivityIndicator()
        viewModel?.addCar()
    }

}
