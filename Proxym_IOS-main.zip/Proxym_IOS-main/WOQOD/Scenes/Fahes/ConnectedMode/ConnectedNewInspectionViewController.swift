//
//  ConnectedNewInspectionViewController.swift
//  WOQOD
//
//  Created by rim ktari on 9/30/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class ConnectedNewInspectionViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var submitButton: WQButton!
    @IBOutlet weak var subtitleLabel: UILabel!

    @IBOutlet weak var qidItemContent: WQItemContent!

    @IBOutlet weak var carPlateTFView: WQTextFieldView!
    @IBOutlet weak var plateTypesTFView: WQDropDownMenu!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var fahesImageView: UIImageView!
    @IBOutlet weak var deleteCarDescriptionLabel: UILabel!

    // MARK: - Properties

    let viewModel =  ConnectedNewInspectionViewModel()
    var cancellable = Set<AnyCancellable>()
    var isBooking: Bool = false
    var bookVehicleViewModel = BookVehicleInspectionViewModel()
    // MARK: - Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        bindData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showActivityIndicator()
        viewModel.fetchDataForConnectedUser()
        carPlateTFView.textField.text = ""
    }

    // MARK: - Methods

    func bindData() {
        viewModel.connectedNewInspectionState.sink { state in
            hideActivityIndicator()
            switch state {
            case .finishFetchingData : self.reloadViews()
            case .didEndSubmitAction : self.showPincodeScreen()
            case .error(let error) :
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true)
            case .didEndFetchingFeeConnectedMode:
                self.showNewInspectionRegister()
            case .didFinishDeletingCar(let indexPath) :
                self.deleteCarFromTableView(indexPath: indexPath)
            case .errorCheckingIsOwner(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    if error.errorId == "400001" {
                        /// Delete car if isOwner ws failed
                        showActivityIndicator()
                        self.viewModel.deleteCar(indexPath: self.bookVehicleViewModel.selectedCarIndex ?? IndexPath())
                    }
                }
            case .errorGettingFee(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    self.popToRootViewController()
                }
            default: break
            }
        }.store(in: &cancellable)
        bookVehicleViewModel.bookingState.sink { state in
            hideActivityIndicator()
            switch state {
            case .successCheckingBookingValidity(let carValidty):
                if !(carValidty.canProceed ?? false) {
                    self.showBookingFirstScreen()
                } else {
                    self.showProceedToBookingActionPopUp(message: carValidty.message)
                }
            case .errorCheckingOwnership(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    /// Delete car if error code = 400
                    if error.errorId == "400001" {
                        /// Delete car if checkIsOwnerBooking ws failed
                        showActivityIndicator()
                        self.viewModel.deleteCar(indexPath: self.bookVehicleViewModel.selectedCarIndex ?? IndexPath())
                    }
                }
            case .error(let error):
                self.showErrorAlertView(descriptionMessage: error.message, fromFahes: true) {
                    // Case OTP not valid
                    self.pop()
                }
            default:break
            }
        }.store(in: &cancellable)
    }

    /// This function is fro loading UI after fetching Data
    private func reloadViews() {
        tableView.reloadData()
        setEmptyMessage()
        showDeleteCarNote()
        plateTypesTFView.dataArray = viewModel.plateTypeNames
        plateTypesTFView.defaultValueDropDownMenu = viewModel.plateTypeNames.first
    }

    /// Redirect user to pincodeScreen
    private func showPincodeScreen() {
        FahesRouter.shared
            .showPincodeScreen(viewModel:
                                FahesCarRegisterViewModel(fahesCarRequestVM:
                                                            self.viewModel.fahesCarRequestVM))

    }

    /// Redirect user to NewInspectionRegisterViewController
    private func showNewInspectionRegister() {
        FahesRouter.shared
            .showNewInspectionRegister(viewModel:
                                        NewInspectionRegisterViewModel(preRegistrationFee:
                                                                        self.viewModel.preRegistrationFee,
                                                                       car: self.viewModel.carDetails), isFromPayment: true)

    }
    /// Redirect user to showBookingFirstScreen
    private func showBookingFirstScreen() {
        FahesRouter.shared.showBookingFirstViewController(
            viewModel: viewModel.fahesCarVM, registerCarVM: NewInspectionRegisterViewModel(
                preRegistrationFee: self.viewModel.preRegistrationFee, car: self.viewModel.carDetails))
    }

    /// This func is to set a message if there was no cars found
    private func setEmptyMessage() {
        if self.viewModel.carsListVM.count == 0 {
            self.tableView.setEmptyMessage(LocalizableFahes.noCarsFound.localized)
        } else {
            self.tableView.restore()
        }
    }

    private func showDeleteCarNote(message: String = LocalizableFahes.deleteCarDescription.localized) {
        self.deleteCarDescriptionLabel.isHidden = self.viewModel.carsListVM.count == 0
        deleteCarDescriptionLabel.setText(text: message,
                                          font: Fonts.mediumFontName,
                                          size: 14,
                                          forgroundColor: .wqBlue,
                                          align: .center)

    }

    /// Initialize our UI
    func initUI() {
        // Labels
        subtitleLabel.setText(text: LocalizableFahes.addNewCar.localized.uppercased(),
                              font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
        // qidItemContent
        qidItemContent.title = LocalizableShared.qid.localized
        qidItemContent.value =  AuthManager.shared.currentUser?.qid
        // plateTypesTFView
        plateTypesTFView.title = LocalizableShared.plateType.localized + "*"
        plateTypesTFView.fieldType = .dropDown(type: .plateTypes)
        plateTypesTFView.$selectedText
            .assign(to: viewModel.plateTypeKeyPath, on: viewModel)
            .store(in: &cancellable)
        plateTypesTFView.pickerViewWillChangeValue
            .sink { self.handleCarPLateTypeChange()}
            .store(in: &cancellable)
        plateTypesTFView.shouldSelectFirstItem = true
//        plateTypesTFView.defaultValueDropDownMenu =
        // carPlateTFView
        carPlateTFView.title = LocalizableShared.carPlate.localized + "*"
        carPlateTFView.fieldType = .carPlate()
        carPlateTFView.placeholder = ""
        carPlateTFView.textPublisher?.assign(to: viewModel.carPlateKeyPath, on: viewModel)
            .store(in: &cancellable)
        // Init tableView
        tableView.delegate = self
        tableView.dataSource = self
        tableView.registerCellNib(FahesCarTableViewCell.self)

        // Buttons
        submitButton.title = LocalizableShared.submit.localized.uppercased()
        submitButton.style = Buttontype.secondary
        // Background and images
        initBgViews()
        initHeaderView()
        showDeleteCarNote()
    }
    
    private func handleCarPLateTypeChange() {
        carPlateTFView.resetLabel()
            if plateTypesTFView.selectedText == LocalizableFahes.diplomaticTitle.localized {
                carPlateTFView.fieldType = .carPlate(type: .diplomatic)
            } else {
                carPlateTFView.fieldType = .carPlate()
            }
    }

    func initBgViews() {
        contentView.border(borderColor: UIColor.white, borderwidth: 1)
        contentView.roundTopCorners(radius: 15)

        fahesImageView.setTintedImage(image: UIImage(named: "ic_fahes"),
                                      color: UIColor.wqBlue.withAlphaComponent(0.05) )
    }

    private func initHeaderView() {
        headerView.sideMenuButton.setImage(
            UIImage(named: "ic_back"), for: .normal)
        headerView.menuAction = {self.pop()}
    }

    @IBAction func submitAction(_ sender: Any) {
        view.endEditing(true)
        if carPlateTFView.isValid {
            showActivityIndicator()
            viewModel.submit()
        }
    }

}

extension ConnectedNewInspectionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.carsListVM.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FahesCarTableViewCell")
                as? FahesCarTableViewCell
        else {return UITableViewCell()}
        cell.setup(rowVM: viewModel.carsListVM[indexPath.row])
        cell.tapCellAction = {
            self.bookVehicleViewModel.selectedCarIndex = indexPath
            self.tapActionFor(item: self.viewModel.carsListVM[indexPath.row])
        }
        return cell
    }

    func tapActionFor(item: FahesCarViewModel) {
        viewModel.fahesCarVM = item
        viewModel.carDetails = Car(
            modelName: item.model ?? "",
            plateNumber: item.plateNumber,
            carPlateId: item.plateTypeId ?? 1,
            manufacturerName: item.name ?? "",
            expirationDate: item.expirationDate,
            ownerQid: item.qid,
            ownerFullname: viewModel.user?.fullName,
            ownerEmail: viewModel.user?.email,
            ownerMobile: viewModel.user?.mobileNumber ?? ""
        )
        viewModel.fahesCarVM.mobile = viewModel.carDetails?.ownerMobile ?? ""
        bookVehicleViewModel.fahesCarVM = item
        // If is booking -> Book inspection - If is payment -> getFee
        if self.isBooking {
            showActivityIndicator()
            bookVehicleViewModel.checkIsOwnerBooking()
        } else {
            showActivityIndicator()
            viewModel.checkIsOwner()
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func deleteCarFromTableView(indexPath: IndexPath) {
        self.viewModel.carsListVM.remove(at: indexPath.row)
        self.tableView.deleteRows(at: [indexPath], with: .none)
        self.tableView.reloadData()
        setEmptyMessage()
        showDeleteCarNote()
    }
    func showProceedToBookingActionPopUp(message: String?) {
        showCustomAlertView(title: LocalizableFahes.bookNewVehicle.localized.uppercased(),
                                 text: message,
                                 didConfirm: {
                                     self.showBookingFirstScreen()
                                 }, confirmText: LocalizableShared.commonContinue.localized, fromFahes: true)
    }

    func showDeleteActionPopUp(indexPath: IndexPath ) {
        showCustomAlertView(title: LocalizableWoqode.manageCarDeleteMessage.localized,
                            didConfirm: {
                                showActivityIndicator()
                                self.viewModel.deleteCar(indexPath: indexPath)
        }, fromFahes: true)
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath)
    -> UISwipeActionsConfiguration? {

        let deleteAction =
            UIContextualAction(style: .normal, title: "",
                               handler: {(_: UIContextualAction, _: UIView, success: (Bool) -> Void) in
            success(true)
            self.showDeleteActionPopUp(indexPath: indexPath)
        })
        deleteAction.backgroundColor = .white
        deleteAction.image = UIImage(named: "ic_trash")
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}
