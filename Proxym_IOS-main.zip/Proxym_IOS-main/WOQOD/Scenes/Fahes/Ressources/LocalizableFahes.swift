//
//  LocalizableFahes.swift
//  WOQOD
//
//  Created by Oumayma Guefrej on 8/29/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum LocalizableFahes: String, LocalizableDelegate {

    var tableName: String? {
        return "Fahes"
    }

    /* Fahes Menu */

    case title = "FahesTitle"
    case newInspectionRequest = "FahesMenuNewInspectionRequest"
    case inspectionReport = "FahesMenuInspectionReport"
    case stations = "FahesMenuStations"
    case aboutTitle = "FahesMenuAbout"
    case listOfReceipt = "FahesMenuListOfReceipt"
    case inspectionTipsTitle = "FahesMenuInspectionTips"
    case bookNewVehicle = "FahesMenuBookNewVehicle"
    case cancelModifyBooking = "FahesMenuBookCancelModify"
    case onlinePayementForInspection = "FahesMenuOnlinePaymentForInspection"
    case diplomaticTitle = "FahesDiplomaticTitle"
    /* List of receipt */

    case noReceipts = "FahesNoReceipts"

    /* Inspection details */

    case inspectionDetailsTitle = "FahesMenuInspectionDetails"
    case inspection = "FahesInspection"
    case inspectionOn = "FahesInspectionOn"
    case addCar = "FahesAddCar"
    case sendByMail = "FahesReceiptDetailsSendByMailButton"
    case download = "FahesReceiptDetailsDownloadButton"
    case successDownload = "FahesReceiptDetailsDownloadSuccessText"
    case successsendByMail = "FahesReceiptDetailsSendSuccessText"
    case inspectionDetailsLegalInformationsTitle = "InspectionDetailsLegalInformationsTitle"
    case inspectionDetailsTechnicalInformations = "inspectionDetailsTechnicalInformations"
    case inspectionDetailsTechnicalEvaluation = "inspectionDetailsTechnicalEvaluation"
    case inspectionDetailsPlateDetails = "InspectionDetailsPlateDetails"
    case inspectionDetailscommentsTitle = "InspectionDetailscommentsTitle"
    case inspectionDetailsNoComments = "InspectionDetailsNoComments"
    case inspectionDetailsNoDetails = "InspectionDetailsNoDetails"

    /* Inspection Preregistration  */
    case inspectionPreregitration = "FahesInspectionPreregitration"
    case paymentTerms = "FahesInspectionPreregitrationPaymentTermConditions"
    case emailTip = "FahesInspectionPreregitrationEmailTip"

    case carRegistrationConfirmation = "FahesInspectionPreregitrationCarRegistrationConfirmation"
    case customerType = "FahesInspectionPreregitrationCustomerType"
    case mobileTip = "FahesInspectionPreregitrationMobileTip"
    case customerTypeIndividual = "FahesInspectionPreregitrationCustomerTypeIndividual"
    case customerTypeCorporate = "FahesInspectionPreregitrationCustomerTypeCorporate"
    case companyId = "FahesInspectionPreregitrationCompanyId"
    case privatePlateTip = "FahesInspectionPreregitrationPrivatePlateTip"
    case addNewCar = "FahesInspectionPreregitrationAddNewCar"
    case successAddingNewCar = "FahesInspectionPreregitrationSuccessAddingNewCar"
    case deactivateCarTitle = "FahesInspectionPreregitrationDeactivateCarTitle"
    case deactivateCarMessage = "FahesInspectionPreregitrationDeactivateCarMessage"
    case swipeToDeactivate = "FahesInspectionPreregitrationSwipeToDeactivate"
    case noCarRegistered = "FahesInspectionPreregitrationNoCarRegistered"
    case pleaseCheckCarInformation = "FahesInspectionPreregitrationPleaseCheckCarInformation"
    case ownerName = "FahesInspectionPreregitrationOwnerName"
    case regitrationDate = "FahesInspectionPreregitrationDate"
    case driverMobileNbrMsg = "FahesInspectionPreregitrationDriverMobileNbrMsg"
    case driverNumber = "FahesInspectionPreregitrationDriverNumber"
    case paymentQnb = "FahesInspectionPreregitrationQnb"
    case paymentQpay = "FahesInspectionPreregitrationQpay"
    case regitrationAmount = "FahesInspectionPreregitrationAmount"
    case inspectionType = "FahesInspectionPreregitrationInspectionType"
    case paymentMode = "FahesInspectionPreregitrationPaymentMode"
    case totalAmount = "FahesInspectionPreregitrationTotalAmount"
    case paymentModeCreditCard = "FahesInspectionPreregitrationPaymentModeCreditCard"
    case paymentModeDebitCard = "FahesInspectionPreregitrationPaymentModeDebitCard"
    case expiresOn = "FahesInspectionPreregitrationExpiresOn"
    case receiptNotFound =  "FahesListOfReceiptReceiptNotFound"
    case noReceiptsFound =  "FahesListOfReceiptNoReceiptsFound"
    case noCarsFound =  "FahesInspectionNoCarsFound"
    case feeAlreadyPaid =  "FahesInspectionPreregitrationInspectionFeeAlreadyPaid"
    case feePaymentInProgress =  "FahesInspectionPreregitrationInspectionFeePaymentInProgress"
    case qpayPaymentDescription = "FahesInspectionPreregitrationInspectionqpayPaymentDescription"

    /* Static Screen */
    case inspectionTipsDescriptionIntro = "FahesInspectionTipsDescriptionIntroduction"
    case inspectionTipsDescription = "FahesInspectionTipsDescription"
    case inspectionTipsFirstVehicleType = "FahesInspectionTipsFirstVehicleType"
    case inspectionTipsFirstFrequency = "FahesInspectionTipsFirstFrequency"
    case inspectionTipsSecondVehicleType = "FahesInspectionTipsSecondVehicleType"
    case inspectionTipsSecondFrequency = "FahesInspectionTipsSecondFrequency"
    case inspectionTipsThirdVehicleType = "FahesInspectionTipsThirdVehicleType"
    case inspectionTipsFourthVehicleType = "FahesInspectionTipsFourthVehicleType"
    case inspectionTipsFifthVehicleType = "FahesInspectionTipsFifthVehicleType"
    case inspectionTipsVehicleTypeTitle = "FahesInspectionTipsVehicleTypeTitle"
    case inspectionTipsVehicleTypeTitleFrequency = "inspectionTipsVehicleTypeTitleFrequency"

    /* Fahes CR */
    case fahesBookingDetailsTitle = "FahesBookingDetailsTitle"
    case fahesBookingDetailsDescriptionText = "FahesBookingDetailsDescriptionText"
    case fahesBookingDetailsConfirmAndExitButton = "FahesBookingDetailsConfirmAndExitButton"
    case fahesBookingDetailsConfirmAndPayButton = "FahesBookingDetailsConfirmAndPayButton"
    case fahesBookingDetailsModifyButton = "FahesBookingDetailsModifyButton"
    case backToFahesMenu = "FahesBookingDetailsBackToFahesButton"
    case fahesBookingDetailsReScheduleButton = "FahesBookingDetailsReScheduleButton"
    case fahesBookingDetailsCancelBooking = "FahesBookingDetailsCancelBooking"
    case fahesBookingDetailsCancelBookingSuccess = "FahesBookingDetailsCancelBookingSuccess"
    case fahesBookingDetailsCancelBookingFailure = "FahesBookingDetailsCancelBookingErrorMessage"
    case fahesProceedToBookingVerification = "FahesProceedToBookingVerification"
    case emptyReservation = "FahesBookingEmptyReservation"
    case cantProceedToInspection = "FahesProceedToInspectionError"
    case cantProceedToBooking = "FahesProceedToBookingError"
    case selectSationAndDate = "FahesSelectStationAndDate"
    case slotPM = "FahesBookingSlotsTimePM"
    case slotAm = "FahesBookingSlotsTimeAM"
    case deleteCarDescription = "FahesBookingDeleteCarDescription"
    case duplicatedReservationCodeError = "DuplicatedReservationCodeError"
}
