//
//  PreRegistrationFee.swift
//  WOQOD
//
//  Created by rim ktari on 9/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class PreRegistrationFee: DomainModel {

    var totalAmount: Float?
    var name: String?
    var inspectionType: Int?
    var serviceCategory: String?
    var categoryNameEn: String?
    var categoryNameAr: String?
    var categoryId: Int?
    var categoryFee: Float?
    init(totalAmount: Float?, name: String?, serviceCategory: String?,
         categoryNameEn: String?, categoryNameAr: String?, categoryId: Int?,
         categoryFee: Float?,
         inspectionType: Int?) {
        self.totalAmount = totalAmount
        self.name = name
        self.serviceCategory = serviceCategory
        self.categoryNameEn = categoryNameEn
        self.categoryNameAr = categoryNameAr
        self.categoryId = categoryId
        self.categoryFee = categoryFee
        self.inspectionType = inspectionType
    }

}
