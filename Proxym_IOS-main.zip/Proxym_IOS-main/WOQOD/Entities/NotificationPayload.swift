//
//  NotificationPayload.swift
//  WOQOD
//
//  Created by Rim Ktari on 22/01/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class NotificationPayload: Codable {
    var payload: String?

    public var notificationDTO: NotificationDTO? {

        let decoder = JSONDecoder()
        do {
            guard let stringData = payload else {return nil}
            let data = stringData.data(using: .utf8)!
            let formattedData = try decoder.decode(NotificationDTO.self, from:
                data)
            return formattedData
        } catch {
            return nil
        }
    }
}
