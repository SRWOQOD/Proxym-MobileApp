//
//  FuelPrices.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 02/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class FuelPrices: DomainModel {

    let id: Int?
    let name: String?
    let price: String?
    let petrolId: Int?
    let syncdate: Int?
    let type: FuelType?
    var order: Int = 0

    init(id: Int?, name: String?, price: String?, petrolId: Int?, syncdate: Int?, type: FuelType?) {
        self.id = id
        self.name = name
        self.price = price
        self.petrolId = petrolId
        self.syncdate = syncdate
        self.type = type
    }
}

public enum FuelType {
    case gasolinePremium
    case diesel
    case gasolineSuper
}
