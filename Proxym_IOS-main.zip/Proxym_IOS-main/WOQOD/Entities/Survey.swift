//
//  Survey.swift
//  WOQOD
//
//  Created by rim ktari on 12/8/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class Survey: Codable {
    let idQuestion: Int?
    let question, type, messageType: String?
    let responses: [Response]?
}
class Response: Codable {
    let id: Int?
    let response: String?
}
