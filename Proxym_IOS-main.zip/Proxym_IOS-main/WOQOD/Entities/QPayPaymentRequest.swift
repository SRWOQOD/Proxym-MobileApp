//
//  QPayPaymentRequest.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 04/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation

class QPayParamsRequestModel: Codable {
    
    public var name: String?
    public var action: String = QPayPaymentValue.paymentActionPay
    public var amount: String?
    public var lang: String?
    public var merchantModuleSessionID: String?
    public var pun: String?
    public var quantity: String = QPayPaymentValue.paymentDefaultQuantity
    public var transactionRequestDate: String?
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case action = "action"
        case amount = "amount"
        case lang = "lang"
        case merchantModuleSessionID = "merchantModuleSessionID"
        case pun = "pun"
        case quantity = "quantity"
        case transactionRequestDate = "transactionRequestDate"
    }
    
    init() {
    }
    
    init(name: String? ,action: String?, amount: String?, lang: String?,
         merchantModuleSessionID: String?, pun: String?,
         paymentDescription: String?, quantity: String?, transactionRequestDate: String?) {
        self.name = name
        self.action = action ?? QPayPaymentValue.paymentActionPay
        self.amount = amount
        self.lang = lang
        self.merchantModuleSessionID = merchantModuleSessionID
        self.pun = pun
        self.quantity = quantity ?? QPayPaymentValue.paymentDefaultQuantity
        self.transactionRequestDate = transactionRequestDate
    }
    
    init(name: String?, amount: String?, pun: String?) {
        self.name = name
        self.action = QPayPaymentValue.paymentActionPay
        self.amount = amount
        self.merchantModuleSessionID = String(generateUniqueString().prefix(14))
        self.pun = pun
        self.quantity = QPayPaymentValue.paymentDefaultQuantity
        self.transactionRequestDate = Date().getStringDate("ddMMyyyyHHmmss")
        self.lang = Language.currentLanguage.local.identifier
    }
    
}
