//
//  StockPrice.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 15/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class StockPrice: DomainModel, Codable {
    var date: Date?
    var symbol: String?
    var marketCap: String?
    var last: Double?
    var change: Double?
    var noShares: String?
    var volume: Double?
    var previousClose: Double?
    var high: Double?
    var marketName: String?
    var low: Double?
    var ask: String?
    var changePercent: Double?
    var currency: String?
    var bid: String?
    var open: Double?
    var isin: String?
    enum CodingKeys: String, CodingKey {
        case date, symbol, marketCap, last, change, noShares,
             volume, previousClose, high, marketName, low,
             ask, changePercent, currency, bid
        case open
        case isin
    }

    init(date: Date?, symbol: String?, marketCap: String?,
         last: Double?, change: Double?, noShares: String?,
         volume: Double?, previousClose: Double?, high: Double?,
         marketName: String?, low: Double?, ask: String?,
         changePercent: Double?, currency: String?, bid: String?,
         open: Double?, isin: String?) {
        self.date = date
        self.symbol = symbol
        self.marketCap = marketCap
        self.last = last
        self.change = change
        self.noShares = noShares
        self.volume = volume
        self.previousClose = previousClose
        self.high = high
        self.marketName = marketName
        self.low = low
        self.ask = ask
        self.changePercent = changePercent
        self.currency = currency
        self.bid = bid
        self.open = open
        self.isin = isin
    }
}
