//
//  TransactionUUID.swift
//  WOQOD
//
//  Created by rim ktari on 9/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum TransactionStatus: String {
    case inProgress = "INPROGRESS"
    case cancelled = "CANCELED"
}

class TopUpTransactionUUIDModel {

    public var userID: String?
    public var email: String?
    public var mobile: String?
    public var qid: String?
    public var amount: String?
    public var currency: String = PaymentValue.currency
    public var transactionUUID: String = generateUUID()
    public var transactionStatus: TransactionStatus = .inProgress
    public var referenceNumber: String?
    init() {
    }

    init(userID: String?, email: String?, mobile: String?, qid: String?, amount: String?, referenceNumber: String? ) {
        self.userID = userID
        self.email = email
        self.mobile  = mobile
        self.qid = qid
        self.amount = amount
        self.referenceNumber = referenceNumber
    }

}
