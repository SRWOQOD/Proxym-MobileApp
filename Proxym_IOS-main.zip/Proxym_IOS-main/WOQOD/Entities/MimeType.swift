//
//  MimeType.swift
//  WOQOD
//
//  Created by rim ktari on 9/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
struct MimeType {

    static let html = "text/html"
    static let png = "image/png"
    static let jpeg = "image/jpeg"
    static let jpg = "image/jpg"
    static let csv = "text/csv"
    static let doc = "application/msword"
    static let pdf = "application/pdf"
}
