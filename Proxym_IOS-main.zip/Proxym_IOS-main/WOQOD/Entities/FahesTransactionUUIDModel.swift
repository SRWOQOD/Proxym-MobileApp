//
//  FahesTransactionUUIDModel.swift
//  WOQOD
//
//  Created by rim ktari on 11/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class FahesTransactionUUIDModel {

    var userID: String = ""
    var qid: String = ""
    var mobile: String = ""
    var email: String = ""
    var amount: String = ""
    var inspectionType: String = ""
    var serviceCategory: String = ""
    var categoryId: Int = 0
    var categoryNameEn: String = ""
    var categoryNameAr: String = ""
    var categoryFee: Float = 0
    var plateNumber: String = ""
    var plateType: Int = 0
    var referenceNumber: String = ""
    var anonym: Bool = true
    public var signedDate: String = ""
    var transactionUUID: String = ""
    var currency: String = ""

    init() {

    }
    init(
    userID: String,
    qid: String,
    mobile: String,
    email: String,
    amount: String,
    inspectionType: String,
    serviceCategory: String,
    categoryId: Int,
    categoryNameEn: String,
    categoryNameAr: String,
    categoryFee: Float,
    plateNumber: String,
    plateType: Int,
    referenceNumber: String,
    anonym: Bool

    ) {

        self.userID =  userID
        self.qid = qid
        self.mobile = mobile
        self.email = email
        self.amount = amount
        self.inspectionType = inspectionType
        self.serviceCategory = serviceCategory
        self.categoryId = categoryId
        self.categoryNameEn =  categoryNameEn
        self.categoryNameAr = categoryNameAr
        self.categoryFee = categoryFee
        self.plateNumber = plateNumber
        self.plateType = plateType
        self.referenceNumber = referenceNumber
        self.anonym = anonym
        self.signedDate = AuthManager.shared.serverDate?.utcDateTime ?? ""
        self.transactionUUID = generateUUID()
        self.currency = PaymentValue.currency

    }

}
