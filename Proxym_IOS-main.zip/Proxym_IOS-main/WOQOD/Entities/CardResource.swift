//
//  CardResource.swift
//  WOQOD
//
//  Created by rim ktari on 8/31/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class CardResource: Codable {
    var side1: String?
    var side2: String?
}
