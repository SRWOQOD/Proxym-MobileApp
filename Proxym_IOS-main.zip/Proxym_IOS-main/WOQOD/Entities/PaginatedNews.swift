//
//  PaginatedNews.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 22/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class PaginatedNews: DomainModel {

    public var size: Int?
    public var count: Int?
    public var page: Int?
    public var result: [News]?

    enum CodingKeys: String, CodingKey {
        case size, count, page, result
    }

    init(size: Int?, count: Int?, page: Int?, result: [News]? ) {
        self.size = size
        self.count = count
        self.page = page
        self.result = result
    }

}
