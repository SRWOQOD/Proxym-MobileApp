//
//  TopUpTransactionPUNModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 18/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation

class TopUpTransactionPUNModel {

    public var userID: String?
    public var email: String?
    public var mobile: String?
    public var qid: String?
    public var amount: String?
    public var currency: String?
    public var pun: String = ""
    public var transactionStatus: TransactionStatus = .inProgress
    public var referenceNumber: String?


    init() {
    }

    init(userID: String?, email: String?, mobile: String?, qid: String?, amount: String?) {
        self.userID = userID
        self.email = email
        self.mobile  = mobile
        self.qid = qid
        self.amount = amount
        self.referenceNumber = "\(Date().timeStamp)"
        self.pun = String(generateUniqueString().prefix(20))
    }
}
