//
//  Tender.swift
//  WOQOD
//
//  Created by rim ktari on 12/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class Tender: DomainModel, Equatable {

    static func == (lhs: Tender, rhs: Tender) -> Bool {
        return lhs.id == rhs.id
    }

  var id: Int?
  var collectionDate: Date?
  var tenderNumber: String?
  var bond: String?
  var details: String?
  var closingDate: Date?
  var category: String?
  var description: String?
  var fee: String?
  var serialNumber: String?

  init (id: Int?, serialNumber: String?, tenderNumber: String?,
        description: String?, collectionDate: Date?, bond: String?,
        fee: String?, category: String?, closingDate: Date?, details: String?) {
    self.id = id
    self.collectionDate = collectionDate
    self.tenderNumber = tenderNumber
    self.bond = bond
    self.details = details
    self.closingDate = closingDate
    self.category = category
    self.description = description
    self.fee = fee
    self.serialNumber = serialNumber
  }

}
