//
//  FahesCar.swift
//  WOQOD
//
//  Created by rim ktari on 9/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
struct  FahesCar {

    var customerType: String?
    var qatariID: String?
    var mobile: String?
    var plateNumber: String?
    var plateType: String?
    var email: String?
    var plateTypeId: Int?
    var vehicleShape: String?
    var vehicleShapeId: Int?
    var carId: Int?
}
