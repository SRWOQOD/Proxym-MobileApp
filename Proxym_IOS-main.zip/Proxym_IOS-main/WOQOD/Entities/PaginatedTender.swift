//
//  PaginatedTender.swift
//  WOQOD
//
//  Created by Bouabid Wassim on 17/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

class PaginatedTender: DomainModel {

    public var size: Int?
    public var count: Int?
    public var page: Int?
    public var result: [Tender]?

    enum CodingKeys: String, CodingKey {
        case size, count, page, result
    }

    init(size: Int?, count: Int?, page: Int?, result: [Tender]? ) {
        self.size = size
        self.count = count
        self.page = page
        self.result = result
    }
}
