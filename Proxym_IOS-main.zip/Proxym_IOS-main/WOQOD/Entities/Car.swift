//
//  Car.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 04/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

let defaultPlateTypeId = 1
let defaultPlateType = "private"

public class Car: DomainModel, Codable {

    var carId: Int = 0
    var carTag: Bool = false
    var manufacturerName: String = ""
    var statusFuel: Bool = false
    var modelName: String = ""

    // Automation Process
    var ownerQid: String?
    var ownerMobile: String?
    var plateNumber: String?
    var plateType: String = defaultPlateType
    var fuelType: String?
    var transactionLimit: String?
    var transactionType: String?
    var carPaperResource: CardResource?
    var limitType: String?
    var plateTypeId: Int = defaultPlateTypeId
    var expirationDate: String?
    var ownerFullname: String?
    var ownerEmail: String?
    var creationDate: Int64?
    enum CodingKeys: String, CodingKey {

        case ownerQid = "owner_qid"
        case plateNumber =  "plate_number"
        case plateType =  "plate_type"
        case plateTypeId = "plate_type_id"
        case expirationDate = "registration_expires_on"

    }

    init(carId: Int = 0, statusFuel: Bool = false, carTag: Bool = false, modelName: String = "",
         plateNumber: String = "", carPlateId: Int = defaultPlateTypeId,
         manufacturerName: String = "", expirationDate: String? = nil,
         ownerQid: String?, ownerFullname: String?, ownerEmail: String?,
         creationDate: Int64?,
         plateType: String) {
        self.carId = carId
        self.statusFuel = statusFuel
        self.carTag = carTag
        self.modelName = modelName
        self.plateNumber = plateNumber
        self.plateTypeId = carPlateId
        self.expirationDate = expirationDate
        self.manufacturerName = manufacturerName
        self.ownerQid = ownerQid
        self.ownerFullname = ownerFullname
        self.ownerEmail = ownerEmail
        self.creationDate = creationDate
        self.plateType = plateType
    }

    // Vehicle details
    init( plateNumber: String, fuelType: String, transactionLimit: String ,
          limitType: String, ownerMobile: String, ownerQid: String) {
        self.plateNumber = plateNumber
        self.fuelType = fuelType
        self.transactionLimit = transactionLimit
        self.limitType = limitType
        self.ownerMobile = ownerMobile
        self.ownerQid = ownerQid
    }

    // Inspection details
    init(plateNumber: String, ownerQid: String, plateTypeId: Int) {
        self.plateNumber = plateNumber
        self.ownerQid = ownerQid
        self.plateTypeId = plateTypeId
    }
    // Register details
    init(modelName: String = "",
         plateNumber: String = "", carPlateId: Int = defaultPlateTypeId,
         manufacturerName: String = "", expirationDate: String? = nil,
         ownerQid: String?, ownerFullname: String?, ownerEmail: String?, ownerMobile: String) {
        self.modelName = modelName
        self.plateNumber = plateNumber
        self.plateTypeId = carPlateId
        self.expirationDate = expirationDate
        self.manufacturerName = manufacturerName
        self.ownerQid = ownerQid
        self.ownerFullname = ownerFullname
        self.ownerEmail = ownerEmail
        self.ownerMobile = ownerMobile
    }
}
