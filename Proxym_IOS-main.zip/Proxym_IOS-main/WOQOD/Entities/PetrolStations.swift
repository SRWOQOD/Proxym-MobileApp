//
//  PetrolStations.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class PetrolStations: DomainModel, Codable {

    public var id: Int?
    public var stationId: Int?
    public var category: String?
    public var petrolCategory: PetrolCategory?
    public var stationName: String?
    public var stationNameAR: String?
    public var latitude: String?
    public var longitude: String?
    public var phone: String?
    public var status: StationStatus?
    public var icon: String?
    public var isVisible: String?
    var area: Area?
    var serviceStations: [ServiceStations]?

    init(id: Int?,
         stationId: Int?,
         category: String?,
         petrolCategory: PetrolCategory?,
         stationName: String?,
         stationNameAR: String?,
         latitude: String?,
         longitude: String?,
         phone: String?,
         status: StationStatus?,
         serviceStations: [ServiceStations]?,
         icon: String?,
         area: Area?,
         isVisible: String?) {

        self.id = id
        self.stationId = stationId
        self.category = category
        self.petrolCategory = petrolCategory
        self.stationName = stationName
        self.stationNameAR = stationNameAR
        self.latitude = latitude
        self.longitude = longitude
        self.phone = phone
        self.status = status
        self.serviceStations = serviceStations
        self.icon = icon
        self.area = area
        self.isVisible = isVisible
    }

}
