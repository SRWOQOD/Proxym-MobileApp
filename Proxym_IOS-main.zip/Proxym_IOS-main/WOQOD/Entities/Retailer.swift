//
//  Retail.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 24/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Retailer: DomainModel {

    var id: Int?
    var name: String?
    var nameAR: String?
    var phoneNumber: String?
    var latitude: String?
    var longitude: String?
    var icon: String?
    var area: Area?

    init(id: Int?, name: String?, nameAR: String?, phoneNumber: String?, latitude: String?, longitude: String?,
         icon: String?, area: Area?) {
        self.id = id
        self.name = name
        self.nameAR = nameAR
        self.phoneNumber = phoneNumber
        self.latitude = latitude
        self.longitude = longitude
        self.icon = icon
        self.area = area
    }
}
