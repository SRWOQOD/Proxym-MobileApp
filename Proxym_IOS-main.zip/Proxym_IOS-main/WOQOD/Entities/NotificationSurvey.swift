//
//  NotificationSurvey.swift
//  WOQOD
//
//  Created by rim ktari on 12/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class NotificationSurvey: DomainModel {

    var surveyID: Int?
    var surveyQuestionsList: [SurveyQuestion]?
    var description: String?
    var title: String?

    init(surveyID: Int?,
         surveyQuestionsList: [SurveyQuestion]?,
         description: String?,
         title: String?) {
        self.surveyID=surveyID
        self.surveyQuestionsList=surveyQuestionsList
        self.description=description
        self.title = title
    }
    override init() {}
}

struct SurveyQuestion {
    var type: SurveyTypesEnum?
    var options: [SurveyQuestionOptions]?
    var title: String?
    var questionId: Int?
    let min: Float?
    let max: Float?
    let textLimit: Int?
}

struct SurveyQuestionOptions {
    var option: String?
}
