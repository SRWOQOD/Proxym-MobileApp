//
//  EncodingName.swift
//  WOQOD
//
//  Created by rim ktari on 9/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

struct  EncodingName {

    static let  base64 = "base64"
}
