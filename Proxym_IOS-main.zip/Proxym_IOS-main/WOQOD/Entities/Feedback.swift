//
//  Feedback.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Feedback: DomainModel {
    
    public var id: String?
    public var category: String?
    public var connected: Bool = userIsConnected
    public var username: String?
    public var name: String?
    public var comment: String?
    public var contactNumber: String?
    public var creationDate: Int64?
    public var file: String?
    public var email: String?
    public var sector: String?
    public var state: Bool?
    var details: [ItemContentModel] = []
    var feedbackResponseResources: [FeedbackResponseResource]

    init(username: String?,
         name: String?,
         category: String?,
         contactNumber: String?,
         email: String?,
         sector: String?,
         comment: String?,
         file: String?,
         creationDate: Int64?,
         state: Bool?,
         feedbackResponseResources: [FeedbackResponseResource]) {

        self.username = username
        self.name = name
        self.category = category
        self.contactNumber = contactNumber
        self.email = email
        self.sector = sector
        self.comment = comment
        self.file = file
        self.creationDate = creationDate
        self.state = state
        self.feedbackResponseResources = feedbackResponseResources
    }
    
    init(id: String?,
         username: String?,
         name: String?,
         category: String?,
         contactNumber: String?,
         email: String?,
         sector: String?,
         comment: String?,
         file: String?,
         creationDate: Int64?,
         state: Bool?,
         feedbackResponseResources: [FeedbackResponseResource]) {

        self.id = id
        self.username = username
        self.name = name
        self.category = category
        self.contactNumber = contactNumber
        self.email = email
        self.sector = sector
        self.comment = comment
        self.file = file
        self.creationDate = creationDate
        self.state = state
        self.feedbackResponseResources = feedbackResponseResources
    }

}
