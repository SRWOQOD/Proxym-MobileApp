//
//  Area.swift
//  WOQOD
//
//  Created by rim ktari on 12/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
public class Area: DomainModel, Codable {

    var latitude: String?
    var id: Float?
    var title: String?
    var titleAR: String?
    var longitude: String?
    var idArea: String?
    override init() {}
    init(id: Float?,
         title: String?,
         titleAR: String?,
         longitude: String?,
         latitude: String?,
         idArea: String?
    ) {
        self.id = id
        self.title = title
        self.titleAR = titleAR
        self.longitude = longitude
        self.latitude = latitude
        self.idArea = idArea
    }
}
