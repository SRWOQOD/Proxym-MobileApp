//
//  TopBannerInfo.swift
//  WOQOD
//
//  Created by rim.ktari on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class TopBannerInfo: DomainModel {
    var imageURL: String?
    var type: BannerFileType?
    var videoURL: String?
    var appRedirectionType: AppRedirectionType?
    var orderItem: Int?
    var redirectionURL: String?
    var redirectionTypeEnum: BannerRedirectionPath?
    var bannerTitle: String?
    var shouldRedirect: Bool = false
    var titleDisplayed: Bool = false
    init(imageURL: String?,
         type: BannerFileType?,
         videoURL: String?,
         appRedirectionType: AppRedirectionType?,
         orderItem: Int?,
         redirectionURL: String?,
         redirectionTypeEnum: BannerRedirectionPath?,
         bannerTitle: String?,
         shouldRedirect: Bool = false, titleDisplayed: Bool = false) {
        self.imageURL = imageURL
        self.type = type
        self.videoURL = videoURL
        self.appRedirectionType = appRedirectionType
        self.orderItem = orderItem
        self.redirectionURL = redirectionURL
        self.redirectionTypeEnum = redirectionTypeEnum
        self.bannerTitle = bannerTitle
        self.shouldRedirect = shouldRedirect
        self.titleDisplayed = titleDisplayed
    }

}
