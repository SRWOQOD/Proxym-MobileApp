//
//  RowViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

protocol RowViewModel {}
