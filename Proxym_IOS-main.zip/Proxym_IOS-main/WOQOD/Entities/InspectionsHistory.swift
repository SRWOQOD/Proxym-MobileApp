//
//  InspectionDetails.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 18/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class InspectionsHistory: DomainModel {

    var inspection: Int?
    var inspectionOn: String?
    var plateType: String?
    var legalEvaluation: String?
    var technicalEvaluation: String?
    var plateNumber: String?

    init(inspection: Int?, inspectionOn: String?, plateType: String?,
         legalEvaluation: String?, technicalEvaluation: String?, plateNumber: String?) {

        self.inspection = inspection
        self.inspectionOn = inspectionOn
        self.plateType = plateType
        self.legalEvaluation = legalEvaluation
        self.technicalEvaluation = technicalEvaluation
        self.plateNumber = plateNumber
    }

}
