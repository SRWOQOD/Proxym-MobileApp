//
//  Place.swift
//  WOQOD
//
//  Created by rim ktari on 7/20/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

struct  Place: Equatable {
    static func == (lhs: Place, rhs: Place) -> Bool {
       return (lhs.latitude == rhs.latitude) &&
        (lhs.longitude == rhs.longitude) &&
        (languageIsArabic ? lhs.titleAR == rhs.titleAR : lhs.title == rhs.title)
    }

    public var id: Int?
    public var stationId: Int?
    public var title: String?
    public var titleAR: String?
    public var address: String?
    public var addressAR: String?
    public var secondAddress: String?
    public var secondAddressAR: String?
    public var phone: String?
    public var latitude: Double?
    public var longitude: Double?
    public var workingDays: String?
    public var workingDaysAR: String?
    public var serviceStations: [ServiceStations]?
    public var petrolCategory: PetrolCategory?
    public var icon: String?
    public var status: StationStatus?
    public var area: Area?
    public var isVisible: String?
}
