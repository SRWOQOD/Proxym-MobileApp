//
//  AppointmentDate.swift
//  WOQOD
//
//  Created by rim.ktari on 05/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class AppointmentDate: DomainModel {
    var date: Date?

    init(date: Date?) {
        self.date = date
    }
}
