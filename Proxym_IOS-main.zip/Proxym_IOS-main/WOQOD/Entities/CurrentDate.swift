//
//  CurrentDate.swift
//  WOQOD
//
//  Created by Oumeima.ben-Ghalba on 1/7/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation

class CurrentDate: DomainModel, Codable {

    public var dateTimeStamp: String?
    public var utcDateTime: String?
    public var qpayDate: String?

    init(dateTimeStamp: String?, utcDateTime: String?, qpayDate: String?) {
        self.dateTimeStamp = dateTimeStamp
        self.utcDateTime = utcDateTime
        self.qpayDate = qpayDate
        
    }
}
