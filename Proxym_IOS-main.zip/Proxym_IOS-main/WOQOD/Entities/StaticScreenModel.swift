//
//  StaticScreenModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 13/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
public class StaticScreenModel: DomainModel {

    public var textType: String?
    public var id: Int?
    public var content: String?

    init(textType: String?,
         id: Int?,
         content: String?) {

        self.textType = textType
        self.id = id
        self.content = content
    }
}
