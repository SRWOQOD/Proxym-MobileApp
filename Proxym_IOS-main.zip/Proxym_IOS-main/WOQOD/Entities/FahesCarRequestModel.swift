//
//  FahesCarRequestModel.swift
//  WOQOD
//
//  Created by rim ktari on 10/6/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class FahesCarRequestModel: Codable {

    var ownerQid: String?
    var vin: String?
    var pincode: String?
    var plateNumber: String?

    var plateTypeId: Int?
    var plateTypeNameEn: String?
    var plateTypeNameAr: String?

    var manufactureId: Int?
    var manufactureNameEn: String?
    var manufactureNameAr: String?

    var modelId: Int?
    var modelNameEn: String?
    var modelNameAr: String?

    var colorId: Int?
    var colorNameEn: String?
    var colorNameAr: String?

    var registrationExpiresOn: String?

    var year: String?
    var active: Bool?

    init() {}

    init(ownerQid: String?,
         vin: String?,
         plateNumber: String?,
         plateTypeId: Int?,
         plateTypeNameEn: String?,
         plateTypeNameAr: String?,
         manufactureId: Int?,
         manufactureNameEn: String?,
         manufactureNameAr: String?,
         modelId: Int?,
         modelNameEn: String?,
         modelNameAr: String?,
         colorId: Int?,
         colorNameEn: String?,
         colorNameAr: String?,
         registrationExpiresOn: String?,
         year: String? ,
         active: Bool?) {

        self.ownerQid = ownerQid
        self.vin = vin
        self.plateNumber = plateNumber
        self.plateTypeId =  plateTypeId
        self.plateTypeNameEn = plateTypeNameEn
        self.plateTypeNameAr = plateTypeNameAr
        self.manufactureId = manufactureId
        self.manufactureNameEn = manufactureNameEn
        self.manufactureNameAr = manufactureNameAr
        self.modelId = modelId
        self.modelNameEn  = modelNameEn
        self.modelNameAr = modelNameAr
        self.colorId = colorId
        self.colorNameEn = colorNameEn
        self.colorNameAr = colorNameAr
        self.registrationExpiresOn = registrationExpiresOn
        self.year = year
        self.active = active ?? false

    }

    enum CodingKeys: String, CodingKey {

        case ownerQid = "qid"
        case vin = "vin"
        case pincode = "pincode"
        case plateNumber = "plate_number"
        case plateTypeId = "plate_type_id"
        case plateTypeNameEn = "plate_type_name_en"
        case plateTypeNameAr = "plate_type_name_ar"
        case manufactureId = "manufacture_id"
        case manufactureNameEn = "manufacture_name_en"
        case manufactureNameAr = "manufacture_name_ar"
        case modelId = "model_id"
        case modelNameEn = "model_name_en"
        case modelNameAr = "model_name_ar"
        case colorId = "colour_id"
        case colorNameEn = "colour_name_en"
        case colorNameAr = "colour_name_ar"
        case registrationExpiresOn = "registration_expires_on"
        case year = "year"
        case active = "active"

    }

}
