//
//  QPayPaymentResponse.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 06/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation

class QPayParamsResponseModel: DomainModel, Codable {
    public var action: String?
    public var amount: String?
    public var lang: String?
    public var merchantModuleSessionID: String?
    public var pun: String?
    public var paymentDescription: String?
    public var quantity: String?
    public var transactionRequestDate: String?
    public var bankID: String?
    public var currencyCode: String?
    public var merchantID: String?
    public var extraFields_f14: String?
    public var secureHash: String?
    public var redirectUrl: String?
    public var referer: String?
    
    enum CodingKeys: String, CodingKey {
        case action = "Action"
        case amount = "Amount"
        case lang = "Lang"
        case merchantModuleSessionID = "MerchantModuleSessionID"
        case paymentDescription = "PaymentDescription"
        case pun = "PUN"
        case quantity = "Quantity"
        case transactionRequestDate = "TransactionRequestDate"
        case bankID = "BankID"
        case currencyCode = "CurrencyCode"
        case merchantID = "MerchantID"
        case extraFields_f14 = "ExtraFields_f14"
        case secureHash = "SecureHash"
        case redirectUrl = "PG_REDIRECT_URL"
        case referer = "referer"
    }
    
    init(action: String?, amount: String?, lang: String?,
         merchantModuleSessionID: String?, pun: String?,
         paymentDescription: String?, quantity: String?, transactionRequestDate: String?,
         bankID: String?, currencyCode: String?, merchantID: String?, secureHash: String?,
         extraFields_f14: String?, redirectUrl: String?, referer: String?) {
        self.action = action ?? QPayPaymentValue.paymentActionPay
        self.amount = amount
        self.lang = lang
        self.merchantModuleSessionID = merchantModuleSessionID
        self.paymentDescription = paymentDescription
        self.pun = pun
        self.quantity = quantity ?? QPayPaymentValue.paymentDefaultQuantity
        self.transactionRequestDate = transactionRequestDate
        self.bankID = bankID
        self.currencyCode = currencyCode
        self.merchantID = merchantID
        self.secureHash = secureHash
        self.extraFields_f14 = extraFields_f14
        self.redirectUrl = redirectUrl
        self.referer = referer
    }
    
    // Init webView Params
    init(action: String?, amount: String?, lang: String?,
         merchantModuleSessionID: String?, pun: String?,
         paymentDescription: String?, quantity: String?, transactionRequestDate: String?,
         bankID: String?, currencyCode: String?, merchantID: String?, secureHash: String?,
         extraFields_f14: String?) {
        self.action = action ?? QPayPaymentValue.paymentActionPay
        self.amount = amount
        self.lang = lang
        self.merchantModuleSessionID = merchantModuleSessionID
        self.paymentDescription = paymentDescription
        self.pun = pun
        self.quantity = quantity ?? QPayPaymentValue.paymentDefaultQuantity
        self.transactionRequestDate = transactionRequestDate
        self.bankID = bankID
        self.currencyCode = currencyCode
        self.merchantID = merchantID
        self.secureHash = secureHash
        self.extraFields_f14 = extraFields_f14
    }

    override init() {}
}
