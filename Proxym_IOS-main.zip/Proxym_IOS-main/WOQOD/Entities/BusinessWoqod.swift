//
//  BusinessWoqod.swift
//  WOQOD
//
//  Created by rim.ktari on 06/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class BusinessWoqod: DomainModel {
    var title: String?
    var description: String?
    var shouldRedirect: Bool?
    var detailsImageURL: String?
    var selectedIconURL: String?
    var unselectedIconURL: String?
    var redirectionURL: String?
    var iconTitle: String?
    var orderItem: Int?
    var redirectionTypeEnum: BannerRedirectionPath?
    var appRedirectionType: AppRedirectionType?

    init(title: String?,
         description: String?,
         shouldRedirect: Bool?,
         detailsImageURL: String?,
         selectedIconURL: String?,
         unselectedIconURL: String?,
         redirectionURL: String?,
         iconTitle: String?,
         orderItem: Int?,
         redirectionTypeEnum: BannerRedirectionPath?,
         appRedirectionType: AppRedirectionType?) {
        self.title = title
        self.description = description
        self.shouldRedirect = shouldRedirect
        self.selectedIconURL = selectedIconURL
        self.detailsImageURL = detailsImageURL
        self.unselectedIconURL = unselectedIconURL
        self.redirectionURL = redirectionURL
        self.iconTitle = iconTitle
        self.orderItem = orderItem
        self.redirectionTypeEnum = redirectionTypeEnum
        self.appRedirectionType = appRedirectionType
    }
}
