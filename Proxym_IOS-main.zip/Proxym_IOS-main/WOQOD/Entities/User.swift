//
//  User.swift
//  WOQOD
//
//  Created by rim ktari on 7/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum UserType: String, Codable {
    case individualCustomer =  "Individual_Customer"
}

enum ContactType: String, Codable {
    case mail =  "Mail"
}

public class User: DomainModel, Codable {

    public var qid: String?
    public var id: Int?
    public var userName: String?
    public var email: String?
    public var birthdate: Int64?
    public var mobileNumber: String?
    public var familyName: String?
    public var firstName: String?
    public var address: String?
    public var income: Int?
    public var status: String?
    public var createdAt: Int64?
    public var password: String?
    public var poBox: String?
    public var unlockAccount: String?
    public var fleetName: String?
    public var gender: String?
    public var isBiometricActivated: Bool?
    public var customIdentification: String?
    var area: Area?
    var type: UserType?
    var contactType: ContactType?
    var card: CardResource?
    var fullName: String? = ""
    var photo: String?

    override init() {}

    init(id: Int? = nil ,
         qid: String? ,
         userName: String? ,
         email: String?,
         birthdate: Int64?,
         mobileNumber: String? ,
         type: UserType?,
         contactType: ContactType? ,
         firstName: String?,
         familyName: String?,
         fullName: String?,
         address: String? ,
         income: Int? = nil ,
         status: String? = nil ,
         createdAt: Int64? = nil,
         poBox: String?,
         unlockAccount: String?,
         fleetName: String?,
         gender: String?,
         area: Area? = nil,
         isBiometricActivated: Bool?,
         customIdentification: String?) {

        self.id = id
        self.qid = qid
        self.userName = userName
        self.email = email
        self.birthdate = birthdate
        self.mobileNumber = mobileNumber
        self.type = type
        self.contactType = contactType
        self.firstName = firstName
        self.familyName = familyName
        self.fullName = fullName
        self.address = address
        self.income = income
        self.status = status
        self.createdAt = createdAt
        self.poBox = poBox
        self.unlockAccount = unlockAccount
        self.fleetName = fleetName
        self.gender = gender
        self.area=area
        self.isBiometricActivated = isBiometricActivated
        self.customIdentification = customIdentification
    }

    init(id: Int? = nil ,
         qid: String? ,
         userName: String? ,
         birthdate: Int64?,
         type: UserType?,
         contactType: ContactType? ,
         firstName: String?,
         familyName: String?,
         fullName: String?,
         address: String? ,
         income: Int? = nil ,
         status: String? = nil ,
         createdAt: Int64? = nil,
         poBox: String?,
         unlockAccount: String?,
         fleetName: String?,
         gender: String?,
         area: Area? = nil,
         isBiometricActivated: Bool?,
         customIdentification: String?) {

        self.id = id
        self.qid = qid
        self.userName = userName
        self.birthdate = birthdate
        self.type = type
        self.contactType = contactType
        self.firstName = firstName
        self.familyName = familyName
        self.fullName = fullName
        self.address = address
        self.income = income
        self.status = status
        self.createdAt = createdAt
        self.poBox = poBox
        self.unlockAccount = unlockAccount
        self.fleetName = fleetName
        self.gender = gender
        self.area=area
        self.isBiometricActivated = isBiometricActivated
        self.customIdentification = customIdentification
    }
}
