//
//  PlateTypeWithShape.swift
//  WOQOD
//
//  Created by rim.ktari on 03/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class PlateTypeWithShape: DomainModel {

    let plateTypeID: Int?
    let plateTypeName: String?
    let vehicleShapes: [VehicleShape]?

    init(plateTypeID: Int?,
         plateTypeName: String?,
         vehicleShapes: [VehicleShape]?) {
        self.plateTypeID = plateTypeID
        self.plateTypeName = plateTypeName
        self.vehicleShapes = vehicleShapes
    }
}
