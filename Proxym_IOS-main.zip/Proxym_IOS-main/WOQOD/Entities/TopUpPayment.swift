//
//  TopUpPayment.swift
//  WOQOD
//
//  Created by rim ktari on 9/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class TopUpPayment: DomainModel {

    public var minAmount, maxAmount: Float?

    init(minAmount: Float?, maxAmount: Float?) {
        self.minAmount = minAmount
        self.maxAmount = maxAmount
    }
}
