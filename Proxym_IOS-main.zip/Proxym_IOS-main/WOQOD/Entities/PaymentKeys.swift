//
//  PaymentKeys.swift
//  WOQOD
//
//  Created by rim ktari on 11/26/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class  PaymentKeys: DomainModel {

    var profileID: String?
    var accessKey: String?
    var secretKey: String?
    init(profileID: String?, accessKey: String?, secretKey: String?) {
        self.profileID = profileID
        self.accessKey = accessKey
        self.secretKey = secretKey
    }
}
