//
//  Notification.swift
//  WOQOD
//
//  Created by rim ktari on 12/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class Notification: DomainModel {

    var uniqueID: String?
    var description: String?
    var title: String?
    var sendDate: Date?
    var notificationSurvey: NotificationSurvey?
    var status: Bool?
    var notifID: Int?
    var notificationType: NotificationTypeEnum?
    var idFeedback: String?
    var isanswered: Bool?
    var isAll: String?

    override init() {}
    init(title: String?,
         description: String?,
         sendDate: Date?,
         notificationSurvey: NotificationSurvey?,
         status: Bool?,
         notifID: Int?,
         notifType: String?,
         idFeedback: String?,
         isanswered: Bool?,
         isAll: String?,
         uniqueID: String?) {
        self.title=title
        self.description=description
        self.sendDate=sendDate
        self.notificationSurvey=notificationSurvey
        self.status=status
        self.notifID=notifID
        self.notificationType = NotificationTypeEnum(rawValue: notifType ?? "")
        self.idFeedback=idFeedback
        self.isanswered=isanswered
        self.isAll = isAll
        self.uniqueID = uniqueID
    }
}
enum NotificationTypeEnum: String {
    case fahes = "FAHES"
    case backOffice = "BO"
    case feedback = "FEEDBACK"
    case survey = "SURVEY"
}
