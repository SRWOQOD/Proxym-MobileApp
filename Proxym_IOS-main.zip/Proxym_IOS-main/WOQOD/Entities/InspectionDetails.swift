//
//  InspectionDetails.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 13/11/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class InspectionDetails: DomainModel {

    var evaluation: Evaluation?
    var defectComment: DefectComment?
    var location: Location?
    var additionalComment: String?
    var defectType: Evaluation?

    init(evaluation: Evaluation?, defectComment: DefectComment?, location: Location?,
         additionalComment: String?, defectType: Evaluation?) {
        self.evaluation = evaluation
        self.defectComment = defectComment
        self.location = location
        self.additionalComment = additionalComment
        self.defectType = defectType
    }

}
