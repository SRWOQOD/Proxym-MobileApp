//
//  CarValidity.swift
//  WOQOD
//
//  Created by Bouthaina ghachem on 11/02/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
public class CarValidity: DomainModel {

    var canProceed: Bool?
    var message: String?

    init(canProceed: Bool?, message: String?) {
        self.canProceed = canProceed
        self.message = message
    }
}
