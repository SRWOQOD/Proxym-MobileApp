//
//  FahesBooking.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 10/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class FahesBooking: DomainModel {

    var reservationID: Int?
    var plateTypeName: String?
    var time: String?
    var bookingDate: String?
    var customerID: String?
    var station: String?
    var plateNumber: String?
    var mobileNumber: String?
    var pay: Bool?
    init(reservationID: Int?, plateTypeName: String?, time: String?,
         date: String?, customerID: String?, station: String?,
         plateNumber: String?, mobileNumber: String?, pay: Bool?) {
        self.reservationID = reservationID
        self.plateTypeName = plateTypeName
        self.time = time
        self.bookingDate = date
        self.customerID = customerID
        self.station = station
        self.plateNumber =  plateNumber
        self.mobileNumber = mobileNumber
        self.pay = pay
    }
    /// Init to display booking view
    init(time: String?, date: String?, station: String?, pay: Bool?) {
        self.time = time
        self.bookingDate = date
        self.station = station
        self.pay = pay
    }
}
