//
//  Receipt.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Receipt: DomainModel {

    var receipturl: String?
    var referenceNumber: String?
    var wsStatus: String?
    var discountInfo: String?
    var serviceCategory: String?
    var initialAmount, creationDate: Int?
    var qid: String?
    var errorNo: String?
    var userName, transactionUUID, payStatus: String?
    var car: Car?
    var error: String?
    var finalAmount, id: Int?
    var category: PreRegistration?
    var mobileNumber: String?
    var barcodeReference: String?
    var inspectionType: String?
    var barcode: String?

    init(receipturl: String?,
         referenceNumber: String?,
         wsStatus: String?,
         discountInfo: String?,
         serviceCategory: String?,
         initialAmount: Int?,
         creationDate: Int?,
         qid: String?,
         errorNo: String?,
         userName: String?,
         transactionUUID: String?,
         payStatus: String?,
         car: Car?,
         error: String?,
         finalAmount: Int?,
         id: Int?,
         category: PreRegistration?,
         mobileNumber: String?,
         barcodeReference: String?,
         inspectionType: String?,
         barcode: String?) {

        self.receipturl = receipturl
        self.referenceNumber = referenceNumber

        self.wsStatus = wsStatus
        self.discountInfo = discountInfo
        self.serviceCategory = serviceCategory
        self.initialAmount = initialAmount
        self.creationDate = creationDate
        self.qid = qid
        self.errorNo = errorNo
        self.error = error
        self.userName = userName
        self.transactionUUID = transactionUUID
        self.payStatus = payStatus
        self.car = car
        self.finalAmount = finalAmount
        self.id = id
        self.category = category
        self.mobileNumber = mobileNumber
        self.barcodeReference = barcodeReference
        self.inspectionType = inspectionType
        self.barcode = barcode

    }
}
