//
//  PaginatedNotification.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 28/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class PaginatedNotification: DomainModel {

    public var size: Int?
    public var count: Int?
    public var page: Int?
    var result: [Notification]?

    enum CodingKeys: String, CodingKey {
        case size, count, page, result
    }

    init(size: Int?, count: Int?, page: Int?, result: [Notification]? ) {
        self.size = size
        self.count = count
        self.page = page
        self.result = result
    }

}
