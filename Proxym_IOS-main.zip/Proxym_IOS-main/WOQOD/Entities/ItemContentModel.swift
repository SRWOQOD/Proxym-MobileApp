//
//  ItemContentModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 25/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class ItemContentModel {

    // MARK: - Properties
    var title: String
    var value: String
    var valueIsSelected: Bool
    var isMultipleLine: Bool

    // MARK: - Initialization
    init(title: String, value: String, valueIsSelected: Bool = false, isMultipleLine: Bool = false) {
        self.title = title
        self.value = value
        self.valueIsSelected = valueIsSelected
        self.isMultipleLine = isMultipleLine
    }
}
