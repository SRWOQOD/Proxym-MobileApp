//
//  FuelPrice.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class FahesStation: DomainModel {

    public var workingDays: String?
    public var workingDaysAR: String?
    public var title: String?
    public var titleAR: String?
    public var address: String?
    public var addressAR: String?
    public var secondAddress: String?
    public var secondAddressAR: String?
    public var lastSynchronisationDate: Int?
    public var areaId: Int?
    public var phone: String?
    public var id: Int?
    public var fahesId: Int?
    public var status: StationStatus?
    public var latitude: Double?
    public var longitude: Double?
    public var icon: String?
    public var area: Area?
    public var serviceStations: [ServiceStations]?

    init(workingDays: String?,
         workingDaysAR: String?,
         title: String? ,
         titleAR: String?,
         address: String?,
         addressAR: String?,
         secondAddress: String?,
         secondAddressAR: String?,
         lastSynchronisationDate: Int?,
         areaId: Int?,
         phone: String?,
         id: Int?,
         fahesId: Int?,
         status: StationStatus?,
         latitude: Double?,
         longitude: Double?,
         icon: String?,
         area: Area?,
         serviceStations: [ServiceStations]?
        ) {

        self.workingDays = workingDays
        self.workingDaysAR = workingDaysAR
        self.title = title
        self.titleAR = titleAR
        self.address = address
        self.addressAR = addressAR
        self.secondAddress = secondAddress
        self.secondAddressAR = secondAddressAR
        self.lastSynchronisationDate = lastSynchronisationDate
        self.areaId = areaId
        self.phone =  phone
        self.id = id
        self.fahesId = fahesId
        self.status = status
        self.latitude = latitude
        self.longitude = longitude
        self.icon = icon
        self.area = area
        self.serviceStations = serviceStations
    }
}
