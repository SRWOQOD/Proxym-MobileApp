//
//  Signature.swift
//  WOQOD
//
//  Created by rim ktari on 9/10/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class Signature: DomainModel {

    public var value: String?

    init(value: String?) {
        self.value = value
    }
}
