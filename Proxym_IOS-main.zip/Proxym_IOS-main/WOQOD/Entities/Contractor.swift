//
//  Contractor.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Contractor: DomainModel, Codable {

    public var title: String?
    public var address: String?
    public var phone: [String?]
    public var fax: String?
    public var email: String?

    init(title: String?, address: String?, phone: [String?], fax: String?, email: String?) {
        self.title = title
        self.address = address
        self.phone = phone
        self.fax = fax
        self.email = email
    }

}
