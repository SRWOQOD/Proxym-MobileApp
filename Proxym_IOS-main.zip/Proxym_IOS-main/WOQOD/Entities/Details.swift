//
//  PlateType.swift
//  WOQOD
//
//  Created by rim ktari on 9/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class Details: DomainModel {

    var name: String?
    var id: Int?

    init(name: String?, id: Int?) {
        self.name = name
        self.id = id
    }
}

class DetailsArea: DomainModel {

    var name: String?
    var id: Int?
    var latitude: String?
    var longitude: String?

    init(name: String?, id: Int?, latitude: String?, longitude: String?) {
        self.name = name
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
    }
}
