//
//  News.swift
//  WOQOD
//
//  Created by montassar YAAKOUBI on 29/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class News: DomainModel {

    public var listImageUrl: String?
    public var detailsImageUrl: String?
    public var linkUrl: String?
    public var endDate: Int64?
    public var title: String?
    public var description: String?
    public var id: Int?
    public var viewsNumber: Int?

    init(detailsPicture: String?, link: String?, listPicture: String?, details: String?,
         id: Int?, title: String?, creationDate: Int64?, views: Int?) {

        self.listImageUrl = listPicture
        self.detailsImageUrl = detailsPicture
        self.linkUrl = link
        self.endDate = creationDate
        self.title = title
        self.description = details
        self.id = id
        self.viewsNumber = views
    }

}
