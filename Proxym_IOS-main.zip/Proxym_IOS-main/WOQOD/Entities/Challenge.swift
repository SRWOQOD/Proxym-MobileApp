//
//  Challenge.swift
//  WOQOD
//
//  Created by rim ktari on 7/8/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

struct Challenge: Codable {
    public var header: ChallengeHeader?
    public var remainingAttempts: Int?
}

struct ChallengeHeader: Codable {
    public var statusCode: String?
    public var errorMsg: String?
}
