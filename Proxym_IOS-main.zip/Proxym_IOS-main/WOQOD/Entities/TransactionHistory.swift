//
//  TransactionHistory.swift
//  WOQOD
//
//  Created by rim ktari on 11/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class TransactionHistory: DomainModel {

    var plateNumber: String?
    var station: String?
    var date: String?
    var amount: String?

    init(plateNumber: String?, station: String?, date: String?, amount: String? ) {
        self.plateNumber =  plateNumber
        self.station = station
        self.date = date
        self.amount = amount

    }
}
