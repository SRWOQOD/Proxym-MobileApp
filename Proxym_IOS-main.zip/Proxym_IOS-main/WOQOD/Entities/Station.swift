//
//  Station.swift
//  WOQOD
//
//  Created by rim.ktari on 04/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class Station: DomainModel {

    var name: String?
    var id: Int?
    init(name: String?, id: Int?) {
        self.name = name
        self.id = id
    }
}
