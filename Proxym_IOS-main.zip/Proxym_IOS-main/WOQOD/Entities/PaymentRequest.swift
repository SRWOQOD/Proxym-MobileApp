//
//  PaymentRequest.swift
//  WOQOD
//
//  Created by rim ktari on 9/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class PaymentRequestModel: Codable {

    public var accessKey: String?
    public var profileId: String?
    public var transactionUuid: String?
    public var signedFieldNames: String?
    public var unsignedFieldNames: String?
    public var signedDateTime: String?
    public var locale: String?
    public var transactionType: String = PaymentValue.transactionType
    public var referenceNumber: String = ""
    public var amount: String?
    public var currency: String? = PaymentValue.currency
    public var billToForename: String?
    public var billToSurname: String?
    public var billToEmail: String?
    public var billToAddressLine1: String?
    public var billToAddressCountry: String?
    public var billToAddressCity: String?
    public var billToAddressPostalCode: String?
    public var customerIPAddress: String?

    enum CodingKeys: String, CodingKey {
        case accessKey = "access_key"
        case profileId = "profile_id"
        case transactionUuid = "transaction_uuid"
        case signedFieldNames = "signed_field_names"
        case unsignedFieldNames = "unsigned_field_names"
        case signedDateTime = "signed_date_time"
        case locale = "locale"
        case transactionType = "transaction_type"
        case referenceNumber = "reference_number"
        case amount = "amount"
        case currency = "currency"
        case billToForename = "bill_to_forename"
        case billToSurname = "bill_to_surname"
        case billToEmail  = "bill_to_email"
        case billToAddressLine1  = "bill_to_address_line1"
        case billToAddressCity = "bill_to_address_city"
        case billToAddressPostalCode    = "bill_to_address_postal_code"
        case customerIPAddress = "customer_ip_address"
        case billToAddressCountry = "bill_to_address_country"

    }

    init(amount: String?, transactionUUID: String?, referenceNumber: String?) {
        // We init amount and transactionUUID

        // Then we init the other fields
//        self.accessKey  = PaymentValue.paymentAccessKey
//        self.profileId = PaymentValue.paymentProfileId
        self.transactionUuid = transactionUUID
        self.signedFieldNames = PaymentValue.signedFieldsNames
        self.unsignedFieldNames = PaymentValue.emptyField
//        self.signedDateTime = signedDate
        self.locale = languageIsEnglish ? "en" : "ar-xn"
        self.transactionType = PaymentValue.transactionType
        self.referenceNumber = referenceNumber ?? ""
        self.amount = amount
        self.currency = PaymentValue.currency
        self.billToForename = PaymentValue.billToNameValue
        self.billToSurname  = PaymentValue.billToNameValue
        self.billToEmail  = PaymentValue.billToEmailValue
        self.billToAddressLine1  = PaymentValue.billToAddessLineValue
        self.billToAddressCountry = PaymentValue.billToAddressCountryValue
        self.billToAddressCity  = PaymentValue.billToAddressCityValue
        self.billToAddressPostalCode = PaymentValue.billToAddressPostalCodeValue
        self.customerIPAddress = PaymentValue.customerIPAddress

    }

    func convertToString() -> String {

        var array: [String] = []

        array.append("\(CodingKeys.accessKey.rawValue)=\(String(describing: accessKey!))")
        array.append("\(CodingKeys.profileId.rawValue)=\(String(describing: profileId!))")
        array.append("\(CodingKeys.transactionUuid.rawValue)=\(String(describing: transactionUuid!))")
        array.append("\(CodingKeys.signedFieldNames.rawValue)=\(String(describing: signedFieldNames!))")
        array.append("\(CodingKeys.unsignedFieldNames.rawValue)=\(String(describing: unsignedFieldNames!))")
        array.append("\(CodingKeys.signedDateTime.rawValue)=\(String(describing: signedDateTime!))")
        array.append("\(CodingKeys.locale.rawValue)=\(String(describing: locale!))")
        array.append("\(CodingKeys.transactionType.rawValue)=\(transactionType)")
        array.append("\(CodingKeys.referenceNumber.rawValue)=\(String(describing: referenceNumber))")
        array.append("\(CodingKeys.amount.rawValue)=\(String(describing: amount!))")
        array.append("\(CodingKeys.currency.rawValue)=\(String(describing: currency!))")
        array.append("\(CodingKeys.billToForename.rawValue)=\(String(describing: billToForename!))")
        array.append("\(CodingKeys.billToSurname.rawValue)=\(String(describing: billToSurname!))")
        array.append("\(CodingKeys.billToEmail.rawValue)=\(String(describing: billToEmail!))")
        array.append("\(CodingKeys.billToAddressLine1.rawValue)=\(String(describing: billToAddressLine1!))")
        array.append("\(CodingKeys.billToAddressCountry.rawValue)=\(String(describing: billToAddressCountry!))")
        array.append("\(CodingKeys.billToAddressCity.rawValue)=\(String(describing: billToAddressCity!))")
        array.append("\(CodingKeys.billToAddressPostalCode.rawValue)=\(String(describing: billToAddressPostalCode!))")
        array.append("\(CodingKeys.customerIPAddress.rawValue)=\(String(describing: customerIPAddress!))")

        return array.joined(separator: ",")
    }
    init() {}
}
