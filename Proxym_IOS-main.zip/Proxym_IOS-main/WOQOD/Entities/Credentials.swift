//
//  Credentials.swift
//  WOQOD
//
//  Created by rim ktari on 7/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

struct  Credentials: Codable {

    var username: String?
    var password: String?
    var rememberMe: Bool?
    var type: String?

    enum CodingKeys: String, CodingKey {
        case username, password, rememberMe, type
    }

    func appendHeaders() {

    }
    init(username: String, password: String, rememberMe: Bool, type: String) {
        self.username = username
        self.password = password
        self.rememberMe = rememberMe
        self.type = type
    }
}
