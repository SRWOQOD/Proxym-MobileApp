//
//  ApplicationTips.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 07/10/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class ApplicationTips: DomainModel {
    var orderItem: Int?
    var fileUrl: String?
    var id: Int?
    var active: Bool?

    init(orderItem: Int?,
         fileUrl: String?) {
        self.fileUrl = fileUrl
        self.orderItem = orderItem
    }

}
