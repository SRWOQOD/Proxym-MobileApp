//
//  Account.swift
//  WOQOD
//
//  Created by rim ktari on 9/1/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class Account: DomainModel, Codable {

    public var civilName: String?
    public var balance: String?
    public var fleetID: String?
    public var userHasBalance: Bool?

    override init() {}

    init(civilName: String?, balance: String?, fleetID: String?, userHasBalance: Bool?) {

        self.civilName = civilName
        self.balance = balance
        self.fleetID = fleetID
        self.userHasBalance = userHasBalance
    }

}
