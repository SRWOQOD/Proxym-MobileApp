//
//  UserToRegister.swift
//  WOQOD
//
//  Created by rim ktari on 10/20/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class UserToRegister {

    var username: String = ""
    var familyName: String = ""
    var firstName: String = ""
    var fullName: String = ""
    var mobileNumber: String = ""
    var email: String = ""
    var address: String = ""
    var qid: String = ""
    var birthdate: String = ""
    var idArea: String = ""
    var typeLogin: String = ""
    var poBox: String = ""
    var gender: String = ""
    var type: UserType? =  .individualCustomer
    var contactType: ContactType? = .mail
    var password: String  = ""
    var confirmPassword: String = ""
    var areaName: String = ""
}
