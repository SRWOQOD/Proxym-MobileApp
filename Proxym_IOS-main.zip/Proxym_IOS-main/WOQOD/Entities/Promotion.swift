//
//  Promotion.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Promotion: DomainModel {

    public var listImageUrl: String?
    public var detailsImageUrl: String?
    public var linkUrl: String?
    public var endDate: Int64?
    public var title: String?
    public var id: Int?
    public var description: String?

    init(image: String?, link: String?, title: String?, id: Int?,
         imageList: String?, endDate: Int64?, briefDescription: String?) {

        self.listImageUrl = imageList
        self.detailsImageUrl = image
        self.linkUrl = link
        self.endDate = endDate
        self.title = title
        self.id = id
        self.description = briefDescription
    }

}
