//
//  Slot.swift
//  WOQOD
//
//  Created by rim.ktari on 05/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

class Slot: DomainModel {
    var value: String?
    var identifier: Int?
    init(value: String?, identifier: Int?) {
        self.identifier = identifier
        self.value = value
    }
}
