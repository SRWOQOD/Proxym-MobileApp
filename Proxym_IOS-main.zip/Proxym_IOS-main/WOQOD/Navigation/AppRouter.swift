//
//  AppRouter.swift
//  WOQOD
//
//  Created by rim ktari on 6/29/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit
import Combine
import RESideMenu

class AppRouter {

    static var shared = AppRouter()
    var cancellable = Set<AnyCancellable>()

    var resideMenu: ResideMenuViewController?
    var menuVC: MenuViewController?
    var mainViewController: MainViewController?

    var navigationController: WQNavigationController?

    var currentMenu: MenuElement?

    func reloadMenuView() {
        updateMainViewWith(.home)
        menuVC?.reloadElements()
    }

    func reloadUserPhoto() {
        menuVC?.updateUserInfo()
    }

    func initSplashScreen() {
            let splashViewController = SplashViewController.instantiate(appStoryboardName: AppStoryboard.main)
            UIApplication.window?.rootViewController = splashViewController
    }

    /// This function is used when user changes the app language.
    /// He should not be redirected to the home menu but he have to stay in the settings view
    func resetLanguageViews() {
        self.initResideMenuViewController(type: currentMenu?.type ?? .home, menuElement: currentMenu)
    }

    func initBottomButtonAnimation() {
        self.mainViewController?.bottomMenuView.awakeFromNib()
    }

    func initResideMenuViewController(type: MenuElementType, menuElement: MenuElement? = nil) {
        if !shouldHideAppTips {
            let appTipsViewController = ApplicationTipsViewController.instantiate(appStoryboardName: AppStoryboard.main)
            UIApplication.window?.rootViewController = appTipsViewController
        } else {
            menuVC  = MenuViewController.instantiate(appStoryboardName: AppStoryboard.main)
            mainViewController = MainViewController.instantiate(appStoryboardName: AppStoryboard.main)
            mainViewController?.view.layoutIfNeeded()
            mainViewController!.setUpNavigationItem()

            navigationController =  WQNavigationController(rootViewController: mainViewController!)
            navigationController?.isNavigationBarHidden = true
            resideMenu = ResideMenuViewController(contentViewController: navigationController,
                                                  leftMenuViewController: languageIsEnglish ? menuVC : nil,
                                                  rightMenuViewController: !languageIsEnglish ? menuVC : nil)
            resideMenu?.scaleMenuView = false
            resideMenu?.contentViewScaleValue = 0.77
            resideMenu?.scaleBackgroundImageView = false

            UIApplication.window?.rootViewController = resideMenu
            self.setUpSideMenu()
            switch type {
            case .home:
                updateMainViewWith(.home)
            case .notifications, .feedback, .topup:
                let viewController = menuElement?.viewControllerType?
                    .instantiate(appStoryboardName: menuElement?.storyboard ?? "")
                mainViewController?.upadateWith(viewController: viewController)
            case .aboutUs, .contactUs, .settings, .resetPassword:
                self.updateViewController(menuElement)

            case .account, .login, .locations, .shafaf, .stockPrices, .tenders :
                self.updateViewController(menuElement)
            case .fahes, .woqode :
                updateViewController(menuElement?.viewController)
            case .loginFromHome :
                AppRouter.shared.updateViewController(menuElement?.viewController)
            case .news:
                mainViewController?.upadateWith(menuElement: menuElement)
            default:
                mainViewController?.upadateWith(viewController: menuElement?.viewController)

            }
        }
    }

    func updateViewWith(type: MenuElementType) {
        menuVC?.updateViewWith(type: type)
    }

    func updateViewController(_ viewController: UIViewController?) {
        self.resideMenu?.hideViewController()
        mainViewController!.upadateWith(viewController: viewController)
    }

    func updateViewController(_ menuItem: MenuElement?) {
        self.resideMenu?.hideViewController()
        mainViewController!.upadateWith(menuElement: menuItem)
    }

    func updateMainViewWith(_ type: MenuElementType?) {
        mainViewController!.updateViewWith(type: type)
    }

    func updateViewsAfterLogout() {
        AuthManager.shared.logout()
        self.updateViewWith(type: .home)
        self.reloadMenuView()
        AppDelegate.shared?.registerDeviceForMFPPush()
        hideActivityIndicator()
    }

    func updateViewsAfterSessionExpired() {
        AuthManager.shared.cancelChallenge()
        self.mainViewController?.popToRootViewController()
        self.updateMainViewWith(.home)
        self.reloadMenuView()
        hideActivityIndicator()
    }

    func logout() {
        AppDelegate.shared?.unregisterDeviceFromPush()
        showActivityIndicator()
        self.logoutToRemoveUser()
    }

    func reloadHomeView(menuElement: MenuElement?) {
        let viewC = menuElement?.viewController as? HomeViewController
        viewC?.view.layoutIfNeeded()
        viewC?.reloadElements()
    }

    func hideSideMenu() {
        self.resideMenu?.hideViewController()
    }

    func setUpSideMenu() {

        menuVC?.menuViewModel.selectedItem.sink { (menuElement) in

            let type = menuElement?.type
            switch type {
            case .rentAshop:
                openURL(urlString: rentAshopURLstring)
            case .logout:
                self.logout()
            default:
                self.currentMenu = menuElement
                self.updateViewController(menuElement)
                self.reloadHomeView(menuElement: menuElement)
            }

        }.store(in: &cancellable)
    }

    // This func is added to remove user from device after logout
    func logoutToRemoveUser() {
        let stateHandler: StateHandler = { result in
            switch result {
            case .finished:
                self.updateViewsAfterLogout()
            case .failure:
                self.updateViewsAfterLogout()
            }
        }
        let receiveValue: (Bool, Bool) -> Void = { (_, hasloggedOut) in
            #if DEBUG
            print("hasloggedOut, \(hasloggedOut)")
            #endif
        }

        LoginAPIManager.logout()
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

    func goToLocationForRating() {
        self.mainViewController?.popToRootViewController()
        let viewController =  LocationsViewController.instantiate(
            appStoryboardName: AppStoryboard.locations) as? LocationsViewController
        viewController?.locationsDirectionPath = .fromRating
        AppRouter.shared.currentMenu =
        MenuElement(type: .locations,
                         viewController: viewController)
        AppRouter.shared.updateViewController(viewController)
    }

}
