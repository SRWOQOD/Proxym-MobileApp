//
//  ApplicationTipsViewController.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 07/10/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import UIKit
import Combine

class ApplicationTipsViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var skipButton: WQButton!
    @IBOutlet weak var nextButton: WQButton!

    private var cancellable = Set<AnyCancellable>()
    private let appTipsVM = ApplicationTipsViewModel()
    var viewControllers: [UIViewController] = []
    private var selectedIndex: Int = 0
    var lastIndexSelected: Int = 0

    let pageViewController: PageViewController = PageViewController.instantiate()
    private var theParentViewController: UIViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        bindData()

    }

    func initUI() {
        setUpButtons()
    }

    func bindData() {
        appTipsVM.getApplicationTips()
        appTipsVM.state.sink { _ in
            hideActivityIndicator()
            self.setUpPageControl()
            self.setupPageViewController()
            self.setUpViewControllers()
            self.changeVC(direction: nil)
        }.store(in: &cancellable)

    }

    private func setUpButtons() {
        setUpWQButton(button: skipButton, style: Buttontype.secondary,
                      title: LocalizableShared.commonSkip.localized, action: {
                        AuthManager.shared.shouldHideAppTips = true
                        AppRouter.shared.initResideMenuViewController(type: .home)
                      })

        setUpWQButton(button: nextButton, style: Buttontype.primary,
                      title: LocalizableShared.next.localized, action: {
                        self.setUpNextAction()
                      })
    }

        func setUpNextAction() {
            if  appTipsVM.applicationTipsList?.count == nil {
                AuthManager.shared.shouldHideAppTips = true
                AppRouter.shared.initResideMenuViewController(type: .home)
            } else {
                self.changeVC(direction: .forward)
            }

        }

    private func setUpWQButton(button: WQButton?, style: WQButtonStyle, title: String?, action: (() -> Void)?) {
        button?.style = style
        button?.title = title
        button?.didTapOnButton = action
    }

    private func changeVC(direction: UIPageViewController.NavigationDirection?) {
        var index = 0

        switch direction {

        case .forward?:
            if lastIndexSelected < (appTipsVM.applicationTipsList?.count ?? 0) - 1 {
                index = lastIndexSelected + 1
            } else if lastIndexSelected == (appTipsVM.applicationTipsList?.count ?? 0) - 1 {
                AuthManager.shared.shouldHideAppTips = true
                AppRouter.shared.initResideMenuViewController(type: .home)
            }

        case .reverse?:
            if lastIndexSelected > 0 {
                index = lastIndexSelected - 1
            }
        default:
            break
        }

        pageViewController.setViewController(index: index, direction: direction ?? .forward)
        updateIndexes(index: index)
    }
    private func updateIndexes(index: Int) {
        self.lastIndexSelected = index
        pageControl.currentPage = lastIndexSelected
    }
    private func setupPageViewController() {
        theParentViewController = self
        pageViewController.setupPageViewController(contentView: self.containerView)
        self.pageViewController.didChangeViewAt = { (index) in
            self.updateIndexes(index: index)
        }
        theParentViewController?.addChild(self.pageViewController)
    }
    private func setUpViewControllers() {
        viewControllers = []
        if self.appTipsVM.applicationTipsList?.count ?? 0 > 0 {
            self.appTipsVM.applicationTipsList?.forEach {
                let applicationTipsContentVC: ApplicationTipsContentViewController
                    = ApplicationTipsContentViewController.instantiate(appStoryboardName: AppStoryboard.main)
                applicationTipsContentVC.imageURL = $0
                viewControllers.append(applicationTipsContentVC)
            }
        } else {
            let applicationTipsContentVC: ApplicationTipsContentViewController
                = ApplicationTipsContentViewController.instantiate(appStoryboardName: AppStoryboard.main)
            applicationTipsContentVC.imageURL = ""
            viewControllers.append(applicationTipsContentVC)
        }
        pageViewController.views = viewControllers
    }
    private func setUpPageControl() {
        pageControl.numberOfPages = appTipsVM.applicationTipsList?.count ?? 0
        pageControl.currentPage = selectedIndex
        pageControl.pageIndicatorTintColor = UIColor.wqBlue.withAlphaComponent(0.6)
        pageControl.currentPageIndicatorTintColor = UIColor.wqBlue
    }
}
