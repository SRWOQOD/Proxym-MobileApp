//
//  ApplicationTipsViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 07/10/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class ApplicationTipsViewModel: ViewModel {
    // MARK: - Public properties
    var applicationTipsList: [String]?

    // MARK: - private methods

    func getApplicationTips() {
        let stateHandler: StateHandler = { (result) in
            switch result {
            case .finished: break
            case .failure(let error): self.state.send(.error(error as? WQError ?? WQError()))
            }
        }
        let receiveValue: ([ApplicationTipsDTO], [ApplicationTips]) -> Void = { (_, appTipsList) in
            self.applicationTipsList = appTipsList.sorted {
                Int($0.orderItem ?? 0) < Int($1.orderItem ?? 0)
            }.map({
                $0.fileUrl ?? ""
            })
            self.state.send(.finishedLoading)
        }
        HomeAPIManager.getApplicationTips()
            .sink(receiveCompletion: stateHandler, receiveValue: receiveValue)
            .store(in: &cancellable)
    }

}
