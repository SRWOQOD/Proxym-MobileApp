//
//  ApplicationTipsContentViewController.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 07/10/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit

class ApplicationTipsContentViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!

    var imageURL: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.setImage(withString: imageURL ?? "",
                           placeholderImage: UIImage(named: "ic_app_tips_placehorler"))
        imageView.cornerRadius = 11.adjusted
    }
}
