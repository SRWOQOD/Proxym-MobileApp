//
//  MenuTableViewCell.swift
//  WOQOD
//
//  Created by rim ktari on 6/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var menuImage: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func setupView(viewModel: MenuElement?) {
        guard let viewModel = viewModel else { return }
        self.titleLabel.setText(text: viewModel.title, font: Fonts.mediumFontName, size: 15, forgroundColor: .wqBlue)
        menuImage.image = viewModel.image
        self.backgroundColor = (viewModel.type == .resetPassword) ?  UIColor.wqBlue.withAlphaComponent(0.05) : .clear
    }
}
