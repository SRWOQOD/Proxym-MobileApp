//
//  MenuViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 6/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

struct MenuElement {
    var title: String?
    var type: MenuElementType?
    var viewController: UIViewController?
    var viewControllerType: UIViewController.Type?
    var image: UIImage?
    var imageDisabled: UIImage?
    var imageEnabled: UIImage?
    var storyboard: String?

    init(title: String? = nil,
         type: MenuElementType? = nil,
         viewControllerType: UIViewController.Type? = nil,
         viewController: UIViewController? = nil,
         image: UIImage? = nil,
         imageDisabled: UIImage? = nil,
         imageEnabled: UIImage? = nil,
         storyboard: String? = nil) {

        self.title = title
        self.type = type
        self.viewControllerType = viewControllerType
        self.viewController = viewController
        self.image = image
        self.imageDisabled = imageDisabled
        self.imageEnabled = imageEnabled
        self.storyboard = storyboard
    }

}

public enum MenuElementType: String {
    case home = "home"
    case fahes = "FAHEs"
    case loginFromHome = "loginFromHome"
    case woqode = "woqode"
    case shafaf = "shafaf"
    case locations = "locations"
    case register = "register"
    case promotions = "promotions"
    case aboutUs = "aboutUs"
    case settings = "settings"
    case shareApp = "shareApp"
    case feedback = "feedback"
    case account = "account"
    case fuelPrices = "fuelPrices"
    case login = "login"
    case logout = "logout"
    case notifications = "notifications"
    case information = "information"
    case tenders = "tenders"
    case rentAshop = "rentAshop"
    case resetPassword = "resetPassword"
    case language = "language"
    case privacyPolicy = "privacyPolicy"
    case termsofUse = "termsOfUse"
    case contactUs = "contactUs"
    case stockPrices = "stockPrices"
    case news = "news"
    case topup = "topUp"

}

class MenuViewModel: ViewModel {

    var menuElements: [MenuElement]? {
        return  userIsConnected ? menuElementsConnected : menuElementsGuest
    }
    var selectedItem = PassthroughSubject<MenuElement?, Never>()

    var menuElementsConnected: [MenuElement]?
    var menuElementsGuest: [MenuElement]?

    var registerMenuElement: MenuElement?

    let registerViewController = RegisterQidViewController
        .instantiate(appStoryboardName: AppStoryboard.authentification) as? RegisterQidViewController

    var selectedItemType: MenuElementType? {
        didSet {
            let menuElement = menuElements?.filter {$0.type == selectedItemType }.first
            self.selectedItem.send(menuElement)
        }
    }

    override init() {
        super.init()
        initMenuElements()
        initRegisterMenuElement()
    }

    func initRegisterMenuElement() {
        registerViewController?.registrationPath = .fromMenu
        self.registerMenuElement = MenuElement(type: .register,
                                             viewController: registerViewController)
    }

    func initMenuElements() {
        // View controllers
        let aboutUsViewController =  WQStaticScreenViewController
            .instantiate(appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
        aboutUsViewController?.strategy = AboutUsStrategy()

        let privacyPolicyViewController =  WQStaticScreenViewController
            .instantiate(appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
        privacyPolicyViewController?.strategy = PrivacyPolicyStrategy()

        let loginViewController = LoginViewController.instantiate(appStoryboardName: AppStoryboard.authentification)

        let settingsViewController = SettingsViewController.instantiate(appStoryboardName: AppStoryboard.settings)

        let bulkLPGViewController = BulkLPGViewController.instantiate(appStoryboardName: AppStoryboard.bulkLPG)

        let termsOfUseViewController =  WQStaticScreenViewController
            .instantiate(appStoryboardName: AppStoryboard.staticScreen) as? WQStaticScreenViewController
        termsOfUseViewController?.strategy = TermsOfUseStrategy()

        let contactUsViewController =  ContactUsViewController
            .instantiate(appStoryboardName: AppStoryboard.staticScreen) as? ContactUsViewController
        // sideMenu elements
        let resetPasswordElement = MenuElement(title: LocalizedAccount.menuResetPassword.localized,
                                               type: .resetPassword,
                                               viewControllerType: SendPincodeViewController.self,
                                               image: UIImage(named: "ic_menu_reset_pass"),
                                               storyboard: AppStoryboard.authentification)

        let aboutUsElement = MenuElement(title: LocalizableStaticScreens.aboutWoqodTitle.localized,
                                         type: .aboutUs,
                                         viewController: aboutUsViewController,
                                         image: UIImage(named: "ic_menu_aboutUs"))
        let bulkLpgElement = MenuElement(title: Localizable.menuBulkLpg.localized, type: .aboutUs,
                                         viewController: bulkLPGViewController,
                                         image: UIImage(named: "ic_bulkLpg_logo"))
        let settingsElement = MenuElement(title: Localizable.menuSettings.localized, type: .settings,
                                         viewController: settingsViewController,
                                         image: UIImage(named: "ic_menu_settings")?.withTintColor(UIColor.wqBlue),
                                         storyboard: AppStoryboard.staticScreen)

        let privacyPolicyElement = MenuElement(title: Localizable.menuPrivacyPolicy.localized,
                                               type: .privacyPolicy,
                                               viewController: privacyPolicyViewController,
                                               image: UIImage(named: "ic_menu_privacy_policy"),
                                               storyboard: AppStoryboard.staticScreen)

        let termsOfUseElement = MenuElement(title: Localizable.menuTermsOfUse.localized,
                                            type: .termsofUse,
                                            viewController: termsOfUseViewController,
                                            image: UIImage(named: "ic_menu_terms_of_use"),
                                            storyboard: AppStoryboard.staticScreen)
        let contactUsElement = MenuElement(title: Localizable.menuContactUs.localized, type: .contactUs,
                                           viewController: contactUsViewController,
                                           image: UIImage(named: "ic_menu_contact_us"))

        let logoutElement = MenuElement(title: Localizable.menuLogout.localized,
                                        type: .logout, viewController: loginViewController,
                                        image: UIImage(named: "ic_menu_logout"))
        let emptyElement = MenuElement()
        menuElementsConnected = [resetPasswordElement, aboutUsElement,
                                 privacyPolicyElement, contactUsElement, bulkLpgElement,
                                 settingsElement, emptyElement, logoutElement]

        menuElementsGuest = [aboutUsElement, privacyPolicyElement,
                             termsOfUseElement, contactUsElement,
                             bulkLpgElement,
                             settingsElement]

    }
}
