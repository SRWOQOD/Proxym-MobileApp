//
//  ResideMenuViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/6/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import RESideMenu

class ResideMenuViewController: RESideMenu {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.backgroundImage = UIImage(named: "ic_resideMenu_bg")

    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
