//
//  MenuViewController.swift
//  WOQOD
//
//  Created by rim ktari on 6/26/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine
import RESideMenu

class MenuViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var headerView: WQHeaderView!
    @IBOutlet weak var tableView: UITableView!
    // Guest User View elements
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var guestUserView: UIView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var registerButton: UIButton!
    // Connected User View elements
    @IBOutlet weak var connectedUserView: UIView!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    // MARK: - Public properties

    var menuViewModel = MenuViewModel()

    // MARK: - Overrides

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
//        initHeaderView()
        initConnectedViews()
        hideElementsIfNeeded()
        profileImageView.round()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateUserInfo()
    }
    // MARK: - Methods

    func initConnectedViews() {
        // For connected state
        welcomeLabel.setText(text: Localizable.menuWelcomeMsg.localized,
                             font: Fonts.boldFontName, size: 14,
                             forgroundColor: .wqBlue,
                             align: .center)
        loginButton.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.11),
                           borderwidth: 1, cornerRadius: 11)
        loginButton.title = Localizable.menuLogin.localized.uppercased()
        registerButton.title = LocalizableShared.register.localized.uppercased()
        connectedUserView.backgroundColor = UIColor.wqBlue.withAlphaComponent(0.05)
    }
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.registerCellNib(MenuTableViewCell.self)
        tableView.isScrollEnabled = false
    }

//    func initHeaderView() {
//        headerView.sideMenuButton.setImage(UIImage(named: "ic_close"), for: .normal)
//        headerView.menuAction = {
//            AppRouter.shared.hideSideMenu()
//        }
//    }

    func updateUserInfo() {
        if  let image =  AuthManager.shared.photo {
            self.profileImageView.image = image.base64ToImage()
        } else {
            self.profileImageView.setTintedImage(image: #imageLiteral(resourceName: "ic_default_img_profile.png"), color: .white)
        }
        self.nameLabel.setText(text: AuthManager.shared.currentUser?.fullName,
                               font: Fonts.boldFontName, size: 14, forgroundColor: .wqBlue,
                               align: languageIsEnglish ? .left : .right)
    }

    func updateViewWith(type: MenuElementType) {
        self.menuViewModel.selectedItemType = type
    }
    func hideElementsIfNeeded() {
        connectedUserView.isHidden = !userIsConnected
        guestUserView.isHidden = userIsConnected
    }
    func reloadElements() {

        self.tableView.reloadData()
        hideElementsIfNeeded()
        updateUserInfo()
    }
    // Actions
    @IBAction func accountAction(_ sender: Any) {
        let accountMenuElement = MenuElement(type: .account,
                                             viewControllerType: ProfileViewController.self,
                                             storyboard: AppStoryboard.account)
        AppRouter.shared.currentMenu = accountMenuElement
        AppRouter.shared.updateViewController(accountMenuElement)
    }
    @IBAction func loginAction(_ sender: Any) {
        let loginMenuElement = MenuElement(type: .login,
                                           viewControllerType: LoginViewController.self,
                                           storyboard: AppStoryboard.authentification)
        AppRouter.shared.currentMenu = loginMenuElement
        AppRouter.shared.updateViewController(loginMenuElement)
    }

    @IBAction func registerAction(_ sender: Any) {
        let registerViewController = RegisterQidViewController
            .instantiate(appStoryboardName: AppStoryboard.authentification) as? RegisterQidViewController
        registerViewController?.registrationPath = .fromMenu
        let registerMenuElement = MenuElement(type: .register,
                                              viewController: registerViewController)
        AppRouter.shared.currentMenu = registerMenuElement
        AppRouter.shared.updateViewController(registerMenuElement)
    }
    // MARK: - Actions
    @IBAction func closeAction(_ sender: Any) {
        AppRouter.shared.hideSideMenu()
    }
}

// MARK: - UITableViewDelegate,UITableViewDataSource

extension MenuViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuViewModel.menuElements?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath)
            as? MenuTableViewCell
        else {return UITableViewCell()}
        cell.setupView(viewModel: menuViewModel.menuElements?[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.menuViewModel.selectedItem.send(menuViewModel.menuElements?[indexPath.row])
    }
}
