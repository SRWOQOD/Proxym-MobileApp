//
//  SplashViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine
import IBMMobileFirstPlatformFoundation
import AVFoundation
import AVKit

class SplashViewController: UIViewController {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    let playerController = AVPlayerViewController()

    let viewModel = SplashViewModel()
    var cancellable = Set<AnyCancellable>()
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        checkJailBroken()
    }
    
    func checkJailBroken() {
        if isDeviceJailBroken {
            showErrorAlertView(descriptionMessage: LocalizableShared.errorJailBroken.localized, didConfirm: {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
                     DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                      exit(0)
                        }
                    }
                }
            )
        } else {
            bindData()
            playVideo()
        }
    }

    func bindData() {

        activityIndicator.startAnimating()

        viewModel.state.sink { [unowned self] state  in
            self.activityIndicator.hide()
            self.activityIndicator.isHidden = true

            switch state {
            case .error:
                AuthManager.shared.currentUser = nil
                AccountManager.shared.userAccount = nil
            case .finishedLoading: break
            case .loading: break
            }
        }.store(in: &cancellable)
        viewModel.obtainAccessToken()

    }

    private func playVideo() {
        // drag your video file in  project
        // check if video file is available,if not return
        guard let path = Bundle.main.path(forResource: "splash", ofType: "mp4") else {
            #if DEBUG
            debugPrint("video.mp4 missing")
            #endif
            return
        }
        // create instance of videoPlayer with video path
        let videoPlayer = AVPlayer(url: URL(fileURLWithPath: path))
        // create instance of playerlayer with videoPlayer
        let playerLayer = AVPlayerLayer(player: videoPlayer)
        // set its videoGravity to AVLayerVideoGravityResizeAspectFill to make it full size
        playerLayer.videoGravity = .resize
        // add it to your view
        playerLayer.frame = self.view.frame
        self.view.layer.addSublayer(playerLayer)
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying),
                                               name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
                                               object: playerController.player?.currentItem)

        // start playing video
        videoPlayer.play()
    }

    @objc func  playerDidFinishPlaying() {
        AppRouter.shared.initResideMenuViewController(type: .home)
        AppDelegate.shared?.loaded = true

    }
}
