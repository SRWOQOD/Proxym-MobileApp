//
//  WQNavigationController.swift
//  WOQOD
//
//  Created by rim ktari on 10/12/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

class WQNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }

    func initUI() {
        let navigationBarAppearace = UINavigationBar.appearance()
        navigationBarAppearace.isTranslucent = true
        navigationBarAppearace.tintColor = UIColor.white

//        let navBackgroundImage: UIImage! = #imageLiteral(resourceName: "ic_nav_bg.png")
//        navigationBarAppearace.setBackgroundImage(navBackgroundImage, for: .default)

        let style = UINavigationBarAppearance()
//        style.backgroundImage = navBackgroundImage
        style.shadowColor = .clear
        style.backgroundImageContentMode = .scaleToFill
        style.setBackIndicatorImage(#imageLiteral(resourceName: "back_button.png"), transitionMaskImage: #imageLiteral(resourceName: "back_button.png"))
        let button = UIBarButtonItemAppearance(style: .plain)

        // clear to hide back text
        button.normal.titleTextAttributes = [.foregroundColor: UIColor.clear]
        style.buttonAppearance = button
        UINavigationBar.appearance().standardAppearance = style
    }

}
