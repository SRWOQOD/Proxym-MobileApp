//
//  MainViewController.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class MainViewController: UIViewController {

    // MARK: - Outlets

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var bottomMenuView: WQBottomMenuView!

    var cancellable = Set<AnyCancellable>()

    // This is used to handle navigation for woqode users
    var woqodeViewModel = WOQODeMenuViewModel()
    var woqodeMenuViewController: UIViewController?
    var feedbackMenuViewController: UIViewController?
    var woqodeMenuElement: MenuElement?
    // MARK: - Overrides

    override func viewDidLoad() {
        super.viewDidLoad()
        bindWoqodeData()
        self.bindToSelectedItems()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        bottomMenuView.awakeFromNib()
    }

    func bindWoqodeData() {
        woqodeViewModel.state.sink { _ in
            // handle navigation for woqode users
            self.redirectWoqodeUsers()
            hideActivityIndicator()
        }.store(in: &cancellable)
    }

    // MARK: - Private Methods

    private func bindToSelectedItems() {
        bottomMenuView.menuViewModel.selectedItem.sink { (item) in
            switch item?.type {
            case .topup :
                self.woqodeMenuElement = item
                if !userIsConnected {
                    let woqodeMenuViewController =
                        item?.viewControllerType?.instantiate(appStoryboardName: item?.storyboard ?? "")
                        as? WOQODeMenuViewController
                    woqodeMenuViewController?.shouldCallGetBalance = false
                    AppRouter.shared.currentMenu = item
                    self.upadateWith(viewController: woqodeMenuViewController)
                    let guestWoqodeTopUpViewController =
                        GuestWoqodeTopUpViewController.instantiate(appStoryboardName: AppStoryboard.woqode)
                    woqodeMenuViewController?.push(viewController: guestWoqodeTopUpViewController)
                } else {
                    showActivityIndicator()
                    self.woqodeViewModel.getBalance()
                }
            case .language :
                self.bottomMenuView.menuViewModel.updateLanguage()
            case .feedback:
                let postElementMenu = MenuElement.init(type: .feedback,
                                                       viewControllerType: PostFeedbackViewController.self,
                                                       storyboard: AppStoryboard.feedback)
                if !userIsConnected {
                    AppRouter.shared.currentMenu = postElementMenu
                    self.upadateWith(menuElement: postElementMenu)
                } else {
                    AppRouter.shared.currentMenu = item
                    self.upadateWith(menuElement: item)
                }
            case .notifications:
                AppRouter.shared.currentMenu = item
                self.upadateWith(menuElement: item)
            default:
                AppRouter.shared.currentMenu = item
                self.upadateWith(viewController: item?.viewController)
            }
        }.store(in: &cancellable)
    }

    func redirectWoqodeUsers() {
        if userHasBalance {
            let woqodeMenuViewController =
                woqodeMenuElement?.viewControllerType?
                .instantiate(appStoryboardName: woqodeMenuElement?.storyboard ?? "")
                as? WOQODeMenuViewController
            woqodeMenuViewController?.shouldCallGetBalance = false
            AppRouter.shared.currentMenu = woqodeMenuElement
            self.upadateWith(viewController: woqodeMenuViewController)
            let woqodeTopUpViewController =
                WoqodeTopUpViewController.instantiate(appStoryboardName: AppStoryboard.woqode )
                as? WoqodeTopUpViewController
            guard let woqodeTopUpVC = woqodeTopUpViewController else { return }
            woqodeMenuViewController?.push(viewController: woqodeTopUpVC)
        } else {
            let aboutWoqodeVC = WQStaticScreenViewController.instantiate(
                appStoryboardName: AppStoryboard.staticScreen)
                as? WQStaticScreenViewController
            aboutWoqodeVC?.strategy = AboutWoqodStrategy()
            woqodeMenuElement?.type = .aboutUs
            woqodeMenuElement?.viewController = aboutWoqodeVC
            AppRouter.shared.currentMenu = woqodeMenuElement
            aboutWoqodeVC?.path = .fromBottomMenu
            self.upadateWith(viewController: aboutWoqodeVC)
        }

    }
    // MARK: - Public Methods

    public func upadateWith(menuElement: MenuElement?) {
        guard let type = menuElement?.type else { return }

        switch type {
        case .feedback, .woqode, .news, .notifications, .account, .login, .tenders:
            let viewController =
                menuElement?.viewControllerType?.instantiate(appStoryboardName: menuElement?.storyboard ?? "")
            self.upadateWith(viewController: viewController)
            return
        case .resetPassword:
            let viewController =
                menuElement?.viewControllerType?
                .instantiate(appStoryboardName: menuElement?.storyboard ?? "") as? SendPincodeViewController
            viewController?.strategy = AccountResetPasswordStrategy()
            self.upadateWith(viewController: viewController)
            return
        default:
            self.upadateWith(viewController: menuElement?.viewController)
        }

    }

    func updateViewWith(type: MenuElementType?) {
        self.bottomMenuView.menuViewModel.selectedItemType = type
        self.bottomMenuView.selectItemFor(type: type)
    }

    public func upadateWith(viewController: UIViewController?) {
        self.removeViewController(self.children.first)
        self.addViewController(targetView: containerView, targetViewController: viewController)
    }

}
