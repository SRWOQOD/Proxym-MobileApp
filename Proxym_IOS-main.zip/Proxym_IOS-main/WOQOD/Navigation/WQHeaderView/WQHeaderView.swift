//
//  WQHeaderView.swift
//  WOQOD
//
//  Created by rim.ktari on 31/05/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit

// enum WQHeaderButtonType {
//    case back
//    case menu
// }

@IBDesignable
class WQHeaderView: UIView {

    @IBOutlet weak var sideMenuButton: UIButton!
    var menuAction : (() -> Void)?

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        if Language.currentLanguage == .arabic {
            sideMenuButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
        }
    }

    @IBAction func sideMenuAction(_ sender: Any) {
        menuAction?()
    }

}
