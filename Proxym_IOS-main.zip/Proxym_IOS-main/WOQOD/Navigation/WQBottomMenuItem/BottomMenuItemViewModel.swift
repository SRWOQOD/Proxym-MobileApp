//
//  BottomMenuItemViewModel.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

// MARK: - Enum
enum BottomMenuCellType {
    case locations
    case notifications
    case home
    case language
    case information

}

class BottomMenuViewModel: NSObject {

    var tabBarItems: [MenuElement] = []
    var selectedItem = PassthroughSubject<MenuElement?, Never>()

    var selectedItemType: MenuElementType? {
        didSet {
            let menuElement = tabBarItems.filter {$0.type == selectedItemType }.first
            self.selectedItem.send(menuElement)
        }
    }

    override init() {
        super.init()
        initTabBarItems()
    }

    func initTabBarItems() {

        let homeViewController =  HomeViewController.instantiate(appStoryboardName: AppStoryboard.main)
        // home submenu items
        tabBarItems = [
            MenuElement.init(type: .feedback, viewControllerType: FeedbacksMenuViewController.self,
                             imageDisabled: #imageLiteral(resourceName: "ic_bottom_menu_feedback"),
                             imageEnabled: #imageLiteral(resourceName: "ic_bottom_menu_feedback"),
                             storyboard: AppStoryboard.feedback),

            MenuElement.init( type: .topup, viewControllerType: WOQODeMenuViewController.self,
                              imageDisabled: #imageLiteral(resourceName: "ic_bottom_menu_money"), imageEnabled: #imageLiteral(resourceName: "ic_bottom_menu_money"),
                              storyboard: AppStoryboard.woqode),
            MenuElement.init(type: .home, viewController: homeViewController, imageDisabled: nil,
                             imageEnabled: nil),
            MenuElement.init(type: .language, viewController: nil,
                             imageDisabled: languageIsArabic ? #imageLiteral(resourceName: "ic_bottom_menu_lang_en") :#imageLiteral(resourceName: "ic_bottom_menu_lang_ar") ,
                             imageEnabled: languageIsArabic ? #imageLiteral(resourceName: "ic_bottom_menu_lang_en") :#imageLiteral(resourceName: "ic_bottom_menu_lang_ar") ),
            MenuElement.init(type: .notifications,
                             viewControllerType: NotificationsListViewController.self,
                             imageDisabled: #imageLiteral(resourceName: "ic_bottom_menu_notifications"), imageEnabled: #imageLiteral(resourceName: "ic_bottom_menu_notifications"),
                             storyboard: AppStoryboard.notifications)]
    }
    func updateLanguage() {
        AuthManager.shared.didChangeLanguage = true
        Language.currentLanguage = (Language.currentLanguage.isEnglish) ? .arabic : .english
        AppRouter.shared.resetLanguageViews()
        HomeManager.shared.deviceHasNotif()
    }
}
