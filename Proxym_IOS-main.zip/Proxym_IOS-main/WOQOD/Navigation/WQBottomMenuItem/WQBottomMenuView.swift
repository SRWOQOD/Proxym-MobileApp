//
//  WQBottomMenuView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 14/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class WQBottomMenuView: UIView {

    // MARK: - Outlets

    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var mainMenuButton: UIImageView!

    // MARK: - Properties
    var didSelectButton: ((_ item: MenuElement) -> Void)?
    var menuViewModel = BottomMenuViewModel()

    let kCentredIndex = 2
    // MARK: - Private Properties
    private var tabBarButtonArray: [WQBottomMenuItemView] = []
    private var cancellable = Set<AnyCancellable>()

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        setUpTabbarView()
        initHomeButtonAnimation()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        setUpTabbarView()
        initHomeButtonAnimation()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        self.mainMenuButton.alpha = 1
        self.initHomeButtonAnimation()
    }

    // MARK: - Private methods

    private func setUpTabbarView() {

        setupTabbarItems()
        bindData()

    }

    private func initHomeButtonAnimation() {
        UIView.animate(withDuration: 2.0, delay: 0, options: [.repeat, .autoreverse], animations: {

            self.mainMenuButton.alpha = 0.3

        }, completion: nil)
    }

    private func setupTabbarItems() {
        let items = menuViewModel.tabBarItems
        items.enumerated().forEach { (item) in
            let itemView = WQBottomMenuItemView()
            let itemWidth = CGFloat(self.bgView.frame.width) / CGFloat(items.count)
            let itemHeight = self.bgView.frame.height
            itemView.frame.size.height = itemHeight
            itemView.frame.size.width = itemWidth
            itemView.setUpItemView(menuItem: item.element)
            itemView.button.tag = item.offset
            itemView.button.addTarget(self, action: #selector(didpressTabItem(sender:)), for: .touchUpInside)
            itemView.button.translatesAutoresizingMaskIntoConstraints = false
            tabBarButtonArray.append(itemView)
        }

        tabBarButtonArray.forEach { (itemButton) in
            stackView.addArrangedSubview(itemButton)
        }
    }

    @objc private func didpressTabItem(sender: UIButton) {
        let item = menuViewModel.tabBarItems[sender.tag]
        menuViewModel.selectedItem.send(item)

        self.selectItemFor(type: item.type)
    }

    // MARK: - Public methods

    public func selectItemFor(type: MenuElementType?) {

        shouldResetButton()

        if let index = menuViewModel.tabBarItems.firstIndex(where: { $0.type == type}) {
            tabBarButtonArray[index].button.isSelected = true
        }

    }

    func bindData() {
        HomeManager.shared.hasNotif.sink { hasNotif in
            guard let index = self.menuViewModel.tabBarItems
                    .firstIndex(where: { $0.type == .notifications}) else { return }
            let notificationsButton = self.tabBarButtonArray[index]
            let imageForNotif = !hasNotif ? UIImage(named: "ic_bottom_menu_notifications")
                :UIImage(named: "ic_bottom_menu_notificationsBages")
            notificationsButton.itemImageView.image = imageForNotif
        }.store(in: &cancellable)
    }

    public func shouldResetButton() {
        tabBarButtonArray.forEach { $0.button.isSelected = false }
    }
    @IBAction func clickOnHomeAction(_ sender: Any) {
        let item = menuViewModel.tabBarItems[2]
        menuViewModel.selectedItem.send(item)
        self.selectItemFor(type: item.type)
    }

}
