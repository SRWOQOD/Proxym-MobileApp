//
//  WQBottomMenuItemView.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 03/01/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

class WQBottomMenuItemView: UIView {

    // MARK: - Outlets
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var button: UIButton!

    // MARK: - Properties
    var didClickOn : (() -> Void)?
    // MARK: - Private Properties

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        button.backgroundColor = .clear
        button.tintColor = .clear
        itemImageView.contentMode = .scaleAspectFit
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        button.backgroundColor = .clear
        button.tintColor = .clear
    }

    // MARK: - Private methods

    func setUpItemView(menuItem: MenuElement?) {
        guard let item = menuItem else {return }
        button.isSelected ? itemImageView.setImage(image: item.imageEnabled ?? UIImage())
            : itemImageView.setImage(image: item.imageDisabled ?? UIImage())
    }
}
