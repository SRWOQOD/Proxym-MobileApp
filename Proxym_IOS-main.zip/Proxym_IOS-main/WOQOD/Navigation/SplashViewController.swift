//
//  SplashViewController.swift
//  WOQOD
//
//  Created by rim ktari on 10/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine
import IBMMobileFirstPlatformFoundation

class SplashViewController: UIViewController {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    let viewModel = SplashViewModel()
    var cancellable = Set<AnyCancellable>()
    override func viewDidLoad() {
        super.viewDidLoad()

        bindData()
    }

    func bindData() {

        activityIndicator.startAnimating()

        viewModel.state.sink { (state) in
            self.activityIndicator.hide()
            self.activityIndicator.isHidden = true

            switch state {
            case .error: AuthManager.shared.currentUser = nil
            case .finishedLoading: break
            case .loading: break
            }
            AppRouter.shared.initResideMenuViewController()

        }.store(in: &cancellable)
        viewModel.obtainAccessToken()

    }
}
