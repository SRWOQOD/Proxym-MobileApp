//
//  SplashViewModel.swift
//  WOQOD
//
//  Created by rim ktari on 10/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class SplashViewModel: ViewModel {

    override init() {
        super.init()
        subscribeToAuthResult()
    }

    func subscribeToAuthResult() {
        AuthChallengeHandler.shared.tokenResult.sink { (result) in
            switch result {
            case .success(let token ) : self.state.send(.finishedLoading)
            case .failure(let error): self.state.send(.error(error))
            case .none: break
            }
        }.store(in: &cancellable)
    }

    func obtainAccessToken() {
        AuthChallengeHandler.shared.getAccessToken()
    }

}
