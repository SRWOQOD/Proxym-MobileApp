//
//  FingerPrintManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import LocalAuthentication

public protocol BiometricDelegate {

    func authenticationSuccess()
    func authenticationError()
    func cancelAuthentification()
}

class BiometricManager: NSObject {
    let entryName = KeychainKeys.currentEntryBioKey
    let entryContents = KeychainKeys.currentEntryBioValue
    private var delegate: BiometricDelegate?

    // MARK: - Initialization
    public init(delegate: BiometricDelegate) {

        super.init()
        self.delegate = delegate
        KeychainHelper.createBioProtectedEntry(key: entryName, data: Data(entryContents.utf8))
    }

    func biometricAuthentication() {
        let entryName = KeychainKeys.currentEntryBioKey
        let entryContents = KeychainKeys.currentEntryBioValue
        KeychainHelper.createBioProtectedEntry(key: entryName, data: Data(entryContents.utf8))
        let localAuthenticationContext = LAContext()
        var authorizationError: NSError?
        let reason = "Authentication required to access the secure data"
        if localAuthenticationContext.canEvaluatePolicy(.deviceOwnerAuthentication,
                                                        error: &authorizationError) {
            localAuthenticationContext
                .evaluatePolicy(.deviceOwnerAuthentication,
                                localizedReason: reason) { success, evaluateError in
                    OperationQueue.main.addOperation({ () -> Void in
                        if success,
                           let _ = KeychainHelper.loadBioProtected(
                            key: entryName,
                            context: localAuthenticationContext
                           ) {
                            self.delegate?.authenticationSuccess()
                        }
                        else if success {
                            self.delegate?.authenticationError()
                        }
                        else {
                            guard let error = evaluateError else {
                                return
                            }
                            self.evaluateAuthenticationPolicyForLA(errorCode: error._code)
                        }
                    })
                }
        }
    }

    fileprivate  func evaluateAuthenticationPolicyForLA(errorCode: Int) {

      switch errorCode {
      // user clicked on cancel
      case LAError.userCancel.rawValue:
        self.delegate?.cancelAuthentification()
      case LAError.authenticationFailed.rawValue:
        self.delegate?.authenticationError()
      case LAError.passcodeNotSet.rawValue:
          self.delegate?.cancelAuthentification()
      default:
        break
      }
    }
}


class KeychainHelper {


    static func getBioSecAccessControl() -> SecAccessControl {
        var access: SecAccessControl?
        var error: Unmanaged<CFError>?
    
        if #available(iOS 11.3, *) {
            access = SecAccessControlCreateWithFlags(nil,
                                                     kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                                     .userPresence,
                                                     &error)
        } else {
            access = SecAccessControlCreateWithFlags(nil,
                                                     kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                                     .devicePasscode,
                                                     &error)
        }
        precondition(access != nil, "SecAccessControlCreateWithFlags failed")
        return access!
    }

    static func createBioProtectedEntry(key: String, data: Data)  {
        remove(key)
    
        let query = [
            kSecClass as String       : kSecClassInternetPassword as String,
            kSecAttrAccount as String : key,
            kSecAttrAccessControl as String: getBioSecAccessControl(),
            kSecValueData as String   : data ] as CFDictionary
    
         SecItemAdd(query as CFDictionary, nil)
        }
    
    
    static func loadBioProtected(key: String, context: LAContext? = nil,
                                 prompt: String? = nil) -> Data? {
        var query: [String: Any] = [
            kSecClass as String       : kSecClassInternetPassword,
            kSecAttrAccount as String : key,
            kSecReturnData as String  : kCFBooleanTrue!,
            kSecAttrAccessControl as String: getBioSecAccessControl(),
            kSecMatchLimit as String  : kSecMatchLimitOne ]
        
        if let context = context {
            query[kSecUseAuthenticationContext as String] = context
            
            // Prevent system UI from automatically requesting Touc ID/Face ID authentication
            // just in case someone passes here an LAContext instance without
            // a prior evaluateAccessControl call
            query[kSecUseAuthenticationUI as String] = kSecUseAuthenticationUISkip
        }
        
        if let prompt = prompt {
            query[kSecUseOperationPrompt as String] = prompt
        }

        var dataTypeRef: AnyObject? = nil
        
        let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)
        
        if status == noErr {
            return (dataTypeRef! as! Data)
        } else {
            return nil
        }
    }

}
