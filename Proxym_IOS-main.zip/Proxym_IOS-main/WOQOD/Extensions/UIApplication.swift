//
//  UIApplication.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/1/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UIApplication {

    static var window: UIWindow? {
        return self.shared.windows.first(where: { $0.isKeyWindow })
    }

    class func topViewController(base: UIViewController? = window?.rootViewController) -> UIViewController? {

          if let nav = base as? UINavigationController {
              return topViewController(base: nav.visibleViewController)
          }

          if let presented = base?.presentedViewController {
              return topViewController(base: presented)
          }

          return base
      }
}
