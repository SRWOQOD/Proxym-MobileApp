//
//  UIViewExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UIView {

    /**
     Setting, Getting  the cornerRadius of the UIView
     */

    @IBInspectable public var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.masksToBounds = true
            layer.cornerRadius = newValue
        }
    }

    /**
     Returns a `UIView` object instantiated from nib
     */
    func instantiateFromNib() -> UIView? {
        let nib = UINib(nibName: String(describing: Self.self), bundle: Bundle(for: Self.self))
        let view = nib.instantiate(withOwner: self, options: nil).first as? UIView
        return view
    }
    /**
     * Load the content of the first view in the XIB.
     * Then add this as subview with constraints
     */

    func loadNibContent() {
        guard let view = instantiateFromNib() else {
            fatalError("Failed to instantiate \(String(describing: Self.self)).xib")
        }
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        let views = ["view": view]
        let verticalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[view]-0-|",
                                                                 options: .alignAllLastBaseline,
                                                                 metrics: nil, views: views)
        let horizontalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[view]-0-|",
                                                                   options: .alignAllLastBaseline,
                                                                   metrics: nil, views: views)
        addConstraints(verticalConstraints + horizontalConstraints)
    }

    /// Add border to the UIView
    /// - Parameters:
    ///   - borderColor: border Color
    ///   - borderwidth: The widht of border
    ///   - cornerRadius: cornerRadius
    func border(borderColor: UIColor, borderwidth: CGFloat, cornerRadius: CGFloat  = 0) {
        self.cornerRadius = cornerRadius
        self.layer.borderColor = borderColor.cgColor
        self.layer.borderWidth = borderwidth.adjusted
    }

    /// Add External border to the UIView
    /// - Parameters:
    ///     - borderwidth: The widht of border
    ///     - borderColor: border Color
    func addExternalBorder(borderWidth: CGFloat = 2.0, borderColor: UIColor = UIColor.white) {
        let adjustedBorderWidth = borderWidth.adjusted
        let externalBorder = CALayer()
        externalBorder.frame = CGRect(x: -adjustedBorderWidth, y: -adjustedBorderWidth,
                                      width: frame.size.width.adjusted + 2 * adjustedBorderWidth,
                                      height: frame.size.height.adjusted + 2 * adjustedBorderWidth)
        externalBorder.borderColor = borderColor.cgColor
        externalBorder.borderWidth = adjustedBorderWidth
        externalBorder.cornerRadius = (frame.size.width.adjusted + 2 * adjustedBorderWidth) / 2
        layer.insertSublayer(externalBorder, at: 0)
        layer.masksToBounds = false
    }

    func addEdges(top: CGFloat = 0, left: CGFloat = 0, bottom: CGFloat = 0, right: CGFloat = 0 ) {
        self.frame = self.frame.inset(by: UIEdgeInsets(top: top.adjusted,
                                                       left: left.adjusted,
                                                       bottom: bottom.adjusted,
                                                       right: right.adjusted))
    }

    private func roundedCorners(_ corners: CACornerMask = [.layerMinXMaxYCorner,
                                                           .layerMaxXMaxYCorner,
                                                           .layerMaxXMinYCorner,
                                                           .layerMinXMinYCorner],
                                radius: CGFloat) {
        self.layer.maskedCorners = corners
        self.layer.cornerRadius = radius
    }

    func roundTopCorners(_ corners: CACornerMask = [.layerMaxXMinYCorner, .layerMinXMinYCorner], radius: CGFloat) {
        self.layer.maskedCorners = corners
        self.layer.cornerRadius = radius.adjusted
    }

    func roundBottomCorners(_ corners: CACornerMask = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner], radius: CGFloat) {
        self.layer.maskedCorners = corners
        self.layer.cornerRadius = radius
    }

    func roundCorners( radius: CGFloat) {
        self.roundedCorners(radius: radius.adjusted)
    }

    func round() {
        self.layoutIfNeeded()
        self.layer.cornerRadius = self.layer.frame.height / 2
    }

    func callRecursively(level: Int = 0, _ body: (_ subview: UIView, _ level: Int) -> Void) {
        body(self, level)
        subviews.forEach { $0.callRecursively(level: level + 1, body) }
    }

    func addShadow(color: UIColor = .black, blur: CGFloat = 5,
                   xValue: CGFloat = 0, yValue: CGFloat = 0, alpha: Float = 0.15,
                   cornerRadius: CGFloat=0) {
        layer.borderColor = color.cgColor
        layer.masksToBounds = false
        layer.cornerRadius = cornerRadius == 0 ? self.frame.height / 2 : cornerRadius
        layer.backgroundColor = UIColor.white.cgColor
        layer.borderColor = UIColor.clear.cgColor
        layer.shadowColor = color.cgColor
        layer.shadowOffset = CGSize(width: xValue, height: yValue)
        layer.shadowRadius = blur / 2
        layer.shadowOpacity = alpha
    }
    func addShadow(offset: CGSize, color: UIColor, radius: CGFloat, opacity: Float) {
            layer.masksToBounds = false
            layer.shadowOffset = offset
            layer.shadowColor = color.cgColor
            layer.shadowRadius = radius
            layer.shadowOpacity = opacity

            let backgroundCGColor = backgroundColor?.cgColor
            backgroundColor = nil
            layer.backgroundColor =  backgroundCGColor
        }

    func addTopShadowPath(color: UIColor, blur: CGFloat, yValue: CGFloat, alpha: Float ) {
        let contactRect = CGRect(x: 0, y: -yValue, width: self.bounds.width, height: blur)

        layer.shadowColor = color.cgColor
        layer.shadowPath = UIBezierPath(rect: contactRect).cgPath
        layer.shadowRadius = blur / 2
        layer.shadowOpacity = alpha
        layer.masksToBounds = false
    }

    func deactivateRTL(of view: UIView? = nil) {
        for subview in view?.subviews ?? [self] {
            subview.semanticContentAttribute = .forceLeftToRight
            deactivateRTL(of: subview)
        }
    }

    func addBlurEffect() {
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.systemUltraThinMaterialLight)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        self.frame = self.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.addSubview(blurEffectView)
    }
    
    func visiblity(gone: Bool, dimension: CGFloat = 0.0, attribute: NSLayoutConstraint.Attribute = .height) -> Void {
          if let constraint = (self.constraints.filter{$0.firstAttribute == attribute}.first) {
              constraint.constant = gone ? 0.0 : dimension
              self.layoutIfNeeded()
              self.isHidden = gone
          }
      }

}
