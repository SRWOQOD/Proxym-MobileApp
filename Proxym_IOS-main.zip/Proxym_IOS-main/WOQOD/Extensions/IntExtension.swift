//
//  IntExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

import UIKit

let oneDayInTimeStamp: Int64 = 86400

extension Int {
    var adjusted: CGFloat {
        return CGFloat(self) * Device.ratio
    }
}

extension Int64 {

    /// convert in64 to  string date
    /// - Parameter format: specifying the format of the returned date
    /// - Returns: string date
    func getStringDateFromInt64(_ format: String = "dd-MM-yyyy") -> String {
        let date  = Date(timeIntervalSince1970: TimeInterval(self / 1000))
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Language.english.local
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: date)
    }

    func getDateFromInt64(_ format: String = "dd-MM-yyyy", isNeededAddOneDay: Bool = false) -> Date {
//        let timestamp = isNeededAddOneDay ? ((self / 1000) + oneDayInTimeStamp) : self / 1000
        let date  = Date(timeIntervalSince1970: TimeInterval(((self / 1000) + oneDayInTimeStamp)))
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.locale = Language.english.local
        let dateString = dateFormatter.string(from: date)
        return dateFormatter.date(from: dateString) ?? Date()
    }
    
    func getDateFromInt64ServerTime(_ format: String = "dd-MM-yyyy") -> Date {
//        let timestamp = isNeededAddOneDay ? ((self / 1000) + oneDayInTimeStamp) : self / 1000
        let date  = Date(timeIntervalSince1970: TimeInterval(((self / 1000) + oneDayInTimeStamp)))
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT")
        dateFormatter.locale = Language.english.local
        let dateString = dateFormatter.string(from: date)
        return dateFormatter.date(from: dateString) ?? Date()
    }

    func getDateTimeFromInt64(_ format: String = " yyyy-MM-dd'T'HH:mm:ssZ") -> Date {
        let date  = Date(timeIntervalSince1970: TimeInterval(self / 1000))
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.locale = Language.english.local
        let dateString = dateFormatter.string(from: date)
        return dateFormatter.date(from: dateString) ?? Date()
    }

}

extension Double {
    var clean: String {
       return String(format: "%.2f", self)
    }

    func withCommas() -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.locale = Locale(identifier: "en_US")
        return numberFormatter.string(from: NSNumber(value: self))!
    }
}
