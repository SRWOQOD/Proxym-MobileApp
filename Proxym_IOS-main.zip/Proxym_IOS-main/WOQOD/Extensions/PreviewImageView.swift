//
//  PreviewImageView.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 21/12/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import UIKit

class PreviewImageView: UIImageView {

    fileprivate let imageTag = -1 // avoid view with tag 0 is the current window view
    var fullscreenImageView: UIImageView!
    var closeButton: UIButton!

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setup()
    }

    fileprivate func setup() {
        self.isUserInteractionEnabled = true
        let touchGesture = UITapGestureRecognizer(target: self, action: #selector(showFullscreen))
        self.addGestureRecognizer(touchGesture)
    }

    fileprivate func createFullscreenPhoto() -> UIImageView {
        let tmpImageView = UIImageView(frame: self.frame)
        tmpImageView.image = self.image
        tmpImageView.contentMode = UIView.ContentMode.scaleAspectFit
        tmpImageView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        tmpImageView.tag = imageTag
        tmpImageView.alpha = 0.0
        tmpImageView.isUserInteractionEnabled = true
        tmpImageView.isMultipleTouchEnabled = true

        return tmpImageView
    }

    fileprivate func createCloseButton() -> UIButton {

        let button = UIButton(frame: CGRect.zero)
        button.setImage(#imageLiteral(resourceName: "ic_close_white"), for: .normal)
        button.contentHorizontalAlignment = .right

        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 0, bottom: 0, right: 20)
        button.alpha = 0.0

        button.addTarget(self, action: #selector(hideFullscreen), for: .touchUpInside)

        return button
    }

    @objc func showFullscreen() {

        let window = UIApplication.shared.windows.first!
        if window.viewWithTag(imageTag) == nil {
            window.endEditing(true)
            self.fullscreenImageView = createFullscreenPhoto()

            self.closeButton = createCloseButton()

            let width = window.frame.size.width
            let height = 100.adjusted

            self.closeButton.frame =  CGRect.init(x: 0, y: 0, width: width, height: height)
            self.fullscreenImageView.addSubview(closeButton)

            window.addSubview(self.fullscreenImageView)
            UIView.animate(withDuration: 0.4, delay: 0.0, options: .curveEaseInOut, animations: {

                self.fullscreenImageView.frame = window.frame
                self.fullscreenImageView.alpha = 1
                self.fullscreenImageView.layoutSubviews()

                self.closeButton.alpha = 1

            }, completion: { _ in
            })
        }
    }

    @objc func hideFullscreen() {

        UIView.animate(withDuration: 0.4, delay: 0.0, options: .curveEaseInOut, animations: {

            self.fullscreenImageView?.frame = self.frame
            self.fullscreenImageView?.alpha = 0

        }, completion: { _ in

            self.fullscreenImageView?.removeFromSuperview()
            self.fullscreenImageView = nil
        })
    }

}
