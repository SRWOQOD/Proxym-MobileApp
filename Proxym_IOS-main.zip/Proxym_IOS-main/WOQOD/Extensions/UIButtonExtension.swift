//
//  UIButtonExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 22/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UIButton {

    var title: String? {
        get {
            return self.titleLabel?.text
        }
        set {
            self.setTitle(newValue, for: .normal)
        }

    }
    var titleColor: UIColor? {
        get {
            return self.titleLabel?.textColor
        }
        set {
            self.setTitleColor(newValue, for: .normal)
        }
    }

    var image: UIImage? {
        get {
            return self.backgroundImage(for: .normal)
        }
        set {
            self.setImage(newValue, for: .normal)
        }
    }

    var font: UIFont? {
        get {
            return self.titleLabel?.font
        }
        set {
            self.titleLabel?.font = newValue
        }
    }

    var color: UIColor? {
        get {
            return self.backgroundColor
        }
        set {
            self.backgroundColor = newValue
        }

    }

    public func setTitleText(text: String? = "", font: String, size: Int, titleColor: UIColor = .white) {
        self.setTitle(text, for: .normal)
        self.titleLabel?.font = UIFont.init(name: font, size: size.adjusted)
        self.setTitleColor(titleColor, for: .normal)
    }

    public func setTintedImage(image: UIImage) {
        let tintedImage = image.withRenderingMode(.alwaysTemplate)
        self.image = tintedImage
    }

    func underline() {
        guard let title = self.titleLabel else { return }
        guard let tittleText = title.text else { return }
        let attributedString = NSMutableAttributedString(string: (tittleText))
        attributedString.addAttribute(NSAttributedString.Key.underlineStyle,
                                      value: NSUnderlineStyle.single.rawValue,
                                      range: NSRange(location: 0, length: (tittleText.count)))
        self.setAttributedTitle(attributedString, for: .normal)
    }

}
