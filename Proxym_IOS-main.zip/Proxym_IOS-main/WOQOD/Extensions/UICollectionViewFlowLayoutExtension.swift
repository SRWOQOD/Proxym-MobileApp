//
//  UICollectionViewFlowLayoutExtension.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 04/01/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
import UIKit

extension UICollectionViewFlowLayout {
    var insettedFrame: CGRect {
        guard let frame = collectionView?.frame else { return .zero }
        return frame.inset(by: sectionInset)
    }
}

extension Array where Element: UICollectionViewLayoutAttributes {
    var frame: CGRect {
        return map { $0.frame }.reduce(self[0].frame, { $0.union($1) })
    }
}
