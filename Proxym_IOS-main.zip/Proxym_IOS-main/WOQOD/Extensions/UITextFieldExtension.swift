//
//  UITextFieldExtension.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/13/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

extension UITextField {

    override open func awakeFromNib() {
        super.awakeFromNib()
        self.semanticContentAttribute = Language.currentLanguage.semantic
        self.textAlignment = Language.currentLanguage.textAlignment
    }
    var textPublisher: AnyPublisher<String, Never> {
        NotificationCenter.default
            .publisher(for: UITextField.textDidChangeNotification, object: self)
            .compactMap { $0.object as? UITextField }
            // receiving notifications with objects which are instances of UITextFields
            .map { $0.text ?? "" } // mapping UITextField to extract text
            .eraseToAnyPublisher()
    }
    func isEmpty() -> Bool {
        return self.text?.isEmpty ?? false
    }
    func setEmptyRightView(height: CGFloat, width: CGFloat) {
        let containerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: Int(width), height: Int(height)))
        rightView = containerView
        rightViewMode = .always
    }

    func setEmptyLeftView(height: CGFloat, width: CGFloat) {
        let containerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: Int(width), height: Int(height)))
        leftView = containerView
        leftViewMode = .always
    }

    func setRightView(image: UIImage, padding: CGFloat = 30.adjusted,
                      action: Selector = #selector(noneSelector), target: Any? = self) {
        let size = self.bounds.height
        let viewPadding = UIView(frame: CGRect(x: 0, y: 0, width: padding.adjusted, height: size))
        let iconButton = UIButton(frame: CGRect(x: 0, y: 0, width: size, height: size))
        iconButton.setImage(image, for: .normal)
        iconButton.addTarget(target, action: action, for: .touchUpInside)
        viewPadding.addSubview(iconButton)
        iconButton.center = viewPadding.center
        self.rightViewMode = .always
        self.rightView = viewPadding
    }

    /// This function is used to do nothing
    @objc func noneSelector() {

    }

    /// This function is used to show and hide passwords
    @objc func showPassword() {
        self.isSecureTextEntry.toggle()
    }

    func placeHolderStyle(_ color: UIColor?, _ font: UIFont?) {
        if let color = color {
            if let font = font {
                guard let holder = placeholder, !holder.isEmpty else {
                    return
                }
                self.attributedPlaceholder = NSAttributedString(string: holder,
                                                                attributes:
                                                                    [NSAttributedString.Key.foregroundColor: color,
                                                                     NSAttributedString.Key.font: font])
            }
        }
    }
    open override var textInputMode: UITextInputMode? {
        if self.keyboardType == .default {
            return UITextInputMode.activeInputModes
                .filter { $0.primaryLanguage == Language.currentLanguage.local.languageCode }
                .first ?? super.textInputMode
        } else {
            return UITextInputMode.activeInputModes
                .filter { $0.primaryLanguage == Language.english.local.languageCode }
                .first ?? super.textInputMode
        }
    }
}
