//
//  NSRegularExpressionExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

extension NSRegularExpression {

    func notMatchedIn(value: String) -> Bool {
        return (self.firstMatch(in: value, options: [], range: NSRange(location: 0, length: value.count)) == nil)
    }
}
