//
//  StringExtension.swift
//  WOQOD
//
//  Created by rim ktari on 6/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension String {

    static func className(_ aClass: AnyClass) -> String {
        return NSStringFromClass(aClass).components(separatedBy: ".").last!
    }

    func trimmingAllSpaces(using characterSet: CharacterSet = .whitespacesAndNewlines) -> String {
            return components(separatedBy: characterSet).joined()
        }

    func validatedText(validationType: FieldType) throws -> Bool {
        let validator = VaildatorFactory.validatorFor(type: validationType)
        return try validator.validated(self)
    }

    //
    // Convert a base64 representation to a UIImage
    //
    func base64ToImage() -> UIImage {
        guard let imageData = Data(base64Encoded: self) else { return UIImage() }

        return UIImage(data: imageData) ?? UIImage()
    }

    //
    // Convert a string  to base 64 representation
    //
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
    
    //
    // Convert a base 64 to string representation
    //
    func from64ToString() -> String? {
        guard let data = Data(base64Encoded: self) else { return nil }
        return String(data: data, encoding: .utf8)
        }

    //
    // Convert a string base 64 representation to data
    //

    func toData() -> Data? {
        return Data(base64Encoded: self.toBase64())

    }

    //
    // Convert a base64 representation to a PDF
    //
    func base64ToPDF() -> Data {
        guard let PDFData = Data(base64Encoded: self) else { return Data()}

        return Data(PDFData)
    }

    /// convert a String date to Date
    /// - Parameter format: the format of the returned date
    /// - Returns: returns date
    func getDate(_ format: String? = "yyyy-MM-dd", isNeededTimeZone: Bool = false) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if isNeededTimeZone {
            dateFormatter.timeZone = TimeZone(abbreviation: "GMT")
        }
        dateFormatter.locale = Language.english.local
        let date = dateFormatter.date(from: self)
        return date ?? Date()
    }

    // this function is used in the otp component allowing user to delete a caracter
    func checkBackspace() -> Bool {
        if let char = self.cString(using: String.Encoding.utf8) {
            let isBackSpace = strcmp(char, "\\b")
            if isBackSpace == -92 {
                return true
            }
            return false
        }
        return false
    }

    /// This var is to check if an entred string is a valid number or not
    /// - Returns: Booleen
    var isNumeric: Bool {
        return NumberFormatter().number(from: self) != nil
    }

    /// This var is to convert a string to float
    var floatValue: Float? {
        return self.isNumeric ? (self as NSString).floatValue : nil
    }
    
    /// This var is to convert a string to int
    var doubleValue: Double? {
        return self.isNumeric ? (self as NSString).doubleValue : nil
    }

    /// Parse a string to a model T
    /// - Returns: The object
    func parseData<T: Codable>() -> T? {
        do {
            let data = try JSONSerialization.data(withJSONObject: self, options: .prettyPrinted)

            let decoder = JSONDecoder()
            let item = try decoder.decode(T.self, from: data)

            return (item)

        } catch {
            return nil
        }
    }

    func isValidRegex(regex: String) -> Bool {
        do {
            let firstNameRegex = try NSRegularExpression(pattern: regex, options: .caseInsensitive)
            if firstNameRegex.notMatchedIn(value: self) {
                return false
            } else {
                return true
            }
        } catch {
            return false
        }
    }
}
