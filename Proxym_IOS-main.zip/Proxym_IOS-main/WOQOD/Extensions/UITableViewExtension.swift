//
//  UITableViewExtension.swift
//  WOQOD
//
//  Created by rim ktari on 6/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

public extension UITableView {

    func registerCellNib(_ cellClass: AnyClass) {
        let identifier = String.className(cellClass)
        let nib = UINib(nibName: identifier, bundle: nil)
        self.register(nib, forCellReuseIdentifier: identifier)
    }

    func registerHeaderFooterViewNib(_ viewClass: AnyClass) {
        let identifier = String.className(viewClass)
        let nib = UINib(nibName: identifier, bundle: nil)
        self.register(nib, forHeaderFooterViewReuseIdentifier: identifier)
    }

    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0,
                                                 width: self.bounds.size.width,
                                                 height: self.bounds.size.height))

        messageLabel.setText(text: message, font: Fonts.boldFontName, size: 14, forgroundColor: .wqBlue)
        messageLabel.textAlignment = .center
        messageLabel.sizeToFit()

        self.backgroundView = messageLabel
        self.separatorStyle = .none
    }

    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}

extension UIScrollView {
    func scrollToBottom(animated: Bool, isFirstTapToScroll: Bool = false) {
        self.layoutIfNeeded()
        if self.contentSize.height < self.bounds.size.height { return }
        let bottomOffset = CGPoint(x: 0,
                                   y: self.contentSize.height +
                                   self.contentInset.bottom - self.bounds.size.height)
        self.setContentOffset(bottomOffset, animated: animated)
    }
}
