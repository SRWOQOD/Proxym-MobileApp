//
//  AnyCancellableExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Combine

extension AnyCancellable {
    func store(in cancelBag: CancelBag) {
        cancelBag.subscriptions.insert(self)
    }
}
