//
//  UISearchBarExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UISearchBar {

    /// Access textfield of the search bar
    func getTextField() -> UITextField? { return value(forKey: "searchField") as? UITextField }
    func getDeleteButton() -> UIButton? { return searchTextField.value(forKey: "_clearButton")as? UIButton }

}
