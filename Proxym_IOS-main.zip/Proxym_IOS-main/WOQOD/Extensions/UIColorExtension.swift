//
//  UIColorExtension.swift
//  WOQOD
//
//  Created by rim ktari on 9/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {

    // Woqod Blue shades
    static let wqBlue = UIColor(hexString: "#002280")
    static let wqlightBlue =  UIColor(hexString: "#98A5CC")
    static let wqGrayBlue = UIColor(hexString: "#EBEDF5")
    // Woqod Gray shades
    static let wqDarkGray =  UIColor(hexString: "#68696A")
    static let wqLightGray = UIColor(hexString: "#ADADAD")
    static let wqGray = UIColor(hexString: "#707070")
    static let wqMediumGray = UIColor(hexString: "#F3F4F9")

    // Woqod Green shades
    static let wqGreen = UIColor(hexString: "#009933")
    static let wqLightGreen = UIColor(hexString: "#66C285")
    static let wqDarkGreen = UIColor(hexString: "#159839")

    // Woqod Yellow shades
    static let wqDarkYellow = UIColor(hexString: "#F89828")

    // Red shades
    static let wqRed = UIColor(hexString: "#B30839")
    static let wqLightRed = UIColor(hexString: "#FF4F4F")

    // Orange shades
    static let wqOrange = UIColor(hexString: "#F89828")

    // Create a UIColor from a hex string
    @objc convenience init(hexString: String, alpha: CGFloat = 1.0) {
        var cString: String = hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).uppercased()

        if cString.hasPrefix("#") {
            let index = cString.index(cString.startIndex, offsetBy: 1)
            cString = String(cString[index...])
        }

        if (cString.count) != 6 {
            self.init(red: 0, green: 0, blue: 0, alpha: alpha)
            return
        }

        var rgbValue: UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        self.init(red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
                  green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
                  blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
                  alpha: alpha)
    }

    // Create a UIColor from RGB
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")

        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }

    convenience init(hex: Int) {
        self.init(
            red: (hex >> 16) & 0xFF,
            green: (hex >> 8) & 0xFF,
            blue: hex & 0xFF
        )
    }

}
