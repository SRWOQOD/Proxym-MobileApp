//
//  WKWebViewExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 06/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import WebKit

extension WKWebView {
    // Remove background of a web view
    func setupWebViewClearBackground() {
        self.isOpaque = false
        self.backgroundColor = UIColor.clear
    }

}
