//
//  UIImageExtension.swift
//  WOQOD
//
//  Created by rim ktari on 7/28/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import AVFoundation

extension CGImagePropertyOrientation {
    init(_ uiOrientation: UIImage.Orientation) {
        switch uiOrientation {
            case .up: self = .up
            case .upMirrored: self = .upMirrored
            case .down: self = .down
            case .downMirrored: self = .downMirrored
            case .left: self = .left
            case .leftMirrored: self = .leftMirrored
            case .right: self = .right
            case .rightMirrored: self = .rightMirrored
        @unknown default:
            fatalError()
        }
    }
}

extension UIImage {

    var cgImageOrientation: CGImagePropertyOrientation { .init(imageOrientation) }

    //
    // Convert UIImage to a base64 representation
    //
    func toBase64() -> String {

        guard let imageData = self.jpegData(compressionQuality: 0.4) else { return "" }

        return  imageData.base64EncodedString()
    }

    //
    // Compress image quality
    //
    func compress(_ compressQuality: CGFloat = 0.4) -> UIImage {

        if  let imageData = self.jpegData(compressionQuality: compressQuality) {

            return UIImage(data: imageData) ??  UIImage()

        }
        return UIImage()
    }

    func heicDataCompress(compressionQuality: CGFloat = 0.4) -> UIImage? {
      let data = NSMutableData()
      guard let imageDestination = CGImageDestinationCreateWithData(
          data, AVFileType.heic as CFString, 1, nil
        )
        else {
          return UIImage()
      }

      guard let cgImage = self.cgImage else {
        return UIImage()
      }

      let options: NSDictionary = [
        kCGImageDestinationLossyCompressionQuality: compressionQuality
        , kCGImagePropertyOrientation: cgImageOrientation.rawValue
      ] as CFDictionary

      CGImageDestinationAddImage(imageDestination, cgImage, options)
      guard CGImageDestinationFinalize(imageDestination) else {
        return UIImage()
      }

        
        return UIImage(data: data as Data)
    }

    //
    // Reside image quality
    //
    func resized(withPercentage percentage: CGFloat, isOpaque: Bool = true) -> UIImage? {
        let canvas = CGSize(width: size.width * percentage, height: size.height * percentage)
        let format = imageRendererFormat
        format.opaque = isOpaque
        return UIGraphicsImageRenderer(size: canvas, format: format).image {_ in
            draw(in: CGRect(origin: .zero, size: canvas))
        }
    }
    func resized(withHeight height: CGFloat, withWidth width: CGFloat) -> UIImage? {
        let canvas = CGSize(width: width, height: height)
        let format = imageRendererFormat
        return UIGraphicsImageRenderer(size: canvas, format: format).image {_ in
            draw(in: CGRect(origin: .zero, size: canvas))
        }
    }
    func tint(with fillColor: UIColor) -> UIImage? {
        let image = withRenderingMode(.alwaysTemplate)
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        fillColor.set()
        image.draw(in: CGRect(origin: .zero, size: size))

        guard let imageColored = UIGraphicsGetImageFromCurrentImageContext() else {
            return nil
        }

        UIGraphicsEndImageContext()
        return imageColored
    }

}

// Extension of an UIImage Array
extension Array where Element: UIImage {

    //
    // Convert a list of UIImage to a list of base64 representation
    //
   func convertToBase64() -> [String] {
       var base64List = [String]()

       self.forEach({ base64List.append($0.toBase64()) })
       return  base64List
   }

}
