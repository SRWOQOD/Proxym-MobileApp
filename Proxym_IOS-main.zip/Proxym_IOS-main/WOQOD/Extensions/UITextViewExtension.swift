//
//  UITextViewExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 18/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

extension UITextView {

    override open func awakeFromNib() {
        if textAlignment != .center {
            self.semanticContentAttribute = Language.currentLanguage.semantic
            self.textAlignment =  Language.currentLanguage.textAlignment
        }
    }

    /// This func is used to adjust text when arabic language is updated
    func activateTextRTL() {
        languageIsArabic ? self.makeTextWritingDirectionRightToLeft(true) :  ()
    }

    func setTextStyle(text: String? = "", font: String, size: Int,
                      forgroundColor: UIColor = .black, lineSpace: CGFloat = 1.5,
                      align: NSTextAlignment = .justified) {

        self.setAttributedText(text: text, lineSpace: lineSpace, align: align)
        self.font = UIFont.init(name: font, size: size.adjusted)
        self.textColor = forgroundColor
    }

    var textPublisher: AnyPublisher<String, Never> {
        NotificationCenter.default
            .publisher(for: UITextView.textDidChangeNotification, object: self)
            .compactMap { $0.object as? UITextView }
            // receiving notifications with objects which are instances of UITextViews
            .map { $0.text ?? "" } // mapping UITextView to extract text
            .eraseToAnyPublisher()
    }

    func setAttributedText(text: String? = "", lineSpace: CGFloat, align: NSTextAlignment) {

        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpace.adjusted
        paragraphStyle.alignment = align

        let attributes: [NSAttributedString.Key: Any] =
            [NSAttributedString.Key.paragraphStyle: paragraphStyle] as [NSAttributedString.Key: Any]

        let attributedText = NSMutableAttributedString(string: text ?? "", attributes: attributes)
        self.attributedText = attributedText

    }

    /// Resize the placeholder UILabel to make sure it's in the same position as the UITextView text
    func resizePlaceholder() {
        if let placeholderLabel = self.viewWithTag(100) as? UILabel {
            let labelX = self.textContainer.lineFragmentPadding
            let labelY = self.textContainerInset.top - 2
            let labelWidth = 52
            let labelHeight = 15

            placeholderLabel.frame=CGRect(x: labelX, y: labelY, width: CGFloat(labelWidth),
                                          height: CGFloat(labelHeight))
        }
    }

    func htmlAttributedString(text: String, fontSize: CGFloat, fontName: String, justify: Bool? = true,
                              hexColor: String = "#002280") {
        let textAlign = languageIsArabic ? "right" : "left"
        let direction = languageIsArabic ? "rtl" : "ltr"
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.baseWritingDirection = languageIsArabic ? .rightToLeft : .leftToRight
        let string = text.appending(String(format: "<style>body{font-family:'%@';"
                                            + "font-size:%fpx;text-align:%@;color:%@;direction:%@}</style>",
                                           fontName, fontSize, textAlign,
                                           hexColor, direction))
        let html = attributedString(text: string)
        self.attributedText = html

        self.textColor = UIColor(hexString: hexColor)
    }
    
    private func attributedString(text: String) -> NSAttributedString? {
            guard let data = text.data(using: String.Encoding.utf8,
                allowLossyConversion: false) else { return nil }
            let options: [NSAttributedString.DocumentReadingOptionKey : Any] = [
                NSAttributedString.DocumentReadingOptionKey.characterEncoding : String.Encoding.utf8.rawValue,
                NSAttributedString.DocumentReadingOptionKey.documentType : NSAttributedString.DocumentType.html
            ]
            let htmlString = try? NSMutableAttributedString(data: data, options: options, documentAttributes: nil)
        
            return htmlString
        }
    
    func htmlAttributedStringUtf16(text: String, fontSize: CGFloat, fontName: String, justify: Bool? = true,
                              hexColor: String = "#002280") {
        let textAlign = languageIsArabic ? "right" : "left"
        let direction = languageIsArabic ? "rtl" : "ltr"
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.baseWritingDirection = languageIsArabic ? .rightToLeft : .leftToRight
        let string = text.appending(String(format: "<style>body{font-family:'%@';"
                                            + "font-size:%fpx;text-align:%@;color:%@;direction:%@}</style>",
                                           fontName, fontSize, textAlign,
                                           hexColor, direction))
        guard let data = string.data(using: String.Encoding.utf16, allowLossyConversion: false) else {return}
        guard let html = try? NSMutableAttributedString(
                data: data,
                options:
                    [NSAttributedString.DocumentReadingOptionKey.documentType: NSAttributedString.DocumentType.html],
                documentAttributes: nil) else {return}
        html.addAttribute(.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0, length: html.length))
        self.attributedText = html

        self.textColor = UIColor(hexString: hexColor)
    }
    
    open override var textInputMode: UITextInputMode? {
        if self.keyboardType == .default {
            return UITextInputMode.activeInputModes
                .filter { $0.primaryLanguage == Language.currentLanguage.local.languageCode }
                .first ?? super.textInputMode
        } else {
            return UITextInputMode.activeInputModes
                .filter { $0.primaryLanguage == Language.english.local.languageCode }
                .first ?? super.textInputMode
        }
    }
}
