//
//  CGRectExtension.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 04/01/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

extension CGRect {
    func insettedBy(insets: UIEdgeInsets) -> CGRect {
        return self.inset(by: insets)
    }
}
