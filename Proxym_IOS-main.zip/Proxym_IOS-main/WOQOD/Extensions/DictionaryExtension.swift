//
//  DictionaryExtension.swift
//  WOQOD
//
//  Created by rim ktari on 7/8/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

extension Dictionary {

    func parseDictionary<T: Codable>() -> T? {
        do {

            let data = try JSONSerialization.data(withJSONObject: self, options: .prettyPrinted)

            let decoder = JSONDecoder()

            let item = try decoder.decode(T.self, from: data)

            return item
        } catch {
            return nil
        }
    }
    // remove optional values from a dictionary
    func flattenValues<U>() -> [Key: U] where Value == U? {
        return flatMapValues { $0 }
    }

    func flatMapValues<T>(_ transform: (Value) throws -> T?) rethrows -> [Key: T] {
          var result: [Key: T] = [:]
          for (key, value) in self {
              if let transformed = try transform(value) {
                  result[key] = transformed
              }
          }
          return result
      }

    func paramsString() -> String {

        return (self.compactMap({ (key, value) -> String? in

            if value is [String: Any] {
                if let dictionary = value as? [String: Any] {
                    return dictionary.paramsString()
                }
            } else {
                return "\(key)=\(value)"
            }
            return nil

        }) as Array).joined(separator: ",")
    }
}

extension Array where Element: Equatable {
    mutating func delete(element: Iterator.Element) {
        self = self.filter {$0 != element }
    }

    mutating func deleteFirst() {
        if self.count == 0 {
            return
        } else {
            self.removeFirst()
        }
    }

    func removeDuplicates() -> [Element] {
        var result = [Element]()

        for value in self {

            if !result.contains(value) {

                result.append(value)
            }
        }
        return result
    }

}
