//
//  WQTextFieldViewExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 31/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

extension WQTextFieldView {

    func setEmptyLeftView(width: CGFloat = 16) {

        self.textField.setEmptyLeftView(height: self.textField.frame.height, width: width.adjusted)
    }
}
