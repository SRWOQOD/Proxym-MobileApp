//
//  DateExtension.swift
//  WOQOD
//
//  Created by rim ktari on 8/4/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum TimeZoneNames: String {
    case gmt = "GMT+3"
}

extension TimeZone {
    static var gmt: TimeZone? { return TimeZone(abbreviation: TimeZoneNames.gmt.rawValue)}
}

extension Date {

    var timeStamp: Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }

    init(milliseconds: Int64) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }

    func getStringDate(_ format: String? = "dd-MM-yyyy") -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Language.english.local
        let date = dateFormatter.string(from: self)
        return date

    }
    /// Convert a date to a string representation
    /// - Parameter format: the needed format
    /// - Returns: string format of the date
    func toString(_ format: String = "yyyy-MM-dd'T'HH:mm:ss'Z'") -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.timeZone = TimeZone(abbreviation: "GMT")
        formatter.locale = Language.english.local
        return formatter.string(from: self)

    }

    func toLongString(_ format: String? = "dd-MM-yyyy") -> String {
        // Create Date Formatter
        let dateFormatter = DateFormatter()
        // Set Date/Time Style
        dateFormatter.dateFormat = format
        dateFormatter.locale = Language.english.local
        // Convert Date to String
        return dateFormatter.string(from: self)
    }

    func toUTCDate(_ format: String? = "dd-MM-yyyy") -> String {
        // Create Date Formatter
        let dateFormatter = DateFormatter()
        // Set Date/Time Style
        dateFormatter.dateFormat = format
        dateFormatter.locale = Language.english.local
        dateFormatter.timeZone = TimeZone.gmt

        // Convert Date to String
        return dateFormatter.string(from: self)
    }

    //
    // This funtion checks if the date do not exceed a month
    //
    func lessThanMonth() -> Bool {
        var dateComponent = DateComponents()
        dateComponent.month = 1
        guard  let futureDate = Calendar.current.date(byAdding: dateComponent, to: Date()) else { return false }
        return self <= futureDate
    }

    var isInThePast: Bool {
        return self  < Date()
    }

    static var yesterday: Date { return Date().dayBefore }
    static var tomorrow: Date { return Date().dayAfter }
    var dayBefore: Date {
        return Calendar.current.date(byAdding: .day, value: -1, to: noon)!
    }
    var dayAfter: Date {
        return Calendar.current.date(byAdding: .day, value: 1, to: noon)!
    }
    var noon: Date {
        return Calendar.current.date(bySettingHour: 12, minute: 0, second: 0, of: self)!
    }
    var month: Int {
        return Calendar.current.component(.month, from: self)
    }
    var isLastDayOfMonth: Bool {
        return dayAfter.month != month
    }
    func isSame(_ date: Date) -> Bool {
        let diff = Calendar.current.dateComponents([.day], from: self, to: date)
        return (diff.day == 0)
    }
    func isBetween(_ date1: Date, and date2: Date) -> Bool {
        return (min(date1, date2) ... max(date1, date2)) ~= self
    }

    private func fullDistance(from date: Date,
                              resultIn component: Calendar.Component, calendar: Calendar = .current) -> Int? {
            calendar.dateComponents([component], from: self, to: date).value(for: component)
        }

    func beforeOrEqual(_ date: Date) -> Bool {
        guard let dayCount = fullDistance(from: date, resultIn: .day) else {
            return false
        }
        return dayCount <= 0
    }

    func afterOrEqual(_ date: Date) -> Bool {
        guard let dayCount = fullDistance(from: date, resultIn: .day) else {
            return false
        }

        return dayCount >= 0
    }

    func inRange(startDate: Date, endDate: Date) -> Bool {
        guard let startDayCount = fullDistance(from: startDate, resultIn: .day),
              let endDayCount = fullDistance(from: endDate, resultIn: .day) else {
            return false
        }

        return startDayCount <= 0 && endDayCount >= 0
    }

}
