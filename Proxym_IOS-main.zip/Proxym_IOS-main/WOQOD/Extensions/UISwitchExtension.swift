//
//  UISwitchExtension.swift
//  WOQOD
//
//  Created by Amine Info on 10/31/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UISwitch {

    func setBackgroundColor(_ color: UIColor) {
        if #available(iOS 13.0, *) {
            self.subviews[0].subviews[0].backgroundColor = color
        } else {
            self.subviews[0].subviews[0].subviews[0].backgroundColor = color
        }
    }

    override open func awakeFromNib() {
            self.semanticContentAttribute = Language.currentLanguage.semantic
    }

}
