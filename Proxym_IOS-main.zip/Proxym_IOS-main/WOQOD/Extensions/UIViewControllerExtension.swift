//
//  UIViewControllerExtension.swift
//  WOQOD
//
//  Created by rim ktari on 6/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import AVKit

public enum MenuElementPath {
    case fromBottomMenu
    case fromSideMenu
    case fromRegistration
    case none
}

struct AppStoryboard {
    static let main = "Main"
    static let authentification = "Authentification"
    static let fahes = "Fahes"
    static let automation = "Automation"
    static let settings = "Settings"
    static let feedback = "Feedbacks"
    static let fuelPrices = "FuelPrices"
    static let woqode = "Woqode"
    static let payment = "Payment"
    static let shafaf = "Shafaf"
    static let gdpr = "GDPR"
    static let termsOfUse = "TermsOfUse"
    static let bulkLPG = "BulkLPG"
    static let news = "News"
    static let promotions = "Promotions"
    static let account = "Account"
    static let locations = "Locations"
    static let notifications = "Notifications"
    static let tenders = "Tenders"
    static let survey = "Survey"
    static let staticScreen = "StaticScreens"
    static let stockPrices = "StockPrices"
}

extension UIViewController {

    class func pushViewControllerFor(appStoryboardName: String,
                                     completion:((_ viewC: UIViewController) -> Void)? = nil) {

        let viewC = self.instantiate(appStoryboardName: appStoryboardName)

        let rootViewController =  UIApplication.window?.rootViewController

        if let resideMenuViewController = rootViewController as? ResideMenuViewController {
            if let navigationController = resideMenuViewController.contentViewController as? WQNavigationController {
                viewC.addCentredImageToNavigationBar()
                navigationController.pushViewController(viewC, animated: true)
                completion?(viewC)
            }
        }

    }

    class func pushViewControllerFor(viewController: UIViewController,
                                     completion:((_ viewC: UIViewController) -> Void)? = nil) {

        let rootViewController =  UIApplication.window?.rootViewController

        if let resideMenuViewController = rootViewController as? ResideMenuViewController {
            if let navigationController = resideMenuViewController.contentViewController as? WQNavigationController {
                viewController.addCentredImageToNavigationBar()
                navigationController.pushViewController(viewController, animated: true)
                completion?(viewController)
            }
        }
    }

    func push(viewController: UIViewController, animated: Bool = true) {
        viewController.addCentredImageToNavigationBar()
        self.navigationController?.pushViewController(viewController, animated: animated)
    }

    func pop(animated: Bool = true) {
        self.navigationController?.popViewController(animated: animated)
    }

    func popToRootViewController() {
        addTransitionAnimation()
        self.navigationController?.popToRootViewController(animated: false)
    }

    func popWithCompletion(animated: Bool = true, completion: @escaping () -> Void) {
        self.navigationController?.popViewController(animated: animated)

        if animated, let coordinator = transitionCoordinator {
            coordinator.animate(alongsideTransition: nil) { _ in
                completion()
            }
        } else {
            completion()
        }
    }

    func popToViewController(ofClass: AnyClass, animated: Bool = true) {
        if let viewC = self.navigationController?.viewControllers.last(where: { $0.isKind(of: ofClass) }) {
            addTransitionAnimation()
            self.navigationController?.popToViewController(viewC, animated: animated)
        }
    }

    @discardableResult
    class func showViewWithNavigationControllerFor<T: UIViewController>
    (appStoryboard: String, withNavigationBar: Bool = false) -> T {
        guard let viewC = self.instantiate(appStoryboardName: appStoryboard) as? T
        else {
            return T()
        }
        let navigationController = UINavigationController(rootViewController: viewC)
        navigationController.isNavigationBarHidden = !withNavigationBar
        navigationController.view.semanticContentAttribute = Language.currentLanguage.semantic
        navigationController.navigationBar.semanticContentAttribute = Language.currentLanguage.semantic
        addTransitionAnimation()

        UIApplication.window?.rootViewController = navigationController

        return viewC
    }

    class func instantiate<ViewController: UIViewController>(appStoryboardName: String) -> ViewController {

        let storyboard = UIStoryboard(name: appStoryboardName, bundle: nil)
        let identifier = String(describing: self)
        guard let viewController = storyboard.instantiateViewController(withIdentifier: identifier)
        as? ViewController else {
            return ViewController()
        }
        return viewController
    }

    class func instantiate<ViewController: UIViewController>(xibName: String? = nil) -> ViewController {
        return ViewController(nibName: xibName ?? String(describing: self), bundle: Bundle(for: self))
    }

    func remove() {
        // Just to be safe, we check that this view controller
        // is actually added to a parent before removing it.
        guard parent != nil else {
            return
        }

        willMove(toParent: nil)
        view.removeFromSuperview()
        removeFromParent()
    }

    func addViewController(targetView: UIView, targetViewController: UIViewController?) {
        if let viewController = targetViewController {
            addChild(viewController)
            viewController.willMove(toParent: self)
            viewController.view.frame = targetView.bounds
            targetView.addSubview(viewController.view)
            viewController.didMove(toParent: self)
        }
    }

    func removeViewController(_ viewController: UIViewController?) {
        if let removedViewController = viewController {
            removedViewController.view.layer.removeAllAnimations()
            removedViewController.willMove(toParent: nil)
            removedViewController.view.removeFromSuperview()
            removedViewController.removeFromParent()
        }
    }
    /// Function displays an alert with one validate action
    /// - Parameters:
    ///   - message: the alert message
    ///   - title: the alert title
    ///   - validateTitle: the validate button title
    ///   - completion: the action that will be execuuted when user clicks on the button
    func showConfirmationAlertView(message: String, title: String?,
                                   validateTitle: String = LocalizableShared.commonOk.localized.uppercased(),
                                   completion: @escaping (() -> Void?) = ({}) ) {
        let alertController = UIAlertController(title: title ?? "", message: message, preferredStyle: .alert)
        let validatAction = UIAlertAction(title: validateTitle, style: .default) { _ in
            completion()
        }
        alertController.addAction(validatAction)
        self.present(alertController, animated: true)
    }
    /// Function displays an alert with two buttons validate & cancel
    /// - Parameters:
    ///   - title: alert title
    ///   - message: alert message
    ///   - validateTitle: validate button title
    ///   - cancelTitle: cancel button title
    ///   - validateAction: the action that will be executed when user clicks on the validate button
    ///   - cancelAction: the action that will be executed when user clicks on the cancel button
    func showAlertWith(title: String?, message: String?,
                       validateTitle: String = LocalizableShared.commonOk.localized.uppercased(),
                       cancelTitle: String = LocalizableShared.cancel.localized.uppercased(),
                       validateAction: ((UIAlertAction) -> Void)?,
                       cancelAction: ((UIAlertAction) -> Void)?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let validatAction = UIAlertAction(title: validateTitle, style: .default, handler: validateAction)
        alert.addAction(validatAction)
        let cancelAction = UIAlertAction(title: cancelTitle, style: .default, handler: cancelAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }

    func showErrorAlertView(descriptionMessage: String? = "", isCounterAlert: Bool = false,
                            errorImage: UIImage? = nil, fromFahes: Bool = false, didConfirm:(() -> Void)? = nil) {

        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()
        let errorAlertView = ErrorAlertView(frame: CGRect(x: 0, y: 0, width: 327.adjusted, height: 250.adjusted))
        errorAlertView.alertBackgroundImage = fromFahes ?
            UIImage(named: "ic_fahes_aler_background") :
            UIImage(named: "ic_alert_app_effect")
        errorAlertView.confirmButton.title = LocalizableShared.commonOk.localized.uppercased()
        errorAlertView.descriptionMessage = descriptionMessage
        errorAlertView.isACounter = isCounterAlert
        errorAlertView.errorImage = errorImage
        errorAlertView.didConfirm = {
            popUpViewControler.dismiss(animated: true) {
                didConfirm?()
            }
        }
        popUpViewControler.contentView = errorAlertView
        PopupView.show(popUpViewControler, on: self)
    }

    func showCustomAlertView(title: String? = "", text: String? = "",
                             image: UIImage? = nil, didConfirm:(() -> Void)? = nil,
                             didDiscard:(() -> Void)? = nil,
                             hideCancelButton: Bool = false,
                             confirmText: String = LocalizableShared.commonOk.localized.uppercased(),
                             fromFahes: Bool = false) {
        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()
        let alertView = WQAlertView(frame: CGRect(x: 0, y: 0, width: 327.adjusted, height: 250.adjusted))
        alertView.title = title
        alertView.text = text
        alertView.image = image
        alertView.confirmButtonText = confirmText
        alertView.backgroundImage.image = fromFahes ?
        UIImage(named: "ic_fahes_aler_background") :
        UIImage(named: "ic_alert_app_effect")
        alertView.didConfirm = {
            popUpViewControler.dismiss(animated: true, completion: nil)
            didConfirm?()
        }
        alertView.didCancel = {
            popUpViewControler.dismiss(animated: true) {
                didDiscard?()
            }
        }
        alertView.cancelButton.isHidden = hideCancelButton
        popUpViewControler.contentView = alertView
        PopupView.show(popUpViewControler, on: self)
    }

    func showSuccessAlertView(message: String? = "", description: String? = "", fromFahes: Bool = false, didConfirm:(() -> Void)? = nil) {

        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()

        let successAlertView = SuccessAlertView(frame: CGRect(x: 0, y: 0, width: 327.adjusted, height: 250.adjusted))
        successAlertView.message = message
        successAlertView.text = description
        successAlertView.backgroundImage.image = fromFahes
            ? UIImage(named: "ic_fahes_aler_background")
            : UIImage(named: "ic_alert_app_effect")
        successAlertView.didConfirm = {
            popUpViewControler.dismiss(animated: true, completion: nil)
            didConfirm?()
        }

        popUpViewControler.contentView = successAlertView
        PopupView.show(popUpViewControler, on: self)
    }

    func showPopupView(view: UIView, shouldDismiss: Bool = false ) {
        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()
        popUpViewControler.dismissWhenTappingOutside = shouldDismiss
        popUpViewControler.contentView = view
        PopupView.show(popUpViewControler, on: self)
    }

    func showToast(message: String, seconds: Double) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.view.backgroundColor = UIColor.black
        alert.view.alpha = 0.6
        alert.view.layer.cornerRadius = 15
        self.present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            alert.dismiss(animated: true)
        }
    }

    func showVideoInsidePopUp(videoURL: URL) {
        let player = AVPlayer(url: videoURL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        let playerVideoView = PlayerVideoView()
        let popUpViewControler: PopUpViewControler = PopUpViewControler.instantiate(xibName: "PopUpViewControler")
        popUpViewControler.view.layoutIfNeeded()
        popUpViewControler.dismissWhenTappingOutside = true
        popUpViewControler.contentView = playerVideoView.playerView
        playerViewController.view.frame = popUpViewControler.contentView.bounds
        popUpViewControler.contentView.cornerRadius = 10.adjusted
        popUpViewControler.addChild(playerViewController)
        popUpViewControler.contentView.addSubview(playerViewController.view)
        playerViewController.didMove(toParent: popUpViewControler)
        player.play()
        PopupView.show(popUpViewControler, on: self)
    }

    @objc func sz_viewDidLoad() {

        view.callRecursively { subview, _ in
            for constraint in subview.constraints {
                let screenWidthFactor = 1 / defaultReferenceScreenWidth
                constraint.constant = constraint.constant * UIScreen.main.bounds.width * screenWidthFactor
            }
        }
    }

    private static let swizzleDesriptionImplementation: Void = {
        let aClass: AnyClass! = object_getClass(UIViewController())
        let originalMethod = class_getInstanceMethod(aClass, #selector(viewDidLoad))
        let swizzledMethod = class_getInstanceMethod(aClass, #selector(sz_viewDidLoad))
        if let originalMethod = originalMethod, let swizzledMethod = swizzledMethod {
            method_exchangeImplementations(originalMethod, swizzledMethod)
        }
    }()

    static func swizzleLayoutConstraint() {
        _ = self.swizzleDesriptionImplementation
    }

    func addCentredImageToNavigationBar() {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 97, height: 23))
        imageView.contentMode = .center
        imageView.image = #imageLiteral(resourceName: "ic_woqod_logo")
        navigationItem.titleView = imageView
    }

    func setUpNavigationItem() {
        // Set NavigationBar Image
        self.addCentredImageToNavigationBar()
        // Set NavigationBar Left / Right Button
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "ic_menu.png"), style: .plain,
                                                                target: self, action: #selector(presentMenu))
        // Set NavigationBar Back Button
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    @objc func presentMenu() {
        languageIsEnglish ? presentLeftMenuViewController(nil) : presentRightMenuViewController(nil)
    }
    /// Adding a button to navigation bar
    /// - Parameters:
    ///   - image: image to show
    ///   - action: the action to do
    func showSideButton(image: UIImage, target: Any? = self, action: Selector) {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "ic_mapFilter"), style: .plain,
                                                                 target: target, action: action)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "",
                                                                style: UIBarButtonItem.Style.plain,
                                                                target: nil, action: nil)
    }

    func presentVideo(withURL: URL) {
        let player = AVPlayer(url: withURL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
          player.play()
        }
    }
}

func addTransitionAnimation() {
    let transition = CATransition()
    transition.duration = 0.3
    transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
    transition.type = CATransitionType.fade
    UIApplication.window?.layer.add(transition, forKey: kCATransition)
}

extension UIViewController {
    private static let association = ObjectAssociation<UIView>()
    var thisActivityIndicator: UIView {
        get {
            if let indicator = UIViewController.association[self] {
                return indicator
            } else {
                UIViewController.association[self] =
                    LoaderView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width,
                                             height: self.view.frame.height))
                return UIViewController.association[self]!
            }
        }
        set { UIViewController.association[self] = newValue }
    }

    // MARK: - Acitivity Indicator
    public func startIndicatingActivity() {
        DispatchQueue.main.async {
            self.view.addSubview(self.thisActivityIndicator)
        }
    }

    public func stopIndicatingActivity() {
        DispatchQueue.main.async {
            self.thisActivityIndicator.removeFromSuperview()
        }
    }
}
