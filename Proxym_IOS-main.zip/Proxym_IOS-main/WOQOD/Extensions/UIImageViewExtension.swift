//
//  UIImageViewExtension.swift
//  FineTuneKid
//
//  Created by Dhekra Rouatbi on 9/27/19.
//  Copyright © 2019 Proxym-it. All rights reserved.
//

import UIKit
import SDWebImage
extension UIImageView {

    public func setTintedImage(image: UIImage) {
        let tintedImage = image.withRenderingMode(.alwaysTemplate)
        self.image = tintedImage
    }

    //
    // Change the color of UIiimage with a specific color
    //

    public func setTintedImage(image: UIImage?, color: UIColor) {
        guard let image = image else { return }
        let tintedImage = image.withRenderingMode(.alwaysTemplate)
        self.image = tintedImage
        self.tintColor = color
    }

    public func setImage(image: UIImage) {
        self.image = image
    }

    func loadGif(resourceName: String) {
        guard let path = Bundle.main.path(forResource: resourceName, ofType: "gif") else {
            #if DEBUG
            print("Gif does not exist at that path")
            #endif
            return
        }
        let url = URL(fileURLWithPath: path)
        guard let gifData = try? Data(contentsOf: url),
            let source =  CGImageSourceCreateWithData(gifData as CFData, nil) else { return  }
        var images = [UIImage]()
        let imageCount = CGImageSourceGetCount(source)
        for index in 0 ..< imageCount {
            if let image = CGImageSourceCreateImageAtIndex(source, index, nil) {
                images.append(UIImage(cgImage: image))
            }
        }
        self.animationImages = images

        self.animationDuration = 1

        self.startAnimating()
    }
    func setImage(withString: String, placeholderImage: UIImage?) {
        let url = URL(string: withString)
        self.sd_imageIndicator = SDWebImageActivityIndicator.gray
        self.sd_setImage(with: url, placeholderImage: placeholderImage)
    }

    // round ImageVIew

    func roundImage(_ imagePicked: UIImage?) {

        self.image = imagePicked
        self.contentMode = .scaleAspectFill
        self.layer.masksToBounds = true
        self.layer.cornerRadius =  self.frame.size.width / 2
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor.lightGray.cgColor
    }

    func roundedImageWithBorder(width: CGFloat = 0.0, color: UIColor = .clear) {
        self.layoutIfNeeded()
        self.contentMode = .scaleAspectFill
        self.layer.cornerRadius = self.frame.width/2
        self.layer.masksToBounds = true
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
    }

    func transformImageRTL() {
        if Language.currentLanguage == .arabic {
            self.transform = CGAffineTransform(scaleX: -1, y: 1)
        }

    }

}
