//
//  CLLocationCoordinate2D.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import CoreLocation

extension CLLocationCoordinate2D {

    /// Returns distance from coordianate in meters.
    /// - Parameter from: coordinate which will be used as end point.
    /// - Returns: Returns distance in meters.
    func distance(from: CLLocationCoordinate2D) -> Double {
        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: self.latitude, longitude: self.longitude)
        return from.distance(from: toLocation).inKilometers() as Double
    }
}

extension CLLocationDistance {

    func inKilometers() -> CLLocationDistance {
        return self/1000
    }
}
