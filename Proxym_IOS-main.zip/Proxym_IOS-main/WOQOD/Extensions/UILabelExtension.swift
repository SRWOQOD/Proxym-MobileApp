//
//  UILabelExtension.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/13/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UILabel {

    override open func awakeFromNib() {
        if textAlignment != .center {
            self.semanticContentAttribute = Language.currentLanguage.semantic
            self.textAlignment =  Language.currentLanguage.textAlignment
        }
    }
    func reverseAlignment() {
        self.textAlignment = Language.currentLanguage == .arabic ? .right : .left
    }

    func setText(text: String? = "", font: String,
                 size: Int, forgroundColor: UIColor = .black, lineSpace: CGFloat = 1.5,
                 align: NSTextAlignment = .left) {

        self.font = UIFont.init(name: font, size: size.adjusted)
        self.textColor = forgroundColor
        self.adjustsFontSizeToFitWidth = true
        self.baselineAdjustment = .alignCenters

        self.setAttributedText(text: text, lineSpace: 3, align: align)

    }

    func setAttributedText(text: String? = "", lineSpace: CGFloat, align: NSTextAlignment) {

        self.text = text

        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpace.adjusted
        paragraphStyle.alignment = align

        let attributes: [NSAttributedString.Key: Any] =
            [ NSAttributedString.Key.paragraphStyle: paragraphStyle] as [NSAttributedString.Key: Any]

        let attributedText = NSMutableAttributedString(string: text ?? "", attributes: attributes)

        self.attributedText = attributedText

    }
    func setAttributedTextWithRanged(fullText: String, fullTextFontName: String,
                                     fullTextFontSize: CGFloat, fullTextColor: UIColor = .white,
                                     rangedText: String, rangedTextFontName: String ,
                                     rangedTextFontSize: CGFloat, rangedTextColor: UIColor = .white ,
                                     align: NSTextAlignment = .left, lineSpace: CGFloat = 0,
                                     forgroundColor: UIColor = .black
    ) {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpace.adjusted
        paragraphStyle.alignment = align
        let fullTextFont = UIFont(name: fullTextFontName, size: fullTextFontSize.adjusted)!
        let rangedTextFont = UIFont(name: rangedTextFontName, size: rangedTextFontSize.adjusted)!
        let attributedString =
            NSMutableAttributedString(
                string: fullText,
                attributes: [NSAttributedString.Key.font: fullTextFont,
                             NSAttributedString.Key.foregroundColor: fullTextColor,
                             NSAttributedString.Key.paragraphStyle: paragraphStyle])
        let secondTextAttributed: [NSAttributedString.Key: Any] =
            [NSAttributedString.Key.font: rangedTextFont,
             NSAttributedString.Key.foregroundColor: rangedTextColor,
             NSAttributedString.Key.paragraphStyle: paragraphStyle]
        let range = (fullText as NSString).range(of: rangedText)
        attributedString.addAttributes(secondTextAttributed, range: range)
        self.attributedText = attributedString
        self.textColor = forgroundColor
        self.adjustsFontSizeToFitWidth = true
        self.baselineAdjustment = .none
    }
    // = "#002280"
    func htmlAttributedString(text: String, fontSize: CGFloat, fontName: String, hexColor: String) {
        let textAlign = languageIsArabic ? "right" : "left"
        let string = text.appending(
            String(format: "<style>body{font-family:'%@'; font-size:%fpx;text-align:%@;color:%@}</style>",
                   fontName, fontSize, textAlign, hexColor))
        guard let data = string.data(using: String.Encoding.utf16, allowLossyConversion: false) else {return}
        guard let html = try? NSMutableAttributedString(
                data: data,
                options:
                    [NSAttributedString.DocumentReadingOptionKey.documentType:
                        NSAttributedString.DocumentType.html],
                documentAttributes: nil) else {return}
        self.attributedText = html
        self.textColor = UIColor(hexString: hexColor)
    }

    func countLabelLines() -> Int {
        // Call self.layoutIfNeeded() if your view is uses auto layout
        let text = self.text as NSString?
        let rect = CGSize(width: self.bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let labelSize = text?.boundingRect(with: rect,
                                           options: .usesLineFragmentOrigin,
                                           attributes: [NSAttributedString.Key.font: self.font as Any],
                                           context: nil)
        return Int(ceil(CGFloat(labelSize?.height ?? 0) / self.font.lineHeight)) - 1
    }

    func isTruncated() -> Bool {
        return self.countLabelLines() > self.numberOfLines ? true : false
    }
}
