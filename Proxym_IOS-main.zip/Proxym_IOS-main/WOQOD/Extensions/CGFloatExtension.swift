//
//  CGFloatExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension CGFloat {
  var adjusted: CGFloat {
    return self * Device.ratio
  }
}
