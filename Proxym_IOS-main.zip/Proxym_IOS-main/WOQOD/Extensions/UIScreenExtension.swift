//
//  UIScreenExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UIScreen {
    class var width: CGFloat {
        return UIScreen.main.bounds.size.width
    }
    class var height: CGFloat {
        return UIScreen.main.bounds.size.height
    }
}
