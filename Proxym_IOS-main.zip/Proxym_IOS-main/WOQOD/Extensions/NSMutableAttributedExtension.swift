//
//  NSMutableAttributedExtension.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 23/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

extension NSMutableAttributedString {

    func setColorForText(textToFind text: String, withColor color: UIColor, withFont font: String, withSize size: Int) {
        let range = self.mutableString.range(of: text, options: .caseInsensitive)
        if range.location != NSNotFound {
            let attributes: [NSAttributedString.Key: Any] = [
                       .foregroundColor: color,
                       .font: UIFont(name: font, size: size.adjusted) ?? ""]
            self.addAttributes(attributes, range: range)

        }
    }

}
