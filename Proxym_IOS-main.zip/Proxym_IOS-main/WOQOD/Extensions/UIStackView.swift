//
//  UIStackView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 05/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

extension UIStackView {

    func reverseSubviewsIndex(setNeedsLayout: Bool = true) -> UIStackView {
        let stackedViews = self.arrangedSubviews

        stackedViews.forEach {
            self.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }

        stackedViews.reversed().forEach(addSubview(_:))
        stackedViews.reversed().forEach(addArrangedSubview(_:))

        if setNeedsLayout {
            stackedViews.forEach { $0.setNeedsLayout() }
        }
        return self
    }
    /// This function returns WQTextFieldView in the stackView for a specific type
    /// - Parameter fieldType: FieldType
    /// - Returns: WQTextFieldView
    func getWqTFViewFor(_ fieldType: FieldType) -> WQTextFieldView? {
        guard let view  = self.arrangedSubviews.filter({
                                                        ($0 as? WQTextFieldView)?.fieldType == fieldType  })
                .first  else { return nil }

        return view as? WQTextFieldView
    }

    /// This function returns WQDropDown in the stackView for a specific type
    /// - Parameter fieldType: FieldType
    /// - Returns: WQDropDownMenu
    func getWqDropDownViewFor(_ fieldType: FieldType) -> WQDropDownMenu? {
        guard let view  = self.arrangedSubviews.filter({
                                                        ($0 as? WQDropDownMenu)?.fieldType == fieldType})
                .first  else { return nil }

        return view as? WQDropDownMenu
    }

    func removeAllArrangedSubviews() {
        let removedSubviews = arrangedSubviews.reduce([]) { (allSubviews, subview) -> [UIView] in
            self.removeArrangedSubview(subview)
            return allSubviews + [subview]
        }

        for removedSubview in removedSubviews where removedSubview.superview != nil {
                NSLayoutConstraint.deactivate(removedSubview.constraints)
                removedSubview.removeFromSuperview()
        }
    }

    /// This func is executed when all fields of WQTextFieldView are valid
    /// - Parameter completion: do stuff here
    func validCommonInputFields() -> Bool {

        var validationTextFieldsArray: [Bool] = []

        self.arrangedSubviews.forEach {
            if let value = $0 as? CommonInputFieldView, !$0.isHidden, value.isValidationMandatory {
                validationTextFieldsArray.append(value.isValid)
            }
        }
        return validationTextFieldsArray.allSatisfy({ $0 == true})
    }

    /// This func is to a background color to the stackview
    /// - Parameter color: color
    func addBackground(color: UIColor, cornerRadius: CGFloat = 0 ) {
        let subView = UIView(frame: bounds)
        subView.backgroundColor = color
        subView.cornerRadius =  cornerRadius
        subView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        insertSubview(subView, at: 0)
    }
    
    /// This func is to handle car plate type selection
    /// - Parameter dropMenu: WQDropDownMenu
    func handleCarPLateTypeChange(dropMenu dropMenuView: WQDropDownMenu) {
        self.arrangedSubviews.forEach { component in
            guard let carPlate = component as? WQTextFieldView,  carPlate.fieldType == .carPlate() || carPlate.fieldType == .carPlate(type: .diplomatic) else {
            return
            }
            carPlate.resetLabel()
            if dropMenuView.selectedText == LocalizableFahes.diplomaticTitle.localized {
                carPlate.fieldType = .carPlate(type: .diplomatic)
            } else {
                carPlate.fieldType = .carPlate()
            }
        }
    }

}
