//
//  FahesEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 6/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum FahesEndPointType: EndPointType {

    case fahesStations
    case listOfReceipts(qid: String)
    case inspectionHistory(inspection: Car)
    case inspectionDetails(inspectionId: String)
    case checkIsOwner(car: FahesCar?)
    case checkqidValidity(qid: String, mobile: String)
    case getFeeInspection(car: FahesCar?)
    case getPlateTypes
    case getCarsList(qid: String)
    case checkCar(car: FahesCar?)
    case freeCar(transactionUUID: FahesTransactionUUIDModel)
    case sendPinCode // TOFIX
    case validatePinCode(pincode: String?) // TOFIX
    case addCar(car: FahesCarRequestModel?)

    case create(transactionUUID: FahesTransactionUUIDModel)
    case createQPayTransaction(transactionPUN: FahesTransactionPUNModel)

    case isOwnerAddCar(car: FahesCar?)
    case updateTransactionUUID(transactionUUID: String)
    case cancelTransaction(pun: String)

    case generateReceiptPDF(ref: String)
    case sendReceiptByMail(ref: String, email: String, isConnected: Bool)
    case deleteCar(qid: String, plateNumber: String)

    var url: String {

        var path = ""

        switch self {
        case .fahesStations:
            path = FahesEndPoints.stations
        case .listOfReceipts:
            path = FahesEndPoints.listOfReceipts
        case .inspectionHistory:
            path = FahesEndPoints.inspectionHistory
        case .inspectionDetails:
            path = FahesEndPoints.inspectionDetails
        case .checkIsOwner:
            path = FahesEndPoints.isOwner
        case .checkqidValidity:
            path = EndPoints.checkQidValidity
        case .getFeeInspection :
            path = FahesEndPoints.inspectionFee
        case .getPlateTypes:
            path = FahesEndPoints.plateTypes
        case .getCarsList :
            path = FahesEndPoints.carsList
        case .checkCar:
            path = FahesEndPoints.checkCar
        case .sendPinCode:
            path = PincodeEndPoints.send
        case .validatePinCode:
            path = PincodeEndPoints.validate
        case .addCar :
            path = FahesEndPoints.addCar
        case .create :
            path = FahesEndPoints.createTransactionUUID
        case .isOwnerAddCar:
            path = FahesEndPoints.isOwnerAddCar
        case .updateTransactionUUID:
            path = FahesEndPoints.updateTransactionUUID
        case .generateReceiptPDF:
            path = FahesEndPoints.generateReceipt
        case .sendReceiptByMail:
            path = FahesEndPoints.sendReceiptByMail
        case .freeCar:
            path = FahesEndPoints.freeCar
        case .deleteCar:
           path = FahesEndPoints.deleteCar
        case .createQPayTransaction:
            path = FahesEndPoints.createQPayTransaction
        case .cancelTransaction:
            path = FahesEndPoints.cancelQPayTransaction

        }

        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .fahesStations, .getPlateTypes:
            return WLHttpMethodGet
        case .addCar, .create, .isOwnerAddCar,
             .sendPinCode, .sendReceiptByMail, .validatePinCode, .freeCar,
             .listOfReceipts, .inspectionHistory, .checkIsOwner,
             .checkqidValidity, .getFeeInspection, .getCarsList, .checkCar, .generateReceiptPDF, .inspectionDetails, .createQPayTransaction:
            return WLHttpMethodPost
        case .updateTransactionUUID, .cancelTransaction:
            return WLHttpMethodPost
        case .deleteCar :
            return WLHttpMethodPost

        }
    }

    var parameters: [String: Any?] {
        switch self {
        case .fahesStations, .getPlateTypes:
            return [:]
        case .listOfReceipts(let qid):
            return [FahesAPIParameterKey.qid: qid]
        case .inspectionHistory(let inspection):
            return [FahesAPIParameterKey.plateNumber: inspection.plateNumber,
                    FahesAPIParameterKey.ownerQid: inspection.ownerQid,
                    FahesAPIParameterKey.plateTypeId: inspection.plateTypeId]
        case .checkIsOwner(let car):
            var qid = ""
            if userIsConnected {
                qid = car?.qatariID?.from64ToString() ?? ""
            } else {
                qid = car?.qatariID ?? ""
            }
            return [FahesAPIParameterKey.qid:
                         qid,
                    FahesAPIParameterKey.plateNumber: car?.plateNumber ?? "",
                    FahesAPIParameterKey.plateTypeId: car?.plateTypeId
            ]
        case .checkqidValidity(let qid, let mobile):
            return [
                FahesAPIParameterKey.qid: qid ,
                FahesAPIParameterKey.number: mobile
            ]
        case .getFeeInspection(let car):
            var qid = ""
            if userIsConnected {
                qid = car?.qatariID?.from64ToString() ?? ""
            } else {
                qid = car?.qatariID ?? ""
            }
            return [FahesAPIParameterKey.qid: qid, // "28063402387" ,
                    FahesAPIParameterKey.plateNumber: car?.plateNumber ?? "", // "779496",
                    FahesAPIParameterKey.plateTypeId: car?.plateTypeId ?? 0 // 1

            ]
        case .getCarsList(let qid):
            return [FahesAPIParameterKey.qid: qid]

        case .checkCar(let car):
            var qid = ""
            if let isNumeric = car?.qatariID?.isNumeric,
               !isNumeric  {
                qid = car?.qatariID?.from64ToString() ?? ""
            } else {
                qid = car?.qatariID ?? ""
            }
            return [FahesAPIParameterKey.qid: qid ,
                    FahesAPIParameterKey.plateNumber: car?.plateNumber ?? "",
                    FahesAPIParameterKey.plateTypeId: car?.plateTypeId
            ]

        case .sendPinCode:
            return [FahesAPIParameterKey.username: AuthManager.shared.currentUser?.userName ,
                    FahesAPIParameterKey.language: Language.currentLanguage.rawValue
            ]
        case .validatePinCode(let pincode) :
            return [ PinCodeAPIParameterKey.username: AuthManager.shared.currentUser?.userName,
                     PinCodeAPIParameterKey.pinCode: pincode ?? ""]

        case .addCar(let car  ):
            return car.dictionary ?? [:]

        case .create(let transactionUUID):
            return [
                FahesAPIParameterKey.userID: transactionUUID.userID,
                FahesAPIParameterKey.qid: transactionUUID.qid,
                FahesAPIParameterKey.mobile: transactionUUID.mobile,
                FahesAPIParameterKey.mobileNumber: transactionUUID.mobile,
                FahesAPIParameterKey.email: transactionUUID.email,
                FahesAPIParameterKey.amount: transactionUUID.amount,
                FahesAPIParameterKey.inspectionType: transactionUUID.inspectionType,
                FahesAPIParameterKey.serviceCategory: transactionUUID.serviceCategory,
                FahesAPIParameterKey.categoryId: transactionUUID.categoryId,
                FahesAPIParameterKey.categoryNameAr: transactionUUID.categoryNameAr,
                FahesAPIParameterKey.categoryNameEn: transactionUUID.categoryNameEn,
                FahesAPIParameterKey.categoryFee: transactionUUID.categoryFee,
                FahesAPIParameterKey.plateNumber: transactionUUID.plateNumber,
                FahesAPIParameterKey.plateType: transactionUUID.plateType,
                FahesAPIParameterKey.referenceNumber: transactionUUID.referenceNumber,
                FahesAPIParameterKey.anonym: transactionUUID.anonym,
                FahesAPIParameterKey.transactionUUID: transactionUUID.transactionUUID,
                FahesAPIParameterKey.currency: transactionUUID.currency
            ]
        case .isOwnerAddCar(let car):
            return [
                FahesAPIParameterKey.qid: car?.qatariID,
                FahesAPIParameterKey.plateNumber: car?.plateNumber,
                FahesAPIParameterKey.plateTypeId: car?.plateTypeId
            ]
        case .updateTransactionUUID(let transactionUUID):
            return [
                FahesAPIParameterKey.transactionUUID: transactionUUID,
                FahesAPIParameterKey.statusEnum: TransactionStatus.cancelled.rawValue
            ]
        case .generateReceiptPDF(let reference) :
            return ["reference_number": String(reference)]
        case .sendReceiptByMail(let reference, let mail, let connected) :
            return [ FahesAPIParameterKey.receiptReference: reference,
                     FahesAPIParameterKey.email: mail,
                     FahesAPIParameterKey.isConnected: "\(connected)"]
        case .freeCar(let transactionUUID):
            return [
                FahesAPIParameterKey.userID: transactionUUID.userID,
                FahesAPIParameterKey.qid: transactionUUID.qid,
                FahesAPIParameterKey.mobile: transactionUUID.mobile,
                FahesAPIParameterKey.mobileNumber: transactionUUID.mobile,
                FahesAPIParameterKey.email: transactionUUID.email,
                FahesAPIParameterKey.amount: transactionUUID.amount,
                FahesAPIParameterKey.inspectionType: transactionUUID.inspectionType,
                FahesAPIParameterKey.serviceCategory: transactionUUID.serviceCategory,
                FahesAPIParameterKey.categoryId: transactionUUID.categoryId,
                FahesAPIParameterKey.categoryNameAr: transactionUUID.categoryNameAr,
                FahesAPIParameterKey.categoryNameEn: transactionUUID.categoryNameEn,
                FahesAPIParameterKey.categoryFee: transactionUUID.categoryFee,
                FahesAPIParameterKey.plateNumber: transactionUUID.plateNumber,
                FahesAPIParameterKey.plateType: transactionUUID.plateType,
                FahesAPIParameterKey.referenceNumber: AuthManager.shared.serverDate?.dateTimeStamp ?? "",
                FahesAPIParameterKey.anonym: transactionUUID.anonym,
                FahesAPIParameterKey.transactionUUID: transactionUUID.transactionUUID,
                FahesAPIParameterKey.currency: transactionUUID.currency
            ]
        case .deleteCar(let qid, let  plateNumberid):
            return [FahesAPIParameterKey.qid: qid,
                    FahesAPIParameterKey.plateNumber: plateNumberid]
        case .inspectionDetails(let inspectionId):
            return ["inspection_id": String(inspectionId)]
        case .createQPayTransaction(let transactionPUN):
            return [
                FahesAPIParameterKey.userID: transactionPUN.userID,
                FahesAPIParameterKey.qid: transactionPUN.qid,
                FahesAPIParameterKey.mobile: transactionPUN.mobile,
                FahesAPIParameterKey.mobileNumber: transactionPUN.mobile,
                FahesAPIParameterKey.email: transactionPUN.email,
                FahesAPIParameterKey.amount: transactionPUN.amount,
                FahesAPIParameterKey.inspectionType: transactionPUN.inspectionType,
                FahesAPIParameterKey.serviceCategory: transactionPUN.serviceCategory,
                FahesAPIParameterKey.categoryId: transactionPUN.categoryId,
                FahesAPIParameterKey.categoryNameAr: transactionPUN.categoryNameAr,
                FahesAPIParameterKey.categoryNameEn: transactionPUN.categoryNameEn,
                FahesAPIParameterKey.categoryFee: transactionPUN.categoryFee,
                FahesAPIParameterKey.plateNumber: transactionPUN.plateNumber,
                FahesAPIParameterKey.plateType: transactionPUN.plateType,
                FahesAPIParameterKey.referenceNumber: transactionPUN.referenceNumber,
                FahesAPIParameterKey.anonym: transactionPUN.anonym,
                FahesAPIParameterKey.pun: transactionPUN.pun,
                FahesAPIParameterKey.currency: transactionPUN.currency
            ]
        case .cancelTransaction(let pun):
            return [
                FahesAPIParameterKey.pun: pun,
                TopUpParameterKey.statusMessage: "Canceled before payment method selection.",
                TopUpParameterKey.statusCode: "2996",
                TopUpParameterKey.transactionStatus: TransactionStatus.cancelled.rawValue
            ]
        }
    }
}
