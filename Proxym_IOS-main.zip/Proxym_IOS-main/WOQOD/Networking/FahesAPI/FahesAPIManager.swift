//
//  FahesAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 6/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class FahesAPIManager {

    class func getFahesStationss() -> Future<(([FahesStationDTO], [FahesStation])), Error> {
        let result: Future<(([FahesStationDTO], [FahesStation])), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.fahesStations)
        return result
    }

    class func checkIsOwner(car: FahesCar?)  -> Future<((CarDTO<Int>, Car)), Error> {
        let result: Future<((CarDTO<Int>, Car)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.checkIsOwner(car: car))
        return result
    }

    class func checkCar(car: FahesCar?)  -> Future<((CarDTO<String>, Car)), Error> {
        let result: Future<((CarDTO<String>, Car)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.checkCar(car: car))
        return result
    }

    class func checkQidValidity(qid: String, mobile: String) -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.checkqidValidity(qid: qid, mobile: mobile))
        return result

    }

    class func getFeeInspection(car: FahesCar) -> Future<((CarDTO<Int>, Car)), Error> {

        let result: Future<((CarDTO<Int>, Car)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.getFeeInspection(car: car))
        return result

    }

    class func getPlateTypes() -> Future<(([DetailsDTO], [Details])), Error> {
        let result: Future<(([DetailsDTO], [Details])), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.getPlateTypes)
        return result

    }

    class func getFee(car: FahesCar) -> Future<((PreRegistrationFeeDTO, PreRegistrationFee)), Error> {
        let result: Future<((PreRegistrationFeeDTO, PreRegistrationFee)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.getFeeInspection(car: car))
        return result

    }

    class func getCarsList(qid: String) -> Future<(([CarDTO<String>], [Car])), Error> {
        let result: Future<(([CarDTO<String>], [Car])), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.getCarsList(qid: qid))
        return result

    }

    class func getListReceipts(qid: String) -> Future<(([ReceiptDTO<String>], [Receipt])), Error> {
        let listReeceiptResult: Future<(([ReceiptDTO<String>], [Receipt])), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.listOfReceipts(qid: qid))
        return listReeceiptResult
    }

    class func getInspectionsHistory(inspection: Car) ->
    Future<((InspectionsHistoryDTO<String>, InspectionsHistory)), Error> {
        let inspectionDetailsResult: Future<((InspectionsHistoryDTO<String>, InspectionsHistory)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.inspectionHistory(inspection: inspection))
        return inspectionDetailsResult
    }

    class func getInspectionsDetails(inspectionId: String) ->
    Future<(([InspectionDetailsDTO<String>], [InspectionDetails])), Error> {
        let inspectionDetailsResult: Future<(([InspectionDetailsDTO<String>], [InspectionDetails])), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.inspectionDetails(inspectionId: inspectionId))
        return inspectionDetailsResult
    }

    class func sendReceiptByMail(reference: String, mail: String, isConnected: Bool) ->
    Future<((Bool, Bool)), Error> {
            let result: Future<((Bool, Bool)), Error> =
                HTTPTask.request(endPointType: FahesEndPointType.sendReceiptByMail(
                                    ref: reference, email: mail, isConnected: isConnected))
            return result

        }

    class func addCar(car: FahesCarRequestModel? ) ->
    Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.addCar(car: car))
        return result

    }

    class func getReceiptPDF(reference: String) -> Future<((String, String)), Error> {
        let result: Future<((String, String)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.generateReceiptPDF(ref: reference))
        return result

    }

    /**Will be moved to pinEndpoint*/
    class func sendPinCode() -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType: FahesEndPointType.sendPinCode)
        return result

    }

    class func validatePinCode(pinCode: String?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.validatePinCode(pincode: pinCode))
        return result

    }
    class func create(transactionUUID: FahesTransactionUUIDModel) -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.create(transactionUUID: transactionUUID) )
        return result
    }

    class func isOwnerAddCar(car: FahesCar)  -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.isOwnerAddCar(car: car) )
        return result
    }

    class func updateTransactionUUID(transactionUUID: String)  -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType
                                .updateTransactionUUID(transactionUUID: transactionUUID) )
        return result
    }

    class func freeCar(transactionUUID: FahesTransactionUUIDModel) -> Future<((PaymentModelDTO, PaymentModel)), Error> {
        let result: Future<((PaymentModelDTO, PaymentModel)), Error>
            = HTTPTask.request(endPointType: FahesEndPointType.freeCar(transactionUUID: transactionUUID))
        return result
    }

    class func deleteCar(qid: String, plateNumber: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType.deleteCar(qid: qid, plateNumber: plateNumber))
        return userResult
    }
    
    class func createQPay(transactionPUN: FahesTransactionPUNModel) -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> =
        HTTPTask.request(endPointType: FahesEndPointType.createQPayTransaction(transactionPUN: transactionPUN))
        return result
    }
    
    class func cancelFahesQpayTransaction(pun: String)  -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FahesEndPointType
                                .cancelTransaction(pun: pun))
        return result
    }

}
