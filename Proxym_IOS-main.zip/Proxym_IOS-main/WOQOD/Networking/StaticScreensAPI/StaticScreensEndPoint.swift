//
//  StaticScreensEndPoint.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 12/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
private let KBaseApiMethod = ApiClient.baseURL()

enum StaticScreensEndPoint: EndPointType {

    case getStaticScreen(type: String)
    var url: String {
        var path = ""

        switch self {

        case .getStaticScreen(let type):
            path = StaticScreensEndPoints.staticScreen + "?type=" + type
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getStaticScreen :
            return WLHttpMethodGet

        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getStaticScreen :
            return [:]
        }
    }
}
