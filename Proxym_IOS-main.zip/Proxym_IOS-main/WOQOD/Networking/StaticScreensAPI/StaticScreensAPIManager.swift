//
//  StaticScreensAPIManager.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 12/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import Combine
class StaticScreensAPIManager {

    class func getStaticScreen(type: String) -> Future<((StaticScreenDTO, StaticScreenModel)), Error> {
        let result: Future<((StaticScreenDTO, StaticScreenModel)), Error> =
            HTTPTask.request(endPointType: StaticScreensEndPoint.getStaticScreen(type: type))
        return result
    }

}
