//
//  SurveyEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 11/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum SurveyEndPoint: EndPointType {

    case getStatus
    case changeStatus
    case surveysResponse(surveyID: Int, questionResponseResources: [QuestionResponseResources?])

    var url: String {
        var path = ""
        switch self {

        case .getStatus:
            path = SurveyEndPoints.status
        case .changeStatus:
            path =   SurveyEndPoints.changeStatus
        case .surveysResponse:
            path = SurveyEndPoints.surveysResponse
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getStatus:
            return WLHttpMethodPost
        case .changeStatus, .surveysResponse :
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getStatus:
            return [HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()]
        case .changeStatus:
            return [HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()]

        case .surveysResponse(let surveyId, let questionResponseResources) :

//            let questionResponseResourcesString = [QuestionResponseResources(questionId: 18379, responses: ["Fahes"]),
//            QuestionResponseResources(questionId: 18373, responses: [ "Good"]),
//            QuestionResponseResources(questionId: 18374, responses: ["ok"])].map {
//                $0.convertToString ?? ""
//            }
//
//            let questionResponseResourcesString =
//            [QuestionResponseResources(questionId: 18125, responses: ["Excellent"])].map {
//                $0.convertToString ?? ""
//            } //11200

            let questionResponseResourcesString = questionResponseResources.map {
                $0.convertToString ?? ""
            }
            let arrayStringFormat = "[" + questionResponseResourcesString.joined(separator: ",") + "]"
            return [SurveyAPIParameterKey.surveyId: surveyId,
                    SurveyAPIParameterKey.questionResponseResources: arrayStringFormat,
                    HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()
            ]

        }
    }
}
