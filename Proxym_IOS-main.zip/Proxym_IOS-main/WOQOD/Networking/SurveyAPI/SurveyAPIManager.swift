//
//  SurveyAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 11/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Combine

class SurveyAPIManager {

    class func getStatus() -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType: SurveyEndPoint.getStatus)
        return result
    }

    class func changeStatus() -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType: SurveyEndPoint.changeStatus)
        return result
    }
    class func sendSurveyResponses(surveyID: Int, questionResponseResources: [QuestionResponseResources?])
    -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: SurveyEndPoint.surveysResponse(
                                surveyID: surveyID,
                                questionResponseResources: questionResponseResources)
            )
        return result
    }

}
