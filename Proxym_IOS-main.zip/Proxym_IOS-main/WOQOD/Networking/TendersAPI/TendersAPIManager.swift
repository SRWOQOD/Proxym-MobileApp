//
//  TendersAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 12/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine
class TendersAPIManager {

    class func getTenders(page: Int, size: Int) -> Future<((PaginatedTenderDTO, PaginatedTender)), Error> {
        let result: Future<((PaginatedTenderDTO, PaginatedTender)), Error> =
            HTTPTask.request(endPointType: TendersEndPoint.getTenders(page: page, size: size))
        return result
    }

}
