//
//  TendersEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 12/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum  TendersEndPoint: EndPointType {
    case getTenders(page: Int, size: Int)

    var url: String {
        var path = ""
        switch self {

        case .getTenders:
            path = TendersEndPoints.tenders
        }
        return KBaseApiMethod + path
    }

    var method: String {
        switch self {
        case .getTenders:
            return WLHttpMethodGet
        }

    }

    var parameters: [String: Any?] {
        switch self {
        case .getTenders(let page, let size):
                return [
                    PagingParameterKey.size: size ,
                    PagingParameterKey.page: page
                ]
        }

    }
}
