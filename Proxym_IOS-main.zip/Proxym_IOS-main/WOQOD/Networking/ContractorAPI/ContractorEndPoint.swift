//
//  ContractorEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL() + "/NewApiAdapter/contractors"

enum ContractorEndPointType: EndPointType {

    case getContractors

    var url: String {

        switch self {

        case .getContractors:
            return KBaseApiMethod
        }
    }

    var method: String {

        switch self {
        case .getContractors:
            return WLHttpMethodGet
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getContractors:
            return [:]
        }
    }
}
