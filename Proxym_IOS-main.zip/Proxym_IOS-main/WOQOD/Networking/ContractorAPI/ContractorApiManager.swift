//
//  ContractorApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class ContractorAPIManager {

    class func getContractors() -> Future<(([ContractorDTO], [Contractor])), Error> {
        let contractorsResult: Future<(([ContractorDTO], [Contractor])), Error> =
            HTTPTask.request2(endPointType: ContractorEndPointType.getContractors)
        return contractorsResult
    }

}
