//
//  LocationsApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class LocationsAPIManager {

    class func getPetrolStations() -> Future<(([PetrolStationsDTO], [PetrolStations])), Error> {
        let result: Future<(([PetrolStationsDTO], [PetrolStations])), Error> =
            HTTPTask.request(endPointType: LocationsEndPointType.getPetrolStations)
        return result
    }

    class func rateStation(stationID: Int?, rate: Int?)  -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: LocationsEndPointType.rateStation(stationID: stationID, rate: rate))
        return result
    }

}
