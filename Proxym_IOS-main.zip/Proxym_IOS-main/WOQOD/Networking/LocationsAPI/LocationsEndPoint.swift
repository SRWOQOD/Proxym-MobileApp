//
//  LocationsEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum LocationsEndPointType: EndPointType {

    case getPetrolStations
    case rateStation(stationID: Int?, rate: Int?)

    var url: String {
        var path = ""

        switch self {

        case .getPetrolStations:
            path = EndPoints.locations
        case .rateStation:
            path = EndPoints.rating
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getPetrolStations:
            return WLHttpMethodPost
        case .rateStation:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getPetrolStations:
            return [:]
        case .rateStation(let stationID, let rate):
            return [RatingParameterKey.stationId: stationID,
                    RatingParameterKey.deviceID: getDeviceId(),
                    RatingParameterKey.rating: rate]
        }
    }
}
