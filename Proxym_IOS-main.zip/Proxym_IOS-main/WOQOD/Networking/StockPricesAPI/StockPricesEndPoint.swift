//
//  StockPricesEndPoint.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 15/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
private let KBaseApiMethod = ApiClient.baseURL()

enum StockPricesEndPoint: EndPointType {

    case getStockPrices
    var url: String {
        var path = ""

        switch self {

        case .getStockPrices:
            path = StockPricesEndPoints.stockPrices
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getStockPrices :
            return WLHttpMethodGet

        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getStockPrices :
            return [:]
        }
    }
}
