//
//  StockPricesAPIManager.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 15/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import Combine
class StockPricesAPIManager {

    class func getStockPrices() -> Future<(([StockPriceDTO], [StockPrice])), Error> {
        let result: Future<(([StockPriceDTO], [StockPrice])), Error> =
            HTTPTask.request(endPointType: StockPricesEndPoint.getStockPrices)
        return result
    }

}
