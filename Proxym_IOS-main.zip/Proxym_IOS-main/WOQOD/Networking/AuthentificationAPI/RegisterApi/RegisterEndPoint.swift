//
//  RegisterEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 7/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum RegisterEndPoint: EndPointType {

    case register(user: UserToRegister )
    case checkUserQid(qid: String, mobile: String)
    case checkUserEmail(email: String, username: String)
    case checkEmail(email: String)
    case checkMobile(mobile: String)
    case activateUser(username: String, pincode: String)
    case getRecoveryCode(username: String, connectionType: String)
    case checkRecoveryCode(username: String, connectionType: String, pincode: String)
    case recoverPassword(username: String, connectionType: String, newpassword: String)
    case checkqidValidity(qid: String, mobile: String)
    case checkQidMobileValidity(qid: String, mobile: String)
    case resendPinCode(username: String)
    var url: String {
        var path = ""

        switch self {
        case .register:
            path = RegisterEndPoints.regiter
        case .checkUserQid, .checkUserEmail, .checkEmail, .checkMobile:
            path = RegisterEndPoints.checkUser
        case .activateUser :
            path = RegisterEndPoints.activate
        case .recoverPassword:
            path = RegisterEndPoints.recoverPassword
        case .getRecoveryCode:
            path = RegisterEndPoints.getRecoveryCode
        case .checkRecoveryCode:
            path = RegisterEndPoints.checkRecoveryCode
        case .checkqidValidity:
            path = EndPoints.checkQidValidity
        case .resendPinCode:
            path = RegisterEndPoints.resendPinCode
        case .checkQidMobileValidity:
            path = RegisterEndPoints.checkQidAndMobileValidity
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .register, .checkUserQid, .checkUserEmail, .activateUser,
             .getRecoveryCode, .recoverPassword, .checkEmail, .checkMobile :
            return WLHttpMethodPost
        case .checkRecoveryCode, .checkqidValidity, .checkQidMobileValidity:
            return WLHttpMethodPost
        case .resendPinCode :
            return WLHttpMethodPost
        }
    }

    var parameters: [String: Any?] {
        switch self {
        case .register(let user ):
            return [

                UserParameterKey.firstName: user.firstName ,
                UserParameterKey.lastName: user.familyName ,
                UserParameterKey.mobileNumber: user.mobileNumber ,
                UserParameterKey.email: user.email ,
                UserParameterKey.adress1Label: user.address ,
                UserParameterKey.poBox: user.poBox ,
                UserParameterKey.idArea: user.idArea ,
                UserParameterKey.birthdate: user.birthdate.getDate("dd-MM-yyyy").timeStamp ,
                UserParameterKey.qid: user.qid ,
                UserParameterKey.username: user.username,
                UserParameterKey.type: user.type?.rawValue ,
                UserParameterKey.contactType: user.contactType?.rawValue ,
                UserParameterKey.password: user.password,
                UserParameterKey.language: Language.currentLanguage.rawValue,
                UserParameterKey.gender: user.gender

            ]

        case .checkUserQid(let qid, let mobile):
            return [UserParameterKey.qid: qid,
                    UserParameterKey.mobileNumber: mobile
            ]

        case .checkUserEmail(let email, let username):
            return [UserParameterKey.email: email,
                    UserParameterKey.username: username
            ]
        case .activateUser(let username, let pincode ) :
            return [UserParameterKey.username: username ,
                    UserParameterKey.pinCode: pincode,
                    UserParameterKey.deviceSerial: getDeviceId() ,
                    HTTPHeaderFieldName.deviceType.rawValue: getDeviceOSVersion()
            ]

        case .getRecoveryCode(let username, let connectionType):
            return [LoginAPIParameterKey.username:  encryptUsernameQid(userName: username, type: connectionType) ,
                    LoginAPIParameterKey.type: connectionType,
                    UserParameterKey.language: Language.currentLanguage.rawValue]

        case .checkRecoveryCode(let username, let connectionType, let pincode):
            return [UserParameterKey.pincode: pincode,
                    LoginAPIParameterKey.username: encryptUsernameQid(userName: username, type: connectionType) ,
                    LoginAPIParameterKey.type: connectionType]

        case .recoverPassword(let username, let connectionType, let newPassword):
            return [UserParameterKey.recoveredPassword: newPassword,
                    LoginAPIParameterKey.username: encryptUsernameQid(userName: username, type: connectionType) ,
                    LoginAPIParameterKey.type: connectionType]

        case .checkEmail(let email):
            return [UserParameterKey.email: email]

        case .checkMobile(let mobile):
            return [UserParameterKey.mobileNumber: mobile]

        case .checkqidValidity(let qid, let mobile):
            return [
                UserParameterKey.qid: qid ,
                UserParameterKey.number: mobile
            ]
        case .resendPinCode(let username):
            return [LoginAPIParameterKey.username: username ,
                    UserParameterKey.language: Language.currentLanguage.rawValue
            ]
        case .checkQidMobileValidity(let qid, let mobile):
            return [
                UserParameterKey.qid: qid ,
                UserParameterKey.number: mobile
            ]
        }
    }

}
