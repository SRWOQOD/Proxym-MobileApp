//
//  RegisterApiManager.swift
//  WOQOD
//
//  Created by rim ktari on 7/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class RegisterApiManager {

    class func register(user: UserToRegister ) -> Future<((Bool, Bool)), Error> {

        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.register(user: user ))
        return response

    }
    // Check username and mobile
    class func checkUser(qid: String, mobile: String) -> Future<((Bool, Bool)), Error> {

        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.checkUserQid(qid: qid, mobile: mobile))
        return response

    }
    // Check username and email
    class func checkUser(email: String, username: String) -> Future<((Bool, Bool)), Error> {

        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.checkUserEmail(email: email, username: username))
        return response

    }
    // Check mobile
    class func checkUser(mobile: String) -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType:
                                                                        RegisterEndPoint.checkMobile(mobile: mobile))
        return response
    }
    // Check email
    class func checkUser(email: String) -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType:
                                                                        RegisterEndPoint.checkEmail(email: email))
        return response
    }

    class func activateUser(username: String, pincode: String) -> Future<((Bool, Bool)), Error> {

        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.activateUser(username: username, pincode: pincode) )
        return response

    }

    class func getRecoveryCode(username: String, connectionType: String) -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint
                                .getRecoveryCode(username: username, connectionType: connectionType))
        return response
    }

    class func checkRecoveryCode(username: String, connectionType: String, pincode: String)
    -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.checkRecoveryCode(username: username,
                                                                              connectionType: connectionType,
                                                                              pincode: pincode))
        return response
    }

    class func recoverPassword(username: String, connectionType: String, newpassword: String)
    -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.recoverPassword(username: username,
                                                                            connectionType: connectionType,
                                                                            newpassword: newpassword))
        return response
    }

    class func checkQidValidity(qid: String, mobile: String) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.checkqidValidity(qid: qid, mobile: mobile))
        return result

    }

    class func checkQidMobileValidity(qid: String, mobile: String) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint.checkQidMobileValidity(qid: qid, mobile: mobile))
        return result
    }

    class func resendPinCode(username: String) -> Future<((Bool, Bool)), Error> {
        let response: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: RegisterEndPoint
                                .resendPinCode(username: username))
        return response
    }

}
