//
//  BioEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum BioEndPointType: EndPointType {

    case checkFingerPrint(fingerPrint: BioAuthentication)
    case addBioPin(bioAuth: BioAuthentication)
    case generateCustomPwd(username: String?, deviceId: String)
    case resetBioPin(bioPin: String, deviceId: String, username: String)
    case updateStatus(username: String)
    var url: String {

        var path = ""

        switch self {

        case .checkFingerPrint:
            path = FingerPrintEndPoints.checkFingerPrint
        case .addBioPin:
            path = FingerPrintEndPoints.addBioPin
        case .generateCustomPwd:
            path = FingerPrintEndPoints.generateCustomPwd
        case .resetBioPin:
            path = FingerPrintEndPoints.resetBioPin
        case .updateStatus:
            path = FingerPrintEndPoints.updateStatus
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .checkFingerPrint, .addBioPin:
            return WLHttpMethodPost
        case .generateCustomPwd:
            return WLHttpMethodPost
        case .resetBioPin, .updateStatus:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .checkFingerPrint(let fingerPrint):
            return [ BioAPIParameterKey.bioPin: fingerPrint.bioPin,
                     BioAPIParameterKey.customPwd: fingerPrint.customPwd,
                     BioAPIParameterKey.deviceId: fingerPrint.deviceId,
                     BioAPIParameterKey.username: (fingerPrint.userName),
                     BioAPIParameterKey.pinCode: fingerPrint.pinCode]

        case .addBioPin(let bioAuth):
            return [BioAPIParameterKey.bioPin: bioAuth.bioPin,
                    BioAPIParameterKey.deviceId: bioAuth.deviceId,
                    BioAPIParameterKey.username: bioAuth.userName
            ]

        case .generateCustomPwd(let username, let deviceId):
            return [BioAPIParameterKey.username: username,
                    BioAPIParameterKey.deviceId: deviceId]

        case .resetBioPin(bioPin: let bioPin, deviceId: let deviceId, username: let username):
            return [BioAPIParameterKey.username: username,
                    BioAPIParameterKey.deviceId: deviceId,
                    BioAPIParameterKey.bioPin: bioPin]
        case .updateStatus(let username):
            return [BioAPIParameterKey.username: username,
                    BioAPIParameterKey.deviceId: getDeviceId()]

        }
    }
}
