//
//  CheckFingerPrint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class BioAuthentication {

    var customPwd: String?
    var bioPin: String?
    var deviceId: String = ""
    var userName: String?
    var pinCode: String?

    init(bioPin: String?=nil, customPwd: String?=nil, deviceId: String, userName: String? = "", pinCode: String?=nil) {

        self.bioPin = bioPin
        self.customPwd = customPwd
        self.deviceId = deviceId
        self.userName = userName
        self.pinCode = pinCode
    }

}
