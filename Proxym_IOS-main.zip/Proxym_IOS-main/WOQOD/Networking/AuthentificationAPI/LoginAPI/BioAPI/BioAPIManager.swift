//
//  BioAPIManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import  Combine

class BioAPIManager {

    class func checkFingerPrint(fingerPrint: BioAuthentication) -> Future<((Bool, Bool)), Error> {
        let fingerResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request2(endPointType: BioEndPointType.checkFingerPrint(fingerPrint: fingerPrint))
        return fingerResult
    }

    class func sendBioPin(bioAuth: BioAuthentication) -> Future<((String, String)), Error> {
        let pinCodeResult: Future<((String, String)), Error> =
            HTTPTask.request2(endPointType: BioEndPointType.addBioPin(bioAuth: bioAuth))
        return pinCodeResult
    }

    class func generateCustomPwd(username: String?, deviceId: String) -> Future<((String, String)), Error> {
        let customPwdResult: Future<((String, String)), Error> =
            HTTPTask.request2(endPointType: BioEndPointType.generateCustomPwd(username: username,
                                                                              deviceId: deviceId))
        return customPwdResult
    }

    class func recoverBioPin(bioPin: String) -> Future<((Bool, Bool)), Error> {
           let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: BioEndPointType.resetBioPin(bioPin: bioPin,
                                                                       deviceId: getDeviceId(),
                                                                       username: pwdInKeyChain ?? ""))
           return result
       }
    class func updateStatus(username: String) -> Future<((Bool, Bool)), Error> {
        let updateStatusResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: BioEndPointType.updateStatus(username: username))
        return updateStatusResult
    }
}
