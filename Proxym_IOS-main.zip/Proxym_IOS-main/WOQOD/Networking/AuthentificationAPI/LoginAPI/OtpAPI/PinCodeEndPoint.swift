//
//  PinCodeEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 22/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum OTPCodeEndPointType: EndPointType {

    case sendOTPCode(username: String, language: String, bioStatus: String)
    case validateOTPCode(username: String, pincode: String, bioStatus: String)

    var url: String {
        var path = ""

        switch self {

        case .sendOTPCode:
            path =  PincodeEndPoints.send
        case .validateOTPCode:
            path = PincodeEndPoints.validate
        }

        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .sendOTPCode, .validateOTPCode:
            return WLHttpMethodPost

        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .sendOTPCode(let username, let language, let bioStatus):
            return [ PinCodeAPIParameterKey.username: username as String,
                     PinCodeAPIParameterKey.language: language as String,
                     PinCodeAPIParameterKey.bioStatus: bioStatus]

        case .validateOTPCode(let username, let pincode, let bioStatus):
            return [ PinCodeAPIParameterKey.username: username as String,
                     PinCodeAPIParameterKey.pinCode: pincode as String,
                     PinCodeAPIParameterKey.bioStatus: bioStatus]
        }
    }
}
