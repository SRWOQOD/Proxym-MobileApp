//
//  PinCodeManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 22/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class OTPCodeAPIManager {

    class func getOTPCode(username: String, bioStatus: Bool) -> Future<((Bool, Bool)), Error> {
        let language: String = Language.currentLanguage.rawValue
        let otpCodeResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: OTPCodeEndPointType.sendOTPCode(username: username,
                                                                           language: language,
                                                                           bioStatus: "\(bioStatus)"))
        return otpCodeResult
    }

    class func validateOTPCode(username: String, pincode: String, bioStatus: Bool) -> Future<((Bool, Bool)), Error> {
        let otpCodeResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: OTPCodeEndPointType.validateOTPCode(username: username,
                                                                               pincode: pincode,
                                                                               bioStatus: "\(bioStatus)"))
        return otpCodeResult
    }

    class func sendOTPCodeToUpdateUserEMail(username: String, bioStatus: Bool) -> Future<((Bool, Bool)), Error> {
        let language: String = Language.currentLanguage.rawValue
        let otpCodeResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: OTPCodeEndPointType.sendOTPCode(username: username,
                                                                           language: language,
                                                                           bioStatus: "\(bioStatus)"))
        return otpCodeResult
    }
}
