//
//  LoginAPIManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 20/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class LoginAPIManager {

    class func checkCredsValidity(username: String, type: String, password: String)
    -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: LoginEndPointType
                                .checkCredsValidity(username: username, type: type, password: password))
        return result
    }

    class func requestOTP(username: String, type: String)
    -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: LoginEndPointType
                                .requestOTP(username: username, type: type))
        return result
    }

    class func getProfilePhoto(username: String) -> Future<((String, String)), Error> {
        let profileImage: Future<((String, String)), Error> =
            HTTPTask.request2(endPointType: LoginEndPointType.getProfilePhoto(username: username))
        return profileImage
    }
    class func validatePinCode(username: String, pincode: String, type: String)
    -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: LoginEndPointType
                                .validatePinCode(username: username, pincode: pincode, type: type))
        return result
    }
    class func logout() -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: LoginEndPointType
                                .logout)
        return result
    }

}
