//
//  LoginEndPont.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 20/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

enum LoginEndPointType: EndPointType {
    // 1/ check credentials validity ( ws  : /login/verifyCredentials)
    // 2/ if true request otp ( ws : pincode/login/send )
    // 3/ verify otp ( ws : pincode/login/validatePinCode )
    // 4/ if true invoke login with mfp sdk

    //    case login(user: UserLogin)
    case checkCredsValidity(username: String, type: String, password: String)
    case requestOTP(username: String, type: String)
    case getProfilePhoto(username: String)
    case validatePinCode(username: String, pincode: String, type: String)
    case logout

    var url: String {
        var path = ""
        switch self {
        case .checkCredsValidity:
            path = LoginEndPoints.verifyCredentials
        case .requestOTP:
            path = LoginEndPoints.sendPincode
        case .getProfilePhoto:
            path = EndPoints.imageUrl
        case .validatePinCode:
            path = LoginEndPoints.validatePinCode
        case .logout:
            path = LoginEndPoints.logout
        }
        return ApiClient.baseURL() + path
    }

    var method: String {

        switch self {
        case .validatePinCode, .checkCredsValidity, .requestOTP:
            return WLHttpMethodPost
        case .getProfilePhoto, .logout:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .checkCredsValidity(let username, let type, let password):
            return [ LoginAPIParameterKey.username: username.toBase64(),
                     LoginAPIParameterKey.type: type,
                     UserParameterKey.password: password.toBase64()]
        case .requestOTP(let username, let type):
            return [LoginAPIParameterKey.username:
                        encryptUsernameQid(userName: username, type: type),
                    LoginAPIParameterKey.type: type,
                    PinCodeAPIParameterKey.language: Language.currentLanguage.rawValue]
        case .validatePinCode(let username, let pincode, let type):
            return [LoginAPIParameterKey.username:
                        encryptUsernameQid(userName: username, type: type),
                    LoginAPIParameterKey.type: type,
                    LoginAPIParameterKey.pincode: pincode]

        case .getProfilePhoto(let username):
            return [LoginAPIParameterKey.username: username]
        case .logout:
            return [HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()]
        }
    }
}

func encryptUsernameQid(userName: String, type: String) -> String {
    if type == "Qid_Auth" {
        return userName.toBase64()
    }
    return userName
}
