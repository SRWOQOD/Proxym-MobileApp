//
//  UserLogin.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class UserLogin {

    var password: String?
    var deviceId: String = ""
    var deviceType: String?
    var userName: String = ""
    var pinCode: String?
    var bioPin: String?
    var type: LoginTypeKeys = .usernameAuth
    init(password: String? = nil, deviceId: String, deviceType: String?=nil,
         userName: String, pinCode: String?=nil, bioPin: String?=nil,
         type: LoginTypeKeys) {
        self.password = password
        self.deviceId = deviceId
        self.deviceType = deviceType
        self.userName = userName
        self.pinCode = pinCode
        self.bioPin = bioPin
        self.type = type
    }

}
