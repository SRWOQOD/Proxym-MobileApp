//
//  AuthentificationChallengeHandler.swift
//  WOQOD
//
//  Created by rim ktari on 7/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
import Combine

class AuthChallengeHandler: SecurityCheckChallengeHandler {

    static let shared = AuthChallengeHandler()

    var authResult = PassthroughSubject<Result<User, Error>?, Never>()
    var tokenResult  = PassthroughSubject<Result<String, Error>?, Never>()
    let defaults = UserDefaults.standard
    var remainingAttempts: Int? = 3
    var isChallenged: Bool

    override init() {
        self.isChallenged = false
        super.init(securityCheck: SecurityCheck.name)
        WLClient.sharedInstance().registerChallengeHandler(challengeHandler: self)
    #if WOQOD_ENV_DEV
        WLClient.sharedInstance().pinTrustedCertificatePublicKey(fromFile: "UAT_Woqod.cer")
        
    #elseif WOQOD_ENV_UAT
        WLClient.sharedInstance().pinTrustedCertificatePublicKey(fromFile: "UAT_Woqod.cer")

    #elseif WOQOD_ENV_PROD
        WLClient.sharedInstance().pinTrustedCertificatePublicKey(fromFile: "Woqod_Production.der")
    #endif
    }

    func getAccessToken() {

        WLAuthorizationManager.sharedInstance()?
            .obtainAccessToken(forScope: SecurityCheck.name, withCompletionHandler: { (token, error) in

            if error != nil {
                let err = WQError(message: "RequestTimed Out", statusCode: "500", errorId: "")
                self.tokenResult.send(.failure(err))
                self.authResult.send(.failure(err))
            } else {
                #if DEBUG
                print("AccessToken", token?.value ?? "")
                #endif
                self.tokenResult.send(.success(token?.value ?? ""))
            }
            self.isChallenged = false
        })
    }

    func login(credentials: Credentials?) {

        // We should append Headers to the mfp request
        var withCredentials: [String: Any] = credentials?.dictionary ?? [:]
        withCredentials += [HTTPHeaderFieldName.deviceId.rawValue: getDeviceId(), HTTPHeaderFieldName.ipAddress.rawValue: getIPAddress()]

        if isChallenged {
            submitChallengeAnswer(withCredentials )
        } else {
            WLAuthorizationManager.sharedInstance()?
                .login(SecurityCheck.name, withCredentials: withCredentials,
                       withCompletionHandler: { (error) -> Void in
                    if error != nil {
                        let err = WQError(message: LocalizableShared.loginFail.localized, statusCode: "403", errorId: "")
                        self.tokenResult.send(.failure(err))
                        self.authResult.send(.failure(err))
                    }
            })
        }
    }

    func logout() {

        WLAuthorizationManager.sharedInstance()?.logout(SecurityCheck.name, withCompletionHandler: { (_) -> Void in
            self.isChallenged = false

        })
    }

    func cancelChallange() {
        AuthChallengeHandler.shared.cancel()
        AuthChallengeHandler.shared.isChallenged = false
    }

    // MARK: - handleChallenge
    override func handleChallenge(_ challenge: [AnyHashable: Any]!) {

        self.isChallenged = true

        guard  let challenge: Challenge =   challenge.parseDictionary() else {  return  }

        let error = WQError(errorCode: challenge.header?.statusCode ?? ErrorCode.serverError.rawValue)
        defaults.set(challenge.remainingAttempts, forKey: UserDefaultKeys.remainingAttempts)
        self.authResult.send(.failure(error))
        self.tokenResult.send(.failure(error))

    }

    // MARK: - handleSuccess
    override func handleSuccess(_ success: [AnyHashable: Any]!) {

        self.isChallenged = false

        guard  let userResult: UserResult =   success.parseDictionary() else { return }

        if let user = userResult.user?.attributes?.toDomain() {
            self.authResult.send(.success(user))
            tokenResult.send(.success(""))
        } else {

        }
    }

    // MARK: - handleFailure
    override func handleFailure(_ failure: [AnyHashable: Any]!) {
        self.isChallenged = false
        guard  let authFailure: AuthFailure =   failure.parseDictionary() else { return }

        let error: WQError = authFailure.failure !=  "Account blocked" ?
        WQError(message: authFailure.failure, statusCode: nil, errorId: nil) :  WQError(errorCode: "400")
        self.authResult.send(.failure(error))
    }
}
