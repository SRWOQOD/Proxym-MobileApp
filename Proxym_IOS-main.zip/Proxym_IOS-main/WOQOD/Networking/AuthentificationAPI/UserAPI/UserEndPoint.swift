//
//  UserEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

enum UserEndPoint: EndPointType {

    case updateUser(user: User)
    case resetPassword(username: String, password: String)
    case updatePhoto(username: String, photo: String)
    case getBalance(qid: String?, mobile: String?)
    case getAreas
    case updateEmail(username: String, email: String)
    case updatePhone(username: String, mobile: String)
    case sendPinCodeToUpdateEmail(email: String)
    case sendPinCodeToUpdatePhone(phone: String)
    case hasNotif
    case updateWoqodeUser(qid: String?, mobile: String?, isWoqode: Bool?)
    case deleteUser(username: String)

    var url: String {

        switch self {
        case .getBalance:
            return ApiClient.baseURL() + RspEndPoints.balance

        case .updateUser:
            return ApiClient.baseURL() + EndPoints.users

        case .resetPassword:
            return ApiClient.baseURL() + EndPoints.resetPass
        case .updatePhoto:
            return ApiClient.baseURL() + EndPoints.updatePhoto
        case .getAreas:
            return ApiClient.baseURL() + EndPoints.area
        case .updateEmail:
            return ApiClient.baseURL() + EndPoints.updateEmail
        case .updatePhone:
            return ApiClient.baseURL() + EndPoints.updatePhone
        case .sendPinCodeToUpdateEmail:
            return ApiClient.baseURL() + EndPoints.sendPinCodeToUpdateEmail
        case .sendPinCodeToUpdatePhone:
            return ApiClient.baseURL() + EndPoints.sendPinCodeToUpdatePhone
        case .hasNotif:
            return ApiClient.baseURL() + EndPoints.hasNotif
        case .updateWoqodeUser:
            return ApiClient.baseURL() + EndPoints.updateWoqodeUser
        case .deleteUser:
            return ApiClient.baseURL() + EndPoints.deleteUser
        }
    }

    var method: String {

        switch self {
        case .getAreas:
            return WLHttpMethodGet

        case .updateUser, .resetPassword, .updatePhoto, .updateEmail, .updatePhone:
            return WLHttpMethodPost

        case .getBalance, .hasNotif, .sendPinCodeToUpdateEmail, .sendPinCodeToUpdatePhone, .updateWoqodeUser:
            return WLHttpMethodPost
        case .deleteUser:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {

        case .getBalance(let qid, let mobile) :
//            #if DEBUG
//            qid = "28278800821"
//            mobile = "50130891"
//            #endif

            return [TopUpParameterKey.qid: qid ,
                    TopUpParameterKey.mobile: mobile
            ]

        case .updateUser(let user):
            return [ UserParameterKey.firstName: user.firstName ,
                     UserParameterKey.lastName: user.familyName ,
                     UserParameterKey.mobileNumber: user.mobileNumber ,
                     UserParameterKey.birthdate: user.birthdate,
                     UserParameterKey.email: user.email ,
                     UserParameterKey.income: AuthManager.shared.currentUser?.income ,
                     UserParameterKey.type: user.type.map { $0.rawValue } ,
                     UserParameterKey.username: user.userName ,
                     UserParameterKey.qid: AuthManager.shared.currentUser?.qid ,
                     UserParameterKey.id: AuthManager.shared.currentUser?.id ,
                     UserParameterKey.adress1Label: user.address,
                     UserParameterKey.poBox: user.poBox,
                     UserParameterKey.status: AuthManager.shared.currentUser?.status,
                     UserParameterKey.createdAt: AuthManager.shared.currentUser?.createdAt,
                     UserParameterKey.unlockAccount: user.unlockAccount,
                     UserParameterKey.fleetName: user.fleetName,
                     UserParameterKey.idArea: user.area?.idArea,
                     HTTPHeaderFieldName.ipAddress.rawValue: getIPAddress()

            ]
        case .resetPassword(let username, let password) :
            return [ UserParameterKey.username: username ,
                     UserParameterKey.password: password
            ]
        case .updatePhoto(let username, let photo) :
            return [ UserParameterKey.username: username ,
                     UserParameterKey.photo: photo
            ]
        case .getAreas:
            return [:]
        case .updateEmail(let username, let email):
            return [ UserParameterKey.username: username ,
                     UserParameterKey.email: email,
                     HTTPHeaderFieldName.ipAddress.rawValue: getIPAddress()
            ]
        case .updatePhone(let username, let mobile):
            return [ UserParameterKey.username: username ,
                     UserParameterKey.phone: mobile,
                     HTTPHeaderFieldName.ipAddress.rawValue: getIPAddress()
            ]
        case .sendPinCodeToUpdateEmail(let email):
            return [UserParameterKey.username: AuthManager.shared.currentUser?.userName ,
                    UserParameterKey.language: Language.currentLanguage.rawValue,
                    UserParameterKey.email: email
            ]
        case .sendPinCodeToUpdatePhone(let phone):
            return [UserParameterKey.username: AuthManager.shared.currentUser?.userName ,
                    UserParameterKey.language: Language.currentLanguage.rawValue,
                    UserParameterKey.phone: phone
            ]
        case .hasNotif:
            return [NotificationAPIParameterKey.device: getDeviceId(),
                    NotificationAPIParameterKey.connected: "\(userIsConnected)"]
        case .deleteUser(let userName):
            return [UserParameterKey.username: userName]
            
        case .updateWoqodeUser(let qid, let mobile, let isWoqode) :
//            #if DEBUG
//            qid = "28278800821"
//            mobile = "50130891"
//            #endif

            return [TopUpParameterKey.qid: qid ,
                    TopUpParameterKey.mobile: mobile,
                    TopUpParameterKey.isWoqode: isWoqode
            ]
        }
    }
}
