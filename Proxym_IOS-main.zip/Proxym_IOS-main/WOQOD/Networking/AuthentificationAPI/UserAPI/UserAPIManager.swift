//
//  UserAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 8/3/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class UserAPIManager {

    class func upateUser(user: User) -> Future<((UserDTO, User)), Error> {
        let userResult: Future<((UserDTO, User)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.updateUser(user: user))
        return userResult
    }

    class func resetPassword(username: String, password: String) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.resetPassword(username: username, password: password))
        return result
    }

    class func resetPhoto(username: String, photo: String) -> Future<((UserDTO, User)), Error> {
        let result: Future<((UserDTO, User)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.updatePhoto(username: username, photo: photo))
        return result
    }

    class func getBalance(qid: String?, mobile: String?) -> Future<((AccountDTO, Account)), Error> {
        let result: Future<((AccountDTO, Account)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.getBalance(qid: qid, mobile: mobile))
        return result
    }
    class func updateWoqodeUser(qid: String?, mobile: String?, isWoqode: Bool?) -> Future<((Bool, Bool)), Error> {
           let result: Future<((Bool, Bool)), Error> =
               HTTPTask.request(endPointType: UserEndPoint.updateWoqodeUser(qid: qid, mobile: mobile,isWoqode: isWoqode))
           return result
       }

    class func getAreas() -> Future<(([AreaDTO], [Area])), Error> {
        let result: Future<(([AreaDTO], [Area])), Error> = HTTPTask.request(endPointType: UserEndPoint.getAreas)
        return result
    }

    class func upateEmail(username: String, email: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.updateEmail(username: username, email: email))
        return userResult
    }

    class func upateMobileNumber(username: String, phone: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.updatePhone(username: username, mobile: phone))
        return userResult
    }

    class func sendPinCodeToUpdateEmail(email: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.sendPinCodeToUpdateEmail(email: email))
        return userResult
    }

    class func sendPinCodeToUpdatePhone(phone: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.sendPinCodeToUpdatePhone(phone: phone))
        return userResult
    }
    class func hasNotif() -> Future<(Bool, Bool), Error> {
        let userResult: Future<(Bool, Bool), Error> =
            HTTPTask.request(endPointType: UserEndPoint.hasNotif)
        return userResult
    }
    
    class func deleteUser(userName: String) -> Future<((Bool, Bool)), Error> {
        let userResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: UserEndPoint.deleteUser(username: userName))
        return userResult
    }

}
