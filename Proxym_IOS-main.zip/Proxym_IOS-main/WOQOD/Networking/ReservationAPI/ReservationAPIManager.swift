//
//  ReservationAPIManager.swift
//  WOQOD
//
//  Created by rim.ktari on 03/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import Combine

class ReservationAPIManager {

    class func otpValidation(refId: Int?, otp: String?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.otpValidation(refId: refId, otp: otp))
        return result
    }

    class func availableByCustomer(qid: String) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.availableByCustomer(qid: qid))
        return result
    }

    class func getPlateTypeWithShape() -> Future<(([PlateTypeWithShapeDTO], [PlateTypeWithShape])), Error> {
        let result: Future<(([PlateTypeWithShapeDTO], [PlateTypeWithShape])), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.getPlateTypeWithShape)
        return result
    }
    class func getPreReservationReference(fahesCar: FahesCar?)
    -> Future<((ReservationReferenceDTO, ReservationReference)), Error> {
        let result: Future<((ReservationReferenceDTO, ReservationReference)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.getPreReservationReference(fahesCar: fahesCar))
        return result
    }
    class func getAvailableStations(refId: Int?) -> Future<(([StationDTO], [Station])), Error> {
        let result: Future<(([StationDTO], [Station])), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.getAvailableStations(refID: refId))
        return result
    }
    class func getAppointmentDates(refId: Int?, stationID: Int?)
    -> Future<(([AppointmentDateDTO], [AppointmentDate])), Error> {
        let result: Future<(([AppointmentDateDTO], [AppointmentDate])), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.getAppointmentDates(refId: refId, stationID: stationID))
        return result
    }

    class func getSlots(refId: Int?, stationID: Int?, date: Date?) -> Future<(([SlotDTO], [Slot])), Error> {
        let result: Future<(([SlotDTO], [Slot])), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.getSlots(refID: refId, stationID: stationID, date: date))
        return result
    }

    class func reservation(refId: Int?, slotID: Int?,
                           userType: String?,
                           fahesCar: FahesCar?) -> Future<(FahesBookingResultDTO, FahesBooking), Error> {
        let result: Future<((FahesBookingResultDTO, FahesBooking)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType
                        .reservation(refID: refId,
                                     slotID: slotID,
                                     userType: userType,
                                     fahesCar: fahesCar))
        return result
    }

    class func detailsByCustomer(qid: String) -> Future<(([FahesBookingDTO], [FahesBooking])), Error> {
        let result: Future<(([FahesBookingDTO], [FahesBooking])), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.detailsByCustomer(qid: qid))
        return result
    }

    class func detailsByGuest(fahesCar: FahesCar?) -> Future<((FahesBookingResultDTO, FahesBooking)), Error> {
        let result: Future<((FahesBookingResultDTO, FahesBooking)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.detailsByGuest(fahesCar: fahesCar))
        return result
    }

    class func rescheduling(reservationId: Int?) -> Future<((Int, Int)), Error> {
        let result: Future<((Int, Int)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.rescheduling(reservationId: reservationId))
        return result
    }

    class func cancellation(reservationId: Int?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.cancellation(reservationId: reservationId))
        return result
    }

    class func isReservationHidden() -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.isReservationHidden)
        return result
    }

    class func resendOtp(refId: Int?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask
            .request(endPointType: ReservationEndPointType.resendOTP(refID: refId))
        return result
    }

    class func canPayOnline(refId: String?, slotID: String?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.canPayOnline(refId: refId, slotID: slotID))
        return result
    }

    class func checkBookingValidity(fahesCar: FahesCar?) -> Future<((CarValidtyDTO, CarValidity)), Error> {
        let result: Future<((CarValidtyDTO, CarValidity)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.checkBookingValidity(fahesCar: fahesCar))
        return result
    }

    class func checkOwner(fahesCar: FahesCar?) -> Future<((CarDTO<String>, Car)), Error> {
        let result: Future<((CarDTO<String>, Car)), Error> =
            HTTPTask.request(endPointType: ReservationEndPointType.checkOwner(fahesCar: fahesCar))
        return result
    }

}
