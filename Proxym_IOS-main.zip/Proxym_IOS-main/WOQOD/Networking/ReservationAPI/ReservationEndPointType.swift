//
//  ReservationEndPointType.swift
//  WOQOD
//
//  Created by rim.ktari on 03/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum ReservationEndPointType: EndPointType {
    case otpValidation(refId: Int?, otp: String?)
    case availableByCustomer(qid: String?)
    case getPlateTypeWithShape
    case getPreReservationReference(fahesCar: FahesCar?)
    case getAvailableStations(refID: Int?)
    case getAppointmentDates(refId: Int?, stationID: Int?)
    case getSlots(refID: Int?, stationID: Int?, date: Date?)
    case reservation(refID: Int?, slotID: Int?, userType: String?, fahesCar: FahesCar?)
    case detailsByCustomer(qid: String?)
    case detailsByGuest(fahesCar: FahesCar?)
    case rescheduling(reservationId: Int?)
    case cancellation(reservationId: Int?)
    case resendOTP(refID: Int?)
    case isReservationHidden
    case canPayOnline(refId: String?, slotID: String?)
    case checkOwner(fahesCar: FahesCar?)
    case checkBookingValidity(fahesCar: FahesCar?)

    var url: String {

        var path = ""

        switch self {
        case .otpValidation:
            path = ReservationEndPoints.otpValidation
        case .availableByCustomer:
            path = ReservationEndPoints.availableByCustomer
        case .getPlateTypeWithShape:
            path = ReservationEndPoints.getPlateTypeWithShape
        case .getPreReservationReference:
            path = ReservationEndPoints.getPreReservationReference
        case .getAvailableStations:
            path = ReservationEndPoints.getAvailableStations
        case .getAppointmentDates:
            path = ReservationEndPoints.getAppointmentDates
        case .getSlots:
            path = ReservationEndPoints.getSlots
        case .reservation:
            path = ReservationEndPoints.reservation
        case .detailsByCustomer:
            path = ReservationEndPoints.detailsByCustomer
        case .detailsByGuest:
            path = ReservationEndPoints.detailsByGuest
        case .rescheduling:
            path = ReservationEndPoints.rescheduling
        case .cancellation:
            path = ReservationEndPoints.cancellation
        case .isReservationHidden:
            path = ReservationEndPoints.isReservationHidden
        case .resendOTP:
            path = ReservationEndPoints.resendOtp
        case .canPayOnline:
            path = ReservationEndPoints.payOnline
        case .checkOwner:
            path = ReservationEndPoints.checkOwner
        case .checkBookingValidity:
            path = ReservationEndPoints.checkBookingValidity
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getPlateTypeWithShape, .isReservationHidden:
            return WLHttpMethodGet
        case .getAvailableStations, .getAppointmentDates,
                .availableByCustomer, .getSlots, .detailsByCustomer, .detailsByGuest, .rescheduling,
                .getPreReservationReference, .otpValidation, .reservation, .cancellation, .canPayOnline,
                .checkOwner, .checkBookingValidity:
            return WLHttpMethodPost
        case .resendOTP:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .otpValidation(let refID, let otp):
            return [ReservationAPIParameterKey.referenceId: refID,
                    ReservationAPIParameterKey.otp: otp]
        case .availableByCustomer(let qid):
            return [ReservationAPIParameterKey.customerId: qid]
        case .getPlateTypeWithShape, .isReservationHidden:
            return [:]
        case .getPreReservationReference(let fahesCar):
            return [
                ReservationAPIParameterKey.mobileNumber: fahesCar?.mobile,
                ReservationAPIParameterKey.plateNumber: fahesCar?.plateNumber,
                ReservationAPIParameterKey.plateTypeId: fahesCar?.plateTypeId,
                ReservationAPIParameterKey.vehicleShapeId: fahesCar?.vehicleShapeId,
                ReservationAPIParameterKey.customerId: encryptQidGuestMode(fahesCar: fahesCar)
            ]
        case .getAvailableStations(let refID):
            return [ReservationAPIParameterKey.referenceId: refID]
        case .getAppointmentDates(let refID, let stationId):
            return [ReservationAPIParameterKey.referenceId: refID,
                    ReservationAPIParameterKey.stationId: stationId]
        case .getSlots(let refID, let stationID, let date) :

            return [ReservationAPIParameterKey.referenceId: refID,
                    ReservationAPIParameterKey.stationId: stationID,
                    ReservationAPIParameterKey.date: date?.getStringDate("yyyy-MM-dd")]

        case .reservation(let refID, let slotID, let userType, let fahesCar):
            return [ReservationAPIParameterKey.referenceId: refID,
                    ReservationAPIParameterKey.slotId: slotID,
                    ReservationAPIParameterKey.userType: userType,
                    ReservationAPIParameterKey.vehicleShapeName: fahesCar?.vehicleShape]
            // This attribute is added to serve BO display on reservation details.

        case .detailsByCustomer(let qid):
            return [ReservationAPIParameterKey.customerId: qid?.toBase64()]
        case .detailsByGuest(let fahesCar):
            return [ReservationAPIParameterKey.mobileNumber: fahesCar?.mobile,
                    ReservationAPIParameterKey.plateNumber: fahesCar?.plateNumber,
                    ReservationAPIParameterKey.plateTypeId: fahesCar?.plateTypeId,
                    ReservationAPIParameterKey.customerId: encryptQidGuestMode(fahesCar: fahesCar)]
        case .rescheduling(let reservationId):
            return [ReservationAPIParameterKey.reservationId: reservationId]
        case .cancellation(let reservationId):
            return [ReservationAPIParameterKey.reservationId: reservationId]
        case .resendOTP(let refID):
            return [ReservationAPIParameterKey.referenceId: refID]
        case .canPayOnline(let refID, let slotId):
            return [ReservationAPIParameterKey.referenceId: refID,
                    ReservationAPIParameterKey.slotId: slotId]
        case .checkOwner(let fahesCar):
            return [ReservationAPIParameterKey.plateNumber: fahesCar?.plateNumber,
                    ReservationAPIParameterKey.plateTypeId: String(fahesCar?.plateTypeId ?? 1),
                    ReservationAPIParameterKey.customerId: encryptQidGuestMode(fahesCar: fahesCar)]
        case .checkBookingValidity(let fahesCar):
            
            return [ReservationAPIParameterKey.plateNumber: fahesCar?.plateNumber,
                    ReservationAPIParameterKey.plateTypeId: String(fahesCar?.plateTypeId ?? 1),
                    ReservationAPIParameterKey.customerId: encryptQidGuestMode(fahesCar: fahesCar)]
        }
    }
}


func encryptQidGuestMode(fahesCar: FahesCar?) -> String {
    if userIsConnected {
        return fahesCar?.qatariID ?? ""
    } else {
        return fahesCar?.qatariID?.toBase64() ?? ""
    }
}
