//
//  PaymentEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 9/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

enum PaymentEndPoint: EndPointType {

    case getSignature(amount: String, uuid: String, signedDate: String,
                      accessKey: String, profileID: String, secretKey: String, referenceNumber: String)
    case getSignatureParam(name: String?)
    case create(transactionUUID: TopUpTransactionUUIDModel)
    
    case getQpayParams(qpayParams: QPayParamsRequestModel)
    case createQpayTransaction(transactionPUN: TopUpTransactionPUNModel)
    case getCurrentDate
    case isDebitCardHidden

    var url: String {

        switch self {
        case .getSignature :
            return ApiClient.baseURL() + EndPoints.signature
        case .getSignatureParam :
            return ApiClient.baseURL() + EndPoints.getSignatureParam
        case .create :
            return ApiClient.baseURL() + EndPoints.createTransactionUUID
        case .getQpayParams:
            return ApiClient.baseURL() + EndPoints.getQpayParams
        case .createQpayTransaction:
            return ApiClient.baseURL() + EndPoints.createTransactionPUN
            
        case .getCurrentDate :
            return ApiClient.baseURL() + EndPoints.date
        case .isDebitCardHidden:
            return ApiClient.baseURL() + EndPoints.isDebitCardPaymentHidden

        }
    }

    var method: String {

        switch self {
        case .getSignature, .create, .createQpayTransaction:
            return WLHttpMethodPost
        case .getSignatureParam, .getQpayParams:
            return WLHttpMethodPost
        case .getCurrentDate, .isDebitCardHidden :
            return WLHttpMethodGet

        }
    }

    var parameters: [String: Any?] {
        switch self {
        case .getSignature(let amount, let uuid, let signedDate, let accessKey,
                           let profileID, let secretKey, let referenceNumber):

            let prq = PaymentRequestModel(amount: amount, transactionUUID: uuid, referenceNumber: referenceNumber)
            prq.accessKey = accessKey
            prq.profileId = profileID
            prq.signedDateTime = signedDate
            prq.referenceNumber = referenceNumber

            return[
                // To create transaction we need to convert paymentRequestModel dictionary to a String value
                // Then we send it as params in the body request
                PaymentParameterKey.params: prq.convertToString(),
                // With adding the type source of the paymenst
                PaymentParameterKey.secretKey: secretKey
            ]
        case .getSignatureParam(let name):
            return
                [PaymentParameterKey.name: name]

        case .create(let transactionUUIDd):
            return [TopUpParameterKey.amount: transactionUUIDd.amount ,
                    TopUpParameterKey.userID: transactionUUIDd.userID,
                    TopUpParameterKey.mobile: transactionUUIDd.mobile,
                    TopUpParameterKey.email: transactionUUIDd.email,
                    TopUpParameterKey.currency: transactionUUIDd.currency,
                    TopUpParameterKey.transactionStatus: transactionUUIDd.transactionStatus.rawValue,
                    TopUpParameterKey.transactionUUID: transactionUUIDd.transactionUUID,
                    TopUpParameterKey.qid: transactionUUIDd.qid,
                    TopUpParameterKey.referenceNumber: transactionUUIDd.referenceNumber
            ]
        case .getQpayParams(let qpayParams):
            return [PaymentParameterKey.name: qpayParams.name,
                    PaymentParameterKey.action: qpayParams.action,
                    PaymentParameterKey.qpayAmount: qpayParams.amount,
                    PaymentParameterKey.lang: Language.currentLanguage.local.identifier,
                    PaymentParameterKey.merchantModuleSessionID: qpayParams.merchantModuleSessionID,
                    PaymentParameterKey.pun: qpayParams.pun,
                    PaymentParameterKey.quantity: qpayParams.quantity,
                    PaymentParameterKey.transactionRequestDate: qpayParams.transactionRequestDate]
            
        case .createQpayTransaction(let transactionPUN):
            return [TopUpParameterKey.amount: transactionPUN.amount ,
                    TopUpParameterKey.userID: transactionPUN.userID,
                    TopUpParameterKey.mobile: transactionPUN.mobile,
                    TopUpParameterKey.email: transactionPUN.email,
                    TopUpParameterKey.currency: transactionPUN.currency,
                    TopUpParameterKey.transactionStatus: transactionPUN.transactionStatus.rawValue,
                    TopUpParameterKey.pun: transactionPUN.pun,
                    TopUpParameterKey.qid: transactionPUN.qid,
                    TopUpParameterKey.referenceNumber: transactionPUN.referenceNumber
            ]
            
        case .getCurrentDate:
            return [:]
        
        case .isDebitCardHidden:
            return [:]

        }
    }
    var shouldShowErrorAlerts: Bool {
        switch self {
            case .isDebitCardHidden:
                return false
            default:
                return true
        }
    }
    
    var shouldSendFailure: Bool {
        switch self {
            case .isDebitCardHidden:
                return true
            default:
                return false
        }
    }
}
