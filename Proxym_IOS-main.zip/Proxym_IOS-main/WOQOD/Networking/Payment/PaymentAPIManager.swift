//
//  PaymentAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 9/7/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class PaymentAPIManager {

    class func getSignature(amount: String, uuid: String,
                            signedDate: String, accessKey: String,
                            profileID: String,
                            secretKey: String, referenceNumber: String)
    -> Future<((SignatureDTO, Signature)), Error> {

        let result: Future<((SignatureDTO, Signature)), Error> = HTTPTask
            .request(endPointType: PaymentEndPoint.getSignature(
                        amount: amount, uuid: uuid, signedDate: signedDate,
                        accessKey: accessKey, profileID: profileID, secretKey:
                        secretKey, referenceNumber: referenceNumber))
        return result

    }

    class func getSignatureParam(name: String?) -> Future<((PaymentKeysDTO, PaymentKeys)), Error> {
        let result: Future<((PaymentKeysDTO, PaymentKeys)), Error> =
            HTTPTask.request(endPointType: PaymentEndPoint.getSignatureParam(name: name))
        return result
    }

    class func create(transactionUUID: TopUpTransactionUUIDModel) -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: PaymentEndPoint.create(transactionUUID: transactionUUID) )
        return result

    }
    
    class func createQpayTransaction(transactionPUN: TopUpTransactionPUNModel) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: PaymentEndPoint.createQpayTransaction(transactionPUN: transactionPUN) )
        return result

    }
    
    class func getQPayParams(qpayParams: QPayParamsRequestModel) -> Future<((QPayParamsResponseDTO, QPayParamsResponseModel)), Error> {
        let result: Future<((QPayParamsResponseDTO, QPayParamsResponseModel)), Error> = HTTPTask.request(endPointType: PaymentEndPoint.getQpayParams(qpayParams: qpayParams))
        return result
    }
    
    class func getCurrentDate() -> Future<((CurrentDateDTO, CurrentDate)), Error> {

            let result: Future<((CurrentDateDTO, CurrentDate)), Error> =
                HTTPTask.request(endPointType: PaymentEndPoint.getCurrentDate)
            return result

        }
    
    class func isDebitCardHidden() -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: PaymentEndPoint.isDebitCardHidden)
        return result

    }

}
