//
//  FuelPricesEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 02/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL() + EndPoints.fuelPrices

enum FuelPricesEndPointType: EndPointType {

    case getFuelPrices

    var shouldShowErrorAlerts: Bool {
        switch self {
        case .getFuelPrices:
            return false
        }
    }

    var url: String {

        switch self {
        case .getFuelPrices:
            return KBaseApiMethod
        }
    }

    var method: String {

        switch self {
        case .getFuelPrices:
            return WLHttpMethodGet
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getFuelPrices:
            return [:]
        }
    }
}
