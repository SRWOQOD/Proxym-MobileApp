//
//  FuelPricesApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 02/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class FuelPricesAPIManager {

    class func getFuelPrices() -> Future<(([FuelPricesDTO], [FuelPrices])), Error> {
        let fuelPricesResult: Future<(([FuelPricesDTO], [FuelPrices])), Error> =
            HTTPTask.request(endPointType: FuelPricesEndPointType.getFuelPrices)
        return fuelPricesResult
    }
}
