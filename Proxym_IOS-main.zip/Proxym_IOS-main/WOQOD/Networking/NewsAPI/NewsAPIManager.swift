//
//  NewsAPIManager.swift
//  WOQOD
//
//  Created by montassar YAAKOUBI on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import Combine

class NewsAPIManager {
    class func getNews(page: Int, size: Int) -> Future<((PaginatedNewsDTO, PaginatedNews)), Error> {
        let newsResult: Future<((PaginatedNewsDTO, PaginatedNews)), Error> =
            HTTPTask.request(endPointType: NewsEndPointType.getNews(page: page, size: size))
        return newsResult
    }

    class func updateNewsViewsNumber(identifier: Int) -> Future<((Bool, Bool)), Error> {
        let newsViewsResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: NewsEndPointType.updateNewsViewsNumberBy(id: identifier))
        return newsViewsResult
    }

}
