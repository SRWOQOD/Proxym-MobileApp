//
//  NewsEndPoint.swift
//  WOQOD
//
//  Created by montassar YAAKOUBI on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum NewsEndPointType: EndPointType {

    case getNews(page: Int, size: Int)
    case updateNewsViewsNumberBy(id: Int)

    var url: String {

        var path = ""

        switch self {
        case .getNews:
            path = EndPoints.news
        case .updateNewsViewsNumberBy:
            path = EndPoints.newsViews
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getNews:
            return WLHttpMethodPost
        case .updateNewsViewsNumberBy:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getNews(let page, let size):
            return [
                PagingParameterKey.size: size ,
                PagingParameterKey.page: page
            ]
        case .updateNewsViewsNumberBy(let identifier):
            return [NewsParameterKey.id: String(identifier)]
        }
    }
}
