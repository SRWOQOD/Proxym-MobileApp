//
//  FeedbacksEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum FeedbacksEndPointType: EndPointType {

    case postFeedback(feedback: Feedback)
    case getFeedback(username: String)
    case  getFeedbackBy(identifier: String)
    var url: String {
        var path = ""

        switch self {

        case .postFeedback:
            path =  FeedBackEndPoints.newFeedback

        case .getFeedback:
            path = FeedBackEndPoints.feedbacks
        case .getFeedbackBy:
            path = FeedBackEndPoints.getFeedbackbyid
        }

        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .postFeedback:
            return WLHttpMethodPost
        case .getFeedback, .getFeedbackBy:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .postFeedback(let feedback):
            return [FeedbackAPIParameterKey.connected: "\(userIsConnected)",
                    FeedbackAPIParameterKey.username: feedback.username,
                    FeedbackAPIParameterKey.name: feedback.name,
                    FeedbackAPIParameterKey.category: feedback.category,
                    FeedbackAPIParameterKey.contactNumber: feedback.contactNumber,
                    FeedbackAPIParameterKey.content: feedback.comment,
                    FeedbackAPIParameterKey.creationDate: "\(feedback.creationDate ?? getCurrentDate().timeStamp)",
                    FeedbackAPIParameterKey.email: feedback.email,
                    FeedbackAPIParameterKey.file: feedback.file,
                    FeedbackAPIParameterKey.sector: feedback.sector,
                    FeedbackAPIParameterKey.status: feedback.state,
                    FeedbackAPIParameterKey.language: Language.currentLanguage.local.identifier
            ]

        case .getFeedback(let username):
            return [ FeedbackAPIParameterKey.username: username]
        case .getFeedbackBy(let identifier):
            return [FeedbackAPIParameterKey.id: identifier]
        }
    }
}
