//
//  FeedbacksApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class FeedbackAPIManager {

    class func getFeedbacks(username: String) -> Future<(([FeedbackDTO], [Feedback])), Error> {
        let feedbacksResult: Future<(([FeedbackDTO], [Feedback])), Error> =
            HTTPTask.request2(endPointType: FeedbacksEndPointType.getFeedback(username: username))
        return feedbacksResult
    }
    class func postFeedback(feedback: Feedback) -> Future<((Bool, Bool)), Error> {
        let feedbackResult: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: FeedbacksEndPointType.postFeedback(feedback: feedback))
        return feedbackResult
    }
    class func getFeedbacks(identifier: String) -> Future<((FeedbackDTO, Feedback)), Error> {
        let feedbacksResult: Future<((FeedbackDTO, Feedback)), Error> =
            HTTPTask.request(endPointType: FeedbacksEndPointType.getFeedbackBy(identifier: identifier))
        return feedbacksResult
    }
}
