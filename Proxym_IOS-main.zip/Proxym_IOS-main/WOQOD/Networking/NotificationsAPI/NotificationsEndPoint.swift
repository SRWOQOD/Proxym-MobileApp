//
//  NotificationsEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 12/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
private let KBaseApiMethod = ApiClient.baseURL()
enum NotificationsEndPoint: EndPointType {

    case getNotifList(page: Int, size: Int, username: String)
    case updateStatus(username: String, notifID: Int)
    case updatePushStatus(pushNotificationID: String, userName: String?)
    case updateAll(username: String)
    case getNotifListGuest(page: Int, size: Int)
    var url: String {
        var path = ""
        switch self {

        case .getNotifList:
            path = NotificationsEndPoints.notificationList
        case .updateStatus, .updatePushStatus:
            path = NotificationsEndPoints.updateStatus
        case .updateAll:
            path = NotificationsEndPoints.updateAll
        case .getNotifListGuest:
            path = NotificationsEndPoints.notificationListGuest
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getNotifList, .getNotifListGuest:
            return WLHttpMethodPost
        case .updateAll, .updateStatus, .updatePushStatus:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getNotifList(let page, let size, let username):
            return [UserParameterKey.username: username,
                    NotificationAPIParameterKey.page: page,
                    NotificationAPIParameterKey.size: size,
                    HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()
            ]
        case .updateAll(let username):
            return [UserParameterKey.username: username,
                    NotificationAPIParameterKey.deviceid: getDeviceId(),
                    NotificationAPIParameterKey.connected: "\(userIsConnected)"
            ]
        case .updateStatus(let username, let idNotif):
            if userIsConnected {
                return [UserParameterKey.username: username,
                        NotificationAPIParameterKey.idnotif: "\(idNotif)",
                        NotificationAPIParameterKey.uniqueid: ""]
            } else {
                return [UserParameterKey.username: "",
                        NotificationAPIParameterKey.idnotif: "\(idNotif)",
                        NotificationAPIParameterKey.uniqueid: ""]
            }

        case .updatePushStatus(let pushNotificationID, let userName):
            if userIsConnected {
                return [UserParameterKey.username: userName,
                    NotificationAPIParameterKey.idnotif: pushNotificationID,
                    NotificationAPIParameterKey.uniqueid: pushNotificationID,
                    NotificationAPIParameterKey.deviceid: "\(getDeviceId())"]

            } else {
                return [NotificationAPIParameterKey.idnotif: pushNotificationID,
                    NotificationAPIParameterKey.uniqueid: pushNotificationID,
                    NotificationAPIParameterKey.deviceid: "\(getDeviceId())"]
            }
        case .getNotifListGuest(let page, let size):
            return [NotificationAPIParameterKey.page: page,
                    NotificationAPIParameterKey.size: size,
                    HTTPHeaderFieldName.deviceId.rawValue: getDeviceId()
            ]
        }
    }
}
