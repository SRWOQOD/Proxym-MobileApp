//
//  NotificationsAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 12/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//
import Combine
import Foundation
class NotificationsAPIManager {
    class func getNotificationsList(page: Int, size: Int, username: String)
    -> Future<((PaginatedNotificationDTO, PaginatedNotification)), Error> {
        let result: Future<((PaginatedNotificationDTO, PaginatedNotification)), Error> =
            HTTPTask.request(endPointType: NotificationsEndPoint.getNotifList(page: page,
                                                                              size: size,
                                                                              username: username))
        return result
    }
    class func updateAll(username: String) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: NotificationsEndPoint.updateAll(username: username))
        return result
    }
    class func updateStatus(username: String, notifID: Int ) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: NotificationsEndPoint.updateStatus(username: username,
                                                                              notifID: notifID ))
        return result
    }

    class func updatePushStatus(pushID: String, userName: String?) -> Future<((Bool, Bool)), Error> {
        let result: Future<((Bool, Bool)), Error> =
            HTTPTask.request(endPointType: NotificationsEndPoint.updatePushStatus(
                                pushNotificationID: pushID, userName: userName))
        return result
    }

    class func getNotificationsListGuest(page: Int, size: Int)
    -> Future<((PaginatedNotificationDTO, PaginatedNotification)), Error> {
        let result: Future<((PaginatedNotificationDTO, PaginatedNotification)), Error> =
            HTTPTask.request(endPointType: NotificationsEndPoint.getNotifListGuest(
                                page: page, size: size
            ))
        return result
    }

}
