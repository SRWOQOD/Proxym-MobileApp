//
//  ManageCarEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 05/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import  IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL() // + EndPoints.manageCar

enum ManageCarEndPointType: EndPointType {

    case getCarsByQid(qid: String)
    case deleteCar(carId: String, qid: String)
    case updateCarFuelStatus(carId: String, qid: String, fuelStatus: Bool)
    case updateCarFuelLimit(carId: String, qid: String, fuelStatus: Bool)

    var url: String {

        var path = ""

        switch self {

        case .getCarsByQid:
            path = "/NewApiAdapter/fahes/listCars"

        case .deleteCar:
            path = "/NewApiAdapter/fahes/updateStatusCar"

        case .updateCarFuelStatus:
             path = "/NewApiAdapter/updateFuelStatus"
        case .updateCarFuelLimit:
             path = "/NewApiAdapter/updateCarFuelLimit"
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getCarsByQid:
            return WLHttpMethodPost
        case .deleteCar:
            return WLHttpMethodDelete
        case .updateCarFuelStatus, .updateCarFuelLimit:
            return WLHttpMethodPut
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getCarsByQid(let qid):
            return [ ManageCarParameterKey.qid: qid]

        case .deleteCar(let carId, qid: let qid):
            return [ManageCarParameterKey.carId: carId,
                    ManageCarParameterKey.qid: qid]

        case .updateCarFuelStatus(let carId, let qid, let fuelStatus),
             .updateCarFuelLimit(let carId, let qid, let fuelStatus):
            return [ManageCarParameterKey.carId: carId,
                    ManageCarParameterKey.qid: qid,
                    ManageCarParameterKey.carFuelStatus: String(fuelStatus) ]
        }
    }
}
