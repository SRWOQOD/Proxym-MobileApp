//
//  ManageCarApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 05/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class ManageCarAPIManager {

    class func getCarsByQid(qid: String) -> Future<(([CarDTO<String>], [Car])), Error> {
        return  HTTPTask.request(endPointType: ManageCarEndPointType.getCarsByQid(qid: qid))
    }
    class func deleteCarById(carId: String, qid: String) -> Future<((Bool, Bool)), Error> {
        return  HTTPTask.request(endPointType: ManageCarEndPointType.deleteCar(carId: carId, qid: qid))
    }

    class func updateCarFuelStatus(carId: String, qid: String, carFuelStatus: Bool) -> Future<((Bool, Bool)), Error> {
        return  HTTPTask.request2(endPointType:
                                    ManageCarEndPointType.updateCarFuelStatus(carId: carId,
                                                                              qid: qid,
                                                                              fuelStatus: carFuelStatus))
    }

    class func updateCarFuelLimit(carId: String, qid: String, carFuelStatus: Bool) -> Future<((Bool, Bool)), Error> {
        return  HTTPTask.request2(endPointType: ManageCarEndPointType
                                    .updateCarFuelLimit(carId: carId, qid: qid,
                                                        fuelStatus: carFuelStatus))
    }
}
