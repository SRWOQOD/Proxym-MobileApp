//
//  WoqodeAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 8/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class WoqodeAPIManager {

    class func getMaxMin() -> Future<((TopUpPaymentDTO, TopUpPayment)), Error> {
        let result: Future<((TopUpPaymentDTO, TopUpPayment)), Error> =
            HTTPTask.request(endPointType: WoqodeEndPoint.getMaxMin )
        return result
    }

    class func getCustomerByFleetName(qid: String) ->
    Future<(([TransactionHistoryCustomerDTO], [TransactionHistoryCustomerDTO])), Error> {

        let result: Future<(([TransactionHistoryCustomerDTO],
                             [TransactionHistoryCustomerDTO])), Error>
            = HTTPTask.request(endPointType: WoqodeEndPoint.getCustomerByFleetName(qid: qid) )
        return result

    }

    class func getAllSalesTransactions(qid: String, plateNumbersStr: String) ->
    Future<(([TransactionHistoryDTO], [TransactionHistory])), Error> {
        let result: Future<(([TransactionHistoryDTO],
                             [TransactionHistory])), Error>
            = HTTPTask.request(endPointType: WoqodeEndPoint
                                .getAllSalesTransactions(qid: qid, plateNumbersStr: plateNumbersStr) )
        return result
    }
    class func getSalesTransactions(qid: String, plateNumber: String) ->
    Future<(([TransactionHistoryDTO], [TransactionHistory])), Error> {

        let result: Future<(([TransactionHistoryDTO], [TransactionHistory])), Error>
            = HTTPTask.request(endPointType: WoqodeEndPoint.getSalesTransactions(qid: qid, plateNumber: plateNumber) )
        return result

    }

    class func getTopupReceipt(reference: String) -> Future<((String, String)), Error> {
        let result: Future<((String, String)), Error> =
            HTTPTask.request(endPointType: WoqodeEndPoint.getTopupReceipt(ref: reference))
        return result
    }

    class func sendTopUpReceiptByMail(reference: String, mail: String, isConnected: Bool)
    -> Future<((Bool, Bool)), Error> {
            let result: Future<((Bool, Bool)), Error> =
                HTTPTask.request(endPointType: WoqodeEndPoint.sendReceiptByMail(
                                    ref: reference, email: mail, isConnected: isConnected))
            return result

        }
    class func updateTransactionUUID(transactionUUID: String)
    -> Future<((TopUpTransactionModelDTO, TopUpTransactionModel)), Error> {
        let result: Future<((TopUpTransactionModelDTO, TopUpTransactionModel)), Error> =
            HTTPTask.request(endPointType: WoqodeEndPoint
                                .topupUpdateTransactionUUID(transactionUUID: transactionUUID) )
        return result
    }
    
    class func cancelWoqodeQpayTransaction(pun: String)
    -> Future<((TopUpTransactionModelDTO, TopUpTransactionModel)), Error> {
        let result: Future<((TopUpTransactionModelDTO, TopUpTransactionModel)), Error> =
            HTTPTask.request(endPointType: WoqodeEndPoint
                                .cancelTransaction(pun: pun) )
        return result
    }

}
