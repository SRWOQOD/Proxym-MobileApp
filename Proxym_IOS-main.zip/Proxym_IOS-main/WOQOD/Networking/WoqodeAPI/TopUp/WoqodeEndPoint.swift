//
//  WoqodeEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 8/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import  IBMMobileFirstPlatformFoundation

enum WoqodeEndPoint: EndPointType {

    case getMaxMin
    case getCustomerByFleetName( qid: String)
    case getAllSalesTransactions(qid: String, plateNumbersStr: String)
    case getSalesTransactions(qid: String, plateNumber: String)
    case getTopupReceipt(ref: String)
    case sendReceiptByMail(ref: String, email: String, isConnected: Bool)
    case topupUpdateTransactionUUID(transactionUUID: String)
    case cancelTransaction(pun: String)
    var url: String {

        switch self {

        case .getMaxMin :
            return ApiClient.baseURL() + EndPoints.getMaxMin
        case .getCustomerByFleetName:
            return ApiClient.baseURL() + RspEndPoints.getCustomerByFleetName
        case .getAllSalesTransactions:
            return ApiClient.baseURL() + RspEndPoints.getAllSalesTransactions

        case .getSalesTransactions:
            return ApiClient.baseURL() + RspEndPoints.getSalesTransactions

        case .getTopupReceipt(let reference):
            return ApiClient.baseURL() + RspEndPoints.getTopupReceipt + "?reference_number=" + String(reference)
        case .sendReceiptByMail:
            return ApiClient.baseURL() + RspEndPoints.sendByMailReceipt
        case .topupUpdateTransactionUUID:
            return ApiClient.baseURL() + RspEndPoints.updateTransactionUUID
        case .cancelTransaction:
            return ApiClient.baseURL() + RspEndPoints.cancelTransaction
        }
    }

    var method: String {

        switch self {
        case .getMaxMin, .sendReceiptByMail, .getSalesTransactions, .getAllSalesTransactions, .getCustomerByFleetName:
            return WLHttpMethodPost
        case  .getTopupReceipt:
            return WLHttpMethodGet
        case .topupUpdateTransactionUUID, .cancelTransaction:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getMaxMin :
            return [:]
        case .getCustomerByFleetName(let qid):

//            #if DEBUG
//            qid = "28263400597"
//            #endif
            return [TopUpParameterKey.qid: qid]
        case .getSalesTransactions(let qid, let plateNumber):
//            #if DEBUG
//            qid = "28263400597"
//            #endif

            return [TopUpParameterKey.qid: qid,
                    TopUpParameterKey.plateNumber: plateNumber
            ]

        case .getAllSalesTransactions(let qid, let plateNumbersStr):
//            #if DEBUG
//            qid = "28263400597"
//            #endif

            return [
                TopUpParameterKey.qid: qid,
                TopUpParameterKey.plateNumbersStr: plateNumbersStr
            ]
        case .getTopupReceipt:
            return [:]
        case .sendReceiptByMail(let reference, let mail, let connected) :
            return [ TopUpParameterKey.referenceNumber: reference,
                     TopUpParameterKey.email: mail,
                     TopUpParameterKey.isConnected: "\(connected)"]
        case .topupUpdateTransactionUUID(transactionUUID: let transactionUUID):
            return [
                TopUpParameterKey.transactionUUID: transactionUUID,
                TopUpParameterKey.statusEnum: TransactionStatus.cancelled.rawValue
            ]
        case .cancelTransaction(let pun):
            return [
                TopUpParameterKey.pun: pun,
                TopUpParameterKey.statusEnum:  TransactionStatus.cancelled.rawValue,
                TopUpParameterKey.statusCode: "2996",
                TopUpParameterKey.statusMessage: "Canceled before payment method selection.",
                TopUpParameterKey.transactionStatus: TransactionStatus.cancelled.rawValue
            ]
        }
    }

}
