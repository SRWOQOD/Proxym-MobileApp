//
//  ContractorDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class ContractorDTO: DataModel, Codable {

    public var title: String?
    public var address: String?
    public var phone: [String?]
    public var fax: String?
    public var email: String?

    override func toDomain() -> Contractor? {
            return Contractor.init(title: title,
                                   address: address,
                                   phone: phone,
                                   fax: fax,
                                   email: email)
    }

}
