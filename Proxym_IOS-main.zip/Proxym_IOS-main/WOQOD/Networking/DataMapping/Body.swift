//
//  Body.swift
//  WOQOD
//
//  Created by rim ktari on 6/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Body<T: Codable>: Codable {
    public var type: String?
    public var result: T?
}
