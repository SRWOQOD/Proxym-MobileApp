//
//  RetailDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 24/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class RetailerDTO: DataModel, Codable {

    public var id: Int?
    public var arabicTitle: String?
    public var xportalAdress, latitude, xportalPhone: String?
    public var contactPerson: String?
    public var retailID: Int?
    public var title: String?
    public var lastSynchronisationDate: Int?
    public var xportalTitle: String?
    public var areaID: Int?
    public var imageCaption: String?
    public var longitude: String?
    public var icon: String?
    var area: AreaDTO?

    enum CodingKeys: String, CodingKey {
        case arabicTitle, xportalAdress, latitude, lastSynchronisationDate, xportalPhone, contactPerson
        case retailID = "retailId"
        case title, xportalTitle
        case areaID = "areaId"
        case imageCaption, id, longitude, icon
        case area = "areaResource"
    }

    override func toDomain() -> Retailer? {
        return Retailer.init(id: id, name: title,
                             nameAR: arabicTitle,
                             phoneNumber: xportalPhone, latitude: latitude, longitude: longitude, icon: icon,
                             area: area?.toDomain())

            }

}
