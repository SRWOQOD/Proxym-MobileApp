//
//  CurrentDateDTO.swift
//  WOQOD
//
//  Created by Oumeima.ben-Ghalba on 1/7/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
import CoreData

class CurrentDateDTO: DataModel, Codable {
    let dateTimeStamp: String?
    let utcDateTime: String?
    let qpayDate: String?

    enum CodingKeys: String, CodingKey {
        case dateTimeStamp = "CurrentDateTimeStamp"
        case utcDateTime = "UTCDateTime"
        case qpayDate = "DebitCardDateFormat"
    }
    override func toDomain() -> CurrentDate? {
        return CurrentDate(dateTimeStamp: dateTimeStamp, utcDateTime: utcDateTime, qpayDate: qpayDate)
    }
}
