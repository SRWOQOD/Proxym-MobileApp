//
//  TopUpPaymentDTO.swift
//  WOQOD
//
//  Created by rim ktari on 9/2/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class TopUpPaymentDTO: DataModel, Codable {

    let minAmount, maxAmount: Float?
    let name: String?
    let id: Int?

    override func toDomain() -> TopUpPayment? {
        return TopUpPayment(minAmount: minAmount, maxAmount: maxAmount)
    }
}
