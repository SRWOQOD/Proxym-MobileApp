//
//  DetailsDTO.swift
//  WOQOD
//
//  Created by rim ktari on 9/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class DetailsDTO: DataModel, Codable {

    var nameAr: String?
    var id: Int?
    var nameEn: String?

    enum CodingKeys: String, CodingKey {
        case nameAr = "name_ar"
        case id
        case nameEn = "name_en"
    }

    override func toDomain() -> Details? {
        return Details(name: languageIsEnglish ? nameEn : nameAr, id: id)
    }
}
