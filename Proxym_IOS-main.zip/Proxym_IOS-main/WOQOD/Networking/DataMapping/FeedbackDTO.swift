//
//  FeedbackDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class FeedbackDTO: DataModel, Codable {
    let id: Int?
    let userName: String?
    let name, contactNumber, content: String?
    let feedbackResponseResources: [FeedbackResponseResource]
    let status: Bool?
    let email: String?
    let category, sector: String?
    let creationDate: Int64?
    let connected: Bool?
    let file: String?
    let photo: String?

    override func toDomain() -> Feedback? {
        return Feedback.init(
            id: String(id ?? 0),
            username: userName,
            name: name,
            category: category,
            contactNumber: contactNumber,
            email: email,
            sector: sector,
            comment: content,
            file: file,
            creationDate: creationDate,
            state: status,
            feedbackResponseResources: feedbackResponseResources)
    }
}

// MARK: - FeedbackResponseResource
struct FeedbackResponseResource: Codable {
    let id: Int?
    let adminName: String?
    let content: String?
    let creationDate: Int64?
    let feedbackId: Int?
}
