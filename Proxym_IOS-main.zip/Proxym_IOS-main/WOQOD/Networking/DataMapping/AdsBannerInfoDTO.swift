//
//  AdsBannerInfoDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 05/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import UniformTypeIdentifiers
class AdsBannerInfoDTO: DataModel, Codable {

    let fileTypeEnum: BannerFileType?
    let orderItem: Int?
    let active: Bool?
    let fileUrl: String?
    let id: Int?
    let creationDate: Int64?
    let appRedirection: AppRedirectionType?
    let redirectionTypeEnum: BannerRedirectionPath?
    let redirectionPath: String?
    let redirectionArPath: String?
    let redirection: Bool?
    let title: String?
    let videoThumbnail: String?
    let titleArabic: String?
    let titleDisplayed: Bool?
    enum CodingKeys: String, CodingKey {
        case fileTypeEnum
        case orderItem, id
        case active, redirection, titleDisplayed
        case fileUrl, redirectionPath, title, videoThumbnail, titleArabic
        case creationDate
        case appRedirection
        case redirectionTypeEnum
        case redirectionArPath
    }

    override func toDomain() -> AdsBannerInfo? {
        return AdsBannerInfo(imageURL: (fileTypeEnum == .image ? fileUrl : videoThumbnail),
                             type: fileTypeEnum ?? .image,
                             videoURL: (fileTypeEnum == .video ? fileUrl : ""),
                             appRedirectionType: appRedirection,
                             orderItem: orderItem,
                             redirectionURL: languageIsEnglish ? redirectionPath : redirectionArPath,
                             redirectionTypeEnum: redirectionTypeEnum,
                             bannerTitle: languageIsArabic ? titleArabic : title,
                             shouldRedirect: redirection ?? false,
                             titleDisplayed: titleDisplayed ?? true,
                             showVideo: (fileTypeEnum == .video ? true : false))
    }
}
