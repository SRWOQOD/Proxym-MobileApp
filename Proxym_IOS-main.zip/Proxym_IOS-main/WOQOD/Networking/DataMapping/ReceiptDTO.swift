//
//  ReceiptDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class ReceiptDTO<T: Codable>: DataModel, Codable {

    public var wsStatus: String?
    public var discountInfo: String?
    public var serviceCategory: String?
    public var initialAmount, creationDate: Int?
    public var referenceNumber: String?
    public var qid: String?
    public var errorNo: String?
    public var userNameEn, userNameAr, transactionUUID, payStatus: String?
    public var car: CarDTO<T>?
    public var errorEn, errorAr: String?
    public var finalAmount, id: Int?
    public var category: PreRegistration?
    public var mobileNumber: String?
    public var receipturl: String?
    public var barcodeReference: String?
    public var inspectionType: String?
    public var barcode: String?

    enum CodingKeys: String, CodingKey {
           case wsStatus = "ws_status"
           case discountInfo = "discount_info"
           case serviceCategory = "service_category"
           case userNameAr
           case initialAmount = "initial_amount"
           case creationDate = "creation_date"
           case referenceNumber = "reference_number"
           case qid
           case errorNo = "error_no"
           case userNameEn, transactionUUID
           case payStatus = "pay_status"
           case car
           case errorEn = "error_en"
           case finalAmount = "final_amount"
           case id, category
           case mobileNumber = "mobile_number"
           case receipturl
           case barcodeReference = "barcode_reference"
           case inspectionType = "inspection_type"
           case barcode
           case errorAr = "error_ar"
       }

    override func toDomain() -> Receipt? {

        return Receipt.init(receipturl: receipturl,
                            referenceNumber: referenceNumber,
                            wsStatus: wsStatus,
                            discountInfo: discountInfo ,
                            serviceCategory: serviceCategory,
                            initialAmount: initialAmount ,
                            creationDate: creationDate,
                            qid: qid,
                            errorNo: errorNo,
                            userName: languageIsEnglish ? userNameEn : userNameAr,
                            transactionUUID: transactionUUID,
                            payStatus: payStatus,
                            car: car?.toDomain(),
                            error: languageIsEnglish ? errorEn : errorAr,
                            finalAmount: finalAmount,
                            id: id,
                            category: category,
                            mobileNumber: mobileNumber,
                            barcodeReference: barcodeReference,
                            inspectionType: inspectionType,
                            barcode: barcode)
    }

}

// MARK: - Category
public class PreRegistration: Codable {

    public var preRegistrations: String?
    public var fee, id: Int?
    public var categoryID, nameEn, nameAr: String?

    enum CodingKeys: String, CodingKey {
        case preRegistrations = "pre_registrations"
        case nameAr = "name_ar"
        case fee
        case id = "_id"
        case categoryID = "id"
        case nameEn = "name_en"
    }
}
