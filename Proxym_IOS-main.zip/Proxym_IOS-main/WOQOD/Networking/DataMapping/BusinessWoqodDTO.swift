//
//  BusinessWoqodDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 06/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class BusinessWoqodDTO: DataModel, Codable {

    let fileTypeEnum: String?
    let orderItem: Int?
    let description, descriptionArabic: String?
    let active: Bool?
    var redirectionTypeEnum: BannerRedirectionPath?
    var appRedirection: AppRedirectionType?
    let creationDate: Int?
    let redirectionPath: String?
    let redirectionArPath: String?
    let title, titleArabic: String?
    let uncheckedIconURL, imageURL: String?
    let id: Int?
    let checkedIconURL: String?
    let redirection: Bool?
    let iconTitle, iconTitleArabic: String?
    enum CodingKeys: String, CodingKey {
        case fileTypeEnum, appRedirection, orderItem
        case description = "description"
        case descriptionArabic = "descriptionArabic"
        case active, redirectionTypeEnum, creationDate, redirectionPath, title
        case uncheckedIconURL = "uncheckedIconUrl"
        case redirectionArPath = "redirectionArPath"
        case imageURL = "imageUrl"
        case id
        case checkedIconURL = "checkedIconUrl"
        case redirection, iconTitle, titleArabic, iconTitleArabic
    }
    override func toDomain() -> BusinessWoqod? {
        return BusinessWoqod(title: languageIsEnglish ? title : titleArabic,
                             description: languageIsEnglish ? description : descriptionArabic,
                             shouldRedirect: redirection ?? false,
                             detailsImageURL: imageURL,
                             selectedIconURL: checkedIconURL,
                             unselectedIconURL: uncheckedIconURL,
                             redirectionURL: languageIsEnglish ? redirectionPath : redirectionArPath,
                             iconTitle: languageIsEnglish ? iconTitle : iconTitleArabic,
                             orderItem: orderItem,
                             redirectionTypeEnum: redirectionTypeEnum,
                             appRedirectionType: appRedirection)
    }
}
