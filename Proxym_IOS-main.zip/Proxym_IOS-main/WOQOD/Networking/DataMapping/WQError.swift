//
//  WQError.swift
//  WOQOD
//
//  Created by rim ktari on 7/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class WQError: Error {

    public var message: String?

    public var statusCode: String?

    public var errorId: String?

    init(message: String?, statusCode: String?, errorId: String?) {
        self.message = message
        self.statusCode = statusCode
        self.errorId = errorId
    }

    init(errorCode: String? = nil) {
        self.statusCode = errorCode
        message = getMessage(statusCode ?? ErrorCode.serverError.rawValue)
    }

    func getMessage(_ errorStatus: String) -> String {

        let errorStatus =  ErrorCode.init(rawValue: errorStatus)

        var returnedMessage = ""

        switch errorStatus {

        case .usernameOrPasswordWrongError :
            let attempts = UserDefaults.standard.integer(forKey: UserDefaultKeys.remainingAttempts)
            returnedMessage = String.init(format: LocalizableShared.errorVerifyYourCredentials.localized,
                                          String(attempts))

        case .userPendingError:
            returnedMessage = LocalizableShared.errorUserPending.localized

        case .dataNotAvailableError:
            returnedMessage = LocalizableShared.errorErrorOccurred.localized

        case .userBlocked :
            break

        case .serverError:
            returnedMessage = LocalizableShared.errorServerMessage.localized

        case .timoutRequest:
            returnedMessage = LocalizableShared.errorUnexpectedMessage.localized

        case .noInternet:
            returnedMessage = LocalizableShared.errorNetwork.localized

        default:
            returnedMessage = LocalizableShared.errorUnexpectedMessage.localized
        }

        return  returnedMessage
    }
}
