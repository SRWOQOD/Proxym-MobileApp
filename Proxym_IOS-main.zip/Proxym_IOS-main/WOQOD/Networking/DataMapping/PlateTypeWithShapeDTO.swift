//
//  PlateTypeWithShapeDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 03/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class  PlateTypeWithShapeDTO: DataModel, Codable {

    let plateTypeID: Int?
    let plateTypeNameAr: String?
    let vehicleShapes: [VehicleShapeDTO]?
    let plateTypeNameEn: String?

    enum CodingKeys: String, CodingKey {
        case plateTypeID = "plateTypeId"
        case plateTypeNameAr, vehicleShapes, plateTypeNameEn
    }
    override func toDomain() -> PlateTypeWithShape? {
        return PlateTypeWithShape(plateTypeID: plateTypeID,
                                  plateTypeName: languageIsEnglish ? plateTypeNameEn : plateTypeNameAr,
                                  vehicleShapes: vehicleShapesToDomain())
    }
    func vehicleShapesToDomain() -> [VehicleShape]? {
        let vehicle: [VehicleShape] =  vehicleShapes?.map {
            $0.toDomain()
        } as? [VehicleShape] ?? []
        return vehicle
    }
}

class VehicleShapeDTO: DataModel, Codable {
    let nameAr: String?
    let id: Int?
    let nameEn: String?
    override func toDomain() -> VehicleShape? {
        return VehicleShape(name: languageIsEnglish ? nameEn : nameAr ,
                            id: id)
    }
}

class VehicleShape: DomainModel, Codable {
    let name: String?
    let id: Int?
    init(name: String?, id: Int?) {
        self.name = name
        self.id = id
    }
}
