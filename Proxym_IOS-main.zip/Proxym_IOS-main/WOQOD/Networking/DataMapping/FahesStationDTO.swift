//
//  FuelPriceDTO.swift
//  WOQOD
//
//  Created by rim ktari on 6/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//
import Foundation

public class FahesStationDTO: DataModel, Codable {
    public var workingDays: String?
    public var arabicWorkingDays: String?
    public var latitude: Double?
    public var title: String?
    public var titleArabic: String?
    public var firstAddress: String?
    public var arabicFirstAddress: String?
    public var secondAddress: String?
    public var arabicSecondAddress: String?
    public var lastSynchronisationDate: Int?
    public var areaId: Int?
    public var phone: String?
    public var id: Int?
    public var fahesId: Int?
    public var status: StationStatus?
    public var longitude: Double?
    public var icon: String?
    public var serviceStations: [ServiceStations]?
    var area: AreaDTO?

    override  func toDomain() -> FahesStation {

        let fuelPrice = FahesStation.init(workingDays: workingDays,
                                          workingDaysAR: arabicWorkingDays,
                                          title: title,
                                          titleAR: titleArabic,
                                          address: firstAddress,
                                          addressAR: arabicFirstAddress,
                                          secondAddress: secondAddress,
                                          secondAddressAR: arabicSecondAddress,
                                          lastSynchronisationDate: lastSynchronisationDate,
                                          areaId: areaId,
                                          phone: phone,
                                          id: id,
                                          fahesId: fahesId,
                                          status: status,
                                          latitude: latitude,
                                          longitude: longitude,
                                          icon: icon,
                                          area: area?.toDomain(),
                                          serviceStations: serviceStations
                                          )

        return fuelPrice
    }
}
