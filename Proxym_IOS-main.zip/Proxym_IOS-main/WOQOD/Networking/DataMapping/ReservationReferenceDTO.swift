//
//  ReservationReferenceDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 04/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class ReservationReferenceDTO: DataModel, Codable {

    let otpRetriesLeftCount: String?
    let plateTypeID, mobileNumber, customerID, vehicleShapeID: String?
    let plateNumber: String?
    let preReservationReferenceID: Int?

    enum CodingKeys: String, CodingKey {
        case otpRetriesLeftCount
        case plateTypeID = "plateTypeId"
        case mobileNumber
        case customerID = "customerId"
        case vehicleShapeID = "vehicleShapeId"
        case plateNumber
        case preReservationReferenceID = "preReservationReferenceId"
    }
    override func toDomain() -> ReservationReference? {
        return ReservationReference(referenceID: preReservationReferenceID)
    }
}
class ReservationReference: DomainModel {

    var referenceID: Int?
    init(referenceID: Int?) {
        self.referenceID = referenceID
    }
}
