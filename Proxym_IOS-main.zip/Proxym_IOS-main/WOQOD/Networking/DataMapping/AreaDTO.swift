//
//  AreaDTO.swift
//  WOQOD
//
//  Created by rim ktari on 12/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class AreaDTO: DataModel, Codable {
    var areaNameAr: String?
    var latitude: String?
    var id: Float?
    var areaNameEn: String?
    var longitude: String?
    var idArea: String?
    override func toDomain() -> Area? {
        return Area(id: id, title: areaNameEn, titleAR: areaNameAr,
                    longitude: longitude, latitude: latitude, idArea: idArea)
    }
}
