//
//  CarValidtyDTO.swift
//  WOQOD
//
//  Created by Bouthaina ghachem on 11/02/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
class CarValidtyDTO: DataModel, Codable {

    let canProceed: Bool?
    let messageEN: String?
    let messageAR: String?

    override func toDomain() -> CarValidity? {
        return CarValidity(canProceed: canProceed,
                           message: languageIsArabic ? messageAR: messageEN)
    }

    enum CodingKeys: String, CodingKey {
        case canProceed = "shouldGetUserConfirmationToProceed"
        case messageEN = "confirmationPromptEn"
        case messageAR = "confirmationPromptAr"
    }
}
