//
//  StaticScreenDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 13/07/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class StaticScreenDTO: DataModel, Codable {

    public var id: Int?
    public var textType: String?
    public var content: String?
    public var contentAR: String?
    override func toDomain() -> StaticScreenModel? {
        return StaticScreenModel.init(textType: textType, id: id,
                                      content: languageIsEnglish ?
                                        content : contentAR)
    }

}
