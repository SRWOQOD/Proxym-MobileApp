//
//  PaginatedNewsDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 22/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class PaginatedNewsDTO: DataModel, Codable {

    var size: Int?
    var count: Int?
    var page: Int?
    var result: [NewsDTO]?

    override func toDomain() -> PaginatedNews? {
        return PaginatedNews.init(size: size, count: count, page: page, result: newsToDomain())
    }

    func newsToDomain() -> [News]? {
        let news: [News] =  result?.map {
            $0.toDomain()
        } as? [News] ?? []
        return news
    }

}
