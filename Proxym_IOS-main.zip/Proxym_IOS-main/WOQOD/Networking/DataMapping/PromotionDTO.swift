//
//  PromotionDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class PromotionDTO: DataModel, Codable {

    public var image: String?
    public var endDate: Int64?
    public var link: String?
    public var title: String?
    public var lastSynchronisationDate: Int64?
    public var titleArabic: String?
    public var briefDescriptionArabic: String?
    public var id: Int?
    public var category: String?
    public var imageList: String?
    public var startDate: Int64?
    public var briefDescription: String?

    override func toDomain() -> Promotion? {
        return Promotion.init(image: image,
                              link: link,
                              title: languageIsEnglish ? title : titleArabic,
                              id: id,
                              imageList: imageList,
//                              startDate: startDate,
                              endDate: endDate,
                              briefDescription: languageIsEnglish ? briefDescription : briefDescriptionArabic)
    }
}
