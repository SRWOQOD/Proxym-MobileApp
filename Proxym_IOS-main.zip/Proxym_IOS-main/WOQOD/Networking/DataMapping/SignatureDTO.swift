//
//  SignatureDTO.swift
//  WOQOD
//
//  Created by rim ktari on 9/9/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class SignatureDTO: DataModel, Codable {

    public var isSuccessful: Bool?
    public var signature: String?

    override func toDomain() -> Signature? {
        return Signature(value: signature)
    }
}
