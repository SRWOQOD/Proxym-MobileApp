//
//  TopBannerInfoDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class TopBannerInfoDTO: DataModel, Codable {

    let fileTypeEnum: BannerFileType?
    let appRedirection: AppRedirectionType?
    let orderItem: Int?
    let active: Bool?
    let fileURL: String?
    let redirectionTypeEnum: BannerRedirectionPath?
    let id: Int?
    let redirectionPath: String?
    let redirectionArPath: String?
    let title: String?
    let creationDate: Int64?
    let redirection: Bool?
    let videoThumbnail: String?
    let titleArabic: String?
    let titleDisplayed: Bool?
    enum CodingKeys: String, CodingKey {
        case fileTypeEnum, appRedirection, orderItem, active, videoThumbnail
        case fileURL = "fileUrl"
        case redirectionTypeEnum, id, redirectionPath,
             title, creationDate, redirection, titleArabic, titleDisplayed
        case redirectionArPath = "redirectionArPath"
    }
    override func toDomain() -> TopBannerInfo? {
        return TopBannerInfo(imageURL: (fileTypeEnum == .image ? fileURL : videoThumbnail),
                             type: fileTypeEnum,
                             videoURL: (fileTypeEnum == .video ? fileURL : ""),
                             appRedirectionType: appRedirection,
                             orderItem: orderItem,
                             redirectionURL: languageIsEnglish ? redirectionPath : redirectionArPath,
                             redirectionTypeEnum: redirectionTypeEnum,
                             bannerTitle: languageIsArabic ? titleArabic : title,
                             shouldRedirect: redirection ?? false, titleDisplayed: titleDisplayed ?? false)
    }
}
public enum BannerFileType: String {
    case image = "IMG"
    case video = "VIDEO"
}

public enum BannerRedirectionPath: String {
    case app = "APP"
    case url = "URL"
}

extension BannerRedirectionPath: Codable {
    public init(from decoder: Decoder) throws {
        self = try BannerRedirectionPath(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .app
    }
}

extension BannerFileType: Codable {
    public init(from decoder: Decoder) throws {
        self = try BannerFileType(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .image
    }
}

extension AppRedirectionType: Codable {
    public init(from decoder: Decoder) throws {
        self = try AppRedirectionType(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .woqode
    }
}
public enum AppRedirectionType: String {
    case fahes = "FAHES"
    case fahesBookVehicle = "FAHES_BOOK_VEHICLE_INSPECTION"
    case fahesOnlinePayment = "FAHES_ONLINE_PAYMENT"
    case fahesCancelModifyBooking = "FAHES_CANCEL_MODIFY_BOOKING"
    case fahesStations = "FAHES_STATIONS"
    case aboutFahes = "ABOUT_FAHES"
    case fahesInspectionTips = "FAHES_INSPECTION_TIPS"
    case woqode = "WOQODE"
    case woqodeTopUp = "WOQODE_TOPUP"
    case aboutWoqode = "ABOUT_WOQODE"
    case shafaf = "SHAFAF"
    case shafafSupermarkets = "SHAFAF_SUPERMARKETS"
    case shafafRetails = "SHAFAF_RETAILERS"
    case aboutShafaf = "ABOUT_SHAFAF"
    case stockPrices = "APP_CONTENT_STOCK_PRICES"
    case location = "LOCATION"
    case news = "APP_CONTENT_NEWS"
    case tenders = "APP_CONTENT_TENDER"
    case bulkLPG = "APP_CONTENT_BULK_LPG"
    case promotion = "APP_CONTENT_PROMOTIONS"
    case aboutWoqod = "APP_ABOUT_WOQOD"
    case privacyPolicy = "APP_PRIVACY_POLICY"
    case termsOfUse = "APP_TERMS_OF_USE"
    case registration = "REGISTRATION"
    case feedback = "FEEDBACK"
}


