//
//  DateManager.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/8/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

func getDate(dateArray: [Float]?) -> Date? {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd-HH-mm-ss"
    dateFormatter.timeZone = TimeZone.current
    dateFormatter.locale = Language.english.local
    let dateStringArray = dateArray?.compactMap {"\(Int($0))"}
    if let dateString = dateStringArray?.joined(separator: "-") {
        let date = dateFormatter.date(from: dateString)
        return date
    }
    return nil
}

// Return date
func getCurrentDate() -> Date {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd-HH-mm-ss.SSSS"
    dateFormatter.timeZone = TimeZone.current
    dateFormatter.locale = Language.english.local
    let dateString = dateFormatter.string(from: Date())
    let date = dateFormatter.date(from: dateString)
    return date ?? Date()
}

// Return a string date
func getCurrentDateString(_ format: String? = "MMMM-yyyy") -> String? {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = format
    dateFormatter.timeZone = TimeZone.current
    dateFormatter.locale = Locale.init(identifier: Language.currentLanguage.rawValue)
    let dateString = dateFormatter.string(from: Date())
    return dateString
}

func getTimeInSeconds() -> Int {
    let calendar = Calendar.current
    let time = calendar.dateComponents([.hour, .minute, .second], from: Date())
    let hour = time.hour ?? 0
    let minute = time.minute ?? 0
    let seconds = time.second ?? 0
    let finalSec: Int = (hour * 3600) + minute*60 + seconds
    return finalSec
}

func convertMinFromSeconds(sec: Int) -> String {
    let minute = (sec % 3600) / 60
    let seconds = (sec % 3600) % 60
    return String(format: "%02d:%02d", minute, seconds)
}
