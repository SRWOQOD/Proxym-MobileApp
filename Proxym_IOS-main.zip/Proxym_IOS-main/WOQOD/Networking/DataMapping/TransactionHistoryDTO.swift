//
//  TransactionHistoryDTO.swift
//  WOQOD
//
//  Created by rim ktari on 11/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class TransactionHistoryDTO: DataModel, Codable {

    let customerCode, licensePlateNr, stationCode, rowOrder: String?
    let stationName, fleetName, customerORACLEID, total: String?
    let saleEnd: String?
    let recID, identifier, customerName, fleetCode: String?

    enum CodingKeys: String, CodingKey {
        case customerCode = "customerCode"
        case licensePlateNr = "licensePlateNr"
        case stationCode = "stationCode"
        case rowOrder
        case stationName = "stationName"
        case fleetName = "fleetName"
        case customerORACLEID = "customerORACLE_ID"
        case total = "total"
        case saleEnd = "saleEnd"
        case recID = "recID"
        case identifier = "id"
        case customerName = "customerName"
        case fleetCode = "fleetCode"
    }
    override func toDomain() -> TransactionHistory {
        return TransactionHistory(plateNumber: licensePlateNr,
                                  station: stationName,
                                  date: saleEnd,
                                  amount: getAmount())
    }

    func getAmount() -> String? {
        if let doubleValue = Double(total ?? "") {
            return String(format: "%.2f", doubleValue)
        } else {
            return "0"
        }
    }
}
