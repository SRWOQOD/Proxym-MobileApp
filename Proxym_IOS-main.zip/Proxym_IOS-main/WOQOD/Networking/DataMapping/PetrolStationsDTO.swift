//
//  PetrolStationsDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 11/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

// MARK: - PetrolStationsDTO
public class PetrolStationsDTO: DataModel, Codable {

    public var id: Int?
    public var stationId: Int?

    public var arabicCategory: String?
    public var category: String?

    public var petrolCategory: PetrolCategory?

    public var arabicName: String?
    public var title: String?

    // public var facilityStations: []
    public var lastSynchronisationDate: Double?

    public var latitude: String?
    public var longitude: String?

    public var phone: String?

    public var rating: Int?

    public var status: StationStatus?
    public var icon: String?
    public var isVisible: String?
    var area: AreaDTO?
    var serviceStations: [ServiceStations]?

    override func toDomain() -> PetrolStations? {
        return PetrolStations.init(id: id,
                                   stationId: stationId,
                                   category: languageIsEnglish ? category : arabicCategory,
                                   petrolCategory: petrolCategory,
                                   stationName: title,
                                   stationNameAR: arabicName,
                                   latitude: latitude,
                                   longitude: longitude,
                                   phone: phone,
                                   status: status,
                                   serviceStations: serviceStations,
                                   icon: icon,
                                   area: self.area?.toDomain(),
                                   isVisible: isVisible)
       }
}

public class ServiceStations: Codable {

    var arabicName: String?
    var name: String?
    var openingHour: String?
    var closingHour: String?
    var id: Int?
    var state: String?
    var status: String?
}
public enum StationStatus: String {
    case upcoming = "Upcoming"
    case inactive = "Inactive"
    case active = "Active"
    case underConstruction = "Under_Construction"
}

public enum PetrolCategory: String {
    case petrolStation = "WOQOD PS"
    case mobilePetrolStation = "WOQOD Mobile PS"
    case sidra = "Sidra"
    case marineStation = "Marine"
    case unknown
}

extension StationStatus: Codable {
    public init(from decoder: Decoder) throws {
        self = try StationStatus(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .inactive
    }
}

extension PetrolCategory: Codable {
    public init(from decoder: Decoder) throws {
        self = try PetrolCategory(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .unknown
    }
}
