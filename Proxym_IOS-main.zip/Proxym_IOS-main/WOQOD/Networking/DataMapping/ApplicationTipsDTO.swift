//
//  ApplicationTipsDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 07/10/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class ApplicationTipsDTO: DataModel, Codable {
    let orderItem: Int?
    let fileUrl: String?
    let id: Int?
    override func toDomain() -> ApplicationTips? {
        return ApplicationTips(orderItem: orderItem, fileUrl: fileUrl)
    }
}
