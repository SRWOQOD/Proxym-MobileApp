//
//  AppointmentDateDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 05/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class AppointmentDateDTO: DataModel, Codable {

    let appointmentDate: String?

    override func toDomain() -> AppointmentDate? {
        return AppointmentDate(date: appointmentDate?.getDate("yyyy-MM-dd'T'HH:mm:ss"))
    }
}
