//
//  Result.swift
//  WOQOD
//
//  Created by rim ktari on 6/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class ResultWS<T: Codable>: Codable {
    public var isSuccessful: Bool?
    public var header: Header?
    public var body: Body<T>?
}
