//
//  FuelPricesDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 02/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//
import Foundation

public class FuelPricesDTO: DataModel, Codable {

    let id: Int?
    let name: String?
    let arabicName: String?
    let price: Double?
    let petrolId: Int?
    let syncdate: Int?
    let date: Int?

    override func toDomain() -> FuelPrices? {

        return FuelPrices.init(id: id,
                               name: languageIsEnglish ? name: arabicName,
                               price: (price != nil) ? String(format: "%.2f", price!) : "",
                               petrolId: petrolId,
                               syncdate: syncdate,
                               type: getFuelPrices())
    }

    func getFuelPrices() -> FuelType? {
        if name == "Gasoline Super (95)" {
            return .gasolineSuper
        } else if name == "Gasoline Premium (91)" {
            return .gasolinePremium
        } else {
            return .diesel
        }
    }
}
