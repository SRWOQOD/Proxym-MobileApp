//
//  QPaymentModelDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 26/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation

class QPaymentModelDTO: DataModel, Codable {
    var api: String?
    var grb: String?
    var gtr: String?
    var qnb: String?
    var response: String?
    var responseAr: String?
    var upr: String?
    var utrs: String?
    var utrv: String?
    var barcode: String?
    var decision: PayementDecision?
    var exception: String?
    var receipt: String?
    var reference: String?
    var transactionUUID: String?

    override func toDomain() -> PaymentModel? {
        return PaymentModel(receipt: self.receipt, reference: self.reference)
    }
    override init() {}

    enum CodingKeys: String, CodingKey {
        case api = "API"
        case grb = "GPR"
        case gtr = "GTR"
        case qnb = "QNB"
        case response = "Response"
        case responseAr = "Response_AR"
        case upr = "UPR"
        case utrs = "UTRS"
        case utrv = "UTRV"
        case barcode, decision, exception, receipt, reference, transactionUUID
    }
}
class QPaymentModel: DomainModel {

    var receipt: String?
    var reference: String?

    init(receipt: String?, reference: String?) {
        self.receipt = receipt
        self.reference = reference
    }

}

//webview payement https://pgtest3.qcb.gov.qa/QPayOnePC/PaymentPayServlet
//webview payement https://pgtest3.qcb.gov.qa/QPayOnePC/ExternalPaymentAuthorizationServletSubmit
//https://mobileuat.woqod.com/uwoqodb2c/api/adapters/woqodetopup/qpay/success
