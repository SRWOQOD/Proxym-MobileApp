//
//  SlotDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 05/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class SlotDTO: DataModel, Codable {

    var hourFrom: Int?
    var hourTo: Int?
    var id: Int?
    var slotTimeEn: String?
    var slotTimeAr: String?

    override func toDomain() -> Slot? {
        return Slot(value: getFormattedTime(), identifier: id)
    }

    func getFormattedTime() -> String {
        return languageIsEnglish ? slotTimeEn ?? "" : slotTimeAr ?? ""
    }
}
