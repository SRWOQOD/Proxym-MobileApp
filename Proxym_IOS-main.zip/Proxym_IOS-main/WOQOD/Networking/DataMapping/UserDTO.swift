// MARK: - UserResult
struct UserResult: Codable {
    public var user: UserAttributes?
}

// MARK: - User Attributes
struct UserAttributes: Codable {
    public var attributes: UserDTO?
}
// MARK: - User
public class UserDTO: DataModel, Codable {

    public var firstName: String?
    public var lastName: String?
    public var mobileNumber: String?
    public var email: String?
    public var adress1Label: String?
    public var areaEn: String?
    public var areaAr: String?
    public var birthdate: Int64? // to timestamp
    public var income: Int?
    public var fleetName: String?
    public var unlockAccount: String?
    public var gender: String?
    public var contactType: String?
    public var type: String?
    public var username: String?
    public var preferedLanguage: String?
    public var qid: String?
    public var createdAt: Int64?// to timestamp
    public var id: Int?
    public var status: String?
    public var photo: String?
    public var poBox: String?
    public var isBiometricActivated: Bool?
    public var customIdentification: String?
    var area: AreaDTO?
    public var fullName: String? {
        if firstName != nil && lastName != nil {
            return firstName! + " " + lastName!
        }
        return ""
    }

    override func toDomain() -> User? {
        return User.init(id: id,
                         qid: qid?.from64ToString(),
                         userName: username,
                         email: email,
                         birthdate: birthdate,
                         mobileNumber: mobileNumber,
                         type: UserType(rawValue: type ?? ""),
                         contactType: ContactType(rawValue: type ?? ""),
                         firstName: firstName,
                         familyName: lastName,
                         fullName: fullName,
                         address: adress1Label,
                         income: income,
                         status: status,
                         createdAt: createdAt,
                         poBox: poBox,
                         unlockAccount: unlockAccount,
                         fleetName: fleetName,
                         gender: self.gender,
                         area: self.area?.toDomain(),
                         isBiometricActivated: isBiometricActivated,
                         customIdentification: customIdentification
        )
    }

}

struct  AuthFailure: Codable {
    public var failure: String?
}
