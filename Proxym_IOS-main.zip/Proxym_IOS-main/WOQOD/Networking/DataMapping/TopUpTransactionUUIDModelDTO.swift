//
//  TopUpTransactionUUIDModelDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 19/12/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

class TopUpTransactionModelDTO: DataModel, Codable {
    let transactionUUID: String?
    let transactionStatus: String?

    enum CodingKeys: String, CodingKey {
        case transactionUUID
        case transactionStatus

    }
    override func toDomain() -> TopUpTransactionModel? {
        return TopUpTransactionModel(
            uuid: transactionUUID,
            status: transactionStatus)
    }
}

class TopUpTransactionModel: DomainModel {

    var transactionUUID: String?
    var transactionStatus: TransactionStatus?

    init(uuid: String?, status: String?) {
        self.transactionUUID = uuid
        self.transactionStatus = TransactionStatus(rawValue: status ?? "")
    }
}
