//
//  FahesBookingDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 10/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class FahesBookingDTO: DataModel, Codable {

    let reservationID: Int?
    let plateTypeNameAr, plateTypeNameEn: String?
    let hourFrom, hourTo: Int?
    let slotTimeEn: String?
    let slotTimeAr: String?
    let appointmentDate: String?
    let customerID: String?
    let stationNameEn, stationNameAr: String?
    let vin, plateNumber: String?
    let mobileNumber: String?
    let canPayOnline: String?
    enum CodingKeys: String, CodingKey {
        case plateTypeNameAr, hourFrom
        case reservationID = "reservationId"
        case hourTo, mobileNumber, stationNameEn, canPayOnline
        case customerID = "customerId"
        case plateTypeNameEn, vin, plateNumber, appointmentDate, stationNameAr
        case slotTimeEn, slotTimeAr
    }

    override func toDomain() -> FahesBooking? {
        return FahesBooking(reservationID: reservationID,
                            plateTypeName: languageIsEnglish ? plateTypeNameEn
                                : plateTypeNameAr,
                            time: languageIsEnglish ? slotTimeEn : slotTimeAr,
                            date: getFormattedDate(date: appointmentDate),
                            customerID: customerID,
                            station: languageIsEnglish ? stationNameEn
                                : stationNameAr,
                            plateNumber: plateNumber, mobileNumber: mobileNumber,
                            pay: canPayOnline == "true")
    }

    func getFormattedTime() -> String {
        var fullTime = ""
        if hourFrom == hourTo {
            fullTime = "\(hourFrom ?? 0)" + ":00 - " + "\(hourFrom ?? 0):30"
        } else {
            fullTime = "\(hourFrom ?? 0)" + ":30 - " + "\(hourTo ?? 0):00"
        }
        return fullTime
    }
    func getFormattedDate(date: String?) -> String {
        let dateFormat = date?.getDate("yyyy-MM-dd'T'HH:mm:ss")

        return dateFormat?.getStringDate() ?? ""
    }
}

class FahesBookingResultDTO: DataModel, Codable {
    let licencePlate, mobileNumber, stationNameEn, licencePlateTypeID: String?
    let pid: String?
    let creationDate: Int64?
    let qid, hourFrom, reservationID, hourTo: String?
    let canPayOnline, vehicleShapeID, vin, userType: String?
    let appointmentDate, apiStatus, stationNameAr: String?
    let cancellationDate: Int64?
    let slotTimeEn: String?
    let slotTimeAr: String?
    let status: String?
    let plateTypeNameAr, plateTypeNameEn: String?

    enum CodingKeys: String, CodingKey {
        case licencePlate, mobileNumber, stationNameEn
        case licencePlateTypeID = "licencePlateTypeId"
        case pid, creationDate, qid, hourFrom
        case reservationID = "reservationId"
        case hourTo, canPayOnline
        case vehicleShapeID = "vehicleShapeId"
        case vin, userType, appointmentDate, apiStatus, stationNameAr,
             cancellationDate, status, plateTypeNameAr, plateTypeNameEn
        case slotTimeEn, slotTimeAr

    }
    func getFormattedTime() -> String {
        var fullTime = ""
        if hourFrom == hourTo {
            fullTime = "\(hourFrom ?? "0")" + ":00 - " + "\(hourFrom ?? "0"):30"
        } else {
            fullTime = "\(hourFrom ?? "0")" + ":30 - " + "\(hourTo ?? "0"):00"
        }
        return fullTime
    }
    func getFormattedDate(date: String?) -> String {
        let dateFormat = date?.getDate("yyyy-MM-dd'T'HH:mm:ss")

        return dateFormat?.getStringDate() ?? ""
    }
    override func toDomain() -> FahesBooking? {
        return FahesBooking(reservationID: Int(reservationID ?? "0"),
                            plateTypeName: languageIsEnglish ? plateTypeNameEn : plateTypeNameAr,
                            time: languageIsEnglish ? slotTimeEn : slotTimeAr,
                            date: getFormattedDate(date: appointmentDate),
                            customerID: qid, station: languageIsEnglish ?
                                stationNameEn : stationNameAr,
                            plateNumber: licencePlate,
                            mobileNumber: mobileNumber,
                            pay: canPayOnline == "true")
    }
}
