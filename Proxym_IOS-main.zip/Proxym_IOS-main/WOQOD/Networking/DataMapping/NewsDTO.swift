//
//  NewsDTO.swift
//  WOQOD
//
//  Created by montassar YAAKOUBI on 29/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class NewsDTO: DataModel, Codable {

    public var detailsPicture: String?
    public var link: String?
    public var listPicture: String?
    public var details: String?
    public var id: Int?
    public var title: String?
    public var creationDate: Int64?
    public var views: Int?
    public var titleArabic: String?
    public var detailsArabic: String?
    public var linkAr: String?

    override func toDomain() -> News? {
        return News.init(detailsPicture: detailsPicture,
                         link: languageIsEnglish ? link : linkAr,
                         listPicture: listPicture,
                         details: languageIsEnglish ? details : detailsArabic,
                         id: id,
                         title: languageIsEnglish ? title : titleArabic,
                         creationDate: creationDate,
                         views: views)
    }

}
