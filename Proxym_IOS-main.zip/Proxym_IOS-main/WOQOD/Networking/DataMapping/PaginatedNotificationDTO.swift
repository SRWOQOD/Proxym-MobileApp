//
//  PaginatedNotificationDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 28/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class PaginatedNotificationDTO: DataModel, Codable {

    var size: Int?
    var count: Int?
    var page: Int?
    var result: [NotificationDTO]?

    override func toDomain() -> PaginatedNotification? {
        return PaginatedNotification.init(size: size, count: count, page: page, result: notificationToDomain())
    }

    func notificationToDomain() -> [Notification]? {
        let notifications: [Notification] =  result?.map {
            $0.toDomain()
        } as? [Notification] ?? []
        return notifications
    }

}
