//
//  PaginatedTenderDTO.swift
//  WOQOD
//
//  Created by Bouabid Wassim on 17/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

class PaginatedTenderDTO: DataModel, Codable {

    var size: Int?
    var count: Int?
    var page: Int?
    var result: [TenderDTO]?

    override func toDomain() -> PaginatedTender? {
        return PaginatedTender.init(size: size, count: count, page: page, result: tendersToDomain())
    }

    func tendersToDomain() -> [Tender]? {
        let tenders: [Tender] =  result?.map {
            $0.toDomain()
        } as? [Tender] ?? []
        return tenders
    }
}
