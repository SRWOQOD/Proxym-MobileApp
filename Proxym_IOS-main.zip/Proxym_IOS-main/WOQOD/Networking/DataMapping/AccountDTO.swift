//
//  AccountDTO.swift
//  WOQOD
//
//  Created by rim ktari on 8/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum AccountResponseCode: String {
    case zero = "0"
    case one = "1"
}

// MARK: - Account
class AccountDTO: DataModel, Codable {
    let statusReason: String?
    let responseHeaders: ResponseHeaders?
    let isSuccessful: Bool?
    let responseTime, totalTime: Int?
    let warnings: [String]?
    let accountInquiry: AccountInquiry?
    let errors, info: [String]?
    let statusCode: Int?

    enum CodingKeys: String, CodingKey {
        case statusReason, responseHeaders, isSuccessful, responseTime, totalTime, warnings
        case accountInquiry = "AccountInquiry"
        case errors, info, statusCode
    }

    override func toDomain() -> Account? {

        return  Account(civilName: accountInquiry?.envelope?.body?.accountInquiryResponse?
                            .accountInquiryResult?.civilName,
                        balance: accountInquiry?.envelope?.body?.accountInquiryResponse?
                            .accountInquiryResult?.balance,
                        fleetID: String(accountInquiry?.envelope?.body?.accountInquiryResponse?
                                            .accountInquiryResult?.fleetID ?? 0),
                        userHasBalance:
                            (accountInquiry?.envelope?.body?.accountInquiryResponse?
                                .accountInquiryResult?.responseGeneral?.responseCode
                                == AccountResponseCode.one.rawValue)
        )
    }

}

// MARK: - Envelope
class AccountInquiry: Codable {
    let envelope: Envelope?

    enum CodingKeys: String, CodingKey {
        case envelope = "Envelope"
    }
}

// MARK: - Envelope
class Envelope: Codable {
    let empty: String? = nil
    let body: AccountBody?

    enum CodingKeys: String, CodingKey {
        case body = "Body"
    }
}

// MARK: - Body
class AccountBody: Codable {
    let accountInquiryResponse: AccountInquiryResponse?

    enum CodingKeys: String, CodingKey {
        case accountInquiryResponse = "AccountInquiryResponse"
    }
}

// MARK: - AccountInquiryResponse
class AccountInquiryResponse: Codable {
    let empty: String?
    let accountInquiryResult: AccountInquiryResult?

    enum CodingKeys: String, CodingKey {
        case empty = ""
        case accountInquiryResult = "AccountInquiryResult"
    }
}

// MARK: - AccountInquiryResult
class AccountInquiryResult: Codable {
    let fleetID: Int?
    let civilName: String?
    let responseGeneral: ResponseGeneral?
    let balance: String?

    enum CodingKeys: String, CodingKey {
        case fleetID = "FleetID"
        case civilName = "CivilName"
        case responseGeneral = "ResponseGeneral"
        case balance = "Balance"
    }
}

// MARK: - ResponseGeneral
struct ResponseGeneral: Codable {
    let responseCode, responseMessage: String?

    enum CodingKeys: String, CodingKey {
        case responseCode = "ResponseCode"
        case responseMessage = "ResponseMessage"
    }
}

// MARK: - ResponseHeaders
struct ResponseHeaders: Codable {
    let cacheControl, server, xASPNetVersion, contentLength: String?
    let date, contentType, xPoweredBy: String?

    enum CodingKeys: String, CodingKey {
        case cacheControl = "Cache-Control"
        case server = "Server"
        case xASPNetVersion = "X-AspNet-Version"
        case contentLength = "Content-Length"
        case date = "Date"
        case contentType = "Content-Type"
        case xPoweredBy = "X-Powered-By"
    }
}
