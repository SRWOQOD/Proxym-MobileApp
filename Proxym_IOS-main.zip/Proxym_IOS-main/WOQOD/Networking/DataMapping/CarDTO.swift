//
//  CarDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 04/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

// MARK: - CarDTO
public class CarDTO<T: Codable>: DataModel, Codable {

    public var owner: Owner?
    public var year: String?
    public var dueDate: String?
    public var active: Bool?
    public var creationDate: Int64?
    public var fuelLimit: String?
    public var plateType, manufacturer: CarInfoDTO<T>?
    public var transactionType: String?
    public var colour: CarInfoDTO<T>?
    public var ownerQid: String?
    public var ownerMobile, fuelType: String?
    public var registrationExpiresOn: String?
    public var vin: String?
    public var model: CarInfoDTO<T>?
    public var carId: Int?
    public var transactionLimit, plateNumber: String?
    public var fuelStatus: Bool?
    public var carPaperResource, errorAr, errorEn: String?
    public var vehicleOwner: CarInfoDTO<String>?

    enum CodingKeys: String, CodingKey {
        case plateNumber = "plate_number"
        case fuelLimit = "fuel_Limit"
        case plateType = "plate_type"
        case dueDate = "due_date"
        case registrationExpiresOn = "registration_expires_on"
        case errorEn = "error_en"
        case errorAr = "error_ar"
        case ownerQid = "owner_qid"
        case manufacturer
        case model = "model"
        case carId = "id"
        case vehicleOwner = "vehicle_owner"
        case vin, active, year, colour
    }

    override func toDomain() -> Car? {

        return Car.init(carId: carId ?? 0 ,
                        statusFuel: fuelStatus ?? false,
                        carTag: active ?? false,
                        modelName: modelNameSwitchLanguage ?? "",
                        plateNumber: plateNumber ?? "" ,
                        carPlateId: Int(plateType?.id as? String ?? "") ?? 1,
                        manufacturerName: manufacturerNameSwitchLanguage ?? "",
                        expirationDate: self.registrationExpiresOn,
                        ownerQid: ownerQid,
                        ownerFullname: self.ownerFullnameSwitchLanguage ?? "" ,
                        ownerEmail: owner?.email ?? "" ,
                        creationDate: self.creationDate,
                        plateType: (languageIsArabic ? self.plateType?.nameAr :  self.plateType?.nameEn) ?? ""
                        )
    }

    var modelNameSwitchLanguage: String? {
        return languageIsEnglish ? model?.nameEn
        : model?.nameAr == nil
        ? model?.nameEn : model?.nameAr
    }

    var ownerFullnameSwitchLanguage: String? {
        return languageIsEnglish ? vehicleOwner?.nameEn
        : vehicleOwner?.nameAr == nil
        ? vehicleOwner?.nameEn : vehicleOwner?.nameAr
    }

    var manufacturerNameSwitchLanguage: String? {
        return languageIsEnglish ? manufacturer?.nameEn : manufacturer?.nameAr == nil
            ? manufacturer?.nameEn : manufacturer?.nameAr
    }

    var ownerFullname: String {
        return (owner?.firstName ?? "") + (owner?.lastName ?? "")
    }

    // TO check
    func toFahesCarRequest(carDTO: CarDTO<String>?) -> FahesCarRequestModel? {
        return FahesCarRequestModel(ownerQid: carDTO?.owner?.qid,
                                    vin: carDTO?.vin,
                                    plateNumber: carDTO?.plateNumber,
                                    plateTypeId: Int(carDTO?.plateType?.id ?? "0"),
                                    plateTypeNameEn: carDTO?.plateType?.nameEn,
                                    plateTypeNameAr: carDTO?.plateType?.nameAr,
                                    manufactureId: Int(carDTO?.manufacturer?.id ?? "0"),
                                    manufactureNameEn: carDTO?.manufacturer?.nameEn,
                                    manufactureNameAr: carDTO?.manufacturer?.nameAr,
                                    modelId: Int(carDTO?.model?.id ?? "0"),
                                    modelNameEn: carDTO?.model?.nameEn,
                                    modelNameAr: carDTO?.model?.nameAr,
                                    colorId: Int(carDTO?.colour?.id ?? "0"),
                                    colorNameEn: carDTO?.colour?.nameEn,
                                    colorNameAr: carDTO?.colour?.nameAr,
                                    registrationExpiresOn: carDTO?.registrationExpiresOn,
                                    year: carDTO?.year,
                                    active: carDTO?.active)
    }

}

public class  CarInfoDTO<T: Codable>: Codable {

    public var intId: Int?
    public var id: T?
    public var nameAr, nameEn: String?
 //   public var carList: String? //inutile

    enum CodingKeys: String, CodingKey {
        case intId = "_id"
        case id = "id"
        case nameAr = "name_ar"
        case nameEn = "name_en"

    }

}

public class Owner: Codable {
    let type: String?
    let id: Int?
    let userName, qid, email, firstName: String?
    let lastName, mobileNumber, status: String?
    let createdAt, income: Int?
    let unlockAccount: String?
}
