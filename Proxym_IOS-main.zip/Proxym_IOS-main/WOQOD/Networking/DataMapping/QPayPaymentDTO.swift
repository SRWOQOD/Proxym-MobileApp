//
//  QPayPaymentDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 05/05/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
class QPayParamsResponseDTO: DataModel, Codable {
    let action: String?
    let amount: String?
    let lang: String?
    let merchantModuleSessionID: String?
    let pun: String?
    let paymentDescription: String?
    let quantity: String?
    let transactionRequestDate: String?
    let bankID: String?
    let currencyCode: String?
    let merchantID: String?
    let extraFields_f14: String?
    let secureHash: String?
    let redirectUrl: String?
    let referer: String?
    
    enum CodingKeys: String, CodingKey {
        case action = "Action"
        case amount = "Amount"
        case lang = "Lang"
        case merchantModuleSessionID = "MerchantModuleSessionID"
        case paymentDescription = "PaymentDescription"
        case pun = "PUN"
        case quantity = "Quantity"
        case transactionRequestDate = "TransactionRequestDate"
        case bankID = "BankID"
        case currencyCode = "CurrencyCode"
        case merchantID = "MerchantID"
        case extraFields_f14 = "ExtraFields_f14"
        case secureHash = "SecureHash"
        case redirectUrl = "PG_REDIRECT_URL"
        case referer = "referer"
    }
    
    override func toDomain() -> QPayParamsResponseModel? {
        return QPayParamsResponseModel.init(action: action, amount: amount,
                                             lang: lang,
                                             merchantModuleSessionID: merchantModuleSessionID,
                                             pun: pun, paymentDescription: paymentDescription,
                                             quantity: quantity,
                                             transactionRequestDate: transactionRequestDate,
                                             bankID: bankID, currencyCode: currencyCode,
                                             merchantID: merchantID,
                                             secureHash: secureHash,
                                             extraFields_f14: extraFields_f14,
                                             redirectUrl: redirectUrl,
                                             referer: referer)
        
    }
}
