//
//  NotificationDTO.swift
//  WOQOD
//
//  Created by rim ktari on 12/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class NotificationDTO: DataModel, Codable {

    var uniqueID: String?
    var notifID: Int?
    var descriptionEn: String?
    var descriptionAr: String?
    var status: Bool?
    var titleEn: String?
    var sendDate: Int64?
    var titleAr: String?
    var surveysResource: NotificationSurveyDTO?
    var type: String?
    var nid: String?
    var idFeedback: String?
    var tag: String?
    var isanswered: Bool?
    var isAll: String?

    enum CodingKeys: String, CodingKey {
        case notifID, status, titleEn, sendDate, surveysResource, type, nid
        case idFeedback, descriptionEn, descriptionAr, titleAr, isanswered, isAll
        case uniqueID = "id"
    }

    override func toDomain() -> Notification? {
        return Notification(title: languageIsEnglish ? titleEn : titleAr,
                            description: languageIsEnglish ? descriptionEn : descriptionAr,
                            sendDate: sendDate?.getDateTimeFromInt64(),
                            notificationSurvey: surveysResource?.toDomain(),
                            status: status, notifID: notifID,
                            notifType: type,
                            idFeedback: idFeedback,
                            isanswered: isanswered,
                            isAll: isAll,
                            uniqueID: uniqueID)
    }
}

class NotificationSurveyDTO: DataModel, Codable {

    let briefDescription, title: String?
    let briefArabicDescription, arabicTitle: String?
    let surveyQuestionResources: [SurveyQuestionResourceDTO]?
    let createdBy, resourceType: String?
    let id: Int?

    var options: [SurveyQuestionOptionsDTO]?
    override func toDomain() -> NotificationSurvey? {
        return NotificationSurvey(surveyID: id ?? 0,
                                  surveyQuestionsList: getSurveyQuestions(),
                                  description: Language.currentLanguage == .english ? briefDescription:
                                    briefArabicDescription == nil ? briefDescription: briefArabicDescription,
                                  title: Language.currentLanguage == .english ? title:
                                    arabicTitle == nil ? title : arabicTitle)

    }

    func getSurveyQuestions() -> [SurveyQuestion]? {

        return surveyQuestionResources?.map {
            SurveyQuestion(type: SurveyTypesEnum(rawValue: $0.typeQuestion ?? ""),
                           options: getSurveyQuestionDetails(options: $0.options),
                           title: Language.currentLanguage == .english
                            ? $0.title: $0.arabicTitle == nil ? $0.title :
                            $0.arabicTitle, questionId: $0.questionID, min: $0.min,
                           max: $0.max,
                           textLimit: $0.textLimit)
        }
    }

    func getSurveyQuestionDetails(options: [SurveyQuestionOptionsDTO]?) -> [SurveyQuestionOptions]? {
        return options?.map {
            SurveyQuestionOptions(option: Language.currentLanguage == .english ?
                                  $0.optionEn : $0.optionAr == nil ?
                                  $0.optionEn : $0.optionAr)
        }
    }
}

class SurveyQuestionResourceDTO: Codable {
    let questionID: Int?
    let title, arabicTitle, typeQuestion: String?
    let min: Float?
    let max: Float?
    let textLimit: Int?
    let options: [SurveyQuestionOptionsDTO]?

    enum CodingKeys: String, CodingKey {
        case questionID = "questionId"
        case title, arabicTitle, typeQuestion, options, min, max, textLimit
    }
}
class QuestionResponseResources: Codable {
    let questionId: Int?
    var responses: [String]?

    init(questionId: Int?, responses: [String]?) {
        self.questionId=questionId
        self.responses=responses
    }
}

class SurveyQuestionOptionsDTO: Codable {
    var optionEn: String?
    var optionAr: String?

    enum CodingKeys: String, CodingKey {
        case optionEn, optionAr
    }
}
