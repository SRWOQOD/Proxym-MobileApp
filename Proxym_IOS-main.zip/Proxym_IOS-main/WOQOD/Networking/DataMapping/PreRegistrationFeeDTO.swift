//
//  PreRegistrationFeeDTO.swift
//  WOQOD
//
//  Created by rim ktari on 9/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class PreRegistrationFeeDTO: DataModel, Codable {

    public var category: CategoryResponse?
    public var inspectionType: Int?
    public var inspectionCycleEndsOn: String?
    public var serviceCategory: String?

    enum CodingKeys: String, CodingKey {
        case inspectionType = "inspection_type"
        case inspectionCycleEndsOn = "inspection_cycle_ends_on"
        case serviceCategory = "service_category"
        case category = "category"

    }

    override func toDomain() -> PreRegistrationFee? {
        return PreRegistrationFee(totalAmount: category?.fee,
                                  name: languageIsEnglish ? category?.nameEn : category?.nameAr,
                                  serviceCategory: serviceCategory,
                                  categoryNameEn: category?.nameEn,
                                  categoryNameAr: category?.nameAr,
                                  categoryId: category?.id,
                                  categoryFee: category?.fee,
                                  inspectionType: inspectionType)
    }
}
class CategoryResponse: Codable {

    var id: Int?
    var nameEn: String?
    var nameAr: String?
    var fee: Float?

    enum CodingKeys: String, CodingKey {
        case nameEn = "name_en"
        case nameAr = "name_ar"
        case fee = "fee"
        case id = "id"
    }

}
