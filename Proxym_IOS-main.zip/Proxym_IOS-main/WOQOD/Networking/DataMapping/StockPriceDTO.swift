//
//  StockPriceDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 15/09/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class StockPriceDTO: DataModel, Codable {

    var dateStock: Int64?
    var last: String?
    var open: String?
    var high: String?
    var low: String?
    var volume: String?
    var previousClose: String?
    var change: String?
    var symbol: String?
    var marketCap: String?
    var noShares: String?
    var marketName: String?
    var ask: String?
    var changePercent: String?
    var bid: String?
    var isin: String?
    var currency: String?

    override func toDomain() -> StockPrice? {
        return StockPrice.init(date: dateStock?.getDateTimeFromInt64(),
                               symbol: symbol,
                               marketCap: marketCap,
                               last: Double(last ?? ""),
                               change: Double(change ?? ""),
                               noShares: noShares,
                               volume: Double(volume ?? ""),
                               previousClose: Double(previousClose ?? ""),
                               high: Double(high ?? ""),
                               marketName: marketName,
                               low: Double(low ?? ""),
                               ask: ask,
                               changePercent: Double(changePercent ?? ""),
                               currency: currency,
                               bid: bid,
                               open: Double(open ?? ""),
                               isin: isin)
    }
}

class StockPricesEurolandDTO: DataModel, Codable {

    var qatarFuel: QatarFuel?

    enum CodingKeys: String, CodingKey {
        case qatarFuel = "Qatar Fuel"
    }
}

class QatarFuel: DataModel, Codable {
    var currency: String?
    var bid: String?
    var ask: String?
    var change: String?
    var changePercent: String?
    var last: String?
    var high: String?
    var low: String?
    var volume: String?
   var previousClose: String?
    var date: String?
    var iSIN: String?
   var symbol: String?
    var marketName: String?
    var noShares: String?
   var marketCap: String?
    var open: String?

    enum CodingKeys: String, CodingKey {
        case currency = "Currency"
        case bid = "Bid"
        case ask = "Ask"
        case change = "Change"
        case changePercent = "ChangePercent"
        case last = "Last"
        case high = "High"
        case low = "Low"
        case volume = "Volume"
        case previousClose = "PreviousClose"
        case date = "Date"
        case iSIN = "ISIN"
        case symbol = "Symbol"
        case marketName = "MarketName"
        case noShares = "NoShares"
        case marketCap = "MarketCap"
        case open = "Open"

    }

}
