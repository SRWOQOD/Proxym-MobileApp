//
//  TransactionHistoryCustomerDTO.swift
//  WOQOD
//
//  Created by rim ktari on 11/12/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class TransactionHistoryCustomerDTO: DataModel, Codable {

    let groupName, customerCode, licensePlateNr, groupCode: String?
    let vehicleID, customerID, rowOrder, groupID: String?
    let fleetORACLEID, fleetName, customerORACLEID, fleetID: String?
    let id, customerName, fleetCode: String?

    enum CodingKeys: String, CodingKey {
        case groupName = "groupName"
        case customerCode = "customerCode"
        case licensePlateNr = "licensePlateNr"
        case groupCode = "groupCode"
        case vehicleID = "vehicleID"
        case customerID = "customerID"
        case rowOrder
        case groupID = "groupID"
        case fleetORACLEID = "fleetORACLE_ID"
        case fleetName = "fleetName"
        case customerORACLEID = "customerORACLE_ID"
        case fleetID = "fleetID"
        case id
        case customerName = "customerName"
        case fleetCode = "fleetCode"
    }
}
