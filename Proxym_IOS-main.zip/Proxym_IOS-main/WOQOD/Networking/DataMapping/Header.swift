//
//  Header.swift
//  WOQOD
//
//  Created by rim ktari on 6/23/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class Header: Codable {

    public var providerCode, headerDescription: String?
    public var description: String?
    public var providerDescription: String?

    public var title: String?
    public var titleEN: String?
    public var titleAR: String?
    public var errorId: String?
    public var key: String?

    public var errors: String?
    public var statusCode: String?

}
