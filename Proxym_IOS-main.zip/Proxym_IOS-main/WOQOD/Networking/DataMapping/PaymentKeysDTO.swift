//
//  PaymentKeysDTO.swift
//  WOQOD
//
//  Created by rim ktari on 11/25/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
class PaymentKeysDTO: DataModel, Codable {

    let secretKey: String?
    let profileID: String?
    let accessKey: String?

    enum CodingKeys: String, CodingKey {
        case secretKey = "secret_key"
        case profileID = "profile_id"
        case accessKey = "access_key"
    }
    override func toDomain() -> PaymentKeys? {
        return PaymentKeys(profileID: self.profileID, accessKey: self.accessKey, secretKey: secretKey)
    }
}
