//
//  InspectionDetailsDTO.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 13/11/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

public class InspectionDetailsDTO<T: Codable>: DataModel, Codable {
    let evaluation: EvaluationDTO
    let defectComment: DefectCommentDTO
    let location: LocationDTO
    let additionalComment: String
    let defectType: EvaluationDTO

    enum CodingKeys: String, CodingKey {
        case evaluation
        case defectComment = "defect_comment"
        case location
        case additionalComment = "additional_comment"
        case defectType = "defect_type"
    }

    override func toDomain() -> InspectionDetails? {

        return InspectionDetails.init(evaluation: evaluationToDomain(),
                                      defectComment: defectCommentToDomain(),
                                      location: locationToDomain(),
                                      additionalComment: additionalComment,
                                      defectType: defectTypeToDomain())
    }
    func evaluationToDomain() -> Evaluation? {
        evaluation.toDomain()
    }
    func locationToDomain() -> Location? {
        location.toDomain()
    }
    func defectTypeToDomain() -> Evaluation? {
        defectType.toDomain()
    }
    func defectCommentToDomain() -> DefectComment? {
        defectComment.toDomain()
    }
}
// MARK: - DefectComment
class DefectCommentDTO: DataModel, Codable {
    let code, nameAr: String
    let defectSub: LocationDTO
    let nameEn: String

    enum CodingKeys: String, CodingKey {
        case code
        case nameAr = "name_ar"
        case defectSub = "defect_sub"
        case nameEn = "name_en"
    }
    override func toDomain() -> DefectComment? {
        return DefectComment(code: code,
                             name: languageIsEnglish ? nameEn : nameAr,
                             defectSub: defectSubToDomain())
    }
    func defectSubToDomain() -> Location? {
        defectSub.toDomain()
    }
}

// MARK: - DefectSub
class LocationDTO: DataModel, Codable {
    let nameAr, nameEn: String

    enum CodingKeys: String, CodingKey {
        case nameAr = "name_ar"
        case nameEn = "name_en"
    }
    override func toDomain() -> Location? {
        return Location(name: languageIsEnglish ? nameEn : nameAr)
    }
}

// MARK: - DefectType
class EvaluationDTO: DataModel, Codable {
    let nameAr: String
    let id: Int
    let nameEn: String

    enum CodingKeys: String, CodingKey {
        case nameAr = "name_ar"
        case id
        case nameEn = "name_en"
    }
    override func toDomain() -> Evaluation? {
        return Evaluation(name: languageIsEnglish ? nameEn : nameAr ,
                            id: id)
    }
}

class Evaluation: DomainModel, Codable {
    let name: String?
    let id: Int?
    init(name: String?, id: Int?) {
        self.name = name
        self.id = id
    }
}

class Location: DomainModel, Codable {
    let name: String?
    init(name: String?) {
        self.name = name
    }
}

class DefectComment: DomainModel, Codable {
    let name: String?
    let code: String?
    let defectSub: Location?
    init(code: String?, name: String?, defectSub: Location?) {
        self.code = code
        self.name = name
        self.defectSub = defectSub
    }
}
