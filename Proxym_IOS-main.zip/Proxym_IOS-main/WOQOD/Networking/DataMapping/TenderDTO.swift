//
//  TenderDTO.swift
//  WOQOD
//
//  Created by rim ktari on 12/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
public class TenderDTO: DataModel, Codable {

    var id: Int?
    var srNo: String?
    var tenderNumber: String?
    var description: String?
    var collectionDate: Int64?
    var bond: String?
    var fee: String?
    var tenderFee: Bool?
    var category: String?
    var closingDate: Int64?
    var details: String?

    override func toDomain() -> Tender? {
        return Tender(id: id, serialNumber: srNo ,
                      tenderNumber: tenderNumber,
                      description: description, collectionDate: collectionDate?.getDateTimeFromInt64(),
                      bond: bond, fee: fee, category: category,
                      closingDate: closingDate?.getDateFromInt64(),
                      details: details)
    }
    enum CodingKeys: String, CodingKey {
      case id
      case collectionDate
      case tenderNumber
      case bond
      case details
      case closingDate
      case category
      case description
      case fee
      case srNo
    }

    init (id: Int?, collectionDate: Int64?, tenderNumber: String?, bond: String?, details: String?, closingDate: Int64?, category: String?, description: String?, fee: String?, srNo: String?) {
      self.id = id
      self.collectionDate = collectionDate
      self.tenderNumber = tenderNumber
      self.bond = bond
      self.details = details
      self.closingDate = closingDate
      self.category = category
      self.description = description
      self.fee = fee
      self.srNo = srNo
    }

    required public init(from decoder: Decoder) throws {
      let container = try decoder.container(keyedBy: CodingKeys.self)
      id = try container.decodeIfPresent(Int.self, forKey: .id)
      collectionDate = try container.decodeIfPresent(Int64.self, forKey: .collectionDate)
      tenderNumber = try container.decodeIfPresent(String.self, forKey: .tenderNumber)
      bond = try container.decodeIfPresent(String.self, forKey: .bond)
      details = try container.decodeIfPresent(String.self, forKey: .details)
      closingDate = try container.decodeIfPresent(Int64.self, forKey: .closingDate)
      category = try container.decodeIfPresent(String.self, forKey: .category)
        description = try container.decodeIfPresent(String.self, forKey: .description)
      fee = try container.decodeIfPresent(String.self, forKey: .fee)
      srNo = try container.decodeIfPresent(String.self, forKey: .srNo)
    }

}
