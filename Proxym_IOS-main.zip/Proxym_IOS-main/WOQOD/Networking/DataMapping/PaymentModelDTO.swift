//
//  PaymentModelDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 20/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation

enum PayementDecision: String {
    case accept = "ACCEPT"
    case cancel = "CANCEL"
    case inProgress = "INPROGRESS"
    case paid = "PAID"
    case unknown
}

class PaymentModelDTO: DataModel, Codable {

    var api: String?
    var grb: String?
    var gtr: String?
    var qnb: String?
    var response: String?
    var responseAr: String?
    var upr: String?
    var utrs: String?
    var utrv: String?
    var barcode: String?
    var decision: PayementDecision?
    var exception: String?
    var receipt: String?
    var reference: String?
    var transactionUUID: String?
    var amount: String?
    var pun: String?
    var status: String?
    var civilMobileNumber: String?
    var civilID: String?
    var balanceIncreaseValue: String?
    var transactionID: String?
    var responseDate: String?
    var statusMessage: String?

    override func toDomain() -> PaymentModel? {
        return PaymentModel(receipt: self.receipt, reference: self.reference)
    }
    override init() {}

    enum CodingKeys: String, CodingKey {
        case api = "API"
        case grb = "GPR"
        case gtr = "GTR"
        case qnb = "QNB"
        case response = "Response"
        case responseAr = "Response_AR"
        case upr = "UPR"
        case utrs = "UTRS"
        case utrv = "UTRV"
        case civilMobileNumber = "CivilMobileNumber"
        case civilID = "CivilID"
        case balanceIncreaseValue = "BalanceIncreaseValue"
        case transactionID = "TransactionID"
        case barcode, decision, exception
        case receipt, reference, transactionUUID
        case amount, pun, status, responseDate
        case statusMessage
    }
}
class PaymentModel: DomainModel {

    var receipt: String?
    var reference: String?
    var pun: String?
    var amount: String?
    var responseDate:String?
    var balanceIncreaseValue: String?
    
    init(receipt: String?, reference: String?) {
        self.receipt = receipt
        self.reference = reference
    }
    init(pun: String?, amount: String?, responseDate: String?, balanceIncreaseValue: String?){
        self.pun = pun
        self.amount = amount
        self.responseDate = responseDate
        self.balanceIncreaseValue = balanceIncreaseValue
    }

}

extension PayementDecision: Codable {
    public init(from decoder: Decoder) throws {
        self = try PayementDecision(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .unknown
    }
}
