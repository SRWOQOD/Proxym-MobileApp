//
//  InspectionDetailsDTO.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 18/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

public class InspectionsHistoryDTO<T: Codable>: DataModel, Codable {

    public var identifier: Int?
    public var error: String?
    public var inspectedOn: String?
    public var legalEvaluation: String?
    public var mileage: String?
    public var owner: UserDTO?
    public var station: InspectionStationModel?
    public var technicalEvaluation: String?
    public var vehicle: CarDTO<T>?

    enum CodingKeys: String, CodingKey {
        case error, mileage, owner
        case station, vehicle
        case legalEvaluation = "legal_evaluation"
        case technicalEvaluation = "technical_evaluation"
        case inspectedOn = "inspected_on"
        case identifier = "id"
    }
    override func toDomain() -> InspectionsHistory? {

        return InspectionsHistory.init(inspection: identifier,
                                      inspectionOn: inspectedOn,
                                      plateType: languageIsArabic ? vehicle?.plateType?.nameAr
                                        : vehicle?.plateType?.nameEn,
                                      legalEvaluation: legalEvaluation,
                                      technicalEvaluation: technicalEvaluation,
                                      plateNumber: vehicle?.plateNumber)

    }
}

public class InspectionStationModel: Codable {
    public var id: String?
    public var name: String?
}
