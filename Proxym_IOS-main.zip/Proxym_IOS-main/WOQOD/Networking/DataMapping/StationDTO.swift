//
//  StationDTO.swift
//  WOQOD
//
//  Created by rim.ktari on 04/08/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
class StationDTO: DataModel, Codable {
    let stationNameEn: String?
    let stationID: Int?
    let stationNameAr: String?

    enum CodingKeys: String, CodingKey {
        case stationNameEn
        case stationID = "stationId"
        case stationNameAr
    }
    override func toDomain() -> Station? {
        return Station(name: languageIsEnglish ? stationNameEn : stationNameAr ,
                       id: stationID)
    }
}
