//
//  NetworkParameters.swift
//  WOQOD
//
//  Created by rim ktari on 6/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//
import IBMMobileFirstPlatformFoundation

struct ServerParameters {
    let baseURL: String
    let authorization: String
    static let devParameters: ServerParameters = ServerParameters(
        baseURL: "https://mobileuat1.woqod.com/uwoqodb2c/api/adapters",
//        baseURL:"http://192.168.91.57:9080/mfp/api/adapters",
        authorization: "")
    static let uatParameters: ServerParameters = ServerParameters(
        baseURL: "https://mobileuat1.woqod.com/uwoqodb2c/api/adapters",
        authorization: "")
    static let prodParameters: ServerParameters = ServerParameters(
        baseURL: "https://mobileapp.woqod.com/newwoqod/api/adapters",
        authorization: "")
    
    static let supportParameters: ServerParameters = ServerParameters(
        baseURL: "https://mobileuat1.woqod.com/SWoqod/api/adapters",
        authorization: "")

    
    /// Headers of all the API requests
    static var  headers: [String: String]? = [
        HTTPHeaderFieldName.authorization.rawValue: HTTPHeaderFieldValue.authorizationValue.rawValue,
        HTTPHeaderFieldName.deviceId.rawValue: getDeviceId() ,
        HTTPHeaderFieldName.appVersion.rawValue: getAppVersion(),
        HTTPHeaderFieldName.deviceModel.rawValue: getDeviceType(),
        HTTPHeaderFieldName.deviceBrand.rawValue: "Apple",
        HTTPHeaderFieldName.deviceOS.rawValue: getDeviceOSName(),
        HTTPHeaderFieldName.deviceOSversion.rawValue: getDeviceOSVersion(),
        HTTPHeaderFieldName.deviceType.rawValue: getDeviceOSVersion(),
        HTTPHeaderFieldName.serverIpAddress.rawValue: "10.0.2.15" // Constant 
    ]
}
struct EndPoints {
    static let imageUrl = "/NewApiAdapter/users/getProfilePhoto"
    static let generateCustomPwd = "/NewApiAdapter/generateCustomPwd"
    static let bio = "/NewApiAdapter/bio"
    static let pinCode = "/NewApiAdapter/pincode"
    static let checkQidValidity = "/NewApiAdapter/register/checkQidValidity"
    static let manageCar = "/NewApiAdapter/car"
    static let users = "/NewApiAdapter/users"
    static let resetPass = "/NewApiAdapter/users/password"
    static let deleteCar = "/NewApiAdapter/users/cars/deleteCar"
    static let updatePhoto = "/NewApiAdapter/users/updatePhoto"
    static let updateEmail = "/NewApiAdapter/users/updateEmail"
    static let updatePhone = "/NewApiAdapter/users/updatePhoneNumber"
    static let checkCar = "/NewApiAdapter/car/checkCar"
    static let getMaxMin = "/NewApiAdapter/getMaxMin"
    static let createTransactionUUID = "/NewApiAdapter/createTransactionUUID"
    static let createTransactionPUN = "/NewApiAdapter/qpay/createTransaction"
    static let fuelPrices = "/NewApiAdapter/petrol/prices"
    static let signature = "/NewApiAdapter/signature2"
    static let getQpayParams = "/NewApiAdapter/getQpaySignatureParam"
    static let shafafRetailers = "/NewApiAdapter/retailers"
    static let shafafSupermarket = "/NewApiAdapter/supermarket"
    static let news = "/NewApiAdapter/news"
    static let newsViews = "/NewApiAdapter/news/view"
    static let promotions = "/NewApiAdapter/promotions"
    static let locations = "/NewApiAdapter/stations"
    static let getSignatureParam = "/NewApiAdapter/getSignatureParam"
    static let area = "/NewApiAdapter/area"
    static let sendPinCodeToUpdateEmail = "/NewApiAdapter/pincode/sendPinCodeToUpdateUserEMail"
    static let sendPinCodeToUpdatePhone = "/NewApiAdapter/pincode/sendPinCodeToUpdateUserPhone"
    static let hasNotif = "/NewApiAdapter/hasNotif"
    static let deleteUser = "/NewApiAdapter/users/deleteUser"
    static let rating = "/NewApiAdapter/feedback/addRating"
    static let date = "/NewApiAdapter/date"
    static let updateWoqodeUser = "/NewApiAdapter/updateWoqodeUser"
    static let isDebitCardPaymentHidden = "/NewApiAdapter/isDebitCardPaymentHidden"
}
// Reservation EndPoints
struct ReservationEndPoints {
    static let otpValidation = "/NewApiAdapter/reservation/otpValidation"
    static let availableByCustomer = "/NewApiAdapter/reservation/availableByCustomer"
    static let getPlateTypeWithShape = "/NewApiAdapter/reservation/getPlateTypeWithShape"
    static let getPreReservationReference = "/NewApiAdapter/reservation/getPreReservationReference"
    static let getAvailableStations = "/NewApiAdapter/reservation/getAvailableStations"
    static let getAppointmentDates = "/NewApiAdapter/reservation/getAppointmentDates"
    static let getSlots = "/NewApiAdapter/reservation/getSlots"
    static let reservation = "/NewApiAdapter/reservation/reservation"
    static let detailsByCustomer = "/NewApiAdapter/reservation/detailsByCustomer"
    static let detailsByGuest = "/NewApiAdapter/reservation/getDetails"
    static let rescheduling = "/NewApiAdapter/reservation/rescheduling"
    static let cancellation = "/NewApiAdapter/reservation/cancellation"
    static let isReservationHidden = "/NewApiAdapter/reservation/isReservationHidden"
    static let resendOtp = "/NewApiAdapter/reservation/resendOtp"
    static let payOnline = "/NewApiAdapter/reservation/canPayOnline"
    static let checkOwner = "/NewApiAdapter/reservation/vehiculeDetails"
    static let checkBookingValidity = "/NewApiAdapter/reservation/vehiculeRegistrationValidity"
}
// Home EndPoints
struct HomeEndPoints {
    static let topBanner = "/NewApiAdapter/home/topbanner"
    static let adsBanner = "/NewApiAdapter/home/adsbanner"
    static let business = "/NewApiAdapter/home/businessbanner"
    static let appTips = "/NewApiAdapter/home/apptips"
}
// Login EndPoints
struct LoginEndPoints {
    static let verifyCredentials = "/NewApiAdapter/login/verifyCredentials"
    static let sendPincode = "/NewApiAdapter/pincode/login/send"
    static let validatePinCode = "/NewApiAdapter/pincode/login/validatePinCode"
    static let logout = "/NewApiAdapter/logout"
}
// Feedback EndPoints
struct FeedBackEndPoints {
    static let newFeedback = "/NewApiAdapter/feedback/newFeedback"
    static let feedbacks = "/NewApiAdapter/feedback/lazyFeedbackHistory"
    static let getFeedbackbyid = "/NewApiAdapter/feedback/getFeedbackById"
}
// Notifications EndPoints
struct NotificationsEndPoints {
    static let notificationList = "/NewApiAdapter/notification/listByUsername"
    static let updateStatus = "/NewApiAdapter/notification/updateStatus"
    static let updateAll = "/NewApiAdapter/notification/updateAll"
    static let notificationListGuest = "/NewApiAdapter/notification/anonymous"
}
// Survey EndPoints
struct SurveyEndPoints {
    static let status = "/NewApiAdapter/surveys/getSurveyStatus"
    static let changeStatus = "/NewApiAdapter/surveys/changeStatus"
    static let surveysResponse = "/NewApiAdapter/surveys/surveysResponses"
}
// Register EndPoints
struct RegisterEndPoints {
    static let regiter = "/NewApiAdapter/register/register"
    static let checkUser = "/NewApiAdapter/users/checkUser"
    static let activate = "/NewApiAdapter/register/activate"
    static let resendPinCode = "/NewApiAdapter/register/sendpincode"
    static let recoverPassword = "/NewApiAdapter/register/recover"
    static let getRecoveryCode = "/NewApiAdapter/register/sendrecoverycode"
    static let checkRecoveryCode = "/NewApiAdapter/register/checkrecoverycode"
    static let checkQidAndMobileValidity = "/NewApiAdapter/register/checkQidAndMobileValidity"
}
// Pincode EndPoints
struct PincodeEndPoints {
    static let send = "/NewApiAdapter/pincode/send"
    static let validate = "/NewApiAdapter/pincode/validatePinCode"
}
// Fahes EndPoints
struct FahesEndPoints {
    static let stations = "/NewApiAdapter/fahesStations"
    static let listOfReceipts = "/NewApiAdapter/fahes/preRegistration/findByQid"
    static let listCars =  "/NewApiAdapter/fahes/listCars"
    static let inspectionHistory = "/NewApiAdapter/fahes/inspection/historyInspectionsByPlate"
    static let inspectionDetails = "/NewApiAdapter/fahes/inspection/detailInspection"
    static let checkCar = "/NewApiAdapter/fahes/checkCar"
    static let isOwner = "/NewApiAdapter/fahes/isOwner"
    static let inspectionFee = "/NewApiAdapter/fahes/inspection/fee"
    static let plateTypes = "/NewApiAdapter/fahes/platetypes"
    static let carsList = "/NewApiAdapter/fahes/listCars"
    static let sendPinCode = "/NewApiAdapter/fahes/sendPin"
    static let addCar = "/NewApiAdapter/fahes/addCar"
    static let createTransactionUUID = "/NewApiAdapter/fahes/prtransactionlog/creditcard/save"
    static let isOwnerAddCar = "/NewApiAdapter/fahes/isOwnerAddCar"
    static let updateTransactionUUID = "/NewApiAdapter/fahes/prtransactionlog/updateTransactionUUID"
    static let generateReceipt = "/NewApiAdapter/fahes/preregistration/generatePDF"
    static let sendReceiptByMail = "/NewApiAdapter/fahes/preRegistration/sendMail"
    static let freeCar = "/NewApiAdapter/fahes/prtransactionlog/free/save"
    static let deleteCar = "/NewApiAdapter/fahes/updateStatusCar"
    static let createQPayTransaction = "/NewApiAdapter/fahes/qpaytransaction/debitcard/save"
    static let cancelQPayTransaction = "/fahesregistration/qpay/cancelTransactionPost"
}
struct FingerPrintEndPoints {
    static let checkFingerPrint = "/NewApiAdapter/checkFingerPrint"
    static let addBioPin  = "/NewApiAdapter/addBioPin"
    static let generateCustomPwd = "/NewApiAdapter/generateCustomPwd"
    static let resetBioPin  = "/NewApiAdapter/resetBioPin"
    static let updateStatus = "/NewApiAdapter/bio/updateStatus"
}
struct RspEndPoints {
    static let balance = "/RspServices/BalanceInquiry"
    static let getAllSalesTransactions = "/RpsAdapterJava/getAllSalesTransactions"
    static let getSalesTransactions = "/RpsAdapterJava/getSaleTransactions" // notSales
    static let getCustomerByFleetName = "/RpsAdapterJava/getCustomerByFleetName"
    static let getTopupReceipt = "/NewApiAdapter/transactionLog/receipt"
    static let sendByMailReceipt = "/NewApiAdapter/transactionLog/sendMail"
    static let updateTransactionUUID = "/NewApiAdapter/updateTransactionUUID"
    static let cancelTransaction = "/woqodetopup/updatePun"
}
struct StaticScreensEndPoints {
    static let staticScreen = "/NewApiAdapter/getStaticText"
}
struct StockPricesEndPoints {
    static let stockPrices = "/NewApiAdapter/stockPrices"
}

struct TendersEndPoints {
    static let tenders = "/NewApiAdapter/tenders/tenders"
}

struct SecurityCheck {
    static let  name = "UserLogin"
}
struct PaymentParameterKey {
    static let accessKey = "access_key"
    static let profileId = "profile_id"
    static let transactionUuid = "transaction_uuid"
    static let signedFieldNames = "signed_field_names"
    static let unsignedFieldNames = "unsigned_field_names"
    static let signedDateTime = "signed_date_time"
    static let locale = "locale"
    static let transactionType = "transaction_type"
    static let referenceNumber = "reference_number"
    static let amount = "amount"
    static let currency = "currency"
    static let merchantDefinedData1 = "merchant_defined_data1"
    static let merchantDefinedData2 = "merchant_defined_data2"
    static let billToForename = "bill_to_forename"
    static let billToSurname = "bill_to_surname"
    static let billToEmail  = "bill_to_email"
    static let billToAddressLine1  = "bill_to_address_line1"
    static let billToAddressState = "bill_to_address_state"
    static let billToAddressCity = "bill_to_address_city"
    static let billToAddressPostalCode    = "bill_to_address_postal_code"
    static let params = "params"
    static let sourceType = "sourceType"
    static let secretKey = "secretKey"
    static let name = "name"
    static let action = "action"
    static let qpayAmount = "amount"
    static let lang = "lang"
    static let merchantModuleSessionID  = "merchantModuleSessionID"
    static let pun  = "pun"
    static let paymentDescription = "PaymentDescription"
    static let transactionRequestDate = "transactionRequestDate"
    static let quantity = "quantity"

}
struct FahesAPIParameterKey {
    static let qid = "qid"
    static let plateNumber = "plate_number"
    static let plateTypeId = "plate_type_id"
    static let number = "number"
    static let username = "username"
    static let language = "language"
    static let ownerQid = "owner_id"
    static let userID = "userID"
    static let mobile = "mobile"
    static let mobileNumber = "mobileNumber"
    static let email = "email"
    static let amount = "amount"
    static let inspectionType = "inspection_type"
    static let serviceCategory = "service_category"
    static let categoryId = "category_id"
    static let categoryNameEn = "category_name_en"
    static let categoryNameAr = "category_name_ar"
    static let categoryFee = "category_fee"
    static let plateType = "plate_type"
    static let referenceNumber = "referenceNumber"
    static let anonym = "anonym"
    static let transactionUUID = "transactionUUID"
    static let currency = "currency"
    static let statusEnum = "status"
    static let receiptReference = "reference_number"
    static let isConnected = "connected"
    static let inspectionId = "inspection_id"
    static let pun = "pun"

}
struct LoginAPIParameterKey {
    static let password = "password"
    static let deviceId = "deviceId"
    static let deviceType = "deviceType"
    static let userName = "userName"
    static let pinCode = "pinCode"
    static let pincode = "pincode"
    static let bioPin = "bioPin"
    static let type = "type"
    static let username = "username"
}
struct NotificationAPIParameterKey {
    static let idnotif = "idnotif"
    static let page="page"
    static let size="size"
    static let device = "device"
    static let connected = "connected"
    static let deviceid = "deviceid"
    static let uniqueid = "uniqueId"
}
struct BioAPIParameterKey {
    static let bioPin = "bioPin"
    static let customPwd = "customPwd"
    static let deviceId = "deviceId"
    static let username = "username"
    static let pinCode = "pinCode"
}

struct PinCodeAPIParameterKey {
    static let username = "username"
    static let language = "language"
    static let pinCode = "pincode"
    static let bioStatus = "biostatus"
}
struct CarAPIParameterKey {
    static let qid = "qid"
    static let plateNumber = "plate_number"
    static let plateTypeId = "plate_type_id"
}
struct TopUpParameterKey {
    static let qid = "qid"
    static let amount = "amount"
    static let userID = "userID"
    static let currency = "currency"
    static let email = "email"
    static let mobile = "mobile"
    static let transactionStatus = "transactionStatus"
    static let statusEnum = "statusEnum"
    static let plateNumber = "plateNumber"
    static let plateNumbersStr = "plateNumbersStr"
    static let transactionUUID = "transactionUUID"
    static let referenceNumber = "reference_number"
    static let isConnected = "connected"
    static let isWoqode = "isWoqode"
    static let pun = "pun"
    static let statusCode = "statusCode"
    static let statusMessage = "statusMessage"
}
struct NewsParameterKey {
    static let id = "id"
}
struct UserParameterKey {
    static let qid = "qid"
    static let id = "id"
    static let username = "username"
    static let email = "email"
    static let birthdate = "birthdate"
    static let mobileNumber = "mobileNumber"
    static let number = "number"
    static let type = "type"
    static let contactType = "contactType"
    static let password = "password"
    static let recoveredPassword = "newpassword"
    static let firstName = "firstName"
    static let lastName = "lastName"
    static let income = "income"
    static let adress1Label = "adress1Label"
    static let createdAt = "createdAt"
    static let status = "status"
    static let poBox = "poBox"
    static let language = "language"
    static let areaEn = "areaEn"
    static let photo = "photo"
    static let unlockAccount = "unlockAccount"
    static let fleetName = "fleetName"
    static let phone = "phone"
    static let pincode = "pincode"
    static let pinCode = "pinCode"
    static let deviceSerial = "deviceSerial"
    static let gender = "gender"
    static let idArea = "idArea"
}
struct FeedbackAPIParameterKey {
    static let username = "username"
    static let userName = "userName"
    static let name =  "name"
    static let connected =  "connected"
    static let id = "id"
    static let sector = "sector"
    static let category = "category"
    static let contactNumber = "contactNumber"
    static let content = "content"
    static let creationDate = "creationDate"
    static let email =  "email"
    static let file = "file"
    static let status = "status"
    static let language = "language"
}
struct ReservationAPIParameterKey {
    static let mobileNumber = "mobileNumber"
    static let plateNumber = "plateNumber"
    static let plateTypeId = "plateTypeId"
    static let vehicleShapeId = "vehicleShapeId"
    static let vehicleShapeName = "vehiculeShapeName"
    static let customerId = "customerId"
    static let referenceId = "preReservationReferenceId"
    static let stationId = "stationId"
    static let otp = "otp"
    static let date = "date"
    static let slotId = "slotId"
    static let userType = "userType"
    static let reservationId = "reservationId"
}
struct SurveyAPIParameterKey {
    static let surveyId = "surveyId"
    static let questionResponseResources = "questionResponseResources"
}
struct ManageCarParameterKey {
    static let qid = "qid"
    static let carId = "id"
    static let carFuelStatus = "status"
}
struct RatingParameterKey {
    static let deviceID = "deviceId"
    static let stationId = "stationId"
    static let rating = "rating"
}
enum HTTPHeaderFieldName: String {
    case authorization = "Authorization"
    case deviceId = "deviceId"
    case appVersion = "appVersion"
    case deviceModel = "deviceModel"
    case deviceType = "deviceType"
    case serverIpAddress = "serverIpAddress"
    case deviceBrand = "deviceBrand"
    case deviceOS = "deviceOS"
    case deviceOSversion = "deviceOSversion"
    case contentType = "Content-Type"
    case ipAddress = "ipAddress"
}
enum HTTPHeaderFieldValue: String {
    case authorizationValue = "Basic d29xb2Q6d29xb2Q="
}
struct PagingParameterKey {
    static let size = "size"
    static let page = "page"
}
// The content type (JSON)
enum ContentType: String {
    case json = "application/json"
    case data = "multipart/form-data"
    case url =  "application/x-www-form-urlencoded"
}
