//
//  APIClient.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 6/29/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

class ApiClient: NSObject {

    class func baseURL() -> String {
        return self.serverParameters().baseURL
    }

    class func authorization() -> String {
        return self.serverParameters().authorization
    }

    fileprivate class func serverParameters() -> ServerParameters {

        #if WOQOD_ENV_DEV
        return ServerParameters.devParameters

        #elseif WOQOD_ENV_UAT
        return ServerParameters.uatParameters

        #elseif WOQOD_ENV_PROD
        return ServerParameters.prodParameters

        #elseif WOQOD_ENV_SUPPORT
        return ServerParameters.supportParameters

        #else
        fatalError("The environment is not specified")
        #endif
    }

}
