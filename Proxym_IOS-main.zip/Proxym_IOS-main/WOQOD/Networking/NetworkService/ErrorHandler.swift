//
//  ErrorHandler.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

enum ErrorCode: String {

    /*General errors*/
    case tryAgainError = "100"
    case dataNotAvailableError = "101"
    case saveFailedError = "116"
    case updateFailedError = "117"
    case operationNotAllowedError = "104"
    case operationUnsupportedError = "124"
    case tryRefreshError = "110"
    case tryLaterError = "111"
    case tryNewInputError = "102"
    case invalidInputError = "103"
    case gatewayWrongError = "136"
    case moiFailedError = "107"
    case woqodeFailedError = "108"
    case statusUnknownError = "135"
    case genericError = "500"
    case serverError = "-1"
    case noInternet = "0"
    case timoutRequest = "-1001"
    case oauthCanceled = "-999"

    /*Errors related to rate*/
    case rateFailedUserNotRegistredError = "120"
    case ratingIsOnceADayError = "105"

    /*Errors related to pinCode*/
    case pinCodeExpiredError = "106"
    case pinCodeWrongError = "118"

    /*Errors related to QID*/
    case qidInvalidConbinationWithMobileNumberError = "112"
    case qidAlreadyExistsError = "137"
    case qidNotValidError = "138"

    /*Errors related to User*/
    case usernameAlreadyExistError = "109"
    case usernameOrPasswordWrongError = "125"
    case userNotApprovedError = "119"
    case userBlocked = "400"

    /*Errors related to Mobile Number*/
    case mobileNumberNotFindInOoreedoError = "113"
    case mobileNumbeNotActiveError = "114"
    case mobileNumbeNotRegistredError = "115"

    /*Errors related to ID*/
    case idCheckPresenceError = "121"
    case idNotPresentError = "122"

    /*Errors related to password*/
    case passwordTooShortError = "126"
    case passwordAlreadySetBeforeError = "127"
    case passwordChangedRecentleyError = "128"
    case passwordTooWeakError = "129"
    case passwordMustBeResetError = "130"

   /*Errors related to LDAP*/
   case ldapWrongError  = "131"
   case ldapWronggError = "132"
   case ldapWrongggError = "133"

    case userPendingError = "155"

    /*Errors related to FingerPrint*/  // To FIX NAMES
    /**
     * error code returned when finger print is not set up
     * Biometric login is not yet applied for this device , please log in and activate it from settings
     */
    case fingerPrintDisabledError = "171"
    /**
     * error returned when finger print is already set up in another device
     * The current device which id 'null' is already enabled for Biometric login.
     * To initiate a new Biometric registration, please contact the call-center
     */
    case fingerPrintEnabledInAnotherDeviceError = "170"

    init(fromRawValue: String) {
        self = ErrorCode(rawValue: fromRawValue) ?? .fingerPrintDisabledError
    }
}
