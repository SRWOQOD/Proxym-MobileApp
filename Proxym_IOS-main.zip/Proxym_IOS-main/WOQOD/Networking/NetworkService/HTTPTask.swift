//
//  HTTPTask.swift
//  WOQOD
//
//  Created by rim ktari on 6/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
import Combine

let successCode = "000"

public class HTTPTask {

    class func request<T: Codable, T1>( endPointType: EndPointType  ) -> Future<((T, T1)), Error> {

        // this is added because session expiration not handled from backend
        var getResponseFromServer = false

        return Future {  promise in
            /// TO DO: If response header returns cache-Control, Remove removeAllCachedResponses
            URLCache.shared.removeAllCachedResponses()
            let request = WLResourceRequest(url: URL(string: endPointType.url), method: endPointType.method)
            request?.timeoutInterval = 30

            // Set Headers
            endPointType.additionalHeader?.forEach({
                request?.addHeaderValue($0.value as NSObject, forName: $0.key)
            })
            
            let parameters = encryptQidParam(parameters: endPointType.parameters)
            
            #if DEBUG
            print("url", endPointType.url)
            print("parameters", parameters)
            #endif

            // check for sessionExpiration : this is added because session expiration not handled on MFP adapter
            DispatchQueue.main.asyncAfter(deadline: .now() + 50.0) {
                // your code here
                if !getResponseFromServer && AuthManager.shared.currentUser != nil {
                    showSessionExpiredAlert()
                    return
                }
            }

            // check for internet connexion
            if Reachability.reachabilityForInternetConnection() {
                request?.send(withFormParameters: parameters.flattenValues(),
                              completionHandler: { (response, error) in
                    if let errorResponse = error as? NSError {
                        #if DEBUG
                        print("error web service", errorResponse.description)
                        #endif
                        getResponseFromServer = true
                        if errorResponse.code.description ==
                            ErrorCode.timoutRequest.rawValue  &&
                            endPointType.shouldShowErrorAlerts {
                            showTimeoutAlert()
                        } else
                        // on challange cancel we already showed a popup expiration session
                        // no need for server error popup
                        // this is added because session expiration not handled on MFP adapter
                        if errorResponse.code.description !=
                            ErrorCode.oauthCanceled.rawValue  &&
                            endPointType.shouldShowErrorAlerts {
                            showNoServerAccessAlert()
                        }
                        if endPointType.shouldSendFailure {
                            promise(.failure(errorResponse))
                        }
                        return

                    } else {
                        do {
                            print(response?.responseText)
                            let result: Result<T, Error>  =
                            JSONDecoder().decodeResponse(from: response?.responseData, error: error)

                            switch result {

                            case .success(let result):
                                getResponseFromServer = true
                                promise(.success(getConvertedResult(object: result)))

                            case .failure(let error):
                                getResponseFromServer = true
                                promise(.failure(error))
                            }
                        }
                    }
                })
            } else {
                showNoInternetConnectionAlert()
                getResponseFromServer = true
                return
            }
        }
    }
    // TO BE CORRECTED
    class func request2<T: Codable, T1>( endPointType: EndPointType  ) -> Future<((T, T1)), Error> {

        // this is added because session expiration not handled from backend
        var getResponseFromServer = false

        return Future {  promise in

            let request = WLResourceRequest(url: URL(string: endPointType.url), method: endPointType.method)
            request?.timeoutInterval = 30

            // Set Headers
            endPointType.additionalHeader?.forEach({
                request?.addHeaderValue($0.value as NSObject, forName: $0.key)
            })
            
            let parameters = encryptQidParam(parameters: endPointType.parameters)

            #if DEBUG
            print("url", endPointType.url)
            print("parameters", parameters)
            #endif

            // check for sessionExpiration : this is added because session expiration not handled on MFP adapter
            DispatchQueue.main.asyncAfter(deadline: .now() + 50.0) {
                // your code here
                if !getResponseFromServer && AuthManager.shared.currentUser != nil {
                    showSessionExpiredAlert()
                    return
                }
            }

            if Reachability.reachabilityForInternetConnection() {
                request?.queryParameters = parameters
                request?.send(completionHandler: { (response, error) in

                    if let errorResponse = error as? NSError {
                    #if DEBUG
                    print("error web service", errorResponse.description)
                    #endif
                        getResponseFromServer = true
                        if errorResponse.code.description ==
                            ErrorCode.timoutRequest.rawValue  &&
                            endPointType.shouldShowErrorAlerts {
                            showTimeoutAlert()
                        } else
                        // on challange cancel we already showed a popup expiration session
                        // no need for server error popup
                        // this is added because session expiration not handled on MFP adapter
                        if errorResponse.code.description !=
                            ErrorCode.oauthCanceled.rawValue  &&
                            endPointType.shouldShowErrorAlerts {
                            showNoServerAccessAlert()
                        }
                        return

                    } else {
                        do {
                            let result: Result<T, Error>  = JSONDecoder()
                                .decodeResponse(from: response?.responseData, error: error)

                            switch result {

                            case .success(let result):
                                getResponseFromServer = true
                                promise(.success(getConvertedResult(object: result)))

                            case .failure(let error):
                                getResponseFromServer = true
                                promise(.failure(error))
                            }
                        }
                    }
                })
            } else {
                showNoInternetConnectionAlert()
                getResponseFromServer = true
                return
            }
        }
    }

    class func getConvertedResult<T: Codable, T1>(object: T) -> (T, T1) {

        if let arr = (object.self as? [DataModel]) {

            var arrayConverted: [DomainModel] = []

            arr.forEach { (element) in
                if let converted = (element.toDomain()) {
                    arrayConverted.append(converted)
                }
            }
            return (object, arrayConverted as! T1 )
        } else {
            if let _ = object.dictionary {
                let dataModel = (object.self as! DataModel)
                let domainModel = dataModel.toDomain()
                return (object, domainModel as! T1)
            } else {
                return (object, object as! T1)
            }
        }
    }
}

// MARK: - JSONDecoder Extension
extension JSONDecoder {

    func decodeResponse<T: Codable>(from responseData: Data?, error: Error?) -> Result<T, Error> {

        guard let responseData = responseData, error == nil else {
            return  .failure(error!)
        }

        return self.parseData(data: responseData, error: error)
    }

    func parseData<T: Codable>(data: Data, error: Error?) -> Result<T, Error> {
        do {

            // The generic item represents the centralized result from WQ
            let genericItem =  try self.decode(ResultWS<T>.self, from: data)

            if let result = genericItem.body?.result {
                return .success(result)

            } else if let header = genericItem.header {

                return
                    .failure(WQError(message: (languageIsEnglish ? header.titleEN : header.titleAR )
                                        ?? LocalizableShared.errorServerMessage.localized,
                                     statusCode: header.statusCode, errorId: header.errorId))

            } else {
                // SomeTimes the result structure of the WS is not the same
                // We added the specific item to decode it
                // for example : signature
                let specificItem =  try self.decode(T.self, from: data)

                return .success(specificItem)
            }

        } catch {
            return .failure(error)
        }
    }
}

private func showNoInternetConnectionAlert() {
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
        if let topViewController =  UIApplication.topViewController() {
            topViewController.showErrorAlertView(descriptionMessage:
                                                LocalizableShared.errorNetwork.localized, didConfirm: {
                hideActivityIndicator()
            })
        }
    }
}

private func showNoServerAccessAlert() {
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
        if let topViewController =  UIApplication.topViewController() {
            topViewController.showErrorAlertView(descriptionMessage:
                                                    LocalizableShared.errorServerMessage.localized, didConfirm: {
                hideActivityIndicator()
            })
        }
    }
}

private func showTimeoutAlert() {
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
        if let topViewController =  UIApplication.topViewController() {
            topViewController.showErrorAlertView(descriptionMessage:
                                                    LocalizableShared.errorUnexpectedMessage.localized,
                                                didConfirm: {
                hideActivityIndicator()
            })
        }
    }
}

private func showSessionExpiredAlert() {
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
        if let topViewController =  UIApplication.topViewController() {
            topViewController.showErrorAlertView(descriptionMessage:
                                                LocalizableShared.errorSessionExpired.localized,
                                                 didConfirm: {
                AppRouter.shared.updateViewsAfterSessionExpired()
                hideActivityIndicator()
            })
        }
    }
}

private func encryptQidParam(parameters: [String: Any?]) -> [String: Any?]  {
 
    let key = FahesAPIParameterKey.qid
    var encryptedQidParameters = parameters
    if parameters.keys.contains(key) {
        encryptedQidParameters.updateValue((encryptedQidParameters[key] as? String)?.toBase64(), forKey:key)
    }
    return encryptedQidParameters
}
