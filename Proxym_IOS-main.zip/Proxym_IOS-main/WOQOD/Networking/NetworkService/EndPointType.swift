//
//  EndPointType.swift
//  WOQOD
//
//  Created by rim ktari on 6/24/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//
import UIKit
import Foundation

protocol  EndPointType {

    var url: String { get}

    var method: String { get}

    var parameters: [String: Any?] {get}

    var additionalHeader: [String: String]? {get}

    var shouldShowErrorAlerts: Bool { get }
    
    var shouldSendFailure: Bool { get }

}
extension EndPointType {

    var additionalHeader: [String: String]? {
        return ServerParameters.headers

    }

    var shouldShowErrorAlerts: Bool {
        return true
    }
    
    var shouldSendFailure: Bool {
        return false
    }
}
