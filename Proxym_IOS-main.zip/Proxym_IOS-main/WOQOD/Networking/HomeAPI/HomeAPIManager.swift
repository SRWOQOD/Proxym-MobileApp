//
//  HomeAPIManager.swift
//  WOQOD
//
//  Created by rim.ktari on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import Combine
class HomeAPIManager {

    class func getTopBannerInfo() -> Future<(([TopBannerInfoDTO], [TopBannerInfo])), Error> {
        let result: Future<(([TopBannerInfoDTO], [TopBannerInfo])), Error> =
            HTTPTask.request(endPointType: HomeEndPoint.getTopBanner)
        return result
    }

    class func getADsBanner() -> Future<(([AdsBannerInfoDTO], [AdsBannerInfo])), Error> {
        let adsResult: Future<(([AdsBannerInfoDTO], [AdsBannerInfo])), Error> =
            HTTPTask.request(endPointType: HomeEndPoint.getADsBanner)
        return adsResult
    }
    class func getBusinessBanner() -> Future<(([BusinessWoqodDTO], [BusinessWoqod])), Error> {
        let businessResult: Future<(([BusinessWoqodDTO], [BusinessWoqod])), Error> =
            HTTPTask.request(endPointType: HomeEndPoint.getBusinessBanner)
        return businessResult
    }
    class func getApplicationTips() -> Future<(([ApplicationTipsDTO], [ApplicationTips])), Error> {
        let appTipsResult: Future<(([ApplicationTipsDTO], [ApplicationTips])), Error> =
            HTTPTask.request(endPointType: HomeEndPoint.getAppTips)
        return appTipsResult
    }
}
