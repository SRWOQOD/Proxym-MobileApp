//
//  HomeEndPoint.swift
//  WOQOD
//
//  Created by rim.ktari on 28/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation
private let KBaseApiMethod = ApiClient.baseURL()

enum HomeEndPoint: EndPointType {

    case getTopBanner
    case getADsBanner
    case getBusinessBanner
    case getAppTips

    var shouldShowErrorAlerts: Bool {
        switch self {
        case .getTopBanner, .getADsBanner, .getBusinessBanner, .getAppTips:
            return false
        }
    }

    var url: String {
        var path = ""

        switch self {

        case .getTopBanner:
            path = HomeEndPoints.topBanner
        case .getADsBanner:
            path = HomeEndPoints.adsBanner
        case .getBusinessBanner:
            path = HomeEndPoints.business
        case .getAppTips:
            path = HomeEndPoints.appTips
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getTopBanner, .getADsBanner, .getBusinessBanner:
            return WLHttpMethodGet
        case .getAppTips:
            return WLHttpMethodPost
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getTopBanner, .getADsBanner, .getBusinessBanner:
            return [:]
        case .getAppTips:
            return [NotificationAPIParameterKey.device: getDeviceId()]
        }
    }
}
