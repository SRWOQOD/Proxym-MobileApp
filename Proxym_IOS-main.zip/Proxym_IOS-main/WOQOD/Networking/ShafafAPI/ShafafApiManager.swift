//
//  ShafafApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 24/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class ShafafAPIManager {

    class func getRetailers() -> Future<(([RetailerDTO], [Retailer])), Error> {
        let retailersResult: Future<(([RetailerDTO], [Retailer])), Error> =
            HTTPTask.request2(endPointType: ShafafEndPointType.getRetailers)
        return retailersResult
    }

    class func getSupermarkets() -> Future<(([RetailerDTO], [Retailer])), Error> {
           let retailersResult: Future<(([RetailerDTO], [Retailer])), Error> =
            HTTPTask.request2(endPointType: ShafafEndPointType.getSupermarkets)
           return retailersResult
       }

}
