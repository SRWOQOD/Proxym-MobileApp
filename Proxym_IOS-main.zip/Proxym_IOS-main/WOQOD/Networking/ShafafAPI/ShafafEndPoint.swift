//
//  ShafafEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 24/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL()

enum ShafafEndPointType: EndPointType {

    case getRetailers
    case getSupermarkets

    var url: String {
        var path = ""

        switch self {

        case .getRetailers:
            path = EndPoints.shafafRetailers
        case .getSupermarkets:
             path = EndPoints.shafafSupermarket
        }
        return KBaseApiMethod + path
    }

    var method: String {

        switch self {
        case .getRetailers, .getSupermarkets:
            return WLHttpMethodGet
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {

        switch self {
        case .getRetailers, .getSupermarkets:
            return [:]
        }
    }
}
