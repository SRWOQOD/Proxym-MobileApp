//
//  CarEndPoint.swift
//  WOQOD
//
//  Created by rim ktari on 8/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

enum CarEndPoint: EndPointType {
    case checkCar(car: Car?)

    var url: String {

        switch self {
        case .checkCar:
            return ApiClient.baseURL() + EndPoints.checkCar
        }
    }

    var method: String {

        switch self {
        case .checkCar:
            return WLHttpMethodPost
        }
    }

    var parameters: [String: Any?] {
        switch self {
        case .checkCar(let car):
            return [CarAPIParameterKey.qid: car?.ownerQid ?? "" ,
                    CarAPIParameterKey.plateNumber: car?.plateNumber ?? "",
                    CarAPIParameterKey.plateTypeId: car?.plateTypeId
            ]

        }
    }
}
