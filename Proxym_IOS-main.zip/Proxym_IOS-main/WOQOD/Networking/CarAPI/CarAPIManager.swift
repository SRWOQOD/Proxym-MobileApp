//
//  CarAPIManager.swift
//  WOQOD
//
//  Created by rim ktari on 8/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class CarAPIManager {

    class func checkCar(car: Car?)  -> Future<((Bool, Bool)), Error> {

        let result: Future<((Bool, Bool)), Error> = HTTPTask.request(endPointType: CarEndPoint.checkCar(car: car))
        return result

    }

}
