//
//  PromotionsApiManager.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class PromotionsAPIManager {

    class func getPromotions() -> Future<(([PromotionDTO], [Promotion])), Error> {
        let promotionsResult: Future<(([PromotionDTO], [Promotion])), Error> =
            HTTPTask.request(endPointType: PromotionsEndPointType.getPromotions)
        return promotionsResult
    }

}
