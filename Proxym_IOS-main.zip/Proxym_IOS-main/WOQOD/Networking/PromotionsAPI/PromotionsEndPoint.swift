//
//  PromotionEndPoint.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 12/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import IBMMobileFirstPlatformFoundation

private let KBaseApiMethod = ApiClient.baseURL() + EndPoints.promotions

enum PromotionsEndPointType: EndPointType {

    case getPromotions

    var url: String {

        switch self {
        case .getPromotions:
            return KBaseApiMethod
        }
    }

    var method: String {

        switch self {
        case .getPromotions:
            return WLHttpMethodGet
        }
    }

    // MARK: - Parameters
    var parameters: [String: Any?] {
        switch self {
        case .getPromotions:
            return [:]
        }
    }
}
