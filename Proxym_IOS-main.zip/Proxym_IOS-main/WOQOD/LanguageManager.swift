//
//  LanguageManager.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 7/8/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

let languageKey = "language"
let appleLanguagesKey = "AppleLanguages"

enum Language: String {

    case english = "en"
    case arabic = "ar"

    var isEnglish: Bool {
        return Language.currentLanguage == .english
    }
    var isArabic: Bool {
        return Language.currentLanguage == .arabic
    }

    var semantic: UISemanticContentAttribute {
        switch self {
        case .english:
            return .forceLeftToRight
        case .arabic:
            return .forceRightToLeft
        }
    }

    var textAlignment: NSTextAlignment {
        switch self {
        case .english:
            return .left
        case .arabic:
            return .right
        }
    }

    var local: Locale {
        switch self {
        case .english:
            return Locale(identifier: "en")
        case .arabic:
            return Locale(identifier: "ar")
        }
    }

    static var currentLanguage: Language {
        get {
            return getDefaultLanguage()
        }
        set {

            UserDefaults.standard.set([newValue.rawValue], forKey: appleLanguagesKey)
            UserDefaults.standard.synchronize()

            UIView.appearance().semanticContentAttribute = newValue.semantic

            Bundle.setLanguage(newValue.rawValue)

        }
    }
}

func getDefaultLanguage() -> Language {

    guard let preferredLanguage = NSLocale.preferredLanguages.first?.split(separator: "-").first ,
        let language = Language(rawValue: String(preferredLanguage)) else {
            return Language.english
    }
    return language
}

class LanguageManager {

    class func initLanguage() {

        let selectedLanguage = Language.currentLanguage.rawValue
        Bundle.setLanguage(selectedLanguage)

        UIView.appearance().semanticContentAttribute = Language.currentLanguage.semantic
    }

    class func updateLanguage(language: Language) {
        Language.currentLanguage = language
    }
}
