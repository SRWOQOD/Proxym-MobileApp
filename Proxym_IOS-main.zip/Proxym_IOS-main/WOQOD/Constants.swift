//
//  Constants .swift
//  WOQOD
//
//  Created by rim ktari on 7/16/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

public let googleApiKey = "AIzaSyCOF-Ro1DE-rHHugjaXNEbOcqzntPXSDWE"
                         // AIzaSyCn8-9Tz29PQabL0Y9IdxV-P55dIvZHCss
public let rentAshopURLstring="http://www.woqod.com/EN/Business/Pages/Available-Shops.aspx"
// Fonts
struct Fonts {
    static var boldFontName = "Futura-Bold"
    static var mediumFontName  = "Futura-Medium"
    static var bookFontName = "FuturaBT-Book"
    static var mediumBTFontName = "FuturaBT-Medium"
    static var lightFontName = "FuturaBT-LightCondensed"
    static var heavy = "FuturaBT-Heavy"
    static var bookBold = "Futura_Book-Bold"
}

enum UIUserInterfaceIdiom: Int {
    case unspecified

    case phone // iPhone and iPod touch style UI
    case pad   // iPad style UI (also includes macOS Catalyst)
}

// Keychain keys
struct KeychainKeys {
    static let customPWDKey = "customPWDKey"
    static let currentUserKey = "currentUserKey"
    static let currentAccountKey = "currentAccountKey"
    static let savedCurrentUsername = "currentUsernameKey"
    static let currentEntryBioKey = "currentEntryBioKey"
    static let currentEntryBioValue = "currentEntryBioValue"
}

// UserDefaults
struct UserDefaultKeys {
    static let firstBioAuth = "BioAuth"
    static let firstLogin = "FirstLogin"
    static let counterDownKey = "CounterDown"
    static let remainingAttempts = "RemainingAttempts"
    static let isGuest = "IsGuestMode"
    static let shouldHideAppTips = "shouldHideAppTips"
    static let firstLaunch = "firstLaunch"
    static let isRemembered = "isRemembered"
    static let isBiometricActivated = "isBiometricActivated"
    static let qatarDateString = "currentQatarDate"
}

// value if device supports finguerPrint
let deviceSupportsBiometric = biometricAuthentication().0
// check language
var languageIsEnglish: Bool { return Language.currentLanguage.isEnglish }
var languageIsArabic: Bool { return Language.currentLanguage.isArabic }

// User
var userIsConnected: Bool {
    return AuthManager.shared.currentUser != nil
}
// User Balance 
var userHasBalance: Bool {
    return AccountManager.shared.userAccount?.userHasBalance ?? false
}

// Is guest mode activated
var isGuest: Bool {
    return AuthManager.shared.isGuestModeActivated ?? false
}
// should display topup view
var shouldHideAppTips: Bool {
    return AuthManager.shared.shouldHideAppTips ?? false
}

// Is first application launch
var isFirstLaunch: Bool {
    return !FirstAppLaunchManager.shared.isNotFirstLaunch()
}

// Is remember me checked
var isRemembred: Bool {
    return AuthManager.shared.isRemembred ?? false
}

// Current Qatar date
var currentQatarString: CurrentDate {
    return AuthManager.shared.serverDate ?? CurrentDate(dateTimeStamp: "\(Date().timeStamp)",
                                                        utcDateTime: Date().toString(),
                                                        qpayDate: Date().getStringDate("ddMMyyyyHHmmss"))
}
