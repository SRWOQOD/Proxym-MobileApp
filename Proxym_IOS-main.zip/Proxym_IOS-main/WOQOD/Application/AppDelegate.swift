//
//  AppDelegate.swift
//  WOQOD
//
//  Created by rim ktari on 6/22/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Firebase
import GoogleMaps
import KeychainAccess
import IQKeyboardManager
import IBMMobileFirstPlatformFoundationPush
import DropDown
import Combine

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var pushNotificationResult: [AnyHashable: Any]?
    var loaded: Bool = false
    var cancellable=Set<AnyCancellable>()

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.configureFirebase()
        self.initLanguage()

        self.initSecurityCheck()

        self.flushKeychain()

        self.initGoogleMaps()

        self.setupConstraints()

        setupKeyBoard()
        initLocations()
        // the dropdown handle its display with the keyboard displayed
        DropDown.startListeningToKeyboard()
        // INIT remote notif
        self.configureMFPPush()
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting
                        connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running,
        // this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes,
        // as they will not return.
    }

    func configureFirebase() {
        FirebaseApp.configure()
    }

    func initLanguage() {
        LanguageManager.initLanguage()
    }

    func flushKeychain() {
        if isFirstLaunch {
            // Remove Keychain items here
            do {
                try keychain.remove(KeychainKeys.customPWDKey)
                try keychain.remove(KeychainKeys.currentUserKey)
                try keychain.remove(KeychainKeys.currentAccountKey)
            } catch let error {
                print("error removing from keychain: \(error)")
            }
            // Update the flag indicator
            FirstAppLaunchManager.shared.updateFirstLaunch()
        }
    }

    func setupKeyBoard() {
        IQKeyboardManager.shared().isEnabled = true
        IQKeyboardManager.shared().shouldResignOnTouchOutside = true
        IQKeyboardManager.shared().isEnableAutoToolbar = false
    }

    func initSecurityCheck() {
        _ = AuthChallengeHandler.shared
    }

    func initGoogleMaps() {
        GMSServices.provideAPIKey(googleApiKey)
    }

    func setupConstraints() {
        UIViewController.swizzleLayoutConstraint()
    }
    func initLocations() {
        LocationsManager.shared.determineMyCurrentLocation()
    }
}
