//
//  WQCardItemContentView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class WQCardItemContentView: UIView {

    // MARK: - Outlets
    @IBOutlet weak var titleItem: UILabel!
    @IBOutlet weak var valueItem: UITextView!

    // MARK: - Properties
    var titleColor: UIColor = .wqBlue {
        didSet {
            titleItem.textColor = titleColor
        }
    }

    var title: String? {
        didSet {
            titleItem.setText(text: title, font: Fonts.boldFontName, size: 12,
                              forgroundColor: .wqBlue, align: languageIsEnglish ? .left : .right)
        }
    }

    var value: String? {
        didSet {
            valueItem.setTextStyle(text: value, font: Fonts.bookFontName,
                                   size: 13, forgroundColor: .wqBlue, align: languageIsEnglish ? .right : .left)
            valueItem.tintColor = .wqBlue
        }
    }

    var valueIsSelected: Bool = false {
        didSet {
            valueItem.isSelectable = valueIsSelected
        }
    }

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
    }

}
