//
//  WQButtonView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 29/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class WQButton: UIButton {

    // MARK: - Public properties

    var style: WQButtonStyle = Buttontype.primary {
        didSet {
            self.updateButtonStyle()
        }
    }
    override var isEnabled: Bool {
        didSet {
            self.backgroundColor = self.isEnabled ? style.backgroundColor : style.disabledbackgroundColor
        }
    }

    var didTapOnButton : (() -> Void)?

    // MARK: - Overrides

    override var intrinsicContentSize: CGSize {
        let baseSize = super.intrinsicContentSize
        return CGSize(width: baseSize.width + 30.adjusted,
                      height: baseSize.height)
    }

    // MARK: - Initialization

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
        updateButtonStyle()
    }

    // MARK: - Private API

    func commonInit() {

        self.titleLabel?.numberOfLines = 0
        self.titleLabel?.textAlignment = .center

        self.titleLabel?.minimumScaleFactor = 0.2
        self.titleLabel?.adjustsFontSizeToFitWidth = true
        self.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
    }

    func updateButtonStyle() {
        self.backgroundColor = style.backgroundColor
        self.setTitleColor(style.textColor, for: .normal)
        self.titleLabel?.font = style.font

        self.layoutIfNeeded()
        self.layer.cornerRadius = self.frame.height / 2
        layer.masksToBounds = true
    }

    @objc func buttonAction() {
        didTapOnButton?()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = self.frame.height / 2
    }

}
