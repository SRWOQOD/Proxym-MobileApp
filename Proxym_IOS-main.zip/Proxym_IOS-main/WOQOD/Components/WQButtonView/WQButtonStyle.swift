//
//  WQButtonStyle.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 03/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

protocol WQButtonStyle {
    var font: UIFont {get}
    var textColor: UIColor {get}
    var backgroundColor: UIColor {get}
    var disabledbackgroundColor: UIColor {get}
}

enum Buttontype: WQButtonStyle {

    case primary
    case secondary
    case orange
    case clear
    case cancel

    var font: UIFont {
        switch self {
        case .clear:
            return UIFont.init(name: Fonts.bookFontName, size: 14.adjusted)!
        default:
            return UIFont.init(name: Fonts.boldFontName, size: 14.adjusted)!
        }
    }

    var textColor: UIColor {
        switch self {
        case .clear:
            return .wqBlue
        default:
            return UIColor.white
        }
    }

    var disabledbackgroundColor: UIColor {
        return #colorLiteral(red: 0.6784313725, green: 0.6784313725, blue: 0.6784313725, alpha: 1)
    }

    var backgroundColor: UIColor {
        switch self {
        case .cancel:
            return #colorLiteral(red: 0.7019607843, green: 0.03137254902, blue: 0.2235294118, alpha: 1)

        case .primary:
            return #colorLiteral(red: 0, green: 0.6, blue: 0.2, alpha: 1)

        case .secondary:
            return #colorLiteral(red: 0, green: 0.1333333333, blue: 0.5019607843, alpha: 1)

        case .clear:
            return .white

        case .orange:
            return #colorLiteral(red: 0.9725490196, green: 0.5960784314, blue: 0.1568627451, alpha: 1)

        }
    }
}
