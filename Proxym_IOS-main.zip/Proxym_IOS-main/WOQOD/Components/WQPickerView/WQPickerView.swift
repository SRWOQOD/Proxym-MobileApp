//
//  WQPickerView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class WQPickerView: UIPickerView, UIPickerViewDelegate, UIPickerViewDataSource {

    @Published var selectedItem: String = ""
    var shouldSelectFirstItem = true

    var pickerDataArray: [String] = [] {
        didSet {
            selectedItem = shouldSelectFirstItem ? pickerDataArray.first ?? "" : ""
        }
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        delegate = self
        dataSource = self
    }

    required override init(frame: CGRect) {
        super.init(frame: frame)
        delegate = self
    }

    override func layoutSubviews() {
        super.layoutSubviews()
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerDataArray.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataArray[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedItem = pickerDataArray[row]
    }
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int,
                    forComponent component: Int) -> NSAttributedString? {
        let attributedString = NSAttributedString(
            string: pickerDataArray[row],
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.wqBlue
            ])
        return attributedString
    }

}
