//
//  ImagePicker.swift
//  NationalExpertProgram
//
//  Created by Dhekra Rouatbi on 4/2/20.
//  Copyright © 2020 Proxym-it. All rights reserved.
//

import UIKit
import AVFoundation
import Photos

enum ImageSource {
    case photoLibrary
    case camera
}

public protocol ImagePickerDelegate: class {
    func didSelect(image: UIImage?)
}

class ImagePicker: NSObject, UINavigationControllerDelegate {

    private let pickerController: UIImagePickerController
    private weak var delegate: ImagePickerDelegate?
    private var selectedImage: UIImage?

    // MARK: Public methods

    public init(delegate: ImagePickerDelegate) {

        self.pickerController = UIImagePickerController()

        super.init()

        self.delegate = delegate

        self.pickerController.delegate = self

    }

    public func showCamera() {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            return
        }
        checkPermissionForCameraUsage()
    }

    public func showGallery() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            return
        }
        checkPermissionForLibraryUsage()
    }

    // MARK: - SETTINGS ALERT
    func showAlertForSettings(_ source: ImageSource) {
        var alertMessage: String = ""

        switch source {

        case .camera:
            alertMessage = LocalizableShared.enableCameraSettings.localized
        case .photoLibrary:
            alertMessage = LocalizableShared.enablePhotoLibrarySettings.localized
        }

        UIApplication.topViewController()?
            .showConfirmationAlertView(message: alertMessage,
                                       title: "", validateTitle: LocalizableShared.settings.localized,
                                       completion: {
                                        self.openSettings()
                                       })

    }

    func openSettings() {
        let settingsUrl = NSURL(string: UIApplication.openSettingsURLString)
        if let url = settingsUrl {
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
        }
    }

    // MARK: Private methods

    private func checkPermissionForCameraUsage() {
        let cameraMediaType = AVMediaType.video
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: cameraMediaType)

        switch cameraAuthorizationStatus {
        case .denied:

            showAlertForSettings(.camera)
        case .authorized:
            selectImageFrom(.camera)

        case .restricted:
            break
        case .notDetermined:

            AVCaptureDevice.requestAccess(for: cameraMediaType) { granted in
                DispatchQueue.main.sync {
                    if granted {
                        self.selectImageFrom(.camera)
                    }
                }
            }
        default:
            break
        }
    }

    func checkPermissionForLibraryUsage() {
        let photoAuthorizationStatus = PHPhotoLibrary.authorizationStatus()
        switch photoAuthorizationStatus {
        case .authorized:
            selectImageFrom(.photoLibrary)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization({(newStatus) in

                if newStatus ==  PHAuthorizationStatus.authorized {
                    self.selectImageFrom(.photoLibrary)
                }
            })
        case .restricted:
            break
        case .denied:
            showAlertForSettings(.photoLibrary)
        default:
            break
        }
    }

    private func selectImageFrom(_ source: ImageSource) {
        DispatchQueue.main.async {
            switch source {
            case .camera:
                self.pickerController.sourceType = .camera
            case .photoLibrary:
                self.pickerController.sourceType = .photoLibrary
            }
            UIApplication.topViewController()!.present(self.pickerController, animated: true) {
            }
        }
    }

    func pickerController(_ image: UIImage?) {
        self.dissmissPicker()
        var compressedImage = image?.heicDataCompress()
        compressedImage = compressedImage?.resized(withPercentage: 0.5)
        self.delegate?.didSelect(image: compressedImage)
    }

    private func dissmissPicker() {
        self.pickerController.dismiss(animated: true, completion: nil)
    }

    private func updateImageViewWithImage(_ image: UIImage) {

        self.delegate?.didSelect(image: image)
    }
}

extension ImagePicker: UIImagePickerControllerDelegate {

    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dissmissPicker()
    }

    public func imagePickerController(_ picker: UIImagePickerController,
                                      didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {

        // Selected Image

        guard let image = info[.originalImage] as? UIImage else {
            return
        }
        selectedImage = image

        // Handle result
        self.pickerController(image)
    }
}
