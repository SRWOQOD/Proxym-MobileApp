//
//  WQTextView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 18/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class WQTextView: CommonInputFieldView, UITextViewDelegate {

    // MARK: - Outlets
    @IBOutlet weak var textViewComment: UITextView! {
        didSet {
            textViewComment.delegate = self
        }
    }

    @IBOutlet weak var placeholderLabel: UILabel!

    var maxLength: Int?

    // MARK: - Overrided properties
    override var value: String? {
        get {
            return self.textViewComment.text
        }
        set {
            self.textViewComment.setTextStyle(text: newValue, font: Fonts.bookFontName,
                                              size: 12, forgroundColor: .wqBlue,
                                              align: languageIsEnglish ? .left : .right)
        }
    }

    override var textPublisher: AnyPublisher<String, Never>? {
        get {
            return textViewComment.textPublisher
        }
        set {

        }
    }

    /// Resize the placeholder when the UITextView bounds change
    override open var bounds: CGRect {
        didSet {
            textViewComment.resizePlaceholder()
        }
    }

    /// The UITextView placeholder text
    override var placeholder: String? {
        get {
            return placeholderLabel.text
        }
        set {
            placeholderLabel.setText(text: newValue, font: Fonts.mediumFontName,
                                     size: 13, forgroundColor: .wqlightBlue, align: .left)
            placeholderLabel.sizeToFit()
        }
    }

    override var title: String? {
        get {
            return titleLabel.text
        }

        set {
            titleLabel.text = newValue
            self.placeholder = ""

        }

    }

    override var fieldType: FieldType {
        didSet {
            switch fieldType {
            case .address:
                self.maxLength = MaxLength.address
                textViewComment.keyboardType = .default
            case .comment:
                self.maxLength = MaxLength.comment
                textViewComment.keyboardType = .default
            default :
                break
            }
        }
    }
        // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
        setUpView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initView()
        setUpView()
    }

    // MARK: - Overrided Functions

    override func setUpView() {
        super.setUpView()
        initErrorLabel()
        initTitleLabel()
    }

    override func layoutSubviews() {
        guard textFieldState == .initialField else { return }
        textFieldState = .initialField
    }

    // MARK: - Private Functions

    private func initView() {
        adjustUITextViewHeight()
        textViewComment.delegate = self
        textViewComment.font = WQTextFieldStyle().font
        textViewComment.textColor = WQTextFieldStyle().textColor
        textFieldState = .initialField
    }

    /// Make textview height changes when user is typing
    private func adjustUITextViewHeight() {
        textViewComment.sizeToFit()
        textViewComment.isScrollEnabled = false
    }

    // MARK: - TextView delegate Functions

    func textViewDidBeginEditing(_ textView: UITextView) {
        textFieldState = .initialField
        placeholderLabel.isHidden = !textView.text.isEmpty

    }

    func textViewDidEndEditing(_ textView: UITextView) {
        textFieldState = .initialField

    }

    /// When the UITextView did change, show or hide the label based on if the UITextView is empty or not
    ///
    /// - Parameter textView: The UITextView that got updated
    public func textViewDidChange(_ textView: UITextView) {
        errorLabel.isHidden = true
        textfieldContainerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
        textfieldContainerView.roundCorners(radius: 10.adjusted)
        placeholderLabel.isHidden = !textView.text.isEmpty
    }

    open func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange,
                       replacementText text: String) -> Bool {
        guard let textFieldText = textView.text,
            let rangeOfTextToReplace = Range(range, in: textFieldText), let maxLength = self.maxLength  else {
                return true
        }
        let substringToReplace = textFieldText[rangeOfTextToReplace]
        let count = textFieldText.count - substringToReplace.count + text.count
        return count <= maxLength
    }
}
