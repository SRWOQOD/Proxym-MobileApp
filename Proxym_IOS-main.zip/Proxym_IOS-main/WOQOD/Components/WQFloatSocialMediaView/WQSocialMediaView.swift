//
//  WQSocialMediaView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 09/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

public class WQSocialMediaView: UIView {

    @IBOutlet var containerView: UIView!

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        setUpViews()
    }

    private func setUpViews() {
        containerView.round()
        containerView.backgroundColor = UIColor.wqBlue
    }

    @IBAction func linkedInButton(_ sender: Any) {
        openWebOrAppWithUrl(appLink: wqLinkedinAppURL, webLink: wqLinkedinWebURL)
    }

    @IBAction func facebookButton(_ sender: Any) {
        openWebOrAppWithUrl(appLink: wqFacebookAppURL, webLink: wqFacebookWebURL)
    }

    @IBAction func instagramButton(_ sender: Any) {
        openWebOrAppWithUrl(appLink: wqInstagramAppURL, webLink: wqInstagramWebURL)
    }

    @IBAction func twitterButton(_ sender: Any) {
        openWebOrAppWithUrl(appLink: wqTwitterAppURL, webLink: wqTwitterWebURL)
    }

    @IBAction func youtubeButton(_ sender: Any) {
        openWebOrAppWithUrl(appLink: wqYoutubeAppURL, webLink: wqYoutubeWebURL)
    }

    @IBAction func phoneCallButton(_ sender: Any) {
        callNumberFromList(phoneNumbers: wqPhone)
    }

    private func openWebOrAppWithUrl(appLink: String, webLink: String ) {
        let appURL = URL(string: appLink)!
        let application = UIApplication.shared

        if application.canOpenURL(appURL) {
            application.open(appURL)
        } else {
            // if app is not installed, open URL inside Safari
            let webURL = URL(string: webLink)!
            application.open(webURL)
        }
    }

}
