//
//  WQFloatSocialMediaView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 13/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

public class WQFloatSocialMediaView: UIView {

    @IBOutlet weak var socialMediaView: UIView!
    @IBOutlet weak var reversedSocialMediaView: UIView!
    @IBOutlet weak var floatButton: UIButton!

    var socialMediaStackViewIsHidden = false
    public var tapFloatButton: () -> Void = {}
    var viewIsReversed = false

    // MARK: - Initialization

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        hideSocialMedia()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        hideSocialMedia()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        setUpViews()
    }

    private func setUpViews() {
        floatButton.round()
        floatButton.backgroundColor = .wqBlue
    }

    private func showSocialMediaView() {
        reversedSocialMediaView.isHidden = !viewIsReversed
        socialMediaView.isHidden = viewIsReversed
        socialMediaStackViewIsHidden = false
    }

    public func hideSocialMedia() {
        socialMediaView.isHidden = true
        reversedSocialMediaView.isHidden = true
        socialMediaStackViewIsHidden = true
    }

    @IBAction func tapFloatButton(_ sender: Any) {
        socialMediaStackViewIsHidden ?  showSocialMediaView() : hideSocialMedia()
        tapFloatButton()
    }

}
