//
//  WQDraggableView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 09/11/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

public class WQDraggableView: UIView {

    @IBOutlet weak var floatSocialMediaView: WQFloatSocialMediaView!

    private var panGesture = UIPanGestureRecognizer()
    private var floatCurrentCenterXConstant: CGFloat = 0
    private var floatCurrentCenterYConstant: CGFloat = 0
    private var floatButtonIsTapped = false
    private var xConstraint: NSLayoutConstraint!
    private var yConstraint: NSLayoutConstraint!
    private var containerViewWidth: CGFloat = 0
    private var containerViewHeight: CGFloat = 0

    public var containerView: UIView = UIView() {
        didSet {
            setUpViews()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        setPanGestureToFloatButton()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        setPanGestureToFloatButton()
    }

    // MARK: - Private methods
    private func setUpViews() {
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            // It's an iPad (or macOS Catalyst)
            let screenSize: CGRect = UIScreen.main.bounds
            let diff = screenSize.width - containerView.frame.width
            containerViewWidth = containerView.frame.width + diff
        default:
            containerViewWidth = containerView.frame.width
        }
        containerViewHeight = containerView.frame.height
        let floatButtonheight = self.floatSocialMediaView.frame.height
        // the initial state of the float button is rounded width = height
        floatCurrentCenterXConstant = containerViewWidth/2 - floatButtonheight
        floatCurrentCenterYConstant = containerViewHeight/2 - floatButtonheight/2 - floatButtonheight
        // Disable translating AutoresizingMask Into Constraints to avoid conflicts
        floatSocialMediaView.translatesAutoresizingMaskIntoConstraints = false
        containerView.translatesAutoresizingMaskIntoConstraints = false

        // Add constraints allowing the float button to not exceed its container
        xConstraint = NSLayoutConstraint(item: floatSocialMediaView as Any,
         attribute: .centerX, relatedBy: .equal, toItem: containerView, attribute: .centerX, multiplier: 1,
         constant: languageIsEnglish ? floatCurrentCenterXConstant : -floatCurrentCenterXConstant)
        xConstraint.priority = UILayoutPriority(rawValue: 750)
        yConstraint = NSLayoutConstraint(item: floatSocialMediaView as Any,
        attribute: .centerY, relatedBy: .equal, toItem: containerView,
         attribute: .centerY, multiplier: 1, constant: floatCurrentCenterYConstant)
        yConstraint.priority = UILayoutPriority(rawValue: 750)
        let topConstraint = NSLayoutConstraint(item: floatSocialMediaView as Any,
        attribute: .top, relatedBy: .greaterThanOrEqual, toItem: containerView,
        attribute: .top, multiplier: 1, constant: 0)
         let bottomConstraint = NSLayoutConstraint(item: containerView as Any,
         attribute: .bottom, relatedBy: .greaterThanOrEqual,
         toItem: floatSocialMediaView, attribute: .bottom, multiplier: 1, constant: 0)
        let rightConstraint = NSLayoutConstraint(item: containerView as Any,
        attribute: .trailing,
        relatedBy: .greaterThanOrEqual, toItem: floatSocialMediaView,
        attribute: .trailing, multiplier: 1, constant: 0)
        let leftConstraint = NSLayoutConstraint(item: floatSocialMediaView as Any,
        attribute: .leading, relatedBy: .greaterThanOrEqual, toItem: containerView,
        attribute: .leading, multiplier: 1, constant: 0)
        NSLayoutConstraint.activate([
            xConstraint, yConstraint,
            topConstraint, bottomConstraint, rightConstraint, leftConstraint
        ])
    }

    private func setPanGestureToFloatButton() {
        let panGesture = UIPanGestureRecognizer(target: self, action: (#selector(draggedView)))
        floatSocialMediaView.isUserInteractionEnabled = true
        floatSocialMediaView.addGestureRecognizer(panGesture)

        floatSocialMediaView.tapFloatButton = {
            self.floatButtonIsTapped.toggle()
            let floatButtonheight = self.floatSocialMediaView.frame.height
            let floatButtonWidth = self.floatSocialMediaView.frame.width
            let coolArea = -(self.containerViewWidth / 2)
            if self.xConstraint.constant < 0 {
                let maximX = self.floatButtonIsTapped ? coolArea + floatButtonWidth*3 : coolArea + floatButtonheight
                self.xConstraint.constant = maximX
            } else {
                let maximX = self.floatButtonIsTapped ? -coolArea - floatButtonWidth*3 : -coolArea - floatButtonheight
                self.xConstraint.constant = maximX
            }

        }
    }

    @objc private func draggedView(sender: UIPanGestureRecognizer) {

        // get the current pan movement - relative to the view
        let translation = sender.translation(in: containerView)

        switch sender.state {
        case .began:
            // save the current Center X and Y constants
            floatSocialMediaView.hideSocialMedia()
            floatButtonIsTapped = false

            floatCurrentCenterXConstant = xConstraint.constant
            floatCurrentCenterYConstant = yConstraint.constant

        case .changed:
            // update the Center X and Y constants
           xConstraint.constant = floatCurrentCenterXConstant + translation.x
           yConstraint.constant = floatCurrentCenterYConstant + translation.y

        case .ended, .cancelled:

            // update the Center X and Y constants based on the final position of the dragged view
            // the initial state of the float button is rounded width = height
            let floatButtonWidth = floatSocialMediaView.frame.width
            let maximX =  xConstraint.constant < 0 ?
                -(containerViewWidth/2) + floatButtonWidth
                : (containerViewWidth/2) - floatButtonWidth
            xConstraint.constant = maximX

            // check if it exceeds  the center X
            floatSocialMediaView.viewIsReversed =
                languageIsEnglish ? self.xConstraint.constant < 0 :
                self.xConstraint.constant > 0

        default:
            break

        }
    }

}
