//
//  Menu.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 26/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import Combine

class SubMenuViewModel {
    // MARK: - Public Properties
    var selectedItem = PassthroughSubject<SubMenuItemViewModel, Never>()
}
