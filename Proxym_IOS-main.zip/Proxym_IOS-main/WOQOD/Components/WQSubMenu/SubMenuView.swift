//
//  FilterView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 26/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class SubMenuView: UIView {

    // MARK: - IBOutlets
    @IBOutlet weak var menuCollectionView: DynamicCollectionView!
    @IBOutlet var containerView: UIView!

    // MARK: - Properties
    let subMenuVM: SubMenuViewModel = SubMenuViewModel()
    var menuItems: [SubMenuItemViewModel] = []

    var menuType: MenuElementType?

    // MARK: - Custom Properties
    var cellSize: CGSize?
    var titleFont: (String, Int) = (Fonts.mediumFontName, 14)

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        initCollectionView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        initCollectionView()
    }

    // MARK: - Private methods
    func initCollectionView() {

        menuCollectionView.delegate = self
        menuCollectionView.dataSource = self
        menuCollectionView.registerCellNib(SubMenuItemCollectionViewCell.self)
        menuCollectionView.allowsSelection = true
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            // It's an iPad (or macOS Catalyst)
            menuCollectionView.contentInset = UIEdgeInsets(top: 15,
                                                           left: 45.adjusted,
                                                           bottom: 0,
                                                           right: 45.adjusted)
        default:
            break
        }
        self.layoutIfNeeded()
    }
    func reloadElements() {
        self.menuCollectionView.reloadData()
    }

}

extension SubMenuView: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath)
    -> UICollectionViewCell {

        let cell: SubMenuItemCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath)
        let item = menuItems[indexPath.row]

        cell.setup(viewModel: item, fontNameForTitle: titleFont.0,
                   fonSizeForTitle: titleFont.1)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menuItems.count

    }

}

extension SubMenuView: UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        let selectedItem = menuItems[indexPath.row]
        subMenuVM.selectedItem.send(selectedItem)

    }
}

extension SubMenuView: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return self.cellSize ?? CGSize(width: 135.adjusted, height: 150.adjusted)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if self.menuType == .home {
            switch UIDevice.current.userInterfaceIdiom {
            case .pad: return 25.adjusted
            default: return 5.adjusted
            }
        } else {
            return 5.adjusted
        }
    }
}
