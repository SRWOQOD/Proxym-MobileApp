//
//  SubMenuItemCollectionViewCell.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 26/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class SubMenuItemCollectionViewCell: UICollectionViewCell, ReusableView {

    // MARK: - IBOutlets
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemTitle: UILabel!
    @IBOutlet weak var containerView: UIView!

    // MARK: - Overrides
    override var isSelected: Bool {
        didSet {
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        initUI()
    }

    // MARK: - Private functions
    private func initUI() {
        containerView.roundCorners(radius: 11)
        containerView.addShadow(cornerRadius: 11)
        containerView.addShadow(offset: CGSize.init(width: 0, height: 4), color: .wqBlue, radius: 2.0, opacity: 0.25)

    }

    // MARK: - Public functions
    func setup(viewModel: SubMenuItemViewModel, fontNameForTitle: String, fonSizeForTitle: Int) {
        self.itemTitle.setText(text: viewModel.title, font: fontNameForTitle,
                               size: fonSizeForTitle,
                               forgroundColor: .wqBlue,
                               align: .center)
        self.itemImage.image = viewModel.image

    }

}
