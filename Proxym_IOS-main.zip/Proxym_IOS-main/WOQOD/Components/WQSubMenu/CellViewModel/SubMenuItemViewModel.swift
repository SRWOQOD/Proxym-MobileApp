//
//  SubMenuItemViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 26/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

class SubMenuItemViewModel {

    // MARK: - Properties
    var title: String?
    var image: UIImage?
    var viewController: UIViewController?
    var viewControllerType: UIViewController.Type?
    var storyboard: String?
    var type: MenuElementType?
    // MARK: - Initialization
    init(title: String?, image: UIImage?, viewController: UIViewController? = nil,
         viewControllerType: UIViewController.Type? = nil, storyboard: String? = nil,
         type: MenuElementType? = nil) {

        self.title = title
        self.image = image
        self.viewController = viewController
        self.viewControllerType = viewControllerType
        self.storyboard = storyboard
        self.type = type
    }

}
