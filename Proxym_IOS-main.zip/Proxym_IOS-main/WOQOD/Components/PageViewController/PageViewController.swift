//
//  PageViewController.swift
//  FineTuneKid
//
//  Created by Dhekra Rouatbi on 8/23/19.
//  Copyright © 2019 Proxym-it. All rights reserved.
//

import UIKit

class PageViewController: UIPageViewController {

    // MARK: - Public properties

    var views: [UIViewController] = []
    var didChangeViewAt: ((_ index: Int) -> Void)?

    // MARK: - Overrides

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initIU()
    }

    override init(transitionStyle style: UIPageViewController.TransitionStyle,
                  navigationOrientation: UIPageViewController.NavigationOrientation,
                  options: [UIPageViewController.OptionsKey: Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: options)
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // MARK: Private Methods

    private func initIU() {
        setupPageViewController()
    }

    private func setupPageViewController() {

        self.dataSource = self
        self.delegate = self
    }

    private func index(of viewController: UIViewController) -> Int? {
        for (index, viewC) in views.enumerated() where viewController == viewC {
                return index
        }
        return nil
    }

    func setupPageViewController(contentView: UIView) {

        contentView.addSubview(self.view)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        view.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        view.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        view.isUserInteractionEnabled = true

    }

    func selectItemOnpageViewController(lastIndexSelected: Int, index: Int) {

        switch lastIndexSelected {
        case 0...index:
            self.setViewControllers([views[index]], direction: .forward, animated: true, completion: nil)
        default:
            self.setViewControllers([views[index]], direction: .reverse, animated: true, completion: nil)
        }
    }
    func setViewController(index: Int, direction: NavigationDirection) {
        if index >= 0 && views.count > index {
            // This line will not throw index out of range:
            self.setViewControllers([views[index]], direction: direction, animated: true, completion: nil)
        }

    }
}

extension PageViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {

    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore
                                viewController: UIViewController)
    -> UIViewController? {

        guard let viewControllerIndex = views.firstIndex(of: viewController) else { return nil }

        let previousIndex = viewControllerIndex - 1

        guard previousIndex >= 0
            else {
                return nil
        }

        guard views.count > previousIndex
            else {
                return nil
        }

        return views[previousIndex]
    }

    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController)
    -> UIViewController? {
        guard let viewControllerIndex = views.firstIndex(of: viewController)
            else {
                return nil
        }

        let nextIndex = viewControllerIndex + 1

        guard nextIndex < views.count
            else {
                return nil
        }

        guard views.count > nextIndex
            else {
                return nil
        }

        return views[nextIndex]
    }

    func pageViewController(_ pageViewController: UIPageViewController,
                            didFinishAnimating finished: Bool,
                            previousViewControllers: [UIViewController],
                            transitionCompleted completed: Bool) {

        if !completed {
            return
        }
        if let lastPushedVC = pageViewController.viewControllers?.last {
            if let index = index(of: lastPushedVC) {
                didChangeViewAt?(index)
            }
        }
    }
}
