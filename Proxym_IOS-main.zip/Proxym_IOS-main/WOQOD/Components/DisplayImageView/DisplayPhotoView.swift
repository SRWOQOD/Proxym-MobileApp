//
//  DisplayPhoto.swift
//  WOQOD
//
//  Created by rim ktari on 8/11/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class DisplayPhotoView: UIView {

    // MARK: - outlets
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var deleteButton: UIButton!

    // MARK: - Events

    var didDeleteImage : (() -> Void)?

    // MARK: - Public properties
    var image: UIImage? {

        didSet {
            imageView.image = image
        }
    }

    // MARK: - Overrides
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // MARK: - Actions
    @IBAction func deleteAction(_ sender: Any) {
        didDeleteImage?()
    }
}
