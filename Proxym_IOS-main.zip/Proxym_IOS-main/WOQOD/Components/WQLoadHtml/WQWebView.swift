//
//  WQWebView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 07/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import WebKit

struct FileType {

    static let html = "html"
}

class WQWebView: UIView {

    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var webViewHeight: NSLayoutConstraint!
    var scrollIsEnabled: Bool = true

    var loadHtmlPageWithName: FileName? {
        didSet {
            webView.navigationDelegate = self
            webView.scrollView.showsVerticalScrollIndicator = false
            webView.scrollView.isScrollEnabled = false
            webView.setupWebViewClearBackground()
            if let filePath = Bundle.main.url(forResource:
                                                loadHtmlPageWithName?.rawValue, withExtension: FileType.html) {
                let request = NSURLRequest(url: filePath)
                webView.load(request as URLRequest)
            }
        }
    }
    var loadHTMLString: String? {
        didSet {
            webView.navigationDelegate = self
            webView.scrollView.showsVerticalScrollIndicator = false
            webView.scrollView.isScrollEnabled = false
            webView.setupWebViewClearBackground()
            guard let data = loadHTMLString?.toData()  else { return }
            webView.load(data, mimeType: MimeType.html, characterEncodingName: EncodingName.base64,
                         baseURL: URL(fileURLWithPath: ""))
            hideActivityIndicator()
        }
    }

    // MARK: - Initialization
    var loadPDFFile: String? {
        didSet {
            webView.navigationDelegate = self
            webView.scrollView.showsVerticalScrollIndicator = false
            webView.scrollView.isScrollEnabled = false
            guard let data = loadPDFFile?.base64ToPDF()  else { return }
            webView.load(data, mimeType: MimeType.pdf, characterEncodingName: EncodingName.base64,
                         baseURL: URL(fileURLWithPath: ""))
            hideActivityIndicator()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        // showActivityIndicator()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        // showActivityIndicator()
    }

}

extension WQWebView: WKNavigationDelegate {

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }

        let string = url.absoluteString

        let isAnEmail = string.contains("mailto:")
        let isAWebPage = string.contains("http")
        let isAPhoneNumber = string.contains("tel:")

        if isAnEmail || isAWebPage || isAPhoneNumber {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)

    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {

        hideActivityIndicator()
        self.webView.evaluateJavaScript("document.readyState", completionHandler: { (complete, _) in

            if complete != nil {

                self.webView.evaluateJavaScript("document.body.scrollHeight", completionHandler: { (height, _) in
                    self.webViewHeight.constant = webView.scrollView.contentSize.height
                })
            }
        })
    }

}
