//
//  WQOTPInsertView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 21/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class WQOTPInsertView: UIView {

    // MARK: - IBOutlets
    @IBOutlet weak var codeVerificationView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var verificationImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var otpCodeView: AEOTPTextField!
    @IBOutlet weak var resendCodeButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var confirmCodeButton: WQButton!

    // MARK: - Public properties
    var codeIsRight = false
    var typedCode: String = ""

    var resendIsTapped : (() -> Void) = {}
    var confirmIsTapped : (() -> Void) = {}

    var messageText: String? {
        didSet {
            messageLabel.setText(text: messageText, font: Fonts.mediumFontName,
                                      size: 15, forgroundColor: .wqBlue, align: .center)
        }
    }
    var titleText: String? {
        didSet {
            titleLabel.setText(text: titleText?.uppercased(),
                                font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
        }
    }

    var verificationImage: UIImage? {
        didSet {
            verificationImageView.image = verificationImage
        }
    }

    var confirmButtonTitle: String? {
        didSet {
            confirmCodeButton.title = confirmButtonTitle
            confirmCodeButton.style = Buttontype.primary
        }
    }
    var resendButtonTitle: String? {
        didSet {
            resendCodeButton.title = resendButtonTitle
            resendCodeButton.setTitleColor(.wqBlue, for: .normal)
            resendCodeButton.titleLabel?.font = UIFont.init(name: Fonts.mediumFontName, size: 15.adjusted)
        }

    }

    var strategy: OTPStrategyProtocol? {
        didSet {
            titleLabel.setText(text: strategy?.titleText.uppercased(),
                                font: Fonts.boldFontName, size: 22, forgroundColor: .wqBlue)
            otpCodeView.configure(with: strategy?.maximumDigits ?? 4)
            verificationImageView.image = strategy?.image
            self.messageText = strategy?.descriptionText
            confirmButtonTitle = strategy?.confirmButtonTitle
            resendCodeButton.isHidden = strategy?.resendButtonIsHidden ?? true
            resendButtonTitle = strategy?.resendButtonTitle
        }
    }

    // MARK: - Overrides
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUI()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initUI()
    }

    // MARK: - Private functions
    private func initUI() {
        loadNibContent()
        otpCodeView.otpDelegate = self
        initView()
        initOTPView()
        setErrorLabelStyle()
    }

    private func initView() {
        codeVerificationView.border(borderColor: UIColor.white, borderwidth: 1)
        codeVerificationView.roundTopCorners(radius: 15)
        errorLabel.isHidden = true
    }

    private func initOTPView() {
        otpCodeView.cornerRadius = 11.adjusted
        otpCodeView.otpBackgroundColor = UIColor.wqBlue.withAlphaComponent(0.05)
        otpCodeView.otpFilledBackgroundColor =  UIColor.wqBlue.withAlphaComponent(0.05)
        otpCodeView.otpDefaultBorderColor = .clear
        otpCodeView.otpFilledBorderColor = .clear
        otpCodeView.otpTextColor = UIColor.wqBlue
        otpCodeView.otpFont = UIFont.init(name: Fonts.boldFontName, size: 14.adjusted)!
        otpCodeView.deactivateRTL()
    }

    private func setErrorLabelStyle() {
        let notValidOTPError = String.init(format: LocalizableShared.otpNotValid.localized,
                                           String(self.otpCodeView.digitalLabelsCount()))
        let emptyOTPError = LocalizableShared.emptyOTP.localized
        let errorMsg = self.typedCode.count != 0 ? notValidOTPError  : emptyOTPError
        errorLabel.setText(text: errorMsg, font: Fonts.bookFontName, size: 12, forgroundColor: .wqRed, align: .center)
    }

    // MARK: - IBActions
    @IBAction func resendCodeAction(_ sender: Any) {
        otpCodeView.clearAllFields()
        resendIsTapped()
    }

    @IBAction func confirmCodeAction(_ sender: Any) {
        self.errorLabel.isHidden = codeIsRight
        if codeIsRight {
            confirmIsTapped()
        } else {
            setErrorLabelStyle()
        }
    }

}

extension WQOTPInsertView: AEOTPTextFieldDelegate {

    func didUserFinishEnter(the code: String) {
        codeIsRight = code.count == self.otpCodeView.digitalLabelsCount()
        self.errorLabel.isHidden = true
        typedCode = code
    }
}
