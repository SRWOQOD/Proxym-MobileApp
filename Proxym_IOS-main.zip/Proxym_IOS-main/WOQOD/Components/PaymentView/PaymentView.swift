//
//  PaymentView.swift
//  WOQOD
//
//  Created by rim ktari on 10/1/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class PaymentView: UIView {

    // MARK: - Events
    var qPayPaymentAction : (() -> Void)?
    var qnbPaymentAction : (() -> Void)?

    // MARK: - Overrides
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNibContent()

    }

    // MARK: - Actions
    @IBAction func qnbAction(_ sender: Any) {
        qnbPaymentAction?()
    }

    @IBAction func qPayAction(_ sender: Any) {
        qPayPaymentAction?()
    }
}
