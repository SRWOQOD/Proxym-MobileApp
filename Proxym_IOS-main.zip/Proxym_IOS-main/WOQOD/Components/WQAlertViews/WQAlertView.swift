//
//  WQAlertView.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 21/06/2021.
//  Copyright © 2021 rim ktari. All rights reserved.
//

import UIKit
class WQAlertView: UIView {

    // MARK: - Outlets

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var cancelButton: WQButton!
    @IBOutlet weak var confirmButton: WQButton!
    @IBOutlet weak var backgroundImage: UIImageView!

    // MARK: - Public properties

    public var didConfirm: (() -> Void)?
    public var didCancel: (() -> Void)?

    public var title: String? {
        didSet {
            titleLabel.text = title?.uppercased()
        }
    }

    public var text: String? {
        didSet {
            textLabel.text = text
        }
    }

    public var image: UIImage? {

        didSet {
            if image != nil {
                imageView.image = image ?? #imageLiteral(resourceName: "ic_reset_pass_screen")
            } else {
                imageView.isHidden = true
            }
        }
    }

    public var confirmButtonText: String? {
        didSet {
            confirmButton.title = confirmButtonText?.uppercased()
        }
    }

    // MARK: - Initialization

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    // MARK: - Initialisers

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNibContent()
        commonInit()
    }

    private func commonInit() {
        titleLabel.setText(text: title, font: Fonts.boldFontName, size: 22, forgroundColor: UIColor.wqBlue)
        textLabel.setText(text: text, font: Fonts.mediumFontName, size: 15, forgroundColor: UIColor.wqBlue)
        confirmButton.color = .wqBlue
        confirmButton.setTitleColor(.white, for: .normal)
        confirmButton.font = UIFont(name: Fonts.boldFontName, size: 13)
        confirmButton.title = confirmButtonText
        cancelButton.color = .wqBlue
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.font = UIFont(name: Fonts.boldFontName, size: 13)
        cancelButton.title = LocalizableShared.cancel.localized.uppercased()
        confirmButton.didTapOnButton = {
            self.didConfirm?()
        }
        cancelButton.didTapOnButton = {
            self.didCancel?()
        }
    }
}
