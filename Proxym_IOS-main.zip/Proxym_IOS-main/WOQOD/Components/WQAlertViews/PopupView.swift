//
//  PopupView.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

public protocol PopupViewDelegate: class {
    var popupView: UIView { get }
    var animationDuration: TimeInterval { get }
}

open class PopupView: NSObject {

    private static var shared = PopupView()

    private var visualEffectBlurView = UIVisualEffectView()
    private var isPresenting = false

    public static func show(_ viewControllerToPresent: UIViewController, on parentViewController: UIViewController) {
        viewControllerToPresent.modalPresentationStyle = .overCurrentContext
        viewControllerToPresent.transitioningDelegate = shared

        if !(viewControllerToPresent is PopupViewDelegate) {
            assertionFailure("ERROR: \(viewControllerToPresent) does not conform to protocol 'MIPopupViewDelegate'")
        }

        parentViewController.present(viewControllerToPresent, animated: true, completion: nil)
    }

    private func animatePresent(transitionContext: UIViewControllerContextTransitioning) {
        guard
            let presentedViewController = transitionContext.viewController(forKey: .to)
            else { return }

        presentedViewController.view.alpha = 0
        presentedViewController.view.frame = transitionContext.containerView.bounds

        transitionContext.containerView.addSubview(presentedViewController.view)

        UIView.animate(
            withDuration: transitionDuration(using: transitionContext),
            delay: 0.0,
            usingSpringWithDamping: 1.0,
            initialSpringVelocity: 0.0,
            options: .allowUserInteraction,
            animations: {
                presentedViewController.view.alpha = 1

        },
            completion: { isCompleted in
                transitionContext.completeTransition(isCompleted)
        }
        )
    }

    fileprivate func animateDismiss(transitionContext: UIViewControllerContextTransitioning) {
        guard
            let presentedViewController = transitionContext.viewController(forKey: .from)
            else { return }

        UIView.animate(
            withDuration: transitionDuration(using: transitionContext),
            delay: 0.0,
            usingSpringWithDamping: 2,
            initialSpringVelocity: 0.0,
            options: .allowUserInteraction,
            animations: {
                presentedViewController.view.alpha = 0
        },
            completion: { isCompleted in
                transitionContext.completeTransition(isCompleted)
        }
        )
    }

}

// MARK: - UIViewControllerTransitioningDelegate

extension PopupView: UIViewControllerTransitioningDelegate {

    public func animationController(forPresented presented: UIViewController,
                                    presenting: UIViewController,
                                    source: UIViewController)
    -> UIViewControllerAnimatedTransitioning? {
        isPresenting = true
        return self
    }

    public func animationController(forDismissed dismissed: UIViewController)
    -> UIViewControllerAnimatedTransitioning? {
        isPresenting = false
        return self
    }

}

// MARK: - UIViewControllerAnimatedTransitioning

extension PopupView: UIViewControllerAnimatedTransitioning {

    public func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?)
    -> TimeInterval {
        if let toViewControllerDelegate = transitionContext?.viewController(forKey: .to) as? PopupViewDelegate {
            return toViewControllerDelegate.animationDuration
        }
        if let fromViewControllerDelegate = transitionContext?.viewController(forKey: .from) as? PopupViewDelegate {
            return fromViewControllerDelegate.animationDuration
        }
        return 0
    }

    public func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        if isPresenting {
            animatePresent(transitionContext: transitionContext)
        } else {
            animateDismiss(transitionContext: transitionContext)
        }
    }

}
