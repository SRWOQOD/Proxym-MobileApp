//
//  SuccessAlertView.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class SuccessAlertView: UIView {

    // MARK: - Outlets

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var confirmButton: WQButton!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    // MARK: - Public properties

    public var didConfirm: (() -> Void)?

    public var message: String? {
        didSet {
            messageLabel.text = message?.uppercased()
        }
    }
    public var text: String? {
        didSet {
            descriptionLabel.text = text
        }
    }

    // MARK: - Initialization

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    // MARK: - Initialisers

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNibContent()
        commonInit()
    }

    private func commonInit() {
        descriptionLabel.isHidden = text == ""
        messageLabel.isHidden = message == ""
        confirmButton.style = Buttontype.secondary
        confirmButton.title = LocalizableShared.done.localized.uppercased()
        confirmButton.didTapOnButton = {
            self.didConfirm?()
        }
        descriptionLabel.setText(text: "", font: Fonts.mediumFontName, size: 17,
                             forgroundColor: UIColor.wqBlue, lineSpace: 10)
        messageLabel.setText(text: "", font: Fonts.boldFontName, size: 17,
                             forgroundColor: UIColor.wqBlue, lineSpace: 10)
    }

}
