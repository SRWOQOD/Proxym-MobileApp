//
//  AlertView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 08/09/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

// TO DO: This class will be removed when design of information views will be implemented
class AlertView: UIView {

    // will be removed when information popus are done
    func initWith(_ message: String) {

        let messageLbl = UILabel()
        messageLbl.text = message
        messageLbl.textAlignment = .center
        messageLbl.font = UIFont.systemFont(ofSize: 12)
        messageLbl.textColor = .white
        messageLbl.backgroundColor = UIColor(white: 0, alpha: 0.5)

        let textSize: CGSize = messageLbl.intrinsicContentSize
        let labelWidth = min(textSize.width, UIScreen.width - 40)

        messageLbl.frame = CGRect(x: 20, y: UIScreen.height - 90, width: labelWidth + 30, height: textSize.height + 20)
        messageLbl.center.x = UIScreen.width/2
        messageLbl.layer.cornerRadius = messageLbl.frame.height/2
        messageLbl.layer.masksToBounds = true

        self.addSubview(messageLbl)
    }
}
