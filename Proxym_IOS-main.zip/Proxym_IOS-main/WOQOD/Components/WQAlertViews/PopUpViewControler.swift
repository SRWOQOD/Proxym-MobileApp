//
//  PopUpViewControler.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class PopUpViewControler: UIViewController {

    // MARK: - Outlets

    @IBOutlet weak var popupContentContainerView: UIView!

    // MARK: - Public properties
    public var dismissWhenTappingOutside = false
    public var contentView: UIView = UIView() {
        didSet {
            contentView.translatesAutoresizingMaskIntoConstraints = false

            self.popupContentContainerView.addSubview(contentView)

            let constraints = [
                NSLayoutConstraint(item: contentView, attribute: .top, relatedBy: .equal,
                                   toItem: popupContentContainerView,
                                   attribute: .top, multiplier: 1.0, constant: 0),
                NSLayoutConstraint(item: contentView, attribute: .leading, relatedBy: .equal,
                                   toItem: popupContentContainerView,
                                   attribute: .leading, multiplier: 1.0, constant: 0),
                NSLayoutConstraint(item: contentView, attribute: .trailing, relatedBy: .equal,
                                   toItem: popupContentContainerView,
                                   attribute: .trailing, multiplier: 1.0, constant: 0),

                NSLayoutConstraint(item: contentView, attribute: .bottom, relatedBy: .equal,
                                   toItem: popupContentContainerView,
                                   attribute: .bottom, multiplier: 1.0, constant: 0)
            ]
            NSLayoutConstraint.activate(constraints)
        }
    }

    public var viewController: UIViewController = UIViewController() {
        didSet {
            // popupContentContainerView.translatesAutoresizingMaskIntoConstraints = false
            self.addViewController(targetView: self.popupContentContainerView, targetViewController: viewController)
        }
    }

    // MARK: - Overrides

    override func viewDidLoad() {
        super.viewDidLoad()
        popupContentContainerView.roundCorners(radius: 21)
        addGesture()
    }

    func addGesture() {
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(onBaseTapOnly))
        tapRecognizer.delegate = self
        self.view.addGestureRecognizer(tapRecognizer)
    }
}

// MARK: - MIPopupViewDelegate

extension PopUpViewControler: PopupViewDelegate {

    var popupView: UIView {
        return popupContentContainerView ?? UIView()
    }

    var animationDuration: TimeInterval {
        return  0.2
    }

}
extension PopUpViewControler: UIGestureRecognizerDelegate {

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
         return touch.view == gestureRecognizer.view
     }
     @objc func onBaseTapOnly(_ sender: UITapGestureRecognizer) {
        if self.dismissWhenTappingOutside {
            self.dismiss(animated: false, completion: nil)
        }
     }
}
