//
//  ErrorAlertView.swift
//  WOQOD
//
//  Created by Dhekra Rouatbi on 10/14/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class ErrorAlertView: UIView {

    // MARK: - Outlets
    @IBOutlet weak var errorImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var confirmButton: WQButton!
    @IBOutlet weak var backgroundImage: UIImageView!

    // MARK: - Public properties

    public var didConfirm: (() -> Void)?
    public var didDiscard: (() -> Void)?

    public var descriptionMessage: String? {
        didSet {
            messageLabel.text = descriptionMessage?.uppercased()
        }
    }
    public var errorImage: UIImage? {
        didSet {
            guard let image = errorImage else {return}
            errorImageView.image = image
        }
    }
    public var alertBackgroundImage: UIImage? {
        didSet {
            guard let image = alertBackgroundImage else {return}
            backgroundImage.image = image
        }
    }
    // MARK: - Counter properties
    var timer: Timer?
    // Left time is 15 min
    var timeLeft: Int = 900 // 15*60
    var isACounter: Bool = false {
        didSet {
            if isACounter {
                initCounter()
            }
        }
    }
    public var counterMessage: String? {
        didSet {
            messageLabel.text =  LocalizedAuthentication.loginUserBlockedError.localized + (counterMessage ?? "-:-")
            messageLabel.textColor = .wqDarkGray
        }
    }

    // MARK: - Initialization

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    // MARK: - Initialisers

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNibContent()
        commonInit()
    }

    private func initCounter() {

        if TimerManager.shared.startTime == 0 {
            TimerManager.shared.startTime = getTimeInSeconds()
        } else {
            timeLeft -= (getTimeInSeconds() - TimerManager.shared.startTime)
        }
        counterMessage = convertMinFromSeconds(sec: timeLeft)

        timer = Timer.scheduledTimer(timeInterval: 1, target: self,
                                     selector: #selector(countDown), userInfo: nil, repeats: true)

    }

    @objc func countDown() {
        timeLeft -= 1

        if timeLeft <= 0 {
            timer?.invalidate()
            timer = nil
            TimerManager.shared.startTime = 0
        }
        counterMessage = convertMinFromSeconds(sec: timeLeft)
    }

    private func commonInit() {
        confirmButton.style = Buttontype.secondary
        confirmButton.title = LocalizableShared.done.localized.uppercased()
        confirmButton.didTapOnButton = {
            self.didConfirm?()
        }

        messageLabel.setText(text: "", font: Fonts.boldFontName, size: 22, forgroundColor: UIColor.wqBlue)
    }

}
