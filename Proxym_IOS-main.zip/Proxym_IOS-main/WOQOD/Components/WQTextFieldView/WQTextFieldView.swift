//
//  WQTextFieldView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 17/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

public struct DropDownElement {
    var key: String
    var name: String
}

class WQTextFieldView: CommonInputFieldView {

    // MARK: - Outlets
    @IBOutlet weak var buttonTextfield: UIButton!

    // MARK: - Overrided Properties

    var shouldSelectFirstItem = true
    // TO Fix
    var defaultValueDatePicker: Date? {

        didSet {
            if let date = defaultValueDatePicker {
                self.datePicker.date = date
                self.textField.text = date.getStringDate("dd-MM-yyyy")
            }
        }
    }

    override var value: String? {
        get {
            return self.textField.text
        }
        set {
            self.textField.text = newValue

        }
    }

    var errorValue: String? {
        didSet {
            if errorValue != nil {
                errorLabel.text = errorValue
                errorLabel.isHidden = false
            }
        }
    }

    override var textPublisher: AnyPublisher<String, Never>? {
        get {
            return textField.textPublisher
        }

        set {

        }
    }

    override var fieldType: FieldType {

        didSet {

            textField.setEmptyRightView(height: self.textField.frame.height, width: 16.adjusted)
            textField.setEmptyLeftView(height: self.textField.frame.height, width: 20.adjusted)
            textField.maxLength = nil
            switch fieldType {

            case .email:
                self.textField.keyboardType = .asciiCapable

            case .emailLogin:
                textField.keyboardType = .asciiCapable
                textField.setRightView(image: #imageLiteral(resourceName: "ic_usernameLogin.png"))

            case .passwordLogin, .password, .confirmPassword:

                textField.keyboardType = .asciiCapable
                textField.isSecureTextEntry = true
                textField.setRightView(image: #imageLiteral(resourceName: "ic_passwordLogin.png"), action: #selector(textField.showPassword), target: textField)

            case  .qatariId:
                textField.keyboardType = .asciiCapableNumberPad
                textField.maxLength = MaxLength.qatariID

            case .qatariIdLogin:
                textField.keyboardType = .asciiCapableNumberPad
                textField.maxLength = MaxLength.qatariID
                textField.setRightView(image: #imageLiteral(resourceName: "ic_usernameLogin.png"))

            case .amount :
                textField.keyboardType = .asciiCapableNumberPad

            case .username, .familyName, .name:
                textField.keyboardType = .default

            case .usernameLogin :
                textField.keyboardType = .default
                textField.setRightView(image: #imageLiteral(resourceName: "ic_usernameLogin.png"))

            case .mobileNumber :
                textField.maxLength = MaxLength.mobile
                textField.keyboardType = .asciiCapableNumberPad

            case .carPlate(let plateType) :
                textField.maxLength = plateType == .defaultType ? MaxLength.carPlate : MaxLength.carPlateDiplomatic
                textField.keyboardType = plateType == .defaultType ? .asciiCapableNumberPad : .numbersAndPunctuation

            case .mobileNumberLogin:
                textField.maxLength = MaxLength.mobile
                textField.keyboardType = .asciiCapableNumberPad
                textField.setRightView(image: #imageLiteral(resourceName: "ic_usernameLogin.png"))

            case .text, .address:
                textField.keyboardType = .default

            case .companyID:
                textField.keyboardType = .numbersAndPunctuation
                textField.maxLength = MaxLength.poBox

            case .poBox :
                textField.keyboardType = .asciiCapableNumberPad
                textField.maxLength = MaxLength.poBox

            case .datePicker, .dateOfBirth:
                textField.setRightView(image: #imageLiteral(resourceName: "ic_calendar.png"))
                initpickerView()

            case .bioPin:
                textField.maxLength = MaxLength.bioPin
                textField.keyboardType = .asciiCapableNumberPad

            default:
                break
            }

        }
    }

    override var placeholder: String? {
        didSet {
            if let placeholder = placeholder {
                self.textField.placeholder = placeholder
                textField.placeHolderStyle( textField.textFieldStyle?.placeholderTextColor,
                                            textField.textFieldStyle?.placeholderTextFont)
            }
        }
    }

    // MARK: - Public Properties

    var isEditable: Bool = true {
        didSet {
            self.textField.isEnabled  = isEditable
            !isEditable ? textfieldContainerView.backgroundColor = .wqMediumGray : ()
            !isEditable ? textfieldContainerView.border(borderColor: .clear, borderwidth: 1) : ()
        }
    }

    var buttonTextfieldTapped: (() -> Void) = {}

    let pickerView = WQPickerView()

    let datePicker = UIDatePicker()

    let pickerViewWillChangeValue = ObservableObjectPublisher()

    @Published var pickerSelectedText: String = ""

    var textChanged: AnyPublisher<String, Never> {
        return textField.textPublisher
    }

    // MARK: - Private Properties
    private var cancellable = Set<AnyCancellable>()

    // MARK: - Initialization

    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpView()
    }

    override func layoutSubviews() {
        guard textFieldState == .initialField else { return }
        textFieldState = .initialField
    }

    override func setUpView() {
        super.setUpView()

        textField.textFieldStyle = WQTextFieldStyle()
        textfieldContainerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
        textfieldContainerView.backgroundColor = UIColor.clear
        textField.textChanged = { _ in
            self.textFieldState = .initialField
        }

        textfieldContainerView.roundCorners(radius: 10.adjusted)
    }

    // MARK: - Private methods

    private func initpickerView() {

        self.buttonTextfield.isHidden = false
//        self.textField.text = ( fieldType == .dropDown()) ? pickerView.pickerDataArray.first : ""
        self.errorLabel.isHidden = true
        pickerView.$selectedItem
            .receive(on: RunLoop.main)
            .sink {self.pickerSelectedText = $0}
            .store(in: &cancellable)
    }

    @IBAction func tapButtonTextField(_ sender: Any) {

        switch fieldType {
        case .datePicker, .dateOfBirth:
            textField.inputView = createDatePicker()
            textField.becomeFirstResponder()
        default:
            break
        }
    }

    // MARK: - Picker View

    func initPickerTextStyle(value: String?) {
        self.value = value
        textField.textColor =  .wqBlue
        textField.font = UIFont.init(name: Fonts.bookFontName, size: 12.adjusted)
    }

    func createDatePicker() -> UIDatePicker {
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        }

        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: LocalizableShared.keyboardDone.localized,
                                         style: .done, target: self,
                                         action: #selector(doneDatePicker))
        doneButton.tintColor = .wqBlue
        datePicker.backgroundColor = UIColor(hexString: "#DFE2F0")
        datePicker.tintColor = .wqBlue
        pickerView.border(borderColor: .wqlightBlue, borderwidth: 0.5)
        toolBar.barTintColor = UIColor(hexString: "#DFE2F0")
        toolBar.setItems([doneButton], animated: true)
        textField.inputAccessoryView = toolBar
        fieldType == .dateOfBirth ? datePicker.maximumDate = Date() : ()
        // This is for supporting arabic date displayed with english numbers
        datePicker.locale =  languageIsArabic ? Locale(identifier: "ar") :
            Locale(identifier: "en_GB")
        datePicker.datePickerMode = .date
        return datePicker

    }

    @objc func doneDatePicker() {

        // For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        formatter.locale = Locale(identifier: "en_GB")
        textField.text = formatter.string(from: datePicker.date)
        errorLabel.isHidden = true
        textfieldContainerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
        textfieldContainerView.roundCorners(radius: 10.adjusted)
        formatter.locale =  Language.english.local
        self.pickerSelectedText = formatter.string(from: datePicker.date)
        pickerViewWillChangeValue.send()
        // dismiss date picker dialog
        textField.endEditing(true)
    }

}
