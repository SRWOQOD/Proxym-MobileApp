//
//  WQTextField.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class WQTextField: UITextField, UITextFieldDelegate {

    // MARK: - Public properties

    var textFieldStyle: TextFieldStyle? {
        didSet {
            self.initStyle()
        }
    }

    var placeholderTitle: String? {
        didSet {
            self.placeholder = placeholderTitle
            self.placeHolderStyle(self.textFieldStyle?.placeholderTextColor, self.textFieldStyle?.placeholderTextFont)
        }
    }

    var maxLength: Int?
    var textChanged: (String) -> Void = { _ in }
    var didBeginEditing :() -> Void = { }
    var didEndEditing :() -> Void = { }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        delegate = self
        self.initTextField()
    }

    required override init(frame: CGRect) {
        super.init(frame: frame)
        delegate = self
        self.initTextField()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
    }

    func initTextField() {
        self.returnKeyType = .done
        self.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)

    }

    func initStyle() {

        self.font = self.textFieldStyle?.font

        self.tintColor = self.textFieldStyle?.tintColor

        self.textColor = self.textFieldStyle?.textColor

        self.backgroundColor = self.textFieldStyle?.backgroundColor

        self.autocorrectionType = .no

    }

    // MARK: UITextField delegates methods

    @objc func textFieldDidChange(_ textField: UITextField) {

        textChanged(textField.text!)
    }

    open func textFieldDidBeginEditing(_ textField: UITextField) {
        didBeginEditing()

    }

    open func textFieldDidEndEditing(_ textField: UITextField) {
        didEndEditing()
    }

    open func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }

    open func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }

    open func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }

    open func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange,
                        replacementString string: String) -> Bool {
        guard let textFieldText = textField.text,
            let rangeOfTextToReplace = Range(range, in: textFieldText), let maxLength = self.maxLength  else {
                return true
        }
        let substringToReplace = textFieldText[rangeOfTextToReplace]
        let count = textFieldText.count - substringToReplace.count + string.count
        return count <= maxLength
    }

    open func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
}
