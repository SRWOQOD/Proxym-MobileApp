//
//  WQTextFieldStyle.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

protocol TextFieldStyle {

    var font: UIFont? {get}
    var tintColor: UIColor? {get}
    var textColor: UIColor? {get}
    var placeholderTextColor: UIColor? {get}
    var placeholderTextFont: UIFont? {get}
    var backgroundColor: UIColor? {get}
}

struct WQTextFieldStyle: TextFieldStyle {

    var backgroundColor: UIColor?
    var tintColor: UIColor?
    var titleFont: UIFont { return UIFont.init(name: Fonts.mediumFontName, size: 15.adjusted)!}
    var titleColor: UIColor { return .wqBlue }
    var font: UIFont? { return UIFont.init(name: Fonts.bookFontName, size: 13.adjusted)!}
    var textColor: UIColor? { return .wqBlue}
    var placeholderTextColor: UIColor? { return UIColor.wqBlue.withAlphaComponent(0.5)}
    var placeholderTextFont: UIFont? { return UIFont.init(name: Fonts.mediumFontName, size: 13.adjusted)!}

}
protocol TextFieldViewStyle {

    var errorTitleColor: UIColor {get}
    var errorTitleFont: UIFont {get}
    var errorBorderColor: UIColor {get}
    var titleFont: UIFont {get}
    var titleColor: UIColor {get}
    var leftViewPadding: CGFloat {get}
    var rightViewPadding: CGFloat {get}
}

struct WQTextFieldViewStyle: TextFieldViewStyle {

    var errorTitleColor: UIColor { return .wqLightRed}
    var errorTitleFont: UIFont { return UIFont.init(name: Fonts.bookFontName, size: 12.adjusted)!}
    var errorBorderColor: UIColor { return UIColor.red.withAlphaComponent(0.5)}
    var titleFont: UIFont { return UIFont.init(name: Fonts.mediumFontName, size: 15.adjusted)!}
    var titleColor: UIColor { return .wqBlue }
    var leftViewPadding: CGFloat { return 55.adjusted }
    var rightViewPadding: CGFloat { return 20.adjusted }
}
