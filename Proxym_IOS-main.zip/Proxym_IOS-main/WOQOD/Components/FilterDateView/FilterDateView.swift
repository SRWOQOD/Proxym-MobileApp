//
//  FilterDateView.swift
//  WOQOD
//
//  Created by rim ktari on 11/12/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

class FilterDateView: UIView {

    // MARK: - Outlets
    @IBOutlet weak var endDateTextFiledView: WQTextFieldView!
    @IBOutlet weak var startDateTextFieldView: WQTextFieldView!
    @IBOutlet weak var endDateLabel: UILabel!
    @IBOutlet weak var startDateLabel: UILabel!
   // @IBOutlet weak var arrowImage: UIImageView!
    @IBOutlet weak var startDateTopConstraint: NSLayoutConstraint!

    @IBOutlet weak var endDateTopConstraint: NSLayoutConstraint!
    var startDate: Date?
    var endDate: Date?
    var filterAction : ((_ startDate: Date?, _ endDate: Date?) -> Void) = { (_, _) in}
    // MARK: - Properties
    var cancellable = Set<AnyCancellable>()

    var isDirectedFromTenders: Bool = false {
        didSet {
            updateUI()
        }
    }

    // MARK: - Overrides
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        initUI()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        initUI()
    }

    private func updateUI() {
        hideTextLabels()
        updateDateViewConstraint()
    }

    private func hideTextLabels() {
        self.startDateLabel.isHidden = true
        self.endDateLabel.isHidden = true
    }

    func updateDateViewConstraint() {
        startDateTopConstraint.isActive = false
        startDateTextFieldView.topAnchor.constraint(equalTo: self.topAnchor, constant: 0.0).isActive = true
        endDateTopConstraint.isActive = false
        endDateTextFiledView.topAnchor.constraint(equalTo: self.topAnchor, constant: 0.0).isActive = true
    }

    /// This func is used to reset values of the view to its initial state
    func clearFields(clearMinMaxDate: () -> Void = {}) {
        endDateTextFiledView.value = ""
        startDateTextFieldView.value = ""
        startDateTextFieldView.initPickerTextStyle(value: LocalizableFeedback.start.localized)
        endDateTextFiledView.initPickerTextStyle(value: LocalizableFeedback.end.localized)
        startDate = nil
        endDate = nil
        clearMinMaxDate()
    }

    func initUI() {
        startDateLabel.setText(text: LocalizableFeedback.start.localized, font: Fonts.mediumFontName, size: 15,
                               forgroundColor: .wqBlue, align: languageIsEnglish ? .left : .right)
        endDateLabel.setText(text: LocalizableFeedback.end.localized, font: Fonts.mediumFontName, size: 15,
                             forgroundColor: .wqBlue, align: languageIsEnglish ? .left : .right)
        endDateTextFiledView.setEmptyLeftView()
       // arrowImage.transformImageRTL()
        startDateTextFieldView.fieldType = .datePicker
        startDateTextFieldView.setEmptyLeftView(width: 22)
        endDateTextFiledView.fieldType = .datePicker
        endDateTextFiledView.setEmptyLeftView(width: 22)
        startDateTextFieldView.textField.setRightView(image: UIImage(named: "ic_calendar") ?? UIImage())
        endDateTextFiledView.textField.setRightView(image: UIImage(named: "ic_calendar") ?? UIImage())

        endDateTextFiledView.pickerViewWillChangeValue
            .sink {

                self.endDate = self.endDateTextFiledView.datePicker.date
                self.filterAction(self.startDate, self.endDate )
                if self.isDirectedFromTenders {
                    self.startDateTextFieldView.datePicker.maximumDate = self.endDate
                }
        }
        .store(in: &cancellable)

        startDateTextFieldView.pickerViewWillChangeValue
            .sink {
                self.startDate = self.startDateTextFieldView.datePicker.date
                self.filterAction(self.startDate, self.endDate )
                if self.isDirectedFromTenders {
                    self.endDateTextFiledView.datePicker.minimumDate = self.startDate
                }

        }
        .store(in: &cancellable)
        startDateTextFieldView.placeholder = LocalizableFeedback.start.localized
        endDateTextFiledView.placeholder = LocalizableFeedback.end.localized

    }

}
