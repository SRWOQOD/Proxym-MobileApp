//
//  FadeScrollView.swift
//
//  Created by Luís Machado on 23/06/2017.
//  Copyright © 2017 Luis Machado. All rights reserved.
//

import UIKit

class FadeScrollView: UIScrollView, UIScrollViewDelegate {

    let fadePercentage: Double = 0.05
    let gradientLayer = CAGradientLayer()
    let transparentColor = UIColor.clear.cgColor
    let opaqueColor = UIColor.black.cgColor

    var topOpacity: CGColor {
        let scrollViewHeight = frame.size.height
        let scrollContentSizeHeight = contentSize.height
        let scrollOffset = contentOffset.y

        let alpha: CGFloat = (scrollViewHeight >= scrollContentSizeHeight || scrollOffset <= 0) ? 1 : 0

        let color = UIColor(white: 0, alpha: alpha)
        return color.cgColor
    }

    var bottomOpacity: CGColor {
        let scrollViewHeight = frame.size.height
        let scrollContentSizeHeight = contentSize.height
        let scrollOffset = contentOffset.y

        let alpha: CGFloat =
            (scrollViewHeight >= scrollContentSizeHeight
                || scrollOffset + scrollViewHeight >= scrollContentSizeHeight) ? 1 : 0
        let color = UIColor(white: 0, alpha: alpha)
        return color.cgColor
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        self.delegate = self
        let maskLayer = CALayer()
        maskLayer.frame = self.bounds

        gradientLayer.frame = CGRect(x: self.bounds.origin.x, y: 0,
                                     width: self.bounds.size.width,
                                     height: self.bounds.size.height)
        gradientLayer.colors = [topOpacity, opaqueColor, opaqueColor, bottomOpacity]
        gradientLayer.locations = [0, NSNumber(floatLiteral: fadePercentage),
                                   NSNumber(floatLiteral: 1 - fadePercentage), 1]
        maskLayer.addSublayer(gradientLayer)

        self.layer.mask = maskLayer
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        gradientLayer.colors = [topOpacity, opaqueColor, opaqueColor, bottomOpacity]
    }
    // Scroll to a specific view so that it's top is at the top our scrollview
    func scrollToView(view: UIView, animated: Bool) {
        if let origin = view.superview {
            self.layoutIfNeeded()
            // Get the Y position of your child view
            let childStartPoint = origin.convert(view.frame.origin, to: self)
            // Scroll to a rectangle starting at the Y of your subview, with a height of the scrollview
            self.scrollRectToVisible(CGRect(x: 0, y: childStartPoint.y, width: 1, height: self.frame.height),
                                     animated: animated)
        }
    }

    func scrollToTop(animated: Bool) {
        let topOffset = CGPoint(x: 0, y: -contentInset.top)
        setContentOffset(topOffset, animated: animated)
    }

}
