//
//  Validators.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

enum DropDownType {
    case plateTypes
    case vehicleShapes
    case customerTypes
    case stations
    case defaultType
    case area
    case feedbackCategory
}

enum CarPlateType {
    case diplomatic
    case defaultType
}

enum FieldType: Equatable {
    case email
    case emailLogin
    case passwordLogin
    case confirmPassword
    case password // we create two types of passwords because we didn't want the already +100k
    // users change their password however the new users should have the new rule of password
    case username
    case familyName
    case name
    case address
    case poBox
    case dateOfBirth
    case usernameLogin
    case text
    case comment
    case mobileNumber
    case mobileNumberLogin
    case datePicker
    case qatariId
    case qatariIdLogin
    case companyID
    case amount
    case carPlate(type: CarPlateType = .defaultType)
    case dropDown(type: DropDownType? = .defaultType)
    case bioPin
}
class ValidationError: Error {
    var message: String

    init(_ message: String) {
        self.message = message
    }
}

protocol ValidatorConvertible {
    func validated(_ value: String) throws -> Bool
}

struct VaildatorFactory {
    static func validatorFor(type: FieldType) -> ValidatorConvertible {
        switch type {
        case .carPlate(let plateType) : return CarPlateValidator(type: plateType)
        case .text : return TextValidator()
        case .usernameLogin : return LoginIDValidator()
        case .comment: return CommentValidator()
        case .dropDown: return DropDownValidator()
        case .datePicker: return DatePickerValidator()
        case .companyID : return CompanyIdValidator()
        case .amount :   return AmountValidator()
        case .bioPin: return BioPinValidator()
        case .familyName, .name, .address, .poBox, .dateOfBirth,
             .mobileNumber, .mobileNumberLogin, .qatariId, .qatariIdLogin:
            return userInfoCategoryValidator(type: type)
        case .email, .emailLogin, .passwordLogin, .confirmPassword, .password,
             .username:
            return authenticationCategoryValidator(type: type)
        }
    }
    static func userInfoCategoryValidator(type: FieldType) -> ValidatorConvertible {
        switch type {
        case .familyName : return FamilyNameValidator()
        case .name : return NameValidator()
        case .address : return AddessValidator()
        case .poBox : return PoBoxValidator()
        case .mobileNumber, .mobileNumberLogin: return MobileNumberValidator() // to be corrected
        case .qatariId, .qatariIdLogin : return QatariIdValidator()
        case .dateOfBirth : return DateOfBirthPickerValidator()
        default : return TextValidator()

        }
    }

    static func authenticationCategoryValidator(type: FieldType) -> ValidatorConvertible {
        switch type {
        case .email, .emailLogin: return EmailValidator()
        case .passwordLogin: return PasswordLoginValidator()
        case .password: return PasswordValidator()
        case .confirmPassword: return ConfirmPasswordValidator()
        case .username : return UsernameValidator()
        default : return TextValidator()
        }
    }
}
struct MaxLength {
    static let name = 16
    static let qatariID = 11
    static let mobile = 8
    static let carPlate = 6
    static let carPlateDiplomatic = 7
    static let bioPin = 4
    static let poBox = 10
    static let address = 100
    static let comment = 255
}
struct Regex {
    static let passwordLogin = "^.{4,}"
    static let password =     "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[.#?!@$%^&*-]).{8,}$"

    static let email = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$"
    static let name = "^.{3,16}"
    // Name and lastname can accept arabic letters too
    static let alphaNumericName = "^[A-Za-zء-ي ’]{1,20}$"
    static let alphaNumericUsername =  "^[a-zA-Z0-9ء-ي.#?!$%^&*-]{3,16}$"
    static let text = "^.{3,16}"
    static let comment = "^[^<>-]{20,}$"
    static let address = "^[^<>-]+$"
    static let qatariIdLength = ".{11}$"
    static let mobileLength = "^.{8}$"
    static let companyId = "[A-Za-z0-9]{2}-[A-Za-z0-9]{4}-[A-Za-z0-9]{2}"
    static let amount = "^.{1,}"
    static let carPlateLength =  "^[0-9]{3,6}$"
    static let carPlateDiplomatic = "^([0-9]{3}-[0-9]{2,3}|[0-9]{6})$"
    static let bioPin = "^.{4}$"
    static let poBox =  "^.{3,10}$"
}

struct CarPlateValidator: ValidatorConvertible {
    var plateType: CarPlateType
    init(type: CarPlateType) {
        self.plateType = type
    }
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        switch plateType {
        case .defaultType:
            try validateRegex(value: value, pattern: Regex.carPlateLength,
                              errorMessage: LocalizableShared.carPlateNotValid.localized)
        case .diplomatic:
            try validateRegex(value: value, pattern: Regex.carPlateDiplomatic,
                              errorMessage: LocalizableShared.diplomaticCarPlateInvalid.localized)

        }
        return true
    }
}

struct AmountValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.amount,
                          errorMessage: LocalizableShared.requiredFieldError.localized)
        return true
    }
}

struct BioPinValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.bioPin, errorMessage: LocalizableShared.biopinVotValid.localized)
        return true
    }
}

struct CompanyIdValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.companyId,
                          errorMessage: LocalizableShared.companyIdInvalid.localized)
        return true
    }
}

struct QatariIdValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}

        try validateRegex(value: value, pattern: Regex.qatariIdLength,
                          errorMessage: LocalizableShared.qidNotValid.localized)
        return true
    }
}

struct PasswordLoginValidator: ValidatorConvertible {
    // validate Login Password
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.passwordEmpty.localized)}
        try validateRegex(value: value, pattern: Regex.passwordLogin,
                          errorMessage: LocalizedAuthentication.loginPassword.localized)
        return true
    }
}

struct PasswordValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.passwordEmpty.localized)}
        try evaluateRegex(value: value, pattern: Regex.password,
                          errorMessage: LocalizableShared.passwordNotValid.localized)
        return true
    }
}

struct ConfirmPasswordValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.confirmPasswordEmpty.localized)}
        return true
    }
}

struct EmailValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.email, errorMessage: LocalizableShared.emailNotValid.localized)
        return true
    }
}

struct UsernameValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try evaluateRegex(value: value, pattern: Regex.alphaNumericUsername,
                          errorMessage: LocalizableShared.usernameNotValid.localized)
            return true
    }
}

struct LoginIDValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.loginIDEmpty.localized)}
        return true
    }
}

struct NameValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.alphaNumericName,
                          errorMessage: LocalizableShared.nameNotValid.localized)
        return true
    }
}

struct FamilyNameValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.alphaNumericName,
                          errorMessage: LocalizableShared.familyNameNotValid.localized)
        return true
    }
}

struct AddessValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
       // guard value != "" else {throw ValidationError(LocalizableShared.addressEmpty.localized)}
        if value != "" {
            try validateRegex(value: value, pattern: Regex.address,
                              errorMessage: LocalizableShared.addressInvalid.localized)
        }
        return true
    }
}
struct PoBoxValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
       // guard value != "" else {throw ValidationError(LocalizableShared.poBoxEmpty.localized)}
        if value != "" {
            try validateRegex(value: value, pattern: Regex.poBox,
                              errorMessage: LocalizableShared.poBoxInvalid.localized)
        }
        return true
    }
}

struct TextValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
//        try validateRegex(value: value, pattern: Regex.text, errorMessage: "textError")
        return true
    }
}

struct CommentValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try evaluateRegex(value: value, pattern: Regex.comment,
                          errorMessage: LocalizableShared.commentNotValid.localized)
        return true
    }
}

struct MobileNumberValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        try validateRegex(value: value, pattern: Regex.mobileLength,
                          errorMessage: LocalizableShared.mobileNotValid.localized)
        return true
    }
}

struct DropDownValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        return true
    }
}

struct DatePickerValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        return true
    }
}

struct DateOfBirthPickerValidator: ValidatorConvertible {
    func validated(_ value: String) throws -> Bool {
        guard value != "" else {throw ValidationError(LocalizableShared.requiredFieldError.localized)}
        return true
    }
}

func validateRegex(value: String, pattern: String, errorMessage: String) throws {
    do {
        let firstNameRegex = try NSRegularExpression(pattern: pattern, options: .caseInsensitive)
        if firstNameRegex.notMatchedIn(value: value) {
            throw ValidationError(errorMessage)
        }
    } catch {
        throw ValidationError(errorMessage)
    }
}
func evaluateRegex(value: String, pattern: String, errorMessage: String) throws {
    do {
        let isMatched = NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: value)
        if isMatched  == false {
            throw ValidationError(errorMessage)
        }
    } catch {
        throw ValidationError(errorMessage)
    }
}
