//
//  CommonTextFieldView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 16/07/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit
import Combine

enum FTTextFieldState: Int {
    case defaultField = 0
    case editedField = 1
    case errorField = 2
    case validField = 3
    case initialField = 4
}

class CommonInputFieldView: UIView {
    // MARK: - Outlets
    @IBOutlet weak var textfieldContainerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var textField: WQTextField!
    @IBOutlet weak var hintLabel: UILabel!

    // MARK: - Public properties

    var title: String? {
        get {
            return titleLabel.text
        }
        set {
            self.titleLabel.text = newValue
            self.titleLabel.isHidden = false
            self.placeholder = ""
        }
    }

    var titleColor: UIColor? {
        didSet {
           titleLabel.textColor = titleColor

        }
    }

    var hint: String? {
        didSet {
            guard let hint = hint else { return }
            hintLabel.isHidden = false
            hintLabel.setText(text: hint, font: Fonts.bookFontName,
                              size: 11,
                              forgroundColor: UIColor(hexString: "#04267E").withAlphaComponent(0.5),
                              align: languageIsEnglish ? .left : .right)
        }
    }

    var value: String?

    var errorText: String? {
        didSet {
            self.textFieldState = .errorField
            self.errorLabel.text = errorText
            textfieldContainerView.border(borderColor: UIColor.wqLightRed.withAlphaComponent(0.6), borderwidth: 1)
            textfieldContainerView.roundCorners(radius: 10.adjusted)
        }
    }

    var textFieldState: FTTextFieldState = .initialField {
        didSet {
            self.handleFieldState()

        }
    }
    
    var isMandatory: Bool = true
    
    internal var isValidationMandatory: Bool {
        return isMandatory || !(value?.isEmpty ?? true)
    }

    var isValid: Bool {
        do {
            return ((try value?.validatedText(validationType: fieldType)) != nil)
        } catch {
            guard let err = error as? ValidationError else { return false }
            self.errorText = err.message
            textfieldContainerView.border(borderColor: UIColor.wqLightRed.withAlphaComponent(0.6), borderwidth: 1)
            textfieldContainerView.roundCorners(radius: 10.adjusted)
            return false
        }
    }

    var fieldType: FieldType = .text {
        didSet {
        }
    }

    var textPublisher: AnyPublisher<String, Never>?

    var textFieldViewStyle: TextFieldViewStyle? {
        didSet {
            self.initTextFieldView()
        }
    }

    var placeholder: String? {
        didSet {
            textField.placeholder = placeholder ?? ""
        }
    }

    var dataArray: [String]?

    // MARK: - Initialization

    override init(frame: CGRect) {
        super.init(frame: frame)

        initView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        initView()
    }

    // MARK: - Private functions

    private func initView() {
        self.loadNibContent()

    }

    private func initTextFieldView() {

        if textField != nil { //
            initTextView()
        }
        initTitleLabel()
        initErrorLabel()

    }

    func handleFieldState() {

        switch textFieldState {

        case .initialField, .defaultField, .editedField, .validField:
            self.errorLabel.isHidden = true
            textfieldContainerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
            textfieldContainerView.roundCorners(radius: 10.adjusted)

        case .errorField:
            self.errorLabel.isHidden = false
        }
    }

    private func initTextView() {
        self.textFieldState = .initialField

        textField.didEndEditing = {
            if self.textField.isEmpty() {
                self.textFieldState = .defaultField
            }
        }

    }
    func initTitleLabel() {
        titleLabel.font = textFieldViewStyle?.titleFont
        titleLabel.textColor = textFieldViewStyle?.titleColor
    }

    func initErrorLabel() {

        errorLabel.isHidden = true
        errorLabel.font = textFieldViewStyle?.errorTitleFont
        errorLabel.textColor = textFieldViewStyle?.errorTitleColor
    }
    
    func resetLabel() {
        self.errorLabel.text = ""
        textfieldContainerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
        textfieldContainerView.roundCorners(radius: 10.adjusted)
    }

    // MARK: - Public functions

    func setUpView() {
        textFieldViewStyle = WQTextFieldViewStyle()

    }

}
