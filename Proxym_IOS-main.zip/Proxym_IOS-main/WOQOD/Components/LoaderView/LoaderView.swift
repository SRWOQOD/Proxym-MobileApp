//
//  LoaderView.swift
//  WOQOD
//
//  Created by rim ktari on 9/15/20.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit
class LoaderView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        let activityIndicator = UIActivityIndicatorView()

        activityIndicator.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
        activityIndicator.center = self.center
        activityIndicator.color = UIColor.wqBlue
        activityIndicator.startAnimating()

        self.addSubview(activityIndicator)

        self.backgroundColor = UIColor.black.withAlphaComponent(0.05)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
