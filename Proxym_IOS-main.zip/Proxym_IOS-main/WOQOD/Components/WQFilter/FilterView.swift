//
//  FilterView.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 27/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class FilterView: UIView {

    // MARK: - IBOutlets
    @IBOutlet weak var filterCollectionView: UICollectionView!
    @IBOutlet var containerView: UIView!
    var didSelectFilter: ((_ item: FilterItemViewModel) -> Void)?

    // MARK: - Properties
    var filterItems: [FilterItemViewModel] = []

    // MARK: - Private Properties
    var KNumberCellWidth = 88.adjusted {
        didSet {
           initCollectionView()
        }
    }
    private let KNumberCellHeight = 45.adjusted
    var KNumberCellInterItemsSpace = 5.adjusted {
        didSet {
          initCollectionView()
        }
    }
    private let KNumberCellInterLineSpace = 6.adjusted

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
        initCollectionView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
        initCollectionView()
    }

    // MARK: - Private methods
    fileprivate func initCollectionView() {

        filterCollectionView.backgroundColor = UIColor.clear
        filterCollectionView.delegate = self
        filterCollectionView.dataSource = self
        filterCollectionView.registerCellNib(FilterItemCollectionViewCell.self)
        filterCollectionView.allowsSelection = true

    }
}

extension FilterView: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath)
    -> UICollectionViewCell {

        let cell: FilterItemCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath)
        let item = filterItems[indexPath.row]

        cell.setup(viewModel: item)

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filterItems.count
    }

}

extension FilterView: UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        let selectedItem = filterItems[indexPath.row]
        didSelectFilter?(selectedItem)
    }

}

extension FilterView: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        var cellSize: CGSize = CGSize(width: KNumberCellWidth, height: KNumberCellHeight)

        switch  indexPath.row {
        case 3, 4:
             cellSize = CGSize(width: (collectionView.frame.width - 52) / 2, height: KNumberCellHeight)
        default:
             cellSize = CGSize(width: KNumberCellWidth, height: KNumberCellHeight)
        }
        return cellSize
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return KNumberCellInterLineSpace
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return KNumberCellInterItemsSpace
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 14, left: 24, bottom: 19, right: 22)
    }

}
