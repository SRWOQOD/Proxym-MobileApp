//
//  FilterItemCollectionViewCell.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 27/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import UIKit

class FilterItemCollectionViewCell: UICollectionViewCell, ReusableView {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var filterItemTitle: UILabel!

    var shouldUpdateWhenSelecting = true
    var itemSelected = false

    override var isSelected: Bool {
        didSet {
            if shouldUpdateWhenSelecting {
                updateColorWhenCellClicked()
            }
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        initUI()
    }

    // MARK: - Private functions
    private func initUI() {
        containerView.border(borderColor: UIColor.wqBlue.withAlphaComponent(0.15), borderwidth: 1)
        containerView.roundCorners(radius: 10.adjusted)
        updateColorWhenCellClicked()
    }

     func updateColorWhenCellClicked() {
        containerView.backgroundColor = isSelected ? .wqBlue : .clear
        filterItemTitle.textColor = isSelected ? UIColor.white : .wqBlue
    }

    func setUpItemView() {
        containerView.backgroundColor = itemSelected ? .wqBlue : .clear
        filterItemTitle.textColor = itemSelected ? UIColor.white : .wqBlue

    }
    // MARK: - Public functions
    func setup(viewModel: FilterItemViewModel) {

        filterItemTitle.setText(text: viewModel.title, font: Fonts.mediumFontName, size: 13)

        updateColorWhenCellClicked()

    }

}
