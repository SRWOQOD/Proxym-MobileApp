//
//  FilterItemViewModel.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 27/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

// MARK: - Enum

enum FilterCellType {
    case all
    case date
    case category
    case sector
    case status

}

class FilterItemViewModel {

    // MARK: - Properties
    var title: String?
    var type: FilterCellType = .all
    var placeholder: String?
    var dataArray: [String] = []

    // MARK: - Initialization
    init(title: String?, type: FilterCellType, placeholder: String?, dataArray: [String] = []) {
        self.title = title
        self.type = type
        self.placeholder = placeholder
        self.dataArray = dataArray
    }

}
