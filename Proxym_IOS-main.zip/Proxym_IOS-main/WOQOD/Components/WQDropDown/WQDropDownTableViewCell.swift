//
//  WQDropDownTableViewCell.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 20/04/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import Foundation
import UIKit
import DropDown

class WQDropDownTableViewCell: DropDownCell {
    @IBOutlet weak var containerView: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = .clear
        self.selectionStyle = .none
        initUI()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        containerView.backgroundColor = selected ? UIColor.wqBlue.withAlphaComponent(0.10) : .clear
//        containerView.backgroundColor = UIColor.wqBlue.withAlphaComponent(0.10)
        // Configure the view for the selected state
    }

    // MARK: - Private methods
    fileprivate func initUI() {
        containerView.roundCorners(radius: 12)
        containerView.backgroundColor = .clear
    }
}
