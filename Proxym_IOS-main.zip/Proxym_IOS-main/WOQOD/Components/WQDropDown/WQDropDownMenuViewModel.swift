//
//  WQDropDownMenuViewModel.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 26/04/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

class WQDropDownMenuViewModel: ViewModel {

    // MARK: - Public properties
    var suggestionsArray: [String] = []

    // Update the table view  with suggested values according to what user is typing
    // ( search can be by name of the area)
    /// - Parameter searchBarTexte: what the user typed in the search bar
     func autoCompleteText( in textField: UITextField, using string: String, suggestionsArray: [String]) -> [String] {
        var matches: [String] = []
        if !string.isEmpty {
            matches = suggestionsArray.filter {
                ($0.lowercased().contains(string.lowercased()))
            }
        }
        return matches
    }
}
