//
//  WQDropDownMenu.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 31/01/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit
import DropDown
import Combine

class WQDropDownMenu: CommonInputFieldView {
    @IBOutlet weak var showDropDownButton: UIButton!
    @IBOutlet weak var bottomArrowButton: UIButton!

    // MARK: - Public properties

    var didSelectItem : ((_ index: Int, _ item: String) -> Void)?
    @Published var selectedText: String = ""
    let pickerViewWillChangeValue = ObservableObjectPublisher()
    var textChanged: AnyPublisher<String, Never> {
        return textField.textPublisher
    }
    var shouldSelectFirstItem = false
    let dropDownViewModel = WQDropDownMenuViewModel()
    var filteredArray = [String]()
    // MARK: - Private variables

    private let dropDown = DropDown()
    private var isSelected = false
    private var cancellable = Set<AnyCancellable>()
    private var dropMenuViewState: FTTextFieldState = .initialField {
        didSet {
            self.handleFieldState()
        }
    }
    var searchActive: Bool = false {
        didSet {
            if searchActive {
                activateAutoComplete()
            }
        }
    }

    // MARK: - Overrided properties
    var defaultValueDropDownMenu: String? {
        didSet {
            guard let index = dataArray?.firstIndex(of: defaultValueDropDownMenu ?? "") else { return }
             self.dropDown.selectRow(index)
            self.value = defaultValueDropDownMenu
            selectedText = defaultValueDropDownMenu ?? ""
        }
    }

    override var value: String? {
        get {
            return self.textField.text
        }
        set {
            self.textField.text = newValue
            isSelected = true
            resetView()
        }
    }

    override var placeholder: String? {
        didSet {
            if !shouldSelectFirstItem {
                if let placeholder = placeholder {
                    self.textField.placeholder = placeholder
                    textField.placeHolderStyle( textField.textFieldStyle?.placeholderTextColor,
                                                textField.textFieldStyle?.placeholderTextFont)
                }
            }
        }
    }

    override var title: String? {
        get {
            return titleLabel.text
        }

        set {
            titleLabel.text = newValue
            self.placeholder = ""

        }

    }

    override var dataArray: [String]? {
        didSet {
            dropDown.dataSource = dataArray ?? []
            dropDown.reloadAllComponents()
        }
    }

    // MARK: - Overrides

    var errorValue: String? {
        didSet {
            if errorValue != nil {
                self.errorLabel.text = errorValue
                self.errorLabel.isHidden = false
            }
        }
    }

    // MARK: - Initialisers

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    override func layoutSubviews() {
        guard dropMenuViewState == .initialField else { return }
        dropMenuViewState = .initialField
    }

    // MARK: - Private methods

    private func commonInit() {
        super.setUpView()
        setupButton()
        textField.textFieldStyle = WQTextFieldStyle()
        initClustorDropMenu()
    }

    private func resetView() {
        dropMenuViewState = .initialField
    }

    private func setupButton() {
        guard let image = UIImage(named: "ic_arrow_bottom") else { return }
        self.bottomArrowButton.setImage(image, for: .normal)
    }

    private func initClustorDropMenu() {
        dropDown.direction = .bottom
        dropDown.dismissMode = .onTap
        textFieldState = .initialField
        dropDown.selectionAction = { [unowned self] (_: Int, item: String) in
            textFieldState = .initialField
            self.value = item
            self.selectedText = dropDown.selectedItem ?? ""
            pickerViewWillChangeValue.send()
            self.textField.endEditing(true)
        }
    }

    private func setupDropDownUI() {
        DropDown.appearance().cellHeight = 50
        DropDown.appearance().selectedTextColor = .wqBlue
        DropDown.appearance().textColor = .wqBlue
        DropDown.appearance().backgroundColor = UIColor.white
        DropDown.appearance().selectionBackgroundColor = .clear
        DropDown.appearance().textFont = UIFont(name: Fonts.mediumFontName, size: 13) ?? UIFont()
        DropDown.appearance().setupCornerRadius(15)
        DropDown.appearance().shadowOpacity = 0.2
        DropDown.appearance().shadowColor = .wqBlue.withAlphaComponent(0.6)
        DropDown.appearance().shadowRadius = 8
        dropDown.cellNib = UINib(nibName: "WQDropDownTableViewCell", bundle: nil)
        dropDown.customCellConfiguration = { (_: Index, item: String, cell: DropDownCell) -> Void in
           guard let cell = cell as? WQDropDownTableViewCell else { return }
            cell.optionLabel.setText(text: item, font: Fonts.mediumFontName,
                                     size: 13, forgroundColor: .wqBlue, align:
                                        languageIsEnglish ? .left : .right)
        }
    }
    private func activateAutoComplete() {
        showDropDownButton.isHidden = true
        textField.delegate = self
    }

    // MARK: - public functions

    public func clearDropMenu() {
        dropDown.clearSelection()
        self.selectedText = ""
        self.textField.text = ""
    }

    public func createDropDownMenu() {
        dropDown.anchorView = self
        dropDown.bottomOffset = CGPoint(x: 0, y: (dropDown.anchorView?.plainView.bounds.height)! - 15)
        setupDropDownUI()
        dropDown.show()
    }

    @objc func showDropDownMenuRightAction() {
        dropDown.dataSource = dataArray ?? []
        dropDown.reloadAllComponents()
        createDropDownMenu()
    }

    // MARK: - Actions

    @IBAction func showDropDownMenu(_ sender: Any) {
        UIResponder.currentFirstResponder?.resignFirstResponder()
        createDropDownMenu()
    }
}

// MARK: - Extensions

extension WQDropDownMenu: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        dropDown.dataSource = dataArray ?? []
        dropDown.reloadAllComponents()
        createDropDownMenu()
    }

    func textFieldDidChangeSelection(_ textField: UITextField) {
        guard let textFieldText = textField.text else {
            return
        }
        filteredArray = dropDownViewModel.autoCompleteText(in: textField,
                    using: textFieldText, suggestionsArray: dataArray ?? [])
        dropDown.dataSource = filteredArray
        dropDown.reloadAllComponents()
        createDropDownMenu()
    }
}
