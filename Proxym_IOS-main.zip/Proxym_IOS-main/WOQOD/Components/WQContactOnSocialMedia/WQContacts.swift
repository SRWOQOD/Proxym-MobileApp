//
//  WQContacts.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 09/10/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation

let wqPhone = ["40217777", "800-3835"]
let wqEmail = "customerservice@woqod.com.qa"
let wqWebUrl =  "http://www.woqod.com"

let wqFacebookAppURL =  "facebook.com/QatarFuelWoqod/"
let wqFacebookWebURL =  "https://www.facebook.com/QatarFuelWoqod/"

let wqYoutubeAppURL =  "youtube.com/channel/UCNTcsw1_FgU6cxET0YDLDwg"
let wqYoutubeWebURL =  "https://www.youtube.com/channel/UCNTcsw1_FgU6cxET0YDLDwg"

let wqTwitterAppURL = "twitter.com/qatarfuel_woqod?lang=fr"
let wqTwitterWebURL =  "https://twitter.com/qatarfuel_woqod?lang=fr"

let wqInstagramAppURL =  "instagram://qatarfuelwoqod"
let wqInstagramWebURL = "https://www.instagram.com/qatarfuelwoqod/"

let wqLinkedinAppURL = "linkedin.com/company/qatar-fuel/"
let wqLinkedinWebURL = "https://www.linkedin.com/company/qatar-fuel/"
