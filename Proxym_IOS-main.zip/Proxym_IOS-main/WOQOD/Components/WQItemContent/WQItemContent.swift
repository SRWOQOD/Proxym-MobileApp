//
//  WQItemContent.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 24/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import Foundation
import UIKit

class WQItemContent: UIView {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var containerViewHeightConstraint: NSLayoutConstraint!

    var shouldRoundView: Bool = true
    // MARK: - Properties
    var titleColor: UIColor = .wqBlue {
        didSet {
            titleLabel.textColor = titleColor
        }
    }
    var valueColor: UIColor = .wqBlue {
        didSet {
            titleLabel.textColor = titleColor
        }
    }
    var title: String? {
        didSet {
            titleLabel.setText(text: title, font: Fonts.mediumFontName, size: 15, forgroundColor: .wqBlue)
        }
    }

    var value: String? {
        didSet {
            valueLabel.textAlignment = .right
            valueLabel.setText(text: value, font: Fonts.bookFontName, size: 13, forgroundColor: .wqBlue,
                               align: languageIsArabic ? .right : .left)
        }
    }

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }
    override func layoutSubviews() {

        if shouldRoundView {
            self.containerView.roundCorners(radius: 11)
        }

    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
    }

}
