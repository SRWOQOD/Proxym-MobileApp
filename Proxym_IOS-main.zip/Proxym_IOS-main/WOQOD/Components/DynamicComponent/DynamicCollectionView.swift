//
//  DynamicCollectionView.swift
//  Betterise
//
//  Created by Dhekra Rouatbi on 05/07/2018.
//  Copyright © 2018 Proxym-IT. All rights reserved.
//

import UIKit

class DynamicCollectionView: UICollectionView {

        override func layoutSubviews() {
            super.layoutSubviews()
            if !__CGSizeEqualToSize(bounds.size, self.intrinsicContentSize) {
                self.invalidateIntrinsicContentSize()
            }
        }

        override var intrinsicContentSize: CGSize {
            return collectionViewLayout.collectionViewContentSize
        }
}
