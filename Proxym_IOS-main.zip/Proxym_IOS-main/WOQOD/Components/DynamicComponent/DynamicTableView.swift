//
//  DynamicTableView.swift
//  Betterise
//
//  Created by Dhekra Rouatbi on 09/07/2018.
//  Copyright © 2018 Proxym-IT. All rights reserved.
//

import UIKit

class DynamicTableView: UITableView {

    override func layoutSubviews() {
        super.layoutSubviews()
        if !__CGSizeEqualToSize(bounds.size, self.intrinsicContentSize) {
            self.invalidateIntrinsicContentSize()
        }
        self.separatorStyle = .none
    }

    override var intrinsicContentSize: CGSize {
        return self.contentSize
    }

}
