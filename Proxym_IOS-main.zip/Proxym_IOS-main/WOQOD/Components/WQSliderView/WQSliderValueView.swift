//
//  WQSliderValueView.swift
//  WOQOD
//
//  Created by Oumaima-ben.ghalba on 10/01/2022.
//  Copyright © 2022 rim ktari. All rights reserved.
//

import UIKit

class WQSliderValueView: UIView {
    @IBOutlet weak var valueImageView: UIImageView!
    @IBOutlet weak var valueLabel: UILabel!

    var onValueChanged: (String) -> Void  = {_ in }

    var currentValue: String = "" {
        didSet {
            valueLabel.setText(text: currentValue, font: Fonts.mediumFontName,
                               size: 12, forgroundColor: .white, align: .center)
            onValueChanged(currentValue)
        }
    }

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
