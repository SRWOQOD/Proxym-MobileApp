//
//  WoqodSlider.swift
//  WOQOD
//
//  Created by Oumayma.guefrej on 07/08/2020.
//  Copyright © 2020 rim ktari. All rights reserved.
//

import  UIKit

class WQSliderView: UIView {

    @IBOutlet weak var woqodSlider: Slider!
    @IBOutlet weak var minSliderValue: UILabel!
    @IBOutlet weak var maxSliderValue: UILabel!

    var thumbFrame: CGRect {
        return woqodSlider.thumbRect(forBounds: bounds, trackRect: woqodSlider.trackRect(forBounds: bounds),
                                     value: woqodSlider.value)
    }

    var currentValueLabel: WQSliderValueView =  WQSliderValueView()
    var textFont: String = Fonts.mediumFontName
    var textSize: Int = 12
    var minColor: UIColor = UIColor.wqBlue.withAlphaComponent(0.6)
    var maxColor: UIColor = UIColor.wqBlue.withAlphaComponent(0.6)
    var minUnity: String = ""
    var maxUnity: String = ""

    var minTrackValue: Float = 0.0 {
        didSet {
            let intValue = Int(minTrackValue)
            minSliderValue.setText(text: "\(intValue)" + minUnity, font: textFont,
                                   size: textSize, forgroundColor: minColor)
            woqodSlider.minimumValue = minTrackValue
        }
    }
    var maxTrackValue: Float = 0.0 {
        didSet {
            let intValue = Int(maxTrackValue)
            maxSliderValue.setText(text: "\(intValue)" + maxUnity, font: textFont,
                                   size: textSize, forgroundColor: maxColor)
            woqodSlider.maximumValue = maxTrackValue
        }
    }

    var pickedValue: Double {
        get {
            return Double(woqodSlider.value)
        }
        set {
            woqodSlider.value = Float(newValue)
        }
    }

    var sliderColor: UIColor? {
        didSet {
            woqodSlider.thumbTintColor = sliderColor
            woqodSlider.minimumTrackTintColor = sliderColor
        }
    }

    var minValue: String = "12"
    var maxValue: String = "11"
    var isTimeSlider: Bool = false {
        didSet {
            minSliderValue.text = minValue + minUnity
            maxSliderValue.text = maxValue + maxUnity
        }
    }

    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNibContent()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNibContent()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        addSubview(currentValueLabel)
        if currentValueLabel.currentValue == "" {
            currentValueLabel.isHidden = true
        } else {
            currentValueLabel.isHidden = false
            currentValueLabel.currentValue = String(Int(woqodSlider.value))
        }
        woqodSlider.thumbTintColor = minColor
        woqodSlider.minimumTrackTintColor = minColor

    }

    @IBAction func swipeSlider(_ sender: Any) {

        setUISliderThumbValueWithView(slider: woqodSlider)
        currentValueLabel.valueImageView.image = isTimeSlider ?
            UIImage(named: "ic_blue_slider") :
            UIImage(named: "ic_slider")

        if woqodSlider.isTracking {
            currentValueLabel.isHidden = false
            currentValueLabel.currentValue = isTimeSlider ? convert24hTo12H()
                    :  String(Int(woqodSlider.value)) + minUnity
        } else {
            currentValueLabel.isHidden = true
        }
    }

    // TO FIX
    func convert24hTo12H() -> String {
        if woqodSlider.value >= 13 {
            return "\(Int(woqodSlider.value) - 12) \(maxUnity)"
        } else if (12...12.99).contains(woqodSlider.value) {
            return "\(Int(woqodSlider.value)) \(maxUnity)"
        } else {
            let value = woqodSlider.value < 1 ? 12 : woqodSlider.value
            return "\(Int(value)) \(minUnity)"
        }
    }
    func setUISliderThumbValueWithView(slider: UISlider) {
        let slidertTrack: CGRect = slider.trackRect(forBounds: slider.bounds)
        let sliderFrm: CGRect = slider .thumbRect(forBounds: slider.bounds,
                                                  trackRect: slidertTrack,
                                                  value: slider.value)
        currentValueLabel.frame = CGRect(x: sliderFrm.origin.x
                                            + slider.frame.origin.x - 10,
                                         y: thumbFrame.origin.y - (5+thumbFrame.size.height),
                                         width: 62, height: 40)
    }
}

class Slider: UISlider {

    override func trackRect(forBounds bounds: CGRect) -> CGRect {

        var result = super.trackRect(forBounds: bounds)
        result.origin.x = 0
        result.size.width = bounds.size.width
        result.size.height = 10.adjusted // added height for desired effect
        return result
    }

}
