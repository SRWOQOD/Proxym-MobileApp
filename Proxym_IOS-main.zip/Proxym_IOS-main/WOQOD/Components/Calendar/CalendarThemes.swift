//
//  CalendarThemes.swift
//  FineTuneParent
//
//  Created by Ayoub GBADA on 10/16/19.
//  Copyright © 2019 Proxym-it. All rights reserved.
//

import Foundation
import UIKit

public struct CalendarTheme {

    var monthContainerColor: UIColor?
    var weekContainerColor: UIColor?
    var dayContainerColor: UIColor?
    var selectedDateColor: UIColor?
    var contentViewColor: UIColor?
    var weekFontLabel: UIFont?
    var weekLabelTextColor: UIColor?
    var monthLabelTextColor: UIColor?
    var dayLabelTextColor: UIColor?
    var monthFontLabel: UIFont?
    var dayFontLabel: UIFont?

}

public var wqCalender = { return
    CalendarTheme(

        monthContainerColor: .white,

        weekContainerColor: UIColor.white,

        selectedDateColor: UIColor.wqOrange,

        contentViewColor: UIColor.white,

        weekFontLabel: UIFont(name: Fonts.bookFontName, size: 14.adjusted),

        dayLabelTextColor: .black,

        monthFontLabel: UIFont(name: Fonts.bookFontName, size: 16.adjusted),

        dayFontLabel: UIFont(name: Fonts.bookFontName, size: 14.adjusted)
    )
}
